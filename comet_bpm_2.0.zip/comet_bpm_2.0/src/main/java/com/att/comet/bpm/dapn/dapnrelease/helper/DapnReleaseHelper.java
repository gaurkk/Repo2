package com.att.comet.bpm.dapn.dapnrelease.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class DapnReleaseHelper {
	
	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private AvosDAO avosDAO;
	
	@Autowired
	private BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	
	
	public void preOperationDapnRelease(CommonBO commonBO) throws CamundaServiceException {
		
		// Delete BpmOrderProcess
		commonBO.setProcessId(1030L);
		bpmDAO.deleteBpmOrderProcess(commonBO);
		
		// Save BpmOrderProcess
		commonBO.setBpmStatusId(1001L);
		commonBO.setProcessId(1030L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		
		// Save AVOSProcessInstances
		commonBO.setProcessId(1030L);
		commonBO.setBpmProcessId(1030L);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		
		// Save BpmOrderWorkStep
		commonBO.setWorkStepId(1077L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		
		genericDAO.setReminder1And2FromSlaWorkingDayForITOPSDAPNRelease(commonBO);
		
		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3212L);
		businessStepIdList.add(3213L);
		businessStepIdList.add(3214L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		
		// Delete BpmOrderBusinessStep
		commonBO.setWorkStepId(1077L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);
		
		commonBO.setOrderContactTypeId(1024L);
		String attuid = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(attuid)) {
			commonBO.setAttuid(attuid);
			commonBO.setAssignee(attuid);
			commonBO.setToEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));

		} else {
			// get CCS PM Email
			commonBO.setToEmail(
					genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1008L));

		}
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));
		
		//commonBO.setCcEmail((commonBO.getToEmail()+ "," + commonBO.getAdminEmail())+","+omEmail1+","+niEmail1);
	}

	
	public void postOperationDapnRelease(CommonBO commonBO) throws CamundaServiceException {
		
		//Update BpmOrderWorkStep
		commonBO.setWorkStepId(1077L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		
		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3212L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		
	
		
		// Save BpmOrderBusinessStep
		//commonBO.setBusinessStepValue(commonBO.getTicketNum());
		commonBO.setBusinessStepId(3212L);
		commonBO.setUpdatedBy(commonBO.getAssignee());
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		
		// Save BpmOrderBusStepHistory
		commonBO.setBusinessStepId(3212L);
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);
		
		
		
		//Update BpmOrderProcess
		commonBO.setProcessId(1030L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);
		
		orderDAO.updateOrderStatus(commonBO.getOrderId(), 1068L);
		
		//update DAPN Inventory
		bpmDAO.updateDapnInventory(commonBO);
		
	}

}
