package com.att.comet.bpm.common.repository;

import java.util.Date;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.Orders;

@Repository
public interface OrdersRepository extends JpaRepository<Orders, Long> {

	@Modifying
	@Query(value = "update Orders o set o.orderStatus.orderStatusId=:orderStatusId where o.orderId=:orderId")
	public int updateOrderStatusByOrderId(@Param(value = "orderId") Long orderId,
			@Param(value = "orderStatusId") Long orderStatusId);
	/*@Modifying
	@Query(value = "update Orders o set o.orderStatus.orderStatusId=:orderStatusId,o.updatedBy.attuid=:updatedBy,o.updatedOn=:updatedOn where o.orderId=:orderId")
	int updateOrderByOrderId(@Param(value = "orderId") Long orderId, @Param(value = "orderStatusId") Long orderStatusId,
			@Param(value = "updatedBy") String updatedBy, @Param(value = "updatedOn") Date updatedOn);*/
	
	@Modifying
	@Query(value = "update Orders set order_status_id=:orderStatusId where orderId=:orderId")
	public int  updateOrderStatusIdByOrderId(@Param(value = "orderId") Long orderId,@Param(value = "orderStatusId") Long orderStatusId);
	@Modifying
	@Query(value = "update Orders set order_status_id=:orderStatusId, updated_on=:updatedOn where orderId=:orderId")
	public int updateOrderStatusIdAndUpdatedOnByOrderId(@Param(value = "orderId") Long orderId,@Param(value = "orderStatusId") Long orderStatusId, @Param(value = "updatedOn") Date updatedOn);
}
