package com.att.comet.bpm.iwos.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class APNHLRIWOSCreationHelper {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCreationHelper.class);

	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private AvosDAO avosDAO;

	public void preOperationIWOSCreation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method preOperationIWOSCreation", this);
		commonBO.setProcessId(1003L);//APN HLR IWOS PROCESS
		commonBO.setBpmProcessId(1003L);//APN HLR IWOS PROCESS
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		/**
		 * Deleting bpm_order_business_step for business_step_id in( 3193,3194,3142).
		 **/
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3142L);
		businessStepIdList.add(3193L);
		businessStepIdList.add(3194L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		/** orderType is New **/
		if (commonBO.getOrderTypeName().equalsIgnoreCase("New")) {
			commonBO.setBpmStatusId(1001L);
			commonBO.setProcessId(1024L);//APN HLR IWOS PROCESS
			commonBO.setBpmProcessId(1024L);//APN HLR IWOS PROCESS
			bpmDAO.saveBpmOrderProcess(commonBO);

			commonBO.setWorkStepId(1063L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1063L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {/** orderType is not New **/
			commonBO.setProcessId(1024L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderProcess(commonBO);

			commonBO.setWorkStepId(1063L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		// Dynamic user DB Operation
		List<String> CCSPMEmailList = null;
		commonBO.setOrderContactTypeId(1006L); 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO); 
		if (!CollectionUtils.isEmpty(attUidList)) { 
			logger.debug("osdEmailList is not empty : ", +attUidList.size()); 
			String ccsPM = attUidList.get(0); 
			commonBO.setAttuid(ccsPM); 
			commonBO.setIwosHlrAssignee(ccsPM);
			CCSPMEmailList = userDAO.getUserEmail(commonBO); 
			commonBO.setEmailList(CCSPMEmailList); 
		} else { 
			logger.debug("attUidList is empty: ", +attUidList.size()); 
			commonBO.setRoleId(1005L); 
			CCSPMEmailList = userDAO.getGroupUserEmail(commonBO); 
			commonBO.setEmailList(CCSPMEmailList); 
		}
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}
		// DB COMET Admin Email
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));
		
		// email to be sent to CCPM and Admin as CC in Reminder
		commonBO.setCcEmail((commonBO.getToEmail()+ "," + commonBO.getAdminEmail()));
		
		/* Set Reminder1 & Reminder2 SLA Dates for CCPM */
		genericDAO.setReminder1And2FromSlaWorkingDayForApnHlrCreation(commonBO);

	

		logger.info("@Ending method preOperationIWOSCreation ", this);
	}

	public void postOperationIWOSCreation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method postOperationIWOSCreation ", this);

		/* Get CCSPM ATTUID */
		commonBO.setOrderContactTypeId(1006L);
		String CCSPMAttUId = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);

		/* Insert Into BpmOrderBusinessStep */
		commonBO.setBusinessStepValue(commonBO.getTicketNum());
		commonBO.setComments(commonBO.getComments());
		commonBO.setBusinessStepId(3142L);
		commonBO.setBusinessStepStatus("Created");
		commonBO.setAttuid(CCSPMAttUId);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setWorkStepId(1063L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1063L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		/* Get Email */
		commonBO.setUser_or_group(CCSPMAttUId);
		String userEmail = genericDAO.getEmailFromUsersByActiveAndUserorgroup(commonBO);

		/* Delete AVOSProcessInstances */
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		logger.info("@Ending method postOperationIWOSCreation ", this);
	}
}
