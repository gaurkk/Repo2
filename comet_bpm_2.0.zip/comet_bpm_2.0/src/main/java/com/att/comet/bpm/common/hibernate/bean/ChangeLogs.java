package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_CHANGE_LOGS")
public class ChangeLogs implements Serializable {

	private static final long serialVersionUID = -2311298718011942672L;
	private Long id;
	private Long typeId;
	private Long subTypeId;
	private String subTypeName;
	private Long orderId;
	private String attUID;
	private Long roleId;
	private String roleName;
	private String tabName;
	private String labelName;
	private String fieldName;
	private String oldValue;
	private String newValue;
	private String action;
	private Date modifiedDate;
	private Character crCancel;
	private Date crCancelDate;
	private String crCancelBy;

	@GenericGenerator(name = "generator", strategy = "sequence-identity", parameters = @Parameter(name = "sequence", value = "SEQ_CL_ID"))
	@Id
	@Column(name = "CL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "generator")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "CL_TYPE_ID")
	public Long getTypeId() {
		return typeId;
	}

	public void setTypeId(Long typeId) {
		this.typeId = typeId;
	}

	@Column(name = "CL_SUB_TYPE_ID")
	public Long getSubTypeId() {
		return subTypeId;
	}

	public void setSubTypeId(Long subTypeId) {
		this.subTypeId = subTypeId;
	}

	@Column(name = "CL_SUB_TYPE_NAME")
	public String getSubTypeName() {
		return subTypeName;
	}

	public void setSubTypeName(String subTypeName) {
		this.subTypeName = subTypeName;
	}

	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "ATTUID")
	public String getAttUID() {
		return attUID;
	}

	public void setAttUID(String attUID) {
		this.attUID = attUID;
	}

	@Column(name = "ROLE_ID")
	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	@Column(name = "ROLE_NAME")
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Column(name = "TAB_NAME")
	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	@Column(name = "CL_LABEL_NAME")
	public String getLabelName() {
		return labelName;
	}

	public void setLabelName(String labelName) {
		this.labelName = labelName;
	}

	@Column(name = "CL_FIELD_NAME")
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	@Column(name = "CL_OLD_VALUE")
	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	@Column(name = "CL_NEW_VALUE")
	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	@Column(name = "CL_ACTION")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Column(name = "CL_MODIFIED_ON")
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Column(name = "CL_IS_CR_CANCELLED")
	public Character getCrCancel() {
		return crCancel;
	}

	public void setCrCancel(Character crCancel) {
		this.crCancel = crCancel;
	}

	@Column(name = "CL_CR_CANCEL_ON")
	public Date getCrCancelDate() {
		return crCancelDate;
	}

	public void setCrCancelDate(Date crCancelDate) {
		this.crCancelDate = crCancelDate;
	}

	@Column(name = "CL_CR_CANCEL_BY")
	public String getCrCancelBy() {
		return crCancelBy;
	}

	public void setCrCancelBy(String crCancelBy) {
		this.crCancelBy = crCancelBy;
	}
}