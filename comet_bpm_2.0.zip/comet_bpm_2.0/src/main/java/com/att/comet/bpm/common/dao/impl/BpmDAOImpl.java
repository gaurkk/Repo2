package com.att.comet.bpm.common.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmBusinessStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusStepHistory;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusStepHistoryId;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStepId;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderExpedite;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderProcess;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderProcessId;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStepId;
import com.att.comet.bpm.common.hibernate.bean.BpmProcess;
import com.att.comet.bpm.common.hibernate.bean.BpmStatus;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.hibernate.bean.BpmWorkStep;
import com.att.comet.bpm.common.hibernate.bean.OrderType;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.BpmOrderBusStepHistoryRepository;
import com.att.comet.bpm.common.repository.BpmOrderBusinessStepRepository;
import com.att.comet.bpm.common.repository.BpmOrderExpediteRepository;
import com.att.comet.bpm.common.repository.BpmOrderProcessRepository;
import com.att.comet.bpm.common.repository.BpmOrderWorkStepRepository;
import com.att.comet.bpm.common.repository.BpmUrlRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.oa.helper.OAApprovalHelper;

@Component
public class BpmDAOImpl implements BpmDAO {
	private static final Logger logger = LoggerFactory.getLogger(BpmDAOImpl.class);
	@Autowired
	private BpmOrderProcessRepository bpmOrderProcessRepository;
	@Autowired
	private BpmOrderWorkStepRepository bpmOrderWorkStepRepository;
	@Autowired
	private BpmOrderBusinessStepRepository bpmOrderBusinessStepRepository;
	@Autowired
	private BpmOrderBusStepHistoryRepository bpmOrderBusStepHistoryRepository;
	@Autowired
	private BpmUrlRepository bpmUrlRepository;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	BpmOrderExpediteRepository bpmOrderExpediteRepository;

	@Override
	public void saveBpmOrderProcess(CommonBO commonBO) {
		Long orderTypeId=0L;
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderTypeId =1005L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			orderTypeId =1004L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			orderTypeId =1002L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.NEW_ORDER)) {
			orderTypeId =1001L;
		} else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.EXPEDITE_ORDER)) {
			orderTypeId =1003L;
		}else {
			orderTypeId =1006L;
		}
		Date today = new Date();
		BpmOrderProcess bpmOrderProcess = new BpmOrderProcess();
		BpmOrderProcessId bpmOrderProcessId = new BpmOrderProcessId();
		bpmOrderProcessId.setProcessId(commonBO.getProcessId());
		bpmOrderProcessId.setOrderId(commonBO.getOrderId());
		bpmOrderProcessId.setOrderTypeId(commonBO.getOrderTypeId());
		BpmStatus bpmStatus = new BpmStatus();
		bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());
		OrderType orderType = new OrderType();
		orderType.setOrderTypeId(orderTypeId);
		Orders orders = new Orders();
		orders.setOrderId(commonBO.getOrderId());
		BpmProcess bpmProcess = new BpmProcess();
		bpmProcess.setProcessId(commonBO.getProcessId());
		bpmOrderProcess.setId(bpmOrderProcessId);
		bpmOrderProcess.setBpmStatus(bpmStatus);
		bpmOrderProcess.setOrderType(orderType);
		bpmOrderProcess.setOrders(orders);
		bpmOrderProcess.setComments(orders.getComments());
		bpmOrderProcess.setCreatedOn(today);
		bpmOrderProcess.setUpdatedOn(today);
		bpmOrderProcess.setProcessExecutedOn(today);
		bpmOrderProcessRepository.save(bpmOrderProcess);

	}

	@Override
	public void deleteBpmOrderProcess(CommonBO commonBO) throws CamundaServiceException{
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "] ", this);
		BpmOrderProcessId id = new BpmOrderProcessId();
		id.setOrderId(commonBO.getOrderId());
		id.setOrderTypeId(commonBO.getOrderTypeId());
		id.setProcessId(commonBO.getProcessId());
		Optional<BpmOrderProcess> bpmOrderProcess = bpmOrderProcessRepository.findById(id);
		if (bpmOrderProcess.isPresent()) {
			bpmOrderProcessRepository.deleteById(id);
		}
	}

	@Override
	public void updateBpmOrderProcess(CommonBO commonBO) {
		BpmOrderProcessId id = new BpmOrderProcessId();
		id.setOrderId(commonBO.getOrderId());
		id.setOrderTypeId(commonBO.getOrderTypeId());
		id.setProcessId(commonBO.getProcessId());
		Optional<BpmOrderProcess> optional = bpmOrderProcessRepository.findById(id);
		if (optional.isPresent()) {
			BpmOrderProcess bpmOrderProcess = optional.get();
			BpmStatus bpmStatus = null;
			if (null != commonBO.getBpmStatusId()) {
				bpmStatus = new BpmStatus();
				bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());
				bpmOrderProcess.setBpmStatus(bpmStatus);
			}
			bpmOrderProcess.setUpdatedOn(new Date());
			bpmOrderProcessRepository.save(bpmOrderProcess);
		}
	}

	@Override
	public void saveBpmOrderWorkStep(CommonBO commonBO) throws CamundaServiceException{
		Date date = new Date();
		BpmOrderWorkStep bpmOrderWorkStep = new BpmOrderWorkStep();

		BpmOrderWorkStepId bpmOrderWorkStepId = new BpmOrderWorkStepId();
		bpmOrderWorkStepId.setOrderId(commonBO.getOrderId());
		bpmOrderWorkStepId.setOrderTypeId(commonBO.getOrderTypeId());
		if (commonBO.getWorkStepIdList() != null && commonBO.getWorkStepIdList().size() > 0) {
			bpmOrderWorkStepId.setWorkStepId(commonBO.getWorkStepIdList().get(0));
		} else {
			bpmOrderWorkStepId.setWorkStepId(commonBO.getWorkStepId());
		}

		BpmStatus bpmStatus = new BpmStatus();
		bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());

		BpmWorkStep bpmWorkStep = new BpmWorkStep();
		if (commonBO.getWorkStepIdList() != null && commonBO.getWorkStepIdList().size() > 0) {
			bpmWorkStep.setWorkStepId(commonBO.getWorkStepIdList().get(0));
		} else {
			bpmWorkStep.setWorkStepId(commonBO.getWorkStepId());
		}

		OrderType orderType = new OrderType();
		orderType.setOrderTypeId(commonBO.getOrderTypeId());

		Orders orders = new Orders();
		orders.setOrderId(commonBO.getOrderId());
		bpmOrderWorkStep.setId(bpmOrderWorkStepId);
		bpmOrderWorkStep.setBpmStatus(bpmStatus);
		bpmOrderWorkStep.setBpmWorkStep(bpmWorkStep);
		bpmOrderWorkStep.setOrderType(orderType);
		bpmOrderWorkStep.setOrders(orders);
		bpmOrderWorkStep.setWorkStepExecutedOn(date);
		bpmOrderWorkStep.setCreatedOn(date);
		bpmOrderWorkStep.setUpdatedOn(date);
		bpmOrderWorkStepRepository.save(bpmOrderWorkStep);

	}

	@Override
	public void deleteBpmOrderWorkStep(CommonBO commonBO) {
		if (commonBO.getWorkStepIdList() != null && commonBO.getWorkStepIdList().size() > 0) {
			for (int i = 0; i < commonBO.getWorkStepIdList().size(); i++) {
				BpmOrderWorkStepId bpmOrderWorkStepId = new BpmOrderWorkStepId();
				bpmOrderWorkStepId.setOrderId(commonBO.getOrderId());
				bpmOrderWorkStepId.setWorkStepId(commonBO.getWorkStepIdList().get(i));
				bpmOrderWorkStepId.setOrderTypeId(commonBO.getOrderTypeId());
				Optional<BpmOrderWorkStep> bpmOrderWorkStep = bpmOrderWorkStepRepository.findById(bpmOrderWorkStepId);
				if (bpmOrderWorkStep.isPresent()) {
					bpmOrderWorkStepRepository.deleteById(bpmOrderWorkStepId);
				}
				bpmOrderWorkStepId = null;
			}
		}

	}

	@Override
	public void updateBpmOrderWorkStep(CommonBO commonBO) {
		if (commonBO.getWorkStepIdList() != null && commonBO.getWorkStepIdList().size() > 0) {
			for (Long workStepId : commonBO.getWorkStepIdList()) {
				BpmOrderWorkStepId bpmOrderWorkStepId = new BpmOrderWorkStepId();
				bpmOrderWorkStepId.setOrderId(commonBO.getOrderId());
				bpmOrderWorkStepId.setOrderTypeId(commonBO.getOrderTypeId());
				bpmOrderWorkStepId.setWorkStepId(workStepId);
				Optional<BpmOrderWorkStep> bpmOrderWorkStepOptional = bpmOrderWorkStepRepository
						.findById(bpmOrderWorkStepId);
				bpmOrderWorkStepId = null;
				if (bpmOrderWorkStepOptional.isPresent()) {
					BpmOrderWorkStep bpmOrderWorkStep = bpmOrderWorkStepOptional.get();
					BpmStatus bpmStatus = null;
					if (null != commonBO.getBpmStatusId()) {
						bpmStatus = new BpmStatus();
						bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());
						bpmOrderWorkStep.setBpmStatus(bpmStatus);
					}else {
						logger.error("BPM status Id Not avalaible ", this);	
					}
					bpmOrderWorkStep.setUpdatedOn(new Date());
					bpmOrderWorkStepRepository.save(bpmOrderWorkStep);
					bpmOrderWorkStep = null;
				}else {
					logger.error("Work Steps id:"+workStepId+" Not avalaible ", this);
					logger.error("For order id:"+commonBO.getOrderId()+" ", this);
					logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);
				}
			}
		}

	}

	@Override
	public void saveBpmOrderBusinessStep(CommonBO commonBO) throws CamundaServiceException{
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "] ", this);
		Long orderTypeId=0L;
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderTypeId =1005L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			orderTypeId =1004L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			orderTypeId =1002L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.NEW_ORDER)) {
			orderTypeId =1001L;
		} else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.EXPEDITE_ORDER)) {
			orderTypeId =1003L;
		}else {
			orderTypeId =1006L;
		}
		BpmOrderBusinessStep bpmOrderBusinessStep = new BpmOrderBusinessStep();
		
		BpmOrderBusinessStepId bpmOrderBusinessStepId = new BpmOrderBusinessStepId();
		bpmOrderBusinessStepId.setBusinessStepId(commonBO.getBusinessStepId());
		bpmOrderBusinessStepId.setOrderId(commonBO.getOrderId());
		bpmOrderBusinessStepId.setOrderTypeId(commonBO.getOrderTypeId());
		Optional<BpmOrderBusinessStep> bpmOrderBusinessStepIdOpt = bpmOrderBusinessStepRepository.findById(bpmOrderBusinessStepId);
		if(bpmOrderBusinessStepIdOpt.isPresent()) {
			logger.info("Bussniess Steps id"+commonBO.getBusinessStepId()+"  avaliable ", this);
			logger.info("For order id:"+commonBO.getOrderId()+" ", this);
			logger.info("And for Order type Id:"+commonBO.getOrderTypeId()+"  avaliable ", this);
			BpmBusinessStep bpmBusinessStep = new BpmBusinessStep();
			bpmBusinessStep.setBusinessStepId(commonBO.getBusinessStepId());

			OrderType orderType = new OrderType();
			orderType.setOrderTypeId(orderTypeId);

			Orders orders = new Orders();
			orders.setOrderId(commonBO.getOrderId());

			Date date = new Date();
			if(commonBO.getBusinessStepId().equals(3132L) 
					|| commonBO.getBusinessStepId().equals(3007L)
					|| commonBO.getBusinessStepId().equals(3142L)
					|| commonBO.getBusinessStepId().equals(3004L)
					|| commonBO.getBusinessStepId().equals(3029L)
					|| commonBO.getBusinessStepId().equals(3012L)
					|| commonBO.getBusinessStepId().equals(3143L)) {
				bpmOrderBusinessStep.setBusinessStepExecutedOn(commonBO.getUpdatedOn());
			}else {
				bpmOrderBusinessStep.setBusinessStepExecutedOn(date);
			}
			bpmOrderBusinessStep.setCreatedOn(date);
			bpmOrderBusinessStep.setUpdatedOn(date);
			bpmOrderBusinessStep.setAttuid(commonBO.getUpdatedBy());
			bpmOrderBusinessStep.setId(bpmOrderBusinessStepId);
			bpmOrderBusinessStep.setOrders(orders);
			bpmOrderBusinessStep.setOrderType(orderType);
			bpmOrderBusinessStep.setBpmBusinessStep(bpmBusinessStep);
			
			bpmOrderBusinessStep.setComments(commonBO.getComments());
			bpmOrderBusinessStep.setBusinessStepValue(commonBO.getBusinessStepValue());
			bpmOrderBusinessStep.setBusinessStepStatus(commonBO.getBusinessStepStatus());
			bpmOrderBusinessStepRepository.save(bpmOrderBusinessStep);
		}else {
			logger.info("Bussniess Steps id"+commonBO.getBusinessStepId()+"  avaliable ", this);
			logger.info("For order id:"+commonBO.getOrderId()+" ", this);
			logger.info("And for Order type Id:"+commonBO.getOrderTypeId()+"  avaliable ", this);
			BpmBusinessStep bpmBusinessStep = new BpmBusinessStep();
			bpmBusinessStep.setBusinessStepId(commonBO.getBusinessStepId());

			OrderType orderType = new OrderType();
			orderType.setOrderTypeId(orderTypeId);

			Orders orders = new Orders();
			orders.setOrderId(commonBO.getOrderId());

			Date date = new Date();
			if(commonBO.getBusinessStepId().equals(3132L) 
					|| commonBO.getBusinessStepId().equals(3007L)
					|| commonBO.getBusinessStepId().equals(3142L)
					|| commonBO.getBusinessStepId().equals(3004L)
					|| commonBO.getBusinessStepId().equals(3029L)
					|| commonBO.getBusinessStepId().equals(3012L)
					|| commonBO.getBusinessStepId().equals(3107L)
					|| commonBO.getBusinessStepId().equals(3038L)
					|| commonBO.getBusinessStepId().equals(3143L)) {
				bpmOrderBusinessStep.setBusinessStepExecutedOn(commonBO.getUpdatedOn());
			}else {
				bpmOrderBusinessStep.setBusinessStepExecutedOn(date);
			}
			bpmOrderBusinessStep.setCreatedOn(date);
			bpmOrderBusinessStep.setUpdatedOn(commonBO.getUpdatedOn());
			bpmOrderBusinessStep.setAttuid(commonBO.getUpdatedBy());
			bpmOrderBusinessStep.setId(bpmOrderBusinessStepId);
			bpmOrderBusinessStep.setOrders(orders);
			bpmOrderBusinessStep.setOrderType(orderType);
			bpmOrderBusinessStep.setBpmBusinessStep(bpmBusinessStep);
			//bpmOrderBusinessStep.setBusinessStepExecutedOn(date);
			bpmOrderBusinessStep.setComments(commonBO.getComments());
			bpmOrderBusinessStep.setBusinessStepValue(commonBO.getBusinessStepValue());
			bpmOrderBusinessStep.setBusinessStepStatus(commonBO.getBusinessStepStatus());
			bpmOrderBusinessStepRepository.save(bpmOrderBusinessStep);
			logger.error("Bussniess Steps id"+commonBO.getBusinessStepId()+" Not avalaible ", this);
			logger.error("For order id:"+commonBO.getOrderId()+" ", this);
			logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);
		}
		

	}

	@Override
	public void deleteBpmOrderBusinessStep(CommonBO commonBO) throws CamundaServiceException{
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "] ", this);
		Long crCount = orderDAO.countOrderEvent(commonBO);
		if (null != crCount && crCount >1L) {
			commonBO.setOrderTypeId(1005L);
		}
		if (commonBO.getBusinessStepIdList() != null && commonBO.getBusinessStepIdList().size() > 0) {
			for (Long businessStepId : commonBO.getBusinessStepIdList()) {
				BpmOrderBusinessStepId bpmOrderBusinessStepId = new BpmOrderBusinessStepId();
				bpmOrderBusinessStepId.setBusinessStepId(businessStepId);
				bpmOrderBusinessStepId.setOrderId(commonBO.getOrderId());
				bpmOrderBusinessStepId.setOrderTypeId(commonBO.getOrderTypeId());
				Optional<BpmOrderBusinessStep> bpmOrderBusinessStep = bpmOrderBusinessStepRepository
						.findById(bpmOrderBusinessStepId);
				if (bpmOrderBusinessStep.isPresent()) {
					bpmOrderBusinessStepRepository.deleteById(bpmOrderBusinessStepId);
				}else {
					logger.error("Bussniess Steps id:"+commonBO.getBusinessStepId()+" Not avalaible ", this);
					logger.error("For order id:"+commonBO.getOrderId()+" ", this);
					logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);
				}
			}
		}

	}

	@Override
	public List<String> getBpmOrderBusinessStepComments(CommonBO commonBO) {
		BpmOrderBusinessStepId bpmOrderBusinessStepId = new BpmOrderBusinessStepId();
		if (commonBO.getBusinessStepId() != null) {
			bpmOrderBusinessStepId.setBusinessStepId(commonBO.getBusinessStepId());
		}
		if (commonBO.getOrderId() != null) {
			bpmOrderBusinessStepId.setOrderId(commonBO.getOrderId());
		}
		if (commonBO.getOrderTypeId() != null) {
			bpmOrderBusinessStepId.setOrderTypeId(commonBO.getOrderTypeId());
		}
		return bpmOrderBusinessStepRepository.findBpmOrderBusinessStepComments(bpmOrderBusinessStepId);
	}

	@Override
	public void saveBpmOrderBusStepHistory(CommonBO commonBO) {
		BpmOrderBusStepHistory bpmOrderBusStepHistory = new BpmOrderBusStepHistory();
		Date date = new Date();

		BpmOrderBusStepHistoryId bpmOrderBusStepHistoryId = new BpmOrderBusStepHistoryId();
		bpmOrderBusStepHistoryId.setOrderId(commonBO.getOrderId());
		bpmOrderBusStepHistoryId.setBusinessStepId(commonBO.getBusinessStepId());
		bpmOrderBusStepHistoryId.setBusinessStepStatus(commonBO.getBusinessStepStatus());
		bpmOrderBusStepHistoryId.setComments(commonBO.getComments());
		bpmOrderBusStepHistoryId.setCreatedOn(date);
		bpmOrderBusStepHistoryId.setUpdatedOn(date);
		bpmOrderBusStepHistoryId.setOrderTypeId(commonBO.getOrderTypeId());
		bpmOrderBusStepHistoryId.setBusinessStepExecutedOn(date);
		bpmOrderBusStepHistory.setId(bpmOrderBusStepHistoryId);
		bpmOrderBusStepHistoryRepository.save(bpmOrderBusStepHistory);

	}

	@Override
	public List<Object[]> findWorkStepIdAndUserDecision(CommonBO commonBO) {
		Long orderTypeId=0L;
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderTypeId =1005L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			orderTypeId =1004L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			orderTypeId =1002L;
		}else {
			orderTypeId =1006L;
		}
		return bpmOrderWorkStepRepository.findWorkStepIdAndUserDecision(commonBO.getWorkStepIdList(),
				commonBO.getOrderId(), orderTypeId);
		
	}

	@Override
	public BpmOrderBusinessStep findBpmOrderBusinessStepById(CommonBO commonBO) {
		BpmOrderBusinessStep bpmOrderBusinessStep = null;
		BpmOrderBusinessStepId id = new BpmOrderBusinessStepId();
		id.setBusinessStepId(commonBO.getBusinessStepId());
		id.setOrderId(commonBO.getOrderId());
		id.setOrderTypeId(commonBO.getOrderTypeId());
		Optional<BpmOrderBusinessStep> optional = bpmOrderBusinessStepRepository.findById(id);
		if (optional.isPresent()) {
			bpmOrderBusinessStep = optional.get();
		}else {
			logger.error("Bussniess Steps id:"+commonBO.getBusinessStepId()+" Not avalaible ", this);
			logger.error("For order id:"+commonBO.getOrderId()+" ", this);
			logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);
		}
		return bpmOrderBusinessStep;
	}

	/*@Override
	public void updateBpmOrderExpedite(CommonBO commonBO) {
		String sql = "update bpm_order_expedite set apn_iwos_creation_status =? where order_id=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getApnIwosCreationStatus());
		query.setParameter(2, commonBO.getOrderId());

		query.executeUpdate();

	}*/

	@Override
	public void updateBpmOrderBusinessStep(CommonBO commonBO) {
		BpmOrderBusinessStep bpmOrderBusinessStep = null;

		BpmOrderBusinessStepId bpmOrderBusinessStepId = new BpmOrderBusinessStepId();
		bpmOrderBusinessStepId.setBusinessStepId(commonBO.getBusinessStepId());
		bpmOrderBusinessStepId.setOrderId(commonBO.getOrderId());
		bpmOrderBusinessStepId.setOrderTypeId(commonBO.getOrderTypeId());
		Optional<BpmOrderBusinessStep> optional = bpmOrderBusinessStepRepository.findById(bpmOrderBusinessStepId);
		if (optional.isPresent()) {
			bpmOrderBusinessStep = optional.get();
			bpmOrderBusinessStep.setBusinessStepExecutedOn(new Date());
			bpmOrderBusinessStepRepository.save(bpmOrderBusinessStep);
		}else {
			logger.error("Bussniess Steps id:"+commonBO.getBusinessStepId()+" Not avalaible ", this);
			logger.error("For order id:"+commonBO.getOrderId()+" ", this);
			logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);	
		}

	}

	@Override
	public BpmOrderWorkStep getBpmOrderWorkStep(CommonBO commonBO) {
		BpmOrderWorkStepId bpmOrderWorkStepId = new BpmOrderWorkStepId();
		bpmOrderWorkStepId.setOrderId(commonBO.getOrderId());
		bpmOrderWorkStepId.setOrderTypeId(commonBO.getOrderTypeId());
		bpmOrderWorkStepId.setWorkStepId(commonBO.getWorkStepId());
		Optional<BpmOrderWorkStep> optional = bpmOrderWorkStepRepository.findById(bpmOrderWorkStepId);
		BpmOrderWorkStep bpmOrderWorkStep = null;
		if (optional.isPresent()) {
			bpmOrderWorkStep = optional.get();
		}else {
			logger.error("Work Steps id:"+commonBO.getWorkStepId()+" Not avalaible ", this);
			logger.error("For order id:"+commonBO.getOrderId()+" ", this);
			logger.error("And for Order type Id:"+commonBO.getOrderTypeId()+" Not avalaible ", this);
		}
		return bpmOrderWorkStep;
	}

	@Override
	public void updateBpmOrderWorkStepDisplayFlag(CommonBO commonBO) {

		String sql = "UPDATE BPM_ORDER_WORK_STEP SET DISPLAY_FLAG =? WHERE WORK_STEP_ID=? AND ORDER_ID= ? AND ORDER_TYPE_ID=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getDisplayFlag());
		query.setParameter(2, 1018);
		query.setParameter(3, commonBO.getOrderId());
		query.setParameter(4, commonBO.getOrderTypeId());
		query.executeUpdate();
	}
	@Override
	public void updateDapnInventory(CommonBO commonBO) {
		String sql = "update dapn_inventory set dapn_status_id = 1001 where order_id = ?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public BpmUrl finBpmUrlById(String urlName) {
		BpmUrl bpmUrl = null;
		Optional<BpmUrl> bpmUrlOptional = bpmUrlRepository.findById(urlName);
		if (bpmUrlOptional.isPresent()) {
			bpmUrl = bpmUrlOptional.get();
		}
		return bpmUrl;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findExpediteProcessStatus(Long orderId) {
		String sql = "select expedite_process_status from bpm_order_expedite where order_id=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getBpmOrderProcess(Long orderId) {

		String sql = "select process_id,bpm_status_id from bpm_order_process where order_id=? \r\n"
				+ "and created_on in (select max(created_on) from bpm_order_process where order_id=? group by process_id)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		query.setParameter(2, orderId);
		return query.getResultList();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getProcessUserDecision(CommonBO commonBO) {
		Long orderTypeId=0L;
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderTypeId =1005L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			orderTypeId =1004L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			orderTypeId =1002L;
		}else {
			orderTypeId =1006L;
		}
		String sql = "select process_id , user_decision from bpm_order_process where order_id=? and order_type_id=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, orderTypeId);
		return query.getResultList();
	}
	@Override
	public String findBpmStatusName(CommonBO commonBO) {
		String bpmStatusName = null;
		String sql = "select bpm_status_name from bpm_order_work_step bows, bpm_status bs where bows.bpm_status_id = bs.bpm_status_id "
				+ "and bows.order_id =? "
				+ "and bows.order_Type_id =? and bows.work_step_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderTypeId());
		query.setParameter(3, commonBO.getWorkStepId());
		bpmStatusName = (String) query.getSingleResult();
		return bpmStatusName;
	}
	@Override
	public void deleteBpmOrderProcessByOrderIdAndProcessId(CommonBO commonBO) throws CamundaServiceException {
		BpmOrderProcessId id = new BpmOrderProcessId();
		BpmOrderProcess bpmOrderProcess = new BpmOrderProcess();
		id.setProcessId(commonBO.getProcessId());
		id.setOrderId(commonBO.getOrderId());
		id.setOrderTypeId(commonBO.getOrderTypeId());
		bpmOrderProcess.setId(id);
		Optional<BpmOrderProcess> bpmOrderProcessOpt = bpmOrderProcessRepository.findById(bpmOrderProcess.getId());
		if (bpmOrderProcessOpt.isPresent()) {
			bpmOrderProcessRepository.deleteById(id);
		}
	}

	@Override
	public void saveBpmOrderProcessForOrderIdAndOrderTypeId(CommonBO commonBO) throws CamundaServiceException{
		Date today = new Date();
		BpmOrderProcess bpmOrderProcess = new BpmOrderProcess();
		BpmOrderProcessId bpmOrderProcessId = new BpmOrderProcessId();
		BpmStatus bpmStatus = new BpmStatus();
		bpmOrderProcessId.setProcessId(commonBO.getProcessId());
		bpmOrderProcessId.setOrderId(commonBO.getOrderId());
		bpmOrderProcessId.setOrderTypeId(commonBO.getOrderTypeId());
		bpmOrderProcess.setId(bpmOrderProcessId);
		bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());
		bpmOrderProcess.setBpmStatus(bpmStatus);
		bpmOrderProcess.setProcessExecutedOn(today);
		bpmOrderProcess.setCreatedOn(today);
		bpmOrderProcess.setUpdatedOn(today);
		bpmOrderProcessRepository.save(bpmOrderProcess);
	}

	@Override
	public void updateBpmOrderProcessForOrderIdAndOrderTypeId(CommonBO commonBO) {
		BpmOrderProcess bpmOrderProcess = new BpmOrderProcess();
		BpmOrderProcessId bpmOrderProcessId = new BpmOrderProcessId();
		BpmStatus bpmStatus = new BpmStatus();
		bpmOrderProcessId.setProcessId(commonBO.getProcessId());
		bpmOrderProcessId.setOrderId(commonBO.getOrderId());
		bpmOrderProcessId.setOrderTypeId(commonBO.getOrderTypeId());
		
		Optional<BpmOrderProcess> bpmOrderProcessOp = bpmOrderProcessRepository.findById(bpmOrderProcessId);
		if(bpmOrderProcessOp.isPresent()) {
			Date today = new Date();
			bpmOrderProcess.setId(bpmOrderProcessId);
			bpmStatus.setBpmStatusId(commonBO.getBpmStatusId());
			bpmOrderProcess.setBpmStatus(bpmStatus);
			bpmOrderProcess.setCreatedOn(new Date());
			bpmOrderProcess.setUpdatedOn(today);
			bpmOrderProcessRepository.save(bpmOrderProcess);	
		}else {
			logger.error("bpmOrderProcessRepository is empty::bpmOrderProcessId"+bpmOrderProcessId, this);
			logger.error("for OrderTypeId::"+commonBO.getOrderTypeId(), this);
			logger.error("and orderId::"+commonBO.getOrderId(), this);
		}
	}

	@Override
	public void deleteBpmOrderProcessbyOrderProcessName(CommonBO commonBO)throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "] ", this);
		String sql = "delete from  bpm_order_process  where ORDER_ID=? and  ORDER_TYPE_ID=(select order_type_id from order_type where order_type_name=?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderTypeName());
		query.executeUpdate();

	}

	@Override
	public String findBusinessStepValue(CommonBO commonBO) {
		String businessStepValue = null;
		String sql = "select business_step_value from bpm_order_business_step where business_step_id = ? and order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getBusinessStepId());
		query.setParameter(2, commonBO.getOrderId());
		businessStepValue = (String) query.getSingleResult();
		return businessStepValue;
	}

	@Override
	public String findUserDecision(CommonBO commonBO) {
		String userDecision=null;
		Long orderTypeId=0L;
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderTypeId =1005L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			orderTypeId =1004L;
		}else if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			orderTypeId =1002L;
		}else {
			orderTypeId =1006L;
		}
		List<BpmOrderWorkStep> bpmOrderWorkStepList=bpmOrderWorkStepRepository.findByOrders_orderIdAndOrderType_orderTypeIdAndBpmWorkStep_workStepId(commonBO.getOrderId(), orderTypeId, commonBO.getWorkStepId());
		if(!CollectionUtils.isEmpty(bpmOrderWorkStepList))
		{
			BpmOrderWorkStep bpmOrderWorkStep=bpmOrderWorkStepList.get(0);
			userDecision=bpmOrderWorkStep.getUserDecision();
		}else {
			logger.error("BpmOrderWorkStepList is empty::commonBO.getOrderId()"+commonBO.getOrderId(), this);
			logger.error("for OrderTypeId::"+commonBO.getOrderTypeId(), this);
			logger.error("and WorkStepId::"+commonBO.getWorkStepId(), this);
		}
		return userDecision;
	}
	@Override
	public String getExpediteStatus(CommonBO commonBO) {
		String expediteStatus=null;
		Optional<BpmOrderExpedite> optional = bpmOrderExpediteRepository.findById(commonBO.getOrderId());
		if (optional.isPresent()) {
			expediteStatus=optional.get().getExpediteProcessStatus();
		}else {
			logger.error("BpmOrderExpediteRepository not found for OrderId::"+commonBO.getOrderId(), this);
		}
		return expediteStatus;
	}
	@Override
	public void updateBpmOrderExpedite(CommonBO commonBO) {
		logger.info("@Starting method updateBpmOrderExpedite ", this);
		Optional<BpmOrderExpedite>  bpmOrderExpediteOp= bpmOrderExpediteRepository.findById(commonBO.getOrderStatusId());
		if(bpmOrderExpediteOp.isPresent()) {
			BpmOrderExpedite bpmOrderExpedite = bpmOrderExpediteOp.get();
			bpmOrderExpedite.setApnIwosCreationStatus(commonBO.getApnCreationStatus());
			bpmOrderExpedite.setExpediteProcessStatus(commonBO.getExpediteProcessStatus());
			bpmOrderExpediteRepository.saveAndFlush(bpmOrderExpedite);
		}else {
			logger.error("BpmOrderExpediteRepository not found for OrderStatusId::"+commonBO.getOrderStatusId(), this);
			BpmOrderExpedite bpmOrderExpedite = new BpmOrderExpedite();
			bpmOrderExpedite.setOrderId(commonBO.getOrderId());
			bpmOrderExpedite.setApnIwosCreationStatus(commonBO.getApnCreationStatus());
			bpmOrderExpedite.setExpediteProcessStatus(commonBO.getExpediteProcessStatus());
			bpmOrderExpediteRepository.saveAndFlush(bpmOrderExpedite);
		}
		logger.info("@Existing method updateBpmOrderExpedite ", this);
		
	}
	
	@Override
	public String getBpmOrderBusinessStepStatus(CommonBO commonBO) {
		BpmOrderBusinessStepId bpmOrderBusinessStepId = new BpmOrderBusinessStepId();
		if (commonBO.getBusinessStepId() != null) {
			bpmOrderBusinessStepId.setBusinessStepId(commonBO.getBusinessStepId());
		}
		if (commonBO.getOrderId() != null) {
			bpmOrderBusinessStepId.setOrderId(commonBO.getOrderId());
		}
		if (commonBO.getOrderTypeId() != null) {
			bpmOrderBusinessStepId.setOrderTypeId(commonBO.getOrderTypeId());
		}
		return bpmOrderBusinessStepRepository.findBpmOrderBusinessStepStatus(bpmOrderBusinessStepId);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getExpBuildDateAndReason(Long orderId) {

		String sql = "select REQ_BUILD_COMPLETION_DATE, REASON_TO_EXPEDITE from ORDER_EXPEDITE_INFO where order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		return query.getResultList();
	}
	

}
