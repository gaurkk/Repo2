package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.TaskStatus;

public interface TaskStatusRepository extends JpaRepository<TaskStatus, Long>{

}
