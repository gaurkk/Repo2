package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.BpmOrderProcess;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderProcessId;


@Repository
public interface BpmOrderProcessRepository extends JpaRepository<BpmOrderProcess, BpmOrderProcessId> {
	
}
