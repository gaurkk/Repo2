package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStepId;


@Repository
public interface BpmOrderWorkStepRepository extends JpaRepository<BpmOrderWorkStep, BpmOrderWorkStepId> {

	@Query(value = "select bow.id.workStepId,userDecision from BpmOrderWorkStep bow where bow.id.workStepId in (:workStepIdList) and bow.orders.orderId=:orderId and bow.orderType.orderTypeId=:orderTypeId")
    List<Object[]> findWorkStepIdAndUserDecision(List<Long> workStepIdList, Long orderId, Long orderTypeId);
    
    List<BpmOrderWorkStep> findByOrders_orderIdAndOrderType_orderTypeIdAndBpmWorkStep_workStepId(Long orderId,Long orderTypeId,Long workStepId);
}
