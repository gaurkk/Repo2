package com.att.comet.bpm.osorderupdate.delegate;

import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.osorderupdate.service.OSOrderUpdateService;

@Component
public class OSOrderUpdateDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OSOrderUpdateDelegate.class);

	@Autowired
	private OSOrderUpdateService osOrderUpdateService;

	@Autowired
	private CommonService commonService;

	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.ORDER_REJECTED_BY_INFO:
					getOrderRejectedInfo(execution);
					break;
				case BpmConstant.PRE_OPERATION_OA_REJECT:
					preOperationOAReject(execution);
					break;
				case BpmConstant.POST_OPERATION_OA_REJECT:
					postOperationOAReject(execution);
					break;
				case BpmConstant.PRE_OPERATION_OM_REJECT:
					preOperationOMReject(execution);
					break;
				case BpmConstant.POST_OPERATION_OM_REJECT:
					postOperationOMReject(execution);
					break;
				}
			}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OS_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void postOperationOMReject(DelegateExecution execution) throws Exception {
		logger.info("Start postOperationOMReject method ::", this);
		Long orderId = null;
		CommonBO commonBO = null;
		String comments = null;
		try {
			Map<String, Object> variables = execution.getVariables();
			orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
			if (null != orderId) {
				commonBO = variables.get(BpmConstant.COMMON_BO) != null ? (CommonBO) variables.get(BpmConstant.COMMON_BO) : null;
				if (null != commonBO) {
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OS_ORDER_UPDATE_ERR_OA_REJECT_POST_001);// NI Error code for
																											// post operation
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1001L);// Network Implementation Role Id
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1012L);// Mapped from BPM_task table (NI : Order Update Completion)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
					comments = variables.get(BpmConstant.COMMENTS) != null ? (String) variables.get(BpmConstant.COMMENTS)
							: null;
					commonBO.setComments(comments);
					osOrderUpdateService.postOperationOMReject(commonBO, execution);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
					throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
				}

			} else {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
						this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OS_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}

		logger.info("End postOperationOMReject method ::", this);

	}

	private void preOperationOMReject(DelegateExecution execution) throws Exception {
		logger.info("Start preOperationOMReject method ::", this);
		Long orderId = null;
		CommonBO commonBO = null;
		String orderOperation = null;
		try {
			Map<String, Object> variables = execution.getVariables();
			orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
			orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
					? (String) variables.get(BpmConstant.ORDER_OPERATION)
					: null;
			if (orderId != null && orderOperation != null) {
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OS_ORDER_UPDATE_ERR_OM_REJECT_PRE_001);// NI Error code for
																										// post operation
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1001L);// Network Implementation Role Id
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1012L);// Mapped from BPM_task table (NI : Order Update Completion)
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				commonBO = commonService.getCommonBO(orderId);
				BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
				if (null != commonBO) {
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
					execution.setVariable(BpmConstant.PROCESS_TYPE, commonBO.getOrderTypeName());
					commonBO.setActivityInstanceId(execution.getActivityInstanceId());
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					execution.setVariable("orderStatus", commonBO.getOrderStatusName());
					commonBO.setActivityInstanceId(execution.getActivityInstanceId());
					commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
					commonBO.setRoleId(1001L);// Order Manager Role Id
					commonBO.setCategoryId(1002L);// category ID (user task)
					commonBO.setTaskStatusId(1001L);// User Task Status CREATED Id
					commonBO.setTaskId(1013L);// Mapped from BPM_task table (OS : Order Update Task (Rejected by OM))
					commonBO.setTaskStatusName("OM_OS_Order_Update_Task");// Mapped from TASK_DATA table
					osOrderUpdateService.preOperationOMReject(commonBO, execution);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
					execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
				} else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + commonBO.getOrderId() + "]",
							this);
					throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
				}

			} else {
				logger.error("Comet request does not have::",
						this);
			}
		}  catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OS_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}

		logger.info("End preOperationOMReject method ::", this);
	}

	private void postOperationOAReject(DelegateExecution execution) throws Exception {
		logger.info("Start postOperationOAReject method ::", this);
		Long orderId = null;
		CommonBO commonBO = null;
		String comments = null;
		try {
			Map<String, Object> variables = execution.getVariables();
			orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
			if (null != orderId) {
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OS_ORDER_UPDATE_ERR_OA_REJECT_POST_001);// NI Error code for
																										// post operation
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1001L);// Network Implementation Role Id
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1012L);// Mapped from BPM_task table (NI : Order Update Completion)
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				commonBO = variables.get(BpmConstant.COMMON_BO) != null ? (CommonBO) variables.get(BpmConstant.COMMON_BO) : null;
				if (null != commonBO) {
					comments = variables.get(BpmConstant.COMMENTS) != null ? (String) variables.get(BpmConstant.COMMENTS)
							: null;
					commonBO.setComments(comments);
					osOrderUpdateService.postOperationOAReject(commonBO, execution);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				}

			} else {
				logger.error("Comet request does not have::",
						this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OS_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}

		logger.info("End postOperationOAReject method ::", this);
	}

	private void preOperationOAReject(DelegateExecution execution) throws CamundaServiceException, RecordNotFoundException {
		logger.info("Start preOperationOAReject method ::", this);
		Long orderId = null;
		CommonBO commonBO = null;
		String orderOperation = null;
		try {
			Map<String, Object> variables = execution.getVariables();
			orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
			orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
					? (String) variables.get(BpmConstant.ORDER_OPERATION)
					: null;
			if (orderId != null && orderOperation != null) {
				commonBO = commonService.getCommonBO(orderId);
				BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
				if (null != commonBO) {
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OS_ORDER_UPDATE_ERR_OA_REJECT_PRE_001);// NI Error code for
					commonBO.setUpdatedOn(new Date());																		// post operation
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1001L);// Network Implementation Role Id
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1012L);// Mapped from BPM_task table (NI : Order Update Completion)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
					
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
					execution.setVariable(BpmConstant.PROCESS_TYPE, commonBO.getOrderTypeName());
					commonBO.setActivityInstanceId(execution.getActivityInstanceId());
					commonBO.setOrderOperation(orderOperation);//Order Type coming from Frontend //2:OPERATION TYPE ("NEW_ORDER"  | "CHANGE_ORDER" | "CHANGE_REQUEST" | "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER" | "ONHOLD_ORDER" | "DAPN_ORDER" )
					execution.setVariable(BpmConstant.ORDER_STATUS, commonBO.getOrderStatusName());
					commonBO.setActivityInstanceId(execution.getActivityInstanceId());
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
					commonBO.setRoleId(1001L);// Order Approver Role Id
					commonBO.setCategoryId(1002L);// category ID (user task)
					commonBO.setTaskStatusId(1001L);// User Task Status CREATED Id
					commonBO.setTaskId(1012L);// Mapped from BPM_task table (OS : Order Update Task (Rejected by OA))
					commonBO.setTaskStatusName("OS_Order_Update_Task");// Mapped from TASK_DATA table
					/*
					 * commonBO.setToEmail("rk776w@att.com"); commonBO.setCcEmail("rk776w@att.com");
					 */
					commonBO.setUpdatedOn(new Date());
					osOrderUpdateService.preOperationOAReject(commonBO, execution);
					execution.setVariable("commonBO", commonBO);
					execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
					execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
				} else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				}

			} else {
				logger.error("Comet request does not have::",
						this);
			}

		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OS_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End preOperationOAReject method ::", this);
	}

	private void getOrderRejectedInfo(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start getOrderRejectedInfo method ::", this);
		Long rejectedBy = null;
		Map<String, Object> variables = execution.getVariables();
		
		rejectedBy = variables.get(BpmConstant.REJECTED_BY) != null ? (Long) variables.get(BpmConstant.REJECTED_BY) : null;
		if (!StringUtils.isEmpty(rejectedBy)) {
			if (rejectedBy == 1002L || rejectedBy == 1003L) {
				execution.setVariable(BpmConstant.REJECTED_BY, rejectedBy);
			}
		}
		logger.info("End getOrderRejectedInfo method ::", this);
	}

}
