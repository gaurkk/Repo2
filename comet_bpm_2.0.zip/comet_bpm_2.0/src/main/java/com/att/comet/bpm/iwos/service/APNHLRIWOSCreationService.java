package com.att.comet.bpm.iwos.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface APNHLRIWOSCreationService {

	void preOperationIWOSCreation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationIWOSCreation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

}
