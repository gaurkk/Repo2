package com.att.comet.bpm.codashboard.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface CODashboardService {
	void preOperation(CommonBO commonBO,String processInstanceId) throws CamundaServiceException;
	void postOperation(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;
}
