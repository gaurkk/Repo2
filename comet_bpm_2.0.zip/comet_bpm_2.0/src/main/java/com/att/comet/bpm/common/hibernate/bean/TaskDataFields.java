package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for TaskDataFields. Mapped to TASK_DATA_FIELDS table in the
 * database.
 */
@Entity
@Table(name = "TASK_DATA_FIELDS")
public class TaskDataFields {

	private Long taskFieldId;
	private String fieldId;
	private Long taskDataId;
	private Long fieldOrder;
	private String fieldLabel;
	private String inputElement;
	private String mandatoryField;
	private String fieldLabelId;
	private String formBeanField;
	private String dropdown;
	private String dropdownValues;
	private String roleId;

	/**
	 * No-argument constructor for the class.
	 */
	public TaskDataFields() {

	}

	@Id
	@Column(name = "TASK_FIELD_ID", unique = true, nullable = false, precision = 22, scale = 0)
	public Long getTaskFieldId() {
		return taskFieldId;
	}

	public void setTaskFieldId(Long taskFieldId) {
		this.taskFieldId = taskFieldId;
	}

	@Column(name = "FIELD_ID", nullable = false, length = 100)
	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

//	@ManyToOne(fetch = FetchType.EAGER)
	@Column(name = "TASK_DATA_ID", nullable = false, insertable = false, updatable = false)
	public Long getTaskDataId() {
		return taskDataId;
	}

	public void setTaskDataId(Long taskDataId) {
		this.taskDataId = taskDataId;
	}

	@Column(name = "FIELD_ORDER", nullable = false)
	public Long getFieldOrder() {
		return fieldOrder;
	}

	public void setFieldOrder(Long fieldOrder) {
		this.fieldOrder = fieldOrder;
	}

	@Column(name = "FIELD_LABEL", nullable = false, length = 100)
	public String getFieldLabel() {
		return fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

	@Column(name = "INPUT_ELEMENT", nullable = true, length = 100)
	public String getInputElement() {
		return inputElement;
	}

	public void setInputElement(String inputElement) {
		this.inputElement = inputElement;
	}

	@Column(name = "MANDATORY_FIELD", nullable = false, length = 1)
	public String getMandatoryField() {
		return mandatoryField;
	}

	public void setMandatoryField(String mandatoryField) {
		this.mandatoryField = mandatoryField;
	}

	@Column(name = "FIELD_LABEL_ID", nullable = false, length = 30)
	public String getFieldLabelId() {
		return fieldLabelId;
	}

	public void setFieldLabelId(String fieldLabelId) {
		this.fieldLabelId = fieldLabelId;
	}

	@Column(name = "FORM_BEAN_FIELD", nullable = true, length = 30)
	public String getFormBeanField() {
		return formBeanField;
	}

	public void setFormBeanField(String formBeanField) {
		this.formBeanField = formBeanField;
	}

	@Column(name = "DROPDOWN", nullable = false, length = 1)
	public String getDropdown() {
		return dropdown;
	}

	public void setDropdown(String dropdown) {
		this.dropdown = dropdown;
	}

	@Column(name = "DROPDOWN_VALUES", nullable = true, length = 300)
	public String getDropdownValues() {
		return dropdownValues;
	}

	public void setDropdownValues(String dropdownValues) {
		this.dropdownValues = dropdownValues;
	}

	@Column(name = "ROLE_ID", nullable = true, length = 255)
	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

}
