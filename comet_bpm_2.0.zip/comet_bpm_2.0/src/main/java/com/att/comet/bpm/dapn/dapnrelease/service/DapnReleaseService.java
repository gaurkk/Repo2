package com.att.comet.bpm.dapn.dapnrelease.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface DapnReleaseService {

	public void preOperationDapnRelease(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;
	
	public void postOperationDapnRelease(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;
}
