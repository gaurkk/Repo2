package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.OrderContact;
import com.att.comet.bpm.common.hibernate.bean.Orders;

public interface OrderContactRepository extends JpaRepository<OrderContact, Long> {
	OrderContact findByOrders(Orders orders);
	
	OrderContact findByOrders_orderId(Long orderId);
}

