package com.att.comet.bpm.apniwos.service;

import java.net.URISyntaxException;
import java.text.ParseException;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

@Service
public interface ApnIwosService {

	public void preOperation(CommonBO commonBO,String processInstanceId)throws CamundaServiceException ;
	void updateBpmOrderExpedite(CommonBO commonBO);
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException, URISyntaxException, ParseException;	
	
}
