package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.BpmUrl;


@Repository
public interface BpmUrlRepository extends JpaRepository<BpmUrl, String> {

}
