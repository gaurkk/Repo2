package com.att.comet.bpm.core.processes.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;
import com.att.comet.bpm.core.processes.service.CoreProcessService;

@Component
public class OnHoldBpmDelegate implements JavaDelegate {

	private static final Logger logger = LoggerFactory.getLogger(OnHoldBpmDelegate.class);

	@Autowired
	CommonService commonService;

	@Autowired
	BpmDAO bpmDAO;

	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;

	@Autowired
	CoreProcessService coreProcessService;

	public static final String URL_NAME = "SEARCH_ORDER_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String operationType = (String) execution.getVariable("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.ONHOLD_PRE_OPERATION:
				onHoldPreOperation(execution);
				break;
			case BpmConstant.ONHOLD_CANCEL_OPERATION:
				onHoldCancelOperation(execution);
				break;
			case BpmConstant.ONHOLD_RESUME_OPERATION:
				onHoldResumeOperation(execution);
				break;
			case BpmConstant.ONHOLD_OTHER_OPERATION:
				onHoldOtherOperation(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void onHoldOtherOperation(DelegateExecution execution) {
		logger.info("Start onHoldOtherOperation method ::", this);
		execution.setVariable(BpmConstant.OH_INTERRUPTED, "Faulted");
		logger.info("Start onHoldOtherOperation method ::", this);

	}

	private void onHoldResumeOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start onHoldResumeOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				commonBO.setOnHoldFlag((Long) execution.getVariable("onHoldFlag"));
				commonBO.setTaskId(1046L);// Mapped from BPM_task table (OS : On-hold Request)
				commonBO.setTaskDescription("On-hold Request has been resolved for Order ID -" + commonBO.getOrderId() + " with APN -"
						+ commonBO.getApnName() + "  " + "for Account - " + commonBO.getAccountName());
				// ALL CRUD PREOPERATION for ON HOLD RESUME PROCESS
				commonService.onHoldResumeOperation(commonBO);
				commonBO.setApproved(BpmConstant.REJECTED);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD RESUME SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD RESUME SERVICE EXCEPTION");
		}
		logger.info("End onHoldResumeOperation method ::", this);
	}

	private void onHoldCancelOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start onHoldCancelOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				commonBO.setOnHoldFlag((Long) execution.getVariable("onHoldFlag"));
				commonBO.setTaskId(1046L);// Mapped from BPM_task table (OS : On-hold Request)
				commonBO.setTaskDescription("On-hold Request has been cancelled for Order ID -" + commonBO.getOrderId() + " with APN -"
						+ commonBO.getApnName() + "  " + "for Account - " + commonBO.getAccountName());
				// ALL CRUD PREOPERATION for ON HOLD CANCEL PROCESS
				commonService.onHoldCancelOperation(commonBO, execution);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD CANCEL SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD CANCEL SERVICE EXCEPTION");
		}
		logger.info("End onHoldCancelOperation method ::", this);
	}

	private void onHoldPreOperation(DelegateExecution execution) throws CamundaServiceException {

		logger.info("Start onHoldPreOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);

			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL,
						bpmUrl.getNew_url() != null ? bpmUrl.getNew_url() + commonBO.getOrderId() : "NOT FOUND");
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				// ALL CRUD PREOPERATION for ON HOLD PROCESS
				commonService.onHoldPreOperation(commonBO, execution.getProcessInstanceId());
				execution.setVariable("onHoldProcessInstanceId", execution.getProcessInstanceId());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD PREOPERATION SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD PREOPERATION SERVICE EXCEPTION");

		}
		logger.info("End onHoldPreOperation method ::", this);

	}

}
