package com.att.comet.bpm.common.dao;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OrderContactInfoDAO {

	void updateOrderContactInfoForAttUidByOrderContactDetails(CommonBO commonBO) throws CamundaServiceException;

	void updateOrderContactInfo(CommonBO commonBO) throws CamundaServiceException;

}
