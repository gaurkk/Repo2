package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for BpmStatus. Mapped to BpmStatus table of the database.
 */
@Entity
@Table(name = "BPM_STATUS")
public class BpmStatus implements java.io.Serializable {

	private static final long serialVersionUID = 4535300125939459764L;

	private Long bpmStatusId;
	private String bpmStatusName;
	private Set<BpmOrderProcess> bpmOrderProcesses = new HashSet<BpmOrderProcess>(0);
	private Set<BpmOrderWorkStep> bpmOrderWorkSteps = new HashSet<BpmOrderWorkStep>(0);

	/**
	 * No-argument constructor.
	 */
	public BpmStatus() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param bpmStatusId
	 * @param bpmStatusName
	 */
	public BpmStatus(Long bpmStatusId, String bpmStatusName) {
		this.bpmStatusId = bpmStatusId;
		this.bpmStatusName = bpmStatusName;
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param bpmStatusId
	 * @param bpmStatusName
	 * @param bpmOrderProcesses
	 * @param bpmOrderWorkSteps
	 */
	public BpmStatus(Long bpmStatusId, String bpmStatusName, Set<BpmOrderProcess> bpmOrderProcesses,
			Set<BpmOrderWorkStep> bpmOrderWorkSteps) {
		this.bpmStatusId = bpmStatusId;
		this.bpmStatusName = bpmStatusName;
		this.bpmOrderProcesses = bpmOrderProcesses;
		this.bpmOrderWorkSteps = bpmOrderWorkSteps;
	}

	/**
	 * Getter method for bpmStatusId. BPM_STATUS_ID mapped to BPM_STATUS_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "BPM_STATUS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBpmStatusId() {
		return this.bpmStatusId;
	}

	/**
	 * @param bpmStatusId to bpmStatusId set.
	 */
	public void setBpmStatusId(Long bpmStatusId) {
		this.bpmStatusId = bpmStatusId;
	}

	/**
	 * Getter method for bpmStatusName. BPM_STATUS_NAME mapped to BPM_STATUS_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BPM_STATUS_NAME", nullable = false, length = 100)
	public String getBpmStatusName() {
		return this.bpmStatusName;
	}

	/**
	 * @param bpmStatusName to bpmStatusName set.
	 */
	public void setBpmStatusName(String bpmStatusName) {
		this.bpmStatusName = bpmStatusName;
	}

	/**
	 * Getter method for bpmOrderProcesses.
	 * 
	 * @return Set<BpmOrderProcess>.
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmStatus")
	public Set<BpmOrderProcess> getBpmOrderProcesses() {
		return this.bpmOrderProcesses;
	}

	/**
	 * @param bpmOrderProcesses to bpmOrderProcesses set.
	 */
	public void setBpmOrderProcesses(Set<BpmOrderProcess> bpmOrderProcesses) {
		this.bpmOrderProcesses = bpmOrderProcesses;
	}

	/**
	 * Getter method for bpmOrderWorkSteps.
	 * 
	 * @return Set<BpmOrderWorkStep>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmStatus")
	public Set<BpmOrderWorkStep> getBpmOrderWorkSteps() {
		return this.bpmOrderWorkSteps;
	}

	/**
	 * @param bpmOrderWorkSteps to bpmOrderWorkSteps set.
	 */
	public void setBpmOrderWorkSteps(Set<BpmOrderWorkStep> bpmOrderWorkSteps) {
		this.bpmOrderWorkSteps = bpmOrderWorkSteps;
	}

}
