package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for Back-haul type. Mapped with BACKHAUL_TYPE table in the
 * database.
 */
@Entity
@Table(name = "BACKHAUL_TYPE")
public class BackhaulType implements java.io.Serializable {

	private static final long serialVersionUID = -8191966955217871482L;

	private Long backhaulTypeId;
	private String backhaulTypeName;
	private Set<Backhaul> backhauls = new HashSet<Backhaul>(0);
	private String isActive;
	/**
	 * Getter method for the backhaulTypeId. BACKHAUL_TYPE_ID mapped with
	 * BACKHAUL_TYPE_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "BACKHAUL_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBackhaulTypeId() {
		return this.backhaulTypeId;
	}

	/**
	 * @param backhaulTypeId
	 *            to backhaulTypeId set.
	 */
	public void setBackhaulTypeId(Long backhaulTypeId) {
		this.backhaulTypeId = backhaulTypeId;
	}

	/**
	 * Getter method for backhaulTypeName. BACKHAUL_TYPE_NAME mapped to
	 * BACKHAUL_TYPE_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BACKHAUL_TYPE_NAME", nullable = false, length = 100)
	public String getBackhaulTypeName() {
		return this.backhaulTypeName;
	}

	/**
	 * @param backhaulTypeName
	 *            to backhaulTypeName set.
	 */
	public void setBackhaulTypeName(String backhaulTypeName) {
		this.backhaulTypeName = backhaulTypeName;
	}

	/**
	 * Getter method for the backhauls.
	 * 
	 * @return Set<Backhaul>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "backhaulType")
	public Set<Backhaul> getBackhauls() {
		return this.backhauls;
	}

	/**
	 * @param backhauls
	 *            to backhauls set.
	 */
	public void setBackhauls(Set<Backhaul> backhauls) {
		this.backhauls = backhauls;
	}

	@Column(name = "ACTIVE", nullable = false, length = 1)
	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}
