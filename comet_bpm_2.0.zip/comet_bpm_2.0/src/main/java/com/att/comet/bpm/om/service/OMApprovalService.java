package com.att.comet.bpm.om.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OMApprovalService {

	void preOperation(CommonBO commonBO,String processInstanceId) throws CamundaServiceException;

	void approvedByOM(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

	void rejectedByOM(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

}
