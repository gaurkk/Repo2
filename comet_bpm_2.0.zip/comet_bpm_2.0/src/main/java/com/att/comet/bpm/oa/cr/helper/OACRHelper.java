package com.att.comet.bpm.oa.cr.helper;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusStepHistoryDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusinessStepDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.repository.OrdersRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OACRHelper {

	private static final Logger logger = LoggerFactory.getLogger(OACRHelper.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	OrderTypeRepository orderTypeRepository;
	@Autowired 
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
    BpmOrderBusinessStepDAO bpmOrderBusinessStepDAO;
	@Autowired
	BpmOrderBusStepHistoryDAO bpmOrderBusStepHistoryDAO;
	@Autowired
	OrderContactInfoDAO orderContactInfoDAO;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	CommonServiceHelper commonServiceHelper;
	
	public CommonBO processDBInteractionOperation(CommonBO commonBO ,String processInstanceId) throws CamundaServiceException {
		logger.info("Start processDBInteractionOperation method ::", this);
		commonBO.setProcessId(1027L);
		bpmDAO.deleteBpmOrderProcessByOrderIdAndProcessId(commonBO);
		/* INSERT record into BPM_ORDER_PROCESS */
		Long orderTypeId = orderTypeRepository.getOrderTypeId(commonBO.getOrderTypeName());
		commonBO.setOrderTypeId(orderTypeId);
		commonBO.setBpmProcessId(1027L);//OA CR PROCESS
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		
		
		/* INSERT record into AVOS_Process_Instances */
		commonBO.setBpmProcessInstanceId(processInstanceId);
		//avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		
		
		//(3179,3180,3181,3182,3183,3184)
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3179L);
		businessStepIdList.add(3180L);
		businessStepIdList.add(3181L);
		businessStepIdList.add(3182L);
		businessStepIdList.add(3083L);
		businessStepIdList.add(3184L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		
		List<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1067L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		
		
		/* Inserting record into BPM_Order_Work_Step */
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		commonBO.setOrderContactTypeId(1004L);
		//fetching dynamic user from order_contact_info table 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		List<String> oaEmailList=null;
		if(!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			oaEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(oaEmailList);
		}else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			oaEmailList =userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(oaEmailList);
		}
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {//if no Assignee , email will sent to grp 
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));//All grp
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All grp
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All grp
		}
	
		// DB OS Email For SLA
		commonBO.setOrderContactTypeId(1003L);
		List<String> oaSLAList = orderDAO.getOrderContactInfoATTUId(commonBO);
		List<String> osEmailList=null;
		if(!CollectionUtils.isEmpty(oaSLAList)) {
			logger.debug("oaSLAList is not empty : ", +oaSLAList.size());
			String orderSubmitter = oaSLAList.get(0);
			commonBO.setAttuid(orderSubmitter);
			osEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osEmailList);
		}else {
			logger.debug("oaSLAList is empty: ", +oaSLAList.size());
			commonBO.setRoleId(1001L);
			osEmailList =userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(osEmailList);
		}
		//get the assignee
		String assignee = null;
		commonBO.setOrderContactTypeId(1004L);
		//assignee = genericDAO.getOrderManagerApprovalUserTaskAssigneeByOrderId(commonBO);
		List<String> oaAttUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(oaAttUidList)) {
			logger.debug("osdEmailList is not empty : ", +oaAttUidList.size());
			String OA = oaAttUidList.get(0);
			commonBO.setAttuid(OA);
			commonBO.setAssignee(OA);
		}
		//commonBO.setAssignee(assignee);
		//TO DO set set reminder 1 /2 TO/CC email list
		commonBO.setUserAction("Submitted");
		commonBO.setOrderProcess(commonBO.getCrCountValue());//CR-001 //set on above
		commonBO.setComments(orderDAO.getOrderComments(commonBO));
		commonBO.setRoleId(1002L);
		
		//set Reminder 1/2/3/4
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
			//genericDAO.setReminderCROrderApproval(commonBO);
		}else {
			genericDAO.setReminderCROrderApproval(commonBO);
		}
		logger.info("Exit processDBInteractionOperation method ::", this);
		
		return commonBO;
	}

	public CommonBO postOperation(CommonBO commonBO,DelegateExecution execution)  throws CamundaServiceException, URISyntaxException{
		logger.info("Start postOperation method ::", this);
		String approved = (String) execution.getVariable("response");
		execution.setVariable("approved", approved);
		String comments = (String) execution.getVariable("comments");
		commonBO.setApproved(approved);
		commonBO.setComments(comments);
		Long crCount = orderDAO.countOrderEvent(commonBO);// do we need to know CR count?
		String crVar = "CR-00";
		if (null != crCount && crCount > 0) {
			crVar = crVar + "" + String.valueOf(crCount);
			commonBO.setCrCountValue(crVar);
		}	
		commonBO.setBusinessStepId(3179L);
		commonBO.setComments(commonBO.getComments());
		commonBO.setUpdatedOn(new Date());
		commonBO.setBusinessStepStatus(approved);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		//bpmOrderBusinessStepDAO.saveBpmOrderBusinessStepForOrderIdAndOaDetails(commonBO);
		bpmOrderBusStepHistoryDAO.saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(commonBO);
		
		commonBO.setBpmStepId(1002L);
		commonBO.setWorkStepId(1067L);
		bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);
		
		commonBO.setOrderContactTypeId(1004L);
		orderContactInfoDAO.updateOrderContactInfoForAttUidByOrderContactDetails(commonBO);
		if (commonBO.getApproved().equalsIgnoreCase("Approved")) {
			commonBO.setResponseHTAction("Order Review (OA) - Approved");
		} else {
			commonBO.setResponseHTAction("Order Review (OA) - Rejected");
		}
		commonBO.setRoleId(1002L);
		commonBO.setOrderProcess(commonBO.getCrCountValue());//CR-001 from pre operation
		updatingCommentsForOAApprovedOrRejected(commonBO);
		//check point for all process Status //110971L
		//commonBO.setCrCountValue("CR-02");
		if(null!=commonBO.getCrCountValue() && crCount>1 && commonBO.getApproved().equalsIgnoreCase("Approved")) {
			logger.info("CR COUNT VALUE="+commonBO.getCrCountValue(), this);
			logger.info("NOW FORCING TO COMPLETE ALL IN PROGRESS STATUS TASK UNDER ORDER_ID="+commonBO.getOrderId()+"Under TASK ID = 1028L", this);
			commonServiceHelper.terminateAllTasks(commonBO,execution);
			Orders order = new Orders();
			order.setOrderId(commonBO.getOrderId());
			Long taskId = 1028L;
			commonBO.setTaskId(1028L);
			List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
			if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
				// (1028L);//Mapped from BPM_task table (CR OA : Approval Task)
				if (taskId.equals(1028L)) {
					logger.info("Task ID request " + 1028L, this);
					for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
						if (taskObj.getBpmTask().getTaskId().equals(1028L)
								&& taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
							logger.info("bpmTaskId is :::  " + taskObj.getBpmTaskId(), this);
							commonBO.setBpmTaskId(taskObj.getBpmTaskId());
							commonBO.setTaskDescription(taskObj.getSubject());
							break;
						} else {
							logger.info("taskStatusName is null for orderId ::  " + commonBO.getOrderId()
									+ " for the task :: " + commonBO.getTaskId());
						}
					}
				}
			}
			commonBO.setRoleId(1002L);
			commonBO.setTaskStatusId(1002L);
			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			// updating Order_user_bpm_tasks Table
			commonService.updateOrderUserBpmTasksRepository(commonBO);
			logger.info("!!!!NOW FORCING TO COMPLETE ALL IN PROGRESS STATUS TASK UNDER ORDER_ID="+commonBO.getOrderId()+"Under TASK ID = 1028L IS OVER !!!!!!!", this);
		}
		commonBO.setOrderContactTypeId(1003L);
		//fetching dynamic user from order_contact_info table 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		List<String> oaEmailList=null;
		if(!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			oaEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(oaEmailList);
		}else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			oaEmailList =userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(oaEmailList);
		}
	
		//calling orders table again to get the order status.
		/*Optional<Orders> orders = ordersRepository.findById(commonBO.getOrderId());
		if(orders.isPresent()) {
			Orders orderObj = orders.get();
			orderObj.getOrderStatus().getOrderStatusId();
		}*/
		//not needed for OS email even its on AVOS diagram as we already took on preoperation above.
		commonBO.setRoleId(1002L);
		logger.info("Exit  postOperation method ::", this);
		return commonBO;
	}

	private void updatingCommentsForOAApprovedOrRejected(CommonBO commonBO) {
		if (commonBO.getOrderOperation().equals(BpmConstant.NEW_ORDER)) {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected ::" + commonBO.getOrderOperation(),
					this);
			/// Need to check order Type from Initial FE request from Main delegate
			orderDAO.saveOrderComments(commonBO);
		} else if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_ORDER)) {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			orderDAO.saveOrderComments(commonBO);
		} else if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_REQUEST)) {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			orderDAO.saveOrderComments(commonBO);
		}
	}

	public void rejected(CommonBO commonBO)throws CamundaServiceException {
		logger.info("@Starting method rejected ::" + commonBO.getOrderOperation(),
				this);
		//for rejection order email will sent OS will be taken care on task listener
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		commonBO.setProcessId(1027L);
		commonBO.setTaskStatusId(1002L);
		
		bpmDAO.updateBpmOrderProcess(commonBO);
		commonBO.setCrFlag(' ');
		orderDAO.updateOrderCrFlag(commonBO);
		if(commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			orderDAO.rollbackAuditOrder(commonBO);
		}else {
			logger.debug("@@ cancel order has been rejected @@ ", this);
		}
	}

	public void approved(CommonBO commonBO)throws CamundaServiceException{
		logger.info("@Starting method approved ::" + commonBO.getOrderOperation(),
				this);
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		commonBO.setProcessId(1027L);
		commonBO.setTaskStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);
		//update CR_FLAG in orders
		commonBO.setCrFlag('A');
		orderDAO.updateOrderCrFlag(commonBO);
	}
}

