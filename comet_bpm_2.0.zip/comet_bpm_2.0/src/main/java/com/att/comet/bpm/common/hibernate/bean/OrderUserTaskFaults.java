package com.att.comet.bpm.common.hibernate.bean;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import lombok.Data;

@Entity
@Table(name = "ORDER_USER_TASK_FAULTS")
@Data
public class OrderUserTaskFaults implements Serializable {

	private static final long serialVersionUID = -570195162063594268L;

	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_UTF_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_ORDER_UTF_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_UTF_ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BPM_TASK_ID")
	private OrderUserBpmTasks OrderUserBpmTasks;

	@Column(name = "ERROR_CODE", unique = false, nullable = false, precision = 12, scale = 0)
	private String errorCode;

	@Column(name = "ERROR_DESC", length = 2000)
	private String errorDesc;

	@Column(name = "CREATION_ON")
	private Date creationOn;
}
