package com.att.comet.bpm.core.processes.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.repository.OrdersRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class CoreProcessServicesImpl implements CoreProcessService {
	private static final Logger logger = LoggerFactory.getLogger(CoreProcessServicesImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	@Autowired
	OrdersRepository ordersRepository;

	@Override
	public void cancelOrderPreOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method cancelOrderPreOperation");
		List<String> allUsersEmailList = null;
		// update order status
		commonBO.setOrderStatusId(1010L);
		orderDAO.updateOrders(commonBO);
		// update bpm_order_process
		commonBO.setBpmStatusId(1001L);
		commonBO.setOrderTypeName("cancel order");
		bpmDAO.updateBpmOrderProcess(commonBO);
		// retrieve all email ID of comet users
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		orderContactTypeIdList.add(1024L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		/*
		 * List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		 * allUsersEmailList = new ArrayList<String>(); if
		 * (!CollectionUtils.isEmpty(emailList)) {
		 * logger.debug("osdEmailList is not empty : ", +emailList.size()); for
		 * (Object[] obj : emailList) { if (null != obj[1]) {
		 * allUsersEmailList.add((String) obj[1]); } }
		 * commonBO.setAdminEmailList(allUsersEmailList); } else {
		 * logger.error("osdEmailList is empty: ", +emailList.size()); }
		 */
		// select fan_id from order_account where order_id=120446
		logger.info("::Exiting  Method cancelOrderPreOperation Method :: ");
	}

	@Override
	public void pendingTaskStatusCheck(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method pendingTaskStatusCheck");
		// getting the status of pending taskes
		// fetching process status
		BpmTask bpmTask = new BpmTask();
		Orders order = new Orders();
		// commonBO.setTaskId(1023L);
		// bpmTask.setTaskId(commonBO.getTaskId());
		order.setOrderId(commonBO.getOrderId());
		String omTaskStatus = null;
		String apnItOpsTaskStatus = null;
		String apnIwosTaskStatus = null;
		String ttuPreflightTaskStatus = null;
		String ttuApplicabilityTaskStatus = null;
		String ttuResultTaskStatus = null;
		String ttuRescheduleTaskStatus = null;
		String ttuPerformTaskStatus = null;
		String ttuScheduleTaskStatus = null;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
			if (null != taskObj) {
				if (taskObj.getBpmTask().getTaskId().equals(1011L)) {
					omTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("omTaskStatus  :: " + omTaskStatus, this);
					commonBO.setOmTaskStatus(omTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1021L)) {
					apnItOpsTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("apnItOpsTaskStatus  :: " + apnItOpsTaskStatus, this);
					commonBO.setApnItOpsTaskStatus(apnItOpsTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1016L)) {
					apnIwosTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("apnIwosTaskStatus  :: " + apnIwosTaskStatus, this);
					commonBO.setApnIwosTaskStatus(apnIwosTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1022L)) {
					ttuPreflightTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuPreflightTaskStatus  :: " + ttuPreflightTaskStatus, this);
					commonBO.setTtuPreflightTaskStatus(ttuPreflightTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1023L)) {
					ttuApplicabilityTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuApplicabilityTaskStatus  :: " + ttuApplicabilityTaskStatus, this);
					commonBO.setTtuApplicabilityTaskStatus(ttuApplicabilityTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1024L)) {
					ttuScheduleTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuScheduleTaskStatus  :: " + ttuScheduleTaskStatus, this);
					commonBO.setTtuScheduleTaskStatus(ttuScheduleTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1025L)) {
					ttuPerformTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuPerformTaskStatus  :: " + ttuPerformTaskStatus, this);
					commonBO.setTtuPerformTaskStatus(ttuPerformTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1026L)) {
					ttuResultTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuResultTaskStatus  :: " + ttuResultTaskStatus, this);
					commonBO.setTtuResultTaskStatus(ttuResultTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1027L)) {
					ttuRescheduleTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("ttuRescheduleTaskStatus  :: " + ttuRescheduleTaskStatus, this);
					commonBO.setTtuRescheduleTaskStatus(ttuRescheduleTaskStatus);
				}
			} else {
				logger.error("taskObj is empty: ", this);
			}
		}

		logger.info("::Exiting  Method pendingTaskStatusCheck Method :: ");

	}

	@Override
	public String billingTaskStatus(CommonBO commonBO) {
		logger.info("@@@ Starting billingTaskStatus @@@ ::: ", this);
		String billingTaskStatus = null;
		String iwosHlrTaskStatus = null;
		String apnItOpsTaskStatus = null;
		String apnIwosTaskStatus = null;
		String niTaskStatus = null;
		String iwosHlrCompleteTaskStatus = null;
		Orders order = new Orders();
		order.setOrderId(commonBO.getOrderId());
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
			if (null != taskObj) {
				if (taskObj.getBpmTask().getTaskId().equals(1020L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					billingTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("@@@  billingTaskStatus @@@  :: " + billingTaskStatus, this);
				} else if (taskObj.getBpmTask().getTaskId().equals(1021L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					apnItOpsTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("apnItOpsTaskStatus  :: " + apnItOpsTaskStatus, this);
					commonBO.setApnItOpsTaskStatus(apnItOpsTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1016L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					apnIwosTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("apnIwosTaskStatus  :: " + apnIwosTaskStatus, this);
					commonBO.setApnIwosTaskStatus(apnIwosTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1060L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					iwosHlrTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("iwosHlrTaskStatus  :: " + iwosHlrTaskStatus, this);
					commonBO.setTtuPreflightTaskStatus(iwosHlrTaskStatus);
				} else if (taskObj.getBpmTask().getTaskId().equals(1019L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					niTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("niTaskStatus  :: " + niTaskStatus, this);
					
				} else if (taskObj.getBpmTask().getTaskId().equals(1015L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					iwosHlrCompleteTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					logger.info("iwosHlrCompleteTaskStatus  :: " + iwosHlrCompleteTaskStatus, this);
					
				}
			} else {
				logger.error("@@@ taskObj is empty: @@@ ", this);
			}
			
		}
		if ((null == billingTaskStatus || billingTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
				&& (null == apnItOpsTaskStatus || apnItOpsTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
				&& (null == apnIwosTaskStatus || apnIwosTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
				&& (null == iwosHlrTaskStatus || iwosHlrTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
				&& (null == niTaskStatus || niTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
				&& (null == iwosHlrCompleteTaskStatus || iwosHlrCompleteTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))) {

			billingTaskStatus = BpmConstant.COMPLETED;

		} else {
			billingTaskStatus = BpmConstant.CREATED;
		}
		logger.info("@@@ Exiting billingTaskStatus @@@ ::: ", this);
		return billingTaskStatus;

	}

	@Override
	public void completeProcess(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method completeProcess");
		String processInstanceId = null;
		Orders order = new Orders();
		order.setOrderId(commonBO.getOrderId());
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
			if (null != taskObj) {
				if (taskObj.getBpmTask().getTaskId().equals(1020L)
						&& taskObj.getTaskStatus().getTaskStatusId().equals(1002L)) {
					processInstanceId = taskObj.getProcessInstanceId();
					logger.info("@@@  processInstanceId @@@  :: " + processInstanceId, this);
					break;
				}
			} else {
				logger.error("@@@ taskObj is empty: @@@ ", this);
			}
		}
		if (CommonUtils.isNotNullEmpty(processInstanceId)) {
			// execution.getProcessEngine().getRuntimeService().deleteProcessInstance(processInstanceId,
			// "deleteReason", true, true, true);
		}
		logger.info("::@@@ Exiting  Method completeProcess Method @@@ :: ");

	}

	@Override
	public void userDecisionCheck(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method userDecisionCheck");
		String userDecision = null;
		// List<Object[]> processDetails = null;

		String apnIwosUserDecision = null;
		String billingUserDecision = null;
		commonBO.setOrderTypeId(1002L);
		List<Object[]> processDetails = bpmDAO.getProcessUserDecision(commonBO);
		if (!CollectionUtils.isEmpty(processDetails)) {
			for (Object[] processDetailsdata : processDetails) {
				String processId = processDetailsdata[0].toString();
				if (null != processId && CommonUtils.isNotNullEmpty(processId)) {
					logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
					if (null != processDetailsdata[1]) {
						userDecision = processDetailsdata[1].toString();
						if (null != userDecision && CommonUtils.isNotNullEmpty(userDecision)) {
							if (processId.equalsIgnoreCase("1005")) {
								apnIwosUserDecision = userDecision;
								logger.info("apnIwosUserDecision  :: " + apnIwosUserDecision, this);
								commonBO.setApnIwosUserDecision(apnIwosUserDecision);
							} else if (processId.equalsIgnoreCase("1011")) {
								billingUserDecision = userDecision;
								logger.info("billingUserDecision  :: " + billingUserDecision, this);
								commonBO.setBillingUserDecision(billingUserDecision);
							}
						} else {
							logger.error("userDecision is null: " + userDecision, this);
						}
					} else {
						logger.error("processDetailsdata[1] is null: ", this);
					}

				} else {
					logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
				}
			}
		} else {
			logger.error("processDetails is empty: ", +processDetails.size());
		}
		logger.info("::Exiting  Method userDecisionCheck Method :: ");

	}

	@Override
	public void cancelOrderPostOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method cancelOrderPostOperation");
		// update order status as cancelled
		commonBO.setOrderStatusId(1003L);
		orderDAO.updateOrders(commonBO);
		// cancelled order store procedure call
		boolean result = commonService.completeCancelOrderWorkFlow(commonBO);
		if (result) {
			logger.info("[result is : " + result + "for the OrderID :: ", (commonBO.getOrderId() + "] "), this);
		} else {
			logger.error("result is null ::  ", this);
		}

		// update bpm_order_process
		commonBO.setBpmStatusId(1002L);
		commonBO.setOrderTypeName("cancel order");
		bpmDAO.updateBpmOrderProcess(commonBO);
		// update IMSI Inventory
		// commonBO.setOrderId(0L);
		orderDAO.updateImsiInventory(commonBO);
		Long derivedOrder = orderDAO.getDerivedOrderId(commonBO);
		if(null!=derivedOrder) {
			logger.info("@@@ derivedOrder is @@@  "+derivedOrder,this);
			orderDAO.updateOrderStatus(derivedOrder, 1009L);
			
		}else {
			logger.error("@@@ derivedOrder is null @@@ ",this);
		}
		logger.info("::Exiting  Method cancelOrderPostOperation Method :: ");

	}

	@Override
	public void postDecomUserTaskOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postDecomUserTaskOperation");
		// Invoke Email to CCSPM for Dashboard Completion
		/* Set Reminder1 & Reminder2 SLA Dates for Decommission Dashboard */
		genericDAO.setReminder1And2FromSlaWorkingDayForDashboardDecom(commonBO);

		/* INSERT 3168 & 3169 records into BPM_Order_Business_Step */
		commonBO.setBusinessStepId(3168L); // Mapped with BPM_BUSINESS_STEP table ; REMINDER1
		commonBO.setBusinessStepStatus("Reminder1 Notification has been sent");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		commonBO.setBusinessStepId(3169L); // Mapped with BPM_BUSINESS_STEP table ; REMINDER2
		commonBO.setBusinessStepStatus("Reminder2 Notification has been sent");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
	}

	@Override
	public void preDecomOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Starting  Method preOperationCO Method :: ");
		Long derivedFromOrderId = orderDAO.getDerivedOrderId(commonBO);
		commonBO.setDerivedFromOrderId(derivedFromOrderId);

		/* Get Email Ids for All Users */
		List<Long> orderContactTypeIdList = new ArrayList<>();
		orderContactTypeIdList.add(1003L); // Order Submitter
		orderContactTypeIdList.add(1004L); // Order Approver
		orderContactTypeIdList.add(1005L); // Order Manager
		orderContactTypeIdList.add(1006L); // CCSPM
		orderContactTypeIdList.add(1007L); // Network Implementation
		orderContactTypeIdList.add(1023L); // OSD
		orderContactTypeIdList.add(1024L); // IT OPS
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<String> allUsersEmailList = userDAO.findEmailAllUsers(commonBO);

		String usersEmail = allUsersEmailList.stream().collect(Collectors.joining(","));

		commonBO.setToEmail(usersEmail);

		logger.info("::Exiting  Method preOperationCO Method :: ");
	}

}
