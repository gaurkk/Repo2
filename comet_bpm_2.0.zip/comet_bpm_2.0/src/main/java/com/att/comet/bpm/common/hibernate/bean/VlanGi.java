package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VLAN_GI")
public class VlanGi implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8582556125223745394L;
	private OrderDataCenterId id;
	private String vlanGi;
	private InfraGiInformation infraGiInfo;
	private Orders orders;
	private String rdRtName;
	private String gatewaySgiContext;
	private String inOutInterface;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public OrderDataCenterId getId() {
		return this.id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(OrderDataCenterId id) {
		this.id = id;
	}

	@Column(name = "VLAN_GI")
	public String getVlanGi() {
		return vlanGi;
	}

	public void setVlanGi(String vlanGi) {
		this.vlanGi = vlanGi;
	}

	/**
	 * @return the infraGiInfo
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public InfraGiInformation getInfraGiInfo() {
		return infraGiInfo;
	}

	/**
	 * @param infraGiInfo the infraGiInfo to set
	 */
	public void setInfraGiInfo(InfraGiInformation infraGiInfo) {
		this.infraGiInfo = infraGiInfo;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * @return the rdRtName
	 */
	@Column(name = "RD_RT")
	public String getRdRtName() {
		return rdRtName;
	}

	/**
	 * @param rdRtName the rdRtName to set
	 */
	public void setRdRtName(String rdRtName) {
		this.rdRtName = rdRtName;
	}

	/**
	 * @return the gatewaySgiContext
	 */
	@Column(name = "GATEWAY_SGI_CONTEXT")
	public String getGatewaySgiContext() {
		return gatewaySgiContext;
	}

	/**
	 * @param gatewaySgiContext the gatewaySgiContext to set
	 */
	public void setGatewaySgiContext(String gatewaySgiContext) {
		this.gatewaySgiContext = gatewaySgiContext;
	}

	/**
	 * @return the inOutInterface
	 */
	@Column(name = "IN_OUT_INTERFACE")
	public String getInOutInterface() {
		return inOutInterface;
	}

	/**
	 * @param inOutInterface the inOutInterface to set
	 */
	public void setInOutInterface(String inOutInterface) {
		this.inOutInterface = inOutInterface;
	}
}