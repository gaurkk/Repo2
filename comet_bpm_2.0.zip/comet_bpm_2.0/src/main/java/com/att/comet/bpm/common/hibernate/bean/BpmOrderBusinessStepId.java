package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderBusinessStepId.
 */
@Embeddable
public class BpmOrderBusinessStepId implements Serializable {

	private static final long serialVersionUID = 8225587161441223109L;

	private Long orderId;
	private Long businessStepId;
	private Long orderTypeId;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for businessStepId. BUSINESS_STEP_ID mapped to
	 * BUSINESS_STEP_IDin the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BUSINESS_STEP_ID", nullable = false, precision = 12, scale = 0)
	public Long getBusinessStepId() {
		return this.businessStepId;
	}

	/**
	 * @param businessStepId to businessStepId set.
	 */
	public void setBusinessStepId(Long businessStepId) {
		this.businessStepId = businessStepId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderBusinessStepId))
			return false;
		BpmOrderBusinessStepId castOther = (BpmOrderBusinessStepId) other;

		return (this.getOrderId() == castOther.getOrderId())
				&& (this.getBusinessStepId() == castOther.getBusinessStepId())
				&& (this.getOrderTypeId() == castOther.getOrderTypeId());
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getOrderId().hashCode();
		result = 37 * result + (int) this.getBusinessStepId().hashCode();
		result = 37 * result + (int) this.getOrderTypeId().hashCode();
		return result;
	}

}