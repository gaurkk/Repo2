package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ORDER_UPLOAD_FILE_DETAILS")
public class OrderUploadFileDetails {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "uploadId", column = @Column(name = "UPLOAD_FILE_TYPE_DOC_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)) })
	private OrderUploadId  orderUploadId;
	
	@Column(name = "UPLOAD_FILE_TYPE")
	private String uploadFileType;
	
	@Column(name = "UPLOAD_FILE_NAME")
	private String uploadFileName;
	
	@Column(name = "UPLOAD_FILE_ATTACHMENT")
	private byte[] uploadFileAttachment;
	
}
