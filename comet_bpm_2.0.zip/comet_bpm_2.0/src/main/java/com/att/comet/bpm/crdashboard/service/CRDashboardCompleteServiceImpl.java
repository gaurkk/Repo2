package com.att.comet.bpm.crdashboard.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.crdashboard.helper.CRDashboardCompleteHelper;
@Service
public class CRDashboardCompleteServiceImpl implements CRDashboardCompleteService{
	private static final Logger logger = LoggerFactory.getLogger(CRDashboardCompleteServiceImpl.class);
	@Autowired
	CRDashboardCompleteHelper crDashboardCompleteHelper;
	@Autowired
	CommonService commonService;
	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		crDashboardCompleteHelper.crPreOprCRUD(commonBO,processInstanceId);
		
	}

	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		crDashboardCompleteHelper.crPostOprCRUD(commonBO,execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		
	}

}
