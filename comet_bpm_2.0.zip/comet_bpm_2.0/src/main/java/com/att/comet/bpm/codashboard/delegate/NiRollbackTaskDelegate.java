package com.att.comet.bpm.codashboard.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.codashboard.service.NiRollbackTaskService;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class NiRollbackTaskDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(NiRollbackTaskDelegate.class);
	@Autowired
	NiRollbackTaskService niRollbackTaskService;
	@Autowired
	CommonService commonService;
	public static final String URL_NAME = "SEARCH_ORDER_URL";
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {

				case BpmConstant.NI_ROLLBACK_PRE_OPERATION:
					niRollbackPreOperation(execution);
					break;
				case BpmConstant.NI_ROLLBACK_POST_OPERATION:
					niRollbackPostOperation(execution);
					break;
				}
			}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.CO_NI_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void niRollbackPreOperation(DelegateExecution execution) {
		logger.info("Start niRollbackPreOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.CO_NI_ERR_PRE_001);
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1038L);
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				commonBO = commonService.getCommonBO(orderId);

				if (null != commonBO) {
					BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
					execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
					execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
					execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setRoleId(1004L);// ROLE table , ROLE_NAME = Order Approver
					commonBO.setTaskStatusId(1001L); // TASK_STATUS table , TASK_STATUS_DESC = CREATED
					commonBO.setCategoryId(1002L); // TASK_CATEGORY table , TASK_CATEG_DESC = USER
													// commonBO.setTaskStatusName("CancelOABillingTask");
					commonBO.setTaskId(1040L);// BPM_TASK table , TASK_NAME = OA : Billing Request - Submission(CR)
												// CancelOABillingTask
					commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
					commonBO.setTaskStatusName("NIRollbackIWOSTask");
					
					commonBO.setOrderOperation(orderOperation);
					niRollbackTaskService.niRollbackTaskPreOperation(commonBO, execution.getProcessInstanceId());
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
					execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
				} else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);

				}
			} else {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
						this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.CO_NI_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End niRollbackPreOperation method ::", this);

	}

	private void niRollbackPostOperation(DelegateExecution execution) {
		logger.info("Inside niRollbackPostOperation");
		String niComment = (String) execution.getVariable(BpmConstant.COMMENTS);
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		commonBO.setComments(niComment);
		// OrderUserTaskFaults
		OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
		orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.CO_NI_ERR_POST_001);
		orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
		orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
		orderUserTaskFaultsBO.setRoleId(1004L);// CCS PM Role Id
		orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
		orderUserTaskFaultsBO.setTaskId(1038L);
		orderUserTaskFaultsBO.setOrderId(commonBO.getOrderId());// OrderId
		orderUserTaskFaultsBO.setCreationOn(new Date());
		execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
		try {
			niRollbackTaskService.niRollbackTaskPostOperation(commonBO);
			
			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);
			commonBO.setTaskId(1040L);
			commonBO.setRoleId(1004L);
			commonService.updateOrderUserBpmTasksRepository(commonBO);
		} catch (CamundaServiceException e) {
			
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.CO_NI_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());

		}
		logger.info("end niRollbackPostOperation");

	}

}
