package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for BpmWorkStep . Mapped to BPM_WORK_STEP table in the
 * database.
 */
@Entity
@Table(name = "BPM_WORK_STEP")
public class BpmWorkStep implements Serializable {

	private static final long serialVersionUID = 5034321996224887487L;

	private Long workStepId;
	private BpmProcess bpmProcess;
	private String workStepName;
	private Set<BpmOrderWorkStep> bpmOrderWorkSteps = new HashSet<BpmOrderWorkStep>(0);
	private Set<BpmBusinessStep> bpmBusinessSteps = new HashSet<BpmBusinessStep>(0);
	private Set<BpmWorkStepSla> bpmWorkStepSlas = new HashSet<BpmWorkStepSla>(0);

	/**
	 * Getter method for workStepId. WORK_STEP_ID mapped to WORK_STEP_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "WORK_STEP_ID", unique = true, nullable = false, precision = 22, scale = 0)
	public Long getWorkStepId() {
		return this.workStepId;
	}

	/**
	 * @param workStepId to workStepId set.
	 */
	public void setWorkStepId(Long workStepId) {
		this.workStepId = workStepId;
	}

	/**
	 * Getter method for bpmProcess. PROCESS_ID mapped to PROCESS_ID in the database
	 * table.
	 * 
	 * @return BpmProcess
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PROCESS_ID", nullable = false)
	public BpmProcess getBpmProcess() {
		return this.bpmProcess;
	}

	/**
	 * @param bpmProcess to bpmProcess set.
	 */
	public void setBpmProcess(BpmProcess bpmProcess) {
		this.bpmProcess = bpmProcess;
	}

	/**
	 * Getter method for workStepName WORK_STEP_NAME mapped to WORK_STEP_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "WORK_STEP_NAME", nullable = false, length = 100)
	public String getWorkStepName() {
		return this.workStepName;
	}

	/**
	 * @param workStepName to workStepName set.
	 */
	public void setWorkStepName(String workStepName) {
		this.workStepName = workStepName;
	}

	/**
	 * Getter method for bpmOrderWorkSteps.
	 * 
	 * @return Set<BpmOrderWorkStep>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmWorkStep")
	public Set<BpmOrderWorkStep> getBpmOrderWorkSteps() {
		return this.bpmOrderWorkSteps;
	}

	/**
	 * @param bpmOrderWorkSteps to bpmOrderWorkSteps set.
	 */
	public void setBpmOrderWorkSteps(Set<BpmOrderWorkStep> bpmOrderWorkSteps) {
		this.bpmOrderWorkSteps = bpmOrderWorkSteps;
	}

	/**
	 * Getter method for bpmBusinessSteps.
	 * 
	 * @return Set<BpmBusinessStep>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmWorkStep")
	public Set<BpmBusinessStep> getBpmBusinessSteps() {
		return this.bpmBusinessSteps;
	}

	/**
	 * @param bpmBusinessSteps to bpmBusinessSteps set.
	 */
	public void setBpmBusinessSteps(Set<BpmBusinessStep> bpmBusinessSteps) {
		this.bpmBusinessSteps = bpmBusinessSteps;
	}

	/**
	 * Getter method for bpmWorkStepSlas.
	 * 
	 * @return Set<BpmWorkStepSla>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmWorkStep")
	public Set<BpmWorkStepSla> getBpmWorkStepSlas() {
		return this.bpmWorkStepSlas;
	}

	/**
	 * @param bpmWorkStepSlas to bpmWorkStepSlas set.
	 */
	public void setBpmWorkStepSlas(Set<BpmWorkStepSla> bpmWorkStepSlas) {
		this.bpmWorkStepSlas = bpmWorkStepSlas;
	}
}