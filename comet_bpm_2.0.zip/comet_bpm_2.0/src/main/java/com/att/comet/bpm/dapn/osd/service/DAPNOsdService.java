package com.att.comet.bpm.dapn.osd.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface DAPNOsdService {
	public void preOperation(CommonBO commonBO) throws CamundaServiceException;
	public void postOperation(CommonBO commonBO) throws CamundaServiceException;
}
