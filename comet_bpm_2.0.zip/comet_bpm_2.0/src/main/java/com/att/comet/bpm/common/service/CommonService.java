package com.att.comet.bpm.common.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;

public interface CommonService {
	CommonBO getCommonBO(Long orderId) throws CamundaServiceException;
	BpmUrl getBpmUrl(String urlName);
	void updateOrderUserBpmTasksRepository(CommonBO commonBO)throws CamundaServiceException;
	void updateTaskData(CommonBO commonBO)throws CamundaServiceException;
	String findUserDecision(CommonBO commonBO);
	String completeOrderWorkFlow(Long orderId,String orderOperation)throws CamundaServiceException;
	boolean completeCancelOrderWorkFlow(CommonBO commonBO) throws CamundaServiceException;
	void onHoldPreOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException;
	void onHoldCancelOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;
	void onHoldResumeOperation(CommonBO commonBO) throws CamundaServiceException;
	Integer getBpmStatus(Long orderId,Long workStepId)throws CamundaServiceException;
	CommonBO getDapnCommonBO(Long orderId) throws CamundaServiceException;
}
