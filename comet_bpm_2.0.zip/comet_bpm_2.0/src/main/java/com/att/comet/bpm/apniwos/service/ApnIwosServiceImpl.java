package com.att.comet.bpm.apniwos.service;

import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.apniwos.helper.ApnIwosHelper;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;

@Component
public class ApnIwosServiceImpl implements ApnIwosService {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosServiceImpl.class);
	@Autowired
	ApnIwosHelper apnIwosHelper;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	CommonService commonService;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("Start preApnIwosCRUDOperation method ::", this);
		apnIwosHelper.preApnIwosPreCRUDOperation(commonBO, processInstanceId);
		logger.info("Existing preApnIwosCRUDOperation method ::", this);

	}

	@Override
	public void updateBpmOrderExpedite(CommonBO commonBO) {
		genericDAO.updateBpmOrderExpedite(commonBO);

	}

	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException, URISyntaxException, ParseException {
		logger.info("Start postOperation method ::", this);
		apnIwosHelper.postApnIwosPostCRUDOperation(commonBO, execution);
		commonBO.setProcessId(1024L);//APN HLR IWOS PROCESS
		commonBO.setBpmProcessId(1024L);//APN HLR IWOS PROCESS
		Orders order = new Orders();
		commonBO.setTaskId(1016L);
		order.setOrderId(commonBO.getOrderId());
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
					if (taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						commonBO.setBpmTaskId(taskObj.getBpmTaskId());
						commonBO.setTaskDescription(taskObj.getSubject());
						commonBO.setAttuid(taskObj.getAttuid());
						commonBO.setProcessId(taskObj.getProcessId());
						commonBO.setProcessInstanceId(taskObj.getProcessInstanceId());
						break;
					} else {
						logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId()
								+ " for the task :: " + commonBO.getTaskId());
					}
				}
		}
		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1005L);// CCS PM Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		//commonBO.setTaskId(1014L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		// find expedite status
		String expediteStatus = bpmDAO.getExpediteStatus(commonBO) != null ? bpmDAO.getExpediteStatus(commonBO) : null;
		if (null != expediteStatus && expediteStatus.equalsIgnoreCase("true")) {
			// pick operation
			commonServiceHelper.pickOperation(commonBO, execution);

			logger.info("pick operation performed successfully for the order : " + commonBO.getOrderId());

			commonBO.setApnCreationStatus("post");
			bpmDAO.updateBpmOrderExpedite(commonBO);
		}

		logger.info("Existing postOperation method ::", this);
	}

}
