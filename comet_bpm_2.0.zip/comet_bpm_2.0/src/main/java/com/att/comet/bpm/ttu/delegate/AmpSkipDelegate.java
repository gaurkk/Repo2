package com.att.comet.bpm.ttu.delegate;

import java.math.BigDecimal;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Component
public class AmpSkipDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(AmpSkipDelegate.class);

	@Autowired
	private CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		CommonBO commonBO = (CommonBO) execution.getVariable("commonBO");
		execution.setVariable("ampFlag", commonBO.getAmpFlag());
		Long ampReqStatus = coreProcessDelegateHelper.checkAmpReqStatus(execution, commonBO);
		logger.info("ampRequestStatus :: "+ampReqStatus, this);
		if(ampReqStatus !=null) {
			execution.setVariable("ampReqStatus", ampReqStatus);
		}else {
			logger.info("ampRequestStatus :: "+ampReqStatus, this);
			execution.setVariable("ampReqStatus", "NA");
		}
		
	}

}
