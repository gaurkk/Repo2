package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for EntitlementId.
 */
@Embeddable
public class EntitlementId implements Serializable {

	private static final long serialVersionUID = 7529991052792496080L;

	private Long roleId;
	private Long resourceId;

	/**
	 * Getter method for roleId. ROLE_ID mapped to ROLE_ID in the database table.
	 * 
	 * @return
	 */
	@Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)
	public Long getRoleId() {
		return this.roleId;
	}

	/**
	 * @param roleId to roleId set.
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * Getter method for resourceId. RESOURCE_ID mapped to RESOURCE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "RESOURCE_ID", nullable = false, precision = 12, scale = 0)
	public Long getResourceId() {
		return this.resourceId;
	}

	/**
	 * @param resourceId to resourceId set.
	 */
	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof EntitlementId))
			return false;
		EntitlementId castOther = (EntitlementId) other;

		return (this.getResourceId() == castOther.getResourceId()) && (this.getRoleId() == castOther.getRoleId());
	}
}