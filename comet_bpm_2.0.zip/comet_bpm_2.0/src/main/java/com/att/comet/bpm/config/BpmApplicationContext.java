package com.att.comet.bpm.config;

import java.sql.SQLException;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.spring.ProcessEngineFactoryBean;
import org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import org.springframework.web.client.RestTemplate;
/**
 * CONTEXT FILE TO LOAD CAMUNDA ENGINE AND REST APPLICATION
 * @author pd6080
 *
 */
@ComponentScan({"com.att.comet"})
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = { "com.att.comet.bpm.common.repository"})
@Configuration
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class BpmApplicationContext implements TransactionManagementConfigurer{

	private static final Logger logger = LoggerFactory.getLogger(BpmApplicationContext.class);
	
	//CAMUNDA DATASOURCE JINDI NAME
   // @Value("${spring.datasource.jndi-name}") private String JNDINAME_BPM;
   // @Value("${spring.datasourceComet.jndi-name}") private String JNDINAME_COMET;
	
	//////////////////END OF JINDI //////////////////////////////////////////////
	
	///////////////LOCAL ENV SETUP ENABLE ONLY FOR LOCAL //////////////////////////////
	//CAMUNDA DATASOURCE PARAMS
	@Value("${spring.datasource.driverClassName}") 
	private String	driverClassName;
	  
	@Value("${spring.datasource.username}") private String username; 
	
	@Value("${spring.datasource.password}") private String password;
	  		
    @Value("${spring.datasource.url}") private String url;
    
    //COMET DATASOURCE PARAMS
    @Value("${spring.datasourceComet.driverClassName}") private String	cometdriverClassName;
	  
	@Value("${spring.datasourceComet.username}") private String cometUsername; 
	
	@Value("${spring.datasourceComet.password}") private String cometPassword;
	  
    @Value("${spring.datasourceComet.url}") private String cometUrl;

    @Value("${camunda.bpm.history-level}") private String historyLevel;
    ///////////////////END OF LOCAL SETUP Data Source///////////////////////////////
   
    @Bean
	   public RestTemplate getRestTemplate() {
	      return new RestTemplate();
	   }
 
    
    ///////////////////PROFILE FOR CAUMDA DATASOURCE ONLY FOR ENV//////////////////
	/*
	 * @Bean
	 * 
	 * @Primary public DataSource dataSource() {
	 * logger.debug("SETUP DATABASE DATA SOURCE FOR CAMUNDA", this); final
	 * JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
	 * dsLookup.setResourceRef(true); DataSource dataSource =
	 * dsLookup.getDataSource(JNDINAME_BPM); try {
	 * System.out.println("DataSource CAMUNDA:"+dataSource.getConnection().getSchema
	 * ().toString()); } catch (SQLException e) {
	 * System.out.println("DataSource CAMUNDA: Error found"); e.printStackTrace(); }
	 * return dataSource; }
	 */
    
    /////////////////END OF PROFILE FOR CAUMDA DATASOURCE ONLY FOR ENV/////////////
	
	///////////////////PROFILE FOR COMET DATASOURCE ONLY FOR ENV//////////////////
	/*
	 * @Bean public DataSource dataSourceComet() {
	 * logger.debug("SETUP DATABASE DATA SOURCE FOR COMET", this); final
	 * JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
	 * dsLookup.setResourceRef(true); DataSource dataSource =
	 * dsLookup.getDataSource(JNDINAME_COMET); try {
	 * System.out.println("DataSource Comet:"+dataSource.getConnection().getSchema()
	 * .toString()); } catch (SQLException e) {
	 * System.out.println("DataSource Comet: Error found"); e.printStackTrace(); }
	 * return dataSource; }
	 */
	 
	 /////////////////END OF PROFILE FOR COMET DATASOURCE ONLY FOR ENV/////////////
	
    ///////////////ENABLE ONLY FOR ENV ONLY/////////////////////////////////////// 
    @Value("${camunda.bpm.database.jdbc-batch-processing}") private Boolean  jdbcBatchProcessing;
	
	
	/*ONLY FOR LOCAL CAMUNDA DATA SOURCE*/
	@Bean
	@Primary
	public DataSource dataSource() {
		logger.debug("SETUP DATABASE DATA SOURCE FOR COMET CAMUNDA", this);
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		return dataSource;
	}
	
	
	/*ONLY FOR LOCAL COMET DATA SOURCE*/
	@Bean
	public DataSource dataSourceComet() {
		logger.debug("SETUP DATABASE DATA SOURCE FOR COMET ", this);
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(cometdriverClassName);
		dataSource.setUrl(cometUrl);
		dataSource.setUsername(cometUsername);
		dataSource.setPassword(cometPassword);
		return dataSource;
	}
	
	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		logger.debug("LOADING ENTITIY OBJECT FOR COMET DATA SOURCE ", this);
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setDatabase(Database.ORACLE);
		// vendorAdapter.setGenerateDdl(true);

		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSourceComet());
		em.setPackagesToScan("com.att.comet.bpm.common.hibernate.bean");
		em.setJpaVendorAdapter(vendorAdapter);
		return em;
	}	
	
	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		logger.debug("ESTABLISH ENTITIY OBJECT FOR COMET DATA SOURCE  FOR JPA", this);
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);
		return transactionManager;
	}
	 

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	 public PlatformTransactionManager transactionManager() {
	    return new DataSourceTransactionManager(dataSource());
	  }
	
	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return new JpaTransactionManager();
	}

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

	@Bean
	public SpringProcessEngineConfiguration engineConfiguration(DataSource dataSource,
			PlatformTransactionManager transactionManager,
			@Value("classpath*:bpmn/**/*.bpmn") Resource[] deploymentResources) {
		
		logger.debug("LOADNG ALL BPMN CAMUNDA FILE", this);
		SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();

		configuration.setProcessEngineName("engine");
		////CAMUNDA DATA SOURCE configure////////
		configuration.setDataSource(dataSource());
		configuration.setTransactionManager(transactionManager);
		configuration.setDatabaseSchemaUpdate("true");
		configuration.setJobExecutorActivate(true);
     	configuration.setJobExecutorDeploymentAware(true);
		configuration.setJdbcBatchProcessing(false);
		configuration.setDeploymentResources(deploymentResources);
		configuration.setDeploymentName("bpmService");
		configuration.setHistory(historyLevel);
		return configuration;

	}

	@Bean
	public ProcessEngineFactoryBean engineFactory(SpringProcessEngineConfiguration engineConfiguration) {
		logger.debug("ESTABLISHING CAMUNDA ENGINE", this);
		ProcessEngineFactoryBean factoryBean = new ProcessEngineFactoryBean();
		factoryBean.setProcessEngineConfiguration(engineConfiguration);
		return factoryBean;
	}

	@Bean
	public ProcessEngine processEngine(ProcessEngineFactoryBean factoryBean) throws Exception {
		logger.debug("LOADING CAMUNDA ENGINE", this);
		return factoryBean.getObject();
	}

	@Bean
	public RepositoryService repositoryService(ProcessEngine processEngine) {
		logger.debug("LOADING COMET REPOSITORY SERVICE", this);
		return processEngine.getRepositoryService();
	}

	@Bean
	public RuntimeService runtimeService(ProcessEngine processEngine) {
		return processEngine.getRuntimeService();
	}

	@Bean
	public TaskService taskService(ProcessEngine processEngine) {
		return processEngine.getTaskService();
	}

	@Bean
	@Primary
	public HistoryService historyService(ProcessEngine processEngine) {
		return processEngine.getHistoryService();
	}

	@Bean
	public ManagementService managementService(ProcessEngine processEngine) {
		return processEngine.getManagementService();
	}
}
