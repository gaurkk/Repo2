package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;



/**
 * APN persistent class. Mapped to APN table in the database.
 */
@Entity
@Table(name = "APN")
public class Apn implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private Long orderId;
	private Orders orders;
	private String apnName;
	private String socFeatureCode;
	private String ipAddressSource;
	private String addressType;
	private Character radAccServEnabled;
	private Long uniqueIpAddressSize;
	private Long totalMobilePoolSize;
	private Character mobileToMobileEnabled;
	private Character mobileTerminationEnabled;
	private Character mobileOriginateEnabled;
	private Character splitTunnelIntEnabled;
	private Character splitTunnelMtEnabled;
	private String amplifyingInformation;
	private String provisioningMethod;
	private Character fwdRadReqAuthEnabled;
	private Character fwdRadReqMsgEnabled;
	private String dnsServerIp;
	private String domainName;
	private Character migratedOrder = 'N';
	private Set<MobilePoolAddress> mobilePoolAddresses = new HashSet<MobilePoolAddress>(0);
	private Set<PatPoolAddress> patPoolAddresses = new HashSet<PatPoolAddress>(0);
	private Set<EnterpriseDnsServer> enterPriseDnsServerAddresses = new HashSet<EnterpriseDnsServer>(0);
	//Req#6.2.01 sp3599
	private Set<ApnHealthChkCustDestnIp> apnHealthChkCustDestnIps = new HashSet<ApnHealthChkCustDestnIp>(0);
	private Set<ImsiDataCenterDetails> imsiDcDetails = new HashSet<ImsiDataCenterDetails>(0);


	private Set<PersistentIp> persistentIps = new HashSet<PersistentIp>(0);
	private Set<PdpIdInfo> pdpIdInfos = new HashSet<PdpIdInfo>(0);
	private Set<SplitTunnelIpRange> splitTunnelIpRanges = new HashSet<SplitTunnelIpRange>(0);
	private Set<EntTargetIpRange> entTargetIpRanges = new LinkedHashSet<EntTargetIpRange>(0);
	private Set<ApnRadius> apnRadiuses = new HashSet<ApnRadius>(0);
	private Character overRide;
	private Character overRidePdp;
	private String mobilePoolType;
	private Character managedAvpn;
	private Character ipbrFlag = 'N';
	private Character ocs;
	// For INSTAR
	private String ccsVRFName;
	private Character msp;
	private String whitelistBlacklist;
	
	private String pcrf;
	
	private Character splitAccessPAT; 
	private Set<IntTargetIpRange> intTargetIpRanges = new LinkedHashSet<IntTargetIpRange>(0);
	private Character geoOptimization; 
	private String insideOusideStgPat;
	private Character ccipRadius;
	private Character mspEntAndMms;
	private String apnProtocol;
	private Character firstNet;
	private Character turboAppSupport;
	private Character dscpPreservation;
	private Character interimUpdate = 'N';
	private String authenticationType;
	private String hostedRadiusType;
	private String interimUpdateValue;
	private Character ccsmx;	
	private ApnHealthCheck apnHealthCheck = new ApnHealthCheck();//Added For Req#6.2.01 sp3599
	private Character noFirewall;
	private Character overRideCcsMx;
	private Character pacl = 'N';
	private Character PaclEnabled;
	
	/**
	 * No-argument constructor.
	 */
	public Apn() {
	}

	/**
	 * Single argument constructor.
	 * 
	 * @param orders
	 */
	public Apn(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for the OrderId ORDER_ID mapped to ORDER_ID column if the table in database.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for the Orders.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for apnName. APN_NAME mapped to APN_NAME column of the table in the database.
	 * 
	 * @return String
	 */
	@Column(name = "APN_NAME", length = 100)
	public String getApnName() {
		return this.apnName;
	}

	/**
	 * @param apnName
	 *            to apnName set.
	 */
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	/**
	 * Getter method for socFeatureCode. SOC_FEATURE_CODE mapped to SOC_FEATURE_CODE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SOC_FEATURE_CODE", length = 12)
	public String getSocFeatureCode() {
		return this.socFeatureCode;
	}

	/**
	 * @param socFeatureCode
	 *            to socFeatureCode set.
	 */
	public void setSocFeatureCode(String socFeatureCode) {
		this.socFeatureCode = socFeatureCode;
	}

	/**
	 * Getter method for ipAddressSource. IP_ADDRESS_SOURCE mapped to IP_ADDRESS_SOURCE in database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS_SOURCE", length = 100)
	public String getIpAddressSource() {
		return this.ipAddressSource;
	}

	/**
	 * @param ipAddressSource
	 *            to ipAddressSource set.
	 */
	public void setIpAddressSource(String ipAddressSource) {
		this.ipAddressSource = ipAddressSource;
	}

	/**
	 * Getter method for the addressType. ADDRESS_TYPE mapped to ADDRESS_TYPE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ADDRESS_TYPE", length = 100)
	public String getAddressType() {
		return this.addressType;
	}

	/**
	 * @param addressType
	 *            to addressType set.
	 */
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	/**
	 * Getter method for the radAccServEnabled RAD_ACC_SERV_ENABLED mapped to RAD_ACC_SERV_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "RAD_ACC_SERV_ENABLED", length = 1)
	public Character getRadAccServEnabled() {
		return this.radAccServEnabled;
	}

	/**
	 * @param radAccServEnabled
	 *            to radAccServEnabled set.
	 */
	public void setRadAccServEnabled(Character radAccServEnabled) {
		this.radAccServEnabled = radAccServEnabled;
	}

	/**
	 * Getter method for the UniqueIpAddressSize. UNIQUE_IP_ADDRESS_SIZE mapped to UNIQUE_IP_ADDRESS_SIZE in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "UNIQUE_IP_ADDRESS_SIZE", precision = 12, scale = 0)
	public Long getUniqueIpAddressSize() {
		return this.uniqueIpAddressSize;
	}

	/**
	 * @param uniqueIpAddressSize
	 *            to uniqueIpAddressSize set.
	 */
	public void setUniqueIpAddressSize(Long uniqueIpAddressSize) {
		this.uniqueIpAddressSize = uniqueIpAddressSize;
	}

	/**
	 * Getter method for the totalMobilePoolSize. TOTAL_MOBILE_POOL_SIZE mapped to TOTAL_MOBILE_POOL_SIZE in database table.
	 * 
	 * @return Long
	 */
	@Column(name = "TOTAL_MOBILE_POOL_SIZE", precision = 12, scale = 0)
	public Long getTotalMobilePoolSize() {
		return this.totalMobilePoolSize;
	}

	/**
	 * @param totalMobilePoolSize
	 *            to totalMobilePoolSize set.
	 */
	public void setTotalMobilePoolSize(Long totalMobilePoolSize) {
		this.totalMobilePoolSize = totalMobilePoolSize;
	}

	/**
	 * Getter method for the mobileToMobileEnabled. MOBILE_TO_MOBILE_ENABLED mapped to MOBILE_TO_MOBILE_ENABLED in the database table.
	 * 
	 * @return Character.
	 */
	@Column(name = "MOBILE_TO_MOBILE_ENABLED", length = 1)
	public Character getMobileToMobileEnabled() {
		return this.mobileToMobileEnabled;
	}

	/**
	 * @param mobileToMobileEnabled
	 *            to mobileToMobileEnabled set.
	 */
	public void setMobileToMobileEnabled(Character mobileToMobileEnabled) {
		this.mobileToMobileEnabled = mobileToMobileEnabled;
	}

	/**
	 * Getter method for the mobileTerminationEnabled. MOBILE_TERMINATION_ENABLED mapped to MOBILE_TERMINATION_ENABLED in the database
	 * table.
	 * 
	 * @return Character.
	 */
	@Column(name = "MOBILE_TERMINATION_ENABLED", length = 1)
	public Character getMobileTerminationEnabled() {
		return this.mobileTerminationEnabled;
	}

	/**
	 * @param mobileTerminationEnabled
	 *            to mobileTerminationEnabled set.
	 */
	public void setMobileTerminationEnabled(Character mobileTerminationEnabled) {
		this.mobileTerminationEnabled = mobileTerminationEnabled;
	}
	
	@Column(name = "MOBILE_ORIGINATE_ENABLED", length = 1)
	/**
	 * @return the mobileOriginateEnabled
	 */
	public Character getMobileOriginateEnabled() {
		return mobileOriginateEnabled;
	}

	/**
	 * @param mobileOriginateEnabled the mobileOriginateEnabled to set
	 */
	public void setMobileOriginateEnabled(Character mobileOriginateEnabled) {
		this.mobileOriginateEnabled = mobileOriginateEnabled;
	}

	/**
	 * Getter method for splitTunnelIntEnabled. SPLIT_TUNNEL_INT_ENABLED mapped to SPLIT_TUNNEL_INT_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "SPLIT_TUNNEL_INT_ENABLED", length = 1)
	public Character getSplitTunnelIntEnabled() {
		return this.splitTunnelIntEnabled;
	}

	/**
	 * @param splitTunnelIntEnabled
	 *            to splitTunnelIntEnabled set.
	 */
	public void setSplitTunnelIntEnabled(Character splitTunnelIntEnabled) {
		this.splitTunnelIntEnabled = splitTunnelIntEnabled;
	}

	/**
	 * Getter method for splitTunnelMtEnabled. SPLIT_TUNNEL_MT_ENABLED mapped to SPLIT_TUNNEL_MT_ENABLED in database table
	 * 
	 * @return Character
	 */
	@Column(name = "SPLIT_TUNNEL_MT_ENABLED", length = 1)
	public Character getSplitTunnelMtEnabled() {
		return this.splitTunnelMtEnabled;
	}

	/**
	 * @param splitTunnelMtEnabled
	 *            to splitTunnelMtEnabled set.
	 */
	public void setSplitTunnelMtEnabled(Character splitTunnelMtEnabled) {
		this.splitTunnelMtEnabled = splitTunnelMtEnabled;
	}

	/**
	 * Getter method for amplifyingInformation. AMPLIFYING_INFORMATION mapped to AMPLIFYING_INFORMATION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AMPLIFYING_INFORMATION", length = 3500)
	public String getAmplifyingInformation() {
		return this.amplifyingInformation;
	}

	/**
	 * @param amplifyingInformation
	 *            to amplifyingInformation set.
	 */
	public void setAmplifyingInformation(String amplifyingInformation) {
		this.amplifyingInformation = amplifyingInformation;
	}

	/**
	 * Getter method for provisioningMethod. PROVISIONING_METHOD mapped to PROVISIONING_METHOD in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PROVISIONING_METHOD", length = 100)
	public String getProvisioningMethod() {
		return this.provisioningMethod;
	}

	/**
	 * @param provisioningMethod
	 *            to provisioningMethod set.
	 */
	public void setProvisioningMethod(String provisioningMethod) {
		this.provisioningMethod = provisioningMethod;
	}

	/**
	 * Getter method for fwdRadReqAuthEnabled. FWD_RAD_REQ_AUTH_ENABLED mapped to FWD_RAD_REQ_AUTH_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FWD_RAD_REQ_AUTH_ENABLED", length = 1)
	public Character getFwdRadReqAuthEnabled() {
		return this.fwdRadReqAuthEnabled;
	}

	/**
	 * @param fwdRadReqAuthEnabled
	 *            to fwdRadReqAuthEnabled set.
	 */
	public void setFwdRadReqAuthEnabled(Character fwdRadReqAuthEnabled) {
		this.fwdRadReqAuthEnabled = fwdRadReqAuthEnabled;
	}

	/**
	 * Getter method for fwdRadReqMsgEnabled. FWD_RAD_REQ_MSG_ENABLED mapped to FWD_RAD_REQ_MSG_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FWD_RAD_REQ_MSG_ENABLED", length = 1)
	public Character getFwdRadReqMsgEnabled() {
		return this.fwdRadReqMsgEnabled;
	}

	/**
	 * @param fwdRadReqMsgEnabled
	 *            to fwdRadReqMsgEnabled set.
	 */
	public void setFwdRadReqMsgEnabled(Character fwdRadReqMsgEnabled) {
		this.fwdRadReqMsgEnabled = fwdRadReqMsgEnabled;
	}

	/**
	 * Getter method for dnsServerIp. DNS_SERVER_IP mapped to DNS_SERVER_IP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DNS_SERVER_IP", length = 100)
	public String getDnsServerIp() {
		return this.dnsServerIp;
	}

	/**
	 * @param dnsServerIp
	 *            to dnsServerIp set.
	 */
	public void setDnsServerIp(String dnsServerIp) {
		this.dnsServerIp = dnsServerIp;
	}

	/**
	 * Getter method for domainName. DOMAIN_NAME mapped to DOMAIN_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DOMAIN_NAME", length = 30)
	public String getDomainName() {
		return this.domainName;
	}

	/**
	 * @param domainName
	 *            to domainName set.
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * Getter method for migratedOrder. MIGRATED_ORDER mapped to MIGRATED_ORDER in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "MIGRATED_ORDER", length = 100)
	public Character getMigratedOrder() {
		return this.migratedOrder;
	}

	/**
	 * @param migratedOrder
	 *            to migratedOrder set.
	 */
	public void setMigratedOrder(Character migratedOrder) {
		this.migratedOrder = migratedOrder;
	}

	/**
	 * Getter method for the mobilePoolAddress.
	 * 
	 * @return Set<MobilePoolAddress>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<MobilePoolAddress> getMobilePoolAddresses() {
		return this.mobilePoolAddresses;
	}

	/**
	 * @param mobilePoolAddresses
	 *            to mobilePoolAddresses set.
	 */
	public void setMobilePoolAddresses(Set<MobilePoolAddress> mobilePoolAddresses) {
		this.mobilePoolAddresses = mobilePoolAddresses;
	}

	/**
	 * Getter method for the patPoolAddress.
	 * 
	 * @return Set<PatPoolAddresses>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<PatPoolAddress> getPatPoolAddresses() {
		return this.patPoolAddresses;
	}

	/**
	 * @param patPoolAddresses
	 *            to patPoolAddresses set.
	 */
	public void setPatPoolAddresses(Set<PatPoolAddress> patPoolAddresses) {
		this.patPoolAddresses = patPoolAddresses;
	}

	/**
	 * Getting method for persistentIps.
	 * 
	 * @return Set<PersistentIp>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<PersistentIp> getPersistentIps() {
		return this.persistentIps;
	}

	/**
	 * @param persistentIps
	 *            to persistentIps set.
	 */
	public void setPersistentIps(Set<PersistentIp> persistentIps) {
		this.persistentIps = persistentIps;
	}

	/**
	 * Getter method for pdpIdInfos.
	 * 
	 * @return Set<PdpIdInfo>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<PdpIdInfo> getPdpIdInfos() {
		return this.pdpIdInfos;
	}

	/**
	 * @param pdpIdInfos
	 *            to pdpIdInfos set.
	 */
	public void setPdpIdInfos(Set<PdpIdInfo> pdpIdInfos) {
		this.pdpIdInfos = pdpIdInfos;
	}

	/**
	 * Getter method for splitTunnelIpRanges
	 * 
	 * @return Set<SplitTunnelIpRange>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<SplitTunnelIpRange> getSplitTunnelIpRanges() {
		return this.splitTunnelIpRanges;
	}

	/**
	 * @param splitTunnelIpRanges
	 *            to splitTunnelIpRanges set.
	 */
	public void setSplitTunnelIpRanges(Set<SplitTunnelIpRange> splitTunnelIpRanges) {
		this.splitTunnelIpRanges = splitTunnelIpRanges;
	}

	/**
	 * Getter method for entTargetIpRanges.
	 * 
	 * @return Set<EntTargetIpRange>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<EntTargetIpRange> getEntTargetIpRanges() {
		return this.entTargetIpRanges;
	}

	/**
	 * @param entTargetIpRanges
	 *            to entTargetIpRanges set.
	 */
	public void setEntTargetIpRanges(Set<EntTargetIpRange> entTargetIpRanges) {
		this.entTargetIpRanges = entTargetIpRanges;
	}

	/**
	 * Getter method for apnRadiuses
	 * 
	 * @return Set<ApnRadius>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<ApnRadius> getApnRadiuses() {
		return this.apnRadiuses;
	}

	/**
	 * @param apnRadiuses
	 *            to apnRadiuses
	 */
	public void setApnRadiuses(Set<ApnRadius> apnRadiuses) {
		this.apnRadiuses = apnRadiuses;
	}
	



	/**
	 * Getter method for overRide. OVERRIDE mapped to OVERRIDE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "OVERRIDE", length = 1)
	public Character getOverRide() {
		return overRide;
	}

	/**
	 * @param overRide
	 *            to overRide set.
	 */
	public void setOverRide(Character overRide) {
		this.overRide = overRide;
	}

	/**
	 * Getter method for overRidePdp. OVERRIDE_PDP mapped to OVERRIDE_PDP in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "OVERRIDE_PDP", length = 1)
	public Character getOverRidePdp() {
		return overRidePdp;
	}

	/**
	 * @param overRidePdp
	 *            to overRidePdp set.
	 */
	public void setOverRidePdp(Character overRidePdp) {
		this.overRidePdp = overRidePdp;
	}

	/**
	 * Getter method for mobilePoolType MOBILE_POOL_TYPE mapped to MOBILE_POOL_TYPE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MOBILE_POOL_TYPE", length = 100)
	public String getMobilePoolType() {
		return mobilePoolType;
	}

	/**
	 * @param mobilePoolType
	 *            the mobilePoolType to set
	 */
	public void setMobilePoolType(String mobilePoolType) {
		this.mobilePoolType = mobilePoolType;
	}

	/**
	 * Getter method for ccsVRFName. CCS_VRF_NAME mapped to CCS_VRF_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CCS_VRF_NAME", length = 100)
	public String getCcsVRFName() {
		return ccsVRFName;
	}

	/**
	 * @param ccsVRFName
	 *            to ccsVRFName set.
	 */
	public void setCcsVRFName(String ccsVRFName) {
		this.ccsVRFName = ccsVRFName;
	

	}

	/**
	 * @return the managedAvpn
	 */
	@Column(name = "MANAGED_AVPN", length = 1)
	public Character getManagedAvpn() {
		return managedAvpn;
	}

	/**
	 * @param managedAvpn
	 *            the managedAvpn to set
	 */
	public void setManagedAvpn(Character managedAvpn) {
		this.managedAvpn = managedAvpn;
	}

	/**
	 * @return the enterPriseDnsServerAddresses
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<EnterpriseDnsServer> getEnterPriseDnsServerAddresses() {
		return enterPriseDnsServerAddresses;
	}

	/**
	 * @param enterPriseDnsServerAddresses
	 *            the enterPriseDnsServerAddresses to set
	 */
	public void setEnterPriseDnsServerAddresses(Set<EnterpriseDnsServer> enterPriseDnsServerAddresses) {
		this.enterPriseDnsServerAddresses = enterPriseDnsServerAddresses;
	}

	

	/**
	 * Getter method for PMIP in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "IPBR", length = 1)
	public Character getIpbrFlag() {
		return ipbrFlag;
	}

	/**
	 * PMIP
	 * @param ipbrFlag
	 */
	public void setIpbrFlag(Character ipbrFlag) {
		this.ipbrFlag = ipbrFlag;
	}

	/**
	 * @return the getMsp
	 * Character
	 */
	@Column(name = "MSP", length = 1)
	public Character getMsp() {
		return msp;
	}

	/**
	 * msp
	 * @param msp
	 */
	public void setMsp(Character msp) {
		this.msp = msp;
	}

	/**
	 * Getter method for whitelistBlacklist. 
	 * 
	 * @return String
	 */
	@Column(name = "WHITELIST_BLACKLIST", length = 100)
	public String getWhitelistBlacklist() {
		return whitelistBlacklist;
	}

	/**
	 * @param WhitelistBlacklist
	 *            the WhitelistBlacklist to set
	 */
	public void setWhitelistBlacklist(String whitelistBlacklist) {
		this.whitelistBlacklist = whitelistBlacklist;
	}
	
	/**
	 * Getter method for column pcrf
	 * 
	 * @return
	 */
	@Column(name = "PCRF", length = 50)
	public String getPcrf() {
		return pcrf;
	}

	public void setPcrf(String pcrf) {
		this.pcrf = pcrf;
	}

	/**
	 * @return the splitAccessPAT
	 */
	@Column(name = "SPLIT_ACC_PAT", length = 1)
	public Character getSplitAccessPAT() {
		return splitAccessPAT;
	}

	/**
	 * @param splitAccessPAT
	 *            the splitAccessPAT to set
	 */
	public void setSplitAccessPAT(Character splitAccessPAT) {
		this.splitAccessPAT = splitAccessPAT;
	}

	/**
	 * @return the intTargetIpRanges
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<IntTargetIpRange> getIntTargetIpRanges() {
		return intTargetIpRanges;
	}

	/**
	 * @param intTargetIpRanges
	 *            the intTargetIpRanges to set
	 */
	public void setIntTargetIpRanges(Set<IntTargetIpRange> intTargetIpRanges) {
		this.intTargetIpRanges = intTargetIpRanges;
	}

	/**
	 * @return the geoOptimizationEnabled
	 */
	@Column(name = "GEO_OPTIMIZATION", length = 1)
	public Character getGeoOptimization() {
		return geoOptimization;
	}

	/**
	 * @param geoOptimization
	 *            the geoOptimization to set
	 */
	public void setGeoOptimization(Character geoOptimization) {
		this.geoOptimization = geoOptimization;
	}

	/**
	 * @return the insideOusideStgPat
	 */
	@Column(name = "INSIDE_OUTSIDE", length = 100)
	public String getInsideOusideStgPat() {
		return insideOusideStgPat;
	}

	/**
	 * @param insideOusideStgPat
	 *            the insideOusideStgPat to set
	 */
	public void setInsideOusideStgPat(String insideOusideStgPat) {
		this.insideOusideStgPat = insideOusideStgPat;
	}
	
	/**
	 * @return the ccipRadius
	 */
	@Column(name = "CCIP_RADIUS", length = 1)
	public Character getCcipRadius() {
		return ccipRadius;
	}

	/**
	 * @param ccipRadius
	 *            the ccipRadius to set
	 */
	public void setCcipRadius(Character ccipradius) {
		this.ccipRadius = ccipradius;
	}
	
	@Column(name = "MSP_ENTITLEMENT_AND_MMS", length = 1)
	public Character getMspEntAndMms() {
		return mspEntAndMms;
	}

	public void setMspEntAndMms(Character mspEntAndMms) {
		this.mspEntAndMms = mspEntAndMms;
	}

	/**
	 * @return the ocs
	 */
	public Character getOcs() {
		return ocs;
	}

	/**
	 * @param ocs the ocs to set
	 */
	public void setOcs(Character ocs) {
		this.ocs = ocs;
	}

	@Column(name = "APN_PROTOCOL", length = 20)
	public String getApnProtocol() {
		return apnProtocol;
	}

	public void setApnProtocol(String apnProtocol) {
		this.apnProtocol = apnProtocol;
	}

	@Column(name = "FIRST_NET", length = 1)
	public Character getFirstNet() {
		return firstNet;
	}
	
	public void setFirstNet(Character firstNet) {
		this.firstNet = firstNet;
	}
	
	@Column(name = "TURBO_APP_SUPPORT", length = 1)
	public Character getTurboAppSupport() {
		return turboAppSupport;
	}
	
	public void setTurboAppSupport(Character turboAppSupport) {
		this.turboAppSupport = turboAppSupport;
	}

	@Column(name = "DSCP_PRESERVATION", length = 1)
	public Character getDscpPreservation() {
		return dscpPreservation;
	}
	
	public void setDscpPreservation(Character dscpPreservation) {
		this.dscpPreservation = dscpPreservation;
	}
	
	@Column(name = "INTERIM_UPDATE", length = 1)
	public Character getInterimUpdate() {
		return interimUpdate;
	}

	public void setInterimUpdate(Character interimUpdate) {
		this.interimUpdate = interimUpdate;
	}

	@Column(name = "AUTHENTICATION_TYPE", length = 25)
	public String getAuthenticationType() {
		return authenticationType;
	}

	public void setAuthenticationType(String authenticationType) {
		this.authenticationType = authenticationType;
	}
	@Column(name = "HOSTED_RADIUS_TYPE", length = 25)
	public String getHostedRadiusType() {
		return hostedRadiusType;
	}
	
	public void setHostedRadiusType(String hostedRadiusType) {
		this.hostedRadiusType = hostedRadiusType;
	}
	
	/**
	 * Getter method for CCS-MX in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ccsmx", length = 1)
	public Character getCcsmx() {
		return ccsmx;
	}

	/**
	 * routing behind IP
	 * @param XXS-MX
	 */
	public void setCcsmx(Character ccsmx) {
		this.ccsmx = ccsmx;
	}
	
	@Column(name = "INTERIM_UPDATE_VALUE", length = 25)
	public String getInterimUpdateValue() {
		return interimUpdateValue;
	}

	public void setInterimUpdateValue(String interimUpdateValue) {
		this.interimUpdateValue = interimUpdateValue;
	}
	
	//Start : Added For Req#6.2.01 sp3599
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "apn", cascade = CascadeType.ALL)
	public ApnHealthCheck getApnHealthCheck() {
		return apnHealthCheck;
	}

	public void setApnHealthCheck(ApnHealthCheck apnHelthCheck) {
		this.apnHealthCheck = apnHelthCheck;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<ApnHealthChkCustDestnIp> getApnHealthChkCustDestnIps() {
		return apnHealthChkCustDestnIps;
	}

	public void setApnHealthChkCustDestnIps(
			Set<ApnHealthChkCustDestnIp> apnHealthChkCustDestnIps) {
		this.apnHealthChkCustDestnIps = apnHealthChkCustDestnIps;
	}
	//End : Added For Req#6.2.01 sp3599
	@Column(name = "NO_FIREWALL")
	public Character getNoFirewall() {
		return noFirewall;
	}

	public void setNoFirewall(Character noFirewall) {
		this.noFirewall = noFirewall;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apn")
	public Set<ImsiDataCenterDetails> getImsiDcDetails() {
		return imsiDcDetails;
	}

	public void setImsiDcDetails(Set<ImsiDataCenterDetails> imsiDcDetails) {
		this.imsiDcDetails = imsiDcDetails;
	}
	/**
	 * 
	 * 
	 * @return Character
	 */
	@Column(name = "OVERRIDE_CCSMX", length = 1)
	public Character getOverRideCcsMx() {
		return overRideCcsMx;
	}

	/**
	 * @param overRideCcsMx the overRideCcsMx to set
	 */
	public void setOverRideCcsMx(Character overRideCcsMx) {
		this.overRideCcsMx = overRideCcsMx;
	}
	
	@Column(name = "PACL", length = 1)
	public Character getPacl() {
		return pacl;
	}

	public void setPacl(Character pacl) {
		this.pacl = pacl;
	}

	@Column(name = "OPTOUT_PACL", length = 1)
	public Character getPaclEnabled() {
		return PaclEnabled;
	}

	public void setPaclEnabled(Character PaclEnabled) {
		this.PaclEnabled = PaclEnabled;
	}
}