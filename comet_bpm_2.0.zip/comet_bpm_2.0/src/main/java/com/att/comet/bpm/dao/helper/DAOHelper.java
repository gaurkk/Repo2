package com.att.comet.bpm.dao.helper;

import java.util.List;

import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class DAOHelper {

	public void backHaulIdList(List<String> backhaulIdList, CommonBO commonBO) {
		StringBuilder backhaulIds = new StringBuilder("");
		if (backhaulIdList.size() > 0) {
			for (String backhaulId : backhaulIdList) {
				backhaulIds.append(backhaulId + "").append(",");
			}
			String backhaulIdsList = backhaulIds.toString();
			if (backhaulIdsList.length() > 0)
				backhaulIdsList = backhaulIdsList.substring(0, backhaulIdsList.length() - 1);
			commonBO.setBackHaulIds(backhaulIdsList);

		} else {
			commonBO.setBackHaulIds("N/A");
		}
	}
}
