package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "bpm_order_expedite")
@Data
public class BpmOrderExpedite {
	@Id
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long orderId;
	@Column(name = "EXPEDITE_PROCESS_STATUS", length = 20)
	private String expediteProcessStatus;
	@Column(name = "APN_IWOS_CREATION_STATUS", length = 20)
	private String apnIwosCreationStatus;
}
