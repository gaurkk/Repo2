package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.OrderDataCenterBackhaul;
import com.att.comet.bpm.common.hibernate.bean.OrderDataCenterBackhaulId;


@Repository
public interface OrderDataCenterBackhaulRepository
		extends JpaRepository<OrderDataCenterBackhaul, OrderDataCenterBackhaulId> {
	@Query(value = "select backhaul.backhaulDisplayId from OrderDataCenterBackhaul odc where odc.orders.orderId=:orderId")
	List<String> getBackhaulIds(Long orderId);
}
