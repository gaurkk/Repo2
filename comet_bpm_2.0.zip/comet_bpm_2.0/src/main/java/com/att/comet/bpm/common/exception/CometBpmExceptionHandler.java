package com.att.comet.bpm.common.exception;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;

@Controller
@ControllerAdvice
public class CometBpmExceptionHandler {
	private String INCORRECT_REQUEST = "INCORRECT_REQUEST";

	@ExceptionHandler(CometAppRequestException.class)
	public final ResponseEntity<ErrorResponse> cometAppRequestException(CometAppRequestException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(BpmErrorCodeConstant.COMET_MB001, BpmErrorCodeConstant.FAILURE, new Date(),
				INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(NewOrderDelegateException.class)
	public final ResponseEntity<ErrorResponse> newOrderDelegateException(NewOrderDelegateException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(BpmErrorCodeConstant.COMET_NEW_OR001, BpmErrorCodeConstant.FAILURE,
				new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleOMApprovalDelegateException(RecordNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(BpmErrorCodeConstant.COMET_ANNOUNCEMENT_NTF, BpmErrorCodeConstant.FAILURE,
				new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(BPMInvalidRequestException.class)
	public final ResponseEntity<ErrorResponse> handleBpmInvalidRequestException(BPMInvalidRequestException ex,WebRequest request){
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(BpmErrorCodeConstant.COMET_001, BpmErrorCodeConstant.FAILURE,
				new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(CamundaServiceException.class)
	public final ResponseEntity<ErrorResponse> handleCamundaServiceException(CamundaServiceException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(BpmErrorCodeConstant.COMET_INVALID_REQUEST, BpmErrorCodeConstant.FAILURE,
				new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	
}
