package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for Users. Mapped to USERS table in the database.
 */
@Entity
@Table(name = "USERS")
public class Users implements Serializable {

	private static final long serialVersionUID = 4376436761226567786L;

	private String attuid;
	private State state;
	private City city;
	private Country country;
	private String firstName;
	private String lastName;
	private String cellPhone;
	private Character active;
	private String deskPhone;
	private String email;
	private String streetAddress;
	private String zipCode;
	private String purpose;
	private Set<UserRole> userRoles = new HashSet<UserRole>(0);
	private Set<OrderContactInfo> orderContactInfos = new HashSet<OrderContactInfo>(
			0);
	private String deskPhoneExtention;

	/**
	 * Getter method for deskPhoneExtention. DESK_PHONE_EXTENTION mapped to
	 * DESK_PHONE_EXTENTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DESK_PHONE_EXTENTION", length = 6)
	public String getDeskPhoneExtention() {
		return deskPhoneExtention;
	}

	/**
	 * @param deskPhoneExtention
	 *            to deskPhoneExtention set.
	 */
	public void setDeskPhoneExtention(String deskPhoneExtention) {
		this.deskPhoneExtention = deskPhoneExtention;
	}

	/**
	 * Getter method for attuid. ATTUID mapped to ATTUID in the database table.
	 * 
	 * @return String
	 */
	@Id
	@Column(name = "ATTUID", unique = true, nullable = false, length = 6)
	public String getAttuid() {
		return this.attuid;
	}

	/**
	 * @param attuid
	 *            to attuid set.
	 */
	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	/**
	 * Getter method for state.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATE_ID")
	public State getState() {
		return this.state;
	}

	/**
	 * @param state
	 *            to state set.
	 */
	public void setState(State state) {
		this.state = state;
	}

	/**
	 * Getter method for city.
	 * 
	 * @return City
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CITY_ID")
	public City getCity() {
		return this.city;
	}

	/**
	 * @param city
	 *            to city set.
	 */
	public void setCity(City city) {
		this.city = city;
	}

	/**
	 * Getter method for country.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COUNTRY_ID")
	public Country getCountry() {
		return this.country;
	}

	/**
	 * @param country
	 *            to country set.
	 */
	public void setCountry(Country country) {
		this.country = country;
	}

	/**
	 * Getter method for firstname. FIRSTNAME mapped to FIRSTNAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "FIRSTNAME", nullable = false, length = 20)
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * @param firstname
	 *            to firstname set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Getter method for lastname. LASTNAME mapped to LASTNAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "LASTNAME", nullable = false, length = 20)
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * @param lastname
	 *            to lastname set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Getter method for cellPhone. CELL_PHONE mapped to CELL_PHONE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "CELL_PHONE", length = 10)
	public String getCellPhone() {
		return this.cellPhone;
	}

	/**
	 * @param cellPhone
	 *            to cellPhone set.
	 */
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	/**
	 * Getter method for active. ACTIVE mapped to ACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ACTIVE", nullable = false, length = 1)
	public Character getActive() {
		return this.active;
	}

	/**
	 * @param active
	 *            to active set.
	 */
	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for deskPhone. DESK_PHONE mapped to DESK_PHONE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "DESK_PHONE", length = 100)
	public String getDeskPhone() {
		return this.deskPhone;
	}

	/**
	 * @param deskPhone
	 *            to deskPhone set.
	 */
	public void setDeskPhone(String deskPhone) {
		this.deskPhone = deskPhone;
	}

	/**
	 * Getter method for email. EMAIL mapped to EMAIL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EMAIL", length = 100)
	public String getEmail() {
		return this.email;
	}

	/**
	 * @param email
	 *            to email set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Getter method for streetAddress. STREET_ADDRESS mapped to STREET_ADDRESS
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "STREET_ADDRESS", length = 100)
	public String getStreetAddress() {
		return this.streetAddress;
	}

	/**
	 * @param streetAddress
	 *            to streetAddress set.
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	/**
	 * Getter method for zipCode. ZIP_CODE mapped to ZIP_CODE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ZIP_CODE", length = 100)
	public String getZipCode() {
		return this.zipCode;
	}

	/**
	 * @param zipCode
	 *            to zipCode set.
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * Getter method for userRoles.
	 * 
	 * @return Set<UserRole>
	 */
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "users")
	public Set<UserRole> getUserRoles() {
		return this.userRoles;
	}

	/**
	 * @param userRoles
	 *            to userRoles set.
	 */
	public void setUserRoles(Set<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

	/**
	 * Getter method for orderContactInfos.
	 * 
	 * @return Set<OrderContactInfo>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "users")
	public Set<OrderContactInfo> getOrderContactInfos() {
		return this.orderContactInfos;
	}

	/**
	 * @param orderContactInfos
	 *            to orderContactInfos set.
	 */
	public void setOrderContactInfos(Set<OrderContactInfo> orderContactInfos) {
		this.orderContactInfos = orderContactInfos;
	}

	/**
	 * Getter method for purpose. PURPOSE mapped to PURPOSE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "PURPOSE", length = 3500)
	public String getPurpose() {
		return purpose;
	}

	/**
	 * @param purpose
	 *            to purpose set.
	 */
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
}