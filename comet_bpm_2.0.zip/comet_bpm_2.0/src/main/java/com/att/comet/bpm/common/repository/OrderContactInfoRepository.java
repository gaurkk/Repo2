package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.OrderContactInfo;
import com.att.comet.bpm.common.hibernate.bean.OrderContactInfoId;

@Repository
public interface OrderContactInfoRepository extends JpaRepository<OrderContactInfo, OrderContactInfoId> {

	@Query(value = "select usr.attuid,usr.firstName,usr.lastName from OrderContactInfo oci join oci.orderContact oc join oci.users usr where oc.orders.orderId=:orderId and usr.active=:active and oci.id.orderContactTypeId=:orderContactTypeId")
	List<Object[]> getATTUIDFirstNameLastName(Long orderId, Character active,Long orderContactTypeId);
	
	@Query(value = "select  usr.attuid from OrderContactInfo oci join oci.users usr where oci.orderContact.orders.orderId=:orderId and oci.orderContactType.orderContactTypeId=:orderContactTypeId")
	List<String> getOrderContactInfoATTUId(@Param(value = "orderId") Long orderId,
			@Param(value = "orderContactTypeId") Long orderContactTypeId);
	@Query(value = "select  usr.attuid from OrderContactInfo oci join oci.users usr where oci.orderContact.orders.orderId=:orderId and oci.id.orderContactId=oci.orderContact.orderContactId and  oci.orderContactType.orderContactTypeId=:orderContactTypeId and usr.active=:active")
	List<String> getOrderContactInfoATTUId(Long orderId,Long orderContactTypeId,Character active);
	
	OrderContactInfo findById_OrderContactIdAndId_OrderContactTypeId(Long orderContactId, Long orderContactTypeId);
}
