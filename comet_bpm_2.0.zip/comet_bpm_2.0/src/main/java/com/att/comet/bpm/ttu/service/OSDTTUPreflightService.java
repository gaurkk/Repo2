package com.att.comet.bpm.ttu.service;

import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;



public interface OSDTTUPreflightService {
	void preOperationOSDTTUPreflight(CommonBO commonBO) throws CamundaServiceException;
	void postOperationOSDTTUPreflight(CommonBO commonBO, String OSDComments, String PreFlightTestingDateTime, String preFlightTestingResult) throws CamundaServiceException;
	
}
