package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for city. Mapped to CITY table in the database.
 */
@Entity
@Table(name = "CITY")
public class City implements Serializable {

	private static final long serialVersionUID = -5533928359746172100L;

	private Long cityId;
	private State state;
	private String cityName;
	private Set<SubAccount> subAccountsForBlCityId = new HashSet<SubAccount>(0);
	private Set<SubAccount> subAccountsForMccCityId = new HashSet<SubAccount>(0);
	private Set<SubAccount> subAccountsForHlCityId = new HashSet<SubAccount>(0);
	private Set<Users> userses = new HashSet<Users>(0);
	private Set<SubAccount> subAccountsForClCityId = new HashSet<SubAccount>(0);
	private Character active;

	/**
	 * Getter method for cityId. CITY_ID mapped to CITY_ID in the database
	 * table.
	 * 
	 * @return Long.
	 */
	 @Id
	@GenericGenerator(name = "SEQ_CITY_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_CITY_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CITY_ID")
	@Column(name = "CITY_ID", nullable = false, precision = 12, scale = 0)
	public Long getCityId() {
		return this.cityId;
	}

	/**
	 * @param cityId
	 *            to cityId set.
	 */
	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	/**
	 * Getter method for state.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATE_ID", nullable = false)
	public State getState() {
		return this.state;
	}

	/**
	 * @param state
	 *            to state set.
	 */
	public void setState(State state) {
		this.state = state;
	}

	/**
	 * Getter method for cityName. CITY_NAME mapped to CITY_NAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "CITY_NAME", nullable = false, length = 100)
	public String getCityName() {
		return this.cityName;
	}

	/**
	 * @param cityName
	 *            to cityName set.
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * Getter method for subAccountsForBlCityId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cityByBlCityId")
	public Set<SubAccount> getSubAccountsForBlCityId() {
		return this.subAccountsForBlCityId;
	}

	/**
	 * @param subAccountsForBlCityId
	 *            to subAccountsForBlCityId set.
	 */
	public void setSubAccountsForBlCityId(Set<SubAccount> subAccountsForBlCityId) {
		this.subAccountsForBlCityId = subAccountsForBlCityId;
	}

	/**
	 * Getter method for subAccountsForMccCityId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cityByMccCityId")
	public Set<SubAccount> getSubAccountsForMccCityId() {
		return this.subAccountsForMccCityId;
	}

	/**
	 * @param subAccountsForMccCityId
	 *            to subAccountsForMccCityId set.
	 */
	public void setSubAccountsForMccCityId(
			Set<SubAccount> subAccountsForMccCityId) {
		this.subAccountsForMccCityId = subAccountsForMccCityId;
	}

	/**
	 * Getter method for subAccountsForHlCityId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cityByHlCityId")
	public Set<SubAccount> getSubAccountsForHlCityId() {
		return this.subAccountsForHlCityId;
	}

	/**
	 * @param subAccountsForHlCityId
	 *            to subAccountsForHlCityId set.
	 */
	public void setSubAccountsForHlCityId(Set<SubAccount> subAccountsForHlCityId) {
		this.subAccountsForHlCityId = subAccountsForHlCityId;
	}

	/**
	 * Getter method for userses.
	 * 
	 * @return Set<Users>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "city")
	public Set<Users> getUserses() {
		return this.userses;
	}

	/**
	 * @param userses
	 *            to userses set.
	 */
	public void setUserses(Set<Users> userses) {
		this.userses = userses;
	}

	/**
	 * Getter method for subAccountsForClCityId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "cityByClCityId")
	public Set<SubAccount> getSubAccountsForClCityId() {
		return this.subAccountsForClCityId;
	}

	/**
	 * @param subAccountsForClCityId
	 *            to subAccountsForClCityId set.
	 */
	public void setSubAccountsForClCityId(Set<SubAccount> subAccountsForClCityId) {
		this.subAccountsForClCityId = subAccountsForClCityId;
	}

	@Column(name="ACTIVE", length=1)
	public Character getActive() {
		return active;
	}

	public void setActive(Character active) {
		this.active = active;
	}
}