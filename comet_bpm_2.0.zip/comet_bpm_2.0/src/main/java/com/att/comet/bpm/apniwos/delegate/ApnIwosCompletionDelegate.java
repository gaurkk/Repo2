package com.att.comet.bpm.apniwos.delegate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.apniwos.service.ApnIwosCompletionService;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class ApnIwosCompletionDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosCreationDelegate.class);

	@Autowired
	private CommonService commonService;
	@Autowired
	ApnIwosCompletionService apnIwosCompletionService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.ORDER_STATUS_CHECK:
					preOrderStatusCheck(execution);
					break;
				case BpmConstant.APN_IWOS_PRE_OPERATION:
					preOperationApnIwosCreation(execution);
					break;
				case BpmConstant.APN_IWOS_POST_OPERATION_SUS_COM:
					postOperationApnIwosCompletion_Suspension(execution);
					break;
				case BpmConstant.APN_IWOS_POST_OPERATION:
					postOperationApnIwosCompletion(execution);
					break;
				}
			}

		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(APN_IWOS_COMPLETION_SUSPENSION_BPM_ERROR_CODE should be same for
			 * delegate and BPMN mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.APN_IWOS_COMPLETION_SUSPENSION_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void preOrderStatusCheck(DelegateExecution execution) {
		logger.info("Start preOrderStatusCheck method ::", this);
		CommonBO commonBO = null;
		String apnIwosCompletionInstanceId = null;
		String orderOperation = null;
		apnIwosCompletionInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable("orderId");
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
				if (commonBO != null && null != commonBO.getOrderStatusId()) {
					String orderStatus = commonBO.getOrderStatusName();
					commonBO.setBpmProcessInstanceId(apnIwosCompletionInstanceId);
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable("commonBO", commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable("orderStatus", orderStatus);

					} else {
						logger.error("Order Status name for  ," + "ORDER_ID::[" + orderId + "]  is null", this);
					}
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TO GET ORDER STATUS"));
		}
		logger.info("Exiting preOrderStatusCheck method ::", this);
	}

	private void preOperationApnIwosCreation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperationApnIwosCompletion method ::", this);
		Long orderId = (Long) execution.getVariable("orderId");
		String apnIWOSCcompletionProcessInstanceId = null;
		apnIWOSCcompletionProcessInstanceId = execution.getProcessInstanceId();
		CommonBO commonBO = null;

		commonBO = (CommonBO) execution.getVariable("commonBO");
		if (null != commonBO) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_IWOS_COMPLETION_SUSPENSION_ERR_PRE_001);// APN_IWOS_COMPLETION_SUSPENSION_ERR_PRE_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1017L);// Mapped from BPM_task table (CCS PM : Network IWOS Completion /
													// Suspension)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			execution.setVariable("orderId", commonBO.getOrderId());
			execution.setVariable("apnName", commonBO.getApnName());
			execution.setVariable("accountName", commonBO.getAccountName());
			execution.setVariable("cipn", commonBO.getCipn());
			execution.setVariable("backhaulIds", commonBO.getBackHaulIds());
			execution.setVariable("url", commonBO.getWorkFlowUrl());
			execution.setVariable("pdpName", commonBO.getPdpName()); // Need to check PdpIdInfoRepository
			execution.setVariable("orderType", commonBO.getOrderOperation());// set above method
			execution.setVariable("expediteOrder", commonBO.isExpediteOrder());

			execution.setVariable("categoryId", "1002");// User task
			execution.setVariable("taskId", "1001L");
			execution.setVariable("task", "CREATED");

			commonBO.setRoleId(1005L);// Setting OSD roleID
			commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
			commonBO.setTaskStatusName("CCSPM_APN_IWOS_STATUS_Task");
			commonBO.setCategoryId(1002L);// category ID (user task)
			commonBO.setUrlName(commonBO.getWorkFlowUrl());
			commonBO.setTaskId(1017L);// Mapped from BPM_task table (CCS PM : Network IWOS Completion / Suspension)
			commonBO.setBpmProcessInstanceId(apnIWOSCcompletionProcessInstanceId);
			commonBO.setUrlName(commonBO.getWorkFlowUrl());
			apnIwosCompletionService.preOperationIWOSCompletion(commonBO);
			execution.setVariable("commonBO", commonBO);
			execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
			execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
		} else {
			logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

		}

		logger.info("Existing preOperationApnIwosCompletion method ::", this);

	}

	private void postOperationApnIwosCompletion_Suspension(DelegateExecution execution) throws CamundaServiceException, ParseException {
		logger.info("Start postOperationApnIwosCompletion_Suspenstion method ::", this);
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String CCSPMComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		String IWOSTicketCompletionDateTime = (String) execution.getVariable(BpmConstant.COMPLETED_DATE);
		String IWOSTicketResponse = (String) execution.getVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION);
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_IWOS_COMPLETION_SUSPENSION_ERR_POST_001);// APN_IWOS_COMPLETION_SUSPENSION_ERR_POST_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1017L);// Mapped from BPM_task table (CCS PM : Network IWOS Completion /
													// Suspension)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			
			apnIwosCompletionService.postOperationIWOSCom_Sus(commonBO, CCSPMComments, IWOSTicketCompletionDateTime,
					IWOSTicketResponse);

			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);
			commonService.updateOrderUserBpmTasksRepository(commonBO);

			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION, IWOSTicketResponse);
		} else {
			logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

		}

		logger.info("Exiting postOperationApnIwosCompletion_Suspenstion method ::", this);
	}

	private void postOperationApnIwosCompletion(DelegateExecution execution) {
		logger.info("Start postOperationApnIwosCompletion method ::", this);
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String IWOSTicketResponse = (String) execution.getVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION);
			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				apnIwosCompletionService.postOperationIWOSCompletion(commonBO);
				execution.setVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION, commonBO.getBusinessStepStatus());
				commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
				commonBO.setTaskCompletionTime(new Date());
				commonBO.setCategoryId(1003L);// Service
				if (!IWOSTicketResponse.equalsIgnoreCase("Completed")) {
					commonService.updateOrderUserBpmTasksRepository(commonBO);
				}
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION, commonBO.getBusinessStepStatus());
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

			}

		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure APN IWOS COMPETION EXCEPTION"), this);
			throw new BpmnError("ERROR_BPM_001", "APN IWOS COMPETION EXCEPTION");
		}
		logger.info("Exiting postOperationApnIwosCompletion method ::", this);
	}

}
