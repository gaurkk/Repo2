package com.att.comet.bpm.codashboard.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class NiRollbackTaskServiceImpl implements NiRollbackTaskService {
	private static final Logger logger = LoggerFactory.getLogger(NiRollbackTaskServiceImpl.class);

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;
	@Override
	public void niRollbackTaskPreOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method niRollbackTaskPreOperation", this);

		// saving bom work step
		commonBO.setWorkStepId(1081L);
		commonBO.setBpmStatusId(1001L);
		commonBO.setUpdatedOn(new Date());
		bpmDAO.saveBpmOrderWorkStep(commonBO);

		// delete reminders
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3225L);
		businessStepIdList.add(3226L);
		businessStepIdList.add(3227L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		commonBO.setOrderContactTypeId(1007L); // ORDER_CONTACT_Type table , ORDER_CONTACT_TYPE_NAME = Order
		List<String> niEmailList = null;
		// fetching dynamic user from order_contact_info table

		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderAprover = attUidList.get(0);
			commonBO.setAttuid(orderAprover);
			commonBO.setAssignee(orderAprover);
			niEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(niEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1004L);
			niEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setEmailList(niEmailList);
		}
		// COMET Admin Email List
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All
		}
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForNIIWOSRollback(commonBO);
		
		logger.info("@Ending method niRollbackTaskPreOperation", this);

	}

	@Override
	public void niRollbackTaskPostOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method niRollbackTaskPostOperation", this);
		// saving bpm business step
		commonBO.setBusinessStepId(3225L);
		commonBO.setBusinessStepStatus("Rolled back");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm work step
		commonBO.setWorkStepId(1081L);
		commonBO.setBpmStatusId(1002L);
		commonBO.setUpdatedOn(new Date());
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		
		logger.info("@Ending method niRollbackTaskPostOperation", this);

	}

}
