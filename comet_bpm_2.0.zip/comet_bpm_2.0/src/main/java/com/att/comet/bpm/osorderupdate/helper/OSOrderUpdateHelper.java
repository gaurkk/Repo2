package com.att.comet.bpm.osorderupdate.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class OSOrderUpdateHelper {
	private static final Logger logger = LoggerFactory.getLogger(OSOrderUpdateHelper.class);

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	AuditDAO auditDAO;

	@Autowired
	AvosDAO avosDAO;

	@Autowired
	GenericDAO genericDAO;

	public void preOperationOAReject(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method preOperationOAReject", this);
		// TODO:Invoke Email To OS

		/* Update Orders */
		commonBO.setOrderStatusId(1006L);
		orderDAO.updateOrders(commonBO);

		/* Insert Into OrderStatusHistory */
		commonBO.setOrderStatusId(1006L);
		orderDAO.saveOrderStatusHistory(commonBO);

		/* Update AuditOrders */
		commonBO.setOrderStatusId(1006L);
		auditDAO.updateAuditOrders(commonBO);

		/* Get ATTUID */
		commonBO.setOrderContactTypeId(1003L);
		String assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeOS);

		/* Delete BpmOrderBusinessStep */
		commonBO.setBusinessStepId(new Long(3102));
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		logger.info("@Ending method preOperationOAReject", this);
	}

	public void postOperationOAReject(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method postOperationOAReject", this);
		
		commonBO.setOrderContactTypeId(1003L);
		String assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAttuid(assigneeOS);
		
		/* Update OrderContactInfo */
		//commonBO.setRoleId(1002L);
		

		/* Save OrderComments */
		commonBO.setRoleId(1001L);
		commonBO.setUserAction("Order Update (OS) - Completed for OA Rejection");
		orderDAO.saveOrderComments(commonBO);

		/* Delete BpmOrderWorkStep */
		ArrayList<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1001L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);

		/* Delete BpmOrderProcess */
		bpmDAO.deleteBpmOrderProcess(commonBO);

		/* Delete AVOSProcessInstances */
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		
		// TODO:Invoke Email To OA

		logger.info("@Ending method postOperationOAReject", this);
	}

	public void preOperationOMReject(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method preOperationOMReject", this);
		// TODO:Invoke Email To OS & OA

		/* Update Orders */
		commonBO.setOrderStatusId(1007L);
		orderDAO.updateOrders(commonBO);

		/* Update AuditOrders */
		commonBO.setOrderStatusId(1007L);
		auditDAO.updateAuditOrders(commonBO);

		/* Insert OrderStatusHistory */
		commonBO.setOrderStatusId(1007L);
		orderDAO.saveOrderStatusHistory(commonBO);

		/* Delete BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3103L);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* Get ATTUID */
		commonBO.setOrderContactTypeId(1023L);
		String attUid = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		
		/* Get ATTUID of OrderSubmitter */
		commonBO.setOrderContactTypeId(1003L);
		String assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeOS);
		genericDAO.setReminder1And2FromSlaWorkingDayForITOPSDAPNOS(commonBO);
		// TODO: Email

		logger.info("@Ending method preOperationOMReject", this);
	}

	public void postOperationOMReject(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method postOperationOMReject", this);
		
		commonBO.setOrderContactTypeId(1003L);
		String assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAttuid(assigneeOS);
		/* Insert Into OrderComments */
		commonBO.setRoleId(1001L);
		commonBO.setUserAction("Order Update (OS) - Completed for OM Rejection");
		orderDAO.saveOrderComments(commonBO);

		// TODO:Invoke Email TO OA

		/* Delete BpmOrderWorkStep */
		List<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1002L);
		workStepIdList.add(1001L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);

		/* Update Orders */
		commonBO.setOrderStatusId(1007L);
		orderDAO.updateOrders(commonBO);

		/* Delete BpmOrderProcess */
		bpmDAO.deleteBpmOrderProcess(commonBO);

		/* Delete AVOSProcessInstances */
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		logger.info("@Ending method postOperationOMReject", this);
	}

}
