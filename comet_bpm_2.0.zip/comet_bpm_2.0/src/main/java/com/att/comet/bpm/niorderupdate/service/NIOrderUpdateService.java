package com.att.comet.bpm.niorderupdate.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface NIOrderUpdateService {

	void preOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;
}
