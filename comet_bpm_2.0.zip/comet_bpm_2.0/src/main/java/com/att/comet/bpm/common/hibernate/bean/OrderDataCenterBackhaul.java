package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for OrderDataCenterBackhaul. Mapped to
 * ORDER_DATA_CENTER_BACKHAUL table in the database.
 */
@Entity
@Table(name = "ORDER_DATA_CENTER_BACKHAUL")
public class OrderDataCenterBackhaul implements java.io.Serializable {

	private static final long serialVersionUID = -8871393465225151179L;

	private OrderDataCenterBackhaulId id;
	private Backhaul backhaul;
	private Orders orders;
	private DataCenter dataCenter;
	private String backhaulSelection;

	/**
	 * Getter method for id.
	 * 
	 * @return OrderDataCenterBackhaulId
	 */
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "backhaulId", column = @Column(name = "BACKHAUL_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public OrderDataCenterBackhaulId getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            to id set.
	 */
	public void setId(OrderDataCenterBackhaulId id) {
		this.id = id;
	}

	/**
	 * Getter method for backhaul.
	 * 
	 * @return Backhaul
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BACKHAUL_ID", nullable = false, insertable = false, updatable = false)
	public Backhaul getBackhaul() {
		return this.backhaul;
	}

	/**
	 * @param backhaul
	 *            to backhaul set.
	 */
	public void setBackhaul(Backhaul backhaul) {
		this.backhaul = backhaul;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 *            to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for backhaulSelection. BACKHAUL_SELECTION mapped to
	 * BACKHAUL_SELECTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BACKHAUL_SELECTION", nullable = false, length = 100)
	public String getBackhaulSelection() {
		return this.backhaulSelection;
	}

	/**
	 * @param backhaulSelection
	 *            to backhaulSelection set.
	 */
	public void setBackhaulSelection(String backhaulSelection) {
		this.backhaulSelection = backhaulSelection;
	}
}