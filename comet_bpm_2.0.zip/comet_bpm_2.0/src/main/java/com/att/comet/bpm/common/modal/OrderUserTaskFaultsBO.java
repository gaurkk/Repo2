package com.att.comet.bpm.common.modal;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrderUserTaskFaultsBO implements Serializable{
	
	private static final long serialVersionUID = -9158486237656641972L;

	private Long bpmTaskId;
	
	private Long orderId;
	
	private Long roleId;
	
	private Date taskCreationTime;
	
	private Date taskCompletionTime;
	
	private String taskDescription;
	
	private Long categoryId;// Mater data table
	
	private Long taskStatusId;
	
	private Long taskId;// Mapped from BPM_task table
	
	private String attuid;

	private String errorCode;
	
	private String errorDesc;
	
	private Date creationOn;
}
