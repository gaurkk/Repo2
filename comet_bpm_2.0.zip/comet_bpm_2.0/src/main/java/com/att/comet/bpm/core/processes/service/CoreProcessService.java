package com.att.comet.bpm.core.processes.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface CoreProcessService {
	void cancelOrderPreOperation(CommonBO commonBO) throws CamundaServiceException;
	void pendingTaskStatusCheck(CommonBO commonBO) throws CamundaServiceException;
	void completeProcess(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;
	void userDecisionCheck(CommonBO commonBO) throws CamundaServiceException;
	void cancelOrderPostOperation(CommonBO commonBO) throws CamundaServiceException;
	void postDecomUserTaskOperation(CommonBO commonBO) throws CamundaServiceException;
	void preDecomOperation(CommonBO commonBO) throws CamundaServiceException;
	String billingTaskStatus(CommonBO commonBO);
}
