package com.att.comet.bpm.decom.apnhlr.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.decom.apnhlr.helper.APNHLRDecomHelper;

@Service
public class APNHLRDecomServiceImpl implements APNHLRDecomService {

	@Autowired
	private APNHLRDecomHelper apnhlrDecomHelper;

	@Autowired
	private CommonService commonService;

	@Override
	public void preOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlrDecomHelper.preOperationAPNHLRDecom(commonBO, execution);
	}

	@Override
	public void postOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlrDecomHelper.postOperationAPNHLRDecom(commonBO, execution);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1005L);// CCS PM Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1042L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS Decommission Task)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
