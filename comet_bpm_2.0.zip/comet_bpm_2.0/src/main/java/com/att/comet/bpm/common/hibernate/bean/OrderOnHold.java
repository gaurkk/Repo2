package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_ON_HOLD")
public class OrderOnHold implements Serializable {

	private static final long serialVersionUID = 8240488586374830516L;

	private long onHoldId;
	private Long orderId;
	private OnHoldStatus onHoldStatus;
	private String attuid;
	private Date requestedOn;
	private Date proposedCompletionDate;
	private String onHoldReason;
	private String onHoldNotes;
	private String cancelNotes;
	private String resolveNotes;
	private Date updatedOn;

	@Id
	@Column(name = "ON_HOLD_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ON_HOLD_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_ON_HOLD_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ON_HOLD_ID")
	public long getOnHoldId() {
		return onHoldId;
	}

	public void setOnHoldId(long onHoldId) {
		this.onHoldId = onHoldId;
	}

	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ON_HOLD_STATUS_ID", nullable = false)
	public OnHoldStatus getOnHoldStatus() {
		return onHoldStatus;
	}

	public void setOnHoldStatus(OnHoldStatus onHoldStatus) {
		this.onHoldStatus = onHoldStatus;
	}

	@Column(name = "REQUESTED_BY", length = 50)
	public String getAttuid() {
		return attuid;
	}

	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	@Column(name = "REQUESTED_ON")
	public Date getRequestedOn() {
		return requestedOn;
	}

	public void setRequestedOn(Date requestedOn) {
		this.requestedOn = requestedOn;
	}

	@Column(name = "PROP_COMP_DATE")
	public Date getProposedCompletionDate() {
		return proposedCompletionDate;
	}

	public void setProposedCompletionDate(Date proposedCompletionDate) {
		this.proposedCompletionDate = proposedCompletionDate;
	}

	@Column(name = "ON_HOLD_REASON", length = 100)
	public String getOnHoldReason() {
		return onHoldReason;
	}

	public void setOnHoldReason(String onHoldReason) {
		this.onHoldReason = onHoldReason;
	}

	@Column(name = "ON_HOLD_NOTES", length = 3500)
	public String getOnHoldNotes() {
		return onHoldNotes;
	}

	public void setOnHoldNotes(String onHoldNotes) {
		this.onHoldNotes = onHoldNotes;
	}

	@Column(name = "CANCEL_NOTES", length = 3500)
	public String getCancelNotes() {
		return cancelNotes;
	}

	public void setCancelNotes(String cancelNotes) {
		this.cancelNotes = cancelNotes;
	}

	@Column(name = "RESOLVE_NOTES", length = 3500)
	public String getResolveNotes() {
		return resolveNotes;
	}

	public void setResolveNotes(String resolveNotes) {
		this.resolveNotes = resolveNotes;
	}

	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
