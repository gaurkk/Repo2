package com.att.comet.bpm.apniwos.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;
@Service
public class ApnIwosOsdOrderUpdateServiceImpl implements ApnIwosOsdOrderUpdateService {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosOsdOrderUpdateServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	GenericDAO genericDAO;

	@Override
	public void preOperationOrderUpdate(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperationOrderUpdate");
		List<String> osdEmailList = null;
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1023L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			commonBO.setAssignee(orderSubmitter);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		}
		// insert and update bpm_order_work_step table
		if ("NEW_ORDER".equals(commonBO.getOrderOperation())) {
			commonBO.setWorkStepId(1039L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {
			commonBO.setWorkStepId(1039L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1039L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		/* fetching OS OA OM to put in CC */
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		osdEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					osdEmailList.add((String) obj[1]);
				}
			}
			commonBO.setGroupEmailList(osdEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
		}
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNIWO_COMPLETION(commonBO);
		logger.info("ending Method preOperationOrderUpdate");
	}

	@Override
	public void postOperationOrderUpdate(CommonBO commonBO, String osdComments) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationOrderUpdate");
		// update order_contact_info
		commonBO.setOrderContactId(1023L);
		orderDAO.updateOrderContactInfo(commonBO);
		/* CR Count */
		Long crCount = orderDAO.countOrderEvent(commonBO);// do we need to know CR count?
		String crVar = "CR-00";
		if (null != crCount && crCount > 0) {
			crVar = crVar + "" + String.valueOf(crCount);
			commonBO.setCrCountValue(crVar);
		}
		/* Save OrderComments */
		commonBO.setRoleId(1001L);
		commonBO.setComments(osdComments);
		commonBO.setUserAction("Order Update (OSD) - Completed for IWOS Suspension");
		if ("CHANGE_REQUEST".equalsIgnoreCase(commonBO.getOrderOperation())) {
			commonBO.setOrderProcess(commonBO.getCrCountValue());
			orderDAO.saveOrderComments(commonBO);
		} else if ("CHANGE_ORDER".equalsIgnoreCase(commonBO.getOrderOperation())) {
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			orderDAO.saveOrderComments(commonBO);
		} else {
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			orderDAO.saveOrderComments(commonBO);
		}
		/* update order work step */
		//commonBO.setWorkStepId(1039L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1039L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		/* updating order status */
		commonBO.setOrderStatusId(1046L);
		orderDAO.updateOrders(commonBO);
		/* Update AuditOrders */
		commonBO.setOrderStatusId(1046L);
		auditDAO.updateAuditOrders(commonBO);
		logger.info("ending Method postOperationOrderUpdate");
	}

	@Override
	public void newOrderDBOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method newOrderDBOperation");
		/* deleting bpm order work step */
		List<Long> orderWorkStepList = new ArrayList<Long>();
		orderWorkStepList.add(1008L);
		orderWorkStepList.add(1039L);
		commonBO.setWorkStepIdList(orderWorkStepList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3104L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
	
		/* updating order status */
		commonBO.setOrderStatusId(1045L);
		orderDAO.updateOrders(commonBO);
		/* Update AuditOrders */
		commonBO.setOrderStatusId(1045L);
		auditDAO.updateAuditOrders(commonBO);
		logger.info("ending Method newOrderDBOperation");
	}

	@Override
	public void crcoDBOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crcoDBOperation");
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3104L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		
		commonBO.setComments(commonBO.getComments());
		commonBO.setBusinessStepId(3104L);
		commonBO.setBusinessStepValue("Order is Updated");
		commonBO.setBusinessStepStatus("true");
		commonBO.setAttuid(commonBO.getAttuid());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		/* updating order status */
		commonBO.setOrderStatusId(1045L);
		orderDAO.updateOrders(commonBO);
		/* deleting process instance ID */
		camundaDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);;
		
		logger.info("ending Method crcoDBOperation");
	}

}
