package com.att.comet.bpm.common.dao.impl;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.OrderComments;
import com.att.comet.bpm.common.hibernate.bean.OrderType;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.hibernate.bean.Role;
import com.att.comet.bpm.common.hibernate.bean.Users;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderCommentRepository;

@Component
public class OrderCommentsDAOImpl implements  OrderCommentsDAO{

	private static final Logger logger = LoggerFactory.getLogger(OrderCommentsDAOImpl.class);
	
	@Autowired
	private OrderCommentRepository orderCommentRepository;

	@Override
	public void insertOrderCommentsForOrderIdAndDetails(CommonBO commonBO)throws CamundaServiceException {
		logger.debug("@Starting insertOrderCommentsForOrderIdAndDetails", this);
		OrderComments orderComments = new OrderComments();
		Date today = new Date();
		Orders orders = new Orders();
		OrderType orderType = new OrderType();
		Users users = new Users();
		Role role = new Role();
		
		orderType.setOrderTypeId(commonBO.getOrderTypeId());
		orderType.setOrderTypeName(commonBO.getOrderStatusName());
		
		orders.setOrderId(commonBO.getOrderId());
		orders.setOrderType(orderType);
		if(null==commonBO.getOrderApprover()) {
			//Rejected case only
		users.setAttuid(commonBO.getUpdatedBy());
		}else {
			//Approval case only 
		users.setAttuid(commonBO.getOrderApprover());
		}
		role.setRoleId(commonBO.getRoleId());
		
		orderComments.setRole(role);
		orderComments.setUsers(users);
		orderComments.setOrders(orders);
		orderComments.setCreatedOn(today);
		orderComments.setUserAction(commonBO.getResponseHTAction());
		orderComments.setOrderProcess(commonBO.getOrderProcess());
		orderComments.setComments(commonBO.getComments());
		orderCommentRepository.save(orderComments);
		logger.debug("@Ending insertOrderCommentsForOrderIdAndDetails", this);
	}
}
