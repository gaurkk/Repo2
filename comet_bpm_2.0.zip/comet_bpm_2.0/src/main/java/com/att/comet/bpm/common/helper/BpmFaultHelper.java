package com.att.comet.bpm.common.helper;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Session;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.hibernate.bean.TaskCategory;
import com.att.comet.bpm.common.hibernate.bean.TaskStatus;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.EmailTemplateBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.util.EmailUtil;

@Component
public class BpmFaultHelper implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(BpmFaultHelper.class);

	@Autowired
	OrderDAO orderDAO;
	@Autowired
	EmailUtil emailUtil;

	@Autowired
	EmailTemplateHelper emailTemplateHelper;

	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	// get smtpm server
	@Value("${comet.email.smtp-server}")
	private String smtp_server;
	// Smpt port
	@Value("${comet.email.smtp-port}")
	private String smtp_port;
	// smtp-host
	@Value("${comet.email.smtp-host}")
	private String smtp_host;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		logger.info("Start execute method ::", this);

		Map<String, Object> variables = execution.getVariables();
		OrderUserTaskFaultsBO orderUserTaskFaultsBO = variables.get(BpmConstant.ORDER_USER_TASK_FALULTS) != null
				? (OrderUserTaskFaultsBO) variables.get(BpmConstant.ORDER_USER_TASK_FALULTS)
				: null;
		if (null != orderUserTaskFaultsBO) {
			logger.info("Process faulted for orderId:{} and taskId:{} with errorcode:{}",
					orderUserTaskFaultsBO.getOrderId(), orderUserTaskFaultsBO.getTaskId(),
					orderUserTaskFaultsBO.getErrorCode());
			CommonBO commonBO = new CommonBO();
			commonBO.setOrderId(orderUserTaskFaultsBO.getOrderId());
			commonBO.setBpmTaskId(String.valueOf(orderUserTaskFaultsBO.getBpmTaskId()));
			commonBO.setCategoryId(orderUserTaskFaultsBO.getCategoryId());
			commonBO.setRoleId(orderUserTaskFaultsBO.getRoleId());
			commonBO.setTaskId(orderUserTaskFaultsBO.getTaskId());
			commonBO.setTaskStatusId(orderUserTaskFaultsBO.getTaskStatusId());
			commonBO.setTaskCreationTime(orderUserTaskFaultsBO.getCreationOn());
			if (orderUserTaskFaultsBO.getCategoryId() == 1002L) {
				Orders odr = new Orders();
				odr.setOrderId(orderUserTaskFaultsBO.getOrderId());

				BpmTask taskId = new BpmTask();
				taskId.setTaskId(orderUserTaskFaultsBO.getTaskId());

				TaskCategory category = new TaskCategory();
				category.setTaskCategoryId(orderUserTaskFaultsBO.getCategoryId());

				TaskStatus taskStatus = new TaskStatus();
				taskStatus.setTaskStatusId(1001L);

				Optional<OrderUserBpmTasks> optional = orderUserBpmTasksRepository
						.findByOrdersAndBpmTaskAndTaskCategoryAndTaskStatus(odr, taskId, category, taskStatus);
				if (optional.isPresent()) {
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(optional.get().getBpmTaskId()));
				}

			}

			// update OrderUserBpmTasks
			orderDAO.updateOrderUserBpmTasksForException(commonBO);

			// update OrderUserTaskFaults
			orderDAO.updateOrderUserTaskFaults(orderUserTaskFaultsBO);
			EmailTemplateBO emailTemplateBO = new EmailTemplateBO();

			emailTemplateBO.setToEmail("COMET_BOA@list.att.com");
			emailTemplateBO.setCcEmail("COMET_DEV_TEAM@list.att.com");

			emailTemplateBO.setSubject("EXCEPTION Occured: BPM TASK ID ::" + commonBO.getBpmTaskId() + " TASK ID::"
					+ commonBO.getTaskId() + " " + commonBO.getTaskName());
			emailTemplateBO.setBodySection1("AN EXCEPTION Occured while executing BPM task :" + commonBO.getBpmTaskId()
					+ ".Details are below:- ");
			emailTemplateBO.setBodySection2("ORDER ID:" + commonBO.getOrderId());
			emailTemplateBO.setBodySection3("Error Code:" + orderUserTaskFaultsBO.getErrorCode() + " Error Description:"
					+ orderUserTaskFaultsBO.getErrorDesc());
			emailTemplateBO.setFooterSection("<p>NOTE:This is a auto-generate email : please don'nt reply on it</p>");
			Map<String, Object> model = taskExceptionCreationEmailFormat(emailTemplateBO, commonBO);
			// EMAIL SENDER CLASS INVOKING
			Properties props = System.getProperties();
			props.put(smtp_host, smtp_server);// will update later from YML
			Session session = Session.getInstance(props, null);

			emailUtil.sendEmail(session, emailTemplateBO, model);
		}
		logger.info("End execute method ::", this);
	}

	private Map<String, Object> taskExceptionCreationEmailFormat(EmailTemplateBO emailTemplateBO, CommonBO commonBO) {
		Map<String, Object> model = new HashMap<>();
		model.put("HeaderSection", "Exception  Occured");
		model.put("SubHeaderSection", "Below are the details:-");
		String taskStm = emailTemplateBO.getBodySection1();// task
		model.put("taskStm", taskStm);
		String orderData = emailTemplateBO.getBodySection2();
		model.put("orderData", orderData);
		String footer = emailTemplateBO.getFooterSection();
		model.put("footer", footer);
		String moreOrderDetails = emailTemplateBO.getBodySection3();
		model.put("moreOrderDetails", moreOrderDetails);
		return model;
	}

}
