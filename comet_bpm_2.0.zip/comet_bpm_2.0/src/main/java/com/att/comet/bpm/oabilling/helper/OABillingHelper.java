package com.att.comet.bpm.oabilling.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OABillingHelper {
	private static final Logger logger = LoggerFactory.getLogger(OABillingHelper.class);

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	private OrderTypeRepository orderTypeRepository;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;

	public void oaBillingPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method oaBillingPreOprCRUD", this);
		Long count = orderDAO.countOrderEvent(commonBO);
		Long orderTypeId;
		String assignee = null;
		Boolean User_or_group_exist = false;
		String crCountValue = "CR-00" + count;

		if ("CHANGE_REQUEST".equals(commonBO.getOrderOperation())) {
			commonBO.setBpmProcessId(1011L); // BPM_PROCESS table ,PROCESS_NAME = Process Billing Request
			commonBO.setBpmProcessInstanceId(processInstanceId);
			commonBO.setCrCountValue(crCountValue);
			avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		} else {
			commonBO.setBpmProcessId(1011L); // BPM_PROCESS table ,PROCESS_NAME = Process Billing Request
			commonBO.setBpmProcessInstanceId(processInstanceId);
			avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		}

		commonBO.setCometAdminEmailResponse(
				genericDAO.getEmailFromUsersAndUserRoleByCometAdminRoleIdAndActiveAndApproved(commonBO));

		orderTypeId = orderTypeRepository.getOrderTypeId(commonBO.getOrderTypeName());

		if ("NEW_ORDER".equals(commonBO.getOrderOperation())) {
			commonBO.setOrderTypeId(orderTypeId);
			commonBO.setProcessId(1011L); // BPM_PROCESS table ,PROCESS_NAME = Process Billing Request
			commonBO.setBpmStatusId(1001L); // BPM_STATUS table BPM_STATUS_NAME = TRIGERRED
			bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		} else {
			commonBO.setOrderTypeId(orderTypeId);
			commonBO.setProcessId(1011L); // BPM_PROCESS table ,PROCESS_NAME = Process Billing Request
			commonBO.setBpmStatusId(1001L); // BPM_STATUS table BPM_STATUS_NAME = TRIGERRED
			bpmDAO.updateBpmOrderProcess(commonBO);
		}

		String userDecision = commonBO.getUserDecision();
		if ((BpmConstant.NEW_ORDER.equals(commonBO.getOrderOperation()) || BpmConstant.CHANGE_ORDER.equals(commonBO.getOrderOperation()))
				|| (BpmConstant.CHANGE_REQUEST.equals(commonBO.getOrderOperation())
						|| BpmConstant.DECOMMISSION_ORDER.equals(commonBO.getOrderOperation())
								&& userDecision == "Applicable")) {
			List<Long> businessStepIdList = new ArrayList<>();
			businessStepIdList.add(3023L); // BPM_BUSINESS_STEP table ,BUSINESS_STEP_NAME = BILLING_SUBMIT
			businessStepIdList.add(3034L); // BPM_BUSINESS_STEP table ,BUSINESS_STEP_NAME =
											// BILLING_REQUEST_SUMISSION_DATE
			businessStepIdList.add(3065L); // BPM_BUSINESS_STEP table ,BUSINESS_STEP_NAME = REMINDER1
			businessStepIdList.add(3185L); // BPM_BUSINESS_STEP table ,BUSINESS_STEP_NAME = REMINDER2
			commonBO.setBusinessStepIdList(businessStepIdList);
			bpmDAO.deleteBpmOrderBusinessStep(commonBO);

			if ("NEW_ORDER".equals(commonBO.getOrderOperation())) {
				List<Long> list = new ArrayList<Long>();
				list.add(1018L); // BPM_WORK_STEP table ,WORK_STEP_NAME = BILLING REQUEST SUBMISSION TASK
				commonBO.setBpmStatusId(1001L);
				commonBO.setWorkStepIdList(list);
				bpmDAO.saveBpmOrderWorkStep(commonBO);
			} else {
				List<Long> list = new ArrayList<Long>();
				list.add(1018L); // BPM_WORK_STEP table ,WORK_STEP_NAME = BILLING REQUEST SUBMISSION TASK
				commonBO.setBpmStatusId(1001L); // BPM_STATUS table BPM_STATUS_NAME = TRIGERRED
				commonBO.setWorkStepIdList(list);
				bpmDAO.updateBpmOrderWorkStep(commonBO);
			}

			List<Object[]> detailsBillingDataList = orderDAO.getBillingData(commonBO);

			for (Object[] detailsBillingData : detailsBillingDataList) {
				commonBO.setAccountName(detailsBillingData[0] != null ? detailsBillingData[0].toString() : "N/A");
				commonBO.setCompanyBillingAddress(detailsBillingData[1] != null ? detailsBillingData[1].toString() : "N/A");
				commonBO.setCompanyContactNamePhone(detailsBillingData[2] != null ? detailsBillingData[2].toString() : "N/A");
				commonBO.setFederalTaxID(detailsBillingData[3] != null ? detailsBillingData[3].toString() : "N/A");
				commonBO.setBan(detailsBillingData[4] != null ? detailsBillingData[4].toString() : "N/A");
				commonBO.setFan(detailsBillingData[5] != null ? detailsBillingData[5].toString() : "N/A");
				commonBO.setAccountManager(detailsBillingData[6] != null ? detailsBillingData[6].toString() : "N/A");
				commonBO.setMobilityTechnicalEngineer(detailsBillingData[7] != null ? detailsBillingData[7].toString() : "N/A");
				commonBO.setApnName(detailsBillingData[11] != null ? detailsBillingData[11].toString() : "N/A");
				commonBO.setPdpName(detailsBillingData[12] != null ? detailsBillingData[12].toString() :"N/A");
				commonBO.setSourceofIPAddressing(detailsBillingData[13] !=null ? detailsBillingData[13].toString() : "N/A");
				commonBO.setTypeofAddressing(detailsBillingData[14] !=null ? detailsBillingData[14].toString() : "N/A");
				commonBO.setBackHaulIds(detailsBillingData[15] !=null ? detailsBillingData[15].toString() : "N/A");
				commonBO.setBackhaulInstances(detailsBillingData[16] !=null ? detailsBillingData[16].toString() : "N/A");
				commonBO.setMplscir(detailsBillingData[17] !=null ? detailsBillingData[17].toString() : "N/A");
				commonBO.setEodOrder(detailsBillingData[19] !=null ? detailsBillingData[19].toString() : "N/A");
				commonBO.setFeeWaiverApproved(detailsBillingData[20] !=null ? detailsBillingData[20].toString() : "N/A");
				commonBO.setManagedAVPN(detailsBillingData[21] !=null ? detailsBillingData[21].toString() : "N/A");
			}

			commonBO.setOrderContactTypeId(1004L); // ORDER_CONTACT_Type table , ORDER_CONTACT_TYPE_NAME = Order
													// Approver
			assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);

			if (CommonUtils.isNotNullEmpty(assignee)) {
				User_or_group_exist = true;
				commonBO.setAssignee(assignee);
				commonBO.setAttuid(assignee);
			}
			/* Get OA Email details */
			if (User_or_group_exist) {
				commonBO.setUser_or_group(assignee);
				commonBO.setOaBillingEmailSql(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
			} else {
				commonBO.setOaBillingEmailSql(
						genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
			}
			commonBO.setToEmail(commonBO.getOaBillingEmailSql());
			commonBO.setCcEmail("");
			genericDAO.setReminder1And2FromSlaWorkingDayForOABilling(commonBO);

			commonBO.setWorkStepId(1049L); // BPM_WORK_STEP table ,WORK_STEP_NAME = Expedite OA TASK
			BpmOrderWorkStep bpmOrderWorkStep = bpmDAO.getBpmOrderWorkStep(commonBO);
			if (bpmOrderWorkStep != null && bpmOrderWorkStep.getBpmStatus() != null) {
				Long expediteStatusResponse = bpmOrderWorkStep.getBpmStatus().getBpmStatusId();
			}

			commonBO.setWorkStepId(1050L); // BPM_WORK_STEP table ,WORK_STEP_NAME = Expedite OM TASK
			BpmOrderWorkStep bpmOrderWorkStepOM = bpmDAO.getBpmOrderWorkStep(commonBO);
			if (bpmOrderWorkStepOM != null && bpmOrderWorkStepOM.getBpmStatus() != null) {
				Long omExpediteStatusResponse = bpmOrderWorkStepOM.getBpmStatus().getBpmStatusId();
			}

			if ("NEW_ORDER".equals(commonBO.getOrderOperation())
					|| "CHANGE_ORDER".equals(commonBO.getOrderOperation())) {
				genericDAO.setBillingSLA(commonBO);
				commonBO.setDisplayFlag('N');
				bpmDAO.updateBpmOrderWorkStepDisplayFlag(commonBO);
			}
			
			int auditEventId = auditDAO.getMaxEventId(commonBO.getOrderId());

			if ((BpmConstant.NEW_ORDER.equals(commonBO.getOrderOperation())
					|| BpmConstant.CHANGE_ORDER.equals(commonBO.getOrderOperation())) && auditEventId > 0) {
				List<Object[]> detailsAuditOrdersList = auditDAO.getAuditOrders(commonBO, auditEventId);

				for (Object[] detailsAuditOrders : detailsAuditOrdersList) {
					commonBO.setAccountName(detailsAuditOrders[0] != null ? detailsAuditOrders[0].toString() : "N/A");
					commonBO.setCompanyBillingAddress(detailsAuditOrders[1] != null ? detailsAuditOrders[1].toString() : "N/A");
					commonBO.setCompanyContactNamePhone(detailsAuditOrders[2] != null ? detailsAuditOrders[2].toString() : "N/A");
					commonBO.setFederalTaxID(detailsAuditOrders[3] != null ? detailsAuditOrders[3].toString() : "N/A");
					commonBO.setBan(detailsAuditOrders[4] != null ? detailsAuditOrders[4].toString() : "N/A");
					commonBO.setFan(detailsAuditOrders[5] != null ? detailsAuditOrders[5].toString() : "N/A");
					commonBO.setAccountManager(detailsAuditOrders[6] != null ? detailsAuditOrders[6].toString() : "N/A");
					commonBO.setMobilityTechnicalEngineer(detailsAuditOrders[7] != null ? detailsAuditOrders[7].toString() : "N/A");
					commonBO.setApnName(detailsAuditOrders[11] != null ? detailsAuditOrders[11].toString() : "N/A");
					commonBO.setPdpName(detailsAuditOrders[12] != null ? detailsAuditOrders[12].toString() : "N/A");
					commonBO.setSourceofIPAddressing(detailsAuditOrders[13] != null ? detailsAuditOrders[13].toString() : "N/A");
					commonBO.setTypeofAddressing(detailsAuditOrders[14] != null ? detailsAuditOrders[14].toString() : "N/A");
					commonBO.setBackHaulIds(detailsAuditOrders[15] != null ? detailsAuditOrders[15].toString() : "N/A");
					commonBO.setBackhaulInstances(detailsAuditOrders[16] != null ? detailsAuditOrders[16].toString() : "N/A");
					commonBO.setMplscir(detailsAuditOrders[17] != null ? detailsAuditOrders[17].toString() : "N/A");
					commonBO.setEodOrder(detailsAuditOrders[19] != null ? detailsAuditOrders[19].toString() : "N/A");
					commonBO.setFeeWaiverApproved(detailsAuditOrders[20] != null ? detailsAuditOrders[20].toString() : "N/A");
					commonBO.setManagedAVPN(detailsAuditOrders[21] != null ? detailsAuditOrders[21].toString() : "N/A");
				}
			}
			// Invoke Submission Email
		}
	}

	public void oaBillingTaskCRUD(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method oaBillingTaskCRUD", this);
		if (BpmConstant.CHANGE_REQUEST.equals(commonBO.getOrderOperation())) {
			commonBO.setTaskName("CROABillingSubmitTask");
			commonBO.setTaskDisplayName("OA : Billing Request - Submission(CR)");
			//orderDAO.saveOrderBillingTask(commonBO);
		} else {
			commonBO.setTaskName("CCSPMBillingSubmitTask");
			commonBO.setTaskDisplayName("OA : Billing Request - Submission");
			//orderDAO.saveOrderBillingTask(commonBO);
		}
		logger.info("@Ending method oaBillingTaskCRUD", this);
	}

	public void oaBillingPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method oaBillingPostOprCRUD", this);

		commonBO.setBusinessStepId(3023L); // BPM_BUSINESS_STEP table ,BUSINESS_STEP_NAME = BILLING_SUBMIT
		commonBO.setBusinessStepStatus("Submitted");
		commonBO.setUpdatedOn(new Date());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		commonBO.setBpmStatusId(1002L); // BPM_STATUS table BPM_STATUS_NAME = COMPLETED
		List<Long> idList = new ArrayList<Long>();
		idList.add(1018L); // BPM_WORK_STEP table ,WORK_STEP_NAME = BILLING REQUEST SUBMISSION TASK
		commonBO.setWorkStepIdList(idList);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		orderDAO.updateOrderBillingTask(commonBO);

		commonBO.setProcessId(1011L); // BPM_PROCESS table ,PROCESS_NAME = Process Billing Request
		commonBO.setBpmStatusId(1002L); // BPM_STATUS table BPM_STATUS_NAME = COMPLETED
		bpmDAO.updateBpmOrderProcess(commonBO);

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		logger.info("@Ending method oaBillingPostOprCRUD", this);
	}
}
