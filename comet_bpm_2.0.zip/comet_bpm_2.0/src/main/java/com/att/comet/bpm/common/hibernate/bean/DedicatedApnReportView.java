package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DEDICATED_APN_REPORT_VIEW")
public class DedicatedApnReportView implements Serializable {
	private static final long serialVersionUID = -1837154928804477339L;

	private String dapnId;
	private String dapnStatus;
	private Long orderId;
	private String subAccountName;
	private String bcid;
	private String masterAccountName;
	private String masterAccountId;
	private String headqaurterLocation;
	private String apnType;
	private Long apnSize;
	private String apnName;
	private String pdpName;
	private Long pdpId;
	private Long udPdpId;
	private String mobileIp;
	private String pdnsAdd;
	private String sdnsAdd;
	private String dnsNotes;
	private String ampInfo;
	private String pdpPackageName;
	private String agreementAccountNo;
	private Character eodEnabled;
	private String fanId;
	private Character feewaiverApproved;
	private Character feewaiverApprovedMrc;
	private String waiverNotes;
	private String marketSegmentNote;
	private String useCategory;
	private String primaryBackupRemote;
	private String userType;
	private String stationaryMobile;
	private String ismName;
	private String ismPhone;
	private String ismEmail;

	@Id
	@Column(name = "DAPN_ID")
	public String getDapnId() {
		return dapnId;
	}

	public void setDapnId(String dapnId) {
		this.dapnId = dapnId;
	}

	@Column(name = "DAPN_STATUS")
	public String getDapnStatus() {
		return dapnStatus;
	}

	public void setDapnStatus(String dapnStatus) {
		this.dapnStatus = dapnStatus;
	}

	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "SUB_ACCOUNT_NAME")
	public String getSubAccountName() {
		return subAccountName;
	}

	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}

	@Column(name = "BCID")
	public String getBcid() {
		return bcid;
	}

	public void setBcid(String bcid) {
		this.bcid = bcid;
	}

	@Column(name = "MASTER_ACCOUNT_NAME")
	public String getMasterAccountName() {
		return masterAccountName;
	}

	public void setMasterAccountName(String masterAccountName) {
		this.masterAccountName = masterAccountName;
	}

	@Column(name = "MASTER_ACCOUNT_ID")
	public String getMasterAccountId() {
		return masterAccountId;
	}

	public void setMasterAccountId(String masterAccountId) {
		this.masterAccountId = masterAccountId;
	}

	@Column(name = "HEADQAURTER_LOCATION")
	public String getHeadqaurterLocation() {
		return headqaurterLocation;
	}

	public void setHeadqaurterLocation(String headqaurterLocation) {
		this.headqaurterLocation = headqaurterLocation;
	}

	@Column(name = "APN_TYPE")
	public String getApnType() {
		return apnType;
	}

	public void setApnType(String apnType) {
		this.apnType = apnType;
	}

	@Column(name = "APN_SIZE")
	public Long getApnSize() {
		return apnSize;
	}

	public void setApnSize(Long apnSize) {
		this.apnSize = apnSize;
	}

	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}

	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	@Column(name = "PDP_NAME")
	public String getPdpName() {
		return pdpName;
	}

	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	@Column(name = "PDP_ID")
	public Long getPdpId() {
		return pdpId;
	}

	public void setPdpId(Long pdpId) {
		this.pdpId = pdpId;
	}

	@Column(name = "UD_PDPID")
	public Long getUdPdpId() {
		return udPdpId;
	}

	public void setUdPdpId(Long udPdpId) {
		this.udPdpId = udPdpId;
	}

	@Column(name = "MOBILE_IP")
	public String getMobileIp() {
		return mobileIp;
	}

	public void setMobileIp(String mobileIp) {
		this.mobileIp = mobileIp;
	}

	@Column(name = "P_DNS_ADD")
	public String getPdnsAdd() {
		return pdnsAdd;
	}

	public void setPdnsAdd(String pdnsAdd) {
		this.pdnsAdd = pdnsAdd;
	}

	@Column(name = "S_DNS_ADD")
	public String getSdnsAdd() {
		return sdnsAdd;
	}

	public void setSdnsAdd(String sdnsAdd) {
		this.sdnsAdd = sdnsAdd;
	}

	@Column(name = "DNS_NOTES")
	public String getDnsNotes() {
		return dnsNotes;
	}

	public void setDnsNotes(String dnsNotes) {
		this.dnsNotes = dnsNotes;
	}

	@Column(name = "AMP_INFO")
	public String getAmpInfo() {
		return ampInfo;
	}

	public void setAmpInfo(String ampInfo) {
		this.ampInfo = ampInfo;
	}

	@Column(name = "PDP_PACKAGE_NAME")
	public String getPdpPackageName() {
		return pdpPackageName;
	}

	public void setPdpPackageName(String pdpPackageName) {
		this.pdpPackageName = pdpPackageName;
	}

	@Column(name = "AGREEMENT_ACCOUNT_NO")
	public String getAgreementAccountNo() {
		return agreementAccountNo;
	}

	public void setAgreementAccountNo(String agreementAccountNo) {
		this.agreementAccountNo = agreementAccountNo;
	}

	@Column(name = "EOD_ENABLED")
	public Character getEodEnabled() {
		return eodEnabled;
	}

	public void setEodEnabled(Character eodEnabled) {
		this.eodEnabled = eodEnabled;
	}

	@Column(name = "FAN_ID")
	public String getFanId() {
		return fanId;
	}

	public void setFanId(String fanId) {
		this.fanId = fanId;
	}

	@Column(name = "FEE_WAIVER_APPROVED")
	public Character getFeewaiverApproved() {
		return feewaiverApproved;
	}

	public void setFeewaiverApproved(Character feewaiverApproved) {
		this.feewaiverApproved = feewaiverApproved;
	}

	@Column(name = "FEE_WAIVER_APPROVED_MRC")
	public Character getFeewaiverApprovedMrc() {
		return feewaiverApprovedMrc;
	}

	public void setFeewaiverApprovedMrc(Character feewaiverApprovedMrc) {
		this.feewaiverApprovedMrc = feewaiverApprovedMrc;
	}

	@Column(name = "WAIVER_NOTES")
	public String getWaiverNotes() {
		return waiverNotes;
	}

	public void setWaiverNotes(String waiverNotes) {
		this.waiverNotes = waiverNotes;
	}

	@Column(name = "MARKET_SEGMENT_NOTE")
	public String getMarketSegmentNote() {
		return marketSegmentNote;
	}

	public void setMarketSegmentNote(String marketSegmentNote) {
		this.marketSegmentNote = marketSegmentNote;
	}

	@Column(name = "USE_CATEGORY")
	public String getUseCategory() {
		return useCategory;
	}

	public void setUseCategory(String useCategory) {
		this.useCategory = useCategory;
	}

	@Column(name = "PRIMARY_BACKUP_REMOTE")
	public String getPrimaryBackupRemote() {
		return primaryBackupRemote;
	}

	public void setPrimaryBackupRemote(String primaryBackupRemote) {
		this.primaryBackupRemote = primaryBackupRemote;
	}

	@Column(name = "USER_TYPE")
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	@Column(name = "STATIONARY_MOBILE")
	public String getStationaryMobile() {
		return stationaryMobile;
	}

	public void setStationaryMobile(String stationaryMobile) {
		this.stationaryMobile = stationaryMobile;
	}

	@Column(name = "ISM_NAME")
	public String getIsmName() {
		return ismName;
	}

	public void setIsmName(String ismName) {
		this.ismName = ismName;
	}

	@Column(name = "ISM_PHONE")
	public String getIsmPhone() {
		return ismPhone;
	}

	public void setIsmPhone(String ismPhone) {
		this.ismPhone = ismPhone;
	}

	@Column(name = "ISM_EMAIL")
	public String getIsmEmail() {
		return ismEmail;
	}

	public void setIsmEmail(String ismEmail) {
		this.ismEmail = ismEmail;
	}

}
