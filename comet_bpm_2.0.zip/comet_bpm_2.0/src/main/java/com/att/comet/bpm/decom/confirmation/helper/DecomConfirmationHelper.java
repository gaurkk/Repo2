package com.att.comet.bpm.decom.confirmation.helper;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;

@Component
public class DecomConfirmationHelper {
	private static final Logger logger = LoggerFactory.getLogger(DecomConfirmationHelper.class);

	@Autowired
	OrderDAO orderDAO;

	@Autowired
	GenericDAO genericDAO;

	@Autowired
	BpmDAO bpmDAO;

	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;

	@Autowired
	private CommonService commonService;

	public void postOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postDecomUserTaskOperation");
		
		String errorMsg = orderDAO.completeOrderWorkFlow(commonBO.getOrderId() , commonBO.getOrderOperation());
		logger.error(errorMsg);
		
		String decomConfirmationComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setComments(decomConfirmationComments);
		commonBO.setOrderStatusId(1023L); // Mapped with ORDER_STATUS ; Decommissioned
		orderDAO.updateOrders(commonBO);

		String assignee = null;
		commonBO.setOrderContactTypeId(1006L); // CCSPM
		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assignee);
		commonBO.setAttuid(assignee);

		/* INSERT record into BPM_Order_Business_Step */
		commonBO.setBusinessStepId(3140L); // Mapped with BPM_BUSINESS_STEP table ; Decommission conforamation Task
		commonBO.setBusinessStepStatus("Completed");
		commonBO.setOrderTypeId(1006L); // Mapped with ORDER_TYPE ; Decommission
		commonBO.setUpdatedBy(assignee);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		commonBO.setBpmStatusId(1002L); // Mapped with BPM_STATUS table ; COMPLETED
		commonBO.setBpmStepId(1002L); // this is set because in bpmorderworkstepdaoimpl bpmstepid = bpmstatusid
		commonBO.setWorkStepId(1036L); // Mapped with BPM_WORK_STEP table ;Decommission Confirmation Task
		bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);
		

		logger.info("::Exiting  Method postDecomUserTaskOperation Method :: ");

	}

	public void preOprCRUD(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Starting  Method preOprCRUD Method :: ");
		
		String assignee = null;
		commonBO.setOrderContactTypeId(1006L); // CCSPM
		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assignee);
		
		commonBO.setBpmProcessId(1014L);//Mapped with BPM_PROCESS table ; COMET DECOMMISSION PROCESS
		
		/* Set Reminder1 & Reminder2 SLA Dates for Decommission Confirmation */
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForConfirmationDecom(commonBO);
		
		logger.info("::Exiting  Method preOprCRUD Method :: ");
		
	}
}
