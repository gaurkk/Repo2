package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderExpedite. Mapped to ORDER_EXPEDITE table in the
 * database.
 */
@Entity
@Table(name = "ORDER_EXPEDITE")
public class OrderExpedite implements Serializable {

	private static final long serialVersionUID = 2748161852159697758L;

	private Long orderId;
	private Orders orders;
	private Date expediteOn;
	private String expediteBy;
	private Character expediteApproved;
	private Date expediteApprovedRejectedOn;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for expediteOn. EXPEDITE_ON mapped to EXPEDITE_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "EXPEDITE_ON", nullable = false)
	public Date getExpediteOn() {
		return this.expediteOn;
	}

	/**
	 * @param expediteOn
	 *            to expediteOn set.
	 */
	public void setExpediteOn(Date expediteOn) {
		this.expediteOn = expediteOn;
	}

	/**
	 * Getter method for expediteBy. EXPEDITE_BY mapped to EXPEDITE_BY in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXPEDITE_BY", nullable = false, length = 6)
	public String getExpediteBy() {
		return this.expediteBy;
	}

	/**
	 * @param expediteBy
	 *            to expediteBy set.
	 */
	public void setExpediteBy(String expediteBy) {
		this.expediteBy = expediteBy;
	}

	/**
	 * Getter method for expediteApproved. EXPEDITE_APPROVED mapped to
	 * EXPEDITE_APPROVED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "EXPEDITE_APPROVED", length = 1)
	public Character getExpediteApproved() {
		return this.expediteApproved;
	}

	/**
	 * @param expediteApproved
	 *            to expediteApproved set.
	 */
	public void setExpediteApproved(Character expediteApproved) {
		this.expediteApproved = expediteApproved;
	}

	/**
	 * Getter method for expediteApprovedRejectedOn.
	 * EXPEDITE_APPROVED_REJECTED_ON mapped to EXPEDITE_APPROVED_REJECTED_ON in
	 * the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "EXPEDITE_APPROVED_REJECTED_ON")
	public Date getExpediteApprovedRejectedOn() {
		return this.expediteApprovedRejectedOn;
	}

	/**
	 * @param expediteApprovedRejectedOn
	 *            to expediteApprovedRejectedOn set.
	 */
	public void setExpediteApprovedRejectedOn(Date expediteApprovedRejectedOn) {
		this.expediteApprovedRejectedOn = expediteApprovedRejectedOn;
	}
}