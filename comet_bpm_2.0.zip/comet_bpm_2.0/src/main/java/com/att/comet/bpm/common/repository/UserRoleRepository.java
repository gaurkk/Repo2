package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.UserRole;
import com.att.comet.bpm.common.hibernate.bean.UserRoleId;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, UserRoleId>{
	@Query(value="select us.email from UserRole ur join ur.users us where ur.id.roleId=:roleId and us.attuid= ur.id.attuid and us.active =:active and ur.approved =:approved ")
	List<String> findGroupUserEmail(Long roleId,Character active,char approved);
}
