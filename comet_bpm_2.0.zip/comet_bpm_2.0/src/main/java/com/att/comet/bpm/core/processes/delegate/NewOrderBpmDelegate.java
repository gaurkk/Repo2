package com.att.comet.bpm.core.processes.delegate;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Component
public class NewOrderBpmDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(NewOrderBpmDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired 
	AvosDAO avosDAO;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		String orderStatus = null;
		
		try {
			//commonBO = commonService.getCommonBO(orderId);
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.NEW_ORDER_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.AMP_ELIGIBILTY_CHECK:
					ampEligibilityCheck(execution,orderId);
					break;
				case BpmConstant.ORDER_STATUS_CHECK:
					orderStatusCheck(execution);
					break;
				case BpmConstant.ORDER_STATUS_UPDATE:
					orderStatusUpdate(execution);
					break;
				case BpmConstant.NEW_ORDER_POST_OPERATION:
					postOperation(execution);
					break;
				} 
			 }else {
				 logger.error("@@@@ operationType is null :::" + operationType, this); 
			 }
		} catch (CamundaServiceException e) {
			execution.setVariable("ERROR_CODE", "ErrorCodeConstant.COMET_MB001");
			throw new CamundaServiceException("In proper request from comet app");
		}
	}

	private void postOperation(DelegateExecution execution) {
		logger.info("Starting postOperation method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			
			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				//update order status as in production
				commonBO.setOrderStatusId(1009L);
				orderDAO.updateOrderStatus(orderId, 1009L);
				commonBO.setApproved(BpmConstant.APPROVED);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				//coreProcessService.cancelOrderPostOperation(commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}
		} catch (Exception e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure Post Operation"), this);
			throw new BpmnError("ERROR_BPM_001", "NEW ORDER");
		}
		logger.info("Ending postOperation method ");

		
	}

	private void preOperation(DelegateExecution execution) {
		logger.info("Starting preOperationCR method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		CommonBO commonBO = null;
		String newOrderProcessInstanceId = execution.getProcessInstanceId();
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
				if (null != commonBO) {
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessInstanceId(newOrderProcessInstanceId);
					commonBO.setBpmProcessId(1033L);
					//avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (CamundaServiceException e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TTU Applicability TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Ending preOperationCR method ");
		
	}

	private void orderStatusUpdate(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting orderStatusUpdate method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		CommonBO commonBO = null;
		String isTTURequired = (String) execution.getVariable(BpmConstant.IS_TTU_REQUIRED);
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setOrderStatusId(1047L);
		coreProcessDelegateHelper.updateOrderStaus(commonBO);
		coreProcessDelegateHelper.updateAuditOrderStaus(commonBO);
		execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		execution.setVariable(BpmConstant.IS_TTU_REQUIRED, isTTURequired);
		logger.info("Ending orderStatusUpdate method ");
		
	}

	/**
	 * APM ELIGIBILTY 
	 * @param execution
	 */
	private void ampEligibilityCheck(DelegateExecution execution,Long orderId) {
		logger.info("Start ampEligibilityCheck method ::", this);
		if(null!=orderId && null!=execution) {
			coreProcessDelegateHelper.checkApmEligibility(execution, orderId);
		}else {
			 logger.error("@@@@ NO ORDER ID and OPERATIONYPE", this);	
		}
		logger.info("Existing ampEligibilityCheck method ::", this);
	}
	
	/**
	 *  ORDER STATUS CHECK 
	 * @param execution
	 */
	private void orderStatusCheck(DelegateExecution execution) throws CamundaServiceException{
		logger.info("Start orderStatusCheck method ::", this);
		CommonBO commonBO = null;
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);	
			if(null!=orderId) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if(commonBO!=null && null!=commonBO.getOrderStatusId()) {
					String orderStatus = commonBO.getOrderStatusName();	
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.ORDER_STATUS, orderStatus);
				}
				//update order status "Implementation In-Progress"
				commonBO.setUpdatedBy(commonBO.getAttuid());
				commonBO.setOrderStatusId(1046L);
				coreProcessDelegateHelper.updateOrderStaus(commonBO);
				coreProcessDelegateHelper.updateAuditOrderStaus(commonBO);
			}else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		}
		catch(CamundaServiceException e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TO GET ORDER STATUS"));
		}
		logger.info("Existing orderStatusCheck method ::", this);
	}

}

	
