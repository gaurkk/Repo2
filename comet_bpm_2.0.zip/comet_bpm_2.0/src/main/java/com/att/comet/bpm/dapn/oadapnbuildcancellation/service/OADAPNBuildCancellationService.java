package com.att.comet.bpm.dapn.oadapnbuildcancellation.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OADAPNBuildCancellationService {
	public void preOperationOADAPNBuildCancellation(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

	public void postOperationOADAPNBuildCancellation(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;
}
