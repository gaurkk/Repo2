package com.att.comet.bpm.om.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusStepHistoryDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusinessStepDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.OrderStatusHistoryDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.oa.helper.OAApprovalHelper;

@Component
public class OMApprovalHelper {
	private static final Logger logger = LoggerFactory.getLogger(OAApprovalHelper.class);

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	private BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	@Autowired
	private OrderStatusHistoryDAO orderStatusHistoryDAO;
	@Autowired
	private OrderTypeRepository orderTypeRepository;
	@Autowired
	private BpmOrderBusinessStepDAO bpmOrderBusinessStepDAO;
	@Autowired
	private BpmOrderBusStepHistoryDAO bpmOrderBusStepHistoryDAO;
	@Autowired
	private OrderContactInfoDAO orderContactInfoDAO;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;

	public void omPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method omPreOprCRUD", this);
		Long orderTypeId;
		commonBO.setBpmProcessInstanceId(processInstanceId);
		commonBO.setProcessId(1002L);
		bpmDAO.deleteBpmOrderProcessByOrderIdAndProcessId(commonBO);

		/* INSERT record into AVOS_Process_Instances */
		commonBO.setBpmProcessId(1002L);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

		/* INSERT record into BPM_ORDER_PROCESS */
		orderTypeId = orderTypeRepository.getOrderTypeId(commonBO.getOrderTypeName());
		commonBO.setOrderTypeId(orderTypeId);
		commonBO.setProcessId(1002L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);

		/* UPDATE record into Orders */
		commonBO.setOrderStatusId(1005L);
		orderDAO.saveOrderStatusIdByOrderId(commonBO);

		/* UPDATE record into Audit_Orders */
		auditDAO.saveOrderStatusIdByOrderId(commonBO);

		/* Deleting record from BPM_Order_Work_Step */
		commonBO.setWorkStepId(1002L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		/* Inserting record into BPM_Order_Work_Step */
		commonBO.setBpmStatusId(1001L);
		commonBO.setUpdatedOn(new Date());
		commonBO.setDisplayFlag('N');
		bpmDAO.saveBpmOrderWorkStep(commonBO);

		// Deleting BpmOrderBusinessstep record for business stepids(3002,3041,3042)
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3041L);
		businessStepIdList.add(3042L);
		businessStepIdList.add(3002L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* UPDATE record into Orders */
		commonBO.setOrderStatusId(1005L);
		orderDAO.updateOrderStatus(commonBO.getOrderId(), commonBO.getOrderStatusId());

		long count = orderDAO.countOrderEvent(commonBO);

		List<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1002L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderProcess(commonBO);

		/* INSERT 3041 & 3042 records into BPM_Order_Business_Step */
		
		logger.debug("All Set for OM Approval for OrderId ::" + commonBO.getOrderId(), this);
		logger.info("@Ending method omPreOprCRUD ", this);
	}

	public void omAppovedOprCRUD(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method omAppovedOprCRUD ", this);
		Boolean User_or_group_exist = false;
		String assigneeOM = null;
		String assigneeOS = null;
		String assigneeOSD = null;
		/* Get User_or_group, count, CRcount as per legacy implementation */
		Long count = orderDAO.countOrderEvent(commonBO);
		String crCountValue = "CR-00" + count;
		commonBO.setCrCountValue(crCountValue);

		commonBO.setOrderContactTypeId(1005L);
		assigneeOM = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOM)) {
			User_or_group_exist = true;
			commonBO.setAssignee(assigneeOM);
			commonBO.setOrderManager(assigneeOM);
		}
		/* Get OM Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assigneeOM);
			commonBO.setOmEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOmEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1003L));
		}
		// email to be sent to OM as TO in Notification , Reminder 1 , Reminder 2
		commonBO.setToEmail(commonBO.getOmEmail());

		/* Get OS Email details */
		commonBO.setOrderContactTypeId(1003L);
		assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOS)) {
			commonBO.setUser_or_group(assigneeOS);
			commonBO.setOsEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		/* Get Admin Email details */
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		/* Get OSD Email details */
		commonBO.setOrderContactTypeId(1023L);
		assigneeOSD = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOSD)) {
			commonBO.setUser_or_group(assigneeOSD);
			commonBO.setOsEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}
		
	//in case of when commonBO.getOmEmail()) is null
		if(null==commonBO.getToEmail()) {
			if(null==commonBO.getOmEmail()) {
				commonBO.setToEmail(commonBO.getAdminEmail());	
			}else {
				commonBO.setToEmail(commonBO.getOmEmail());	
			}
			
		}
		
		// email to be sent to OS and Admin as CC in Reminder 2
		if(null!=commonBO.getOmEmail()) {
		commonBO.setCcEmail(commonBO.getOmEmail() + "," + commonBO.getAdminEmail());
		}else {
			commonBO.setCcEmail(commonBO.getAdminEmail());	
		}

		/* Set Reminder1 & Reminder2 SLA Dates for OM */
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForOM(commonBO);
		logger.info("@Ending method omAppovedOprCRUD ", this);
	}

	/**
	 * OM approval POST CRUD
	 * 
	 * @param commonBO
	 */
	public void omPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method omPostOprCRUD ", this);
		if(null==commonBO.getApproved() && !CommonUtils.isNotNullEmpty(commonBO.getApproved())) { 
			String approved = (String) execution.getVariable("response"); 
			commonBO.setApproved(approved); 
		} 
		if(null==commonBO.getComments() && !CommonUtils.isNotNullEmpty(commonBO.getComments())) { 
			String comments = (String)execution.getVariable("comments"); 
			commonBO.setComments(comments); 
		}
		String assignee = null;
		commonBO.setOrderContactTypeId(1005L);

		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assignee);
		commonBO.setAttuid(assignee);
		commonBO.setOrderManager(assignee);

		commonBO.setOrderStatusId(1005L);
		orderStatusHistoryDAO.saveOshByOrderIdAndOsIdUpdatedBy(commonBO);

		commonBO.setBusinessStepId(3002L);
		commonBO.setComments(commonBO.getComments());
		commonBO.setUpdatedOn(new Date());
		commonBO.setBusinessStepStatus(commonBO.getApproved());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		bpmOrderBusStepHistoryDAO.saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(commonBO);
		//commonBO.setBpmStepId(1002L);
		commonBO.setBpmStatusId(1002L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1002L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setUpdatedOn(new Date());
		commonBO.setDisplayFlag('N');
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		//bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);

		

		if (commonBO.getApproved().equalsIgnoreCase("Approved")) {
			commonBO.setResponseHTAction("Order Review (OM) - Approved");
		} else {
			commonBO.setResponseHTAction("Order Review (OM) - Rejected");
		}
		commonBO.setRoleId(1003L);
		updatingCommentsForOMApprovedOrRejected(commonBO);
		logger.info("@Ending method omPostOprCRUD ", this);
	}

	/**
	 * Updating OM Approver Comment
	 * 
	 * @param commonBO
	 */
	private void updatingCommentsForOMApprovedOrRejected(CommonBO commonBO) throws CamundaServiceException {
		/// Need to check order Type from Initial FE request from Main delegate
		if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_REQUEST)) {
			logger.info("@Starting method updatingCommentsForOMApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			commonBO.setOrderProcess(commonBO.getCrCountValue());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_ORDER)) {
			logger.info("@Starting method updatingCommentsForOMApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			commonBO.setOrderProcess("New");
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else {
			logger.info("@Starting method updatingCommentsForOMApprovedOrRejected ::" + commonBO.getOrderOperation(),
					this);
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		}
	}

	/**
	 * OM Rejection
	 * 
	 * @param commonBO
	 */
	public void omRejectedOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method omRejectedOprCRUD ", this);
		String rejected = (String) execution.getVariable("response");
		String  comments = (String) execution.getVariable("comments");
		commonBO.setApproved(rejected);
		commonBO.setComments(comments);
		commonBO.setOrderStatusId(1007L);
		orderDAO.updateOrders(commonBO);

		orderDAO.saveOrderStatusHistory(commonBO);

		commonBO.setBusinessStepId(3103L);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		auditDAO.updateAuditOrders(commonBO);

		commonBO.setResponseHTAction("Order Update (OM) - Completed for OM Rejection");

		updatingCommentsForOMApprovedOrRejected(commonBO);

		commonBO.setOrderStatusId(1007L);
		orderStatusHistoryDAO.saveOshByOrderIdAndOsIdUpdatedBy(commonBO);

		// EMAIL WORK TODO
		commonBO.setWorkStepId(1002L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		bpmDAO.deleteBpmOrderProcessbyOrderProcessName(commonBO);

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		logger.info("@Ending method omRejectedOprCRUD ", this);
	}
}
