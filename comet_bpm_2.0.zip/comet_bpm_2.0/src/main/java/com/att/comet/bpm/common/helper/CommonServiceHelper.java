package com.att.comet.bpm.common.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.config.CometYamlPropertySourceFactory;

@Component
@Configuration
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class CommonServiceHelper {
	private static final Logger logger = LoggerFactory.getLogger(CommonServiceHelper.class);
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	CommonService commonService;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	@Autowired
	GenericDAO genericDAO;

	// This Method for ALL SINGLE TASK WHEN ANY CR CREATED AGAINST
	// ALSO WHEN ANY 1 CR OA CREATED AGAINST ANY NEW ORDER OA TASK

	public void taskCompletedService(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("Staring taskCompletedService for Order  :::  " + commonBO.getOrderId(), this);
		BpmTask bpmTask = new BpmTask();
		Orders order = new Orders();
		Long orderId = commonBO.getOrderId();
		Long taskId = commonBO.getTaskId();
		bpmTask.setTaskId(taskId);
		Long taskStatusId = 1001L;
		order.setOrderId(orderId);
		String inProgressTask = null;
		String inProgressProcess = null;
		String taskSuject = null;
		Long roleId = 0L;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (taskObj.getBpmTask().getTaskId().equals(taskId)
						&& taskObj.getTaskStatus().getTaskStatusId().equals(taskStatusId)) {
					logger.info("@@@@ in progress Process :::  " + taskObj.getProcessInstanceId()
							+ "   @@@@ in progress BPM Task Id ::: " + taskObj.getBpmTaskId(), this);
					commonBO.setBpmTaskId(taskObj.getBpmTaskId());
					inProgressProcess = taskObj.getProcessInstanceId();
					inProgressTask = taskObj.getBpmTaskId();
					roleId = taskObj.getRole().getRoleId();
					taskSuject = taskObj.getSubject();
					break;
				} else {
					logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId() + " for the task :: "
							+ commonBO.getTaskId());
				}
			}
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getBpmTaskId())) {
			// execution.getProcessEngine().getTaskService().complete(commonBO.getBpmTaskId(),
			// variables);
			// execution.getProcessEngine().getRuntimeService().
			execution.getProcessEngine().getRuntimeService().deleteProcessInstance(inProgressProcess, "deleteReason",
					true, true, true);
			// update the database
			commonBO.setTaskDescription(taskSuject);
			commonBO.setProcessInstanceId(inProgressProcess);
			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);// Completed
			commonBO.setBpmTaskId(inProgressTask);
			commonBO.setRoleId(roleId);
			commonBO.setTaskId(taskId);
			commonService.updateOrderUserBpmTasksRepository(commonBO);
		} else {
			logger.error("bpmTaskId is null for the order :: " + commonBO.getOrderId());
		}
		logger.info("Staring taskCompletedService for Order  :::  " + commonBO.getOrderId(), this);
	}

	public void terminateAllTasks(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("Staring terminateAllTasks for Order  :::  " + commonBO.getOrderId(), this);
		BpmTask bpmTask = new BpmTask();
		Orders order = new Orders();
		Long orderId = commonBO.getOrderId();
		Long taskId = commonBO.getTaskId();
		bpmTask.setTaskId(taskId);
		Long taskStatusId = 1001L;
		order.setOrderId(orderId);
		String inProgressTask = null;
		String inProgressProcess = null;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (taskObj.getTaskStatus().getTaskStatusId().equals(taskStatusId)
						&& (!taskObj.getBpmTask().getTaskId().equals(1038L)
								&& !taskObj.getBpmTask().getTaskId().equals(1028L))) {
					logger.info("@@@@ in progress Process :::  " + taskObj.getProcessInstanceId()
							+ "@@@@ in progress BPM Task Id ::: " + taskObj.getBpmTaskId(), this);
					inProgressProcess = taskObj.getProcessInstanceId();
					inProgressTask = taskObj.getBpmTaskId();
					if (CommonUtils.isNotNullEmpty(inProgressTask)) {
						// execution.getProcessEngine().getTaskService().complete(inProgressTask,
						// variables);
						execution.getProcessEngine().getRuntimeService().deleteProcessInstance(inProgressProcess,
								"deleteReason", true, true, true);
						// update the database
						commonBO.setProcessInstanceId(inProgressProcess);
						commonBO.setTaskCompletionTime(new Date());
						commonBO.setCategoryId(1003L);// Service
						commonBO.setTaskStatusId(1002L);// Completed
						commonBO.setBpmTaskId(inProgressTask);
						commonBO.setTaskId(taskObj.getBpmTask().getTaskId());
						commonBO.setRoleId(taskObj.getRole().getRoleId());
						commonBO.setTaskDescription(taskObj.getSubject());
						commonBO.setProcessId(taskObj.getProcessId());
						commonService.updateOrderUserBpmTasksRepository(commonBO);

					} else {
						logger.error("taskObj is null for the order :: " + commonBO.getOrderId());
					}
				} else {
					logger.info("inProgressTask is null for orderId ::  " + commonBO.getOrderId() + " for the task :: "
							+ commonBO.getTaskId());
				}
			}
		} else {
			logger.info("inProgressTaskIdList is null for orderId ::  " + commonBO.getOrderId());
		}
		logger.info("Exiting terminateAllTasks for Order  :::  " + commonBO.getOrderId(), this);
	}

	public void onHoldPreOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method onHoldPreOperation");

		/* INSERT record into AVOS_Process_Instances */
		commonBO.setBpmProcessId(1028L);// OS On hold Request Process
		//avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

		/* DELETE record from Bpm_Order_Process */
		commonBO.setBpmProcessId(1028L);// OS On hold Request Process
		bpmDAO.deleteBpmOrderProcess(commonBO);

		/* INSERT record into BPM_ORDER_PROCESS */
		commonBO.setProcessId(1028L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);

		/* UPDATE record in ORDER_ON_HOLD */
		commonBO.setOnHoldStatusId(1002L);
		orderDAO.updateOrderOnHoldStatusId(commonBO);

		/* DELETE record from BPM_ORDER_BUSINESS_STEP */
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3198L);
		businessStepIdList.add(3199L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* DELETE record from BPM_ORDER_WORK_STEP */
		commonBO.setWorkStepId(1072L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		/* INSERT record into BPM_ORDER_WORK_STEP */
		commonBO.setWorkStepId(1072L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);

		/* Get count, CRcount as per legacy implementation */
		Long count = orderDAO.countOrderEvent(commonBO);
		String crCountValue = "CR-00" + count;
		commonBO.setCrCountValue(crCountValue);

		String assigneeOS = null;
		Boolean User_or_group_exist = false;
		commonBO.setOrderContactTypeId(1003L);
		assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (assigneeOS != null || assigneeOS != "") {
			User_or_group_exist = true;
			commonBO.setAssignee(assigneeOS);
			commonBO.setOrderManager(assigneeOS);
		}

		/* Get OS Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assigneeOS);
			commonBO.setOsEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		// email to be sent to OS as TO in Notification , Reminder 1 , Reminder 2
		commonBO.setToEmail(commonBO.getOsEmail());

		/* Get Admin Email details */
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		/* Get OA Email details */
		String assigneeOA = null;
		commonBO.setOrderContactTypeId(1004L);
		assigneeOA = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOA)) {
			commonBO.setUser_or_group(assigneeOA);
			commonBO.setOaEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOaEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
		}

		/* Get OSD Email details */
		String assigneeOSD = null;
		commonBO.setOrderContactTypeId(1023L);
		assigneeOSD = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOSD)) {
			commonBO.setUser_or_group(assigneeOSD);
			commonBO.setOsdEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsdEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Ending Method onHoldPreOperation");
	}

	public void onHoldCancelOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method onHoldCancelOperation");
		String cancelNotes = orderDAO.getOrderOnHoldCancelNotes(commonBO);
		commonBO.setComments(cancelNotes);
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Ending Method onHoldCancelOperation");

	}

	public void onHoldResumeOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method onHoldResumeOperation");
		String resumeNotes = orderDAO.getOrderOnHoldResumeNotes(commonBO);
		commonBO.setComments(resumeNotes);
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Ending Method onHoldResumeOperation");

	}

// pickOperation to execute the even-based gateways
	public void pickOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@@@ Starting pickOperation for Expedite Order  ::: @@@  " + commonBO.getOrderId(), this);
		Long orderId = commonBO.getOrderId();
		String businessKey = Long.toString(orderId);
		execution.getProcessEngine().getRuntimeService().createMessageCorrelation("apnIWOSCreationTaskStatus")
				.processInstanceBusinessKey(businessKey).correlateAllWithResult();
		logger.info("@@@ Exiting pickOperation for Expedite Order  ::: @@@  " + commonBO.getOrderId(), this);
	}

	public void pickOperationForBillingTask(CommonBO commonBO, DelegateExecution execution) {
		logger.info("@@@ Starting pickOperation for Change Request  ::: @@@  " + commonBO.getOrderId(), this);
		Long orderId = commonBO.getOrderId();
		String businessKey = Long.toString(orderId);
		String billingTaskStatus = null;
		String iwosHlrTaskStatus = null;
		String apnItOpsTaskStatus = null;
		String apnIwosTaskStatus = null;
		String niTaskStatus = null;
		String iwosHlrCompleteTaskStatus = null;
		Orders order = new Orders();
		order.setOrderId(orderId);
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (null != taskObj) {
					if (taskObj.getBpmTask().getTaskId().equals(1020L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						billingTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("@@@  billingTaskStatus @@@  :: " + billingTaskStatus, this);
					} else if (taskObj.getBpmTask().getTaskId().equals(1021L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						apnItOpsTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("apnItOpsTaskStatus  :: " + apnItOpsTaskStatus, this);
						
					} else if (taskObj.getBpmTask().getTaskId().equals(1016L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						apnIwosTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("apnIwosTaskStatus  :: " + apnIwosTaskStatus, this);
						
					} else if (taskObj.getBpmTask().getTaskId().equals(1060L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						iwosHlrTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("iwosHlrTaskStatus  :: " + iwosHlrTaskStatus, this);
						
					} else if (taskObj.getBpmTask().getTaskId().equals(1019L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						niTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("niTaskStatus  :: " + niTaskStatus, this);
						
					} else if (taskObj.getBpmTask().getTaskId().equals(1015L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						iwosHlrCompleteTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
						logger.info("iwosHlrCompleteTaskStatus  :: " + iwosHlrCompleteTaskStatus, this);
						
					}

				}else {
					logger.error("@@@ taskObj is null @@@ :::", this);
				}
			}
			if ((null == billingTaskStatus || billingTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
					&& (null == apnItOpsTaskStatus || apnItOpsTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
					&& (null == apnIwosTaskStatus || apnIwosTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
					&& (null == iwosHlrTaskStatus || iwosHlrTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
					&& (null == niTaskStatus || niTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))
					&& (null == iwosHlrCompleteTaskStatus || iwosHlrCompleteTaskStatus.equalsIgnoreCase(BpmConstant.COMPLETED))) {

				logger.info(" ::: @@@ pickOperation is for Pending Billing task   @@@ ::::");
				execution.getProcessEngine().getRuntimeService().createMessageCorrelation("billingTaskStatus")
						.processInstanceBusinessKey(businessKey).correlateAllWithResult();

			} else {
				logger.info("@@@ some inprogress task are there for Order @@@  :::  " + commonBO.getOrderId(), this);
			}
				
			logger.info("@@@ Exiting pickOperation for Expedite Order @@@  :::  " + commonBO.getOrderId(), this);

		}
	}
	public void crPendingTasks(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		Orders order = new Orders();
		Long orderId = commonBO.getOrderId();
		Long taskStatusId = 1001L;
		order.setOrderId(orderId);
		String inProgressTask = null;
		String inProgressProcess = null;
		String taskSuject = null;
		Long roleId = 0L;
		Long taskId=0L;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (taskObj.getTaskStatus().getTaskStatusId().equals(taskStatusId)) {
					logger.info("@@@@ in progress Process :::  " + taskObj.getProcessInstanceId()
							+ "   @@@@ in progress BPM Task Id ::: " + taskObj.getBpmTaskId(), this);
					commonBO.setBpmTaskId(taskObj.getBpmTaskId());
					inProgressProcess = taskObj.getProcessInstanceId();
					inProgressTask = taskObj.getBpmTaskId();
					roleId = taskObj.getRole().getRoleId();
					taskSuject = taskObj.getSubject();
					taskId = taskObj.getBpmTask().getTaskId();
					break;
				} else {
					logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId() + " for the task :: "
							+ commonBO.getTaskId());
				}
			}
		}
		if (CommonUtils.isNotNullEmpty(inProgressProcess) && (taskId.equals(1022L) || taskId.equals(1023L) 
				|| taskId.equals(1024L) || taskId.equals(1025L) || taskId.equals(1026L)
				|| taskId.equals(1027L) || taskId.equals(1051L))){
			execution.getProcessEngine().getRuntimeService().deleteProcessInstance(inProgressProcess, "deleteReason",
					true, true, true);
			// update the database
			commonBO.setTaskDescription(taskSuject);
			commonBO.setProcessInstanceId(inProgressProcess);
			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);// Completed
			commonBO.setBpmTaskId(inProgressTask);
			commonBO.setRoleId(roleId);
			commonBO.setTaskId(taskId);
			commonService.updateOrderUserBpmTasksRepository(commonBO);
		} else {
			logger.error("bpmTaskId is null for the order :: " + commonBO.getOrderId());
		}

	
	}

}
