package com.att.comet.bpm.config;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Properties;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertySourceFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
/**
 * FILE TO LOAD ALL PROPERTY RESOURCE
 * @author pd6080
 *
 */
public class CometYamlPropertySourceFactory implements PropertySourceFactory{
	private static final Logger logger = LoggerFactory.getLogger(CometYamlPropertySourceFactory.class);
	@Override
	public PropertySource<?> createPropertySource(String name, EncodedResource resource) throws IOException {
		logger.info("Start for createPropertySource",this);
		Properties propertiesFromYaml = loadYamlIntoProperties(resource);
		String sourceName = name != null ? name : resource.getResource().getFilename();
		logger.info("End for createPropertySource");
		return new PropertiesPropertySource(sourceName, propertiesFromYaml);
	}

	private Properties loadYamlIntoProperties(EncodedResource resource) throws FileNotFoundException {
		logger.info("Start for loadYamlIntoProperties",this);
		try {
			YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
			factory.setResources(resource.getResource());
			factory.afterPropertiesSet();
			logger.info("End for loadYamlIntoProperties");	
			return factory.getObject();
		} catch (IllegalStateException e) {
			Throwable cause = e.getCause();
			if (cause instanceof FileNotFoundException)
				throw (FileNotFoundException) e.getCause();
			throw e;
		}
	}
}
