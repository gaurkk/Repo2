package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Search Filters. Mapped to FILTERS table in the database.
 */
@Entity
@Table(name = "FILTERS")
public class Filters implements Serializable {

	private static final long serialVersionUID = -1288311579177991732L;

	@Id
	@Column(name = "FILTER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_FILTER_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_FILTER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_FILTER_ID")
	private Long filterId;

	@Column(name = "NAME", nullable = false, length = 50)
	private String name;

	@Column(name = "ATTUID", nullable = false, length = 50)
	private String attuid;

	@Column(name = "ROLE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long roleId;

	@Column(name = "EDITABLE", length = 1)
	private Character editable = new Character('Y');

	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "UPDATED_ON")
	private Date updatedOn;

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "filters", cascade = { CascadeType.ALL })
	private Set<CustomFilters> customfilters = new LinkedHashSet<CustomFilters>();

	/**
	 * @return the filterId
	 */
	public Long getFilterId() {
		return filterId;
	}

	/**
	 * @param filterId the filterId to set
	 */
	public void setFilterId(Long filterId) {
		this.filterId = filterId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the attuid
	 */
	public String getAttuid() {
		return attuid;
	}

	/**
	 * @param attuid the attuid to set
	 */
	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the editable
	 */
	public Character getEditable() {
		return editable;
	}

	/**
	 * @param editable the editable to set
	 */
	public void setEditable(Character editable) {
		this.editable = editable;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the customfilters
	 */
	public Set<CustomFilters> getCustomfilters() {
		return customfilters;
	}

	/**
	 * @param customfilters the customfilters to set
	 */
	public void setCustomfilters(Set<CustomFilters> customfilters) {
		this.customfilters = customfilters;
	}
}
