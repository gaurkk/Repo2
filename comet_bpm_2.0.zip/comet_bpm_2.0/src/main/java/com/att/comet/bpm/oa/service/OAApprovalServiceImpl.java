package com.att.comet.bpm.oa.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.oa.helper.OAApprovalHelper;


@Service
public class OAApprovalServiceImpl implements OAApprovalService {
		
	@Autowired
	OAApprovalHelper oaApprovalHelper;
	@Autowired
	CommonService commonService;
	
	@Override
	public void preOperation(CommonBO commonBO,String processInstanceId) throws CamundaServiceException {
		oaApprovalHelper.oaPreOprCRUD(commonBO,processInstanceId);
		oaApprovalHelper.oaAppovedOprCRUD(commonBO);
	}


	@Override
	public void approvedByOA(CommonBO commonBO ,DelegateExecution execution) throws CamundaServiceException{
		oaApprovalHelper.oaPostOprCRUD(commonBO,execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Completed 
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

	@Override
	public void rejectedByOA(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException {
		oaApprovalHelper.oaRejectedOprCRUD(commonBO,execution);
		oaApprovalHelper.oaPostOprCRUD(commonBO,execution);
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Completed 
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}



}
