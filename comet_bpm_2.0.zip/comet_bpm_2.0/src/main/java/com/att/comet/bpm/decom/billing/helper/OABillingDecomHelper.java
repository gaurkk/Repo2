package com.att.comet.bpm.decom.billing.helper;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OABillingDecomHelper {
	private static final Logger logger = LoggerFactory.getLogger(OABillingDecomHelper.class);

	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private OrderDAO orderDAO;

	public void preOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		logger.info("Start preOperationOABillingDecom method ::", this);
		String assignee = null;

		boolean User_or_group_exist = false;

		commonBO.setOrderContactTypeId(1004L); // ORDER_CONTACT_Type table , ORDER_CONTACT_TYPE_NAME = Order
		// Approver
		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);

		if (CommonUtils.isNotNullEmpty(assignee)) {
			User_or_group_exist = true;
			commonBO.setAssignee(assignee);
			commonBO.setAttuid(assignee);
		}
		/* Get OA Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assignee);
			commonBO.setOaBillingEmailSql(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOaBillingEmailSql(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
		}
		commonBO.setToEmail(commonBO.getOaBillingEmailSql());
		commonBO.setCcEmail("");

		genericDAO.setReminder1And2FromSlaWorkingDayForOABillingDecom(commonBO);

		commonBO.setBpmProcessId(1014L); //Mapped with BPM_PROCESS table ; COMET DECOMMISSION PROCESS
		logger.info("End preOperationOABillingDecom method ::", this);
	}

	public void postOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		logger.info("Start postOperationAPNIWOSDecom method ::", this);
		
		String assignee = null;
		commonBO.setOrderContactTypeId(1004L); // ORDER_CONTACT_Type table , ORDER_CONTACT_TYPE_NAME = Order Approver
		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAttuid(assignee);
		
		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3094L);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3094L);
		commonBO.setBusinessStepStatus("DECOMMISSION_COMPLETE");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);

		/* Update OrderContactInfo */
		commonBO.setOrderContactTypeId(1004L);
		orderDAO.updateOrderContactInfo(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setWorkStepId(1035L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		orderDAO.updateOrderBillingTask(commonBO);

		logger.info("End postOperationAPNIWOSDecom method ::", this);
	}

}
