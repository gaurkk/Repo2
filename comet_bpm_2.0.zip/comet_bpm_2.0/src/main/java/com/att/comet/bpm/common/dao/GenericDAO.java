package com.att.comet.bpm.common.dao;

import java.math.BigDecimal;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface GenericDAO {

	String getOrderManagerApprovalUserTaskAssigneeByOrderId(CommonBO commonBO);

	String getEmailFromUsersByActiveAndUserorgroup(CommonBO commonBO);

	String getEmailFromUsersAndUserRoleByOrderApproverRoleIdAndActiveAndApproved(long roleId);

	String getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(CommonBO commonBO)
			throws CamundaServiceException;

	String getEmailFromUsersAndUserRoleByCometAdminRoleIdAndActiveAndApproved(CommonBO commonBO);

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForOA(CommonBO commonBO) throws CamundaServiceException;

	String getEmailByOrderIdAndContactTypeId(CommonBO commonBO);

	void updateBpmOrderExpedite(CommonBO commonBO);

	void setReminder1And2FromSlaWorkingDayForAPNIWO_CREATION(CommonBO commonBO);

	String isAmpEligiblity(Long orderId);

	void setReminder1And2FromSlaWorkingDayForOABilling(CommonBO commonBO);

	String getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(long roleId) throws CamundaServiceException;

	String getEmailAssignedUserFromUsersByActiveAndUserorgroup(CommonBO commonBO) throws CamundaServiceException;

	void setReminderCROrderApproval(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForNIOrdeUpdate(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForApnHlrCreation(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForApnHlrCompletion(CommonBO commonBO) throws CamundaServiceException;

	Long getAmpReqStatus(CommonBO commonBO);

	void setReminder1And2FromSlaWorkingDayForAPNHLRDecom(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForDashboardDecom(CommonBO commonBO) throws CamundaServiceException;

	String checkSharedMPLS(Long orderId);

	void setReminder1And2FromSlaWorkingDayForAPNIWOSDecom(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForOABillingDecom(CommonBO commonBO) throws CamundaServiceException;

	void getDapnBillingSla(CommonBO commonBO);

	void updateDAPNInventory(CommonBO commonBO);

	void setReminderFromSlaWorkingDayForOnHoldRequest(CommonBO commonBO) throws CamundaServiceException;

	void setReminderFromSlaWorkingDayForOnHoldRequestTask(CommonBO commonBO) throws CamundaServiceException;

	void setReminderXFromSlaWorkingDayForOnHoldRequest(CommonBO commonBO) throws CamundaServiceException;;

	void setReminder1And2FromSlaWorkingDayForOADAPNBuildCancellation(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForITOPSDAPNCancellation(CommonBO commonBO) throws CamundaServiceException;

	void deleteBpmOrderBusStepHistory(Long orderId, Long businessStepId);

	void setBillingSLA(CommonBO commonBO);

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForOM(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNIWO_COMPLETION(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCRDashboard(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCODashboard(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCancelDashboard(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCancelOABilling(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForNIIWOSRollback(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForConfirmationDecom(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUPreflight(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUApplicability(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1_2_3_4FromSlaWorkingDayByAdminConfigIdForTTUSchedule(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUPerformStatus(CommonBO commonBO)
			throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUResult(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNITOPS(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForITOPSDAPNRelease(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForDAPNBilling(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForExpediteOA(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForExpediteOM(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForExpediteOSD(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForExpediteNI(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForDAPNOA(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForITOPSDAPN(CommonBO commonBO) throws CamundaServiceException;

	void setReminder1And2FromSlaWorkingDayForITOPSDAPNOS(CommonBO commonBO) throws CamundaServiceException;

	String getApnName(Long orderId);

}
