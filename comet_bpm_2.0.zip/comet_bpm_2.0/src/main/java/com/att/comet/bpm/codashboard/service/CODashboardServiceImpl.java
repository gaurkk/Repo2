package com.att.comet.bpm.codashboard.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class CODashboardServiceImpl implements CODashboardService {
	private static final Logger logger = LoggerFactory.getLogger(CODashboardServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired 
	GenericDAO genericDAO;
	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperation");
		List<String> ccspmEmailList = null;
		// fetching dynamic user from order_contact_info table
		commonBO.setProcessId(1020L);
		commonBO.setBpmProcessId(1020L);
		commonBO.setOrderContactTypeId(1006L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String ccsPM = attUidList.get(0);
			commonBO.setAttuid(ccsPM);
			commonBO.setAssignee(ccsPM);
			ccspmEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(ccspmEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1005L);
			ccspmEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(ccspmEmailList);
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
		}
		// Dashboard SLA
		// select cast(SLA_Working_Day(TIMESTAMP '2020-06-09 20:40:48',1084) as
		// timestamp(3))targetSLADate from dual
		// select cast(SLA_Working_Day(TIMESTAMP '2020-06-09 20:40:48',1085) as
		// timestamp(3))targetSLADate from dual
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3156L);
		businessStepIdList.add(3157L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		commonBO.setWorkStepId(1054L);
		commonBO.setBpmStatusId(1001L);
		commonBO.setUpdatedOn(new Date());
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForCancelDashboard(commonBO);
		
	}

	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBusinessStepId(3123L);
		commonBO.setOrderTypeId(1002L);
		String taskStatus = bpmDAO.findBpmOrderBusinessStepById(commonBO) != null
				? bpmDAO.findBpmOrderBusinessStepById(commonBO).getBusinessStepStatus()
				: null;
		if (CommonUtils.isNotNullEmpty(taskStatus)) {
			logger.info("task Status of Change Request Dashboard Task is ::  " + taskStatus);
			commonBO.setBusinessStepStatus("true");
		} else {
			commonBO.setBusinessStepStatus("false");
			logger.info("task Status of Change Request Dashboard Task is ::  " + taskStatus);
		}
		// update bpm_order_work_step
		commonBO.setWorkStepId(1054L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// update bpm_order_business_step
		commonBO.setBusinessStepId(3133L);
		commonBO.setUpdatedOn(new Date());
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepValue("Completed");
		commonBO.setComments(commonBO.getComments());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

	}

}
