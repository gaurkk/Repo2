package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.OrderType;


@Repository
public interface OrderTypeRepository extends JpaRepository<OrderType, Long> {
	@Query("select orderTypeId from OrderType where orderTypeName = :ordertypename")
	Long getOrderTypeId(String ordertypename);
}
