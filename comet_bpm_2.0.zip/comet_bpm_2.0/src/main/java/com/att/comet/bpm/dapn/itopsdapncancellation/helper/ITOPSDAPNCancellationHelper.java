package com.att.comet.bpm.dapn.itopsdapncancellation.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class ITOPSDAPNCancellationHelper {
	private static final Logger logger = LoggerFactory.getLogger(ITOPSDAPNCancellationHelper.class);
	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private BpmOrderWorkStepDAO bpmOrderWorkStepDAO;

	public void preOperationITOPSDAPNCancellation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start preOperationITOPSDAPNCancellation method ::", this);
		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3218L);
		businessStepIdList.add(3219L);
		businessStepIdList.add(3220L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		// Delete BpmOrderWorkStep
		commonBO.setWorkStepId(1079L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		// Save BpmOrderWorkStep
		commonBO.setWorkStepId(1079L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayForOADAPNBuildCancellation(commonBO);
	
		commonBO.setOrderContactTypeId(1024L);
		String attuid = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(attuid)) {
			commonBO.setAttuid(attuid);
			commonBO.setAssignee(attuid);
			commonBO.setToEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));

		} else {
			commonBO.setToEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1008L));

		}
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		//commonBO.setCcEmail((commonBO.getToEmail() + "," + commonBO.getAdminEmail()) + "," + omEmail1 + "," + niEmail1);

		genericDAO.setReminder1And2FromSlaWorkingDayForITOPSDAPNCancellation(commonBO);
		logger.info("End preOperationITOPSDAPNCancellation method ::", this);
	}

	public void postOperationITOPSDAPNCancellation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start postOperationITOPSDAPNCancellation method ::", this);
		// Update BpmOrderWorkStep
		commonBO.setWorkStepId(1079L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3218L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		// Delete BpmOrderBusStepHistory
		genericDAO.deleteBpmOrderBusStepHistory(commonBO.getOrderId(), 3218L);


		// Save BpmOrderBusinessStep
		/*
		 * commonBO.setBusinessStepValue(commonBO.getTicketNum());
		 * commonBO.setBusinessStepId(3218L); bpmDAO.saveBpmOrderBusinessStep(commonBO);
		 */
		

		// Save BpmOrderBusStepHistory
		commonBO.setBusinessStepId(3218L);
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);

		// Update OrderContactInfo
		/*
		 * commonBO.setOrderContactTypeId(1024L);
		 * orderDAO.updateOrderContactInfo(commonBO);
		 */

		// Update OrderContactInfo
		commonBO.setBpmStatusId(1002L);
		commonBO.setProcessId(1031L);
		bpmDAO.updateBpmOrderProcess(commonBO);
		logger.info("End postOperationITOPSDAPNCancellation method ::", this);
	}
}
