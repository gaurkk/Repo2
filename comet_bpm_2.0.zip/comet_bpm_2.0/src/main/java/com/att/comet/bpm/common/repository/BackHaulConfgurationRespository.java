package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.BackhaulConfig;

public interface BackHaulConfgurationRespository extends JpaRepository<BackhaulConfig, Long>{
	//BackhaulConfig
	}
