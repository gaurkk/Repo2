package com.att.comet.bpm.ttu.delegate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Component
public class OSDTTUProcessDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUProcessDelegate.class);

	@Autowired
	private CommonService commonService;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		Map<String, Object> variables = execution.getVariables();
		String operationType = (String) variables.get("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.TTU_PRE_OPERATION:
				ttuProcessPreOpration(execution);
				break;
			case BpmConstant.AMP_ELIGIBILTY_CHECK:
				ampEligibilityCheck(execution);
				break;
			case BpmConstant.UPDATE_AMP_SKIP:
				updateAmpSkip(execution);
				break;
			case BpmConstant.POST_OPERATION:
				ttuProcessPostOperation(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void updateAmpSkip(DelegateExecution execution) {
		logger.info("Existing updateAmpSkip method ::", this);
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		execution.getVariable(BpmConstant.ORDER_OPERATION);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		logger.info("Start ampEligibilityCheck method ::", this);
		if (null != orderId && null != execution) {
			List<Long> orderFlagIdList = new ArrayList<Long>();
			orderFlagIdList.add(1003L);
			orderFlagIdList.add(1004L);
			commonBO.setFlagIdList(orderFlagIdList);
			commonBO.setOrderFlagValue("N");
			coreProcessDelegateHelper.updateAmpSkip(commonBO);
		}
		logger.info("Existing updateAmpSkip method ::", this);

	}

	private void ampEligibilityCheck(DelegateExecution execution) {
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		execution.getVariable(BpmConstant.ORDER_OPERATION);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		logger.info("Start ampEligibilityCheck method ::", this);
		if (null != orderId && null != execution && (orderOperation.equalsIgnoreCase(BpmConstant.NEW_ORDER) 
				|| orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_ORDER))) {
			String ampEligible = coreProcessDelegateHelper.checkApmEligibility(execution, orderId);
			if (ampEligible.equalsIgnoreCase("true")) {
				logger.info("ampEligible :::  " + ampEligible, this);
				execution.setVariable("ampEligible", ampEligible);
				commonBO.setAmpFlag("C");
				execution.setVariable("ampFlag", "C");
			} else {
				commonBO.setAmpFlag("W");
				execution.setVariable("ampFlag", "W");
			}
		} else {
			execution.setVariable(BpmConstant.AMP_ELIGIBILTIY, "false");
			logger.error("@@@@ NO ORDER ID and OPERATIONYPE", this);
		}
		logger.info("Existing ampEligibilityCheck method ::", this);

	}

	private void ttuProcessPreOpration(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting ttuProcessPreOpration method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String isTTURequired = (String) execution.getVariable(BpmConstant.IS_TTU_REQUIRED);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null == commonBO) {
			commonBO = commonService.getCommonBO(orderId);
		} else {
			logger.debug("commonBO is not null :::: ");
		}
		commonBO.setOrderOperation(orderOperation);
		execution.setVariable(BpmConstant.IS_TTU_REQUIRED, isTTURequired);
		execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		
		
		logger.info("Ending ttuProcessPreOpration method ");
	}

	private void ttuProcessPostOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting ttuProcessPostOperation method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			// update bpm_order_process
			commonBO.setProcessId(1012L);
			commonBO.setBpmStatusId(1002L);
			bpmDAO.updateBpmOrderProcess(commonBO);
			Date today = new Date();
			// update Order status
			commonBO.setOrderStatusId(1009L);
			commonBO.setUpdatedBy(commonBO.getAttuid());
			commonBO.setUpdatedOn(today);
			orderDAO.updateOrders(commonBO);
			// update Order status_history
			commonBO.setOrderStatusId(1009L);
			commonBO.setUpdatedBy(commonBO.getAttuid());
			commonBO.setUpdatedOn(today);
			orderDAO.saveOrderStatusHistory(commonBO);
			
		logger.info("Ending ttuProcessPostOperation method ");
	}
	}

}
