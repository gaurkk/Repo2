package com.att.comet.bpm.decom.dashboard.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Component
public class DecomDashboardlHelper {
	private static final Logger logger = LoggerFactory.getLogger(DecomDashboardlHelper.class);
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	BpmDAO bpmDAO;
	
	@Autowired
	GenericDAO genericDAO;
	
	@Autowired
	OrderTypeRepository orderTypeRepository;
	
	@Autowired
	OrderContactInfoDAO orderContactInfoDAO;
	
	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;

	@Autowired
	OrderDAO orderDAO;
	
	public void preOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method preOprCRUD", this);
		//commonBO.setOrderStatusId(1065L);
		//coreProcessDelegateHelper.updateOrderStaus(commonBO);
		/* INSERT record into AVOS_Process_Instances */
		commonBO.setBpmProcessId(1014L);//Mapped with BPM_PROCESS table ; COMET DECOMMISSION PROCESS
		commonBO.setBpmProcessInstanceId(processInstanceId);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		commonBO.setProcessId(1014L);
		/* Inserting record into BPM_Order_Work_Step */
		commonBO.setWorkStepId(1060L); //Mapped with BPM_WORK_STEP table ; Decommissioning Dashboard Task
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		
		/* INSERT record into BPM_Order_Business_Step */
		commonBO.setBusinessStepId(3116L); //Mapped with BPM_BUSINESS_STEP table ; CCS_PM_Dashboard_Update_Task 
		commonBO.setBusinessStepStatus("false");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		
		/* Get CCSPM Email details */
		String assigneeCCSPM = null;
		commonBO.setOrderContactTypeId(1006L); //Mapped with ORDER_CONTACT_TYPE ; CCSPM
		assigneeCCSPM = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeCCSPM);
		if (CommonUtils.isNotNullEmpty(assigneeCCSPM)) {
			commonBO.setUser_or_group(assigneeCCSPM);
			commonBO.setCcspmEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setCcspmEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1005L)); //Mapped with ROLE table ; CCS PM 
		}
		
		commonBO.setToEmail(commonBO.getCcspmEmail()); 
		
		commonBO.setOrderTypeId(1006L); //Mapped with ORDER_TYPE ; Decommission
		if (commonBO.getApnName()!= null && !commonBO.getApnName().equalsIgnoreCase("n/a")) {
			/* INSERT record into BPM_ORDER_PROCESS for APN HLR */			
			commonBO.setProcessId(1024L); //Mapped with BPM_PROCESS table ; APN HLR/HSS IWOS Process
			bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
			commonBO.setProcessId(1005L); //Mapped with BPM_PROCESS table ; APN HLR/HSS IWOS Process
			bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		} else if (commonBO.getApnName()!= null && commonBO.getApnName().equalsIgnoreCase("n/a")){
			/* INSERT record into BPM_ORDER_PROCESS for Network IWOS*/
			commonBO.setProcessId(1005L); //Mapped with BPM_PROCESS table ; Network IWOS Process
			bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		}
		
		/* INSERT record into BPM_ORDER_PROCESS for Billing*/			
		commonBO.setProcessId(1011L); //Mapped with BPM_PROCESS table ; Process Billing Request
		bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		
		/* Set Reminder1 & Reminder2 SLA Dates for Decommission Dashboard */
		genericDAO.setReminder1And2FromSlaWorkingDayForDashboardDecom(commonBO);
		
		logger.info("@Ending method preOprCRUD ", this);		
	}

	public String checkUserEntry(CommonBO commonBO) {
		logger.info("@Starting method checkUserEntry ", this);
		String businessStepStatus = bpmDAO.getBpmOrderBusinessStepStatus(commonBO);
		logger.info("@Ending method checkUserEntry ", this);
		return businessStepStatus;
	}

	public void postOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method postOprCRUD ", this);
		
		String decomDashboardComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setComments(decomDashboardComments);
		
		String assignee = null;
		commonBO.setOrderContactTypeId(1006L);
		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assignee);
		commonBO.setAttuid(assignee);
		
		/* INSERT record into BPM_Order_Business_Step */
		commonBO.setBusinessStepId(3139L); //Mapped with BPM_BUSINESS_STEP table ; Decommissioning Dashboard Task 
		commonBO.setBusinessStepStatus("Completed");
		commonBO.setOrderTypeId(1006L); //Mapped with ORDER_TYPE ; Decommission
		commonBO.setUpdatedBy(assignee);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		
		commonBO.setOrderContactTypeId(1006L);
		commonBO.setAttuid(assignee);
		orderContactInfoDAO.updateOrderContactInfoForAttUidByOrderContactDetails(commonBO);
		
		commonBO.setBpmStatusId(1002L); //Mapped with BPM_STATUS table ; COMPLETED
		commonBO.setBpmStepId(1002L); //this is set because in bpmorderworkstepdaoimpl bpmstepid = bpmstatusid
		commonBO.setWorkStepId(1060L); //Mapped with BPM_WORK_STEP table ;Decommissioning Dashboard Task
		bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);
		
		/* Get NI Email details */
		String assigneeNI = null;
		commonBO.setOrderContactTypeId(1007L); //Mapped with ORDER_CONTACT_TYPE ; Network Implementation
		assigneeNI = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeNI)) {
			commonBO.setUser_or_group(assigneeNI);
			commonBO.setNiEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setNiEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1004L)); //Mapped with ROLE table ; Network Implementation 
		}
		
		/*
		 * List<Object[]> detailsBillingDataList = orderDAO.getBillingData(commonBO);
		 * 
		 * for (Object[] detailsBillingData : detailsBillingDataList) {
		 * commonBO.setAccountName(detailsBillingData[0].toString());
		 * commonBO.setCompanyBillingAddress(detailsBillingData[1].toString());
		 * commonBO.setCompanyContactNamePhone(detailsBillingData[2].toString());
		 * commonBO.setFederalTaxID(detailsBillingData[3].toString());
		 * commonBO.setBan(detailsBillingData[4].toString());
		 * commonBO.setFan(detailsBillingData[5].toString());
		 * commonBO.setAccountManager(detailsBillingData[6].toString());
		 * commonBO.setMobilityTechnicalEngineer(detailsBillingData[7].toString());
		 * commonBO.setApnName(detailsBillingData[11].toString());
		 * commonBO.setPdpName(detailsBillingData[12].toString());
		 * commonBO.setSourceofIPAddressing(detailsBillingData[13].toString());
		 * commonBO.setTypeofAddressing(detailsBillingData[14].toString());
		 * commonBO.setBackHaulIds(detailsBillingData[15].toString());
		 * commonBO.setBackhaulInstances(detailsBillingData[16].toString());
		 * commonBO.setMplscir(detailsBillingData[17].toString());
		 * commonBO.setEodOrder(detailsBillingData[19].toString());
		 * commonBO.setFeeWaiverApproved(detailsBillingData[20].toString());
		 * commonBO.setManagedAVPN(detailsBillingData[21].toString()); }
		 */
		logger.info("@Ending method postOprCRUD ", this);
		
	}
}
