package com.att.comet.bpm.common.modal;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CommonBO extends OrdersBO {
	private static final long serialVersionUID = 1L;
	private Long roleId;
	private List<Long> flagIdList;
	private Long businessStepId;
	private List<Long> businessStepIdList;
	private List<Long> workStepIdList;
	private Long workStepId;
	private Long bpmStepId;
	private Long processId;
	private String processInstanceId;
	private String businessStepStatus;
	private Long bpmStatusId;
	private String bpmProcessInstanceId;
	private Long bpmProcessId;
	private Long flagId;
	private String businessStepValue;
	private String activityInstanceId;
	private String processStatus;// completed/Created/
	private Date taskCreationTime;
	private Date taskCompletionTime;
	private String taskDescription;
	private String bpmTaskId; // Camunda task ID
	private Long categoryId;// Mater data table
	private Long taskStatusId;// 1001//OA Approver etc
	private String taskStatusName;
	private Date apnProductionDate;
	private Long taskId;// Mapped from BPM_task table
	private List<String> adminEmailList;
	private char displayFlag;
	private char crFlag;
	private String taskAssignee;// Common for all
	private String apnCreationStatus;
	private String crCountValue;
	private Long emailNotificationId;//Common for all 
	private boolean isAutoComplete =false; // System Auto Complete task flag
	private String orderOperation;// for all flows
	private boolean processesNotCompletedStatus = false;//for all base on Change Request FLOW
	private boolean isTerminateTask =false; ///only for those task which are terminated
	private List<Long> orderContactTypeIdList;
	private String apnSelection;
	private Date billingSla;
	private String attuid;
	private String apnIwosCreationStatus;
	private String userAction;
	private String orderProcess;
	private String statementId;
	private String urlName;
	private String User_or_group;// Please used this for user grp for email

	private String oaEmail;// its specific for OA approval
	private String orderApprover;// its specific for OA approval
	private String assignee;// its specific for OA approval
	//private boolean oaReviewResponse;// its specific for OA approval
	
	private String approved; //review response common for all 
	private String itOpsAssignee;
	private String iwosHlrAssignee;
	private String iwosAssignee;
	private String niTaskAssignee;
	private String osEmail;

	private String adminEmail;
	private String cometAdminEmailResponse;
	private String toEmail;
	private String ccEmail;
	private List<String> groupEmailList;
	private List<String> emailList;
	private Date businessStepExecutionDate;
	private String workFlowUrl;
	private String TaskUserDecision;
	private String userDecision;

	private String responseHTAction;// Please used once u have response set

	private Date reminder1SlaDate; // used this for email reminder 1
	private Date reminder2SlaDate; // used this for email reminder 2
	private Date reminder3SlaDate; // used this for email reminder 3
	private Date reminder4SlaDate; // used this for email reminder 4
	private Date dapnBillingSla;
	private Long dapnStatusId;
	private String omEmail;// its specific for OM approval
	private String orderManager;// its specific for OM approval
	private String assigneeOM;// its specific for OM approval
	private String apnhlrApprover;
	private String apnhlrAssignee;
	private String hlrHssCompleteUser;
	private String apnhlrEmailSql;
	private Date dateInProduction;
	private String ticketNum;
	private String isTTURequired;
	
	
	// Specific to OA Billing Submission
	private String oaBillingEmailSql;
	private String oaBillingComment;
	private String assigneeOABilling;
	private Date reminderBillingSlaDate;
	private String eodOrder;
  	private String feeWaiverApproved;
	private String companyBillingAddress;
	private String companyContactNamePhone;
	private String federalTaxID;
	private String ban;
	private String fan;
	private String accountManager;
	private String mobilityTechnicalEngineer;
	private String sourceofIPAddressing;
	private String typeofAddressing;
	private String backhaulInstances;
	private String mplscir;
	private String managedAVPN;
	
	private String taskDisplayName;
	private String taskName;
	private String ampFlag;
	private String omTaskStatus;
	private String apnItOpsTaskStatus;
	private String apnIwosTaskStatus;
	private String ttuPreflightTaskStatus;
	private String ttuApplicabilityTaskStatus;
	private String ttuResultTaskStatus;
	private String ttuRescheduleTaskStatus;
	private String ttuPerformTaskStatus;
	private String ttuScheduleTaskStatus;
	private String apnIwosUserDecision;
	private String billingUserDecision;
	private List<String> osdEmailList;
	private List<String> omEmailList;
	private List<String> oaEmailList;
	private List<String> niEmailList;
	private String ccspmEmail;
	private String niEmail;
	private Date expediteBuildDate;
	private String expediteReason;
	private String expediteProcessStatus;
	
	private String osdEmail;
	private Date reminderXSlaDate; // used this for email reminder X for On Hold
	private Date onHoldRequestedDate;
	private Date onHoldProposedCompletionDate;
	private String onHoldReason;
	private String onHoldNotes;
	private Long onHoldStatusId;
	private String cancelNotes;
	private String resumeNotes;
	private int countReminderEmails;
	private Long onHoldFlag; //to know resolve or cancel 
	
	//Specific for Dapn Cancelation
	private String apnType;
	private String iPType;
	private String ifStatic;
	private String mrc;
	private String ericssonCode;
	private String userDefinedPDPID;
	private String cometPdpId;
	private String companyName;
	private String ultimateAccountName;
	private String masterAccountID;
	private String accountID;
	private String pdpID;
	private String agreementAccountName;
	private String subAccountName;
	private String pmip;
	private String ocs;
	private String agreementAccountNumber;
	private String pdpPackageName;
	private String pdpPackageDesc;
	private String pdpDescription;
	
	private Long derivedFromOrderId; // Needed for CO and Decommission
	private String decomWorkFlowStarted ;

}
