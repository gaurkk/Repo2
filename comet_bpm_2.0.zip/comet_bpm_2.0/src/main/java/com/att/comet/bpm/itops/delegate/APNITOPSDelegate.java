package com.att.comet.bpm.itops.delegate;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.CometAppRequestException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.itops.service.ITOPSService;

@Component
public class APNITOPSDelegate implements JavaDelegate {
	@Autowired
	CommonService commonService;
	@Autowired
	ITOPSService iTOPSService;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;

	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	private static final Logger logger = LoggerFactory.getLogger(APNITOPSDelegate.class);
	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			if (execution.getVariable("OPERATION") != null) {
				String operationType = (String) execution.getVariable("OPERATION");
				switch (operationType) {
				case BpmConstant.PRE_OPERATION_ITOPS:
					preOperationItOpsTask(execution);
					break;
				case BpmConstant.POST_OPERATION_ITOPS:
					postOperationItOpsTask(execution);
					break;
				default:
					logger.debug("Please provide valid value for OPERATION:{}", operationType);
				}
			} else {
				logger.debug("Invalid input");
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.APN_ITOPS_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}

	}

	private void preOperationItOpsTask(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting preOperationItOpsTask method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			// boolean isTerminateTask = false;
			String ITOPSProcessInstanceId = null;
			ITOPSProcessInstanceId = execution.getProcessInstanceId();
			// CommonBO commonBO = null;
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_ITOPS_ERR_PRE_001);
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1008L);// CCS PM Role Id
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1021L);
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				if (null == commonBO) {
					commonBO = commonService.getCommonBO(orderId);
				} else {
					logger.debug("commonBO is null :::: ");
				}
				BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.ORDER_OPERATION, BpmConstant.ORDER_OPERATION);
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, commonBO.getUrlName());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());

				execution.setVariable(BpmConstant.CATEGORY, "1002");// User task

				commonBO.setOrderOperation(orderOperation);
				commonBO.setRoleId(1008L);// Setting OSD roleID
				commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
				commonBO.setTaskStatusName("ITOPS_APN_ITOPS_Task");
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(commonBO.getWorkFlowUrl());
				commonBO.setTaskId(1021L);// Mapped from BPM_task table (APN IT OPS Completion)
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setOrderOperation(orderOperation);
				commonBO.setUpdatedOn(new Date());
				iTOPSService.preOperationITOPSTask(commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
				execution.setVariable(BpmConstant.BPM_STATUS_ID, commonBO.getTaskStatusName());
				execution.setVariable(BpmConstant.USER_DECISION, commonBO.getTaskUserDecision());
				execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				
				

			} else {
				logger.error("orderID is null");
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.APN_ITOPS_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending preOperationItOpsTask method ");
	}

	private void postOperationItOpsTask(DelegateExecution execution) throws Exception {
		logger.info("Starting postOperationItOpsTask method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			String ITOPSComments = (String) execution.getVariable(BpmConstant.COMMENTS);
			String CompletionDate = (String) execution.getVariable(BpmConstant.COMPLETED_DATE);
			CommonBO commonBO = null;
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_ITOPS_ERR_POST_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1008L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1021L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			if (null != commonBO) {
				commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(CompletionDate));
				iTOPSService.postOperationITOPSTask(commonBO, ITOPSComments);
				Orders order = new Orders();
				order.setOrderId(orderId);
				Long taskId = 1021L;
				commonBO.setTaskId(1021L);
				List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
				if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
					// (1028L);//Mapped from BPM_task table (CR OA : Approval Task)
					if (taskId.equals(1021L)) {
						logger.info("Task ID request " + 1021L, this);
						for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
							if (taskObj.getBpmTask().getTaskId().equals(1021L)
									&& taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
								logger.info("bpmTaskId is :::  " + taskObj.getBpmTaskId(), this);
								commonBO.setBpmTaskId(taskObj.getBpmTaskId());
								commonBO.setTaskDescription(taskObj.getSubject());
								break;
							} else {
								logger.info("taskStatusName is null for orderId ::  " + commonBO.getOrderId()
										+ " for the task :: " + commonBO.getTaskId());
							}
						}
					}
				}

				commonBO.setRoleId(1008L);
				commonBO.setTaskStatusId(1002L);
				commonBO.setTaskCompletionTime(new Date());
				commonBO.setCategoryId(1003L);// Service
				// updating Order_user_bpm_tasks Table
				commonService.updateOrderUserBpmTasksRepository(commonBO);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.COMPLETION_DATE, CompletionDate);
				
				Long crCount = orderDAO.countOrderEvent(commonBO);
				if (null != crCount && crCount.equals(1L)) {
					logger.info("@@@ Pick Operation for Change Request @@@ "+commonBO.getOrderId(), this);
					commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
				}else if(commonBO.getOrderTypeId().equals(1004L)){
					logger.info("@@@ Pick Operation for Change Order @@@ "+commonBO.getOrderId(), this);
					commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
					
				}else {
					logger.info(" @@@ No Change Request created against the order id :::  @@@  "+commonBO.getOrderId(), this);
				}
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.APN_ITOPS_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending postOperationItOpsTask method ");
	}

}
