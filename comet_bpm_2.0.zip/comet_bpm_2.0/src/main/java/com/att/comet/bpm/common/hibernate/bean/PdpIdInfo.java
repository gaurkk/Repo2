package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for PdpIdInfo. Mapped to PDP_ID_INFO table in the database.
 */
@Entity
@Table(name = "PDP_ID_INFO")
public class PdpIdInfo implements java.io.Serializable {

	private static final long serialVersionUID = 4485265301330621563L;
	private long pdpId;
	private Apn apn;
	private Long autoPdpId;
	private Long userPdpId;
	private Character basicPdpId;
	private String autoPdpName;
	private String userPdpName;

	/**
	 * No-argument constructor of the class.
	 */
	public PdpIdInfo() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param pdpId
	 * @param apn
	 */
	public PdpIdInfo(long pdpId, Apn apn) {
		this.pdpId = pdpId;
		this.apn = apn;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param pdpId
	 * @param apn
	 * @param autoPdpId
	 * @param userPdpId
	 * @param basicPdpId
	 * @param autoPdpName
	 */
	public PdpIdInfo(long pdpId, Apn apn, Long autoPdpId, Long userPdpId,
			Character basicPdpId, String autoPdpName) {
		this.pdpId = pdpId;
		this.apn = apn;
		this.autoPdpId = autoPdpId;
		this.userPdpId = userPdpId;
		this.basicPdpId = basicPdpId;
		this.autoPdpName = autoPdpName;
	}

	/**
	 * Getter method for pdpId. PDP_ID mapped to PDP_ID in the database table.
	 * The sequence used to generate the pdpId is SEQ_PDP_ID.
	 * 
	 * @return long
	 */
	@Id
	@Column(name = "PDP_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_PDP_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_PDP_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PDP_ID")
	public long getPdpId() {
		return this.pdpId;
	}

	/**
	 * @param pdpId
	 *            to pdpId set.
	 */
	public void setPdpId(long pdpId) {
		this.pdpId = pdpId;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for autoPdpId. AUTO_PDP_ID mapped to AUTO_PDP_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "AUTO_PDP_ID", precision = 12, scale = 0)
	public Long getAutoPdpId() {
		return this.autoPdpId;
	}

	/**
	 * @param autoPdpId
	 *            to autoPdpId set.
	 */
	public void setAutoPdpId(Long autoPdpId) {
		this.autoPdpId = autoPdpId;
	}

	/**
	 * Getter method for userPdpId. USER_PDP_ID mapped to USER_PDP_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "USER_PDP_ID", precision = 12, scale = 0)
	public Long getUserPdpId() {
		return this.userPdpId;
	}

	/**
	 * @param userPdpId
	 *            to userPdpId set.
	 */
	public void setUserPdpId(Long userPdpId) {
		this.userPdpId = userPdpId;
	}

	/**
	 * Getter method for basicPdpId. BASIC_PDP_ID mapped to BASIC_PDP_ID in the
	 * database table.
	 * 
	 * @return Character
	 */
	@Column(name = "BASIC_PDP_ID", length = 1)
	public Character getBasicPdpId() {
		return this.basicPdpId;
	}

	/**
	 * @param basicPdpId
	 *            to basicPdpId set.
	 */
	public void setBasicPdpId(Character basicPdpId) {
		this.basicPdpId = basicPdpId;
	}

	/**
	 * Getter method for autoPdpName. AUTO_PDP_NAME mapped to AUTO_PDP_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AUTO_PDP_NAME", length = 100)
	public String getAutoPdpName() {
		return autoPdpName;
	}

	/**
	 * @param autoPdpName
	 *            to autoPdpName set.
	 */
	public void setAutoPdpName(String autoPdpName) {
		this.autoPdpName = autoPdpName;
	}

	/**
	 * Getter method for userPdpName. USER_PDP_NAME mapped to USER_PDP_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_PDP_NAME", length = 100)
	public String getUserPdpName() {
		return userPdpName;
	}

	/**
	 * @param userPdpName
	 *            to userPdpName set.
	 */
	public void setUserPdpName(String userPdpName) {
		this.userPdpName = userPdpName;
	}

}
