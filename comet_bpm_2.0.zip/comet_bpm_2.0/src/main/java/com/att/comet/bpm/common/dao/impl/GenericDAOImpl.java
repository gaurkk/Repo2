package com.att.comet.bpm.common.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderExpedite;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.BpmOrderExpediteRepository;

@Component
public class GenericDAOImpl implements GenericDAO {

	private static final Logger logger = LoggerFactory.getLogger(GenericDAOImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	BpmOrderExpediteRepository bpmOrderExpediteRepository;

	@PersistenceContext
	EntityManager em;

	@Override
	public String getOrderManagerApprovalUserTaskAssigneeByOrderId(CommonBO commonBO) {
		logger.info("@Starting method getOrderManagerApprovalUserTaskAssigneeByOrderId ", this);
		String attuid = null;
		String sql = "select oci.attuid from order_contact_info oci, order_contact oc, users usr where (oc.order_id =:orderId and  oci.attuid = usr.attuid and oc.order_contact_id = oci.order_contact_id and usr.active = 'Y' and oci.order_contact_type_id =:orderContactTypeId)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("orderContactTypeId", commonBO.getOrderContactTypeId());
		attuid = (String) query.getSingleResult();
		logger.info("@Ending method getOrderManagerApprovalUserTaskAssigneeByOrderId attuid= " + attuid, this);
		return attuid;
	}

	@Override
	public String getEmailFromUsersByActiveAndUserorgroup(CommonBO commonBO) {
		String email = null;
		String sql = "select email from users where active = 'Y' and attuid = :User_or_group";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("User_or_group", commonBO.getUser_or_group());
		email = (String) query.getSingleResult();
		return email;
	}

	@Override
	public String getEmailFromUsersAndUserRoleByOrderApproverRoleIdAndActiveAndApproved(long roleId) {
		String email = null;
		String sql = "select us.email from users us, user_role usro where usro.role_id = :roleId and us.attuid = usro.attuid and us.active = 'Y' and usro.approved = 'Y'";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("roleId", roleId);
		email = (String) query.getSingleResult();
		return email;
	}

	@Override
	public String getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(CommonBO commonBO)
			throws CamundaServiceException {
		String attuid = null;
		String sql = "select oci.attuid from order_contact_info oci, order_contact oc, users usr where (oc.order_id =? and  oci.attuid = usr.attuid and oc.order_contact_id = oci.order_contact_id and usr.active = 'Y' and oci.order_contact_type_id =?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderContactTypeId());
		List<String> listAttuid = query.getResultList();
		for (String obj : listAttuid) {
			if (null != obj) {
				attuid = obj;
				break;
			}
		}
		return attuid;
	}

	@Override
	public String getEmailFromUsersAndUserRoleByCometAdminRoleIdAndActiveAndApproved(CommonBO commonBO) {
		String email = null;
		String sql = "select us.email from users us, user_role usro where usro.role_id = 1006 and us.attuid = usro.attuid and us.active = 'Y' and usro.approved = 'Y'";
		Query query = entityManager.createNativeQuery(sql);
		List<String> listObject = query.getResultList();
		for (String obj : listObject) {
			if (null != obj) {
				email = obj;
				break;
			}
		}
		return email;
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForOA(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1001) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1002) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void getDapnBillingSla(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql = "select cast(SLA_Working_Day(:sysDateTime,1156) as timestamp(3))targetSLADate from dual";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("sysDateTime", todaySqlDate);
		commonBO.setDapnBillingSla((java.sql.Timestamp) query.getSingleResult());
	}

	@Override
	public void updateDAPNInventory(CommonBO commonBO) {
		String sql = "update dapn_inventory set dapn_status_id =? where order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getDapnStatusId());
		query.setParameter(2, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public void setReminderCROrderApproval(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1099) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1100) as timestamp(3))targetSLADate from dual";
		String sql3 = "select cast(SLA_Working_Day(:sysDateTime,1101) as timestamp(3))targetSLADate from dual";
		String sql4 = "select cast(SLA_Working_Day(:sysDateTime,1102) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());

		Query query3 = entityManager.createNativeQuery(sql3);
		query3.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder3SlaDate((java.sql.Timestamp) query3.getSingleResult());

		Query query4 = entityManager.createNativeQuery(sql4);
		query4.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder4SlaDate((java.sql.Timestamp) query4.getSingleResult());
	}

	@Override
	public String getEmailByOrderIdAndContactTypeId(CommonBO commonBO) {
		logger.info("@Starting method getEmailByOrderIdAndContactTypeId ", this);
		String email = null;
		String sql = "select  usr.email from order_contact_info oci ,order_contact oc , users usr  where (oc.order_id=:orderId and  oci.attuid = usr.attuid and oc.order_contact_id= oci.order_contact_id and oci.order_contact_type_id = :orderContactTypeId and usr.active = 'Y')";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("orderContactTypeId", commonBO.getOrderContactTypeId());
		email = (String) query.getSingleResult();
		logger.info("@Ending method getEmailByOrderIdAndContactTypeId attuid= " + email, this);
		return email;
	}

	@Override
	public void updateBpmOrderExpedite(CommonBO commonBO) {
		logger.info("@Starting method updateBpmOrderExpedite ", this);
		Optional<BpmOrderExpedite> bpmOrderExpediteOp = bpmOrderExpediteRepository
				.findById(commonBO.getOrderStatusId());
		if (bpmOrderExpediteOp.isPresent()) {
			BpmOrderExpedite bpmOrderExpedite = bpmOrderExpediteOp.get();
			bpmOrderExpedite.setApnIwosCreationStatus("pre");
			bpmOrderExpediteRepository.save(bpmOrderExpedite);
		}
		logger.info("@Existing method updateBpmOrderExpedite ", this);

	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForAPNIWO_CREATION(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1090) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1091) as timestamp(3))targetSLADate from dual";
		// Above query should be replaced with this
		// select cast(SLA_Working_Day({$estimatedIWOSComDate},1090) as
		// timestamp(3))targetSLADate from dual

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());
		
		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());

	}

	@Override
	public String isAmpEligiblity(Long orderId) {
		String sql = "select CHECK_AMP_ELIGIBILITY(:orderId)from dual";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", orderId);
		String isAmpEligible = (String) query.getSingleResult();
		return isAmpEligible;
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForOABilling(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1030) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1031) as timestamp(3))targetSLADate from dual";
		String sql3 = "select cast(SLA_Working_Day(:sysDateTime,1096) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());

		Query query3 = entityManager.createNativeQuery(sql3);
		query3.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminderBillingSlaDate((java.sql.Timestamp) query3.getSingleResult());
	}

	@Override
	public String getEmailAssignedUserFromUsersByActiveAndUserorgroup(CommonBO commonBO)
			throws CamundaServiceException {
		String email = null;

		String sql = "select email from users where active = 'Y' and attuid = :User_or_group";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("User_or_group", commonBO.getUser_or_group());
		List<String> listEmail = query.getResultList();
		for (String obj : listEmail) {
			if (null != obj) {
				email = obj;
			}
		}
		return email;
	}

	@Override
	public String getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(long roleId) throws CamundaServiceException {
		String email = null;
		int count = 0;
		String sql = "select us.email from users us, user_role usro where usro.role_id = :roleId and us.attuid = usro.attuid and us.active = 'Y' and usro.approved = 'Y'";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("roleId", roleId);
		List<String> listEmail = query.getResultList();
		for (String obj : listEmail) {
			if (null != obj) {
				if (count == 0) {
					email = obj;
				} else {
					email = email + "," + obj;
				}
				count++;
			}
		}
		return email;
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForNIOrdeUpdate(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1050) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1051) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForApnHlrCreation(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1127) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1134) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForApnHlrCompletion(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1135) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1136) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public Long getAmpReqStatus(CommonBO commonBO) {
		Long ampReqStatus = null;// commonBO.getUpdatedOn();
		// java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql = "SELECT EVENT_STATUS_ID FROM EXT_INTERFACE_DETAILS WHERE updated_on =(SELECT MAX(UPDATED_ON) "
				+ "FROM EXT_INTERFACE_DETAILS WHERE order_id =?)AND order_id =? AND ext_interface_id not like 'RANDOM%'";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderId());
		try {
			// ampReqStatus = (BigDecimal) query.getSingleResult() != null ? (BigDecimal)
			// query.getSingleResult() : null;
		} catch (NoResultException nre) {
			logger.info(" Exception :: " + nre.getMessage());
		}
		return null;
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForAPNHLRDecom(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1070) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1071) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForDashboardDecom(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1064) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1065) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public String checkSharedMPLS(Long orderId) {
		String sql = "select CHECK_FOR_SHARED_BACKHAUL(:orderId,1004) from dual";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", orderId);
		String sharedMPLSResponse = (String) query.getSingleResult();
		return sharedMPLSResponse;
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForAPNIWOSDecom(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1014) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1015) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForOABillingDecom(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1082) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1083) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminderFromSlaWorkingDayForOnHoldRequestTask(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1137) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1138) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());

	}

	@Override
	public void setReminderFromSlaWorkingDayForOnHoldRequest(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1139) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1140) as timestamp(3))targetSLADate from dual";
		String sql3 = "select cast(SLA_Working_Day(:sysDateTime,1141) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", commonBO.getOnHoldProposedCompletionDate());
		Timestamp reminder1Timestamp = (java.sql.Timestamp) query1.getSingleResult();
		commonBO.setReminder1SlaDate(new Date(reminder1Timestamp.getTime()));

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", commonBO.getOnHoldProposedCompletionDate());
		Timestamp reminder2Timestamp = (java.sql.Timestamp) query2.getSingleResult();
		commonBO.setReminder2SlaDate(new Date(reminder2Timestamp.getTime()));

		Query query3 = entityManager.createNativeQuery(sql3);
		query3.setParameter("sysDateTime", commonBO.getOnHoldProposedCompletionDate());
		Timestamp reminderXTimestamp = (java.sql.Timestamp) query3.getSingleResult();
		commonBO.setReminderXSlaDate(new Date(reminderXTimestamp.getTime()));
	}

	@Override
	public void setReminderXFromSlaWorkingDayForOnHoldRequest(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1141) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		Date reminderXTimestamp = (java.sql.Timestamp) query1.getSingleResult();
		commonBO.setReminderXSlaDate(new Date(reminderXTimestamp.getTime()));
	}

	@Override
	public void setBillingSLA(CommonBO commonBO) {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql = "select cast(SLA_Working_Day(:sysDateTime,1096) as timestamp(3))targetSLADate from dual";
		// select cast(SLA_Working_Day(TIMESTAMP '2020-06-19 04:13:59',1096) as
		// timestamp(3))targetSLADate from dual
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("sysDateTime", todaySqlDate);
		commonBO.setBillingSla((java.sql.Timestamp) query.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForOADAPNBuildCancellation(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1150) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1151) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForITOPSDAPN(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1146) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1147) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void deleteBpmOrderBusStepHistory(Long orderId, Long businessStepId) {
		String sql = "delete from bpm_order_bus_step_history where order_id=:orderId and business_step_id=:businessStepId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", orderId);
		query.setParameter("businessStepId", businessStepId);
		query.executeUpdate();
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForOM(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1002) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1003) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNIWO_COMPLETION(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1014) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1015) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCRDashboard(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1086) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1087) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCODashboard(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1062) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1063) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCancelDashboard(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1084) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1085) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForCancelOABilling(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1157) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1158) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForNIIWOSRollback(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1159) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1160) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForConfirmationDecom(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1066) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1067) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUPreflight(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1034) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1035) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUApplicability(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1036) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1037) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1_2_3_4FromSlaWorkingDayByAdminConfigIdForTTUSchedule(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1040) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1041) as timestamp(3))targetSLADate from dual";
		String sql3 = "select cast(SLA_Working_Day(:sysDateTime,1042) as timestamp(3))targetSLADate from dual";
		String sql4 = "select cast(SLA_Working_Day(:sysDateTime,1043) as timestamp(3))targetSLADate from dual";
		
		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		//replace todaySqlDate with ttuStarted
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		//replace todaySqlDate with ttuStarted
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
		
		Query query3 = entityManager.createNativeQuery(sql3);
		query3.setParameter("sysDateTime", todaySqlDate);
		//replace todaySqlDate with ttuStarted
		commonBO.setReminder3SlaDate((java.sql.Timestamp) query3.getSingleResult());
		
		Query query4 = entityManager.createNativeQuery(sql4);
		query4.setParameter("sysDateTime", todaySqlDate);
		//replace todaySqlDate with ttuStarted
		commonBO.setReminder4SlaDate((java.sql.Timestamp) query4.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUPerformStatus(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1044) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1045) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUResult(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1046) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1047) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNITOPS(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1008) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1009) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	
	@Override
	public void setReminder1And2FromSlaWorkingDayForITOPSDAPNRelease(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1150) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1151) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForDAPNBilling(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1148) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1149) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForExpediteOA(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1052) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1053) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForExpediteOM(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1054) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1055) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForExpediteOSD(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1056) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1057) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForExpediteNI(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1060) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1061) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}
	@Override
	public void setReminder1And2FromSlaWorkingDayForDAPNOA(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1152) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1153) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForITOPSDAPNOS(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1144) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1145) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
		
	}

	@Override
	public void setReminder1And2FromSlaWorkingDayForITOPSDAPNCancellation(CommonBO commonBO)
			throws CamundaServiceException {
		Date today = new Date();
		java.sql.Date todaySqlDate = new java.sql.Date(today.getTime());
		String sql1 = "select cast(SLA_Working_Day(:sysDateTime,1150) as timestamp(3))targetSLADate from dual";
		String sql2 = "select cast(SLA_Working_Day(:sysDateTime,1151) as timestamp(3))targetSLADate from dual";

		Query query1 = entityManager.createNativeQuery(sql1);
		query1.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder1SlaDate((java.sql.Timestamp) query1.getSingleResult());

		Query query2 = entityManager.createNativeQuery(sql2);
		query2.setParameter("sysDateTime", todaySqlDate);
		commonBO.setReminder2SlaDate((java.sql.Timestamp) query2.getSingleResult());
		
	}
	@Override
	public String getApnName(Long orderId) {
		String apnName = null;
		String sql = "select apn_name from dapn_inventory where order_id=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		apnName = (String) query.getSingleResult();
		return apnName;
	}
}
