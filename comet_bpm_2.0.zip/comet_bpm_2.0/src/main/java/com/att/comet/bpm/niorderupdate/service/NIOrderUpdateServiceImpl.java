package com.att.comet.bpm.niorderupdate.service;

import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.niorderupdate.helper.NIOrderUpdateHelper;

@Service
public class NIOrderUpdateServiceImpl implements NIOrderUpdateService {
	private static final Logger logger = LoggerFactory.getLogger(NIOrderUpdateServiceImpl.class);
	@Autowired
	NIOrderUpdateHelper niOrderUpdateHelper;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	CommonService commonService;
	
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;

	@Override
	public void preOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessId(1017L);
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		niOrderUpdateHelper.preOperation(commonBO);
	}

	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		niOrderUpdateHelper.postOperation(commonBO);

		Orders order = new Orders();
		order.setOrderId(commonBO.getOrderId());
		Long taskId = 1019L;
		commonBO.setTaskId(taskId);
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			// (1028L);//Mapped from BPM_task table (CR OA : Approval Task)
			if (taskId.equals(1019L)) {
				// logger.info("Task ID request " + 1021L, this);
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {

					if (taskObj.getBpmTask().getTaskId().equals(1019L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						commonBO.setBpmTaskId(taskObj.getBpmTaskId());
						commonBO.setTaskDescription(taskObj.getSubject());
						break;
					} else {
						logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId()
								+ " for the task :: " + commonBO.getTaskId());
					}
				}
			}

		} else {
			logger.info("orderUserBpmTaskList is null for orderId ::  ");
		}
		// Update OrderUserBpmTasks
		commonBO.setBpmProcessId(1017L);
		commonBO.setRoleId(1004L);// Network Implementation Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setTaskId(1019L); // Mapped from BPM_task table (NI : Order Update Completion)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		
		Long crCount = orderDAO.countOrderEvent(commonBO);
		if (null != crCount && crCount.equals(1L)) {
			logger.info("@@@ Pick Operation for Change Request @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
		}else if(commonBO.getOrderTypeId().equals(1004L)){
			logger.info("@@@ Pick Operation for Change Order @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
			
		}else {
			logger.info(" @@@ No Change Request created against the order id :::  @@@  "+commonBO.getOrderId(), this);
		}
	}

}
