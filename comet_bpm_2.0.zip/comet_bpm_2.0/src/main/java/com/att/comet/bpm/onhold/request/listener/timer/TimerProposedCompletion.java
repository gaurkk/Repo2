package com.att.comet.bpm.onhold.request.listener.timer;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Session;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.impl.persistence.entity.ExecutionEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.EmailTemplateHelper;
import com.att.comet.bpm.common.hibernate.bean.TaskInfo;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.EmailTemplateBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.EmailUtil;
import com.att.comet.bpm.config.BpmApplicationContext;
import com.att.comet.bpm.config.CometYamlPropertySourceFactory;

@Component
@Configuration
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class TimerProposedCompletion implements ExecutionListener {

	private static final Logger logger = LoggerFactory.getLogger(TimerProposedCompletion.class);
	@Autowired
	CommonService commonService;
	@Autowired
	EmailUtil emailUtil;

	@Autowired
	EmailTemplateHelper emailTemplateHelper;

	@Autowired
	BpmApplicationContext bpmApplicationContext;

	// get smtpm server
	@Value("${comet.email.smtp-server}")
	private String smtp_server;
	// Smpt port
	@Value("${comet.email.smtp-port}")
	private String smtp_port;
	// smtp-host
	@Value("${comet.email.smtp-host}")
	private String smtp_host;

	@Override
	public void notify(DelegateExecution execution) throws Exception {

		logger.info("@Starting notify method ::", this);
		ExecutionEntity executionEntity = (ExecutionEntity) execution;
		if (executionEntity.isCanceled()) {
			logger.info("@Execution Entity is Marked Cancelled");
			return;
		}
		logger.info("@Execution Entity is Not Marked Cancelled");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		boolean taskCompleted = false;

		if (execution.getCurrentActivityId().equalsIgnoreCase("Timer_PropCompDate")) {
			commonBO.setEmailNotificationId(1007L); // Notification
		} else if (execution.getCurrentActivityId().equalsIgnoreCase("Timer_Sp_Reminder1")) {
			commonBO.setEmailNotificationId(1008L); // Reminder 1
		} else if (execution.getCurrentActivityId().equalsIgnoreCase("Timer_Sp_Reminder2")) {
			commonBO.setEmailNotificationId(1009L); // Reminder 2
		} else if (execution.getCurrentActivityId().equalsIgnoreCase("Timer_Sp_ReminderX")) {
			commonBO.setEmailNotificationId(1010L); // Reminder X
		} else if (execution.getCurrentActivityId().equalsIgnoreCase("Timer_NSp_ReminderX")) {
			commonBO.setEmailNotificationId(1010L); // Reminder X
		}

		String emailOSD = commonBO.getOsEmail(); // get OS email
		logger.info("OSD email ::" + emailOSD, this);
		if (null != commonBO) {
			try {
				setEmailNotification(commonBO, taskCompleted);
			} catch (Exception e1) {
				logger.error("@ EMAIL sender error:" + e1.getMessage() + "", this);
			}
		}
		logger.info("@Ending notify method ::", this);
	}

	private void setEmailNotification(CommonBO commonBO, boolean taskCompleted)
			throws CamundaServiceException, Exception {

		logger.info("@Starting method setEmailNotification ", this);
		EmailTemplateBO emailTemplateBO = new EmailTemplateBO();
		TaskInfo taskInfo = null;
		taskInfo = emailTemplateHelper.getTaskInfo(commonBO.getTaskId(), commonBO.getEmailNotificationId());
		if (null != taskInfo) {
			if (commonBO.getEmailNotificationId() == 1010L) {
				emailTemplateBO.setToEmail(commonBO.getOsdEmail());
				emailTemplateBO.setCcEmail(
						commonBO.getOsEmail() + "," + commonBO.getOaEmail() + "," + commonBO.getAdminEmail());
			} else {
				emailTemplateBO.setToEmail(commonBO.getOsdEmail());
				emailTemplateBO.setCcEmail(commonBO.getOsEmail() + "," + commonBO.getOaEmail());
			}
			emailTemplateBO.setTaskDataId(String.valueOf(commonBO.getBpmTaskId()));
			if (commonBO.getEmailNotificationId() == 1010L) {
				emailTemplateBO.setSubject(taskInfo.getSubject() + " " + commonBO.getCountReminderEmails() + ":"
						+ commonBO.getTaskDescription());
			} else {
				emailTemplateBO.setSubject(taskInfo.getSubject() + ":" + commonBO.getTaskDescription());
			}

			emailTemplateBO.setHeaderSection(taskInfo.getHeaderSection());
			emailTemplateBO.setSubHeaderSection(taskInfo.getSubHeaderSection());

			emailTemplateBO.setBodySection1(taskInfo.getBodySection1());
			emailTemplateBO.setBodySection2(taskInfo.getBodySection2());
			emailTemplateBO.setBodySection3(taskInfo.getBodySection3());

			emailTemplateBO.setFooterSection(taskInfo.getFooterSection());

			emailTemplateBO.setApnName(commonBO.getApnName());
			emailTemplateBO.setOrderId(commonBO.getOrderId());
			if (BpmConstant.NEW_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("New");
			} else if (BpmConstant.CHANGE_REQUEST.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Change Request");
			} else if (BpmConstant.CHANGE_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Change Order");
			} else if (BpmConstant.CANCEL_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Cancel Order");
			} else if (BpmConstant.DECOMMISSION_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Decommission");
			} else if (BpmConstant.ONHOLD_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType(commonBO.getOrderTypeName() != null ? commonBO.getOrderTypeName() : "");
			}
			emailTemplateBO.setPdpName(commonBO.getPdpName());
			emailTemplateBO.setBackHaulName(commonBO.getBackHaulIds());
			emailTemplateBO.setAccountId(commonBO.getAccountClassId());
			emailTemplateBO.setAccountName(commonBO.getAccountName());
			emailTemplateBO.setBpmUrl(commonBO.getUrlName());
			emailTemplateBO.setEodOrder(commonBO.getEodOrder());
			emailTemplateBO.setFeeWaiverApproved(commonBO.getFeeWaiverApproved());
			emailTemplateBO.setCompanyBillingAddress(commonBO.getCompanyBillingAddress());
			emailTemplateBO.setCompanyContactNamePhone(commonBO.getCompanyContactNamePhone());
			emailTemplateBO.setFederalTaxID(commonBO.getFederalTaxID());
			emailTemplateBO.setBan(commonBO.getBan());
			emailTemplateBO.setFan(commonBO.getFan());
			emailTemplateBO.setAccountManager(commonBO.getAccountManager());
			emailTemplateBO.setMobilityTechnicalEngineer(commonBO.getMobilityTechnicalEngineer());
			emailTemplateBO.setSourceofIPAddressing(commonBO.getSourceofIPAddressing());
			emailTemplateBO.setTypeofAddressing(commonBO.getTypeofAddressing());
			emailTemplateBO.setBackhaulInstances(commonBO.getBackhaulInstances());
			emailTemplateBO.setMplscir(commonBO.getMplscir());
			emailTemplateBO.setManagedAVPN(commonBO.getManagedAVPN());
			emailTemplateBO.setOnHoldRequestedDate(commonBO.getOnHoldRequestedDate());
			emailTemplateBO.setOnHoldProposedCompletionDate(commonBO.getOnHoldProposedCompletionDate());
			emailTemplateBO.setOnHoldReason(commonBO.getOnHoldReason());
			emailTemplateBO.setOnHoldNotes(commonBO.getOnHoldNotes());
			Map<String, Object> model = taskCreationEmailFormat(emailTemplateBO, commonBO);
			// EMAIL SENDER CLASS INVOKING
			Properties props = System.getProperties();
			props.put(smtp_host, smtp_server);// will update later from YML
			Session session = Session.getInstance(props, null);

			emailUtil.sendEmail(session, emailTemplateBO, model);
		}

		logger.info("@Ending method setEmailNotification ", this);

	}

	private Map<String, Object> taskCreationEmailFormat(EmailTemplateBO emailTemplateBO, CommonBO commonBO) {
		
		logger.info("@Starting method taskCreationEmailFormat ", this);
		Map<String, Object> model = new HashMap<>();
		model.put("HeaderSection", emailTemplateBO.getHeaderSection());
		model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());

		if (commonBO.getTaskId() == 1012L) {
			String orderData = emailTemplateBO.getSubHeaderSection();
			orderData = orderData.replace(EmailUtil.rejectionComments, commonBO.getComments() + "\n");
			model.put("SubHeaderSection", orderData);
		} else if (commonBO.getTaskId() == 1013L) {
			String orderData = emailTemplateBO.getSubHeaderSection();
			orderData = orderData.replace(EmailUtil.rejectionComments, commonBO.getComments() + "\n");
			model.put("SubHeaderSection", orderData);
		} else {
			model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());
		}

		String taskStm = emailTemplateBO.getBodySection1();// task
		Boolean found = Arrays.asList(taskStm.split(" ")).contains(EmailUtil.taskIdVar);
		if (found.booleanValue()) {
			taskStm = taskStm.replace(EmailUtil.taskIdVar, emailTemplateBO.getTaskDataId());
		}
		model.put("taskStm", taskStm);

		String orderData = emailTemplateBO.getBodySection2();
		orderData = orderData.replace(EmailUtil.orderIdVar, emailTemplateBO.getOrderId() + "\n");
		orderData = orderData.replace(EmailUtil.orderTypeVar, emailTemplateBO.getOrderType() + "\n");
		orderData = orderData.replace(EmailUtil.apnNameVar, emailTemplateBO.getApnName() + "\n");
		orderData = orderData.replace(EmailUtil.pdpNameVar, emailTemplateBO.getPdpName() + "\n");
		orderData = orderData.replace(EmailUtil.backHaulVar, emailTemplateBO.getBackHaulName() + "\n");
		orderData = orderData.replace(EmailUtil.accountIdVar, emailTemplateBO.getAccountId() + "\n");
		orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName());

		if (commonBO.getTaskId() == 1046L) {// On Hold Request Task
			orderData = orderData.replace(EmailUtil.onHoldRequestedDate,
					emailTemplateBO.getOnHoldRequestedDate() + "\n");
			orderData = orderData.replace(EmailUtil.onHoldProposedCompletionDate,
					emailTemplateBO.getOnHoldProposedCompletionDate() + "\n");
			orderData = orderData.replace(EmailUtil.onHoldReason, emailTemplateBO.getOnHoldReason() + "\n");
			orderData = orderData.replace(EmailUtil.onHoldNotes, emailTemplateBO.getOnHoldNotes() + "\n");
		} else {
			orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName());
		}

		model.put("orderData", orderData);

		String moreOrderDetails = emailTemplateBO.getBodySection3();
		moreOrderDetails = moreOrderDetails.replace(EmailUtil.pleaseClick, commonBO.getUrlName());
		model.put("moreOrderDetails", moreOrderDetails);
		model.put("footer", emailTemplateBO.getFooterSection());
		logger.info("@Ending method taskCreationEmailFormat ", this);
		return model;
	}

}
