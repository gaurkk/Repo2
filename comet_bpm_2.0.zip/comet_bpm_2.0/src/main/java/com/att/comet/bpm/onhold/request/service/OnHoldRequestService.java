package com.att.comet.bpm.onhold.request.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OnHoldRequestService {

	void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException;

	void postRequestOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void updateOrdersOperation(CommonBO commonBO) throws CamundaServiceException;

	void slaNotSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException;

	void slaSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException;

	void slaSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException;

	void slaNotSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException;

}
