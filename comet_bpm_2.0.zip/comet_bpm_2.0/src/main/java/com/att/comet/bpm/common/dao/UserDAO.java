package com.att.comet.bpm.common.dao;

import java.util.List;

import com.att.comet.bpm.common.modal.CommonBO;

public interface UserDAO {
	List<String> getUserEmail(CommonBO commonBO);

	List<Object[]> findContactTypeIdAndEmail(CommonBO commonBO);

	List<String> getGroupUserEmail(CommonBO commonBO);

	List<String> findEmailByRoleId(CommonBO commonBO);

	List<String> getAssignedUserEmail(List<String> attUidList);
	
	List<String> getActiveUserGroupEmail(CommonBO commonBO);
	
	List<String> findEmailAllUsers(CommonBO commonBO);
	
}
