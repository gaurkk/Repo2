package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderWorkStep. Mapped with the BPM_ORDER_WORK_STEP
 * table in the database.
 */
@Entity
@Table(name = "BPM_ORDER_WORK_STEP")
public class BpmOrderWorkStep implements Serializable {

	private static final long serialVersionUID = -8048518760010798145L;

	private BpmOrderWorkStepId id;
	private BpmStatus bpmStatus;
	private BpmWorkStep bpmWorkStep;
	private OrderType orderType;
	private Orders orders;
	private Date workStepExecutedOn;
	private String userDecision;
	private Date userDecisionOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderWorkStepId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "workStepId", column = @Column(name = "WORK_STEP_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)) })
	public BpmOrderWorkStepId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderWorkStepId id) {
		this.id = id;
	}

	/**
	 * Getter method for bpmStatus.
	 * 
	 * @return BpmStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BPM_STATUS_ID")
	public BpmStatus getBpmStatus() {
		return this.bpmStatus;
	}

	/**
	 * @param bpmStatus to bpmStatus set.
	 */
	public void setBpmStatus(BpmStatus bpmStatus) {
		this.bpmStatus = bpmStatus;
	}

	/**
	 * Getter method for bpmWorkStep.
	 * 
	 * @return BpmWorkStep
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WORK_STEP_ID", nullable = false, insertable = false, updatable = false)
	public BpmWorkStep getBpmWorkStep() {
		return this.bpmWorkStep;
	}

	/**
	 * @param bpmWorkStep to bpmWorkStep set.
	 */
	public void setBpmWorkStep(BpmWorkStep bpmWorkStep) {
		this.bpmWorkStep = bpmWorkStep;
	}

	/**
	 * Getter method for orderType.
	 * 
	 * @return OrderType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_TYPE_ID", nullable = false, insertable = false, updatable = false)
	public OrderType getOrderType() {
		return this.orderType;
	}

	/**
	 * @param orderType to orderType set.
	 */
	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for workStepExecutedOn. WORK_STEP_EXECUTED_ON mapped to
	 * WORK_STEP_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "WORK_STEP_EXECUTED_ON")
	public Date getWorkStepExecutedOn() {
		return this.workStepExecutedOn;
	}

	/**
	 * @param workStepExecutedOn to workStepExecutedOn set.
	 */
	public void setWorkStepExecutedOn(Date workStepExecutedOn) {
		this.workStepExecutedOn = workStepExecutedOn;
	}

	/**
	 * Getter method for userDecision. USER_DECISION mapped to USER_DECISION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_DECISION", length = 100)
	public String getUserDecision() {
		return this.userDecision;
	}

	/**
	 * @param userDecision to userDecision set.
	 */
	public void setUserDecision(String userDecision) {
		this.userDecision = userDecision;
	}

	/**
	 * Getter method for userDecisionOn. USER_DECISION_ON mapped to USER_DECISION_ON
	 * in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "USER_DECISION_ON")
	public Date getUserDecisionOn() {
		return this.userDecisionOn;
	}

	/**
	 * @param userDecisionOn to userDecisionOn set.
	 */
	public void setUserDecisionOn(Date userDecisionOn) {
		this.userDecisionOn = userDecisionOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
