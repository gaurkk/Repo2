/**
 * 
 */
package com.att.comet.bpm.apniwos.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetails;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.ApnRepository;
import com.att.comet.bpm.common.util.CommonUtils;

/**
 * @author pd6080
 *
 */
@Component
public class ApnIwosHelper {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosHelper.class);

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	ApnRepository apnRespository;

	public void preApnIwosPreCRUDOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method preApnIwosPreCRUDOperation", this);
		String adminAttId = null;
		// adminAttId =
		// genericDAO.getEmailFromUsersAndUserRoleByOrderApproverRoleIdAndActiveAndApproved(1006L);
		// update BPM Order Expedite table
		genericDAO.updateBpmOrderExpedite(commonBO);
		commonBO.setProcessId(1005L);
		commonBO.setBpmProcessId(1005L);// Network IWOS Process
		commonBO.setBpmProcessInstanceId(processInstanceId);
		commonBO.setBpmStatusId(1001L);// Trigger
		// Inserting into AVOS_Process_Instances
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		Long crCount = orderDAO.countOrderEvent(commonBO);// do we need to know CR count?
		String crVar = "CR-00";
		if (null != crCount && crCount > 0) {
			crVar = crVar + "" + String.valueOf(crCount);
			commonBO.setCrCountValue(crVar);
		}

		// bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
		if (!commonBO.getOrderOperation().equals("NEW_ORDER")) {// Coming from Frontend
			// updating with BPM status 1001L
			bpmDAO.updateBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);
			List<Long> workStepIdList = new ArrayList<>();
			workStepIdList.add(1005L);
			workStepIdList.add(1008L);
			workStepIdList.add(1039L);
			commonBO.setWorkStepIdList(workStepIdList);
			genericDAO.updateBpmOrderExpedite(commonBO);
			
		} else {// for new order only
			commonBO.setWorkStepId(1005L);
			bpmDAO.saveBpmOrderProcess(commonBO);
		}

		/*
		 * commonBO.setBusinessStepId(3104L); BpmOrderBusinessStep bpmOrderBusinessStep
		 * = bpmDAO.findBpmOrderBusinessStepById(commonBO); if (null !=
		 * bpmOrderBusinessStep) { logger.info("bpmOrderBusinessStep is not null",
		 * this); } else { logger.error("bpmOrderBusinessStep is null", this); }
		 */

		List<String> osdEmailList = null;
		
		commonBO.setOrderContactTypeId(1006L); 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO); 
		if (!CollectionUtils.isEmpty(attUidList)) { 
			logger.debug("osdEmailList is not empty : ", +attUidList.size()); 
			String ccsPM = attUidList.get(0); 
			commonBO.setAttuid(ccsPM); 
			commonBO.setIwosAssignee(ccsPM);
			osdEmailList = userDAO.getUserEmail(commonBO); 
			commonBO.setEmailList(osdEmailList); 
		} else { 
			logger.debug("attUidList is empty: ", +attUidList.size()); 
			commonBO.setRoleId(1005L); 
			osdEmailList = userDAO.getGroupUserEmail(commonBO); 
			commonBO.setGroupEmailList(osdEmailList); 
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
		}
		// 1001L new ,1002LCancel Order ,1004LChange Order ,1005L Change Request ,1006L
		// Decommission
		// NO check for expedite order 1003L
		if (commonBO.getOrderTypeId() == 1001L || commonBO.getOrderTypeId() == 1002L
				|| commonBO.getOrderTypeId() == 1004L || commonBO.getOrderTypeId() == 1005L
				|| commonBO.getOrderTypeId() == 1006L) {
			/* Inserting record into BPM_Order_Work_Step */
			commonBO.setBpmStatusId(1001L);
			commonBO.setWorkStepId(1005L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1005L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setDisplayFlag('N');
			bpmDAO.saveBpmOrderWorkStep(commonBO);
			List<Long> businessStepIdList = new ArrayList<Long>();
			businessStepIdList.add(3006L);
			businessStepIdList.add(3007L);
			commonBO.setBusinessStepIdList(businessStepIdList);
			bpmDAO.deleteBpmOrderBusinessStep(commonBO);
			genericDAO.setReminder1And2FromSlaWorkingDayForAPNIWO_CREATION(commonBO);
			commonBO.setFlagId(1001L);
			OrderFlagsDetails orderFlagsDetails = null;
			orderFlagsDetails = orderDAO.findOrderFlagsDetails(commonBO);
			if (null != orderFlagsDetails && null != orderFlagsDetails.getFlagValue()) {
				commonBO.setOrderFlagValue(orderFlagsDetails.getFlagValue());
			} else {
				logger.error("orderFlagsDetails is null for flag Id 1001L : ", this);
			}
		
		
		}
		
		logger.info("@Existing method preApnIwosPreCRUDOperation", this);

	}

	public void postApnIwosPostCRUDOperation(CommonBO commonBO, DelegateExecution execution)  throws CamundaServiceException, ParseException{
		logger.info("@Starting method postApnIwosPostCRUDOperation", this);
		String iwosCreationDate = null;
		String iwosTicketNumber = null;

		iwosTicketNumber = (String) execution.getVariable(BpmConstant.TICKET_NUM);
		iwosCreationDate = (String) execution.getVariable(BpmConstant.TICKET_CREATION_DATE);
		String comments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setBpmStatusId(1002L);
		commonBO.setOrderContactTypeId(1006L); 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO); 
		if (!CollectionUtils.isEmpty(attUidList)) { 
			logger.debug("osdEmailList is not empty : ", +attUidList.size()); 
			String ccsPM = attUidList.get(0); 
			commonBO.setAttuid(ccsPM); 
			commonBO.setIwosAssignee(ccsPM);
			 
		}
		commonBO.setDisplayFlag('Y');
		commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(iwosCreationDate));
		List<Long> idList = new ArrayList<Long>();
		idList.add(1005L);
		commonBO.setWorkStepIdList(idList);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		commonBO.setUpdatedBy(commonBO.getIwosAssignee());
		commonBO.setBusinessStepId(3007L);
		commonBO.setBusinessStepStatus("Created");
		commonBO.setBusinessStepValue(iwosTicketNumber);
		commonBO.setComments(comments);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		/*
		 * if(CommonUtils.isNotNullEmpty(commonBO.getIwosAssignee())) {
		 * logger.info("@@@@ Apn Network IWOS Assignee is @@@@  "+commonBO.
		 * getIwosAssignee(), this); commonBO.setOrderContactTypeId(1006L);
		 * commonBO.setUpdatedBy(commonBO.getIwosAssignee());
		 * orderDAO.updateOrderContactInfo(commonBO); }else {
		 * logger.info("@@@@ Apn Network IWOS Assignee is null @@@@  "+commonBO.
		 * getIwosAssignee(), this); }
		 */
		

		logger.info("@Existing method postApnIwosPostCRUDOperation", this);
	}
}
