package com.att.comet.bpm.core.processes.delegate;

import java.util.Map;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.service.DAPNProcessService;

@Component
public class DAPNBpmDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(DAPNBpmDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	private DAPNProcessService dapnProcessService;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Map<String, Object> variables = execution.getVariables();
		String operationType = (String) variables.get("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.PRE_DAPN_OPERATION:
				dapnPreOpration(execution);
				break;
			case BpmConstant.DAPN_STATUS_UPDATE:
				dapnOrderStatusUpdate(execution);
				break;
			case BpmConstant.DAPN_STATUS_UPDATE_PROD:
				dapnOrderStatusUpdateProd(execution);
				break;
			case BpmConstant.POST_DAPN_OPERATION:
				dapnPostOperation(execution);
				break;
			case BpmConstant.DAPN_BILLING_SLA:
				dapnBillingSla(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}
	private void dapnPreOpration(DelegateExecution execution) {
		logger.info("Starting dapnPreOpration method ");
		CommonBO commonBO = null;
		String expediteOrderProcessInstanceId = null;
		expediteOrderProcessInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getDapnCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); 
					execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
					execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
					execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessInstanceId(expediteOrderProcessInstanceId);
					dapnProcessService.preOperation(commonBO);
					execution.setVariable("apnIwosCreationTaskStatus", commonBO.getApnIwosTaskStatus());
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed in DAPN Order Pre Opration"));
			throw new BpmnError("ERROR_BPM_001", "DAPN_ORDER_EXCEPTION");
		}

		logger.info("Exiting dapnPreOpration method ");
		
	}
	private void dapnBillingSla(DelegateExecution execution) {
		logger.info("Starting dapnBillingSla method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			dapnProcessService.billingSla(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable("duration", commonBO.getDapnBillingSla());
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure dapnBillingSla"), this);
			throw new BpmnError("ERROR_BPM_001", "DAPN_ORDER_EXCEPTION");
		}
		logger.info("Starting dapnBillingSla method ");

	}
	private void dapnOrderStatusUpdate(DelegateExecution execution) {
		logger.info("Starting dapnOrderStatusUpdate method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			dapnProcessService.orderStatusUpdate(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure dapnOrderStatusUpdate"), this);
			throw new BpmnError("ERROR_BPM_001", "DAPN_ORDER_EXCEPTION");
		}
		logger.info("Starting dapnOrderStatusUpdate method ");

	}
	private void dapnOrderStatusUpdateProd(DelegateExecution execution) {
		logger.info("Starting dapnOrderStatusUpdateProd method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			dapnProcessService.orderStatusUpdateProd(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure dapnOrderStatusUpdateProd"), this);
			throw new BpmnError("ERROR_BPM_001", "DAPN_ORDER_EXCEPTION");
		}
		logger.info("Starting dapnOrderStatusUpdateProd method ");
	}
	private void dapnPostOperation(DelegateExecution execution) {
		logger.info("Starting dapnPostOperation method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			dapnProcessService.postOperation(commonBO);
			commonBO.setApproved(BpmConstant.APPROVED);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure dapnPostOperation"), this);
			throw new BpmnError("ERROR_BPM_001", "DAPN_ORDER_EXCEPTION");
		}
		logger.info("Exiting dapnPostOperation method ");

	}

		
	

}
