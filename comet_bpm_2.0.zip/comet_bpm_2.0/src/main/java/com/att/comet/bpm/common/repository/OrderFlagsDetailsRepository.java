package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetails;
import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetailsPK;



public interface OrderFlagsDetailsRepository extends JpaRepository<OrderFlagsDetails, OrderFlagsDetailsPK> {

}
