package com.att.comet.bpm.common.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.hibernate.bean.OrderStatus;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.repository.OrdersRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Service
public class CommonServiceImpl implements CommonService {
	private static final Logger logger = LoggerFactory.getLogger(CommonServiceImpl.class);

	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private OrdersRepository ordersRepository;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	CommonServiceHelper commonServiceHelper;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Autowired
	CommonService commonService;

	@Override
	public CommonBO getCommonBO(Long orderId) throws CamundaServiceException {
		return orderDAO.getOrderById(orderId);
	}
	@Override
	public CommonBO getDapnCommonBO(Long orderId) throws CamundaServiceException {
		return orderDAO.getDapnOderById(orderId);
	}

	@Override
	public BpmUrl getBpmUrl(String urlName) {
		return bpmDAO.finBpmUrlById(urlName);
	}

	@Override
	public void updateOrderUserBpmTasksRepository(CommonBO commonBO) throws CamundaServiceException {
		orderDAO.updateOrderUserBpmTasksRepository(commonBO);

	}

	@Override
	public void updateTaskData(CommonBO commonBO) throws CamundaServiceException {
		/*
		 * insert in to bpm_order_business_step commonBO.setBusinessStepId(3005L);
		 * commonBO.setUpdatedBy(commonBO.getAttuid());
		 * commonBO.setBusinessStepStatus("Completed");
		 * commonBO.setComments("Terminating the inprogress process");
		 * bpmDAO.saveBpmOrderBusinessStep(commonBO); update bpm_order_work_step
		 * commonBO.setWorkStepId(1004L); commonBO.setBpmStatusId(1002L);
		 * bpmDAO.updateBpmOrderWorkStep(commonBO); update bpm_order_process
		 * commonBO.setProcessId(1004L); commonBO.setBpmStatusId(1002L);
		 * bpmDAO.updateBpmOrderProcess(commonBO);
		 */
	}

	@Override
	public String findUserDecision(CommonBO commonBO) {
		return bpmDAO.findUserDecision(commonBO);
	}

	@Override
	public String completeOrderWorkFlow(Long orderId, String orderOperation) throws CamundaServiceException {
		return orderDAO.completeOrderWorkFlow(orderId, orderOperation);
	}

	@Override
	public boolean completeCancelOrderWorkFlow(CommonBO commonBO) throws CamundaServiceException {
		return orderDAO.completeCancelOrderWorkFlow(commonBO);
	}

	@Override
	public void onHoldPreOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		commonServiceHelper.onHoldPreOperation(commonBO, processInstanceId);

	}

	@Override
	public void onHoldCancelOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonServiceHelper.onHoldCancelOperation(commonBO);
		Map<String, Object> variables = execution.getVariables();
		variables.put("response", "Rejected");
		variables.put("comments", "cancelling Request");
		commonBO.setProcessId(1028L);// OS On hold Request Process
		commonBO.setBpmProcessId(1028L);// OS On hold Request Process
		commonBO.setTaskId(1046L);// On Hold Request Task
		Orders order = new Orders();
		order.setOrderId(commonBO.getOrderId());
		String inProgressTaskId = null;
		String inprogressOnhlodTask = null;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
					commonBO.setBpmTaskId(taskObj.getBpmTaskId());
					commonBO.setTaskCreationTime(taskObj.getCreationDate());
					inprogressOnhlodTask = taskObj.getProcessInstanceId();
					inProgressTaskId = taskObj.getBpmTaskId();
					break;
				} else {
					logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId() + " for the task :: "
							+ commonBO.getTaskId());
				}
			}
		}
		if (CommonUtils.isNotNullEmpty(inProgressTaskId)) {
			commonBO.setApproved(BpmConstant.REJECTED);
			// Update OrderUserBpmTasks
			commonBO.setBpmTaskId(inProgressTaskId);
			commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
			commonBO.setRoleId(1001L);// CCS PM Role Id
			commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
			commonBO.setCategoryId(1003L);// Category Id(SERVICE)
			commonBO.setTaskId(1046L);// Mapped from BPM_task table (OS : On-hold Request)
			commonService.updateOrderUserBpmTasksRepository(commonBO);

		} else {
			logger.error("@@@ inprogressOnhlodTask is null @@@   ");
		}
	}

	@Override
	public void onHoldResumeOperation(CommonBO commonBO) throws CamundaServiceException {
		commonServiceHelper.onHoldResumeOperation(commonBO);
		commonBO.setApproved(BpmConstant.REJECTED);
		
	}

	@Override
	public Integer getBpmStatus(Long orderId, Long workStepId) throws CamundaServiceException {
		String sql = "select bpm_status_id from bpm_order_work_step where order_id = ? and work_step_id = ?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		query.setParameter(2, workStepId);

		List<Integer> resultList = query.getResultList();
		Integer bpmStatusId = null;
		if (resultList != null && resultList.size() > 0) {
			bpmStatusId = resultList.get(0);
		}
		return bpmStatusId;
	}

}
