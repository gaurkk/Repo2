package com.att.comet.bpm.expedite.ni.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class ExpditeNIServiceImpl implements ExpditeNIService{
	private static final Logger logger = LoggerFactory.getLogger(ExpditeNIServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperation");
		List<String> OAEmailList = null;
		if(commonBO.getOrderOperation().equalsIgnoreCase("EXPEDITE_ORDER")) {
			commonBO.setOrderTypeName("expedite");
		}
		commonBO.setBpmProcessId(1018L);
		//NI ATTUID and email
		commonBO.setOrderContactTypeId(1007L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderApprover = attUidList.get(0);
			commonBO.setAttuid(orderApprover);
			commonBO.setAssignee(orderApprover);
			OAEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(OAEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1004L);
			OAEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setOmEmailList(OAEmailList);
		}
		
		
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getOmEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3006L);
		businessStepIdList.add(3084L);
		businessStepIdList.add(3085L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// saving bpm_order_work_step
		commonBO.setWorkStepId(1028L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayForExpediteNI(commonBO);
		

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method preOperation");
	}

	@Override
	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperation");

		// updating bpm_order_work_step
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// update bpm_order_business_step
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setUpdatedOn(commonBO.getExpediteBuildDate());
		commonBO.setBusinessStepStatus("Completed");
		commonBO.setBusinessStepId(3107L);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// updating bpm_order_work_step
		commonBO.setWorkStepId(1029L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method postOperation");

	}


}
