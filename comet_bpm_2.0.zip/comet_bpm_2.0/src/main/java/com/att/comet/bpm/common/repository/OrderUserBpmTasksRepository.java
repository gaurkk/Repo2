package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;

import java.util.List;
import java.util.Optional;

import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.hibernate.bean.TaskCategory;
import com.att.comet.bpm.common.hibernate.bean.TaskStatus;

@Repository
public interface OrderUserBpmTasksRepository extends JpaRepository<OrderUserBpmTasks,String> {

	List<OrderUserBpmTasks> findByOrders(Orders orders);
	
	List<OrderUserBpmTasks> findByOrdersAndBpmTaskAndTaskCategory(Orders orders,BpmTask bpmTask,TaskCategory taskCategory);
	
	Optional<OrderUserBpmTasks> findByOrdersAndBpmTaskAndTaskCategoryAndTaskStatus(Orders orders,BpmTask bpmTask,TaskCategory taskCategory,TaskStatus taskStatus);
}
