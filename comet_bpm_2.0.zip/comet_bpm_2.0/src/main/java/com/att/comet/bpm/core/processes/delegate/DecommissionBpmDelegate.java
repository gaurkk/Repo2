package com.att.comet.bpm.core.processes.delegate;

import java.util.List;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;
import com.att.comet.bpm.core.processes.service.CoreProcessService;

@Component
public class DecommissionBpmDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(DecommissionBpmDelegate.class);

	@Autowired
	CommonService commonService;

	@Autowired
	BpmDAO bpmDAO;

	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;

	@Autowired
	CoreProcessService coreProcessService;

	public static final String URL_NAME = "Decommission_Order_Status_url";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String operationType = (String) execution.getVariable("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.PRE_OPERATION_DECOM:
				preOperation(execution);
				break;
			case BpmConstant.CHECK_USER_DECISION:
				checkUserDecision(execution);
				break;
			case BpmConstant.POST_USER_TASK_OPERATION:
				postUserTaskOperation(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void preOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);

			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url() + commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());

				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setTaskId(1041L); // Mapped from BPM_task table (CCS PM : Decommissioning Dashboard Task)
				commonBO.setDecomWorkFlowStarted("Y"); //flag set when Decom Workflow Started
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				// Get Derived Order From
				coreProcessService.preDecomOperation(commonBO);
				// setting for email subject
				commonBO.setTaskDescription("Decommission Order - " + commonBO.getOrderId()
						+ " is submitted in COMET for Order ID - " +  commonBO.getDerivedFromOrderId() +" with APN -" + commonBO.getApnName() + "  "
						+ "for Account - " + commonBO.getAccountName());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "DECOM PREOPERATION SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "DECOM PREOPERATION SERVICE EXCEPTION");

		}
		logger.info("End preOperation method ::", this);
	}

	private void postUserTaskOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Inside postUserTaskOperation");
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		coreProcessService.postDecomUserTaskOperation(commonBO);
		commonBO.setApproved(BpmConstant.APPROVED);
		execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		logger.info("end postUserTaskOperation");

	}

	private void checkUserDecision(DelegateExecution execution) {
		logger.info("Starting checkUserDecision method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String userDecision = null;
		String apnIwosHlrUserDecision = null;
		String apnIwosUserDecision = null;
		String billingUserDecision = null;
		CommonBO commonBO = null;
		try {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				if (null == commonBO) {
					commonBO = commonService.getCommonBO(orderId);
				} else {
					logger.debug("commonBO is not null :::: ");
				}
				commonBO.setOrderOperation(orderOperation);
				List<Object[]> processDetails = bpmDAO.getProcessUserDecision(commonBO);
				if (!CollectionUtils.isEmpty(processDetails)) {
					for (Object[] processDetailsdata : processDetails) {
						String processId = processDetailsdata[0].toString();
						if (null != processId && CommonUtils.isNotNullEmpty(processId)) {
							logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
							if (null != processDetailsdata[1]) {
								userDecision = processDetailsdata[1].toString();
								if (null != userDecision && CommonUtils.isNotNullEmpty(userDecision)) {
									if (processId.equalsIgnoreCase("1024")) {
										apnIwosHlrUserDecision = userDecision;
										logger.info("apnIwosHlrUserDecision  :: " + apnIwosHlrUserDecision, this);
									} else if (processId.equalsIgnoreCase("1005")) {
										apnIwosUserDecision = userDecision;
										logger.info("apnIwosUserDecision  :: " + apnIwosUserDecision, this);
									}else if (processId.equalsIgnoreCase("1011")) {
										billingUserDecision = userDecision;
										logger.info("apnIwosUserDecision  :: " + apnIwosUserDecision, this);
									}
								} else {
									logger.error("userDecision is null: " + userDecision, this);
								}
							} else {
								logger.error("processDetailsdata[1] is null: ", this);
							}

						} else {
							logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
						}
					}
				} else {
					logger.error("processDetails is empty: ", +processDetails.size());
				}

				execution.setVariable(BpmConstant.APN_IWOS_USER_DECISION, apnIwosUserDecision);// need to change and take the
																						// value from DB
				execution.setVariable(BpmConstant.APN_IWOS_HLR_USER_DECISION, apnIwosHlrUserDecision); // need to change and take
																								// the value from DB
			}

			String sharedMPLSResponse = coreProcessDelegateHelper.checkSharedMPLS(orderId);
			if (CommonUtils.isNotNullEmpty(sharedMPLSResponse)) {
				execution.setVariable(BpmConstant.BILLING_USER_DECISION, sharedMPLSResponse); // need to change and take the
																				// value from DB}
			} else {
				logger.error("sharedMPLSResponse is null ", this);
			}
			//execution.setVariable(BpmConstant.BILLING_USER_DECISION, "NO");

		} catch (Exception e) {
			/*
			 * logger.error("", new
			 * CamundaServiceException("DB Operation failed for Decommission Order DO_Error001"
			 * )); throw new BpmnError("DO_Error001");
			 */
		}
		logger.info("Ending checkUserDecision method ");

	}
}
