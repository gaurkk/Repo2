package com.att.comet.bpm.expedite.om.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class ExpediteOMServiceImpl implements ExpediteOMService{
	private static final Logger logger = LoggerFactory.getLogger(ExpediteOMServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperation");
		List<String> OAEmailList = null;
		if(commonBO.getOrderOperation().equalsIgnoreCase("EXPEDITE_ORDER")) {
			commonBO.setOrderTypeName("expedite");
		}
		commonBO.setBpmProcessId(1018L);
		// OSD ATTUID
		// List<String> osdAttuidList=null;
		commonBO.setOrderContactTypeId(1003L);
		List<String> osdAttuidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(osdAttuidList)) {
			logger.debug("osdAttuidList is not empty : ", +osdAttuidList.size());
			String orderSubmitter = osdAttuidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			List<String> osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setOsdEmailList(osdEmailList);
		}
		//OM ATTUID and email
		commonBO.setOrderContactTypeId(1005L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderApprover = attUidList.get(0);
			commonBO.setAttuid(orderApprover);
			commonBO.setAssignee(orderApprover);
			OAEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(OAEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1003L);
			OAEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setOmEmailList(OAEmailList);
		}
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getOmEmailList()));
			//commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3038L);
		businessStepIdList.add(3082L);
		businessStepIdList.add(3083L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// saving bpm_order_work_step
		commonBO.setWorkStepId(1050L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayForExpediteOM(commonBO);
		
		
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method preOperation");
	}

	@Override
	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperation");

		// updating bpm_order_work_step
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		if (commonBO.getApproved().equalsIgnoreCase(BpmConstant.APPROVED)) {
			commonBO.setResponseHTAction("Expedite (OM) - Approved");
		} else {
			commonBO.setResponseHTAction("Expedite (OM) - Rejected");
		}
		// update bpm_order_business_step
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus(commonBO.getApproved());
		commonBO.setBusinessStepId(3120L);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update order comments
		commonBO.setOrderProcess(commonBO.getOrderOperation());
		commonBO.setRoleId(1003L);
		orderDAO.saveOrderComments(commonBO);

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method postOperation");

	}


}
