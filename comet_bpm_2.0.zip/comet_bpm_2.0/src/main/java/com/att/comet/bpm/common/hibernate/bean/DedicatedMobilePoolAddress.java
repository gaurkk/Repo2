package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for DedicatedMobilePoolAddress. Mapped to
 * DEDICATED_MOBILE_POOL_ADDRESS table in the database.
 */
@Entity
@Table(name = "DEDICATED_MOBILE_POOL_ADDRESS")
public class DedicatedMobilePoolAddress implements Serializable {

	private static final long serialVersionUID = -704757809848051193L;

	private Long mobilePoolAddressId;
	private DedicatedApn dedicatedApn;
	private DataCenter dataCenter;
	private String ipAddress;
	private Byte seq;

	/**
	 * Getter method for mobilePoolAddressId. MOBILE_POOL_ADDRESS_ID mapped to
	 * MOBILE_POOL_ADDRESS_ID in the database table. The value of the Id is being
	 * generated using a sequence defined by SEQ_MOBILE_POOL_ADDRESS_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "MOBILE_POOL_ADDRESS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_MOBILE_POOL_ADDRESS_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_MOBILE_POOL_ADDRESS_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MOBILE_POOL_ADDRESS_ID")
	public Long getMobilePoolAddressId() {
		return mobilePoolAddressId;
	}

	/**
	 * @param mobilePoolAddressId to mobilePoolAddressId set
	 */
	public void setMobilePoolAddressId(Long mobilePoolAddressId) {
		this.mobilePoolAddressId = mobilePoolAddressId;
	}

	/**
	 * Getter method for dedicatedApn.
	 * 
	 * @return DedicatedApn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "APN_ID", nullable = false)
	public DedicatedApn getDedicatedApn() {
		return this.dedicatedApn;
	}

	/**
	 * @param dedicatedApn to dedicatedApn set.
	 */
	public void setDedicatedApn(DedicatedApn dedicatedApn) {
		this.dedicatedApn = dedicatedApn;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for ipAddress. IP_ADDRESS mapped to IP_ADDRESS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * @param ipAddress to ipAddress set.
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Getter method for seq. SEQ mapped to SEQ in the database table.
	 * 
	 * @return Byte
	 */
	@Column(name = "SEQ", precision = 2, scale = 0)
	public Byte getSeq() {
		return this.seq;
	}

	/**
	 * @param seq to seq set.
	 */
	public void setSeq(Byte seq) {
		this.seq = seq;
	}
}