package com.att.comet.bpm.common.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BackhaulConfig;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderComments;
import com.att.comet.bpm.common.hibernate.bean.OrderContactInfo;
import com.att.comet.bpm.common.hibernate.bean.OrderContactInfoId;
import com.att.comet.bpm.common.hibernate.bean.OrderEvent;
import com.att.comet.bpm.common.hibernate.bean.OrderFlags;
import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetails;
import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetailsPK;
import com.att.comet.bpm.common.hibernate.bean.OrderStatus;
import com.att.comet.bpm.common.hibernate.bean.OrderStatusHistory;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.OrderUserTaskFaults;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.hibernate.bean.Role;
import com.att.comet.bpm.common.hibernate.bean.TaskCategory;
import com.att.comet.bpm.common.hibernate.bean.TaskStatus;
import com.att.comet.bpm.common.hibernate.bean.Users;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.repository.BackHaulConfgurationRespository;
import com.att.comet.bpm.common.repository.BpmTaskRepository;
import com.att.comet.bpm.common.repository.DapnInventoryRepository;
import com.att.comet.bpm.common.repository.OrderCommentsRepository;
import com.att.comet.bpm.common.repository.OrderContactInfoRepository;
import com.att.comet.bpm.common.repository.OrderDataCenterBackhaulRepository;
import com.att.comet.bpm.common.repository.OrderEventRepository;
import com.att.comet.bpm.common.repository.OrderFlagsDetailsRepository;
import com.att.comet.bpm.common.repository.OrderStatusHistoryRepository;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.repository.OrderUserTaskFaultsRepository;
import com.att.comet.bpm.common.repository.OrdersRepository;
import com.att.comet.bpm.common.repository.PdpIdInfoRepository;
import com.att.comet.bpm.common.repository.TaskCategoryRespository;
import com.att.comet.bpm.common.repository.TaskStatusRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.dao.helper.DAOHelper;

@Component
public class OrderDAOImpl implements OrderDAO {
	private static final Logger logger = LoggerFactory.getLogger(OrderDAOImpl.class);
	@Autowired
	private OrdersRepository ordersRepository;
	@Autowired
	private OrderStatusHistoryRepository orderStatusHistoryRepository;
	@Autowired
	private OrderEventRepository orderEventRepository;
	@Autowired
	private OrderContactInfoRepository orderContactInfoRepository;
	@Autowired
	private OrderCommentsRepository orderCommentsRepository;
	@Autowired
	private OrderFlagsDetailsRepository orderFlagsDetailsRepository;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	BackHaulConfgurationRespository backHaulConfgurationRespository;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	TaskCategoryRespository taskCategoryRepository;

	@Autowired
	TaskStatusRepository taskStatusRepository;

	@Autowired
	BpmTaskRepository bpmTaskRepository;
	@Autowired
	DapnInventoryRepository dapnRepository;

	@Autowired
	DAOHelper daoHelper;

	@Autowired
	private OrderDataCenterBackhaulRepository orderDataCenterBackhaulRepository;

	@Autowired
	private PdpIdInfoRepository pdpIdInfoRepository;

	@Autowired
	OrderUserTaskFaultsRepository orderUserTaskFaultsRepository;

	@Override
	public int updateOrderStatus(Long orderId, Long orderStatusId) {

		return ordersRepository.updateOrderStatusByOrderId(orderId, orderStatusId);
	}

	@Override
	public void updateOrders(CommonBO commonBO) {
		Optional<Orders> orders = ordersRepository.findById(commonBO.getOrderId());
		if (orders.isPresent()) {
			Orders order = orders.get();
			OrderStatus orderStatus = new OrderStatus();
			orderStatus.setOrderStatusId(commonBO.getOrderStatusId());
			order.setOrderStatus(orderStatus);
			Users updatedBy = new Users();
			updatedBy.setAttuid(commonBO.getUpdatedBy());
			order.setUpdatedBy(updatedBy);
			order.setUpdatedOn(commonBO.getUpdatedOn());
			order.setExpedite(commonBO.getExpedite());
			ordersRepository.save(order);
		}
	}

	@Override
	public void updateOrderCrFlag(CommonBO commonBO) {
		String sql = "update orders set cr_flag =? where order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getCrFlag());
		query.setParameter(2, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public CommonBO getDapnOderById(Long orderId) {
		CommonBO commonBO = new CommonBO();
		Optional<Orders> orders = ordersRepository.findById(orderId);
		List<String> backhaulIdList = orderDataCenterBackhaulRepository.getBackhaulIds(orderId);
		String pdpName = pdpIdInfoRepository.findAutoPdpNameByOrderId(orderId);
		if (pdpName == null) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + " does not has PDP NAME ::", this);
			pdpName = pdpIdInfoRepository.findUserPdpNameByOrderId(orderId);
		}
		if (!CollectionUtils.isEmpty(backhaulIdList)) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "backhaulIdList have record ::",
					this);
			daoHelper.backHaulIdList(backhaulIdList, commonBO);
		} else {
			logger.error("backhaulIdList is empty :::  " + backhaulIdList.size());
		}
		if (orders != null && orders.isPresent()) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "orders have record ::", this);
			Orders order = orders.get();
			commonBO.setOrderId(order.getOrderId());
			commonBO.setOrderStatusId(order.getOrderStatus().getOrderStatusId());
			commonBO.setOrderStatusName(order.getOrderStatus().getOrderStatusName());
			commonBO.setOrderContactId(order.getOrderContact().getOrderContactId());
			commonBO.setCreatedBy(order.getCreatedBy().getAttuid());
			commonBO.setUpdatedBy(order.getUpdatedBy().getAttuid());
			commonBO.setOrderTypeId(order.getOrderType().getOrderTypeId());
			commonBO.setOrderTypeName(order.getOrderType().getOrderTypeName());
			commonBO.setOrderStatusName(order.getOrderStatus().getOrderStatusName());
			commonBO.setApnProductionDate(order.getDateInProduction());
			commonBO.setApnSelection(order.getApnSelection());
			if (null != order.getExpedite()) {
				commonBO.setExpediteOrder(true);
			}
			if (null != pdpName) {
				commonBO.setPdpName(pdpName);
			}
			if (null != order.getSubAccount() && order.getSubAccount().getSubAccountName() != null) {
				commonBO.setAccountName(order.getSubAccount().getSubAccountName());
			} else {
				commonBO.setAccountName(order.getInternalProductAccount().getInternalProductAccountName());
			}
			if (null != order.getInternalProductAccount() && order.getInternalProductAccount().getCipn() != null) {
				commonBO.setCipn(order.getInternalProductAccount().getCipn());
				commonBO.setAccountClassId(order.getInternalProductAccount().getAccountClass().getAccountClassId());
				commonBO.setAccountClassName(order.getInternalProductAccount().getAccountClass().getAccountClassName());
			}
			if (null != order.getSubAccount() && order.getSubAccount().getBcid() != null) {
				commonBO.setBcId(order.getSubAccount().getBcid());
				commonBO.setUbcId(order.getSubAccount().getMasterAccount().getUbcid());
				commonBO.setAccountClassId(
						order.getSubAccount().getMasterAccount().getAccountClass().getAccountClassId());
				commonBO.setAccountClassName(
						order.getSubAccount().getMasterAccount().getAccountClass().getAccountClassName());
			}
		} else {
			logger.error("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "orders does not have record ::",
					this);
		}
		return commonBO;

	}

	@Override
	public CommonBO getOrderById(Long orderId) throws CamundaServiceException {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] " + "Starting method getOrderById : ", this);
		Optional<Orders> orders = ordersRepository.findById(orderId);
		List<String> backhaulIdList = orderDataCenterBackhaulRepository.getBackhaulIds(orderId);
		String pdpName = pdpIdInfoRepository.findAutoPdpNameByOrderId(orderId);
		if (pdpName == null) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + " does not has PDP NAME ::", this);
			pdpName = pdpIdInfoRepository.findUserPdpNameByOrderId(orderId);
		}
		CommonBO commonBO = new CommonBO();
		if (!CollectionUtils.isEmpty(backhaulIdList)) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "backhaulIdList have record ::",
					this);
			daoHelper.backHaulIdList(backhaulIdList, commonBO);
		} else {
			logger.error("backhaulIdList is empty :::  " + backhaulIdList.size());
		}
		if (orders != null && orders.isPresent()) {
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "orders have record ::", this);
			Orders order = orders.get();
			commonBO.setOrderId(order.getOrderId());
			commonBO.setOrderStatusId(order.getOrderStatus().getOrderStatusId());
			commonBO.setOrderStatusName(order.getOrderStatus().getOrderStatusName());
			commonBO.setOrderContactId(order.getOrderContact().getOrderContactId());
			commonBO.setCreatedBy(order.getCreatedBy().getAttuid());
			commonBO.setUpdatedBy(order.getUpdatedBy().getAttuid());
			commonBO.setOrderTypeId(order.getOrderType().getOrderTypeId());
			commonBO.setOrderTypeName(order.getOrderType().getOrderTypeName());

			commonBO.setApnName(order.getApn().getApnName());
			commonBO.setApnProductionDate(order.getDateInProduction());
			commonBO.setApnSelection(order.getApnSelection());
			if (null != order.getExpedite()) {
				commonBO.setExpediteOrder(true);
			}
			if (null != pdpName) {
				commonBO.setPdpName(pdpName);
			}
			if (null != order.getSubAccount() && order.getSubAccount().getSubAccountName() != null) {
				commonBO.setAccountName(order.getSubAccount().getSubAccountName());
			} else {
				commonBO.setAccountName(order.getInternalProductAccount().getInternalProductAccountName());
			}
			if (null != order.getInternalProductAccount() && order.getInternalProductAccount().getCipn() != null) {
				commonBO.setCipn(order.getInternalProductAccount().getCipn());
				commonBO.setAccountClassId(order.getInternalProductAccount().getAccountClass().getAccountClassId());
				commonBO.setAccountClassName(order.getInternalProductAccount().getAccountClass().getAccountClassName());
			}
			if (null != order.getSubAccount() && order.getSubAccount().getBcid() != null) {
				commonBO.setBcId(order.getSubAccount().getBcid());
				commonBO.setUbcId(order.getSubAccount().getMasterAccount().getUbcid());
				commonBO.setAccountClassId(
						order.getSubAccount().getMasterAccount().getAccountClass().getAccountClassId());
				commonBO.setAccountClassName(
						order.getSubAccount().getMasterAccount().getAccountClass().getAccountClassName());
			}
		} else {
			logger.error("[OrderID : " + (orderId == null ? "" : orderId) + "] " + "orders does not have record ::",
					this);
		}
		return commonBO;
	}

	@Override
	public void saveOrderStatusHistory(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();

		OrderStatusHistory orderStatusHistory = new OrderStatusHistory();

		Orders orders = new Orders();
		orders.setOrderId(commonBO.getOrderId());

		OrderStatus orderStatus = new OrderStatus();
		orderStatus.setOrderStatusId(commonBO.getOrderStatusId());

		Users users = new Users();
		users.setAttuid(commonBO.getUpdatedBy());

		orderStatusHistory.setOrders(orders);
		orderStatusHistory.setOrderStatus(orderStatus);
		orderStatusHistory.setUpdatedOn(today);
		orderStatusHistory.setComments(commonBO.getComments());
		orderStatusHistory.setUsers(users);
		orderStatusHistoryRepository.save(orderStatusHistory);

	}

	@Override
	public long countOrderEvent(CommonBO commonBO) {
		return orderEventRepository.countByOrderIdAndEventStatusNot(commonBO.getOrderId(), "REJECTED");
	}

	@Override
	public List<String> getOrderContactInfoATTUId(CommonBO commonBO) throws CamundaServiceException {
		return orderContactInfoRepository.getOrderContactInfoATTUId(commonBO.getOrderId(),
				commonBO.getOrderContactTypeId(), 'Y');
	}

	@Override
	public void updateOrderContactInfo(CommonBO commonBO) {
		OrderContactInfoId orderContactInfoId = new OrderContactInfoId();
		orderContactInfoId.setOrderContactId(commonBO.getOrderContactId());
		orderContactInfoId.setOrderContactTypeId(commonBO.getOrderContactTypeId());
		Optional<OrderContactInfo> optional = orderContactInfoRepository.findById(orderContactInfoId);
		if (optional.isPresent()) {
			OrderContactInfo orderContactInfo = optional.get();
			Users users = new Users();
			users.setAttuid(commonBO.getUpdatedBy());
			orderContactInfo.setUsers(users);
			orderContactInfoRepository.save(orderContactInfo);
		}
	}

	@Override
	public List<Object[]> getATTUIDFirstNameLastName(CommonBO commonBO) {
		return orderContactInfoRepository.getATTUIDFirstNameLastName(commonBO.getOrderId(), 'Y',
				commonBO.getOrderContactTypeId());
	}

	@Override
	public void saveOrderComments(CommonBO commonBO) {
		OrderComments orderComments = new OrderComments();
		Date today = new Date();
		Role role = new Role();
		role.setRoleId(commonBO.getRoleId());
		Orders orders = new Orders();
		orders.setOrderId(commonBO.getOrderId());
		Users users = new Users();
		users.setAttuid(commonBO.getUpdatedBy());

		orderComments.setOrders(orders);
		orderComments.setUsers(users);
		orderComments.setComments(commonBO.getComments());
		orderComments.setUserAction(commonBO.getUserAction());
		orderComments.setCreatedOn(today);
		orderComments.setRole(role);
		orderComments.setOrderProcess(commonBO.getOrderOperation());
		orderCommentsRepository.save(orderComments);

	}

	@Override
	public String getOrderComments(CommonBO commonBO) {
		return orderCommentsRepository.getOrderComments(commonBO.getOrderId(), commonBO.getUserAction(),
				commonBO.getOrderProcess());
	}

	@Override
	public OrderFlagsDetails findOrderFlagsDetails(CommonBO commonBO) {
		OrderFlagsDetails orderFlagsDetails = new OrderFlagsDetails();
		OrderFlagsDetailsPK orderFlagsDetailsPK = new OrderFlagsDetailsPK();
		orderFlagsDetailsPK.setFlagId(commonBO.getFlagId());
		orderFlagsDetailsPK.setOrderId(commonBO.getOrderId());
		Optional<OrderFlagsDetails> flagsDetails = orderFlagsDetailsRepository.findById(orderFlagsDetailsPK);
		if (flagsDetails.isPresent()) {
			orderFlagsDetails = flagsDetails.get();
		}
		return orderFlagsDetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getBillingData(CommonBO commonBO) {
		String sql = "SELECT\r\n" + "NVL(sa.sub_account_name,ipa.internal_product_account_name) AS account_name,\r\n"
				+ "sa.bl_street_address || ' ' ||\r\n"
				+ "(select city_name from city where city_id = sa.bl_city_id) || ' ' ||\r\n"
				+ "(select state_name from state where state_id = sa.bl_state_id) || ' ' ||\r\n"
				+ "(select country_name from country where country_id=sa.bl_country_id) || ' ' ||\r\n"
				+ "sa.bl_zip_code as company_billing_address,\r\n"
				+ "sa.main_cust_contact || ' / ' || sa.mcc_deskphone as cust_name_phone,\r\n"
				+ "sa.federal_tax_id as federal_tax_id,\r\n" + "NVL(oa.ban_id,'N/A') as billing_account_number,\r\n"
				+ "NVL(oa.fan_id,'N/A') as foundation_account_number,\r\n"
				+ "(select name from order_contact_info where order_contact_type_id = '1001' and order_contact_id = (select order_contact_id from order_contact where order_id=?)) as account_manager, \r\n"
				+ "(select u.firstname || ' ' || u.lastname  || ' (' || u.attuid || ')' from order_contact_info oci, users u where oci.order_contact_type_id = '1003' and oci.order_contact_id = (select order_contact_id from order_contact where order_id=?) and oci.attuid = u.attuid) as mobility_tech_engg, \r\n"
				+ "o.order_id as order_id ,\r\n" + "o.order_type_id as order_type_id ,\r\n"
				+ "case when o.change_request = 'F' then 'Change Request' when o.order_type_id = 1004 then 'Change Order'\r\n"
				+ "when o.order_type_id = 1001 then 'New' when o.order_type_id = 1006 then 'Decommission' else '' end as Process_Type,\r\n"
				+ "NVL(NVL(apn.apn_name,da.apn_name),'N/A') AS APN_Name ,\r\n"
				+ "NVL((select listagg(pdp.auto_pdp_name , ', ') \r\n"
				+ "   within group (order by pdp.auto_pdp_name) from pdp_id_info pdp where pdp.order_id = o.order_id),'N/A') AS PDP_Name ,\r\n"
				+ "NVL(apn.ip_address_source,'N/A') as sorce_of_ip_addressing,\r\n"
				+ "NVL(apn.address_type,'N/A') as type_of_addressing,\r\n"
				+ "NVL((select LISTAGG(b.backhaul_display_id, ', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from order_data_center_backhaul odc, backhaul b where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id),'N/A') AS Backhaul_Id,\r\n"
				+ "NVL ((select LISTAGG(odc.backhaul_selection, ', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from order_data_center_backhaul odc, backhaul b where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id),'N/A') AS backhaul_instance,\r\n"
				+ "NVL (( select LISTAGG(mpls.mpls_cir,', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from mpls mpls, backhaul b,order_data_center_backhaul odc where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id and mpls.backhaul_id = b.backhaul_id ),'N/A') AS mpls_cir,\r\n"
				+ "NVL(to_char(sa.bcid),ipa.cipn) AS account_id_cipn ,\r\n"
				+ "NVL(case when oa.eod_enabled = 'Y' then 'Yes' else 'No' end,'No') as EOD,\r\n"
				+ "case when oa.fee_waiver_approved = 'Y' then 'Yes' else 'No' end as fee_waiver_approved,\r\n"
				+ "NVL(case when apn.managed_avpn = 'Y' then 'Yes' else 'No' end,'No') as managed_avpn\r\n"
				+ "FROM orders o ,\r\n" + "apn apn ,\r\n" + "dedicated_apn da ,\r\n" + "pdp_id_info pdp ,\r\n"
				+ "sub_account sa ,\r\n" + "internal_product_account ipa ,\r\n" + "order_type ot ,\r\n"
				+ "order_account oa\r\n" + "WHERE o.order_id = ?\r\n" + "AND o.order_id = apn.order_id (+)\r\n"
				+ "AND o.order_id = da.order_id(+)\r\n" + "AND o.order_id = pdp.order_id (+)\r\n"
				+ "AND o.order_id = oa.order_id(+)\r\n" + "AND o.bcid = sa.bcid (+)\r\n"
				+ "AND o.cipn = ipa.cipn (+)\r\n" + "AND o.order_type_id = ot.order_type_id\r\n" + "AND ROWNUM = 1\r\n"
				+ "";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderId());
		query.setParameter(3, commonBO.getOrderId());
		return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getItOpsTaskData(CommonBO commonBO) {
		String sql = "SELECT o.order_id AS Order_Id , \r\n" + 
				"	ot.order_type_name AS Process_Type , \r\n" + 
				"	NVL(NVL(apn.apn_name,da.apn_name),'N/A') AS APN_Name , \r\n" + 
				"	NVL(pdp.auto_pdp_name, NVL(NVL(pdp.user_pdp_name,da.pdp_name),'N/A')) AS PDP_Name , \r\n" + 
				"	NVL((select LISTAGG(b.backhaul_display_id, ', ') WITHIN GROUP (ORDER BY odc.order_id) \r\n" +  
				"	from order_data_center_backhaul odc, backhaul b where odc.order_id = o.order_id \r\n" + 
				"	and odc.backhaul_id = b.backhaul_id),'N/A') AS  Backhaul_Id , \r\n" + 
				"	NVL(to_char(sa.bcid),ipa.cipn) AS Account_Id_CIPN , \r\n" + 
				"	NVL(sa.sub_account_name,ipa.internal_product_account_name) AS Account_Name , \r\n" + 
				"	case when o.order_id is not null then 'Gold' else '' end   AS APN_TYPE , \r\n" + 
				"	NVL(apn.ADDRESS_TYPE,'N/A') as IP_TYPE , \r\n" + 
				"	case when apn.ADDRESS_TYPE = 'Static' and apn.IP_ADDRESS_SOURCE = 'PublicATTProvided' then 'Yes' else 'No' end as MRC , \r\n" + 
				"	o.order_id                    AS ERICSSON_CODE           , \r\n" +
				"	nvl(to_char(nvl(pdp.user_pdp_id, nvl(pdp.auto_pdp_id, da.pdp_id))),'N/A') AS PDP_ID , \r\n" + 
				"	sa.company_name               AS COMPANY_NAME            , \r\n" + 
				"	ma.master_account_name        AS ULTIMATE_ACCOUNT_NAME  , \r\n" + 
				"	ma.ubcid                      AS MASTER_ACCOUNT_ID       , \r\n" + 
				"   NVL(sa.sub_account_name,ipa.internal_product_account_name) AS SUB_ACCOUNT_NAME , \r\n" + 
				"	oa.agreement_account_name     AS AGREEMENT_ACCOUNT_NAME  , \r\n" + 
				"	oa.agreement_account_no       AS AGREEMENT_ACCOUNT_NUMBER , \r\n" + 
				"	oa.fan_id                     AS FAN_ACCOUNT_NUMBER      , \r\n" + 
				"	ppack.pdp_package_name        AS PDP_PACKAGE_NAME        , \r\n" + 
				"	ppack.pdp_package_description AS PDP_PACKAGE_DESC , \r\n" + 
				"	nvl(oa.pdp_description,'N/A') as PDP_DESCRIPTION , \r\n" + 
				"	apn.IPBR  as IPBR , \r\n" + 
				"	apn.OCS  as OCS , \r\n" + 
				"	o.firstnet_epc as first_net \r\n" + 
				"	FROM orders o                  , \r\n" + 
				"	order_account oa               , \r\n" + 
				"	apn apn                        , \r\n" + 
				"	dedicated_apn da               , \r\n" + 
				"	pdp_id_info pdp                , \r\n" + 
				"	sub_account sa                 , \r\n" + 
				"	PDP_PACKAGE ppack              , \r\n" + 
				"	master_account ma              , \r\n" + 
				"	internal_product_account ipa   , \r\n" + 
				"	order_type ot                    \r\n" + 
				"	WHERE o.order_id    = ? \r\n" + 
				"	AND o.order_id        = oa.order_id (+) \r\n" + 
				"	AND o.order_id        = apn.order_id (+) \r\n" + 
				"	AND apn.order_id      = pdp.order_id (+) \r\n" + 
				"	AND o.order_id	   	  = da.order_id(+) \r\n" + 
				"	AND o.bcid            = sa.bcid (+) \r\n" + 
				"	AND oa.pdp_package_id = ppack.pdp_package_id (+) \r\n" + 
				"	AND sa.ubcid          = ma.ubcid(+) \r\n" + 
				"	AND o.cipn            = ipa.cipn (+) \r\n" + 
				"	AND o.order_type_id   = ot.order_type_id";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		return query.getResultList();
	}

	@Override
	public void saveOrderBillingTask(CommonBO commonBO) {
		Date today = new Date();
		String sql = "INSERT INTO ORDER_BILLING_TASK(ORDER_ID,TASK_ID,TASK_NAME,DISPLAY_NAME,CREATION_DATE,CREATED_BY,ROLE_ID,STATUS) VALUES (?,?,?,?,?,?,?,?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getBpmTaskId());
		query.setParameter(3, commonBO.getTaskName());
		query.setParameter(4, commonBO.getTaskDisplayName());
		query.setParameter(5, today);
		query.setParameter(6, commonBO.getAssignee());
		query.setParameter(7, 1002);
		query.setParameter(8, 1001);
		query.executeUpdate();
	}

	@Override
	public void updateOrderBillingTask(CommonBO commonBO) {
		Date today = new Date();
		String sql = "UPDATE ORDER_BILLING_TASK SET STATUS = 1002 , COMPLETED_BY = ? , COMPLETION_DATE = ? WHERE ORDER_ID = ? AND TASK_ID = ?  ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getAssignee());
		query.setParameter(2, today);
		query.setParameter(3, commonBO.getOrderId());
		query.setParameter(4, commonBO.getBpmTaskId());
		query.executeUpdate();
	}

	@Override
	public void updateOrderFlagDetails(CommonBO commonBO) {
		logger.info("@Starting method updateOrderFlagDetails ", this);
		if (commonBO.getFlagIdList() != null && commonBO.getFlagIdList().size() > 0) {
			Date today = new Date();
			for (Long orderFlagId : commonBO.getFlagIdList()) {
				OrderFlagsDetailsPK orderFlagsDetailsPK = new OrderFlagsDetailsPK();
				orderFlagsDetailsPK.setFlagId(orderFlagId);
				orderFlagsDetailsPK.setOrderId(commonBO.getOrderId());
				Optional<OrderFlagsDetails> flagsDetails = orderFlagsDetailsRepository.findById(orderFlagsDetailsPK);
				if (flagsDetails.isPresent()) {
					Orders orders = new Orders();
					orders.setOrderId(commonBO.getOrderId());
					OrderFlagsDetails orderFlagDetails = new OrderFlagsDetails();
					orderFlagsDetailsPK.setFlagId(orderFlagId);
					orderFlagsDetailsPK.setOrderId(commonBO.getOrderId());
					orderFlagDetails.setOrders(orders);
					OrderFlags orderFlags = new OrderFlags();
					orderFlags.setFlagId(orderFlagId);
					orderFlagDetails.setCompositeKey(orderFlagsDetailsPK);
					orderFlagDetails.setFlagValue(commonBO.getOrderFlagValue());
					orderFlagDetails.setUpdatedOn(today);
					orderFlagDetails.setOrderFlags(orderFlags);
					orderFlagsDetailsRepository.save(orderFlagDetails);
				}
			}
		}
	}

	@Override
	public void saveOrderStatusIdByOrderId(CommonBO commonBO) throws CamundaServiceException {
		ordersRepository.updateOrderStatusIdByOrderId(commonBO.getOrderId(), commonBO.getOrderStatusId());
	}

	@Override
	public void updateOrderUserBpmTasksRepository(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method updateOrderUserBpmTasksRepository ", this);
		Optional<OrderUserBpmTasks> orderUserBpmtaskOp = orderUserBpmTasksRepository.findById(commonBO.getBpmTaskId());
		if (orderUserBpmtaskOp.isPresent()) {
			OrderUserBpmTasks orderUserBpmTasks = orderUserBpmtaskOp.get();
			// updating on existing BPM task ID
			orderUserBpmTasks.setBpmTaskId(String.valueOf(commonBO.getBpmTaskId()));
			Orders orders = new Orders();
			orders.setOrderId(commonBO.getOrderId());
			orderUserBpmTasks.setOrders(orders);

			// orderUserBpmTasks.setAttuid(commonBO.getAttuid());
			if (commonBO.isExpediteOrder()) {
				orderUserBpmTasks.setExpedite('Y');
			}
			Role role = new Role();
			role.setRoleId(commonBO.getRoleId());
			orderUserBpmTasks.setRole(role);

			Optional<TaskCategory> taskCategoryOP = taskCategoryRepository.findById(commonBO.getCategoryId());
			if (taskCategoryOP.isPresent()) {
				TaskCategory taskCategory = taskCategoryOP.get();
				taskCategory.getTaskCategoryId();
				taskCategory.getTaskCategoryDesc();
				orderUserBpmTasks.setTaskCategory(taskCategory);
			}
			Optional<TaskStatus> taskStatusOP = taskStatusRepository.findById(commonBO.getTaskStatusId());
			if (taskStatusOP.isPresent()) {
				TaskStatus taskStatus = taskStatusOP.get();
				taskStatus.getTaskStatusId();
				taskStatus.getTaskStatusDesc();
				orderUserBpmTasks.setTaskStatus(taskStatus);
			}

			Optional<BpmTask> bpmTaskOpt = bpmTaskRepository.findById(commonBO.getTaskId());
			if (bpmTaskOpt.isPresent()) {
				BpmTask bpmTask = bpmTaskOpt.get();
				orderUserBpmTasks.setBpmTask(bpmTask);
			}
			orderUserBpmTasks.setCreationDate(commonBO.getTaskCreationTime());
			orderUserBpmTasks.setCompletionDate(commonBO.getTaskCompletionTime());
			orderUserBpmTasks.setAccountName(commonBO.getAccountName());
			orderUserBpmTasks.setApnName(commonBO.getApnName());
			orderUserBpmTasks.setSubject(commonBO.getTaskDescription());// Set on BPM Diagram
			orderUserBpmTasks.setOrderOperation(commonBO.getOrderOperation());
			orderUserBpmTasks.setProcessId(commonBO.getBpmProcessId());
			orderUserBpmTasks.setProcessInstanceId(commonBO.getBpmProcessInstanceId());
			orderUserBpmTasksRepository.saveAndFlush(orderUserBpmTasks);
		} else {
			/// Preparing data for update Comet DB ORDER USER BPM TASK TABLE new ENTRY
			OrderUserBpmTasks orderUserBpmTasks = new OrderUserBpmTasks();
			orderUserBpmTasks.setBpmTaskId(String.valueOf(commonBO.getBpmTaskId()));

			Orders orders = new Orders();
			orders.setOrderId(commonBO.getOrderId());
			orderUserBpmTasks.setOrders(orders);

			orderUserBpmTasks.setAttuid(commonBO.getAssignee());// from task listener
			if (commonBO.isExpediteOrder()) {
				orderUserBpmTasks.setExpedite('Y');
			}
			Role role = new Role();
			role.setRoleId(commonBO.getRoleId());
			orderUserBpmTasks.setRole(role);

			Optional<TaskCategory> taskCategoryOP = taskCategoryRepository.findById(commonBO.getCategoryId());
			if (taskCategoryOP.isPresent()) {
				TaskCategory taskCategory = taskCategoryOP.get();
				taskCategory.getTaskCategoryId();
				taskCategory.getTaskCategoryDesc();
				orderUserBpmTasks.setTaskCategory(taskCategory);
			}
			Optional<TaskStatus> taskStatusOP = taskStatusRepository.findById(commonBO.getTaskStatusId());
			if (taskStatusOP.isPresent()) {
				TaskStatus taskStatus = taskStatusOP.get();
				taskStatus.getTaskStatusId();
				taskStatus.getTaskStatusDesc();
				orderUserBpmTasks.setTaskStatus(taskStatus);
			}

			Optional<BpmTask> bpmTaskOpt = bpmTaskRepository.findById(commonBO.getTaskId());
			if (bpmTaskOpt.isPresent()) {
				BpmTask bpmTask = bpmTaskOpt.get();
				orderUserBpmTasks.setBpmTask(bpmTask);
			}
			/**
			 * 1038L cancel order dashboard 1032L Change order dashboard 1029L Change
			 * Request dasboard 1041L Decommission Dashboard
			 */
			if (commonBO.getTaskId().equals(1038L) || commonBO.getTaskId().equals(1032L)
					|| commonBO.getTaskId().equals(1029L) || commonBO.getTaskId().equals(1041L)) {
				orderUserBpmTasks.setDashboardFlag('Y');
				orderUserBpmTasks.setDashboardLinkComplete('N');// this only Dashboard link complete task only , when is
																// completed form FE , service code will update to Y,
																// but from BPM its always N
				logger.debug("Dasboard board Flag set to Y", this);
			} else {
				orderUserBpmTasks.setDashboardFlag('N');
				orderUserBpmTasks.setDashboardLinkComplete('N');// this only Dashboard link complete task only , when is
																// completed form FE , service code will update to Y,
																// but from BPM its always N
				logger.debug("Dasboard board Flag set to N", this);
			}
			orderUserBpmTasks.setCreationDate(commonBO.getTaskCreationTime());
			orderUserBpmTasks.setCompletionDate(commonBO.getTaskCompletionTime());
			orderUserBpmTasks.setAccountName(commonBO.getAccountName());
			orderUserBpmTasks.setApnName(commonBO.getApnName());
			orderUserBpmTasks.setSubject(commonBO.getTaskDescription());// Set on BPM Diagram
			orderUserBpmTasks.setOrderOperation(commonBO.getOrderOperation());
			orderUserBpmTasks.setProcessId(commonBO.getBpmProcessId());
			orderUserBpmTasks.setProcessInstanceId(commonBO.getBpmProcessInstanceId());
			orderUserBpmTasksRepository.saveAndFlush(orderUserBpmTasks);
		}

		logger.info("@Ending method updateOrderUserBpmTasksRepository ", this);
	}

	@Override
	public void deleteOrderFlagDetails(CommonBO commonBO) {
		String sql = "delete from order_flags_details where flag_id in :flagIdList and order_id = :orderId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("flagIdList", commonBO.getFlagIdList());
		query.setParameter("orderId", commonBO.getOrderId());
		query.executeUpdate();

	}

	@Override
	public Date getBackHaulConfig(CommonBO commonBO) {
		Long orderId = commonBO.getOrderId();
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] " + "Starting method getBackHaulConfig : ",
				this);
		BackhaulConfig backhaulConfig = null;
		Optional<BackhaulConfig> backhaulConfigOptional = backHaulConfgurationRespository.findById(orderId);
		if (backhaulConfigOptional.isPresent()) {
			logger.debug(
					"[OrderID : " + (orderId == null ? "" : orderId) + "] " + "backhaulConfigOptional have record ::",
					this);
			Date apnInProductionDate = backhaulConfigOptional.get().getApnInProductionDate();
			return apnInProductionDate;
		} else {
			logger.error("backhaulConfigOptional is null for Order Id:::[" + orderId + "]", this);
			return null;
		}
	}

	@Override
	public void updateBackhaulConfig(CommonBO commonBO) {
		String sql = "update backhaul_config set apn_inproduction_date = :apnInProductionDate where order_id = :orderId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("apnInProductionDate", commonBO.getApnProductionDate());
		query.setParameter("orderId", commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public void updateImsiInventory(CommonBO commonBO) {
		String sql = "update imsi_msisdn_inventory set order_id = null where order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public String completeOrderWorkFlow(Long orderId, String orderOperation) throws CamundaServiceException {
		logger.info(
				"[OrderId : " + (orderId == null ? "" : orderId) + "] " + "Starting method completeOrderWorkFlow : ",
				this);
		String package_Name = "COMET_ORDER_PKG.COMPLETE_ORDER_WORKFLOW";
		String completeOrderWorkFlow = "Success";
		String errorMsg = null;
		if (null != orderId && null != orderOperation) {
			StoredProcedureQuery sProcQury = entityManager.createStoredProcedureQuery(package_Name);
			sProcQury.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);

			sProcQury.registerStoredProcedureParameter(3, String.class, ParameterMode.OUT);

			sProcQury.setParameter(1, orderId);
			sProcQury.setParameter(2, orderOperation);

			sProcQury.execute();
			errorMsg = (String) sProcQury.getOutputParameterValue(3);

			if (CommonUtils.isValidString(errorMsg)) {
				completeOrderWorkFlow = "Failed";
			}
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] " + "completeOrderWorkFlow : "
				+ completeOrderWorkFlow, this);
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] " + "Ending method completeOrderWorkFlow : ",
				this);
		return completeOrderWorkFlow;

	}

	@Override
	public boolean completeCancelOrderWorkFlow(CommonBO commonBO) {
		String package_Name = "UPDATE_ORDERS_ON_CO_CANCEL";
		String completeOrderWorkFlow = "Success";

		if (null != commonBO) {
			// StoredProcedureQuery sProcQury =
			// entityManager.createStoredProcedureQuery(varibale name );
			StoredProcedureQuery sProcQury = entityManager.createStoredProcedureQuery(package_Name);
			sProcQury.registerStoredProcedureParameter(0, Long.class, ParameterMode.IN);
			// sProcQury.registerStoredProcedureParameter(2, String.class,
			// ParameterMode.OUT);
			// sProcQury.registerStoredProcedureParameter(3, String.class,
			// ParameterMode.OUT);
			sProcQury.setParameter(0, commonBO.getOrderId());
			return sProcQury.execute();
		}
		logger.info("[OrderId : " + (commonBO.getOrderId() == null ? "" : commonBO.getOrderId()) + "] "
				+ "completeOrderWorkFlow : " + completeOrderWorkFlow, this);
		logger.info("[OrderId : " + (commonBO.getOrderId() == null ? "" : commonBO.getOrderId()) + "] "
				+ "Ending method completeOrderWorkFlow : ", this);
		return false;
	}

	@Override
	public void updateOrderUserTaskFaults(OrderUserTaskFaultsBO orderUserTaskFaultsBO) {
		logger.info("@Starting method updateOrderUserTaskFaults ", this);

		Optional<OrderUserTaskFaults> orderUserTaskFaultsBOOptional = orderUserTaskFaultsRepository
				.findById(orderUserTaskFaultsBO.getBpmTaskId());
		if (orderUserTaskFaultsBOOptional.isPresent()) {
			OrderUserTaskFaults orderUserTaskFaults = orderUserTaskFaultsBOOptional.get();

			orderUserTaskFaults.setErrorCode(orderUserTaskFaultsBO.getErrorCode());
			orderUserTaskFaults.setErrorDesc(orderUserTaskFaultsBO.getErrorDesc());
			orderUserTaskFaults.setCreationOn(orderUserTaskFaultsBO.getCreationOn());
			orderUserTaskFaultsRepository.saveAndFlush(orderUserTaskFaults);
		} else {
			OrderUserTaskFaults orderUserTaskFaults = new OrderUserTaskFaults();

			OrderUserBpmTasks orderUserBpmTasks = new OrderUserBpmTasks();
			orderUserBpmTasks.setBpmTaskId(String.valueOf(orderUserTaskFaultsBO.getBpmTaskId()));
			orderUserTaskFaults.setOrderUserBpmTasks(orderUserBpmTasks);

			orderUserTaskFaults.setErrorCode(orderUserTaskFaultsBO.getErrorCode());
			orderUserTaskFaults.setErrorDesc(orderUserTaskFaultsBO.getErrorDesc());
			orderUserTaskFaults.setCreationOn(orderUserTaskFaultsBO.getCreationOn());
			orderUserTaskFaultsRepository.saveAndFlush(orderUserTaskFaults);
		}
		logger.info("@Ending method updateOrderUserTaskFaults ", this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getOrderOnHoldDetails(CommonBO commonBO) {
		String sql = "select ooh.requested_on,ooh.prop_comp_date,ooh.on_hold_reason,ooh.on_hold_notes from order_on_hold ooh where ooh.on_hold_id = (select max(on_hold_id) as on_hold_id from order_on_hold where order_id=:orderId) and order_id = :orderId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", commonBO.getOrderId());
		return query.getResultList();
	}

	@Override
	public void updateOrderOnHoldStatusId(CommonBO commonBO) throws CamundaServiceException {
		String sql = "UPDATE ORDER_ON_HOLD SET ON_HOLD_STATUS_ID = ? where on_hold_id = (select max(on_hold_id) as on_hold_id from order_on_hold where order_id= ?) and order_id = ? ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOnHoldStatusId());
		query.setParameter(2, commonBO.getOrderId());
		query.setParameter(3, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public void updateOrderStatusOnhold(CommonBO commonBO) {
		String sql = "UPDATE ORDERS SET ORDER_STATUS_ID = 1047 WHERE ORDER_ID = ? ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.executeUpdate();
	}

	@Override
	public void updateOrderOnHoldApprovedDate(CommonBO commonBO) throws CamundaServiceException {
		Date today = new Date();
		String sql = "UPDATE ORDER_ON_HOLD SET ON_HOLD_APPROVED = ? where on_hold_id = (select max(on_hold_id) as on_hold_id from order_on_hold where order_id= ?) and order_id = ? ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, today);
		query.setParameter(2, commonBO.getOrderId());
		query.setParameter(3, commonBO.getOrderId());
		query.executeUpdate();

	}

	@Override
	public String getOrderOnHoldCancelNotes(CommonBO commonBO) throws CamundaServiceException {
		String sql = "select CANCEL_NOTES from order_on_hold ooh where ooh.on_hold_id = (select max(on_hold_id) as on_hold_id from order_on_hold where order_id= ?) and order_id = ? ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderId());
		String cancelNotes = null;
		try {
			@SuppressWarnings("unchecked")
			List<String> cancelNotesList = query.getResultList();
			if (cancelNotesList != null && cancelNotesList.size() > 0) {
				cancelNotes = cancelNotesList.get(0);
			} else {
				cancelNotes = null;
			}
		} catch (NoResultException nre) {
			logger.info(" Exception :: " + nre.getMessage());
		}
		return cancelNotes;

	}

	@Override
	public String getOrderOnHoldResumeNotes(CommonBO commonBO) throws CamundaServiceException {
		String sql = "select RESOLVE_NOTES from order_on_hold ooh where ooh.on_hold_id = (select max(on_hold_id) as on_hold_id from order_on_hold where order_id=?) and order_id = ? ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderId());
		String resumeNotes = null;
		try {
			@SuppressWarnings("unchecked")
			List<String> resumeNotesList = query.getResultList();
			if (resumeNotesList != null && resumeNotesList.size() > 0) {
				resumeNotes = resumeNotesList.get(0);
			} else {
				resumeNotes = null;
			}
		} catch (NoResultException nre) {
			logger.info(" Exception :: " + nre.getMessage());
		}
		return resumeNotes;
	}

	@Override
	public Long getDerivedOrderId(CommonBO commonBO) throws CamundaServiceException {
		long derivedFromOrderId = 0L;
		try {
			if (commonBO.getOrderId() != null) {
				Optional<Orders> ordersOpt = ordersRepository.findById(commonBO.getOrderId());
				if (ordersOpt.isPresent()) {
					logger.info("ordersOpt is not null ");
					derivedFromOrderId = ordersOpt.get().getDerivedFromOrder();
					if(CommonUtils.isNotNullEmpty(derivedFromOrderId)) {
						logger.info(" @@ derivedFromOrderId @@ "+derivedFromOrderId,this);
						return derivedFromOrderId;
					}else {
						logger.error(" @@ derivedFromOrderId is null @@");
						return 0L;
					}

				} else {
					logger.error(" @@ ordersOpt is null @@");
				}
			}

		} catch (NoResultException nre) {
			logger.info(" Exception :: " + nre.getMessage());
		}
		return derivedFromOrderId;
	}

	@Override
	public void updateOrderUserBpmTasksForException(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method updateOrderUserBpmTasksForException ", this);
		Orders odr = new Orders();
		odr.setOrderId(commonBO.getOrderId());

		BpmTask taskId = new BpmTask();
		taskId.setTaskId(commonBO.getTaskId());

		TaskCategory category = new TaskCategory();
		category.setTaskCategoryId(commonBO.getCategoryId());

		List<OrderUserBpmTasks> orderUserBpmTasksList = orderUserBpmTasksRepository
				.findByOrdersAndBpmTaskAndTaskCategory(odr, taskId, category);
		if (orderUserBpmTasksList != null && orderUserBpmTasksList.size() > 0) {
			List<OrderUserBpmTasks> bpmTaskList = new ArrayList<>();
			for (OrderUserBpmTasks orderUserBpmTasks : orderUserBpmTasksList) {
				TaskStatus taskStatus = new TaskStatus();
				taskStatus.setTaskStatusId(commonBO.getTaskStatusId());
				orderUserBpmTasks.setTaskStatus(taskStatus);
				bpmTaskList.add(orderUserBpmTasks);
			}
			orderUserBpmTasksRepository.saveAll(bpmTaskList);
		} else {
			/// Preparing data for update Comet DB ORDER USER BPM TASK TABLE new ENTRY
			OrderUserBpmTasks orderUserBpmTasks = new OrderUserBpmTasks();
			orderUserBpmTasks.setBpmTaskId(String.valueOf(commonBO.getBpmTaskId()));

			Orders orders = new Orders();
			orders.setOrderId(commonBO.getOrderId());
			orderUserBpmTasks.setOrders(orders);

			orderUserBpmTasks.setAttuid(commonBO.getAssignee());// from task listener
			if (commonBO.isExpediteOrder()) {
				orderUserBpmTasks.setExpedite('Y');
			}
			Role role = new Role();
			role.setRoleId(commonBO.getRoleId());
			orderUserBpmTasks.setRole(role);

			Optional<TaskCategory> taskCategoryOP = taskCategoryRepository.findById(commonBO.getCategoryId());
			if (taskCategoryOP.isPresent()) {
				TaskCategory taskCategory = taskCategoryOP.get();
				taskCategory.getTaskCategoryId();
				taskCategory.getTaskCategoryDesc();
				orderUserBpmTasks.setTaskCategory(taskCategory);
			}
			Optional<TaskStatus> taskStatusOP = taskStatusRepository.findById(commonBO.getTaskStatusId());
			if (taskStatusOP.isPresent()) {
				TaskStatus taskStatus = taskStatusOP.get();
				taskStatus.getTaskStatusId();
				taskStatus.getTaskStatusDesc();
				orderUserBpmTasks.setTaskStatus(taskStatus);
			}

			Optional<BpmTask> bpmTaskOpt = bpmTaskRepository.findById(commonBO.getTaskId());
			if (bpmTaskOpt.isPresent()) {
				BpmTask bpmTask = bpmTaskOpt.get();
				orderUserBpmTasks.setBpmTask(bpmTask);
			}
			/**
			 * 1038L cancel order dashboard 1032L Change order dashboard 1029L Change
			 * Request dasboard 1041L Decommission Dashboard
			 */
			if (commonBO.getTaskId().equals(1038L) || commonBO.getTaskId().equals(1032L)
					|| commonBO.getTaskId().equals(1029L) || commonBO.getTaskId().equals(1041L)) {
				orderUserBpmTasks.setDashboardFlag('Y');
				orderUserBpmTasks.setDashboardLinkComplete('N');// this only Dashboard link complete task only , when is
																// completed form FE , service code will update to Y,
																// but from BPM its always N
				logger.debug("Dasboard board Flag set to Y", this);
			} else {
				orderUserBpmTasks.setDashboardFlag('N');
				orderUserBpmTasks.setDashboardLinkComplete('N');// this only Dashboard link complete task only , when is
																// completed form FE , service code will update to Y,
																// but from BPM its always N
				logger.debug("Dasboard board Flag set to N", this);
			}
			orderUserBpmTasks.setCreationDate(commonBO.getTaskCreationTime());
			orderUserBpmTasks.setCompletionDate(commonBO.getTaskCompletionTime());
			orderUserBpmTasks.setAccountName(commonBO.getAccountName());
			orderUserBpmTasks.setApnName(commonBO.getApnName());
			orderUserBpmTasks.setSubject(commonBO.getTaskDescription());// Set on BPM Diagram
			orderUserBpmTasks.setOrderOperation(commonBO.getOrderOperation());
			orderUserBpmTasks.setProcessId(commonBO.getBpmProcessId());
			orderUserBpmTasksRepository.saveAndFlush(orderUserBpmTasks);
		}
		logger.info("@End method updateOrderUserBpmTasksForException ", this);
	}

	@Override
	public void rollbackAuditOrder(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Start method rollbackAuditOrder ", this);
		String ROLLBACK_ORDER_AUDIT = "COMET_AUDIT_PKG.ROLLBACK_ORDER_AUDIT";
		Long orderId = commonBO.getOrderId();
		String eventName = commonBO.getOrderOperation();
		String rollbackByUser = commonBO.getAssignee();
		Long eventId = 0L;
		String errorCode = null;
		String errorMsg = null;
		List<OrderEvent> orderEventList = orderEventRepository.findEventIDMaxByOrderIdAndEventName(orderId, eventName);
		if (orderEventList.size() > 0) {
			for (OrderEvent orderEvent : orderEventList) {
				eventId = orderEvent.getEventId();
			}
		}
		logger.info("orderId Id :" + orderId);
		logger.info("Event Id :" + eventId);
		logger.info("Event Name :" + eventName);

		if (CommonUtils.isNotNullEmpty(orderId)) {
			StoredProcedureQuery sProcQury = entityManager.createStoredProcedureQuery(ROLLBACK_ORDER_AUDIT);
			sProcQury.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(5, String.class, ParameterMode.IN);
			sProcQury.registerStoredProcedureParameter(6, String.class, ParameterMode.OUT);
			sProcQury.setParameter(1, orderId);
			sProcQury.setParameter(2, eventId);
			sProcQury.setParameter(3, eventName);
			sProcQury.setParameter(4, rollbackByUser);
			sProcQury.setParameter(5, "C");

			sProcQury.execute();

			errorMsg = (String) sProcQury.getOutputParameterValue(6);
			logger.debug("Error Msg in Rollback Audit : " + errorMsg);
			if (CommonUtils.isValidString(errorMsg) && errorMsg.contains("ORA-")) {
				logger.error("Error Msg in Rollback Audit : " + errorMsg);
				logger.error("Error code in Rollback Audit : " + errorCode);
			}
		}
		logger.info("@End method rollbackAuditOrder ", this);
	}

}
