package com.att.comet.bpm.core.processes.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Service
public class DAPNProcessServiceImpl implements DAPNProcessService{
	private static final Logger logger = LoggerFactory.getLogger(DAPNProcessServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	private AvosDAO avosDAO;
	@Autowired
	private GenericDAO genericDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method preOperation Method :: ");
		commonBO.setBpmProcessId(1029L);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		logger.info("::Exiting  Method preOperation Method :: ");
	}

	@Override
	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method postOperation Method :: ");
		
		logger.info("::Exiting  Method postOperation Method :: ");
	}

	@Override
	public void orderStatusUpdate(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method orderStatusUpdate Method :: ");
		if (commonBO.getApproved().equalsIgnoreCase("Approved")) {
			commonBO.setOrderStatusId(1046L);
			coreProcessDelegateHelper.updateOrderStaus(commonBO);
		} else {
			commonBO.setOrderStatusId(1006L);
			coreProcessDelegateHelper.updateOrderStaus(commonBO);
			
		}
		logger.info("::Exiting  Method orderStatusUpdate Method :: ");
	}

	@Override
	public void orderStatusUpdateProd(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method orderStatusUpdateProd Method :: ");
		commonBO.setDapnStatusId(1004L);
		genericDAO.updateDAPNInventory(commonBO);
		//save order status_history
		commonBO.setOrderStatusId(1009L);
		orderDAO.saveOrderStatusHistory(commonBO);
		//save orders
		orderDAO.updateOrders(commonBO);
	
		logger.info("::Exiting  Method orderStatusUpdateProd Method :: ");
	}

	@Override
	public void billingSla(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method billingSla Method :: ");
		genericDAO.getDapnBillingSla(commonBO);
		logger.info("::Exiting  Method billingSla Method :: ");
	}

}
