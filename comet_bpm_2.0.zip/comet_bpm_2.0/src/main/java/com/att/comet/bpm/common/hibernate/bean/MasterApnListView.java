package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MASTER_APN_LIST_REPORT_VIEW")
public class MasterApnListView implements Serializable {
	private static final long serialVersionUID = 3863487051020199704L;
	private Long orderId;
	private String orderType;
	private String accountClass;
	private String masterAccountName;
	private String accountName;
	private String apnName;
	private String apnStatus;
	private String dateApnInProduction;
	private Long apnPriority;
	private String pdpId;
	private String pdpName;
	private String fanId;
	private String os;
	private String osd;
	private Character geo;
	private String activePassive;
	private String agreementAccountNumber;
	private Long buildSla;

	@Id
	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "ORDER_TYPE")
	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Column(name = "ACCOUNT_CLASS")
	public String getAccountClass() {
		return accountClass;
	}

	public void setAccountClass(String accountClass) {
		this.accountClass = accountClass;
	}

	@Column(name = "MASTER_ACCOUNT_NAME")
	public String getMasterAccountName() {
		return masterAccountName;
	}

	public void setMasterAccountName(String masterAccountName) {
		this.masterAccountName = masterAccountName;
	}

	@Column(name = "ACCOUNT_NAME")
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}

	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	@Column(name = "APN_STATUS")
	public String getApnStatus() {
		return apnStatus;
	}

	public void setApnStatus(String apnStatus) {
		this.apnStatus = apnStatus;
	}

	@Column(name = "DATE_APN_IN_PRODUCTION")
	public String getDateApnInProduction() {
		return dateApnInProduction;
	}

	public void setDateApnInProduction(String dateApnInProduction) {
		this.dateApnInProduction = dateApnInProduction;
	}

	@Column(name = "APN_PRIORITY")
	public Long getApnPriority() {
		return apnPriority;
	}

	public void setApnPriority(Long apnPriority) {
		this.apnPriority = apnPriority;
	}

	@Column(name = "PDP_ID")
	public String getPdpId() {
		return pdpId;
	}

	public void setPdpId(String pdpId) {
		this.pdpId = pdpId;
	}

	@Column(name = "PDP_NAME")
	public String getPdpName() {
		return pdpName;
	}

	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	@Column(name = "FAN_ID")
	public String getFanId() {
		return fanId;
	}

	public void setFanId(String fanId) {
		this.fanId = fanId;
	}

	@Column(name = "OS")
	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	@Column(name = "OSD")
	public String getOsd() {
		return osd;
	}

	public void setOsd(String osd) {
		this.osd = osd;
	}

	@Column(name = "GEO")
	public Character getGeo() {
		return geo;
	}

	public void setGeo(Character geo) {
		this.geo = geo;
	}

	@Column(name = "ACTIVE_PASSIVE")
	public String getActivePassive() {
		return activePassive;
	}

	public void setActivePassive(String activePassive) {
		this.activePassive = activePassive;
	}

	@Column(name = "AGREEMENT_ACCOUNT_NUMBER")
	public String getAgreementAccountNumber() {
		return agreementAccountNumber;
	}

	public void setAgreementAccountNumber(String agreementAccountNumber) {
		this.agreementAccountNumber = agreementAccountNumber;
	}

	@Column(name = "BUILD_SLA")
	public Long getBuildSla() {
		return buildSla;
	}

	public void setBuildSla(Long buildSla) {
		this.buildSla = buildSla;
	}

}
