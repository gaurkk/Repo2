package com.att.comet.bpm.common.dao;

import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface BpmOrderBusinessStepDAO {

	void saveBpmOrderBusinessStepForOrderIdAndOaDetails(CommonBO commonBO) throws CamundaServiceException;
	public void saveBpmOrderBusinessStepIWOACreation(CommonBO commonBO,String iwosTicketNumber, Date iwosCreationDate, String comments);

}
