package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "TASK_DISPLAY_TYPE")
@Data
public class TaskDisplayType implements Serializable {

	private static final long serialVersionUID = 6008719353493721222L;

	@Id
	@Column(name = "TASK_DISPLAY_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long taskDisplayTypeId;

	@Column(name = "TASK_DISPLAY_TYPE_DESC", nullable = true, length = 500)
	private String taskDisplayTypeDesc;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "taskDisplayType")
	private List<TaskInfo> taskInfosList = new ArrayList<>();

}
