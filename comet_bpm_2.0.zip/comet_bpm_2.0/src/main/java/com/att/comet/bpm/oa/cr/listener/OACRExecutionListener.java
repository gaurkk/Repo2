package com.att.comet.bpm.oa.cr.listener;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Session;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.helper.EmailTemplateHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.hibernate.bean.TaskInfo;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.EmailTemplateBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.common.util.EmailUtil;

@Component
public class OACRExecutionListener implements ExecutionListener {
	private static final Logger logger = LoggerFactory.getLogger(OACRExecutionListener.class);
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	EmailTemplateHelper emailTemplateHelper;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void notify(DelegateExecution execution) throws Exception {
		CommonBO commonBO = (CommonBO) execution.getVariable("commonBO");
		String response = (String) execution.getVariable("response"); // Email work need
		String inProgressTaskStatus =null;
		try {
			if (response.equalsIgnoreCase("Approved") && (commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST) 
					|| commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CANCEL_ORDER))) {
				commonBO.setEmailNotificationId(1005L);
				Orders order = new Orders();
				order.setOrderId(commonBO.getOrderId());
				List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
					if (null != taskObj) {
						if (taskObj.getBpmTask().getTaskId().equals(1010L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
							inProgressTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
							logger.info("@@@  OATaskStatus @@@  :: " + inProgressTaskStatus, this);
							commonBO.setTaskId(1010L);
							//commonBO.setOmTaskStatus(omTaskStatus);
							break;
						}else if (taskObj.getBpmTask().getTaskId().equals(1011L) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
							inProgressTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
							logger.info("@@@ inProgressTaskStatus @@@ :: " + inProgressTaskStatus, this);
							//commonBO.setOmTaskStatus(inProgressTaskStatus);
							commonBO.setTaskId(1011L);
							break;
						}
					}else {
						logger.info("@@@ taskObj is null @@@ ");
					}
				}
				if(CommonUtils.isNotNullEmpty(inProgressTaskStatus)) {
					commonServiceHelper.taskCompletedService(commonBO, execution);
					logger.info("OA task for NEW OrderOperation for orderId ::" + commonBO.getOrderId() + " is Terminated",
						this);
				}else {
					logger.info("@@@ there is not inprogress task for Order Id @@@ :: " +commonBO.getOrderId(), this);
				}

				setEmailNotification(commonBO);

			} else if (response.equalsIgnoreCase("Rejected")) { // CR rejected
				commonBO.setEmailNotificationId(1006L);
				setEmailNotification(commonBO);
			}

		} catch (URISyntaxException e) {
			logger.error("@NOT ABLE TO Complete the task Issue on Json request::" + e.getMessage() + "", this);
		} catch (CamundaServiceException e) {
			logger.error("@NOT ABLE TO Complete the task::" + e.getMessage() + "", this);
		}

	}

	private void setEmailNotification(CommonBO commonBO) throws CamundaServiceException, Exception {
		logger.info("@Starting method setEmailNotification ", this);
		EmailTemplateBO emailTemplateBO = new EmailTemplateBO();
		TaskInfo taskInfo = null;
		taskInfo = emailTemplateHelper.getTaskInfo(commonBO.getTaskId(), commonBO.getEmailNotificationId());
		if (null != taskInfo) {
			emailTemplateBO.setToEmail(commonBO.getToEmail());
			emailTemplateBO.setCcEmail(commonBO.getCcEmail());
			emailTemplateBO.setTaskDataId(String.valueOf(commonBO.getBpmTaskId()));
			emailTemplateBO.setSubject(taskInfo.getSubject() + ":" + commonBO.getTaskDescription());

			emailTemplateBO.setHeaderSection(taskInfo.getHeaderSection());// Dear
			emailTemplateBO.setSubHeaderSection(taskInfo.getSubHeaderSection());

			emailTemplateBO.setBodySection1(taskInfo.getBodySection1());
			emailTemplateBO.setBodySection2(taskInfo.getBodySection2());
			emailTemplateBO.setBodySection3(taskInfo.getBodySection3());

			emailTemplateBO.setFooterSection(taskInfo.getFooterSection());

			emailTemplateBO.setApnName(commonBO.getApnName());
			emailTemplateBO.setOrderId(commonBO.getOrderId());
			if (BpmConstant.CHANGE_REQUEST.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Change Request");
			}
			emailTemplateBO.setPdpName(commonBO.getPdpName());
			emailTemplateBO.setBackHaulName(commonBO.getBackHaulIds());
			emailTemplateBO.setAccountId(commonBO.getAccountClassId());
			emailTemplateBO.setAccountName(commonBO.getAccountName());
			emailTemplateBO.setBpmUrl(commonBO.getUrlName());
			emailTemplateBO.setEodOrder(commonBO.getEodOrder());
			emailTemplateBO.setFeeWaiverApproved(commonBO.getFeeWaiverApproved());
			emailTemplateBO.setCompanyBillingAddress(commonBO.getCompanyBillingAddress());
			emailTemplateBO.setCompanyContactNamePhone(commonBO.getCompanyContactNamePhone());
			emailTemplateBO.setFederalTaxID(commonBO.getFederalTaxID());
			emailTemplateBO.setBan(commonBO.getBan());
			emailTemplateBO.setFan(commonBO.getFan());
			emailTemplateBO.setAccountManager(commonBO.getAccountManager());
			emailTemplateBO.setMobilityTechnicalEngineer(commonBO.getMobilityTechnicalEngineer());
			emailTemplateBO.setSourceofIPAddressing(commonBO.getSourceofIPAddressing());
			emailTemplateBO.setTypeofAddressing(commonBO.getTypeofAddressing());
			emailTemplateBO.setBackhaulInstances(commonBO.getBackhaulInstances());
			emailTemplateBO.setMplscir(commonBO.getMplscir());
			emailTemplateBO.setManagedAVPN(commonBO.getManagedAVPN());
			Map<String, Object> model = taskCreationEmailFormat(emailTemplateBO, commonBO);
			// EMAIL SENDER CLASS INVOKING
			Properties props = System.getProperties();
			props.put("mail.smtp.host", "smtp.it.att.com");// will update later from YML
			Session session = Session.getInstance(props, null);
			emailUtil.sendEmail(session, emailTemplateBO, model);
		}

		logger.info("@Ending method setEmailNotification", this);
	}

	private Map<String, Object> taskCreationEmailFormat(EmailTemplateBO emailTemplateBO, CommonBO commonBO) {
		Map<String, Object> model = new HashMap<>();
		model.put("HeaderSection", emailTemplateBO.getHeaderSection());
		model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());
		model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());
		String taskStm = emailTemplateBO.getBodySection1();// task
		taskStm = taskStm.replace(EmailUtil.approverComments, commonBO.getComments() + "\n");
		taskStm = taskStm.replace(EmailUtil.crNote, "CR NOTES:");
		model.put("taskStm", taskStm);
		String orderData = emailTemplateBO.getBodySection2();
		orderData = orderData.replace(EmailUtil.orderIdVar, emailTemplateBO.getOrderId() + "\n");
		orderData = orderData.replace(EmailUtil.orderTypeVar, emailTemplateBO.getOrderType() + "\n");
		orderData = orderData.replace(EmailUtil.apnNameVar, emailTemplateBO.getApnName() + "\n");
		orderData = orderData.replace(EmailUtil.pdpNameVar, emailTemplateBO.getPdpName() + "\n");
		orderData = orderData.replace(EmailUtil.backHaulVar, emailTemplateBO.getBackHaulName() + "\n");
		orderData = orderData.replace(EmailUtil.accountIdVar, emailTemplateBO.getAccountId() + "\n");
		orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName());
		model.put("orderData", orderData);
		String moreOrderDetails = emailTemplateBO.getBodySection3();
		model.put("moreOrderDetails", moreOrderDetails);
		model.put("footer", emailTemplateBO.getFooterSection());

		return model;
	}

}
