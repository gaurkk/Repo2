package com.att.comet.bpm.common.modal;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmailTemplateBO {

	private String toEmail;
	private String ccEmail;
	private String headerSection;
	private String subHeaderSection;
	private String subject;
	private String bodySection1;
	private String bodySection2;
	private String bodySection3;
	private String footerSection;
	private String taskDataId;
	private String firstNet;
	private Long roleId;
	private String ocs;
	private String pmip;
	private String fanAccontNumber;
	private String subAccountName;

	private Long orderId;
	private String apnName;
	private Long accountId;
	private String accountName;
	private String backHaulName;
	private String pdpName;
	private String orderType;

	private String messageBody;
	private String bpmUrl;

	private String eodOrder;
	private String feeWaiverApproved;
	private String companyBillingAddress;
	private String companyContactNamePhone;
	private String federalTaxID;
	private String ban;
	private String fan;
	private String accountManager;
	private String mobilityTechnicalEngineer;
	private String sourceofIPAddressing;
	private String typeofAddressing;
	private String backhaulInstances;
	private String mplscir;
	private String managedAVPN;

	// OA OM RejectionComments
	private String rejectionComments;

	private String apnType;
	private String iPType;
	private String ifStatic;
	private String mrc;
	private String ericssonCode;
	private String userDefinedPDPID;
	private String cometPdpId;
	private String companyName;
	private String ultimateAccountName;
	private String materAccountID;
	private String agreementAccountName;
	private String agreementAccountNumber;
	private String pdpPackageName;
	private String pdpPackageDesc;
	private String pdpDescription;
	private String pdpId;
	private String accountCipn;
	

	// On Hold Request Task
	private Date onHoldRequestedDate;
	private Date onHoldProposedCompletionDate;
	private String onHoldReason;
	private String onHoldNotes;

}
