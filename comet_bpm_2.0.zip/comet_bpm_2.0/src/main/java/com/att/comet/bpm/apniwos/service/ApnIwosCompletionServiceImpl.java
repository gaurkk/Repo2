package com.att.comet.bpm.apniwos.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class ApnIwosCompletionServiceImpl implements ApnIwosCompletionService {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosCompletionServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	GenericDAO genericDAO;
	@Override
	public void preOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperationIWOSCompletion");
		List<String> escalationEmailList = null;
		BpmUrl bpmUrl = bpmDAO.finBpmUrlById(BpmConstant.URL_NAME);
		// saving camunda process instance ID
		commonBO.setProcessId(1005L);
		commonBO.setBpmProcessId(1005L);// Network IWOS Process
		commonBO.setWorkFlowUrl(bpmUrl.getNew_url()+commonBO.getOrderId());
		camundaDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		// find expedite status
		/*
		 * String expediteStatus = bpmDAO.getExpediteStatus(commonBO); if
		 * (expediteStatus.equalsIgnoreCase("true")) { // do something for expedite }
		 * else { commonBO.setApnCreationStatus("post");
		 * bpmDAO.updateBpmOrderExpedite(commonBO); }
		 */
		// getting APN Creation date
		commonBO.setBusinessStepId(3007L);
		Date businessStepExecutionDate = bpmDAO.findBpmOrderBusinessStepById(commonBO) != null
				? bpmDAO.findBpmOrderBusinessStepById(commonBO).getBusinessStepExecutedOn()
				: null;
		// Fetching emails for escalation
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		escalationEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					escalationEmailList.add((String) obj[1]);
				}
			}
			commonBO.setAdminEmailList(escalationEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		List<String> CCSPMEmailList = null;
		commonBO.setOrderContactTypeId(1006L); 
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO); 
		if (!CollectionUtils.isEmpty(attUidList)) { 
			logger.debug("osdEmailList is not empty : ", +attUidList.size()); 
			String ccsPM = attUidList.get(0); 
			commonBO.setAttuid(ccsPM); 
			commonBO.setIwosAssignee(ccsPM);
			CCSPMEmailList = userDAO.getUserEmail(commonBO); 
			commonBO.setEmailList(CCSPMEmailList); 
		} else { 
			logger.debug("attUidList is empty: ", +attUidList.size()); 
			commonBO.setRoleId(1005L); 
			CCSPMEmailList = userDAO.getGroupUserEmail(commonBO); 
			commonBO.setEmailList(CCSPMEmailList); 
		}
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		}
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3012L);
		businessStepIdList.add(3049L);
		businessStepIdList.add(3050L);
		businessStepIdList.add(3112L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		
		// insert and update bpm_order_work_step table
		if ("NEW_ORDER".equals(commonBO.getOrderOperation())) {
			commonBO.setWorkStepId(1008L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1008L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {
			commonBO.setWorkStepId(1008L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1008L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			commonBO.setUpdatedOn(new Date());
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNIWO_COMPLETION(commonBO);

	}

	@Override
	public void postOperationIWOSCom_Sus(CommonBO commonBO, String CCSPMComments, String IWOSTicketCompletionDateTime,
			String IWOSTicketResponse) throws CamundaServiceException, ParseException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationIWOSCom_Sus");
		if (IWOSTicketResponse.equalsIgnoreCase("COMPLETED")) {
			commonBO.setBusinessStepStatus("Completed");
		} else {
			commonBO.setBusinessStepStatus("Suspended");
		}
		// fetching order ccspm from order_contact_info table
		commonBO.setOrderContactTypeId(1006L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String CCSPM = attUidList.get(0);
			commonBO.setAttuid(CCSPM);
			commonBO.setAssignee(CCSPM);
		}
		commonBO.setBusinessStepId(3012L);
		commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(IWOSTicketCompletionDateTime));
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepValue("Completed");
		commonBO.setComments(CCSPMComments);
		// commonBO.setUpdatedOn(IWOSTicketCompletionDateTime);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		List<Long> idList = new ArrayList<Long>();
		idList.add(1008L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		logger.info("[::Ending Method postOperationIWOSCom_Sus");
	}

	@Override
	public void postOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationIWOSCompletion");

		commonBO.setBusinessStepValue("APN_BUILD_IWOS_READY_FOR_TTU");
		commonBO.setComments(commonBO.getComments());

		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3104L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		commonBO.setBusinessStepId(3112L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		// commonBO.setUpdatedOn(IWOSTicketCompletionDateTime);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		logger.info("[::Ending Method postOperationIWOSCompletion");
	}

}
