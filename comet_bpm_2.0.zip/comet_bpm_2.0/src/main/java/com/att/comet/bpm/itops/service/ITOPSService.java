package com.att.comet.bpm.itops.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ITOPSService {
	void preOperationITOPSTask(CommonBO commonBO) throws CamundaServiceException;
	void postOperationITOPSTask(CommonBO commonBO, String ITOPSComments) throws CamundaServiceException;
}
