package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderRecent. Mapped to ORDER_RECENT table in the
 * database.
 */
@Entity
@Table(name = "ORDER_RECENT")
public class OrderRecent implements Serializable {

	private static final long serialVersionUID = 6047184564201404326L;

	private Long recentId;
	private Orders order;
	private Users user;
	private Role role;
	private Date createdOn;

	/**
	 * Getter method for recentId. RECENT_ID mapped to RECENT_ID in the database
	 * table. The sequence is generated using the SEQ_ORDER_RECENT_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "RECENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_RECENT_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ORDER_RECENT_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_RECENT_ID")
	public Long getRecentId() {
		return recentId;
	}

	/**
	 * @param recentId
	 *            to recentId set.
	 */
	public void setRecentId(Long recentId) {
		this.recentId = recentId;
	}

	/**
	 * Getter method for order.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrder() {
		return order;
	}

	/**
	 * @param order
	 *            to order set.
	 */
	public void setOrder(Orders order) {
		this.order = order;
	}

	/**
	 * Getter method for user.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ATTUID", nullable = false)
	public Users getUser() {
		return user;
	}

	/**
	 * @param user
	 *            to user set.
	 */
	public void setUser(Users user) {
		this.user = user;
	}

	/**
	 * Getter method for role.
	 * 
	 * @return Role
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false)
	public Role getRole() {
		return role;
	}

	/**
	 * @param role
	 *            to role set.
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
}