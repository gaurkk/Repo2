package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, String> {

	@Query(value = "select us.email from Users us where us.active =:active and us.attuid=:attuid")
	List<String> findUserEmail(String attuid, Character active);

	@Query(value = "select att.order_contact_type_id,  usr.email from users usr,(select oci.order_contact_type_id,oci.attuid from order_contact_info oci ,"
			+ "order_contact oc , users usr where (oc.order_id=:orderId and  oci.attuid = usr.attuid "
			+ "and oc.order_contact_id= oci.order_contact_id and usr.active = 'Y' "
			+ "and oci.order_contact_type_id in (:orderContactTypeIdList))) att where att.attuid= usr.attuid and usr.active = 'Y'", nativeQuery = true)
	List<Object[]> findContactTypeIdAndEmail(Long orderId, List<Long> orderContactTypeIdList);

	@Query(value = "select us.email from Users us join us.userRoles usro where usro.role.roleId=:roleId and us.active = 'Y'")
	List<String> findEmailByRoleId(Long roleId);

	@Query("Select usr.email from Users usr where usr.attuid in (:attUidList) and usr.active='Y'")
	List<String> getAssignedUserEmail(List<String> attUidList);

	/*
	 * @Query("select us.email from Users us join us.userRoles usro  where usro.role.roleId=:roleId and us.attuid= usro.attuid and us.active = 'Y' and usro.approved = 'Y'"
	 * ) List<String> getCometAdminEmail(Long roleId);
	 */

	/*
	 * @Query("select us.email from Users us join us.userRoles  usro where usro.role.roleId=:roleId and us.attuid= usro.attuid and us.active = 'Y' and usro.approved = 'Y'"
	 * ) List<String> getOmGroupEmail(Long roleId);
	 */

	@Query("Select usr.email from Users usr where usr.attuid= :attUid and usr.active='Y'")
	List<String> getUserEmail(String attUid);
	
	@Query(value = "select usr.email from users usr,(select oci.order_contact_type_id,oci.attuid from order_contact_info oci ,"
			+ "order_contact oc , users usr where (oc.order_id=:orderId and  oci.attuid = usr.attuid "
			+ "and oc.order_contact_id= oci.order_contact_id and usr.active = 'Y' "
			+ "and oci.order_contact_type_id in (:orderContactTypeIdList))) att where att.attuid= usr.attuid and usr.active = 'Y'", nativeQuery = true)
	List<String> findEmailAllUsers(Long orderId, List<Long> orderContactTypeIdList);

}
