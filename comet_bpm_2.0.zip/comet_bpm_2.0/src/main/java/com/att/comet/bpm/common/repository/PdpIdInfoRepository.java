package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.PdpIdInfo;

@Repository
public interface PdpIdInfoRepository extends JpaRepository<PdpIdInfo, Long> {

	@Query(value = "select autoPdpName from PdpIdInfo where apn.orderId=:orderId")
	String findAutoPdpNameByOrderId(Long orderId);
	
	@Query(value = "select userPdpName from PdpIdInfo where apn.orderId=:orderId")
	String findUserPdpNameByOrderId(Long orderId);
}
