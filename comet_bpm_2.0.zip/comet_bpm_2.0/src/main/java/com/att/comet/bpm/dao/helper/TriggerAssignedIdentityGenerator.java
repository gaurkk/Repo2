package com.att.comet.bpm.dao.helper;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.AbstractPostInsertGenerator;
import org.hibernate.id.IdentifierGeneratorHelper;
import org.hibernate.id.PostInsertIdentityPersister;
import org.hibernate.id.SequenceIdentityGenerator.NoCommentsInsert;
import org.hibernate.id.insert.AbstractReturningDelegate;
import org.hibernate.id.insert.IdentifierGeneratingInsert;
import org.hibernate.id.insert.InsertGeneratedIdentifierDelegate;

public class TriggerAssignedIdentityGenerator extends
AbstractPostInsertGenerator {
	
	/*
	 * (non-Javadoc)
	 * 
	 * @seeorg.hibernate.id.PostInsertIdentifierGenerator#
	 * getInsertGeneratedIdentifierDelegate
	 * (org.hibernate.id.PostInsertIdentityPersister,
	 * org.hibernate.dialect.Dialect, boolean)
	 */
	public InsertGeneratedIdentifierDelegate getInsertGeneratedIdentifierDelegate(
			PostInsertIdentityPersister persister, Dialect dialect,
			boolean isGetGeneratedKeysEnabled) throws HibernateException {
		return new Delegate(persister, dialect);
	}

	/**
	 * Hibernate class Delegator
	 */
	public static class Delegate extends AbstractReturningDelegate {
		private final Dialect dialect;

		private final String[] keyColumns;

		/**
		 * Delegate constructor
		 * 
		 * @param persister
		 * @param dialect
		 */
		public Delegate(PostInsertIdentityPersister persister, Dialect dialect) {
			super(persister);
			this.dialect = dialect;
			this.keyColumns = getPersister().getRootTableKeyColumnNames();
			if (keyColumns.length > 1) {
				throw new HibernateException(
						"trigger assigned identity generator cannot be used with multi-column keys");
			}
		}

		/**
		 * @return IdentifierGeneratingInsert
		 */
		public IdentifierGeneratingInsert prepareIdentifierGeneratingInsert() {
			@SuppressWarnings("deprecation")
			NoCommentsInsert insert = new NoCommentsInsert(dialect);
			return insert;
		}

		/**
		 * @return PreparedStatement
		 */
		protected PreparedStatement prepare(String insertSQL,
				SessionImplementor session) throws SQLException {
			return session.connection().prepareStatement(insertSQL, keyColumns);
		}

		/**
		 * @return Serializable
		 */
		protected Serializable executeAndExtract(PreparedStatement insert)
				throws SQLException {
			insert.executeUpdate();
			 ResultSet generatedKeys = insert.getGeneratedKeys();
	         try {
	            return IdentifierGeneratorHelper.getGeneratedIdentity(generatedKeys, keyColumns[0], getPersister()
	               .getIdentifierType(), dialect);
	         } finally {
	            generatedKeys.close();
	         }
		}

		@Override
		protected PreparedStatement prepare(String insertSQL, SharedSessionContractImplementor session)
				throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		protected Serializable executeAndExtract(PreparedStatement insert, SharedSessionContractImplementor session)
				throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}
	}

}
