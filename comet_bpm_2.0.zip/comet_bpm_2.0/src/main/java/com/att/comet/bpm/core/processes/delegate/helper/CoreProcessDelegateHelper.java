package com.att.comet.bpm.core.processes.delegate.helper;

import java.math.BigDecimal;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class CoreProcessDelegateHelper {
	private static final Logger logger = LoggerFactory.getLogger(CoreProcessDelegateHelper.class);
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	public String checkApmEligibility(DelegateExecution execution , Long orderId) {
		logger.info("Start checkApmEligibility method ::", this);
		String  isAmpEligible = genericDAO.isAmpEligiblity(orderId);
		if(CommonUtils.isNotNullEmpty(isAmpEligible)) {
			execution.setVariable(BpmConstant.AMP_ELIGIBILTIY, isAmpEligible);
		}else {
			logger.error("isAmpEligible is null ",this);
		}
		logger.info("Existing checkApmEligibility method ::", this);
		return isAmpEligible;
	}
	public void updateAmpSkip(CommonBO commonBO) {
		logger.info("Starting updateAmpSkip method ::", this);
		orderDAO.updateOrderFlagDetails(commonBO);
		logger.info("Existing updateAmpSkip method ::", this);
	}
	public Long checkAmpReqStatus(DelegateExecution execution, CommonBO commonBO) {
		Long ampReqStatus = genericDAO.getAmpReqStatus(commonBO);
		if(ampReqStatus!=null) {
			return ampReqStatus;
		}else {
			return null;
		}
		
	}
	
	public void updateOrderStaus(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Starting updateOrderStaus method ::", this);
		auditDAO.saveOrderStatusIdByOrderId(commonBO);
		logger.info("Exiting updateOrderStaus method ::", this);
	}
	public void updateAuditOrderStaus(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Starting updateOrderStaus method ::", this);
		auditDAO.updateAuditOrders(commonBO);
		logger.info("Exiting updateOrderStaus method ::", this);
	}
	
	public String checkSharedMPLS(Long orderId) {
		logger.info("Start checkSharedMPLS method ::", this);
		String  sharedMPLSResponse = genericDAO.checkSharedMPLS(orderId);
		logger.info("Exiting checkSharedMPLS method ::", this);
		return sharedMPLSResponse;
	}
}
