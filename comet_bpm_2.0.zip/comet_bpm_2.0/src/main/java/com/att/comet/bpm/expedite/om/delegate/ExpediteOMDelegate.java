package com.att.comet.bpm.expedite.om.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.expedite.om.service.ExpediteOMService;
@Component
public class ExpediteOMDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(ExpediteOMDelegate.class);
	@Autowired
	ExpediteOMService expediteOMService;
	@Autowired
	CommonService commonService;
	public static final String URL_NAME = "SEARCH_ORDER_URL";
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {

				case BpmConstant.PRE_EXPEDITE_OM_OPERATION:
					expediteOMPreOperation(execution);
					break;
				case BpmConstant.POST_EXPEDITE_OM_OPERATION:
					expediteOMPostOperation(execution);
					break;
				}
			}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.EXPEDITE_OM_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		
	}
	private void expediteOMPreOperation(DelegateExecution execution) {
		logger.info("Starting expeditePreOperation method ");
		CommonBO commonBO = null;
		String expediteOAProcessInstanceId = null;
		expediteOAProcessInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					// OrderUserTaskFaults
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.EXPEDITE_OM_ERR_PRE_001);// DECOM_NI_ORDER_UPDATE_ERR_PRE_001
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1003L);// CCS PM Role Id
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1034L);// Mapped from BPM_task table (NI : Network Decommission Task)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is not null :::: ");
					}
					BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check
																						// PdpIdInfoRepository
					execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
					execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
					execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);

					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setRoleId(1003L);// Setting OSD roleID
					
					//Expedite_Order_Manager_Task, CCSPM_PROPOSED_EXPEDITE_BUILD_DATE_TASK, CCSPM_Final_Expedite_Build_Date_Task
					commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
					commonBO.setTaskStatusName("Expedite_Order_Manager_Task");
					commonBO.setCategoryId(1002L);// category ID (user task)
					commonBO.setUpdatedOn(new Date());
					commonBO.setTaskId(1034L);// Mapped from BPM_task table (OA : Expedite Request Approval Task)
					commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
					expediteOMService.preOperation(commonBO);
					execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
					execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
					execution.setVariable("apnIwosCreationTaskStatus", commonBO.getApnIwosTaskStatus());
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed in Expedite Order Pre Opration"));
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}

		logger.info("Exiting expeditePreOperation method ");
		
	}
	private void expediteOMPostOperation(DelegateExecution execution) {
		logger.info("Starting expediteOAPostOperation method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		String response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOmComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOmComments);
		try {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.EXPEDITE_OM_ERR_POST_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1003L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1034L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			expediteOMService.postOperation(commonBO);
			commonBO.setTaskStatusId(1002L);
			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			
			commonService.updateOrderUserBpmTasksRepository(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable(BpmConstant.RESPONSE, commonBO.getApproved());
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure setExpediteFlagAfter"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Exiting expeditePreOperation method ");
		
	}

}
