package com.att.comet.bpm.decom.apniwos.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.decom.apniwos.helper.APNIWOSDecomHelper;

@Component
public class APNIWOSDecomServiceImpl implements APNIWOSDecomService {

	@Autowired
	private APNIWOSDecomHelper apniwosDecomHelper;

	@Autowired
	private CommonService commonService;

	@Override
	public void preOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apniwosDecomHelper.preOperationAPNIWOSDecom(commonBO, execution);
	}

	@Override
	public void postOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apniwosDecomHelper.postOperationAPNIWOSDecom(commonBO, execution);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1005L);// CCS PM Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1043L);// Mapped from BPM_task table (NI : Network Decommission Task)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
