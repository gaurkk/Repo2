package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for MasterAccount. Mapped to MASTER_ACCOUNT table in the
 * database.
 */
@Entity
@Table(name = "MASTER_ACCOUNT")
public class MasterAccount implements java.io.Serializable {

	private static final long serialVersionUID = -1452873680336747234L;

	private String ubcid;
	private AccountClass accountClass;
	private String masterAccountName;
	private Set<SubAccount> subAccounts = new HashSet<SubAccount>(0);

	/**
	 * Getter method for ubcid. UBCID mapped to UBCID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "UBCID", unique = true, nullable = false, length=50)
	public String getUbcid() {
		return this.ubcid;
	}

	/**
	 * @param ubcid
	 *            to ubcid set.
	 */
	public void setUbcid(String ubcid) {
		this.ubcid = ubcid;
	}

	/**
	 * Getter method for accountClass.
	 * 
	 * @return AccountClass
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_CLASS_ID", nullable = false)
	public AccountClass getAccountClass() {
		return this.accountClass;
	}

	/**
	 * @param accountClass
	 *            to accountClass set.
	 */
	public void setAccountClass(AccountClass accountClass) {
		this.accountClass = accountClass;
	}

	/**
	 * Getter method for masterAccountName. MASTER_ACCOUNT_NAME mapped to
	 * MASTER_ACCOUNT_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MASTER_ACCOUNT_NAME", nullable = false, length = 100)
	public String getMasterAccountName() {
		return this.masterAccountName;
	}

	/**
	 * @param masterAccountName
	 *            to masterAccountName set.
	 */
	public void setMasterAccountName(String masterAccountName) {
		this.masterAccountName = masterAccountName;
	}

	/**
	 * Getter method for subAccounts.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "masterAccount")
	public Set<SubAccount> getSubAccounts() {
		return this.subAccounts;
	}

	/**
	 * @param subAccounts
	 *            to subAccounts set.
	 */
	public void setSubAccounts(Set<SubAccount> subAccounts) {
		this.subAccounts = subAccounts;
	}
}