package com.att.comet.bpm.dapn.oadapnbuildcancellation.delegate;

import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.dapn.oadapnbuildcancellation.service.OADAPNBuildCancellationService;

@Component
public class OADAPNBuildCancellationDelegate implements JavaDelegate {

	private static final Logger logger = LoggerFactory.getLogger(OADAPNBuildCancellationDelegate.class);

	@Autowired
	OADAPNBuildCancellationService oadapnBuildCancellationService;

	@Autowired
	CommonService commonService;

	public static final String URL_NAME = "SEARCH_ORDER_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (operationType != null) {
				switch (operationType) {
				case BpmConstant.PRE_OPERATION_OA_DAPN_BUILD_CANCELLATION:
					preOperationOADAPNBuildCancellation(execution);
					break;
				case BpmConstant.POST_OPERATION_OA_DAPN_BUILD_CANCELLATION:
					postOperationOADAPNBuildCancellation(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(OA_DAPN_BUILD_CANCELLATION_BPM_ERROR_CODE should be same for delegate
			 * and BPMN mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.OA_DAPN_BUILD_CANCELLATION_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void postOperationOADAPNBuildCancellation(DelegateExecution execution)
			throws CamundaServiceException, RecordNotFoundException {
		logger.info("Start postOperationOADAPNBuildCancellation method ::", this);
		Long orderId = 0L;
		CommonBO commonBO = null;
		String comments = null;
		String orderOperation = null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		if (orderId != null && orderOperation != null) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_DAPN_BUILD_CANCELLATION_ERR_POST_001);// OA_DAPN_BUILD_CANCELLATION_ERR_POST_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1002L);// Order Approver Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1052L);// Mapped from BPM_task table (OA : D-APN Build Cancellation Review)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			commonBO = variables.get("commonBO") != null ? (CommonBO) variables.get("commonBO") : null;
			if (null != commonBO) {
				comments = variables.get(BpmConstant.COMMENTS) != null ? (String) variables.get(BpmConstant.COMMENTS)
						: null;
				String response = (String) execution.getVariable(BpmConstant.RESPONSE);
				commonBO.setApproved(response);
				commonBO.setComments(comments);
				oadapnBuildCancellationService.postOperationOADAPNBuildCancellation(commonBO, execution);
				execution.setVariable(BpmConstant.RESPONSE, commonBO.getApproved());
				execution.setVariable("commonBO", commonBO);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}

		logger.info("End postOperationOADAPNBuildCancellation method ::", this);
	}

	private void preOperationOADAPNBuildCancellation(DelegateExecution execution)
			throws CamundaServiceException, RecordNotFoundException {

		logger.info("Start preOperationOADAPNBuildCancellation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		if (orderId != null && CommonUtils.isNotNullEmpty(orderOperation)) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_DAPN_BUILD_CANCELLATION_ERR_PRE_001);// OA_DAPN_BUILD_CANCELLATION_ERR_PRE_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1002L);// Order Approver Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1052L);// Mapped from BPM_task table (OA : D-APN Build Cancellation Review)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			commonBO = variables.get("commonBO") != null ? (CommonBO) variables.get("commonBO") : null;
			if (null == commonBO) {
				commonBO = commonService.getDapnCommonBO(orderId);
			}

			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url() + commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
				execution.setVariable(BpmConstant.PROCESS_TYPE, commonBO.getOrderTypeName());
				execution.setVariable("orderTypeId", commonBO.getOrderTypeId());

				execution.setVariable("bpmStatusId", commonBO.getTaskStatusName());
				execution.setVariable("userDecision", commonBO.getTaskUserDecision());
				execution.setVariable("orderOperation", orderOperation);
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setActivityInstanceId(execution.getActivityInstanceId());
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setRoleId(1002L);// Order Approver Role Id
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setTaskStatusId(1001L);// User Task Status CREATED Id
				commonBO.setTaskId(1052L);// Mapped from BPM_task table (OA : D-APN Build Cancellation Review)
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				oadapnBuildCancellationService.preOperationOADAPNBuildCancellation(commonBO, execution);
				execution.setVariable("commonBO", commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}
		logger.info("End preOperationOADAPNBuildCancellation method ::", this);

	}

}
