package com.att.comet.bpm.itops.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class ITOPSServiceImpl implements ITOPSService {
	private static final Logger logger = LoggerFactory.getLogger(ITOPSServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	CommonService commonService;
	@Autowired
	GenericDAO genericDAO;

	@Override
	public void preOperationITOPSTask(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperationITOPSTask");
		List<String> itOPSEmailList = null;

		BpmUrl bpmUrl = bpmDAO.finBpmUrlById(BpmConstant.URL_NAME);
		/* saving camunda process instance ID */
		commonBO.setProcessId(1004L);
		commonBO.setBpmProcessId(1004L);//APN ITPOS
		commonBO.setWorkFlowUrl(bpmUrl.getNew_url()+commonBO.getOrderId());
		camundaDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		/* fetch user decision from bpm_order_work_step */
		if (!commonBO.getOrderOperation().equalsIgnoreCase("NEW_ORDER")) {
			
			/* update bpm_order_process */
			commonBO.setProcessId(1004L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderProcess(commonBO);
			/* update into bpm_order_work_step for CR and CO */
			commonBO.setWorkStepId(1020L);
			commonBO.setBpmStatusId(1001L);
			commonBO.setDisplayFlag('N');
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		} else {
			/* insert into bpm_oder_process */
			commonBO.setBpmStatusId(1001L);
			commonBO.setProcessId(1004L);
			bpmDAO.saveBpmOrderProcess(commonBO);
			/* insert into bpm_order_work_step for new order */
			List<Long> idList = new ArrayList<Long>();
			idList.add(1004L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		}
		/* delete bpm_order_business_step table */
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3004L);
		businessStepIdList.add(3007L);
		businessStepIdList.add(3142L);
		businessStepIdList.add(3141L);
		businessStepIdList.add(3005L);
		
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* fetching dynamic user from order_contact_info table */
		commonBO.setOrderContactTypeId(1024L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String itOPSAttuid = attUidList.get(0);
			commonBO.setAttuid(itOPSAttuid);
			commonBO.setItOpsAssignee(itOPSAttuid);
			itOPSEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(itOPSEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1008L);
			itOPSEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setEmailList(itOPSEmailList);
		}
		//setting the email data
		List<Object[]> detailsItOpsDataList = orderDAO.getItOpsTaskData(commonBO);

		for (Object[] detailsBillingData : detailsItOpsDataList) {
			//commonBO.setOrderId(detailsBillingData[0]);
			commonBO.setOrderTypeName(detailsBillingData[1] != null ? detailsBillingData[1].toString() : "N/A");
			commonBO.setApnName(detailsBillingData[2] != null ? detailsBillingData[2].toString() : "N/A");
			commonBO.setPdpName(detailsBillingData[3] != null ? detailsBillingData[3].toString() : "N/A");
			commonBO.setBackHaulIds(detailsBillingData[4] != null ? detailsBillingData[4].toString() : "N/A");
			commonBO.setAccountID(detailsBillingData[5] != null ? detailsBillingData[5].toString() : "N/A");
			commonBO.setAccountName(detailsBillingData[6] != null ? detailsBillingData[6].toString() : "N/A");
			commonBO.setApnType(detailsBillingData[7] != null ? detailsBillingData[7].toString() : "N/A");
			commonBO.setIPType(detailsBillingData[8] != null ? detailsBillingData[8].toString() : "N/A");
			commonBO.setMrc(detailsBillingData[9] != null ? detailsBillingData[9].toString() :"N/A");
			commonBO.setEricssonCode(detailsBillingData[10] !=null ? detailsBillingData[10].toString() : "N/A");
			commonBO.setPdpID(detailsBillingData[11] !=null ? detailsBillingData[11].toString() : "N/A");
			commonBO.setCompanyName(detailsBillingData[12] !=null ? detailsBillingData[12].toString() : "N/A");
			commonBO.setUltimateAccountName(detailsBillingData[13] !=null ? detailsBillingData[13].toString() : "N/A");
			commonBO.setMasterAccountID(detailsBillingData[14] !=null ? detailsBillingData[14].toString() : "N/A");
			commonBO.setSubAccountName(detailsBillingData[15] !=null ? detailsBillingData[15].toString() : "N/A");
			commonBO.setAgreementAccountName(detailsBillingData[16] !=null ? detailsBillingData[16].toString() : "N/A");
			commonBO.setAgreementAccountNumber(detailsBillingData[17] !=null ? detailsBillingData[17].toString() : "N/A");
			commonBO.setFan(detailsBillingData[18] !=null ? detailsBillingData[18].toString() : "N/A");
			commonBO.setPdpPackageName(detailsBillingData[19] !=null ? detailsBillingData[19].toString() : "N/A");
			commonBO.setPdpPackageDesc(detailsBillingData[20] !=null ? detailsBillingData[20].toString() : "N/A");
			commonBO.setPdpDescription(detailsBillingData[21] !=null ? detailsBillingData[21].toString() : "N/A");
			commonBO.setPmip(detailsBillingData[22] !=null ? detailsBillingData[22].toString() : "N/A");
			commonBO.setOcs(detailsBillingData[23] !=null ? detailsBillingData[23].toString() : "N/A");
		}
		

		/*
		 * OS,OM,CCSPM Email select usr.email from order_contact_info oci ,order_contact
		 * oc , users usr where (oc.order_id=115788 and oci.attuid = usr.attuid and
		 * oc.order_contact_id= oci.order_contact_id and oci.order_contact_type_id in
		 * (1003,1005,1006) and usr.active = 'Y')
		 */
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		List<String> osOMCCSPMEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					osOMCCSPMEmailList.add((String) obj[1]);
				}
			}
			commonBO.setGroupEmailList(osOMCCSPMEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		if(CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {//if no Assignee , email will sent to grp 
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));//All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));
					
		}else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All grp
			
		}
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForAPNITOPS(commonBO);
			
		
		
		/*
		 * 
		 * select eod_with_fan , eod_enabled from order_account where order_id=115788
		 * select apn_name, ipbr, ocs from apn where order_id = 115788 if ipbr =Y then
		 * YES else NO if OCS =Y then YES else NO
		 */

		/* save bpm_order_business_step table */
		commonBO.setBusinessStepId(3004L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Notified to CCSPM");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		/* save bpm_order_business_step_hostory table */
		commonBO.setBusinessStepId(3004L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Notified to CCSPM");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);

		logger.info("Ending Method preOperationITOPSTask");
	}

	@Override
	public void postOperationITOPSTask(CommonBO commonBO, String ITOPSComments) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationITOPSTask");
		/* fetching dynamic user from order_contact_info table */
		commonBO.setComments(ITOPSComments);
		commonBO.setOrderContactTypeId(1024L);
		commonBO.setProcessId(1004L);
		commonBO.setBpmProcessId(1004L);//APN ITPOS
		List<String> attUidList;
		try {
			attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
			if (!CollectionUtils.isEmpty(attUidList)) {
				logger.debug("osdEmailList is not empty : ", +attUidList.size());
				String actorName = attUidList.get(0);
				commonBO.setAttuid(actorName);
			} else {
				logger.error("attUidList is empty: ", +attUidList.size());
			}
		} catch (CamundaServiceException e) {
			logger.error("inviking attUidList exception : " + e.getMessage(), this);
		}

		/* insert in to bpm_order_business_step */
		commonBO.setBusinessStepId(3005L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Completed");
		commonBO.setComments(ITOPSComments);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		/* save bpm_order_business_step_hostory table */
		commonBO.setBusinessStepId(3005L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("ITOPS_COMPLETED");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);
		/* update bpm_order_work_step */
		commonBO.setWorkStepId(1004L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1004L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setDisplayFlag('Y');
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		
		commonBO.setBusinessStepStatus("APN_ITOPS_READY_FOR_TTU");
		commonBO.setComments(commonBO.getComments());
	
		/* update order_contact_info */
		commonBO.setOrderContactId(1023L);
		orderDAO.updateOrderContactInfo(commonBO);

		/* update bpm_order_process */
		commonBO.setProcessId(1004L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);
		// delete process intance id
		camundaDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		/* save bpm_order_business_step_hostory table */
		commonBO.setBusinessStepId(3110L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		logger.info("Ending Method postOperationITOPSTask");

	}
}
