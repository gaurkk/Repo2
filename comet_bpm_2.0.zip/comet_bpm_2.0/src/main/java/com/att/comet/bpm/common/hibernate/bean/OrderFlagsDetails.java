package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * APN persistent class. Mapped to APN table in the database.
 */
@Entity
@Table(name = "ORDER_FLAGS_DETAILS")
public class OrderFlagsDetails implements Serializable{

	private static final long serialVersionUID = -2033318731597851362L;
	@EmbeddedId
	@Id
	private OrderFlagsDetailsPK compositeKey;
	
	@Column(name = "FLAG_VALUE", nullable = false)
	private String flagValue; 
	
	@Column(name = "UPDATED_ON", nullable = false)
	private Date updatedOn;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	private Orders orders;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FLAG_ID", nullable = false, insertable = false, updatable = false)
	private OrderFlags orderFlags;
	
	public OrderFlagsDetailsPK getCompositeKey() {
		return compositeKey;
	}
	public void setCompositeKey(OrderFlagsDetailsPK compositeKey) {
		this.compositeKey = compositeKey;
	}
	
	public String getFlagValue() {
		return flagValue;
	}
	public void setFlagValue(String flagValue) {
		this.flagValue = flagValue;
	}
	
	
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	public Orders getOrders() {
		return this.orders;
	}
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	/**
	 * Getter method for flag id.
	 * 
	 * @return FLAG_ID
	 */
	public OrderFlags getOrderFlags() {
		return orderFlags;
	}
	public void setOrderFlags(OrderFlags orderFlags) {
		this.orderFlags = orderFlags;
	}
	
	
}
