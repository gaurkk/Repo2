package com.att.comet.bpm.niorderupdate.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class NIOrderUpdateHelper {

	private static final Logger logger = LoggerFactory.getLogger(NIOrderUpdateHelper.class);

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private AvosDAO avosDAO;
	
	@Autowired
	GenericDAO genericDAO;

	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start preOperation method ::", this);
		String assigneeNI = null;
		Boolean User_or_group_exist = false;
		/* Delete BpmOrderProcess */
		commonBO.setProcessId(1017L);//NI ORDER UPDATE
		commonBO.setBpmProcessId(1017L);//NI ORDER UPDATE
		bpmDAO.deleteBpmOrderProcess(commonBO);

		/* Save AVOSProcessInstances */
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

		/* Delete BpmOrderWorkStep */
		ArrayList<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1048L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);

		/* Delete BpmOrderBusinessStep */
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3148L);
		businessStepIdList.add(3149L);
		businessStepIdList.add(3027L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		//Decide User or Group for HT for email
		commonBO.setOrderContactTypeId(1007L);
		assigneeNI = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeNI)) {
			User_or_group_exist = true;
			commonBO.setNiTaskAssignee(assigneeNI);
		}
		commonBO.setBpmStatusId(1001L);
		commonBO.setWorkStepId(1048L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1048L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setDisplayFlag('N');
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		/* Get NI Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assigneeNI);
			commonBO.setToEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setToEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
		}
		
		/* Get Admin Email details */
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		// email to be sent to NI and Admin as CC in Reminder
		commonBO.setCcEmail((commonBO.getToEmail()+ "," + commonBO.getAdminEmail()));
		
		/* Set Reminder1 & Reminder2 SLA Dates for NI */
		genericDAO.setReminder1And2FromSlaWorkingDayForNIOrdeUpdate(commonBO);
	
		//commonBO.setBusinessStepId(3149L);
		//BpmOrderBusinessStep bpmOrderBusinessStep = bpmDAO.findBpmOrderBusinessStepById(commonBO);

		logger.info("End preOperation method ::", this);

	}

	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start postOperation method ::", this);
		/* Save Get BpmOrderWorkStep */
		// TODO
		commonBO.setWorkStepId(1005L);
		//BpmOrderWorkStep bpmOrderWorkStepMWIWOSCr = bpmDAO.getBpmOrderWorkStep(commonBO);
		commonBO.setOrderContactTypeId(1007L);
		String assigneeNI = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeNI)) {
			//User_or_group_exist = true;
			commonBO.setUpdatedBy(assigneeNI);
		}

		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3027L);
		commonBO.setBusinessStepValue(commonBO.getIsTTURequired());
		commonBO.setComments(commonBO.getComments());
		commonBO.setUpdatedOn(new Date());
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Save OrderComments */
		commonBO.setRoleId(1004L);
		commonBO.setUserAction("Order Update (NI) - Completed");
		if (commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			Long count = orderDAO.countOrderEvent(commonBO);
			commonBO.setOrderProcess("CR-00" + count);
			commonBO.setAttuid(commonBO.getUpdatedBy());
			orderDAO.saveOrderComments(commonBO);
		} else if (commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
			commonBO.setOrderProcess("Change Order");
			commonBO.setAttuid(commonBO.getUpdatedBy());
			orderDAO.saveOrderComments(commonBO);
		} else {
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			commonBO.setAttuid(commonBO.getUpdatedBy());
			orderDAO.saveOrderComments(commonBO);
		}

		/* Delete AVOSProcessInstances */
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		/* Update BpmOrderProcess */
		commonBO.setProcessId(1017L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setBpmStatusId(1002L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1048L);
		commonBO.setWorkStepIdList(idList);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		logger.info("End postOperation method ::", this);

	}

}
