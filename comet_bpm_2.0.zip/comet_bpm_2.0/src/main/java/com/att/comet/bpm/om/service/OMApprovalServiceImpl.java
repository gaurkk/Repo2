package com.att.comet.bpm.om.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.om.helper.OMApprovalHelper;

@Service
public class OMApprovalServiceImpl implements OMApprovalService {

	@Autowired
	OMApprovalHelper omApprovalHelper;
	
	@Autowired
	CommonService commonService;

	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		omApprovalHelper.omPreOprCRUD(commonBO, processInstanceId);
		omApprovalHelper.omAppovedOprCRUD(commonBO);
	}

	@Override
	public void approvedByOM(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		omApprovalHelper.omPostOprCRUD(commonBO, execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Complete Status
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

	@Override
	public void rejectedByOM(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		omApprovalHelper.omRejectedOprCRUD(commonBO, execution);
		omApprovalHelper.omPostOprCRUD(commonBO, execution);
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Complete Status
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}
}
