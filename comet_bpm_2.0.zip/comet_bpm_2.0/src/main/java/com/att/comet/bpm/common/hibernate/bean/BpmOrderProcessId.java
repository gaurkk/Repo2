package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderProcessId.
 */
@Embeddable
public class BpmOrderProcessId implements java.io.Serializable {

	private static final long serialVersionUID = 5967059143613308L;

	private Long processId;
	private Long orderId;
	private Long orderTypeId;

	/**
	 * No-argument constructor for the class.
	 */
	public BpmOrderProcessId() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param processId
	 * @param orderId
	 * @param orderTypeId
	 */
	public BpmOrderProcessId(Long processId, Long orderId, Long orderTypeId) {
		this.processId = processId;
		this.orderId = orderId;
		this.orderTypeId = orderTypeId;
	}

	/**
	 * Getter method for processId. PROCESS_ID mapped to PROCESS_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Column(name = "PROCESS_ID", nullable = false, precision = 12, scale = 0)
	public Long getProcessId() {
		return this.processId;
	}

	/**
	 * @param processId to processId set.
	 */
	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderProcessId))
			return false;
		BpmOrderProcessId castOther = (BpmOrderProcessId) other;

		return (this.getProcessId() == castOther.getProcessId()) && (this.getOrderId() == castOther.getOrderId())
				&& (this.getOrderTypeId() == castOther.getOrderTypeId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getProcessId().intValue();
		result = 37 * result + (int) this.getOrderId().intValue();
		result = 37 * result + (int) this.getOrderTypeId().intValue();
		return result;
	}

}
