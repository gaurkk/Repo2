package com.att.comet.bpm.common.hibernate.bean;

import java.sql.Blob;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderAccount. Mapped to ORDER_ACCOUNT table in the
 * database.
 */
@Entity
@Table(name = "ORDER_ACCOUNT")
public class OrderAccount implements java.io.Serializable {

	private static final long serialVersionUID = 1436791396611182437L;

	private Long orderId;
	private String internalSupportMethod;
	private Orders orders;
	private String marketSegment;
	private String pdpDescription;
	private String agreementAccountName;
	private String agreementAccountNo;
	private Character eodEnabled;
	private Character eodWithFan;
	private String fanId;
	private String banId;
	private Character feeWaiverApproved;
	private Character feeWaiverApprovedMRC;
	private String waiverNotes;
	private byte[] waiverAttachment;
	private String waiverAttachmentFilename;
	private String cos;
	private String qos;
	private String serverSoftware;
	private String middleware;
	private String mobilePlatform;
	private String mobileSoftware;
	private Short currentYear;
	private String pkBwRelAvgBw;
	private String pecentBwOhVpnTunCust;
	private String noSmsWakeupsPerDevices;
	private String noPdpCtxActvPerDevice;
	private String avgLenActvPdpCtxSession;
	private String noOfNdcSupportTraffic;
	private String ismName;
	private String ismPhone;
	private String ismEmail;
	private String marketSegmentNote;
	private PdpPackage pdpPackage;
	private Set<OrderCapacityForecast> orderCapacityForecasts = new HashSet<OrderCapacityForecast>(0);
	
	private String eodBLU;//-- BR-2.2.005 -- HLD-2.2.5.02

	private String useCategory;
	private String primaryBackupRemote;
	private String userType;
	private String stationaryMobile;
	
	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for internalSupportMethod. INTERNAL_SUPPORT_METHOD mapped
	 * to INTERNAL_SUPPORT_METHOD in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INTERNAL_SUPPORT_METHOD", length = 100)
	public String getInternalSupportMethod() {
		return this.internalSupportMethod;
	}

	/**
	 * @param internalSupportMethod
	 *            to internalSupportMethod set
	 */
	public void setInternalSupportMethod(String internalSupportMethod) {
		this.internalSupportMethod = internalSupportMethod;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for marketSegment. MARKET_SEGMENT mapped to MARKET_SEGMENT
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MARKET_SEGMENT", length = 100)
	public String getMarketSegment() {
		return this.marketSegment;
	}

	/**
	 * @param marketSegment
	 *            to marketSegment set.
	 */
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	/**
	 * Getter method for pdpDescription. PDP_DESCRIPTION mapped to
	 * PDP_DESCRIPTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PDP_DESCRIPTION", length = 3500)
	public String getPdpDescription() {
		return this.pdpDescription;
	}

	/**
	 * @param pdpDescription
	 *            to pdpDescription set.
	 */
	public void setPdpDescription(String pdpDescription) {
		this.pdpDescription = pdpDescription;
	}

	/**
	 * Getter method for agreementAccountName. AGREEMENT_ACCOUNT_NAME mapped to
	 * AGREEMENT_ACCOUNT_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AGREEMENT_ACCOUNT_NAME", length = 100)
	public String getAgreementAccountName() {
		return this.agreementAccountName;
	}

	/**
	 * @param agreementAccountName
	 *            to agreementAccountName set.
	 */
	public void setAgreementAccountName(String agreementAccountName) {
		this.agreementAccountName = agreementAccountName;
	}

	/**
	 * Getter method for agreementAccountNo. AGREEMENT_ACCOUNT_NO mapped to
	 * AGREEMENT_ACCOUNT_NO in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AGREEMENT_ACCOUNT_NO", length = 100)
	public String getAgreementAccountNo() {
		return this.agreementAccountNo;
	}

	/**
	 * @param agreementAccountNo
	 *            to agreementAccountNo set.
	 */
	public void setAgreementAccountNo(String agreementAccountNo) {
		this.agreementAccountNo = agreementAccountNo;
	}

	/**
	 * Getter method for eodEnabled. EOD_ENABLED mapped to EOD_ENABLED in the
	 * database table.
	 * 
	 * @return Character
	 */
	@Column(name = "EOD_ENABLED", length = 1)
	public Character getEodEnabled() {
		return this.eodEnabled;
	}

	/**
	 * @param eodEnabled
	 *            to eodEnabled set.
	 */
	public void setEodEnabled(Character eodEnabled) {
		this.eodEnabled = eodEnabled;
	}

	/**
	 * Getter method for eodWithFan. EOD_WITH_FAN mapped to EOD_WITH_FAN in the
	 * database table.
	 * 
	 * @return Character
	 */
	@Column(name = "EOD_WITH_FAN", length = 1)
	public Character getEodWithFan() {
		return this.eodWithFan;
	}

	/**
	 * @param eodWithFan
	 *            to eodWithFan set.
	 */
	public void setEodWithFan(Character eodWithFan) {
		this.eodWithFan = eodWithFan;
	}

	/**
	 * Getter method for fanId. FAN_ID mapped to FAN_ID in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "FAN_ID", length = 20)
	public String getFanId() {
		return this.fanId;
	}

	/**
	 * @param fanId
	 *            to fanId set
	 */
	public void setFanId(String fanId) {
		this.fanId = fanId;
	}

	/**
	 * Getter method for banId. BAN_ID mapped to BAN_ID in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BAN_ID", length = 25)
	public String getBanId() {
		return this.banId;
	}

	/**
	 * @param banId
	 *            to banId set.
	 */
	public void setBanId(String banId) {
		this.banId = banId;
	}

	/**
	 * Getter method for feeWaiverApproved. FEE_WAIVER_APPROVED mapped to
	 * FEE_WAIVER_APPROVED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FEE_WAIVER_APPROVED", length = 1)
	public Character getFeeWaiverApproved() {
		return this.feeWaiverApproved;
	}

	/**
	 * @param feeWaiverApproved
	 *            to feeWaiverApproved set.
	 */
	public void setFeeWaiverApproved(Character feeWaiverApproved) {
		this.feeWaiverApproved = feeWaiverApproved;
	}

	/**
	 * Getter method for feeWaiverApprovedMRC. FEE_WAIVER_APPROVED_MRC mapped to
	 * FEE_WAIVER_APPROVED_MRC in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FEE_WAIVER_APPROVED_MRC", length = 1)
	public Character getFeeWaiverApprovedMRC() {
		return this.feeWaiverApprovedMRC;
	}

	/**
	 * @param feeWaiverApprovedMRC
	 *            to feeWaiverApprovedMRC set.
	 */
	public void setFeeWaiverApprovedMRC(Character feeWaiverApprovedMRC) {
		this.feeWaiverApprovedMRC = feeWaiverApprovedMRC;
	}
	
	/**
	 * Getter method for waiverNotes. WAIVER_NOTES mapped to WAIVER_NOTES in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_NOTES", length = 3500)
	public String getWaiverNotes() {
		return this.waiverNotes;
	}

	/**
	 * @param waiverNotes
	 *            to waiverNotes set.
	 */
	public void setWaiverNotes(String waiverNotes) {
		this.waiverNotes = waiverNotes;
	}

	/**
	 * Getter method for waiverAttachment. WAIVER_ATTACHMENT mapped to
	 * WAIVER_ATTACHMENT in the database table.
	 * 
	 * @return Blob
	 */
	@Column(name = "WAIVER_ATTACHMENT")
	public byte[] getWaiverAttachment() {
		return this.waiverAttachment;
	}

	/**
	 * @param waiverAttachment
	 *            to waiverAttachment set.
	 */
	public void setWaiverAttachment(byte[] waiverAttachment) {
		this.waiverAttachment = waiverAttachment;
	}

	/**
	 * Getter method for waiverAttachmentFilename. WAIVER_ATTACHMENT_FILENAME
	 * mapped to WAIVER_ATTACHMENT_FILENAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_ATTACHMENT_FILENAME", length = 100)
	public String getWaiverAttachmentFilename() {
		return this.waiverAttachmentFilename;
	}

	/**
	 * @param waiverAttachmentFilename
	 *            to waiverAttachmentFilename set.
	 */
	public void setWaiverAttachmentFilename(String waiverAttachmentFilename) {
		this.waiverAttachmentFilename = waiverAttachmentFilename;
	}

	/**
	 * Getter method for cos. COS mapped to COS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "COS", length = 200)
	public String getCos() {
		return this.cos;
	}

	/**
	 * @param cos
	 *            to cos set.
	 */
	public void setCos(String cos) {
		this.cos = cos;
	}

	/**
	 * Getter method for qos. QOS mapped to QOS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "QOS", length = 200)
	public String getQos() {
		return this.qos;
	}

	/**
	 * @param qos
	 *            to qos set.
	 */
	public void setQos(String qos) {
		this.qos = qos;
	}

	/**
	 * Getter method for serverSoftware. SERVER_SOFTWARE mapped to
	 * SERVER_SOFTWARE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SERVER_SOFTWARE", length = 3500)
	public String getServerSoftware() {
		return this.serverSoftware;
	}

	/**
	 * @param serverSoftware
	 *            to serverSoftware set.
	 */
	public void setServerSoftware(String serverSoftware) {
		this.serverSoftware = serverSoftware;
	}

	/**
	 * Getter method for middleware. MIDDLEWARE mapped to MIDDLEWARE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "MIDDLEWARE", length = 3500)
	public String getMiddleware() {
		return this.middleware;
	}

	/**
	 * @param middleware
	 *            to middleware set.
	 */
	public void setMiddleware(String middleware) {
		this.middleware = middleware;
	}

	/**
	 * Getter method for mobilePlatform. MOBILE_PLATFORM mapped to
	 * MOBILE_PLATFORM in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MOBILE_PLATFORM", length = 3500)
	public String getMobilePlatform() {
		return this.mobilePlatform;
	}

	/**
	 * @param mobilePlatform
	 *            to mobilePlatform set.
	 */
	public void setMobilePlatform(String mobilePlatform) {
		this.mobilePlatform = mobilePlatform;
	}

	/**
	 * Getter method for mobileSoftware. MOBILE_SOFTWARE mapped to
	 * MOBILE_SOFTWARE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MOBILE_SOFTWARE", length = 3500)
	public String getMobileSoftware() {
		return this.mobileSoftware;
	}

	/**
	 * @param mobileSoftware
	 *            to mobileSoftware set.
	 */
	public void setMobileSoftware(String mobileSoftware) {
		this.mobileSoftware = mobileSoftware;
	}

	/**
	 * Getter method for currentYear. CURRENT_YEAR mapped to CURRENT_YEAR in the
	 * database table.
	 * 
	 * @return Short
	 */
	@Column(name = "CURRENT_YEAR", precision = 4, scale = 0)
	public Short getCurrentYear() {
		return this.currentYear;
	}

	/**
	 * @param currentYear
	 *            to currentYear set.
	 */
	public void setCurrentYear(Short currentYear) {
		this.currentYear = currentYear;
	}

	/**
	 * Getter method for pkBwRelAvgBw. PK_BW_REL_AVG_BW mapped to
	 * PK_BW_REL_AVG_BW in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_BW_REL_AVG_BW", length = 200)
	public String getPkBwRelAvgBw() {
		return this.pkBwRelAvgBw;
	}

	/**
	 * @param pkBwRelAvgBw
	 *            to pkBwRelAvgBw set.
	 */
	public void setPkBwRelAvgBw(String pkBwRelAvgBw) {
		this.pkBwRelAvgBw = pkBwRelAvgBw;
	}

	/**
	 * Getter method for pecentBwOhVpnTunCust. PECENT_BW_OH_VPN_TUN_CUST mapped
	 * to PECENT_BW_OH_VPN_TUN_CUST in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PECENT_BW_OH_VPN_TUN_CUST", length = 200)
	public String getPecentBwOhVpnTunCust() {
		return this.pecentBwOhVpnTunCust;
	}

	/**
	 * @param pecentBwOhVpnTunCust
	 *            to pecentBwOhVpnTunCust set.
	 */
	public void setPecentBwOhVpnTunCust(String pecentBwOhVpnTunCust) {
		this.pecentBwOhVpnTunCust = pecentBwOhVpnTunCust;
	}

	/**
	 * Getter method for noSmsWakeupsPerDevices. NO_SMS_WAKEUPS_PER_DEVICES
	 * mapped to NO_SMS_WAKEUPS_PER_DEVICES in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "NO_SMS_WAKEUPS_PER_DEVICES", length = 200)
	public String getNoSmsWakeupsPerDevices() {
		return this.noSmsWakeupsPerDevices;
	}

	/**
	 * @param noSmsWakeupsPerDevices
	 *            to noSmsWakeupsPerDevices set.
	 */
	public void setNoSmsWakeupsPerDevices(String noSmsWakeupsPerDevices) {
		this.noSmsWakeupsPerDevices = noSmsWakeupsPerDevices;
	}

	/**
	 * Getter method for noPdpCtxActvPerDevice. NO_PDP_CTX_ACTV_PER_DEVICE
	 * mapped to NO_PDP_CTX_ACTV_PER_DEVICE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "NO_PDP_CTX_ACTV_PER_DEVICE", length = 200)
	public String getNoPdpCtxActvPerDevice() {
		return this.noPdpCtxActvPerDevice;
	}

	/**
	 * @param noPdpCtxActvPerDevice
	 *            to noPdpCtxActvPerDevice set.
	 */
	public void setNoPdpCtxActvPerDevice(String noPdpCtxActvPerDevice) {
		this.noPdpCtxActvPerDevice = noPdpCtxActvPerDevice;
	}

	/**
	 * Getter method for avgLenActvPdpCtxSession. AVG_LEN_ACTV_PDP_CTX_SESSION
	 * mapped to AVG_LEN_ACTV_PDP_CTX_SESSION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AVG_LEN_ACTV_PDP_CTX_SESSION", length = 200)
	public String getAvgLenActvPdpCtxSession() {
		return this.avgLenActvPdpCtxSession;
	}

	/**
	 * @param avgLenActvPdpCtxSession
	 *            to avgLenActvPdpCtxSession set.
	 */
	public void setAvgLenActvPdpCtxSession(String avgLenActvPdpCtxSession) {
		this.avgLenActvPdpCtxSession = avgLenActvPdpCtxSession;
	}

	/**
	 * Getter method for noOfNdcSupportTraffic. NO_OF_NDC_SUPPORT_TRAFFIC mapped
	 * to NO_OF_NDC_SUPPORT_TRAFFIC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "NO_OF_NDC_SUPPORT_TRAFFIC", length = 200)
	public String getNoOfNdcSupportTraffic() {
		return this.noOfNdcSupportTraffic;
	}

	/**
	 * @param noOfNdcSupportTraffic
	 *            tp noOfNdcSupportTraffic set.
	 */
	public void setNoOfNdcSupportTraffic(String noOfNdcSupportTraffic) {
		this.noOfNdcSupportTraffic = noOfNdcSupportTraffic;
	}

	/**
	 * Getter method for orderCapacityForecasts.
	 * 
	 * @return Set<OrderCapacityForecast>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orderAccount")
	public Set<OrderCapacityForecast> getOrderCapacityForecasts() {
		return this.orderCapacityForecasts;
	}

	/**
	 * @param orderCapacityForecasts
	 *            to orderCapacityForecasts set.
	 */
	public void setOrderCapacityForecasts(
			Set<OrderCapacityForecast> orderCapacityForecasts) {
		this.orderCapacityForecasts = orderCapacityForecasts;
	}

	/**
	 * Getter method for ismName. ISM_NAME mapped to ISM_NAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ISM_NAME", length = 100)
	public String getIsmName() {
		return ismName;
	}

	/**
	 * @param ismName
	 *            to ismName set.
	 */
	public void setIsmName(String ismName) {
		this.ismName = ismName;
	}

	/**
	 * Getter method for ismPhone. ISM_PHONE mapped to ISM_PHONE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ISM_PHONE", length = 100)
	public String getIsmPhone() {
		return ismPhone;
	}

	/**
	 * @param ismPhone
	 *            to ismPhone set.
	 */
	public void setIsmPhone(String ismPhone) {
		this.ismPhone = ismPhone;
	}

	/**
	 * Getter method for ismEmail. ISM_EMAIL mapped to ISM_EMAIL in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ISM_EMAIL", length = 100)
	public String getIsmEmail() {
		return ismEmail;
	}

	/**
	 * @param ismEmail
	 *            to ismEmail set.
	 */
	public void setIsmEmail(String ismEmail) {
		this.ismEmail = ismEmail;
	}

	/**
	 * Getter method for pdpPackage.
	 * 
	 * @return PdpPackage
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PDP_PACKAGE_ID")
	public PdpPackage getPdpPackage() {
		return this.pdpPackage;
	}

	/**
	 * @param pdpPackage
	 *            to PdpPackage set.
	 */
	public void setPdpPackage(PdpPackage pdpPackage) {
		this.pdpPackage = pdpPackage;
	}

	/**
	 * Getter method for marketSegmentNote. MARKET_SEGMENT_NOTE mapped to
	 * MARKET_SEGMENT_NOTE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MARKET_SEGMENT_NOTE", length = 3500)
	public String getMarketSegmentNote() {
		return marketSegmentNote;
	}

	/**
	 * @param marketSegmentNote
	 *            to marketSegmentNote set.
	 */
	public void setMarketSegmentNote(String marketSegmentNote) {
		this.marketSegmentNote = marketSegmentNote;
	}

	//-- STARTS -- BR-2.2.005 -- HLD-2.2.5.02
	/**
	 * Getter method for EOD_BLU mapped to EOD_BLU column in the database table.
	 * @return
	 */
	@Column(name = "EOD_BLU", length = 20)
	public String getEodBLU() {
		return eodBLU;
	}
	
	/**
	 * 
	 * @param eodBLU
	 */
	public void setEodBLU(String eodBLU) {
		this.eodBLU = eodBLU;
	}
	//-- ENDS -- BR-2.2.005 -- HLD-2.2.5.02
	
	/**
	 * @return the useCategory
	 */
	@Column(name = "USE_CATEGORY", length = 100)
	public String getUseCategory() {
		return useCategory;
	}

	/**
	 * @param useCategory the useCategory to set
	 */
	public void setUseCategory(String useCategory) {
		this.useCategory = useCategory;
	}

	/**
	 * @return the primaryBackupRemote
	 */
	@Column(name = "PRIMARY_BACKUP_REMOTE", length = 100)
	public String getPrimaryBackupRemote() {
		return primaryBackupRemote;
	}

	/**
	 * @param primaryBackupRemote the primaryBackupRemote to set
	 */
	public void setPrimaryBackupRemote(String primaryBackupRemote) {
		this.primaryBackupRemote = primaryBackupRemote;
	}

	/**
	 * @return the userType
	 */
	@Column(name = "USER_TYPE", length = 100)
	public String getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @return the stationaryMobile
	 */
	@Column(name = "STATIONARY_MOBILE", length = 100)
	public String getStationaryMobile() {
		return stationaryMobile;
	}

	/**
	 * @param stationaryMobile the stationaryMobile to set
	 */
	public void setStationaryMobile(String stationaryMobile) {
		this.stationaryMobile = stationaryMobile;
	}
}