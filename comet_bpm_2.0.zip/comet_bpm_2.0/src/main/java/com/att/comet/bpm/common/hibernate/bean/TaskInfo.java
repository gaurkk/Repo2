package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "TASK_INFO")
@Data
public class TaskInfo implements Serializable {

	private static final long serialVersionUID = 334850117512316109L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "taskId", column = @Column(name = "TASK_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "taskDisplayTypeId", column = @Column(name = "TASK_DISPLAY_TYPE_ID", nullable = false, precision = 12, scale = 0)) })
	private TaskInfoId taskInfoId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TASK_ID", nullable = false, insertable = false, updatable = false)
	private BpmTask bpmTask;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TASK_DISPLAY_TYPE_ID", nullable = false, insertable = false, updatable = false)
	private TaskDisplayType taskDisplayType;

	@Column(name = "SUBJECT", length = 2000)
	private String subject;

	@Column(name = "HEADER_SECTION", length = 2000)
	private String headerSection;

	@Column(name = "SUB_HEADER_SECTION", length = 2000)
	private String subHeaderSection;

	@Column(name = "BODY_SECTION_1", length = 4000)
	private String bodySection1;

	@Column(name = "BODY_SECTION_2", length = 4000)
	private String bodySection2;

	@Column(name = "BODY_SECTION_3", length = 4000)
	private String bodySection3;

	@Column(name = "FOOTER_SECTION", length = 2000)
	private String footerSection;
}
