package com.att.comet.bpm.decom.billing.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.decom.billing.helper.OABillingDecomHelper;

@Service
public class OABillingDecomServiceImpl implements OABillingDecomService {

	@Autowired
	private OABillingDecomHelper oaBillingDecomHelper;

	@Autowired
	private CommonService commonService;

	@Override
	public void preOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		oaBillingDecomHelper.preOperationOABillingDecom(commonBO, execution);
	}

	@Override
	public void postOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		oaBillingDecomHelper.postOperationOABillingDecom(commonBO, execution);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1004L);// Network Implementation Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1044L);// Mapped from BPM_task table (OA : Decommission Task for Billing)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
