package com.att.comet.bpm.ttu.delegate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.CometAppRequestException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;

import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.ttu.service.OSDTTUReScheduleService;

@Component
public class OSDTTUReScheduleDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUReScheduleDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	OSDTTUReScheduleService osdTTUReScheduleService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String operationType = (String) execution.getVariable("OPERATION");

		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.ORDER_STATUS_CHECK:
				orderStatusCheck(execution);
				break;
			case BpmConstant.PRE_OPERATION_TTU_RESCHEDULE:
				preOperationTTUReSchedule(execution);
				break;
			case BpmConstant.POST_OPERATION_TTU_RESCHEDULE:
				postOperationTTUReSchedule(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void orderStatusCheck(DelegateExecution execution) {
		logger.info("Starting orderStatusCheck method ");
		CommonBO commonBO = null;
		String OSDTTUscheduleInstanceId = null;
		OSDTTUscheduleInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
				if (null != commonBO) {
					String orderStatus = commonBO.getOrderStatusName();
					
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable(BpmConstant.ORDER_STATUS, orderStatus);
					} else {
						logger.error("Order Status name for  ," + "ORDER_ID::[" + orderId + "]  is null", this);
					}
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);

			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_RESCHEDULE_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending orderStatusCheck method ");

	}

	private void preOperationTTUReSchedule(DelegateExecution execution) {
		logger.info("Starting preOperationTTUReSchedule method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String OSDTTUReScheduleInstanceId = null;
			OSDTTUReScheduleInstanceId = execution.getProcessInstanceId();
			CommonBO commonBO = null;
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OSD_TTU_RESCHEDULE_ERR_PRE_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1027L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");// User task
				commonBO.setUpdatedOn(new Date());
				commonBO.setRoleId(1001L);// Setting OSD roleID
				commonBO.setTaskStatusId(1001L);// Task Id//Creation
				commonBO.setTaskStatusName("TTUScheduleOSD");
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(commonBO.getWorkFlowUrl());
				commonBO.setTaskId(1027L);// Mapped from BPM_task table (OSD : TTU - ReSchedule)
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				osdTTUReScheduleService.preOperationOSDTTUReSchedule(commonBO);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.BPM_STATUS_ID, commonBO.getTaskStatusName());
				execution.setVariable(BpmConstant.USER_DECISION, commonBO.getTaskUserDecision());
				execution.setVariable(BpmConstant.ORDER_OPERATION, commonBO.getOrderOperation());
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}

		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_RESCHEDULE_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending preOperationTTUReSchedule method ");

	}

	private void postOperationTTUReSchedule(DelegateExecution execution) throws ParseException {
		logger.info("Starting postOperationTTUReSchedule method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			String reasonForReschedule = (String) execution.getVariable(BpmConstant.REASON_FOR_RESCHEDULE);
			String ttuReScheduleDateTime = (String) execution.getVariable(BpmConstant.TTU_RE_SCHEDULE_DATE);
			CommonBO commonBO = null;
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OSD_TTU_RESCHEDULE_ERR_POST_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1027L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			commonBO.setOrderOperation(orderOperation);
			osdTTUReScheduleService.postOperationOSDTTUReSchedule(commonBO, reasonForReschedule,
					ttuReScheduleDateTime);

			commonBO.setTaskCompletionTime(new Date());
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);
			commonService.updateOrderUserBpmTasksRepository(commonBO);

			// execution.setVariable("isTTURequired", commonBO.getBusinessStepValue());
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable(BpmConstant.RESCHEDULED, "Yes");

		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_RESCHEDULE_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending postOperationTTUReSchedule method ");

	}

}
