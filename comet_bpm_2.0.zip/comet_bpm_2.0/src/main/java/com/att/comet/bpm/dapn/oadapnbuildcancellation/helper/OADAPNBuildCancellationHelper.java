package com.att.comet.bpm.dapn.oadapnbuildcancellation.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OADAPNBuildCancellationHelper {
	private static final Logger logger = LoggerFactory.getLogger(OADAPNBuildCancellationHelper.class);
	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private AvosDAO avosDAO;

	@Autowired
	private BpmOrderWorkStepDAO bpmOrderWorkStepDAO;

	public void preOperationOADAPNBuildCancellation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start preOperationOADAPNBuildCancellation method ::", this);
		// Delete BpmOrderProcess
		commonBO.setProcessId(1031L);
		bpmDAO.deleteBpmOrderProcess(commonBO);

		// Save BpmOrderProcess
		commonBO.setBpmStatusId(1001L);
		commonBO.setProcessId(1031L);
		bpmDAO.saveBpmOrderProcess(commonBO);

		// Save AVOSProcessInstances
		commonBO.setBpmProcessId(1031L);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3215L);
		businessStepIdList.add(3216L);
		businessStepIdList.add(3217L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		// Delete BpmOrderWorkStep
		commonBO.setWorkStepId(1078L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		// Save BpmOrderWorkStep
		commonBO.setWorkStepId(1078L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayForITOPSDAPN(commonBO);


		commonBO.setOrderContactTypeId(1004L);
		String attuid = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(attuid)) {
			commonBO.setAttuid(attuid);
			commonBO.setAssignee(attuid);
			commonBO.setToEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));

		} else {
			commonBO.setToEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));

		}
		commonBO.setOrderContactTypeId(1003L);
		
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO); 
		if (!CollectionUtils.isEmpty(attUidList)) { 
			logger.debug("osdEmailList is not empty : ", +attUidList.size()); 
			String ccsPM = attUidList.get(0);
			commonBO.setAttuid(ccsPM);
			List<String> CCSPMEmailList = userDAO.getUserEmail(commonBO); 
			commonBO.setEmailList(CCSPMEmailList); 
		}
	
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		//commonBO.setCcEmail((commonBO.getToEmail() + "," + commonBO.getAdminEmail()) + "," + CCSPMEmailList + "," + niEmail1);

		// Set SLA
		genericDAO.setReminder1And2FromSlaWorkingDayForOADAPNBuildCancellation(commonBO);
		logger.info("End preOperationOADAPNBuildCancellation method ::", this);
	}

	public void postOperationOADAPNBuildCancellation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start postOperationOADAPNBuildCancellation method ::", this);
		// Update BpmOrderWorkStep
		commonBO.setWorkStepId(1078L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		// Delete BpmOrderBusinessStep
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3215L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		// Delete BpmOrderBusStepHistory
		genericDAO.deleteBpmOrderBusStepHistory(commonBO.getOrderId(), 3215L);

		// Save OrderComments
		commonBO.setRoleId(1002L);
		orderDAO.saveOrderComments(commonBO);

		// Save BpmOrderBusinessStep
		
		  commonBO.setBusinessStepValue(commonBO.getApproved());
		  commonBO.setUpdatedBy(commonBO.getAttuid());
		  commonBO.setBusinessStepId(3215L); 
		  commonBO.setUpdatedOn(new Date());
		  bpmDAO.saveBpmOrderBusinessStep(commonBO);
		 

		// Save BpmOrderBusStepHistory
		commonBO.setBusinessStepId(3215L);
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);
		logger.info("End postOperationOADAPNBuildCancellation method ::", this);
	}
}
