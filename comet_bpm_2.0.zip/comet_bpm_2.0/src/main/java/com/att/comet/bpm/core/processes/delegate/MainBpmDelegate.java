package com.att.comet.bpm.core.processes.delegate;

import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;

@Component
public class MainBpmDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(MainBpmDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String operationType = (String) execution.getVariable("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.COMPLETE_WORK_FLOW:
				completeWorkFlow(execution);
				break;
			case BpmConstant.PREOPERATION_MAIN:
				preOperation(execution);
				break;
			}
		} else {
			logger.error("@@@@ operationType is null :::" + operationType, this);
		}

	}

	private void preOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting preOperation method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			logger.info(
					"Order id coming from COMET UI ::::  " + orderId + ":::: orderOperation is ::: " + orderOperation,
					this);
			BpmTask bpmTask = new BpmTask();
			Orders order = new Orders();
			String inProgressTask = null;
			Long taskId = 1037L;
			bpmTask.setTaskId(taskId);
			Long taskStatusId = 1001L;
			order.setOrderId(orderId);
			if (orderOperation.equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
				List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
				if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
					for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
						if (taskObj.getBpmTask().getTaskId().equals(taskId)
								&& taskObj.getTaskStatus().getTaskStatusId().equals(taskStatusId)) {
							logger.info("@@@@ in progress Process :::  " + taskObj.getProcessInstanceId()
									+ "   @@@@ in progress BPM Task Id ::: " + taskObj.getBpmTaskId(), this);
							inProgressTask = taskObj.getBpmTaskId();
							break;
						} else {
							//execution.setVariable("inProgressTask", inProgressTask);
							logger.info("bpmTaskId is null for orderId ::  " + orderId + " for the task :: " + taskId);
						}
					}
				}
				if (CommonUtils.isNotNullEmpty(inProgressTask)) {
					execution.setVariable("inProgressTask", inProgressTask);
				}else {
					execution.setVariable("inProgressTask", "noTask");
				}
			} else {
				logger.info("Order id coming from COMET UI ::::  " + orderId
						+ ":::: orderOperation is not Cancel Order::: " + orderOperation, this);
			}
		} catch (Exception e) {
			throw new CamundaServiceException("In proper request from comet app");
		}
		logger.info("Starting preOperation method ");
	}

	private void completeWorkFlow(DelegateExecution execution) {
		logger.info("Starting completeWorkFlow method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String response = (String) execution.getVariable("response");
		CommonBO commonBO = null;
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					Date sysdate = new Date();
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);

					if (orderOperation.equalsIgnoreCase(BpmConstant.CANCEL_ORDER)) {
						if (null != commonBO.getApproved()) {
							if (commonBO.getApproved().equalsIgnoreCase(BpmConstant.REJECTED)) {
								logger.debug(" @@@ cancel Order has been rejected by OA @@@ ::: ");
							} else {
								commonBO.setOrderStatusId(1003L);
								commonBO.setDateInProduction(sysdate);
								coreProcessDelegateHelper.updateOrderStaus(commonBO);
								// String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId,
								// orderOperation);
								// logger.info("work flow has been completed :: " + isWorkflowCompleted, this);
							}
						}
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.DECOMMISSION_ORDER)) {
						commonBO.setOrderStatusId(1023L);
						commonBO.setDateInProduction(sysdate);
						coreProcessDelegateHelper.updateOrderStaus(commonBO);
						String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId, orderOperation);
						logger.info("work flow has been completed  :: " + isWorkflowCompleted, this);
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
						commonBO.setOrderStatusId(1009L);
						commonBO.setDateInProduction(sysdate);
						coreProcessDelegateHelper.updateOrderStaus(commonBO);
						Long derivedOrder = orderDAO.getDerivedOrderId(commonBO);
						if (null != derivedOrder) {
							logger.info("@@@ derivedOrder is @@@  " + derivedOrder, this);
							orderDAO.updateOrderStatus(derivedOrder, 1064L);

						} else {
							logger.error("@@@ derivedOrder is null @@@ ", this);
						}
						String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId, orderOperation);
						logger.info("work flow has been completed  :: " + isWorkflowCompleted, this);
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.DAPN_ORDER)) {
						commonBO.setOrderStatusId(1068L);
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.ONHOLD_ORDER)) {
						if (null != commonBO.getApproved()
								&& commonBO.getApproved().equalsIgnoreCase(BpmConstant.REJECTED)) {
							logger.debug(" @@@ On-Hold Order has been rejected by OA @@@ ::: ");

						} else {
							
							String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId, orderOperation);
							commonBO.setOrderStatusId(1009L);
							commonBO.setDateInProduction(sysdate);
							coreProcessDelegateHelper.updateOrderStaus(commonBO);
							logger.info("work flow has been completed  :: " + isWorkflowCompleted, this);
						}
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.BASE_ORDER)
							|| orderOperation.equalsIgnoreCase(BpmConstant.NEW_ORDER)) {
						
						String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId, orderOperation);
						commonBO.setOrderStatusId(1009L);
						commonBO.setDateInProduction(sysdate);
						coreProcessDelegateHelper.updateOrderStaus(commonBO);
						logger.info("work flow has been completed  :: " + isWorkflowCompleted, this);
					} else if (orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
						if (null != commonBO.getApproved()
								&& commonBO.getApproved().equalsIgnoreCase(BpmConstant.REJECTED)) {
							logger.debug(" @@@ Change Request has been rejected by OA @@@ ::: ");
						} else {
							
							String isWorkflowCompleted = commonService.completeOrderWorkFlow(orderId, orderOperation);
							commonBO.setOrderStatusId(1009L);
							commonBO.setDateInProduction(sysdate);
							coreProcessDelegateHelper.updateOrderStaus(commonBO);
							logger.info("work flow has been completed  :: " + isWorkflowCompleted, this);
						}
					}

				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (CamundaServiceException e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TTU Applicability TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Exiting completeWorkFlow method ");

	}

}
