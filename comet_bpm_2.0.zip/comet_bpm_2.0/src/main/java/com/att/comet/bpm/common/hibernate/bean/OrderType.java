package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for OrderType. Mapped to ORDER_TYPE table in the database.
 */
@Entity
@Table(name = "ORDER_TYPE")
public class OrderType implements java.io.Serializable {

	private static final long serialVersionUID = 7731094160527703013L;
	private Long orderTypeId;
	private String orderTypeName;
	private Set<Orders> orderses = new HashSet<Orders>(0);

	/**
	 * No-argument constructor of the class.
	 */
	public OrderType() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderTypeId
	 * @param orderTypeName
	 */
	public OrderType(Long orderTypeId, String orderTypeName) {
		this.orderTypeId = orderTypeId;
		this.orderTypeName = orderTypeName;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderTypeId
	 * @param orderTypeName
	 * @param orderses
	 */
	public OrderType(Long orderTypeId, String orderTypeName,
			Set<Orders> orderses) {
		this.orderTypeId = orderTypeId;
		this.orderTypeName = orderTypeName;
		this.orderses = orderses;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId
	 *            to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/**
	 * Getter method for orderTypeName. ORDER_TYPE_NAME mapped to
	 * ORDER_TYPE_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_TYPE_NAME", nullable = false, length = 50)
	public String getOrderTypeName() {
		return this.orderTypeName;
	}

	/**
	 * @param orderTypeName
	 *            to orderTypeName set.
	 */
	public void setOrderTypeName(String orderTypeName) {
		this.orderTypeName = orderTypeName;
	}

	/**
	 * Getter method for orderses.
	 * 
	 * @return Set<Orders>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orderType")
	public Set<Orders> getOrderses() {
		return this.orderses;
	}

	/**
	 * @param orderses
	 *            to orderses set.
	 */
	public void setOrderses(Set<Orders> orderses) {
		this.orderses = orderses;
	}

}
