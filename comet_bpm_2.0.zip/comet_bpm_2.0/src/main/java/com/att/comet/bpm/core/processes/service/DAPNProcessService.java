package com.att.comet.bpm.core.processes.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface DAPNProcessService {
	public void preOperation(CommonBO commonBO) throws CamundaServiceException;
	public void postOperation(CommonBO commonBO) throws CamundaServiceException;
	public void orderStatusUpdate(CommonBO commonBO) throws CamundaServiceException;
	public void orderStatusUpdateProd(CommonBO commonBO) throws CamundaServiceException;
	public void billingSla(CommonBO commonBO) throws CamundaServiceException;
}
