package com.att.comet.bpm.common.hibernate.bean;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmWorkStepSlaId.
 */
@Embeddable
public class BpmWorkStepSlaId implements java.io.Serializable {

	private static final long serialVersionUID = 3125610142967393010L;

	private BigDecimal workStepId;
	private String slaLevel;

	/**
	 * No-argument constructor.
	 */
	public BpmWorkStepSlaId() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param workStepId
	 * @param slaLevel
	 */
	public BpmWorkStepSlaId(BigDecimal workStepId, String slaLevel) {
		this.workStepId = workStepId;
		this.slaLevel = slaLevel;
	}

	/**
	 * Getter method for workStepId. WORK_STEP_ID mapped to WORK_STEP_ID in the
	 * database table.
	 * 
	 * @return BigDecimal
	 */
	@Column(name = "WORK_STEP_ID", nullable = false, precision = 22, scale = 0)
	public BigDecimal getWorkStepId() {
		return this.workStepId;
	}

	/**
	 * @param workStepId to workStepId set.
	 */
	public void setWorkStepId(BigDecimal workStepId) {
		this.workStepId = workStepId;
	}

	/**
	 * Getter method for slaLevel. SLA_LEVEL mapped to SLA_LEVEL in the database.
	 * 
	 * @return String.
	 */
	@Column(name = "SLA_LEVEL", nullable = false, length = 100)
	public String getSlaLevel() {
		return this.slaLevel;
	}

	/**
	 * @param slaLevel to slaLevel set.
	 */
	public void setSlaLevel(String slaLevel) {
		this.slaLevel = slaLevel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmWorkStepSlaId))
			return false;
		BpmWorkStepSlaId castOther = (BpmWorkStepSlaId) other;

		return ((this.getWorkStepId() == castOther.getWorkStepId()) || (this.getWorkStepId() != null
				&& castOther.getWorkStepId() != null && this.getWorkStepId().equals(castOther.getWorkStepId())))
				&& ((this.getSlaLevel() == castOther.getSlaLevel()) || (this.getSlaLevel() != null
						&& castOther.getSlaLevel() != null && this.getSlaLevel().equals(castOther.getSlaLevel())));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (getWorkStepId() == null ? 0 : this.getWorkStepId().hashCode());
		result = 37 * result + (getSlaLevel() == null ? 0 : this.getSlaLevel().hashCode());
		return result;
	}

}
