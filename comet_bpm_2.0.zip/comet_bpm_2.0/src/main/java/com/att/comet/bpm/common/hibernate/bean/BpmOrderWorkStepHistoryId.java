package com.att.comet.bpm.common.hibernate.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderWorkStepHistoryId.
 */
@Embeddable
public class BpmOrderWorkStepHistoryId implements java.io.Serializable {

	private static final long serialVersionUID = 1324429234723551467L;

	private Long workStepId;
	private Long orderId;
	private Long orderTypeId;
	private Long bpmStatusId;
	private Date workStepExecutedOn;
	private String userDecision;
	private Date userDecisionOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;

	/**
	 * No-argument constructor.
	 */
	public BpmOrderWorkStepHistoryId() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param workStepId
	 * @param orderId
	 * @param orderTypeId
	 * @param bpmStatusId
	 * @param workStepExecutedOn
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderWorkStepHistoryId(Long workStepId, Long orderId, Long orderTypeId, Long bpmStatusId,
			Date workStepExecutedOn, Date createdOn, Date updatedOn) {
		this.workStepId = workStepId;
		this.orderId = orderId;
		this.orderTypeId = orderTypeId;
		this.bpmStatusId = bpmStatusId;
		this.workStepExecutedOn = workStepExecutedOn;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param workStepId
	 * @param orderId
	 * @param orderTypeId
	 * @param bpmStatusId
	 * @param workStepExecutedOn
	 * @param userDecision
	 * @param userDecisionOn
	 * @param comments
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderWorkStepHistoryId(Long workStepId, Long orderId, Long orderTypeId, Long bpmStatusId,
			Date workStepExecutedOn, String userDecision, Date userDecisionOn, String comments, Date createdOn,
			Date updatedOn) {
		this.workStepId = workStepId;
		this.orderId = orderId;
		this.orderTypeId = orderTypeId;
		this.bpmStatusId = bpmStatusId;
		this.workStepExecutedOn = workStepExecutedOn;
		this.userDecision = userDecision;
		this.userDecisionOn = userDecisionOn;
		this.comments = comments;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for workStepId. WORK_STEP_ID mapped to WORK_STEP_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "WORK_STEP_ID", nullable = false, precision = 12, scale = 0)
	public Long getWorkStepId() {
		return this.workStepId;
	}

	/**
	 * @param workStepId to workStepId set.
	 */
	public void setWorkStepId(Long workStepId) {
		this.workStepId = workStepId;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/**
	 * Getter method for bpmStatusId. BPM_STATUS_ID mapped to BPM_STATUS_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BPM_STATUS_ID", nullable = false, precision = 12, scale = 0)
	public Long getBpmStatusId() {
		return this.bpmStatusId;
	}

	/**
	 * @param bpmStatusId to bpmStatusId set.
	 */
	public void setBpmStatusId(Long bpmStatusId) {
		this.bpmStatusId = bpmStatusId;
	}

	/**
	 * Getter method for workStepExecutedOn. WORK_STEP_EXECUTED_ON mapped to
	 * WORK_STEP_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "WORK_STEP_EXECUTED_ON", nullable = false)
	public Date getWorkStepExecutedOn() {
		return this.workStepExecutedOn;
	}

	/**
	 * @param workStepExecutedOn to workStepExecutedOn set.
	 */
	public void setWorkStepExecutedOn(Date workStepExecutedOn) {
		this.workStepExecutedOn = workStepExecutedOn;
	}

	/**
	 * Getter method for userDecision. USER_DECISION mapped to USER_DECISION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_DECISION", length = 100)
	public String getUserDecision() {
		return this.userDecision;
	}

	/**
	 * @param userDecision to userDecision set.
	 */
	public void setUserDecision(String userDecision) {
		this.userDecision = userDecision;
	}

	/**
	 * Getter method for userDecisionOn. USER_DECISION_ON mapped to USER_DECISION_ON
	 * in the database table.
	 * 
	 * @return Date.
	 */
	@Column(name = "USER_DECISION_ON")
	public Date getUserDecisionOn() {
		return this.userDecisionOn;
	}

	/**
	 * @param userDecisionOn to userDecisionOn set.
	 */
	public void setUserDecisionOn(Date userDecisionOn) {
		this.userDecisionOn = userDecisionOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTSin the database table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderWorkStepHistoryId))
			return false;
		BpmOrderWorkStepHistoryId castOther = (BpmOrderWorkStepHistoryId) other;

		return (this.getWorkStepId() == castOther.getWorkStepId()) && (this.getOrderId() == castOther.getOrderId())
				&& (this.getOrderTypeId() == castOther.getOrderTypeId())
				&& (this.getBpmStatusId() == castOther.getBpmStatusId())
				&& ((this.getWorkStepExecutedOn() == castOther.getWorkStepExecutedOn())
						|| (this.getWorkStepExecutedOn() != null && castOther.getWorkStepExecutedOn() != null
								&& this.getWorkStepExecutedOn().equals(castOther.getWorkStepExecutedOn())))
				&& ((this.getUserDecision() == castOther.getUserDecision())
						|| (this.getUserDecision() != null && castOther.getUserDecision() != null
								&& this.getUserDecision().equals(castOther.getUserDecision())))
				&& ((this.getUserDecisionOn() == castOther.getUserDecisionOn())
						|| (this.getUserDecisionOn() != null && castOther.getUserDecisionOn() != null
								&& this.getUserDecisionOn().equals(castOther.getUserDecisionOn())))
				&& ((this.getComments() == castOther.getComments()) || (this.getComments() != null
						&& castOther.getComments() != null && this.getComments().equals(castOther.getComments())))
				&& ((this.getCreatedOn() == castOther.getCreatedOn()) || (this.getCreatedOn() != null
						&& castOther.getCreatedOn() != null && this.getCreatedOn().equals(castOther.getCreatedOn())))
				&& ((this.getUpdatedOn() == castOther.getUpdatedOn()) || (this.getUpdatedOn() != null
						&& castOther.getUpdatedOn() != null && this.getUpdatedOn().equals(castOther.getUpdatedOn())));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getWorkStepId().intValue();
		result = 37 * result + (int) this.getOrderId().intValue();
		result = 37 * result + (int) this.getOrderTypeId().intValue();
		result = 37 * result + (int) this.getBpmStatusId().intValue();
		result = 37 * result + (getWorkStepExecutedOn() == null ? 0 : this.getWorkStepExecutedOn().hashCode());
		result = 37 * result + (getUserDecision() == null ? 0 : this.getUserDecision().hashCode());
		result = 37 * result + (getUserDecisionOn() == null ? 0 : this.getUserDecisionOn().hashCode());
		result = 37 * result + (getComments() == null ? 0 : this.getComments().hashCode());
		result = 37 * result + (getCreatedOn() == null ? 0 : this.getCreatedOn().hashCode());
		result = 37 * result + (getUpdatedOn() == null ? 0 : this.getUpdatedOn().hashCode());
		return result;
	}

}
