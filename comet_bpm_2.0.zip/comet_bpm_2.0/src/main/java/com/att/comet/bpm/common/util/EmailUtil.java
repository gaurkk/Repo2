package com.att.comet.bpm.common.util;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.att.comet.bpm.common.modal.EmailTemplateBO;
import com.att.comet.bpm.config.CometYamlPropertySourceFactory;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Component
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class EmailUtil {
	private static final Logger logger = LoggerFactory.getLogger(EmailUtil.class);
	@Autowired
	private Configuration config;
	public static final String taskIdVar = "@@@taskId@@@";
	public static final String orderIdVar = "@@@orderId@@@";
	public static final String orderTypeVar = "@@@orderType@@@";
	public static final String apnNameVar = "@@@apnName@@@";
	public static final String pdpNameVar = "@@@pdpName@@@";
	public static final String backHaulVar = "@@@backHaul@@@";
	public static final String accountIdVar = "@@@accountId@@@";
	public static final String accountName = "@@@accountName@@@";
	public static final String eodOrder = "@@@eodOrder@@@";
	public static final String feeWaiverApproved = "@@@feeWaiverApproved@@@";
	public static final String companyBillingAddress = "@@@companyBillingAddress@@@";
	public static final String companyContactNamePhone = "@@@companyContactNamePhone@@@";
	public static final String federalTaxID = "@@@federalTaxID@@@";
	public static final String ban = "@@@ban@@@";
	public static final String fan = "@@@fan@@@";
	public static final String accountManager = "@@@accountManager@@@";
	public static final String mobilityTechnicalEngineer = "@@@mobilityTechnicalEngineer@@@";
	public static final String sourceofIPAddressing = "@@@sourceofIPAddressing@@@";
	public static final String typeofAddressing = "@@@typeofAddressing@@@";
	public static final String backhaulInstances = "@@@backhaulInstances@@@";
	public static final String mplscir = "@@@mplscir@@@";
	public static final String managedAVPN = "@@@managedAVPN@@@";
	public static final String rejectionComments = "@@@rejectionComments@@@";// OA/OM rejectionComments
	public static final String approverComments = "@@@approverComments@@@";// approver comments
	public static final String crNote = "@@@crNote@@@";
	public static final String pleaseClick = "@@@@url_value@@@";

	public static final String apnType = "@@@apnType@@@";
	public static final String iPType = "@@@iPType@@@";
	public static final String ifStatic = "@@@ifStatic@@@";
	public static final String mrc = "@@@mrc@@@";
	public static final String ericssonCode = "@@@ericssonCode@@@";
	public static final String userDefinedPDPID = "@@@userDefinedPDPID@@@";
	public static final String cometPdpId = "@@@cometPdpId@@@";
	public static final String companyName = "@@@companyName@@@";
	public static final String ultimateAccountName = "@@@ultimateAccountName@@@";
	public static final String materAccountID = "@@@materAccountID@@@";
	public static final String agreementAccountName = "@@@agreementAccountName@@@";
	public static final String agreementAccountNumber = "@@@agreementAccountNumber@@@";
	public static final String pdpPackageName = "@@@pdpPackageName@@@";
	public static final String pdpPackageDesc = "@@@pdpPackageDesc@@@";
	public static final String pdpDescription = "@@@pdpDescription@@@";
	public static final String onHoldRequestedDate = "@@@onHoldRequestedDate@@@";
	public static final String onHoldProposedCompletionDate = "@@@onHoldProposedCompletionDate@@@";
	public static final String onHoldReason = "@@@onHoldReason@@@";
	public static final String onHoldNotes = "@@@onHoldNotes@@@";
	public static final String cancellationComments = "@@@cancellationComments@@@";// On Hold Cancellation Comments
	public static final String completionComments = "@@@completionComments@@@";// On Hold Completion Comments
	public static final String firstNet = "@@@firstNet@@@";
	public static final String ocs = "@@@ocs@@@";
	public static final String pmip = "@@@pmip@@@";
	public static final String fanAccontNumber = "@@@fanAccontNumber@@@";
	public static final String subAccountName = "@@@subAccountName@@@";
	public static final String accountId = "@@@accountId@@@";
	

	@Value("${comet.email.destro-email}")
	private String destroEmail;

	/**
	 * Utility method to send simple HTML email
	 * 
	 * @param session
	 * @param toEmail
	 * @param subject
	 * @param body
	 */
	public void sendEmail(Session session, EmailTemplateBO emailBO, Map<String, Object> model) {
		logger.info("@Starting sendEmail");
		try {
			MimeMessage msg = new MimeMessage(session);
			// set message headers

			msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
			msg.addHeader("format", "flowed");
			msg.addHeader("Content-Transfer-Encoding", "8bit");

			Template t = config.getTemplate("emailTemplate.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
			msg.setFrom(new InternetAddress(destroEmail, "COMET-UAT"));
			msg.setSubject(emailBO.getSubject(), "UTF-8");
			msg.setText(html, "UTF-8");
			msg.setContent(html, "text/html");
			msg.setSentDate(new Date());
			if (null != emailBO.getToEmail()) {
				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailBO.getToEmail(), false));
			} else {
				logger.error("NO TO EMAIL SET::" + this);
			}
			if (null != emailBO.getCcEmail()) {
				msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse(emailBO.getCcEmail(), false));
			} else {
				logger.info("NO CC EMAIL SET::" + this);
			}

			System.out.println("Message is ready");
			Transport.send(msg);
			logger.info("@Ending sendEmail ::::EMail Sent Successfully!! ");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String formatStringTemplate(String message) {
		message = message.replaceAll("\\<.*?\\>", "");
		message = message.replace("&nbsp;", " ");
		return message;
	}

	/**
	 * Remove HTML Tag
	 * 
	 * @param message
	 * @return
	 */
	public static String formatString(String message) {
		message = message.replaceAll("\\<.*?\\>", "");
		message = message.replace("&nbsp;", " ");
		return message;
	}

	public static boolean isCharPresent(String message, String findStr) {
		Boolean found = Arrays.asList(message.split("@@@")).contains(findStr);
		if (found.booleanValue()) {
			return true;
		}
		return false;
	}

	public static String replaceStr(String message, String findStr, String replaceStr) {
		message = message.replace(findStr, replaceStr);
		return message;
	}

	public static String splitVariable(String message, String findStr, String replaceStr) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(formatString(message));
		if (isCharPresent(strBuilder.toString(), findStr)) {
			return replaceStr(strBuilder.toString(), findStr, replaceStr);
		}
		return null;
	}

}
