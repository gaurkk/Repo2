package com.att.comet.bpm.common.modal;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrdersBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long orderId;

	private Long orderStatusId;
	private String orderStatusName;
	private String createdBy;
	private Date createdOn;
	private Date submittedOn;
	private String updatedBy;
	private Date updatedOn;
	private Long orderTypeId;
	private String comments;
	private long orderContactId;
	private String pcrf;
	private String apnName;
	private String accountName;
	private Long accountClassId;
	private String cipn;
	private String bcId;
	private String ubcId;
	private String backHaulIds;
	private String pdpName;
	private String orderTypeName;
	private String accountClassName;
	private Long orderContactTypeId;
	private boolean expediteOrder=false;
	private String orderFlagValue;
	private Character expedite='N';
}
