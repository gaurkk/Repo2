package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EVENT_STATUS")
public class EventStatus implements Serializable {

	private static final long serialVersionUID = -5989893673994752897L;
	private Long eventStatusId;
	private String eventStatusDec;
	private List<ExternalInterfaceDetails> lstExtIntDetails = new ArrayList<ExternalInterfaceDetails>();

	/**
	 * @return the eventStatusId
	 */
	@Id
	@Column(name = "EVENT_STATUS_ID", unique = true, nullable = false, precision = 4, scale = 0)
	public Long getEventStatusId() {
		return eventStatusId;
	}

	/**
	 * @param eventStatusId the eventStatusId to set
	 */
	public void setEventStatusId(Long eventStatusId) {
		this.eventStatusId = eventStatusId;
	}

	/**
	 * @return the eventStatusDec
	 */
	@Column(name = "EVENT_STATUS_DESC", nullable = false, length = 100)
	public String getEventStatusDec() {
		return eventStatusDec;
	}

	/**
	 * @param eventStatusDec the eventStatusDec to set
	 */
	public void setEventStatusDec(String eventStatusDec) {
		this.eventStatusDec = eventStatusDec;
	}

	/**
	 * @return the lstExtIntDetails
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "eventStatus")
	public List<ExternalInterfaceDetails> getLstExtIntDetails() {
		return lstExtIntDetails;
	}

	/**
	 * @param lstExtIntDetails the lstExtIntDetails to set
	 */
	public void setLstExtIntDetails(List<ExternalInterfaceDetails> lstExtIntDetails) {
		this.lstExtIntDetails = lstExtIntDetails;
	}
}
