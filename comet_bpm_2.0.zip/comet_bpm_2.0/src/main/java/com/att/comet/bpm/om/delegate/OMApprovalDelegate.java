package com.att.comet.bpm.om.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.om.service.OMApprovalService;

@Component
public class OMApprovalDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OMApprovalDelegate.class);

	@Autowired
	private OMApprovalService omApprovalService;

	@Autowired
	private CommonService commonService;

	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {

			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType.trim()) {
				case BpmConstant.OM_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.APPROVED_BY_OM:
					approvedByOM(execution);
					break;
				case BpmConstant.REJECTED_BY_OM:
					rejectedByOM(execution);
					break;
				default:
					logger.info("Comet request does not have::" + "valid task", this);
				}
			} else {
				logger.info("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OM_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	/**
	 * OM APPROVAL PREOPERATION
	 * 
	 * @param execution
	 * @throws CamundaServiceException
	 * @throws RecordNotFoundException
	 */
	private void preOperation(DelegateExecution execution) throws CamundaServiceException, RecordNotFoundException {
		logger.info("Start preOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable("orderId");
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.COMET_OM_APPROVAL_OM001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1003L);// Setting OSD roleID
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1011L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL,bpmUrl.getNew_url()+commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
				execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");// User task
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setRoleId(1003L);// Setting OM roleID
				commonBO.setTaskStatusId(1001L);// OM Task Id//Creation
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setTaskId(1011L);// Mapped from BPM_task table (OM : Approval Task)
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
				commonBO.setUpdatedOn(new Date());											// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				// ALL CRUD PREOPERATION for OM Approval
				omApprovalService.preOperation(commonBO, execution.getProcessInstanceId());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				
			}
		} else {
			logger.error("Comet request does not have::" ,
					this);
		}
		logger.info("End preOperation method ::", this);
	}

	/**
	 * OM APPROVAL POST OPERATION FOR APPROVAL
	 * 
	 * @param execution
	 * @throws Exception
	 */
	private void approvedByOM(DelegateExecution execution) throws Exception {
		logger.info("Start approvedByOM method ::", this);
		Long orderId = 0L;
		String processType = null;
		CommonBO commonBO = null;
		try {
			// value fetch from COMET FRONTEND by Assign USER
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			if (null != orderId || null != processType) {
				// commonBO = commonService.getCommonBO(orderId);
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					// OrderUserTaskFaults
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OM_ERR_APPROVED_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1003L);// Setting OSD roleID
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1011L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
					omApprovalService.approvedByOM(commonBO, execution);
					// setting for email subject
					commonBO.setTaskDescription("Request for Order ID -" + commonBO.getOrderId() + " with APN -"
							+ commonBO.getApnName() + "  " + "for Account - " + commonBO.getAccountName()
							+ "- Approved by Order Manager");
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.RESPONSE,commonBO.getApproved());
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OM_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End approvedByOM method ::", this);
	}

	/**
	 * OM APPROVAL POST OPERATION FOR REJECTED
	 * 
	 * @param execution
	 * @throws Exception
	 */
	private void rejectedByOM(DelegateExecution execution) throws Exception {
		logger.info("Start rejectedByOM method ::", this);
		Long orderId = 0L;
		CommonBO commonBO = null;
		try {
			// value fetch from COMET FRONTEND by Assign USER
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			if (null != orderId) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					
					omApprovalService.rejectedByOM(commonBO, execution);
					// OrderUserTaskFaults
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OM_ERR_REJECTED_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1003L);// Setting OSD roleID
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1011L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				}
				execution.setVariable(BpmConstant.REJECTED_BY, 1003L);
				// setting for email subject
				commonBO.setTaskDescription("Order Manager has rejected the request for - Order ID -"
						+ commonBO.getOrderId() + " with APN -" + commonBO.getApnName() + "  for Account - "
						+ commonBO.getAccountName());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.RESPONSE,commonBO.getApproved());
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OM_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End rejectedByOM method ::", this);
	}
}
