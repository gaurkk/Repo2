package com.att.comet.bpm.oa.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusStepHistoryDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusinessStepDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.OrderStatusHistoryDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OAApprovalHelper {
	private static final Logger logger = LoggerFactory.getLogger(OAApprovalHelper.class);
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	private BpmOrderWorkStepDAO bpmOrderWorkStepDAO;
	@Autowired
	private OrderStatusHistoryDAO orderStatusHistoryDAO;
	@Autowired
	private OrderTypeRepository orderTypeRepository;
	@Autowired
	private BpmOrderBusinessStepDAO bpmOrderBusinessStepDAO;
	@Autowired
	private BpmOrderBusStepHistoryDAO bpmOrderBusStepHistoryDAO;
	@Autowired
	private OrderContactInfoDAO orderContactInfoDAO;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;

	public void oaPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method oaPreOprCRUD", this);
		Long orderTypeId;
		commonBO.setBpmProcessInstanceId(processInstanceId);
		bpmDAO.deleteBpmOrderProcessByOrderIdAndProcessId(commonBO);

		/* INSERT record into BPM_ORDER_PROCESS */
		orderTypeId = orderTypeRepository.getOrderTypeId(commonBO.getOrderTypeName());
		commonBO.setOrderTypeId(orderTypeId);
		commonBO.setProcessId(1001L);
		commonBO.setBpmStatusId(1001L);

		bpmDAO.saveBpmOrderProcessForOrderIdAndOrderTypeId(commonBO);

		/* INSERT record into AVOS_Process_Instances */
		commonBO.setBpmProcessId(1001L);//OA APPROVAL PROCESS
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

		/* UPDATE record into Orders */
		commonBO.setOrderStatusId(1004L);
		orderDAO.saveOrderStatusIdByOrderId(commonBO);

		/* UPDATE record into Audit_Orders */
		auditDAO.saveOrderStatusIdByOrderId(commonBO);

		// Deleting BpmOrderBusinessstep record for business stepids(3001,3039,3040)
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3001L);
		businessStepIdList.add(3039L);
		businessStepIdList.add(3040L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* Deleting record from BPM_Order_Work_Step */
		commonBO.setWorkStepId(1001L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		/* Inserting record into BPM_Order_Work_Step */
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);

		List<Long> workStepIdList = new ArrayList<>();
		workStepIdList.add(1001L);
		commonBO.setWorkStepIdList(workStepIdList);
		
		logger.debug("All Set for OA Approval for OrderId ::" + commonBO.getOrderId(), this);
		logger.info("@Ending method oaPreOprCRUD ", this);
	}

	public void oaAppovedOprCRUD(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method oaAppovedOprCRUD ", this);
		Boolean User_or_group_exist = false;
		String assigneeOA = null;
		String assigneeOS = null;
		/* Get User_or_group, count, CRcount as per legacy implementation */
		Long count = orderDAO.countOrderEvent(commonBO);
		String crCountValue = "CR-00" + count;
		commonBO.setCrCountValue(crCountValue);
		
		commonBO.setOrderContactTypeId(1004L);
		assigneeOA = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOA)) {
			User_or_group_exist = true;
			commonBO.setAssignee(assigneeOA);
			commonBO.setOrderApprover(assigneeOA);
		}
		/* Get OA Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assigneeOA);
			commonBO.setOaEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOaEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
		}

		// email to be sent to OA as TO in Notification , Reminder 1 , Reminder 2
		commonBO.setToEmail(commonBO.getOaEmail());

		/* Get OS Email details */
		commonBO.setOrderContactTypeId(1003L);
		assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOS)) {
			commonBO.setUser_or_group(assigneeOS);
			commonBO.setOsEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		/* Get Admin Email details */
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));
	
		//IN case of commonBO.getToEmail()) is null
		if(null==commonBO.getToEmail()) {
			if(null==commonBO.getOsEmail()) {
			commonBO.setToEmail(commonBO.getAdminEmail());
			}else {
				commonBO.setToEmail(commonBO.getOsEmail());
			}
		}
		
		// email to be sent to OS and Admin as CC in Reminder 2
		if(null!=commonBO.getOsEmail()) {
			commonBO.setCcEmail((commonBO.getOsEmail() + "," + commonBO.getAdminEmail()));
		}else {
			commonBO.setCcEmail((commonBO.getAdminEmail()));
		}
		

		/* Set Reminder1 & Reminder2 SLA Dates for OA */
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForOA(commonBO);
		logger.info("@Ending method oaAppovedOprCRUD ", this);
	}

	/**
	 * OA approval POST CRUD
	 * 
	 * @param commonBO
	 */
	public void oaPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method oaPostOprCRUD ", this);

		String response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOaComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOaComments);

		String assignee = null;
		commonBO.setOrderContactTypeId(1004L);

		assignee = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assignee);
		commonBO.setAttuid(assignee);
		commonBO.setOrderApprover(assignee);

		commonBO.setOrderStatusId(1002L);
		orderStatusHistoryDAO.saveOshByOrderIdAndOsIdUpdatedBy(commonBO);

		commonBO.setBusinessStepId(3001L);
		bpmOrderBusinessStepDAO.saveBpmOrderBusinessStepForOrderIdAndOaDetails(commonBO);

		bpmOrderBusStepHistoryDAO.saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(commonBO);
		//commonBO.setBpmStepId(1002L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1001L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setUpdatedOn(new Date());
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		//bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);

		if (commonBO.getApproved().equalsIgnoreCase(BpmConstant.APPROVED)) {
			commonBO.setResponseHTAction("Order Review (OA) - Approved");
		} else {
			commonBO.setResponseHTAction("Order Review (OA) - Rejected");
		}
		commonBO.setRoleId(1002L);
		updatingCommentsForOAApprovedOrRejected(commonBO);//
		logger.info("@Ending method oaPostOprCRUD ", this);
	}

	/**
	 * Updating OA Approver Comment
	 * 
	 * @param commonBO
	 */
	private void updatingCommentsForOAApprovedOrRejected(CommonBO commonBO) throws CamundaServiceException{
		/// Need to check order Type from Initial FE request from Main delegate
		if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_REQUEST)) {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			commonBO.setOrderProcess("New");
			commonBO.setOrderProcess(commonBO.getCrCountValue());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_ORDER)) {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected::" + commonBO.getOrderOperation(),
					this);
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else {
			logger.info("@Starting method updatingCommentsForOAApprovedOrRejected ::" + commonBO.getOrderOperation(),
					this);
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		}
	}

	/**
	 * OA Rejection
	 * 
	 * @param commonBO
	 */
	public void oaRejectedOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method oaRejectedOprCRUD ", this);

		String  response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOaComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOaComments);
		commonBO.setOrderStatusId(1006L);
		orderDAO.updateOrders(commonBO);

		orderDAO.saveOrderStatusHistory(commonBO);

		commonBO.setBusinessStepId(3102L);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		auditDAO.updateAuditOrders(commonBO);


		commonBO.setResponseHTAction("Order Update (OA) - Completed for OA Rejection");

		updatingCommentsForOAApprovedOrRejected(commonBO);

		commonBO.setOrderStatusId(1006L);
		orderStatusHistoryDAO.saveOshByOrderIdAndOsIdUpdatedBy(commonBO);

		// EMAIL WORK TODO
		commonBO.setWorkStepId(1001L);
		bpmOrderWorkStepDAO.deleteBpmOrderWorkStepForOrderIdAndWorkStepId(commonBO);

		bpmDAO.deleteBpmOrderProcessbyOrderProcessName(commonBO);

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		logger.info("@Ending method oaRejectedOprCRUD ", this);
	}

}
