package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for StaticRoute. Mapped to STATIC_ROUTE table in the
 * database.
 */
@Entity
@Table(name = "STATIC_ROUTE")
public class StaticRoute implements java.io.Serializable {

	private static final long serialVersionUID = -6803804159905959217L;

	private Long staticRouteId;
	private Long backhaulId;
	private String ipAddress;
	private String mask;
	private Backhaul backhaul;

	/**
	 * Getter method for staticRouteId. STATIC_ROUTE_ID mapped to
	 * STATIC_ROUTE_ID in the database table. The id is generated using the
	 * sequence SEQ_STATIC_ROUTE_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "STATIC_ROUTE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_STATIC_ROUTE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_STATIC_ROUTE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_STATIC_ROUTE_ID")
	public Long getStaticRouteId() {
		return staticRouteId;
	}

	/**
	 * @param staticRouteId
	 *            to staticRouteId set.
	 */
	public void setStaticRouteId(Long staticRouteId) {
		this.staticRouteId = staticRouteId;
	}

	/**
	 * Getter method for backhaulId. BACKHAUL_ID mapped to BACKHAUL_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BACKHAUL_ID", nullable = false, precision = 12, scale = 0)
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	/**
	 * Getter method for ipAddress. IP_ADDRESS mapped to IP_ADDRESS in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * @param ipAddress
	 *            to ipAddress set.
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Getter method for mask. MASK mapped to MASK in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MASK", length = 100)
	public String getMask() {
		return this.mask;
	}

	/**
	 * @param mask
	 *            to mask set.
	 */
	public void setMask(String mask) {
		this.mask = mask;
	}

	/**
	 * Getter method for backhaul.
	 * 
	 * @return Backhaul
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BACKHAUL_ID", nullable = false, insertable = false, updatable = false)
	public Backhaul getBackhaul() {
		return this.backhaul;
	}

	/**
	 * @param backhaul
	 *            to backhaul set.
	 */
	public void setBackhaul(Backhaul backhaul) {
		this.backhaul = backhaul;
	}
}