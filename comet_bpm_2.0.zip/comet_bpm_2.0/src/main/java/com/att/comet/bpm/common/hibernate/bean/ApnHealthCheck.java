/**
 * Created For Req#6.2.01
 */
package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "APN_HELTHCHECK")
public class ApnHealthCheck  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	Long orderId;
	private Apn apn;	
	private Character helthChkenable;	
	private String helthChkType;
	private Long helthChkFrequency;		

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "apn"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	
	/**
	 * Getter method for apn. ORDER_ID mapped to ORDER_ID of the database table.
	 * 
	 * @return Apn
	 */
	
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 * to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	@Column(name = "HELTHCHECK_ENABLE", length = 1)
	public Character getHelthChkenable() {
		return helthChkenable;
	}

	public void setHelthChkenable(Character helthChkenable) {
		this.helthChkenable = helthChkenable;
	}

	@Column(name = "HELTHCHECK_TYPE", length = 30)
	public String getHelthChkType() {
		return helthChkType;
	}

	public void setHelthChkType(String helthChkType) {
		this.helthChkType = helthChkType;
	}
	@Column(name = "HELTHCHECK_FREQUENCY", precision = 12, scale = 0)
	public Long getHelthChkFrequency() {
		return helthChkFrequency;
	} 

	public void setHelthChkFrequency(Long helthChkFrequency) {
		this.helthChkFrequency = helthChkFrequency;
	}

}
