package com.att.comet.bpm.common.exception;

import static org.camunda.bpm.engine.impl.util.EnsureUtil.ensureNotEmpty;

import org.camunda.bpm.engine.delegate.BpmnError;

public class CamundaBpmnError extends BpmnError {
	
	private static final long serialVersionUID = 7747244935295278336L;
	
	private String errorCode;
	
	private String errorMessage;

	public CamundaBpmnError(String errorCode) {
		super("");
		setErrorCode(errorCode);
	}

	public CamundaBpmnError(String errorCode, String message) {
		super(message + " (errorCode='" + errorCode + "')");
		setErrorCode(errorCode);
		setMessage(message);
	}

	protected void setErrorCode(String errorCode) {
		ensureNotEmpty("Error Code", errorCode);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String toString() {
		return super.toString() + " (errorCode='" + errorCode + "')";
	}

	protected void setMessage(String errorMessage) {
		ensureNotEmpty("Error Message", errorMessage);
		this.errorMessage = errorMessage;
	}

	public String getMessage() {
		return errorMessage;
	}

}
