package com.att.comet.bpm.iwos.delegate;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class CRAPNHLRIWOSCompletionDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(CRAPNHLRIWOSCompletionDelegate.class);

	@Autowired
	CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	CommonServiceHelper commonServiceHelper;

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (operationType != null) {
				switch (operationType) {
				case BpmConstant.CHECK_USERDECESION:
					checkUserDecesion(execution);
					break;
				case BpmConstant.COMPLETE_PROCESS:
					completeProcess(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			throw new CamundaServiceException("NO INPUT FOUND FOR NEXT FLOW STEPS");
		}
	}

	private void completeProcess(DelegateExecution execution) throws CamundaServiceException, URISyntaxException {
		logger.info("Start completeProcess method ::", this);
		Long orderId = (Long) execution.getVariable("orderId");
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String bpmStatusId = (String) execution.getVariable("bpmStatusId");
		String userDecision = (String) execution.getVariable("userDecision");
		CommonBO commonBO = null;
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
			}
			if (commonBO != null) {
				commonBO.setTaskId(1015L);
				commonServiceHelper.taskCompletedService(commonBO, execution);
				//commonBO.setTerminateTask(isTerminated);

				execution.setVariable("isTerminated", commonBO.isTerminateTask());
				execution.setVariable("orderOperation", orderOperation);
				execution.setVariable("commonBO", commonBO);
				execution.setVariable("orderId", orderId);
				execution.setVariable("apnName", commonBO.getApnName());
			}
		} catch (CamundaServiceException e) {
			execution.setVariable("ERROR_CODE", "ErrorCodeConstant.COMET_MB001");
			throw new CamundaServiceException("In proper request from comet app");
		}
		logger.info("End completeProcess method ::", this);
	}

	private void checkUserDecesion(DelegateExecution execution) throws CamundaServiceException {

		logger.info("Start checkUserDecesion method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		String userDecision = null;
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			commonBO = (CommonBO) execution.getVariable("commonBO");
			if (null == commonBO) {
				commonBO = commonService.getCommonBO(orderId);
			}
			if (commonBO != null) {
				commonBO.setWorkStepId(1064L);// NETWORK IWOS SUSPENSION / COMPLETION TASK(Mapped from bpm_work_step)
				commonBO.setOrderOperation(orderOperation);
				userDecision = commonService.findUserDecision(commonBO);
				if (null != userDecision) {
					execution.setVariable(BpmConstant.USER_DECISION, userDecision);
				} else {
					execution.setVariable(BpmConstant.USER_DECISION, "na");
				}
			if (commonBO != null) {
				// fetching process status
				BpmTask bpmTask = new BpmTask();
				Orders order = new Orders();
				commonBO.setTaskId(1015L);
				bpmTask.setTaskId(commonBO.getTaskId());
				order.setOrderId(orderId);
				String taskStatusName = null;
				List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
					if (null != taskObj) {
						if ((taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()))) {
							taskStatusName = taskObj.getTaskStatus().getTaskStatusDesc();
							if (CommonUtils.isNotNullEmpty(taskStatusName)) {
								logger.info("taskStatusName :: " + taskStatusName);
								if (taskStatusName.equalsIgnoreCase("CREATED")) {
									commonBO.setTaskStatusName(taskStatusName);
									break;
								}
							}

						} else {
							logger.info("taskStatusName is null for orderId ::  " + commonBO.getOrderId()
									+ " for the task :: " + commonBO.getTaskId());
						}
					}
				}
				commonBO.setOrderOperation(orderOperation);
				execution.setVariable("bpmStatusName", taskStatusName);
				execution.setVariable("commonBO", commonBO);
			}
			}
		} catch (CamundaServiceException e) {
			execution.setVariable("ERROR_CODE", "ErrorCodeConstant.COMET_MB001");
			throw new CamundaServiceException("In proper request from comet app");
		}
	}

}
