package com.att.comet.bpm.codashboard.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderTypeRepository;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class OABillingCancellationServiceImpl implements OABillingCancellationService {
	private static final Logger logger = LoggerFactory.getLogger(OABillingCancellationServiceImpl.class);

	@Autowired
	GenericDAO genericDAO;
	@Autowired
	UserDAO userDAO;
	@Autowired
	BpmDAO bpmDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	AuditDAO auditDAO;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;

	@Override
	public void preOperationOABilling(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("@Starting method preOperationOABilling", this);

		commonBO.setUpdatedOn(new Date());
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3222L);
		businessStepIdList.add(3223L);
		businessStepIdList.add(3224L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		List<Object[]> detailsBillingDataList = orderDAO.getBillingData(commonBO);

		for (Object[] detailsBillingData : detailsBillingDataList) {
			commonBO.setAccountName(detailsBillingData[0] != null ? detailsBillingData[0].toString() : "N/A");
			commonBO.setCompanyBillingAddress(detailsBillingData[1] != null ? detailsBillingData[1].toString() : "N/A");
			commonBO.setCompanyContactNamePhone(detailsBillingData[2] != null ? detailsBillingData[2].toString() : "N/A");
			commonBO.setFederalTaxID(detailsBillingData[3] != null ? detailsBillingData[3].toString() : "N/A");
			commonBO.setBan(detailsBillingData[4] != null ? detailsBillingData[4].toString() : "N/A");
			commonBO.setFan(detailsBillingData[5] != null ? detailsBillingData[5].toString() : "N/A");
			commonBO.setAccountManager(detailsBillingData[6] != null ? detailsBillingData[6].toString() : "N/A");
			commonBO.setMobilityTechnicalEngineer(detailsBillingData[7] != null ? detailsBillingData[7].toString() : "N/A");
			commonBO.setApnName(detailsBillingData[11] != null ? detailsBillingData[11].toString() : "N/A");
			commonBO.setPdpName(detailsBillingData[12] != null ? detailsBillingData[12].toString() :"N/A");
			commonBO.setSourceofIPAddressing(detailsBillingData[13] !=null ? detailsBillingData[13].toString() : "N/A");
			commonBO.setTypeofAddressing(detailsBillingData[14] !=null ? detailsBillingData[14].toString() : "N/A");
			commonBO.setBackHaulIds(detailsBillingData[15] !=null ? detailsBillingData[15].toString() : "N/A");
			commonBO.setBackhaulInstances(detailsBillingData[16] !=null ? detailsBillingData[16].toString() : "N/A");
			commonBO.setMplscir(detailsBillingData[17] !=null ? detailsBillingData[17].toString() : "N/A");
			commonBO.setEodOrder(detailsBillingData[19] !=null ? detailsBillingData[19].toString() : "N/A");
			commonBO.setFeeWaiverApproved(detailsBillingData[20] !=null ? detailsBillingData[20].toString() : "N/A");
			commonBO.setManagedAVPN(detailsBillingData[21] !=null ? detailsBillingData[21].toString() : "N/A");
		}

		commonBO.setOrderContactTypeId(1004L); // ORDER_CONTACT_Type table , ORDER_CONTACT_TYPE_NAME = Order
		List<String> osdEmailList = null;
		// fetching dynamic user from order_contact_info table

		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderAprover = attUidList.get(0);
			commonBO.setAttuid(orderAprover);
			commonBO.setAssignee(orderAprover);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1002L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		}
		// COMET Admin Email List
		commonBO.setRoleId(1002L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All
		}
		// SLA
		// select cast(SLA_Working_Day(TIMESTAMP '2020-06-09 20:45:50',1157) as
		// timestamp(3))targetSLADate from dual
		// select cast(SLA_Working_Day(TIMESTAMP '2020-06-09 20:45:50',1158) as
		// timestamp(3))targetSLADate from dual

		// update bpm_order_work_step
		commonBO.setWorkStepId(1080L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayForOABilling(commonBO);
		
	}

	@Override
	public void operationOABillingTask(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method operationOABillingTask", this);
		commonBO.setTaskName("CancelOABillingTask");
		commonBO.setTaskDisplayName("OA : Cancel Billing Request – Submission)");
		orderDAO.saveOrderBillingTask(commonBO);
		logger.info("@Ending method operationOABillingTask", this);

	}

	@Override
	public void postOperationOABilling(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("@Starting method postOperationOABilling", this);
		// save order business step
		commonBO.setBusinessStepId(3222L);
		commonBO.setBusinessStepStatus("Submitted");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm work step
		commonBO.setWorkStepId(1080L);
		commonBO.setBpmStatusId(1002L);
		commonBO.setUpdatedOn(new Date());
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		

		orderDAO.updateOrderBillingTask(commonBO);
	}

}
