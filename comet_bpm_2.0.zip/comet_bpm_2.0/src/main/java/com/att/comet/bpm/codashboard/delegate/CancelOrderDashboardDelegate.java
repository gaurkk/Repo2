package com.att.comet.bpm.codashboard.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.codashboard.service.CODashboardService;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.crdashboard.service.CRProcessService;

@Component
public class CancelOrderDashboardDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(CancelOrderDashboardDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	CODashboardService coDashboardService;
	public static final String URL_NAME = "SEARCH_ORDER_URL";
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.CO_DASHBOARD_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.CO_DASHBOARD_POST_OPERATION:
					postOperation(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.CO_DASHBOARD_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}

	}

	private void preOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperation method ::", this);
		CommonBO commonBO = null;
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.CO_DASHBOARD_ERR_PRE_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1038L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO = commonService.getCommonBO(orderId);
			if (null != commonBO) {
				BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setRoleId(1005L);// Setting OA roleID
				commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setTaskId(1038L);// Mapped from BPM_task table (CO Dashboard Task)
				commonBO.setTaskStatusName("Cancel_Order_Task");
				commonBO.setOrderOperation(orderOperation);
				coDashboardService.preOperation(commonBO, execution.getProcessInstanceId());
				execution.setVariable("taskStatus", commonBO.getBusinessStepStatus());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "CO PREOPERATION SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "CO PREOPERATION SERVICE EXCEPTION");

		}

	}

	private void postOperation(DelegateExecution execution) {
		logger.info("Start postOperation method ::", this);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		String CCSPMComments = (String) execution.getVariable(BpmConstant.COMMENTS);

		if (null != commonBO) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.CO_DASHBOARD_ERR_POST_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1038L);
			orderUserTaskFaultsBO.setOrderId(commonBO.getOrderId());// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			try {
				commonBO.setComments(CCSPMComments);
				coDashboardService.postOperation(commonBO, execution);

				commonBO.setTaskCompletionTime(new Date());
				commonBO.setCategoryId(1003L);// Service
				commonBO.setTaskStatusId(1002L);
				commonBO.setTaskId(1038L);
				commonBO.setRoleId(1005L);
				commonService.updateOrderUserBpmTasksRepository(commonBO);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable("uiTaskStatus", commonBO.getBusinessStepStatus());
			} catch (CamundaServiceException e) {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
						this);
				throw new BpmnError("ERROR_BPM_001", "CO POSTOPERATION SERVICE EXCEPTION");
			}

		}
		logger.info("Existing postOperation method ::", this);

	}

}
