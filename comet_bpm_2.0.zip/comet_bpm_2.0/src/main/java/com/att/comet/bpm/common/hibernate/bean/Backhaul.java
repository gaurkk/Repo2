package com.att.comet.bpm.common.hibernate.bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent Class for Back-haul. Mapped with the BACKHAUL table in the
 * database.
 */
@Entity
@Table(name = "BACKHAUL")
public class Backhaul implements java.io.Serializable {

	private static final long serialVersionUID = 941645110548647643L;
	private Long backhaulId;
	private BackhaulType backhaulType;
	private Set<OrderDataCenterBackhaul> orderDataCenterBackhauls = new HashSet<OrderDataCenterBackhaul>(
			0);
	private Bgp bgp;
	private Set<StaticRoute> staticRoutes = new HashSet<StaticRoute>(0);
	private Mpls mpls;
	private InternetVpn internetVpn;
	private Users createdBy;
	private Users updatedBy;
	private Date createdOn;
	private Date updatedOn;
	private String backhaulDisplayId;
	private String status;
	private Long derivedFromBackhaul;
	@Column(name = "OWNER")
	private Long owner;

	/**
	 * Getter method for the value of the back-haul id which is generated using
	 * a sequence. BACKHAUL_ID mapped to BACKHAUL_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "BACKHAUL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_BACKHAUL_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_BACKHAUL_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_BACKHAUL_ID")
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	/**
	 * Getter method for the backhaulType. Here the mapping is many to one with
	 * BACKHAUL_TYPE_ID.
	 * 
	 * @return BackhaulType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BACKHAUL_TYPE_ID", nullable = false)
	public BackhaulType getBackhaulType() {
		return this.backhaulType;
	}

	/**
	 * @param backhaulType
	 *            to backhaulType set.
	 */
	public void setBackhaulType(BackhaulType backhaulType) {
		this.backhaulType = backhaulType;
	}

	/**
	 * Getter method for orderDataCenterBackhauls. Mapped by the back-haul and
	 * the mapping style is one to many.
	 * 
	 * @return Set<OrderDataCenterBackhaul>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "backhaul")
	public Set<OrderDataCenterBackhaul> getOrderDataCenterBackhauls() {
		return this.orderDataCenterBackhauls;
	}

	/**
	 * @param orderDataCenterBackhauls
	 *            to orderDataCenterBackhauls set.
	 */
	public void setOrderDataCenterBackhauls(
			Set<OrderDataCenterBackhaul> orderDataCenterBackhauls) {
		this.orderDataCenterBackhauls = orderDataCenterBackhauls;
	}

	/**
	 * Getter method for Bgp.
	 * 
	 * @return Bgp
	 */
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "backhaul")
	public Bgp getBgp() {
		return this.bgp;
	}

	/**
	 * @param bgp
	 *            to Bgp set.
	 */
	public void setBgp(Bgp bgp) {
		this.bgp = bgp;
	}

	/**
	 * Getter method for staticRoutes. Mapped by Back-haul in one to one
	 * mapping.
	 * 
	 * @return Set<StaticRoute>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "backhaul")
	public Set<StaticRoute> getStaticRoutes() {
		return this.staticRoutes;
	}

	/**
	 * @param staticRoutes
	 *            to staticRoutes set.
	 */
	public void setStaticRoutes(Set<StaticRoute> staticRoutes) {
		this.staticRoutes = staticRoutes;
	}

	/**
	 * Getter method for Mpls.
	 * 
	 * @return Mpls
	 */
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "backhaul")
	public Mpls getMpls() {
		return this.mpls;
	}

	/**
	 * @param mpls
	 *            to mpls set.
	 */
	public void setMpls(Mpls mpls) {
		this.mpls = mpls;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON")
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn
	 *            to createdOn.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for the updatedOn. UPDATED_ON mapped to UPDATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn
	 *            to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for createdBy. CREATED_BY mapped to CREATED_BY in the
	 * database table.
	 * 
	 * @return Users.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATED_BY", updatable = false)
	public Users getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 *            to createdBy set.
	 */
	public void setCreatedBy(Users createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter method for updatedBy. UPDATED_BY mapped to UPDATED_BY in the
	 * database table.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UPDATED_BY", nullable = false)
	public Users getUpdatedBy() {
		return this.updatedBy;
	}

	/**
	 * @param updatedBy
	 *            to updatedBy set.
	 */
	public void setUpdatedBy(Users updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Getter method for internetVpn.
	 * 
	 * @return InternetVpn
	 */
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "backhaul")
	public InternetVpn getInternetVpn() {
		return this.internetVpn;
	}

	/**
	 * @param internetVpn
	 *            to internetVpn set.
	 */
	public void setInternetVpn(InternetVpn internetVpn) {
		this.internetVpn = internetVpn;
	}

	/**
	 * Getter method for backhaulDisplayId BACKHAUL_DISPLAY_ID mapped to
	 * BACKHAUL_DISPLAY_ID in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BACKHAUL_DISPLAY_ID", length = 100)
	public String getBackhaulDisplayId() {
		return this.backhaulDisplayId;
	}

	/**
	 * @param backhaulDisplayId
	 *            to backhaulDisplayId.
	 */
	public void setBackhaulDisplayId(String backhaulDisplayId) {
		this.backhaulDisplayId = backhaulDisplayId;
	}

	/**
	 * Getter method for status. STATUS mapped to STATUS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "STATUS", length = 100, nullable = false)
	public String getStatus() {
		return this.status;
	}

	/**
	 * @param status
	 *            to status set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter method for derivedFromBackhaul. DERIVED_FROM_BACKHAUL mapped to
	 * DERIVED_FROM_BACKHAUL in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "DERIVED_FROM_BACKHAUL")
	public Long getDerivedFromBackhaul() {
		return derivedFromBackhaul;
	}

	/**
	 * @param derivedFromBackhaul
	 *            to derivedFromBackhaul set.
	 */
	public void setDerivedFromBackhaul(Long derivedFromBackhaul) {
		this.derivedFromBackhaul = derivedFromBackhaul;
	}
	
	public Long getOwner() {
		return owner;
	}

	public void setOwner(Long owner) {
		this.owner = owner;
	}
}