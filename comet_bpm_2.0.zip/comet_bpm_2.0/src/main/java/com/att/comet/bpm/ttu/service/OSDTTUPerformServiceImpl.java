package com.att.comet.bpm.ttu.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class OSDTTUPerformServiceImpl implements OSDTTUPerformService {
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUPerformServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;

	@Override
	public void preOperationOSDTTUPerform(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperationOSDTTUPerform");

		List<String> osdEmailList = null;
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1023L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			commonBO.setAssignee(orderSubmitter);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
		}
		// delete bpm_order_work_step
		List<Long> workStepIdList = new ArrayList<Long>();
		workStepIdList.add(1023L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3074L);
		businessStepIdList.add(3075L);
		businessStepIdList.add(3076L);
		businessStepIdList.add(3077L);
		businessStepIdList.add(3028L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		if (commonBO.getOrderOperation().equalsIgnoreCase("NEW_ORDER")) {
			commonBO.setWorkStepId(1023L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1023L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {
			
			commonBO.setWorkStepId(1023L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		// reminders
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUPerformStatus(commonBO);

		/*
		 * SLA Calculation select cast(SLA_Working_Day(TIMESTAMP '2020-04-08
		 * 08:21:42',1044) as timestamp(3))targetSLADate from dual select
		 * cast(SLA_Working_Day(TIMESTAMP '2020-04-08 08:21:42',1045) as
		 * timestamp(3))targetSLADate from dual
		 */

	}

	@Override
	public void postOperationOSDTTUPerform(CommonBO commonBO, String OSDComments, String ttuPerformedOrRescheduled)
			throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationOSDTTUPerform");
		String actorName = null;
		if (!StringUtils.isEmpty(OSDComments)) {
			commonBO.setComments(OSDComments);
		} else {
			commonBO.setComments("N/A");
		}
		if (ttuPerformedOrRescheduled.equalsIgnoreCase("YES")) {
			commonBO.setBusinessStepValue("YES");
		} else {
			commonBO.setBusinessStepValue("RESCHEDULED");
		}
		/* fetching order submiiter from order_contact_info table */
		commonBO.setOrderContactTypeId(1023L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			actorName = attUidList.get(0);
			commonBO.setAttuid(actorName);
		}
		// update bpm_order_work_step
		commonBO.setBusinessStepId(3028L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		commonBO.setWorkStepId(1023L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1023L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

	}

}
