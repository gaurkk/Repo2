package com.att.comet.bpm.common.dao.impl;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrdersRepository;

@Component
public class AuditDAOImpl implements AuditDAO {
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Override
	public void saveOrderStatusIdByOrderId(CommonBO commonBO) throws CamundaServiceException{
		ordersRepository.updateOrderStatusIdByOrderId(commonBO.getOrderId(), commonBO.getOrderStatusId());
	}
	
	@Override
	public void updateAuditOrders(CommonBO commonBO) throws CamundaServiceException {
		String sql = "update audit_orders set order_status_id=:order_status_id where order_id=:order_id";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("order_status_id", commonBO.getOrderStatusId());
		query.setParameter("order_id", commonBO.getOrderId());
		query.executeUpdate();

	}

	@Override
	public int getMaxEventId(Long orderId) {
		String sql = "select max(event_id) from audit_orders where order_id=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		return query.getFirstResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAuditOrders(CommonBO commonBO, int eventId) {
		String sql = "SELECT\r\n" + "NVL(oa.ban_id,'N/A') as billing_account_number,\r\n"
				+ "NVL(oa.fan_id,'N/A') as foundation_account_number,\r\n"
				+ "(select name from audit_order_contact_info where order_contact_type_id = '1001' and order_contact_id = (select order_contact_id from audit_order_contact where order_id=? and event_id =?) and event_id =?) as account_manager,\r\n"
				+ "(select u.firstname || ' ' || u.lastname  || ' (' || u.attuid || ')' from audit_order_contact_info aoci, users u where aoci.order_contact_type_id = '1003' and aoci.order_contact_id = (select order_contact_id from audit_order_contact where order_id=? and event_id =?) and aoci.attuid = u.attuid and event_id =?) as mobility_tech_engg,\r\n"
				+ "o.order_id as order_id ,\r\n" + "o.order_type_id as order_type_id ,\r\n"
				+ "NVL(NVL(apn.apn_name,da.apn_name),'N/A') AS APN_Name ,\r\n"
				+ "NVL(pdp.auto_pdp_name, NVL(NVL(pdp.user_pdp_name,da.pdp_name),'N/A')) AS PDP_Name ,\r\n"
				+ "NVL(apn.ip_address_source,'N/A') as sorce_of_ip_addressing,\r\n"
				+ "NVL(apn.address_type,'N/A') as type_of_addressing,\r\n"
				+ "NVL((select LISTAGG(b.backhaul_display_id, ', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from audit_order_dc_backhaul odc, audit_backhaul b where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id and o.event_id = b.event_id and o.event_id = odc.event_id),'N/A') AS Backhaul_Id,\r\n"
				+ "NVL ((select LISTAGG(odc.backhaul_selection, ', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from audit_order_dc_backhaul odc, audit_backhaul b where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id and o.event_id = b.event_id and o.event_id = odc.event_id),'N/A') AS backhaul_instance,\r\n"
				+ "NVL (( select LISTAGG(mpls.mpls_cir,', ') WITHIN GROUP (ORDER BY odc.order_id,odc.backhaul_id) from audit_mpls mpls, audit_backhaul b,audit_order_dc_backhaul odc where odc.order_id = o.order_id\r\n"
				+ "and odc.backhaul_id = b.backhaul_id and mpls.backhaul_id = b.backhaul_id and o.event_id = b.event_id and o.event_id = odc.event_id and o.event_id = mpls.event_id),'N/A') AS mpls_cir,\r\n"
				+ "NVL(to_char(o.bcid),o.cipn) AS account_id_cipn ,\r\n"
				+ "NVL(case when oa.eod_enabled = 'Y' then 'Yes' else 'No' end,'No') as EOD,\r\n"
				+ "case when oa.fee_waiver_approved = 'Y' then 'Yes' else 'No' end as fee_waiver_approved,\r\n"
				+ "NVL(case when apn.managed_avpn = 'Y' then 'Yes' else 'No' end,'No') as managed_avpn\r\n"
				+ "FROM audit_orders o ,\r\n" + "audit_apn apn ,\r\n" + "audit_dedicated_apn da ,\r\n"
				+ "audit_pdp_id_info pdp ,\r\n" + "audit_order_account oa\r\n" + "WHERE o.order_id =?\r\n"
				+ "AND o.event_id =?\r\n" + "AND o.event_id = apn.event_id (+)\r\n"
				+ "AND o.event_id = da.event_id(+)\r\n" + "AND o.event_id = pdp.event_id (+)\r\n"
				+ "AND o.event_id = oa.event_id\r\n" + "";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, eventId);
		query.setParameter(3, eventId);
		query.setParameter(4, commonBO.getOrderId());
		query.setParameter(5, eventId);
		query.setParameter(6, eventId);
		query.setParameter(7, commonBO.getOrderId());
		query.setParameter(8, eventId);
		return query.getResultList();
	}

}
