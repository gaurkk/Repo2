package com.att.comet.bpm.iwos.service;

import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.iwos.helper.APNHLRIWOSCreationHelper;

@Service
public class APNHLRIWOSCreationServiceImpl implements APNHLRIWOSCreationService {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCreationServiceImpl.class);
	@Autowired
	private APNHLRIWOSCreationHelper apnhlriwosCreationHelper;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	CommonService commonService;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;

	@Override
	public void preOperationIWOSCreation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlriwosCreationHelper.preOperationIWOSCreation(commonBO);
	}

	@Override
	public void postOperationIWOSCreation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlriwosCreationHelper.postOperationIWOSCreation(commonBO);
		commonBO.setProcessId(1024L);//APN HLR IWOS PROCESS
		commonBO.setBpmProcessId(1024L);//APN HLR IWOS PROCESS
		Orders order = new Orders();
		order.setOrderId(commonBO.getOrderId());
		if (null != commonBO.getOrderTypeId() && commonBO.getOrderTypeId() == 1004L) {
			execution.setVariable("pcrfFlagValue", "Y");
		} else {
			execution.setVariable("pcrfFlagValue", "N");
		}
		
		commonBO.setTaskId(1060L);
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
					if (taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						commonBO.setBpmTaskId(taskObj.getBpmTaskId());
						commonBO.setTaskDescription(taskObj.getSubject());
						commonBO.setAttuid(taskObj.getAttuid());
						commonBO.setProcessId(taskObj.getProcessId());
						commonBO.setProcessInstanceId(taskObj.getProcessInstanceId());
						break;
					} else {
						logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId()
								+ " for the task :: " + commonBO.getTaskId());
					}
				}
		}
		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1005L);// CCS PM Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		//commonBO.setTaskId(1014L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		
		Long crCount = orderDAO.countOrderEvent(commonBO);
		if (null != crCount && crCount.equals(1L)) {
			logger.info("@@@ Pick Operation for Change Request @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
		}else if(commonBO.getOrderTypeId().equals(1004L)){
			logger.info("@@@ Pick Operation for Change Order @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
			
		}else {
			logger.info(" @@@ No Change Request created against the order id :::  @@@  "+commonBO.getOrderId(), this);
		}
	}

}
