package com.att.comet.bpm.decom.apnhlr.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface APNHLRDecomService {

	void preOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

}
