package com.att.comet.bpm.apniwos.service;

import java.text.ParseException;
import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ApnIwosCompletionService {
	void preOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException;
	void postOperationIWOSCom_Sus(CommonBO commonBO, String CCSPMComments, String iwosTicketCometionDate, String IWOSTicketResponse) throws CamundaServiceException, ParseException;
	void postOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException;
	
}
