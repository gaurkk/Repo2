package com.att.comet.bpm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStepId;


@Repository
public interface BpmOrderBusinessStepRepository extends JpaRepository<BpmOrderBusinessStep, BpmOrderBusinessStepId> {
	@Query(value="select comments from BpmOrderBusinessStep b where b.id=:id")
	List<String>  findBpmOrderBusinessStepComments(BpmOrderBusinessStepId id);
	
	@Query(value="select businessStepStatus from BpmOrderBusinessStep b where b.id=:id")
    String findBpmOrderBusinessStepStatus(BpmOrderBusinessStepId id);

}
