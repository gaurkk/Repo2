package com.att.comet.bpm.common.exception;

public class CamundaServiceException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CamundaServiceException(String message) {
		super(message);
	}

}