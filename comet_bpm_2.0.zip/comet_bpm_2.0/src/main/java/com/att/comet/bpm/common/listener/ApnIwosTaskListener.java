package com.att.comet.bpm.common.listener;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Session;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.EmailTemplateHelper;
import com.att.comet.bpm.common.hibernate.bean.TaskInfo;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.EmailTemplateBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.repository.TaskDataRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.EmailUtil;
import com.att.comet.bpm.config.CometYamlPropertySourceFactory;
import com.att.comet.bpm.oa.helper.OAApprovalHelper;

@Component
@Configuration
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class ApnIwosTaskListener implements TaskListener {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosTaskListener.class);
	@Autowired
	OAApprovalHelper oaApprovalHelper;
	@Autowired
	EmailUtil emailUtil;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	TaskDataRepository taskDataRepository;
	@Autowired
	CommonService commonService;
	@Autowired
	EmailTemplateHelper emailTemplateHelper;

	// get smtpm server
	@Value("${comet.email.smtp-server}")
	private String smtp_server;
	// Smpt port
	@Value("${comet.email.smtp-port}")
	private String smtp_port;
	// smtp-host
	@Value("${comet.email.smtp-host}")
	private String smtp_host;

	@Override
	public void notify(DelegateTask delegateTask) {
		CommonBO commonBO = (CommonBO) delegateTask.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			commonBO.setEmailNotificationId(1002L);// Mail Notification ID 1002 from TASK_DISPLAY_TYPE table
			delegateTask.setVariable("emailReminder1", commonBO.getReminder1SlaDate());
			delegateTask.setVariable("emailReminder2", commonBO.getReminder2SlaDate());
			commonBO.setTaskCreationTime(delegateTask.getCreateTime());
			commonBO.setTaskDescription(delegateTask.getDescription());
			commonBO.setBpmTaskId(delegateTask.getId());
			delegateTask.setAssignee(commonBO.getIwosAssignee());
			try {
				setEmailNotification(commonBO);
			} catch (Exception e1) {
				logger.error("@ EMAIL sender error:" + e1.getMessage() + "", this);
			}
			// Preparing data for update Comet DB ORDER USER BPM TASK TABLE
			try {
				commonBO.setAssignee(delegateTask.getAssignee());
				commonService.updateOrderUserBpmTasksRepository(commonBO);
			} catch (CamundaServiceException e) {
				logger.error("@NOT ABLE TO STORE ON COMET DB ORDER USER BPM TASK::" + e.getMessage() + "", this);
			}
		}
	}

	private void setEmailNotification(CommonBO commonBO) throws CamundaServiceException, Exception {
		logger.info("@Starting method setOAPreOprEmailTemplate ", this);
		EmailTemplateBO emailTemplateBO = new EmailTemplateBO();
		TaskInfo taskInfo = null;
		taskInfo = emailTemplateHelper.getTaskInfo(commonBO.getTaskId(), commonBO.getEmailNotificationId());
		if (null != taskInfo) {
			emailTemplateBO.setToEmail(commonBO.getToEmail());
			//emailTemplateBO.setCcEmail(commonBO.getCcEmail());
			emailTemplateBO.setTaskDataId(String.valueOf(commonBO.getBpmTaskId()));
			emailTemplateBO.setSubject(taskInfo.getSubject() + ":" + commonBO.getTaskDescription());

			emailTemplateBO.setHeaderSection(taskInfo.getHeaderSection());// Dear
			emailTemplateBO.setSubHeaderSection(taskInfo.getSubHeaderSection());

			emailTemplateBO.setBodySection1(taskInfo.getBodySection1());
			emailTemplateBO.setBodySection2(taskInfo.getBodySection2());
			emailTemplateBO.setBodySection3(taskInfo.getBodySection3());

			emailTemplateBO.setFooterSection(taskInfo.getFooterSection());

			emailTemplateBO.setApnName(commonBO.getApnName());
			emailTemplateBO.setOrderId(commonBO.getOrderId());
			if (BpmConstant.NEW_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("New");
			} else if (BpmConstant.CHANGE_REQUEST.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Change Request");
			} else if (BpmConstant.CHANGE_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Change Order");
			} else if (BpmConstant.CANCEL_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Cancel Order");
			} else if (BpmConstant.DECOMMISSION_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType("Decommission");
			} else if (BpmConstant.ONHOLD_ORDER.equals(commonBO.getOrderOperation())) {
				emailTemplateBO.setOrderType(commonBO.getOrderTypeName() != null ? commonBO.getOrderTypeName() : "");
			}
			emailTemplateBO.setPdpName(commonBO.getPdpName());
			emailTemplateBO.setBackHaulName(commonBO.getBackHaulIds());
			emailTemplateBO.setAccountId(commonBO.getAccountClassId());
			emailTemplateBO.setAccountName(commonBO.getAccountName());
			emailTemplateBO.setBpmUrl(commonBO.getUrlName());
			emailTemplateBO.setEodOrder(commonBO.getEodOrder());
			emailTemplateBO.setFeeWaiverApproved(commonBO.getFeeWaiverApproved());
			emailTemplateBO.setCompanyBillingAddress(commonBO.getCompanyBillingAddress());
			emailTemplateBO.setCompanyContactNamePhone(commonBO.getCompanyContactNamePhone());
			emailTemplateBO.setFederalTaxID(commonBO.getFederalTaxID());
			emailTemplateBO.setBan(commonBO.getBan());
			emailTemplateBO.setFan(commonBO.getFan());
			emailTemplateBO.setAccountManager(commonBO.getAccountManager());
			emailTemplateBO.setMobilityTechnicalEngineer(commonBO.getMobilityTechnicalEngineer());
			emailTemplateBO.setSourceofIPAddressing(commonBO.getSourceofIPAddressing());
			emailTemplateBO.setTypeofAddressing(commonBO.getTypeofAddressing());
			emailTemplateBO.setBackhaulInstances(commonBO.getBackhaulInstances());
			emailTemplateBO.setMplscir(commonBO.getMplscir());
			emailTemplateBO.setManagedAVPN(commonBO.getManagedAVPN());
			emailTemplateBO.setOnHoldRequestedDate(commonBO.getOnHoldRequestedDate());
			emailTemplateBO.setOnHoldProposedCompletionDate(commonBO.getOnHoldProposedCompletionDate());
			emailTemplateBO.setOnHoldReason(commonBO.getOnHoldReason());
			emailTemplateBO.setOnHoldNotes(commonBO.getOnHoldNotes());
			Map<String, Object> model = taskCreationEmailFormat(emailTemplateBO, commonBO);
			// EMAIL SENDER CLASS INVOKING
			Properties props = System.getProperties();
			props.put(smtp_host, smtp_server);// will update later from YML
			Session session = Session.getInstance(props, null);

			emailUtil.sendEmail(session, emailTemplateBO, model);
		}

		logger.info("@Ending method setOAPreOprEmailTemplate ", this);
	}

	private Map<String, Object> taskCreationEmailFormat(EmailTemplateBO emailTemplateBO, CommonBO commonBO) {
		Map<String, Object> model = new HashMap<>();
		model.put("HeaderSection", emailTemplateBO.getHeaderSection());
		model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());

		if (commonBO.getTaskId() == 1012L) {
			String orderData = emailTemplateBO.getSubHeaderSection();
			orderData = orderData.replace(EmailUtil.rejectionComments, commonBO.getComments() + "\n");
			model.put("SubHeaderSection", orderData);
		} else if (commonBO.getTaskId() == 1013L) {
			String orderData = emailTemplateBO.getSubHeaderSection();
			orderData = orderData.replace(EmailUtil.rejectionComments, commonBO.getComments() + "\n");
			model.put("SubHeaderSection", orderData);
		} else {
			model.put("SubHeaderSection", emailTemplateBO.getSubHeaderSection());
		}

		String taskStm = emailTemplateBO.getBodySection1();// task
		Boolean found = Arrays.asList(taskStm.split(" ")).contains(EmailUtil.taskIdVar);
		if (found.booleanValue()) {
			taskStm = taskStm.replace(EmailUtil.taskIdVar, emailTemplateBO.getTaskDataId());
		}
		model.put("taskStm", taskStm);
		String orderData = null;
		if (commonBO.getTaskId() == 1051L || commonBO.getTaskId() == 1052L || commonBO.getTaskId() == 1053L) {// billing
																												// BPM
																												// TASK
			orderData = emailTemplateBO.getBodySection2();
			if (emailTemplateBO.getOrderId() != null) {
				orderData = orderData.replace(EmailUtil.orderIdVar, emailTemplateBO.getOrderId() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.orderIdVar, "N/A" + "\n");
			}
			if (emailTemplateBO.getOrderType() != null) {
				orderData = orderData.replace(EmailUtil.orderTypeVar, emailTemplateBO.getOrderType() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.orderTypeVar, "N/A" + "\n");
			}
			if (emailTemplateBO.getApnType() != null) {
				orderData = orderData.replace(EmailUtil.apnType, emailTemplateBO.getApnType() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.apnType, "N/A" + "\n");
			}
			if (emailTemplateBO.getIPType() != null) {
				orderData = orderData.replace(EmailUtil.iPType, emailTemplateBO.getIPType() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.iPType, "N/A" + "\n");
			}
			if (emailTemplateBO.getIfStatic() != null) {
				orderData = orderData.replace(EmailUtil.ifStatic, emailTemplateBO.getIfStatic() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.ifStatic, "N/A" + "\n");
			}
			if (emailTemplateBO.getMrc() != null) {
				orderData = orderData.replace(EmailUtil.mrc, emailTemplateBO.getMrc() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.mrc, "N/A" + "\n");
			}
			if (emailTemplateBO.getEricssonCode() != null) {
				orderData = orderData.replace(EmailUtil.ericssonCode, emailTemplateBO.getEricssonCode() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.ericssonCode, "N/A" + "\n");
			}
			if (emailTemplateBO.getApnName() != null) {
				orderData = orderData.replace(EmailUtil.apnNameVar, emailTemplateBO.getApnName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.apnNameVar, "N/A" + "\n");
			}
			if (emailTemplateBO.getPdpName() != null) {
				orderData = orderData.replace(EmailUtil.pdpNameVar, emailTemplateBO.getPdpName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.pdpNameVar, "N/A" + "\n");
			}
			if (emailTemplateBO.getUserDefinedPDPID() != null) {
				orderData = orderData.replace(EmailUtil.userDefinedPDPID, emailTemplateBO.getUserDefinedPDPID() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.userDefinedPDPID, "N/A" + "\n");
			}
			if (emailTemplateBO.getCometPdpId() != null) {
				orderData = orderData.replace(EmailUtil.cometPdpId, emailTemplateBO.getCometPdpId() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.cometPdpId, "N/A" + "\n");
			}
			if (emailTemplateBO.getCompanyName() != null) {
				orderData = orderData.replace(EmailUtil.companyName, emailTemplateBO.getCompanyName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.companyName, "N/A" + "\n");
			}
			if (emailTemplateBO.getUltimateAccountName() != null) {
				orderData = orderData.replace(EmailUtil.ultimateAccountName,
						emailTemplateBO.getUltimateAccountName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.ultimateAccountName, "N/A" + "\n");
			}
			if (emailTemplateBO.getMaterAccountID() != null) {
				orderData = orderData.replace(EmailUtil.materAccountID, emailTemplateBO.getMaterAccountID() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.materAccountID, "N/A" + "\n");
			}
			if (emailTemplateBO.getAccountName() != null) {
				orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.accountName, "N/A" + "\n");
			}
			if (emailTemplateBO.getAccountId() != null) {
				orderData = orderData.replace(EmailUtil.accountIdVar, emailTemplateBO.getAccountId() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.accountIdVar, "N/A" + "\n");
			}
			if (emailTemplateBO.getAgreementAccountName() != null) {
				orderData = orderData.replace(EmailUtil.agreementAccountName,
						emailTemplateBO.getAgreementAccountName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.agreementAccountName, "N/A" + "\n");
			}
			if (emailTemplateBO.getAgreementAccountNumber() != null) {
				orderData = orderData.replace(EmailUtil.agreementAccountNumber,
						emailTemplateBO.getAgreementAccountNumber() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.agreementAccountNumber, "N/A" + "\n");
			}
			if (emailTemplateBO.getFan() != null) {
				orderData = orderData.replace(EmailUtil.fan, emailTemplateBO.getFan() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.fan, "N/A" + "\n");
			}
			if (emailTemplateBO.getPdpPackageName() != null) {
				orderData = orderData.replace(EmailUtil.pdpPackageName, emailTemplateBO.getPdpPackageName() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.pdpPackageName, "N/A" + "\n");
			}
			if (emailTemplateBO.getPdpPackageDesc() != null) {
				orderData = orderData.replace(EmailUtil.pdpPackageDesc, emailTemplateBO.getPdpPackageDesc() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.pdpPackageDesc, "N/A" + "\n");
			}
			if (emailTemplateBO.getPdpDescription() != null) {
				orderData = orderData.replace(EmailUtil.pdpDescription, emailTemplateBO.getPdpDescription() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.pdpDescription, "N/A" + "\n");
			}
		} else {
			orderData = emailTemplateBO.getBodySection2();
			orderData = orderData.replace(EmailUtil.orderIdVar, emailTemplateBO.getOrderId() + "\n");
			orderData = orderData.replace(EmailUtil.orderTypeVar, emailTemplateBO.getOrderType() + "\n");
			orderData = orderData.replace(EmailUtil.apnNameVar, emailTemplateBO.getApnName() + "\n");
			orderData = orderData.replace(EmailUtil.pdpNameVar, emailTemplateBO.getPdpName() + "\n");
			orderData = orderData.replace(EmailUtil.backHaulVar, emailTemplateBO.getBackHaulName() + "\n");
			orderData = orderData.replace(EmailUtil.accountIdVar, emailTemplateBO.getAccountId() + "\n");
			orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName());

			if (commonBO.getTaskId() == 1020L || commonBO.getTaskId() == 1030L) {// billing BPM TASK
				orderData = orderData.replace(EmailUtil.eodOrder, emailTemplateBO.getEodOrder() + "\n");
				orderData = orderData.replace(EmailUtil.feeWaiverApproved,
						emailTemplateBO.getFeeWaiverApproved() + "\n");
				orderData = orderData.replace(EmailUtil.companyBillingAddress,
						emailTemplateBO.getCompanyBillingAddress() + "\n");
				orderData = orderData.replace(EmailUtil.companyContactNamePhone,
						emailTemplateBO.getCompanyContactNamePhone() + "\n");
				orderData = orderData.replace(EmailUtil.federalTaxID, emailTemplateBO.getFederalTaxID() + "\n");
				orderData = orderData.replace(EmailUtil.ban, emailTemplateBO.getBan() + "\n");
				orderData = orderData.replace(EmailUtil.fan, emailTemplateBO.getFan() + "\n");
				orderData = orderData.replace(EmailUtil.accountManager, emailTemplateBO.getAccountManager() + "\n");
				orderData = orderData.replace(EmailUtil.mobilityTechnicalEngineer,
						emailTemplateBO.getMobilityTechnicalEngineer() + "\n");
				orderData = orderData.replace(EmailUtil.sourceofIPAddressing,
						emailTemplateBO.getSourceofIPAddressing() + "\n");
				orderData = orderData.replace(EmailUtil.typeofAddressing, emailTemplateBO.getTypeofAddressing() + "\n");
				orderData = orderData.replace(EmailUtil.backhaulInstances,
						emailTemplateBO.getBackhaulInstances() + "\n");
				orderData = orderData.replace(EmailUtil.mplscir, emailTemplateBO.getMplscir() + "\n");
				orderData = orderData.replace(EmailUtil.managedAVPN, emailTemplateBO.getManagedAVPN());
			} else if (commonBO.getTaskId() == 1046L) { // On Hold Request Task
				orderData = orderData.replace(EmailUtil.onHoldRequestedDate,
						emailTemplateBO.getOnHoldRequestedDate() + "\n");
				orderData = orderData.replace(EmailUtil.onHoldProposedCompletionDate,
						emailTemplateBO.getOnHoldProposedCompletionDate() + "\n");
				orderData = orderData.replace(EmailUtil.onHoldReason, emailTemplateBO.getOnHoldReason() + "\n");
				orderData = orderData.replace(EmailUtil.onHoldNotes, emailTemplateBO.getOnHoldNotes() + "\n");
			} else {
				orderData = orderData.replace(EmailUtil.accountName, emailTemplateBO.getAccountName());
			}
		}

		model.put("orderData", orderData);

		String moreOrderDetails = emailTemplateBO.getBodySection3();
		moreOrderDetails = moreOrderDetails.replace(EmailUtil.pleaseClick, commonBO.getWorkFlowUrl());
		model.put("moreOrderDetails", moreOrderDetails);
		model.put("footer", emailTemplateBO.getFooterSection());

		return model;
	}
}


