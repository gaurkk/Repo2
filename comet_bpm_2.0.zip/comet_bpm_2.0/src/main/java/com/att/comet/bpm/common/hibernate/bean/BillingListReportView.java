package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BILLING_LIST_REPORT_VIEW")
public class BillingListReportView implements Serializable {
	private static final long serialVersionUID = 5511213860615436088L;
	private Long orderId;
	private String taskId;
	private String dateBillingCreation;
	private String dateBillingComplete;
	private String orderType;
	private String orderStatus;
	private String accountClass;
	private String dateApnInProduction;
	private String masterAccountName;
	private String accountName;
	private String companyBillingAddress;
	private String contactName;
	private Long contactPhone;
	private String federalTaxId;
	private String salesContact;
	private String newBackhaulInstance;
	private String existingBackhaulInstance;
	private String os;
	private String oa;
	private String dateSubmitted;
	private String dateOaApproved;
	private Long refOrderId;
	private String expedite;
	private String fanId;
	private String banId;
	private String eod;
	private String eodBlu;
	private String feewaiverAccount;
	private String feewaiverOrder;
	private String managedAvpn;
	private String apnName;
	private String pdpName;
	private String backhaulTypes;
	private String ipAddressSource;
	private String addressType;

	@Id
	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "TASK_ID")
	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	@Column(name = "DATE_BILLING_CREATION")
	public String getDateBillingCreation() {
		return dateBillingCreation;
	}

	public void setDateBillingCreation(String dateBillingCreation) {
		this.dateBillingCreation = dateBillingCreation;
	}

	@Column(name = "DATE_BILLING_COMPLETE")
	public String getDateBillingComplete() {
		return dateBillingComplete;
	}

	public void setDateBillingComplete(String dateBillingComplete) {
		this.dateBillingComplete = dateBillingComplete;
	}

	@Column(name = "ORDER_TYPE")
	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Column(name = "ORDER_STATUS")
	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Column(name = "ACCOUNT_CLASS")
	public String getAccountClass() {
		return accountClass;
	}

	public void setAccountClass(String accountClass) {
		this.accountClass = accountClass;
	}

	@Column(name = "DATE_APN_IN_PRODUCTION")
	public String getDateApnInProduction() {
		return dateApnInProduction;
	}

	public void setDateApnInProduction(String dateApnInProduction) {
		this.dateApnInProduction = dateApnInProduction;
	}

	@Column(name = "MASTER_ACCOUNT_NAME")
	public String getMasterAccountName() {
		return masterAccountName;
	}

	public void setMasterAccountName(String masterAccountName) {
		this.masterAccountName = masterAccountName;
	}

	@Column(name = "ACCOUNT_NAME")
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Column(name = "COMPANY_BILLING_ADDRESS")
	public String getCompanyBillingAddress() {
		return companyBillingAddress;
	}

	public void setCompanyBillingAddress(String companyBillingAddress) {
		this.companyBillingAddress = companyBillingAddress;
	}

	@Column(name = "CONTACT_NAME")
	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	@Column(name = "CONTACT_PHONE")
	public Long getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(Long contactPhone) {
		this.contactPhone = contactPhone;
	}

	@Column(name = "FEDERAL_TAX_ID")
	public String getFederalTaxId() {
		return federalTaxId;
	}

	public void setFederalTaxId(String federalTaxId) {
		this.federalTaxId = federalTaxId;
	}

	@Column(name = "SALES_CONTACT")
	public String getSalesContact() {
		return salesContact;
	}

	public void setSalesContact(String salesContact) {
		this.salesContact = salesContact;
	}

	@Column(name = "NEW_BACKHAUL_INSTANCE")
	public String getNewBackhaulInstance() {
		return newBackhaulInstance;
	}

	public void setNewBackhaulInstance(String newBackhaulInstance) {
		this.newBackhaulInstance = newBackhaulInstance;
	}

	@Column(name = "EXISTING_BACKHAUL_INSTANCE")
	public String getExistingBackhaulInstance() {
		return existingBackhaulInstance;
	}

	public void setExistingBackhaulInstance(String existingBackhaulInstance) {
		this.existingBackhaulInstance = existingBackhaulInstance;
	}

	@Column(name = "OS")
	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	@Column(name = "OA")
	public String getOa() {
		return oa;
	}

	public void setOa(String oa) {
		this.oa = oa;
	}

	@Column(name = "DATE_SUBMITTED")
	public String getDateSubmitted() {
		return dateSubmitted;
	}

	public void setDateSubmitted(String dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}

	@Column(name = "DATE_OA_APPROVED")
	public String getDateOaApproved() {
		return dateOaApproved;
	}

	public void setDateOaApproved(String dateOaApproved) {
		this.dateOaApproved = dateOaApproved;
	}

	@Column(name = "REF_ORDER_ID")
	public Long getRefOrderId() {
		return refOrderId;
	}

	public void setRefOrderId(Long refOrderId) {
		this.refOrderId = refOrderId;
	}

	@Column(name = "EXPEDITE")
	public String getExpedite() {
		return expedite;
	}

	public void setExpedite(String expedite) {
		this.expedite = expedite;
	}

	@Column(name = "FAN_ID")
	public String getFanId() {
		return fanId;
	}

	public void setFanId(String fanId) {
		this.fanId = fanId;
	}

	@Column(name = "BAN_ID")
	public String getBanId() {
		return banId;
	}

	public void setBanId(String banId) {
		this.banId = banId;
	}

	@Column(name = "EOD")
	public String getEod() {
		return eod;
	}

	public void setEod(String eod) {
		this.eod = eod;
	}

	@Column(name = "EOD_BLU")
	public String getEodBlu() {
		return eodBlu;
	}

	public void setEodBlu(String eodBlu) {
		this.eodBlu = eodBlu;
	}

	@Column(name = "FEE_WAIVER_ACCOUNT")
	public String getFeewaiverAccount() {
		return feewaiverAccount;
	}

	public void setFeewaiverAccount(String feewaiverAccount) {
		this.feewaiverAccount = feewaiverAccount;
	}

	@Column(name = "FEE_WAIVER_ORDER")
	public String getFeewaiverOrder() {
		return feewaiverOrder;
	}

	public void setFeewaiverOrder(String feewaiverOrder) {
		this.feewaiverOrder = feewaiverOrder;
	}

	@Column(name = "MANAGED_AVPN")
	public String getManagedAvpn() {
		return managedAvpn;
	}

	public void setManagedAvpn(String managedAvpn) {
		this.managedAvpn = managedAvpn;
	}

	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}

	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	@Column(name = "PDP_NAME")
	public String getPdpName() {
		return pdpName;
	}

	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	@Column(name = "BACKHAUL_TYPES")
	public String getBackhaulTypes() {
		return backhaulTypes;
	}

	public void setBackhaulTypes(String backhaulTypes) {
		this.backhaulTypes = backhaulTypes;
	}

	@Column(name = "IP_ADDRESS_SOURCE")
	public String getIpAddressSource() {
		return ipAddressSource;
	}

	public void setIpAddressSource(String ipAddressSource) {
		this.ipAddressSource = ipAddressSource;
	}

	@Column(name = "ADDRESS_TYPE")
	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

}
