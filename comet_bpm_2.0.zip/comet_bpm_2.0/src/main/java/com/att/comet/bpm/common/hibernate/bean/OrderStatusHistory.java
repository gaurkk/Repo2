package com.att.comet.bpm.common.hibernate.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderStatusHistory. Mapped to ORDER_STATUS_HISTORY table
 * in the database.
 */
@Entity
@Table(name = "ORDER_STATUS_HISTORY")
public class OrderStatusHistory implements java.io.Serializable {

	private static final long serialVersionUID = -4282550360444828081L;

	private Long orderStatusHistoryId;
	private OrderStatus orderStatus;
	private Users users;
	private Orders orders;
	private Date updatedOn;
	private String comments;

	/**
	 * No-argument constructor of the class.
	 */
	public OrderStatusHistory() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderStatusHistoryId
	 * @param orderStatus
	 * @param users
	 * @param orders
	 * @param updatedOn
	 */
	public OrderStatusHistory(Long orderStatusHistoryId,
			OrderStatus orderStatus, Users users, Orders orders, Date updatedOn) {
		this.orderStatusHistoryId = orderStatusHistoryId;
		this.orderStatus = orderStatus;
		this.users = users;
		this.orders = orders;
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for orderStatusHistoryId. ORDER_STATUS_HISTORY_ID mapped to
	 * ORDER_STATUS_HISTORY_ID in the database table. The sequence for the
	 * generation of the orderStatusHistoryId is SEQ_ORDER_STATUS_HISTORY_ID
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_STATUS_HISTORY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_STATUS_HISTORY_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ORDER_STATUS_HISTORY_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_STATUS_HISTORY_ID")
	public Long getOrderStatusHistoryId() {
		return this.orderStatusHistoryId;
	}

	/**
	 * @param orderStatusHistoryId
	 *            to orderStatusHistoryId set.
	 */
	public void setOrderStatusHistoryId(Long orderStatusHistoryId) {
		this.orderStatusHistoryId = orderStatusHistoryId;
	}

	/**
	 * Getter method for orderStatus.
	 * 
	 * @return OrderStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_STATUS_ID", nullable = false)
	public OrderStatus getOrderStatus() {
		return this.orderStatus;
	}

	/**
	 * @param orderStatus
	 *            to orderStatus set.
	 */
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * Getter method for users.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UPDATED_BY", nullable = false)
	public Users getUsers() {
		return this.users;
	}

	/**
	 * @param users
	 *            to users set.
	 */
	public void setUsers(Users users) {
		this.users = users;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn
	 *            to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 2000)
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

}
