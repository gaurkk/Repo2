package com.att.comet.bpm.common.dao.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmOrderBusStepHistoryDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class BpmOrderBusStepHistoryDAOImpl implements BpmOrderBusStepHistoryDAO{

	private static final Logger logger = LoggerFactory.getLogger(BpmOrderBusStepHistoryDAOImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(CommonBO commonBO) throws CamundaServiceException{
		logger.info("@Starting saveBpmOrderBusStepHistoryForOrderIdAndOaDetails", this);
		Date today = new Date();
		String sql = "insert into bpm_order_bus_step_history (order_id, business_step_id, order_type_id, business_step_status, comments, business_step_executed_on, created_on, updated_on) values(:orderId,:businessStepId,(select order_type_id from order_type where lower(order_type.order_type_name)=lower(:orderType)),:ReviewResponse,:OrderManagerComments,:sysDateTime,:sysDateTime,:sysDateTime)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("businessStepId", commonBO.getBusinessStepId());
		query.setParameter("orderType", commonBO.getOrderTypeName());
		query.setParameter("ReviewResponse", commonBO.getApproved());//Approved(true) Rejected(false)
		query.setParameter("OrderManagerComments", commonBO.getComments());
		query.setParameter("sysDateTime", today);
		query.executeUpdate();
		logger.info("@Ending saveBpmOrderBusStepHistoryForOrderIdAndOaDetails", this);
	}
}
