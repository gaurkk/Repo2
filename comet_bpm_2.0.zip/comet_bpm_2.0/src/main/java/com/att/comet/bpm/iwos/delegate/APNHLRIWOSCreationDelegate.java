package com.att.comet.bpm.iwos.delegate;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.iwos.service.APNHLRIWOSCreationService;

@Component
public class APNHLRIWOSCreationDelegate implements JavaDelegate {

	@Autowired
	APNHLRIWOSCreationService apnHLRIWOSCreationService;

	@Autowired
	CommonService commonService;

	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCreationDelegate.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (operationType != null) {
				switch (operationType) {
				case BpmConstant.CHECK_ORDER_STATUS:
					checkOrderStatus(execution);
					break;
				case BpmConstant.PRE_OPERATION_IWOS_CREATION:
					preOperationIWOSCreation(execution);
					break;
				case BpmConstant.POST_OPERATION_IWOS_CREATION:
					postOperationIWOSCreation(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(APN_HLR_IWOS_CREATION_BPM_ERROR_CODE should be same for delegate and
			 * BPMN mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.APN_HLR_IWOS_CREATION_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void checkOrderStatus(DelegateExecution execution) throws RecordNotFoundException, CamundaServiceException {
		logger.info("Start checkOrderStatus method ::", this);
		Map<String, Object> variables = execution.getVariables();
		Long orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		String orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		String camundaApnIwosProcessInstanceId = execution.getProcessInstanceId();
		CommonBO commonBO = null;
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable("commonBO");
				execution.setVariable("orderType", orderOperation);// set on above method
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					String orderStatus = commonBO.getOrderStatusName();
					commonBO.setBpmProcessInstanceId(camundaApnIwosProcessInstanceId);
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable("commonBO", commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable("orderStatus", orderStatus);

					} else {
						logger.error("Order Status name for  ," + "ORDER_ID::[" + orderId + "]  is null", this);
					}
					// ccspmNetworkIWOSCreationService.postOperationNetworkIWOSCreation(commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TO GET ORDER STATUS"));
		}
		logger.info("End checkOrderStatus method ::", this);
	}

	private void postOperationIWOSCreation(DelegateExecution execution)
			throws CamundaServiceException, RecordNotFoundException, ParseException {

		logger.info("Start postOperationIWOSCreation method ::", this);
		Long orderId = 0L;
		CommonBO commonBO = null;
		String comments = null;
		String iwosTicketNum = null;
		String orderOperation = null;
		boolean isTerminateTask = false;
		String ticketCreateDate=null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		if (orderId != null && orderOperation != null) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_HLR_IWOS_CREATION_ERR_POST_001);// APN_HLR_IWOS_CREATION_ERR_POST_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1014L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			commonBO = variables.get("commonBO") != null ? (CommonBO) variables.get("commonBO") : null;
			if (null != commonBO) {
				comments = variables.get(BpmConstant.COMMENTS) != null ? (String) variables.get(BpmConstant.COMMENTS)
						: null;
				iwosTicketNum = variables.get(BpmConstant.TICKET_NUM) != null
						? (String) variables.get(BpmConstant.TICKET_NUM)
						: null;
						ticketCreateDate =variables.get(BpmConstant.TICKET_CREATION_DATE) != null
								? (String) variables.get(BpmConstant.TICKET_CREATION_DATE)
								: null;
				commonBO.setComments(comments);
				commonBO.setTicketNum(iwosTicketNum);
				commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(ticketCreateDate));
				apnHLRIWOSCreationService.postOperationIWOSCreation(commonBO, execution);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}

		logger.info("End postOperationIWOSCreation method ::", this);
	}

	private void preOperationIWOSCreation(DelegateExecution execution)
			throws CamundaServiceException, RecordNotFoundException {

		logger.info("Start preOperationIWOSCreation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		if (orderId != null && CommonUtils.isNotNullEmpty(orderOperation)) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_HLR_IWOS_CREATION_ERR_PRE_001);// APN_HLR_IWOS_CREATION_ERR_PRE_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1014L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			commonBO = variables.get("commonBO") != null ? (CommonBO) variables.get("commonBO") : null;
			if (null == commonBO) {
				commonBO = commonService.getCommonBO(orderId);
			}

			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url() + commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
				execution.setVariable(BpmConstant.PROCESS_TYPE, commonBO.getOrderTypeName());
				execution.setVariable("orderTypeId", commonBO.getOrderTypeId());
				if (null != commonBO.getOrderTypeId() && commonBO.getOrderTypeId() == 1004L) {
					execution.setVariable("pcrfFlagValue", "Y");
					// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
					commonBO.setTaskStatusName("CCSPM_APN_IWOS_Create_PCRF_Task");// Mapped from TASK_DATA table
				} else {
					execution.setVariable("pcrfFlagValue", "N");
					// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Creation)
					commonBO.setTaskStatusName("CCSPM_HLR_LTE_PCRF_Create_Task");// Mapped from TASK_DATA table
				}
				commonBO.setTaskId(1060L);
				execution.setVariable("bpmStatusId", commonBO.getTaskStatusName());
				execution.setVariable("userDecision", commonBO.getTaskUserDecision());
				execution.setVariable("orderOperation", orderOperation);
				commonBO.setActivityInstanceId(execution.getActivityInstanceId());
				commonBO.setWorkFlowUrl(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setRoleId(1005L);// CCS PM Role Id
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setTaskStatusId(1001L);// User Task Status CREATED Id
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
				commonBO.setUpdatedOn(new Date());											// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				execution.setVariable("commonBO", commonBO);
				apnHLRIWOSCreationService.preOperationIWOSCreation(commonBO, execution);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}
		logger.info("End preOperationIWOSCreation method ::", this);
	}

}
