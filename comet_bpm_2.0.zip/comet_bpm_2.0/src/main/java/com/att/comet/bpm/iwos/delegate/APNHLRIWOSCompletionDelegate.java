package com.att.comet.bpm.iwos.delegate;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.iwos.service.APNHLRIWOSCompletionService;

@Component
public class APNHLRIWOSCompletionDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCreationDelegate.class);

	@Autowired
	APNHLRIWOSCompletionService apnHLRIWOSCompletionService;

	@Autowired
	CommonService commonService;

	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (operationType != null) {
				switch (operationType) {
				case BpmConstant.PRE_OPERATION_IWOS_COMPLETION:
					preOperationIWOSCompletion(execution);
					break;
				case BpmConstant.POST_OPERATION_IWOS_COMPLETION:
					postOperationIWOSCompletion(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(APN_HLR_IWOS_COMPLETION_BPM_ERROR_CODE should be same for delegate and
			 * BPMN mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.APN_HLR_IWOS_COMPLETION_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void postOperationIWOSCompletion(DelegateExecution execution)
			throws RecordNotFoundException, CamundaServiceException, ParseException {

		logger.info("Start postOperationIWOSCompletion method ::", this);
		Long orderId = 0L;
		CommonBO commonBO = null;
		String comments = null;
		String iwosTicketNum = null;
		String completedDate = null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		if (orderId != null) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_HLR_IWOS_COMPLETION_ERR_POST_001);// APN_HLR_IWOS_COMPLETION_ERR_POST_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1015L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Completion)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO = variables.get(BpmConstant.COMMON_BO) != null ? (CommonBO) variables.get(BpmConstant.COMMON_BO)
					: null;
			if (null != commonBO) {

				iwosTicketNum = variables.get(BpmConstant.TICKET_NUM) != null
						? (String) variables.get(BpmConstant.TICKET_NUM)
						: null;
				comments = variables.get(BpmConstant.TICKET_NUM) != null ? (String) variables.get(BpmConstant.COMMENTS)
						: null;
				completedDate = variables.get(BpmConstant.COMPLETED_DATE) != null
						? (String) variables.get(BpmConstant.COMPLETED_DATE)
						: null;
				commonBO.setComments(comments);
				commonBO.setTicketNum(iwosTicketNum);
				commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(completedDate));
				apnHLRIWOSCompletionService.postOperationIWOSCompletion(commonBO, execution);
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}

		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}
		logger.info("End postOperationIWOSCompletion method ::", this);
	}

	private void preOperationIWOSCompletion(DelegateExecution execution)
			throws CamundaServiceException, RecordNotFoundException {

		logger.info("Start preOperationIWOSCompletion method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		Map<String, Object> variables = execution.getVariables();
		orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		orderOperation = variables.get(BpmConstant.ORDER_OPERATION) != null
				? (String) variables.get(BpmConstant.ORDER_OPERATION)
				: null;
		if (orderId != null && orderOperation != null) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_HLR_IWOS_COMPLETION_ERR_PRE_001);// APN_HLR_IWOS_COMPLETION_ERR_PRE_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1005L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1015L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Completion)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			CommonBO commonBO = commonService.getCommonBO(orderId);
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url() + commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
				execution.setVariable(BpmConstant.PROCESS_TYPE, commonBO.getOrderTypeName());
				commonBO.setActivityInstanceId(execution.getActivityInstanceId());
				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				execution.setVariable("orderStatus", commonBO.getOrderStatusName());
				commonBO.setActivityInstanceId(execution.getActivityInstanceId());
				commonBO.setWorkFlowUrl(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setRoleId(1005L);// CCS PM Role Id
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setTaskStatusId(1001L);// User Task Status CREATED Id
				commonBO.setTaskId(1015L);// Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Completion)
				commonBO.setTaskStatusName("CCSPM_APN_HLR_LTE_Complete_Task");// Mapped from TASK_DATA table
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				commonBO.setUpdatedOn(new Date());
				apnHLRIWOSCompletionService.preOperationIWOSCompletion(commonBO, execution);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new RecordNotFoundException("Record not found::[" + execution.getCurrentActivityId() + "]");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}

		logger.info("End preOperationIWOSCompletion method ::", this);
	}
}
