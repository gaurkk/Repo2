package com.att.comet.bpm.common.dao;

public interface DapnInventoryDAO {

	public void saveDapnInventoryByOrderId(Long orderId);
	
	public void updateDapnInventoryByOrderIdAndId(Long orderId);
	
	public void updateDapnInventoryByOrderId(Long orderId);
	
}
