package com.att.comet.bpm.common.util;

public class TaskStatus {
	public static String CREATED ="CREATED";
	public static String COMPLETED ="COMPLETED";
	public static String DELETED ="DELETED";
	public static String FAULTED ="FAULTED";
}
