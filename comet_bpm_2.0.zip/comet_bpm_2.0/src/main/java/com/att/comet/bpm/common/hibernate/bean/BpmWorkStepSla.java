package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for BpmWorkStepSla. Mapped to BPM_WORK_STEP_SLA table in the
 * database.
 */
@Entity
@Table(name = "BPM_WORK_STEP_SLA")
public class BpmWorkStepSla implements java.io.Serializable {

	private static final long serialVersionUID = -5873020613185785175L;

	private BpmWorkStepSlaId id;
	private BpmWorkStep bpmWorkStep;
	private String slaDuration;

	/**
	 * No-argument constructor for the class.
	 */
	public BpmWorkStepSla() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param id
	 * @param bpmWorkStep
	 * @param slaDuration
	 */
	public BpmWorkStepSla(BpmWorkStepSlaId id, BpmWorkStep bpmWorkStep, String slaDuration) {
		this.id = id;
		this.bpmWorkStep = bpmWorkStep;
		this.slaDuration = slaDuration;
	}

	/**
	 * Getter method for id.
	 * 
	 * @return BpmWorkStepSlaId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "workStepId", column = @Column(name = "WORK_STEP_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "slaLevel", column = @Column(name = "SLA_LEVEL", nullable = false, length = 100)) })
	public BpmWorkStepSlaId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmWorkStepSlaId id) {
		this.id = id;
	}

	/**
	 * Getter method for bpmWorkStep.
	 * 
	 * @return BpmWorkStep
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WORK_STEP_ID", nullable = false, insertable = false, updatable = false)
	public BpmWorkStep getBpmWorkStep() {
		return this.bpmWorkStep;
	}

	/**
	 * @param bpmWorkStep to bpmWorkStep set.
	 */
	public void setBpmWorkStep(BpmWorkStep bpmWorkStep) {
		this.bpmWorkStep = bpmWorkStep;
	}

	/**
	 * Getter method for slaDuration. SLA_DURATION mapped to SLA_DURATION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "SLA_DURATION", nullable = false, length = 100)
	public String getSlaDuration() {
		return this.slaDuration;
	}

	/**
	 * @param slaDuration to slaDuration set.
	 */
	public void setSlaDuration(String slaDuration) {
		this.slaDuration = slaDuration;
	}

}
