package com.att.comet.bpm.iwos.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class APNHLRIWOSCompletionHelper {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCompletionHelper.class);
	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private AvosDAO avosDAO;

	@Autowired
	GenericDAO genericDAO;

	public void preOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method preOperationIWOSCompletion", this);

		String assigneeCCPM = null;
		Boolean User_or_group_exist = false;

		if (1001L == commonBO.getOrderTypeId() || 1004L == commonBO.getOrderTypeId()
				|| 1005L == commonBO.getOrderTypeId()) {

			// Decide User or Group for HT for email
			commonBO.setOrderContactTypeId(1006L);
			assigneeCCPM = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
			if (CommonUtils.isNotNullEmpty(assigneeCCPM)) {
				User_or_group_exist = true;
				commonBO.setIwosHlrAssignee(assigneeCCPM);
			}
			/* Get CCPM Email details */
			if (User_or_group_exist) {
				commonBO.setUser_or_group(assigneeCCPM);
				commonBO.setToEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
			} else {
				commonBO.setToEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
			}

			/* Get Admin Email details */
			commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

			// email to be sent to CCPM and Admin as CC in Reminder
			commonBO.setCcEmail((commonBO.getToEmail() + "," + commonBO.getAdminEmail()));

			/* Set Reminder1 & Reminder2 SLA Dates for NI */
			genericDAO.setReminder1And2FromSlaWorkingDayForApnHlrCompletion(commonBO);

			/* Insert Into AVOSProcessInstances */
			commonBO.setProcessId(1024L);//APN HLR IWOS PROCESS
			commonBO.setBpmProcessId(1024L);//APN HLR IWOS PROCESS
			avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);

			/* Insert Into BpmOrderWorkStep */
			if ("New".equals(commonBO.getOrderTypeName())) {
				commonBO.setWorkStepId(1064L);
				List<Long> idList = new ArrayList<Long>();
				idList.add(1064L);
				commonBO.setWorkStepIdList(idList);
				commonBO.setBpmStatusId(1001L);
				bpmDAO.saveBpmOrderWorkStep(commonBO);
			}

			/* Delete From BpmOrderBusinessStep */
			List<Long> businessStepIdList = new ArrayList<>();
			businessStepIdList.add(3195L);
			businessStepIdList.add(3196L);
			businessStepIdList.add(3143L);
			commonBO.setBusinessStepIdList(businessStepIdList);
			bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		} else {
			
			/* Update BpmOrderWorkStep */
			commonBO.setWorkStepId(1064L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		logger.info("@Ending method preOperationIWOSCompletion", this);
	}

	public void postOperationIWOSCompletion(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method postOperationIWOSCompletion", this);
		
		/* Insert Into BpmOrderBusinessStep */
		commonBO.setBusinessStepValue(commonBO.getTicketNum());
		commonBO.setComments(commonBO.getComments());
		commonBO.setBusinessStepId(3143L);
		commonBO.setBusinessStepStatus("Completed");
		commonBO.setAttuid(commonBO.getAttuid());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setWorkStepId(1064L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1064L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		/* Update OrderContactInfo */
		commonBO.setProcessId(1024L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);

		/* Update BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3111L);
		commonBO.setBusinessStepStatus("APN_HLR_IWOS_READY_FOR_TTU");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Delete AVOSProcessInstances */
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);

		logger.info("@Ending method postOperationIWOSCompletion", this);
	}

}
