package com.att.comet.bpm.common.dao;

import java.util.Date;
import java.util.List;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.OrderFlagsDetails;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;


public interface OrderDAO {

	/**
	 * Fetches order details
	 * 
	 * @param orderId
	 * @throws CamundaServiceException 
	 */
	CommonBO getOrderById(Long orderId) throws CamundaServiceException;

	int updateOrderStatus(Long orderId, Long orderStatusId);

	void updateOrders(CommonBO commonBO);

	void saveOrderStatusHistory(CommonBO commonBO) throws CamundaServiceException;

	long countOrderEvent(CommonBO commonBO);

	List<String> getOrderContactInfoATTUId(CommonBO commonBO) throws CamundaServiceException;

	void updateOrderContactInfo(CommonBO commonBO);

	List<Object[]> getATTUIDFirstNameLastName(CommonBO commonBO);

	void saveOrderComments(CommonBO commonBO);

	OrderFlagsDetails findOrderFlagsDetails(CommonBO commonBO);

	List<Object[]> getBillingData(CommonBO commonBO);

	void saveOrderBillingTask(CommonBO commonBO);

	void updateOrderBillingTask(CommonBO commonBO);

	String getOrderComments(CommonBO commonBO);

	void saveOrderStatusIdByOrderId(CommonBO commonBO) throws CamundaServiceException;
	
	void updateOrderUserBpmTasksRepository(CommonBO commonBO)throws CamundaServiceException;
	
	void deleteOrderFlagDetails(CommonBO commonBO);

	Date getBackHaulConfig(CommonBO commonBO);

	void updateBackhaulConfig(CommonBO commonBO);

	void updateOrderFlagDetails(CommonBO commonBO);

	String completeOrderWorkFlow(Long orderId,String orderOperation)throws CamundaServiceException;

	boolean completeCancelOrderWorkFlow(CommonBO commonBO);

	void updateImsiInventory(CommonBO commonBO);
	
	void updateOrderUserTaskFaults(OrderUserTaskFaultsBO orderUserTaskFaultsBO);

	List<Object[]> getOrderOnHoldDetails(CommonBO commonBO) throws CamundaServiceException;

	void updateOrderOnHoldStatusId(CommonBO commonBO) throws CamundaServiceException;

	void updateOrderOnHoldApprovedDate(CommonBO commonBO) throws CamundaServiceException;

	String getOrderOnHoldCancelNotes(CommonBO commonBO) throws CamundaServiceException;

	String getOrderOnHoldResumeNotes(CommonBO commonBO) throws CamundaServiceException;

	Long getDerivedOrderId(CommonBO commonBO) throws CamundaServiceException;
	
	void updateOrderUserBpmTasksForException(CommonBO commonBO)throws CamundaServiceException;

	CommonBO getDapnOderById(Long orderId);

	void updateOrderStatusOnhold(CommonBO commonBO);

	void updateOrderCrFlag(CommonBO commonBO);
	void rollbackAuditOrder(CommonBO commonBO) throws CamundaServiceException;

	List<Object[]> getItOpsTaskData(CommonBO commonBO);
}
