package com.att.comet.bpm.common.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.UserRoleRepository;
import com.att.comet.bpm.common.repository.UsersRepository;


@Component
public class UserDAOImpl implements UserDAO {
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private UserRoleRepository userRoleRepository;

	@Override
	public List<String> getUserEmail(CommonBO commonBO) {
		return usersRepository.findUserEmail(commonBO.getAttuid(), 'Y');
	}

	@Override
	public List<Object[]> findContactTypeIdAndEmail(CommonBO commonBO) {

		return usersRepository.findContactTypeIdAndEmail(commonBO.getOrderId(), commonBO.getOrderContactTypeIdList());
	}

	@Override
	public List<String> getGroupUserEmail(CommonBO commonBO) {
		return userRoleRepository.findGroupUserEmail(commonBO.getRoleId(), 'Y', 'Y');
	}

	@Override
	public List<String> findEmailByRoleId(CommonBO commonBO) {
		return usersRepository.findEmailByRoleId(commonBO.getRoleId());
	}

	@Override
	public List<String> getAssignedUserEmail(List<String> attUidList) {

		return usersRepository.getAssignedUserEmail(attUidList);
	}

	@Override
	public List<String> getActiveUserGroupEmail(CommonBO commonBO){
		return userRoleRepository.findGroupUserEmail(commonBO.getRoleId(), 'Y', 'Y');
	}
	
	@Override
	public List<String> findEmailAllUsers(CommonBO commonBO) {

		return usersRepository.findEmailAllUsers(commonBO.getOrderId(), commonBO.getOrderContactTypeIdList());
	}
}
