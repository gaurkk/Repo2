package com.att.comet.bpm.common.util;

public enum TaskOperations {
	COMPLETE,
	CLAIM,
	DELEGATE,
	RELEASE,
	SAVE,
	START;
}
