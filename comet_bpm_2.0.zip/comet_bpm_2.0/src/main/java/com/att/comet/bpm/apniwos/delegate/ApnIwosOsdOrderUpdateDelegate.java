package com.att.comet.bpm.apniwos.delegate;

import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.apniwos.service.ApnIwosOsdOrderUpdateService;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class ApnIwosOsdOrderUpdateDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(ApnIwosOsdOrderUpdateDelegate.class);

	@Autowired
	private CommonService commonService;
	@Autowired
	ApnIwosOsdOrderUpdateService apnIwosOsdOrderUpdateService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.APN_IWOS_ORDER_TYPE:
					orderTypeCheck(execution);
					break;
				case BpmConstant.NEW_ORDER_UPDATE_OPERATION:
					newOderUpdateOperation(execution);
					break;
				case BpmConstant.CR_CO_UPDATE_OPERATION:
					crcoUpdateOperation(execution);
					break;
				case BpmConstant.APN_IWOS_OSD_PRE_OPERATION:
					preOperationOSDOrderUpdate(execution);
					break;
				case BpmConstant.APN_IWOS_OSD_POST_OPERATION:
					postOperationOSDOrderUpdate(execution);
					break;

				}
			} else {
				throw new CamundaServiceException("NO INPUT FOUND FOR NEXT FLOW STEPS");
			}

		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.APN_IWOS_OSD_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void newOderUpdateOperation(DelegateExecution execution) {
		logger.info("Start newOderUpdateOperation method ::", this);
		CommonBO commonBO = null;
		try {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				apnIwosOsdOrderUpdateService.newOrderDBOperation(commonBO);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + commonBO + "]", this);

			}
		} catch (Exception e) {

		}
		logger.info("Start newOderUpdateOperation method ::", this);
	}

	private void orderTypeCheck(DelegateExecution execution) {
		logger.info("Start orderTypeCheck method ::", this);
		CommonBO commonBO = null;
		String osdOderUpdateInstanceId = null;
		String orderOperation = null;
		osdOderUpdateInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
				if (commonBO != null && null != commonBO.getOrderTypeId()) {
					commonBO.setBpmProcessInstanceId(osdOderUpdateInstanceId);
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					if (!StringUtils.isEmpty(orderOperation)) {
						execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);

					} else {
						logger.error("Order Type name for  ," + "ORDER_ID::[" + orderId + "]  is null", this);
					}
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.APN_IWOS_OSD_ORDER_UPDATE_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Exiting orderTypeCheck method ::", this);
	}

	private void crcoUpdateOperation(DelegateExecution execution) {
		logger.info("Start crcoUpdateOperation method ::", this);
		CommonBO commonBO = null;
		try {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				apnIwosOsdOrderUpdateService.crcoDBOperation(commonBO);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + commonBO + "]", this);

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure OSD ORDER UPDATE"), this);
			throw new BpmnError("ERROR_BPM_001", "OSD ORDER UPDATE EXCEPTION");
		}
		logger.info("Start crcoUpdateOperation method ::", this);

	}

	private void preOperationOSDOrderUpdate(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperationApnIwosCompletion method ::", this);
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String osdOderUpdateInstanceId = null;
		osdOderUpdateInstanceId = execution.getProcessInstanceId();
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// Setting OSD roleID
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1022L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
			execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
			execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
			execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
			execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
			execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
			execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
			execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());// set On above method
			execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());

			execution.setVariable(BpmConstant.CATEGORY, "1002");// User task

			commonBO.setRoleId(1001L);// Setting OSD roleID
			commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
			commonBO.setTaskStatusName("OS_NI_Feedback_Complete_Task");
			commonBO.setCategoryId(1002L);// category ID (user task)
			commonBO.setUrlName(commonBO.getWorkFlowUrl());
			commonBO.setTaskId(1018L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
			commonBO.setUpdatedOn(new Date());
			commonBO.setBpmProcessInstanceId(osdOderUpdateInstanceId);
			apnIwosOsdOrderUpdateService.preOperationOrderUpdate(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
			execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
		} else {
			logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

		}
		logger.info("Existing preOperationApnIwosCompletion method ::", this);

	}

	private void postOperationOSDOrderUpdate(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start postOperationApnIwosCompletion_Suspenstion method ::", this);
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String osdComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		CommonBO commonBO = null;

		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.APN_IWOS_OSD_ORDER_UPDATE_ERR_POST_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_POST_001
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// Setting OSD roleID
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1022L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO.setUpdatedOn(new Date());
			apnIwosOsdOrderUpdateService.postOperationOrderUpdate(commonBO, osdComments);
			commonBO.setCategoryId(1003L);// Service
			commonBO.setTaskStatusId(1002L);
			commonBO.setTaskCompletionTime(new Date());
			commonService.updateOrderUserBpmTasksRepository(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			execution.setVariable(BpmConstant.APN_IWOS_BUILD_CONFIRMATION, "SUSPENDED");
		} else {
			logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

		}
		logger.info("Exiting postOperationApnIwosCompletion_Suspenstion method ::", this);

	}

}
