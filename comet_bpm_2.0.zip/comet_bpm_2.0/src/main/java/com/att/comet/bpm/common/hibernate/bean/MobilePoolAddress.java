package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for MobilePoolAddress. Mapped to MOBILE_POOL_ADDRESS table in the database.
 */
@Entity
@Table(name = "MOBILE_POOL_ADDRESS")
public class MobilePoolAddress implements Serializable {

	private static final long serialVersionUID = 276269772464216052L;

	private Long mobilePoolAddressId;
	private DataCenter dataCenter;
	private Apn apn;
	private String ipAddress;
	private Byte seq;
	private String ipAddressType;

	/**
	 * Getter method for mobilePoolAddressId. MOBILE_POOL_ADDRESS_ID mapped to MOBILE_POOL_ADDRESS_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "MOBILE_POOL_ADDRESS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_MOBILE_POOL_ADDRESS_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_MOBILE_POOL_ADDRESS_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_MOBILE_POOL_ADDRESS_ID")
	public Long getMobilePoolAddressId() {
		return mobilePoolAddressId;
	}

	/**
	 * @param mobilePoolAddressId
	 *            to mobilePoolAddressId set
	 */
	public void setMobilePoolAddressId(Long mobilePoolAddressId) {
		this.mobilePoolAddressId = mobilePoolAddressId;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 *            to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for ipAddress. IP_ADDRESS mapped to IP_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * @param ipAddress
	 *            to ipAddress set.
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Getter method for ipAddressType. IP_ADDRESS_TYPE mapped to IP_ADDRESS_TYPE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS_TYPE", length = 100)
	public String getIpAddressType() {
		return ipAddressType;
	}

	/**
	 * @param ipAddressType
	 *            to ipAddressType set.
	 */
	public void setIpAddressType(String ipAddressType) {
		this.ipAddressType = ipAddressType;
	}

	/**
	 * Getter method for seq. SEQ mapped to SEQ in the database table.
	 * 
	 * @return Byte
	 */
	@Column(name = "SEQ", precision = 2, scale = 0)
	public Byte getSeq() {
		return this.seq;
	}

	/**
	 * @param seq
	 *            to seq set.
	 */
	public void setSeq(Byte seq) {
		this.seq = seq;
	}
}