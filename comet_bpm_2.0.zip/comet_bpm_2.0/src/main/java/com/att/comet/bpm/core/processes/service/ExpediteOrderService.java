package com.att.comet.bpm.core.processes.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ExpediteOrderService {
	public void preOperation(CommonBO commonBO) throws CamundaServiceException;
	public void postOperation(CommonBO commonBO) throws CamundaServiceException;
	public void setExpediteFlagBefore(CommonBO commonBO) throws CamundaServiceException;
	public void setExpediteFlagAfter(CommonBO commonBO) throws CamundaServiceException;
	public void rejectedByOM(CommonBO commonBO) throws CamundaServiceException;
	public void rejectedByOA(CommonBO commonBO) throws CamundaServiceException;
}
