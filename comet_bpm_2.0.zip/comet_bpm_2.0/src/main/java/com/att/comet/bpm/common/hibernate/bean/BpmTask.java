package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "BPM_TASK")
@Data
public class BpmTask implements Serializable {

	private static final long serialVersionUID = -4498741977221029349L;

	@Id
	@Column(name = "TASK_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long taskId;

	@Column(name = "TASK_NAME", nullable = true, length = 500)
	private String taskName;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmTask")
	private List<OrderUserBpmTasks> orderUserBpmTasksList = new ArrayList<>();

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmTask")
	private List<TaskInfo> taskInfoList = new ArrayList<>();

}
