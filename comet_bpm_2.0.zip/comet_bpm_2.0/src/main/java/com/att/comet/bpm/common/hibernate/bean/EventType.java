package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EVENT_TYPE")
public class EventType implements Serializable {

	private static final long serialVersionUID = 3505800771512828730L;
	private Long eventTypeId;
	private String eventTypeDec;
	private List<ExternalInterfaceEventLogs> lstExtIntEventLogs = new ArrayList<ExternalInterfaceEventLogs>();

	/**
	 * @return the eventTypeId
	 */
	@Id
	@Column(name = "EVENT_TYPE_ID", unique = true, nullable = false, precision = 4, scale = 0)
	public Long getEventTypeId() {
		return eventTypeId;
	}

	/**
	 * @param eventTypeId the eventTypeId to set
	 */
	public void setEventTypeId(Long eventTypeId) {
		this.eventTypeId = eventTypeId;
	}

	/**
	 * @return the eventTypeDec
	 */
	@Column(name = "EVENT_TYPE_DESC", nullable = false, length = 100)
	public String getEventTypeDec() {
		return eventTypeDec;
	}

	/**
	 * @param eventTypeDec the eventTypeDec to set
	 */
	public void setEventTypeDec(String eventTypeDec) {
		this.eventTypeDec = eventTypeDec;
	}

	/**
	 * @return the lstExtIntEventLogs
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "eventType")
	public List<ExternalInterfaceEventLogs> getLstExtIntEventLogs() {
		return lstExtIntEventLogs;
	}

	/**
	 * @param lstExtIntEventLogs the lstExtIntEventLogs to set
	 */
	public void setLstExtIntEventLogs(List<ExternalInterfaceEventLogs> lstExtIntEventLogs) {
		this.lstExtIntEventLogs = lstExtIntEventLogs;
	}
}
