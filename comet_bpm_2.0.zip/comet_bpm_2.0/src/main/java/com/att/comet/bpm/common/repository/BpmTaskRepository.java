package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.BpmTask;

public interface BpmTaskRepository extends JpaRepository<BpmTask, Long> {

}
