package com.att.comet.bpm.common.hibernate.bean;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for the BGP. Mapped with BGP table in the database.
 */
@Entity
@Table(name = "BGP")
public class Bgp implements java.io.Serializable {

	private static final long serialVersionUID = 2332265599773387118L;

	private Long backhaulId;
	private Backhaul backhaul;
	private String attAsn;
	private String attEndpointIp;
	private String attNotes;
	private Long custAsn;
	private String custBgpPeerIp;
	private String custNotes;
	private String routingPolicies;
	private String generalNotes;
	private List<AttExportList> attExportList;

	/**
	 * Getter method for the backhaulId.It is the unique value in the database ,
	 * having a maximum length of 12. BACKHAUL_ID mapped to BACKHAUL_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "backhaul"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "BACKHAUL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	/**
	 * Getter method for the backhaul.
	 * 
	 * @return Backhaul
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Backhaul getBackhaul() {
		return this.backhaul;
	}

	/**
	 * @param backhaul
	 *            to backhaul set.
	 */
	public void setBackhaul(Backhaul backhaul) {
		this.backhaul = backhaul;
	}

	/**
	 * Getter method for attAsn. ATT_ASN mapped to ATT_ASN in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ATT_ASN")
	public String getAttAsn() {
		return this.attAsn;
	}

	/**
	 * @param attAsn
	 *            to attAsn set.
	 */
	public void setAttAsn(String attAsn) {
		this.attAsn = attAsn;
	}

	/**
	 * Getter method for the attEndpointIp ATT_ENDPOINT_IP mapped to
	 * ATT_ENDPOINT_IP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ATT_ENDPOINT_IP", length = 100)
	public String getAttEndpointIp() {
		return this.attEndpointIp;
	}

	/**
	 * @param attEndpointIp
	 *            to attEndpointIp set.
	 */
	public void setAttEndpointIp(String attEndpointIp) {
		this.attEndpointIp = attEndpointIp;
	}

	/**
	 * Getter method for attNotes. ATT_NOTES mapped to ATT_NOTES in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "ATT_NOTES", length = 3500)
	public String getAttNotes() {
		return this.attNotes;
	}

	/**
	 * @param attNotes
	 *            to attNotes set.
	 */
	public void setAttNotes(String attNotes) {
		this.attNotes = attNotes;
	}

	/**
	 * Getter method for custAsn. CUST_ASN mapped to CUST_ASN in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Column(name = "CUST_ASN", precision = 12, scale = 0)
	public Long getCustAsn() {
		return this.custAsn;
	}

	/**
	 * @param custAsn
	 *            to custAsn set.
	 */
	public void setCustAsn(Long custAsn) {
		this.custAsn = custAsn;
	}

	/**
	 * Getter method for custBgpPeerIp. CUST_BGP_PEER_IP mapped to
	 * CUST_BGP_PEER_IP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUST_BGP_PEER_IP", length = 100)
	public String getCustBgpPeerIp() {
		return this.custBgpPeerIp;
	}

	/**
	 * @param custBgpPeerIp
	 *            to custBgpPeerIp set.
	 */
	public void setCustBgpPeerIp(String custBgpPeerIp) {
		this.custBgpPeerIp = custBgpPeerIp;
	}

	/**
	 * Getter method for custNotes. CUST_NOTES mapped to CUST_NOTES in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUST_NOTES", length = 3500)
	public String getCustNotes() {
		return this.custNotes;
	}

	/**
	 * @param custNotes
	 *            to custNotes set.
	 */
	public void setCustNotes(String custNotes) {
		this.custNotes = custNotes;
	}

	/**
	 * Getter method for routingPolicies ROUTING_POLICIES mapped to
	 * ROUTING_POLICIES in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ROUTING_POLICIES", length = 3500)
	public String getRoutingPolicies() {
		return this.routingPolicies;
	}

	/**
	 * @param routingPolicies
	 *            to routingPolicies set.
	 */
	public void setRoutingPolicies(String routingPolicies) {
		this.routingPolicies = routingPolicies;
	}

	
	/**
	 * Getter method for generalNotes GENERAL_NOTES mapped to GENERAL_NOTES in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "GENERAL_NOTES", length = 3500)
	public String getGeneralNotes() {
		return this.generalNotes;
	}

	/**
	 * @param generalNotes
	 *            to generalNotes set.
	 */
	public void setGeneralNotes(String generalNotes) {
		this.generalNotes = generalNotes;
	}
	@OneToMany(mappedBy="bgp", fetch=FetchType.LAZY)
	public List<AttExportList> getAttExportList() {
		return this.attExportList;
	}

	/**
	 * @param AttExportList
	 * to AttExportList set.
	 */
	public void setAttExportList(List<AttExportList> attExportList) {
		this.attExportList = attExportList;
	}
	

}
