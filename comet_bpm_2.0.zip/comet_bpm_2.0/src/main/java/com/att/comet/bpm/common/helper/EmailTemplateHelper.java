package com.att.comet.bpm.common.helper;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.hibernate.bean.TaskInfo;
import com.att.comet.bpm.common.repository.TaskInfoRepository;

@Component
public class EmailTemplateHelper {

	@Autowired
	TaskInfoRepository taskInfoRepository;

	/**
	 * FOR OA NOTIFICATION
	 * 
	 * @param taskId
	 * @param taskDisplayTypeId
	 */
	public TaskInfo getTaskInfo(Long taskId, Long taskDisplayTypeId) {
		List<TaskInfo> taskInfoList = taskInfoRepository.getTaskIdDetails(taskId);
		if (!CollectionUtils.isEmpty(taskInfoList)) {
			for(TaskInfo taskInfo :taskInfoList) {
				if (taskInfo.getTaskDisplayType().getTaskDisplayTypeId().toString().equals(String.valueOf(taskDisplayTypeId))) {
					taskInfo.getSubject();
					taskInfo.getHeaderSection();
					taskInfo.getSubHeaderSection();
					taskInfo.getBodySection1();
					taskInfo.getBodySection2();
					taskInfo.getBodySection3();
					taskInfo.getFooterSection();
					return taskInfo;
				}
			}
		
		}
		return null;
	}
}
