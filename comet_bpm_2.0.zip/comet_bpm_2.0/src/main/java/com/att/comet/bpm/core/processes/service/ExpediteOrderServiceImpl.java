package com.att.comet.bpm.core.processes.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class ExpediteOrderServiceImpl implements ExpediteOrderService {
	private static final Logger logger = LoggerFactory.getLogger(ExpediteOrderServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO avosDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method pendingTaskStatusCheck");
		List<String> cometUsersEmailList = null;
		commonBO.setBpmProcessId(1018L);
		//avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		// getting the status of pending taskes
		// fetching process status
		BpmTask bpmTask = new BpmTask();
		Orders order = new Orders();
		 bpmTask.setTaskId(1016L);
		order.setOrderId(commonBO.getOrderId());
		String apnIwosTaskStatus = null;
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
			if (null != taskObj) {

				if (taskObj.getBpmTask().getTaskId().equals(1016L) || taskObj.getBpmTask().getTaskId().equals(1032L)
						|| taskObj.getBpmTask().getTaskId().equals(1029L)) {
					apnIwosTaskStatus = taskObj.getTaskStatus().getTaskStatusDesc();
					if (CommonUtils.isNotNullEmpty(apnIwosTaskStatus)) {
						if (apnIwosTaskStatus.equalsIgnoreCase("COMPLETED")) {
							logger.info("apnIwosTaskStatus  :: " + apnIwosTaskStatus, this);
							commonBO.setApnIwosTaskStatus(apnIwosTaskStatus);
							break;
						} else {
							commonBO.setApnIwosTaskStatus("CREATED");
						}
					}
				}
			} else {
				logger.error("taskObj is empty: ", this);
			}
		}
		// Fetching emails of all Users
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		orderContactTypeIdList.add(1024L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		cometUsersEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					cometUsersEmailList.add((String) obj[1]);
				}
			}
			commonBO.setGroupEmailList(cometUsersEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));
		// getting admin email
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setGroupEmailList(adminEmailList);
		commonBO.setAdminEmailList(adminEmailList);
		commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));
		// deleting bpm_order_process
		commonBO.setProcessId(1018L);
		
		//bpmDAO.deleteBpmOrderProcess(commonBO);
		// saving bpm_order_process
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3117L);
		businessStepIdList.add(3118L);
		businessStepIdList.add(3038L);
		businessStepIdList.add(3106L);
		businessStepIdList.add(3107L);
		businessStepIdList.add(3119L);
		businessStepIdList.add(3020L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// deleting bpm_order_work_step
		List<Long> workStepIdList = new ArrayList<Long>();
		workStepIdList.add(1027L);
		workStepIdList.add(1028L);
		workStepIdList.add(1029L);
		workStepIdList.add(1049L);
		workStepIdList.add(1050L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		// Saving bpm_order_work_step
		commonBO.setWorkStepId(1049L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		// saving processInstanceId
		commonBO.setBpmProcessId(1018L);
		avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		// Fetching Expedite Build Date and Reason
		List<Object[]> expBuildDateAndReasonList = bpmDAO.getExpBuildDateAndReason(commonBO.getOrderId());
		// List<String> expediteReason = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(expBuildDateAndReasonList)) {
			logger.debug("expBuildDateAndReasonList is not empty : ", +expBuildDateAndReasonList.size(), this);
			for (Object[] obj : expBuildDateAndReasonList) {
				if (null != obj[0]) {
					try {
						Date expediteBuildDate = (Date) obj[0];
						logger.info("expediteBuildDate :: " + expediteBuildDate, this);
						commonBO.setExpediteBuildDate(expediteBuildDate);
					}catch(Exception e) {
						logger.debug("expediteBuildDate is null :: ");
					}
				} else if (null != obj[1]) {
					String expediteReason = obj[1].toString();
					logger.info("expediteReason :: " + expediteReason, this);
					commonBO.setExpediteReason(expediteReason);
				} else {
					logger.error("obj[0] is null ");
				}
				
			}
			// commonBO.setGroupEmailList(cometUsersEmailList);
		} else {
			logger.error("expBuildDateAndReasonList is empty: ", +expBuildDateAndReasonList.size());
		}
		logger.info("::Exiting  Method pendingTaskStatusCheck Method :: ");

	}

	@Override
	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method postOperation Method :: ");
		// update bpm_order_process
		commonBO.setProcessId(1018L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);
		// delete avos
		avosDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		logger.info("::Exiting  Method postOperation Method :: ");

	}

	@Override
	public void setExpediteFlagBefore(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method setExpediteFlagBefore Method :: ");
		commonBO.setExpediteProcessStatus("true");
		bpmDAO.updateBpmOrderExpedite(commonBO);
		logger.info("::Exiting  Method setExpediteFlagBefore Method :: ");

	}

	@Override
	public void setExpediteFlagAfter(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method setExpediteFlagAfter Method :: ");
		commonBO.setExpediteProcessStatus("false");
		bpmDAO.updateBpmOrderExpedite(commonBO);
		logger.info("::Exiting  Method setExpediteFlagAfter Method :: ");

	}

	@Override
	public void rejectedByOA(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method rejectedByOA Method :: ");
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepId(3117L);
		commonBO.setBusinessStepStatus(commonBO.getApproved());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update orders
		commonBO.setExpedite('N');
		orderDAO.updateOrders(commonBO);
		//update order contact info
		commonBO.setOrderContactTypeId(1004L);
		orderDAO.updateOrderContactInfo(commonBO);
		//update bpm order work step
		commonBO.setWorkStepId(1049L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		//retrive OS email id to send the email notification
		commonBO.setOrderContactTypeId(1003L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			List<String> OsEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(OsEmailList);
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
		}
		logger.info("::Exiting  Method rejectedByOA Method :: ");

	}

	@Override
	public void rejectedByOM(CommonBO commonBO) throws CamundaServiceException {
		logger.info("::Exiting  Method rejectedByOM Method :: ");
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepId(3120L);
		commonBO.setBusinessStepStatus(commonBO.getApproved());
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update orders
		commonBO.setExpedite('N');
		orderDAO.updateOrders(commonBO);
		//update order contact info
		commonBO.setOrderContactTypeId(1005L);
		orderDAO.updateOrderContactInfo(commonBO);
		//update bpm order work step
		commonBO.setWorkStepId(1050L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		//retrive OS email id to send the email notification
		commonBO.setOrderContactTypeId(1003L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			List<String> OsEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setOsdEmailList(OsEmailList);
			
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
		}
		//retrive OA email id to send the email notification
		commonBO.setOrderContactTypeId(1004L);
		List<String> oaAttUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(oaAttUidList)) {
			logger.debug("osdEmailList is not empty : ", +oaAttUidList.size());
			String orderApprover = attUidList.get(0);
			commonBO.setAttuid(orderApprover);
			commonBO.setAssignee(orderApprover);
			List<String> OAEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setOaEmailList(OAEmailList);
		} else {
			logger.debug("oaAttUidList is empty: ", +oaAttUidList.size());
		}
		commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getOsdEmailList()));
		commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getOaEmailList()));
		logger.info("::Exiting  Method rejectedByOM Method :: ");

	}

}
