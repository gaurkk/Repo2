package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for ConnectivityMatrixId.
 */
@Embeddable
public class ConnectivityMatrixId implements Serializable {

	private static final long serialVersionUID = -5854548977544815003L;

	private Long scenario;
	private Long crdId;
	private Long dataCenterId;

	/**
	 * Getter method for scenario. SCENARIO mapped to SCENARIO in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Column(name = "SCENARIO", nullable = false, precision = 12, scale = 0)
	public Long getScenario() {
		return this.scenario;
	}

	/**
	 * @param scenario to scenario set.
	 */
	public void setScenario(Long scenario) {
		this.scenario = scenario;
	}

	/**
	 * Getter method for crdId. CRD_ID mapped to CRD_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "CRD_ID", nullable = false, precision = 12, scale = 0)
	public Long getCrdId() {
		return this.crdId;
	}

	/**
	 * @param crdId to crdId set.
	 */
	public void setCrdId(Long crdId) {
		this.crdId = crdId;
	}

	/**
	 * Getter method for dataCenterId. DATA_CENTER_ID mapped to DATA_CENTER_ID in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return this.dataCenterId;
	}

	/**
	 * @param dataCenterId to dataCenterId set.
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ConnectivityMatrixId))
			return false;
		ConnectivityMatrixId castOther = (ConnectivityMatrixId) other;

		return (this.getScenario() == castOther.getScenario()) && (this.getCrdId() == castOther.getCrdId())
				&& (this.getDataCenterId() == castOther.getDataCenterId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getScenario().hashCode();
		result = 37 * result + (int) this.getCrdId().hashCode();
		result = 37 * result + (int) this.getDataCenterId().hashCode();
		return result;
	}
}