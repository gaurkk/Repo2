package com.att.comet.bpm.ttu.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class OSDTTUReScheduleServiceImpl implements OSDTTUReScheduleService {

	private static final Logger logger = LoggerFactory.getLogger(OSDTTUScheduleServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;

	@Override
	public void postOperationOSDTTUReSchedule(CommonBO commonBO, String reasonForReschedule, String ttuReScheduleDateTime)
			throws CamundaServiceException, ParseException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)
				+ "]::Starting Method postOperationOSDTTUReSchedule");
		// update bpm_order_work_step
		commonBO.setWorkStepId(1053L);
		commonBO.setBpmStatusId(1002L);
		commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(ttuReScheduleDateTime));
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// Insert into bpm_order_business_step
		commonBO.setBusinessStepId(3141L);
		commonBO.setComments(reasonForReschedule);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

	}

	@Override
	public void preOperationOSDTTUReSchedule(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)
				+ "]::Starting Method preOperationOSDTTUReSchedule");
		List<String> osdEmailList = null;
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1023L);
		commonBO.setUpdatedOn(new Date());
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			commonBO.setAssignee(orderSubmitter);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);

		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(osdEmailList);
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
		}
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3141L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		// delete bpm_order_work_step table
		List<Long> workStepIdList = new ArrayList<Long>();
		workStepIdList.add(1023L);
		commonBO.setBusinessStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		if ("NEW_ORDER".equalsIgnoreCase(commonBO.getOrderOperation())) {
			commonBO.setWorkStepId(1053L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1053L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {
			commonBO.setWorkStepId(1053L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1053L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
	}

}
