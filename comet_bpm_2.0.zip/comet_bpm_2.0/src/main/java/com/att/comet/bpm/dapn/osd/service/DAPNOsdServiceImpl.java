package com.att.comet.bpm.dapn.osd.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.dapn.build.service.DAPNBuildServiceImpl;

@Service
public class DAPNOsdServiceImpl implements DAPNOsdService{
	private static final Logger logger = LoggerFactory.getLogger(DAPNBuildServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	OrderCommentsDAO orderCommentsDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperation");
		List<String> OAEmailList = null;
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3203L);
		businessStepIdList.add(3204L);
		businessStepIdList.add(3205L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// deleting bpm_order_work_step
		commonBO.setWorkStepId(1074L);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		// saving bpm_order_work_step
		commonBO.setWorkStepId(1074L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		// dynamic user
		commonBO.setOrderContactTypeId(1003L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderApprover = attUidList.get(0);
			commonBO.setAttuid(orderApprover);
			commonBO.setAssignee(orderApprover);
			OAEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(OAEmailList);
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			OAEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setOaEmailList(OAEmailList);
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getOaEmailList()));// All grp
		}
		// OSD ATTUID
		// List<String> osdAttuidList=null;
		commonBO.setOrderContactTypeId(1004L);
		List<String> osdAttuidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdAttuidList is not empty : ", +osdAttuidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			List<String> osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setOsdEmailList(osdEmailList);
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getOsdEmailList()));// All grp
		}
		// OM ATTUID
		// List<String> osdAttuidList=null;
		commonBO.setOrderContactTypeId(1005L);
		List<String> omAttuidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(omAttuidList)) {
			logger.debug("omAttuidList is not empty : ", +omAttuidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			List<String> osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setOmEmailList(osdEmailList);
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getOmEmailList()));// All grp
		}
		// Admin Email
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		genericDAO.setReminder1And2FromSlaWorkingDayForITOPSDAPNOS(commonBO);
		commonBO.setRoleId(1001L);
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method preOperation");
	}

	@Override
	public void postOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperation");

		// updating bpm_order_work_step
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		// update bpm_order_business_step
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Submitted");
		commonBO.setBusinessStepId(3203L);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_business_step History
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);
		// update order comments
		commonBO.setOrderProcess(commonBO.getOrderOperation());
		commonBO.setRoleId(1001L);
		commonBO.setUserAction("Order Update (OS) - Completed for OA Rejection");
		orderDAO.saveOrderComments(commonBO);
		// Update order Contact info
		commonBO.setOrderContactTypeId(1003L);
		orderDAO.updateOrderContactInfo(commonBO);
		//update bpm_order_process
		commonBO.setProcessId(1029L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderProcess(commonBO);

		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Exiting Method postOperation");

	}
}
