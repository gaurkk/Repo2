package com.att.comet.bpm.common.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for BpmProcess. BPM_PROCESS mapped to BPM_PROCESS table in
 * the database.
 */
@Entity
@Table(name = "BPM_PROCESS")
public class BpmProcess implements java.io.Serializable {

	private static final long serialVersionUID = -8815643869933112743L;

	private Long processId;
	private String processName;
	private Set<BpmOrderProcess> bpmOrderProcesses = new HashSet<BpmOrderProcess>(0);
	private Set<BpmWorkStep> bpmWorkSteps = new HashSet<BpmWorkStep>(0);

	/**
	 * No-argument constructor.
	 */
	public BpmProcess() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param processId
	 * @param processName
	 */
	public BpmProcess(Long processId, String processName) {
		this.processId = processId;
		this.processName = processName;
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param processId
	 * @param processName
	 * @param bpmOrderProcesses
	 * @param bpmWorkSteps
	 */
	public BpmProcess(Long processId, String processName, Set<BpmOrderProcess> bpmOrderProcesses,
			Set<BpmWorkStep> bpmWorkSteps) {
		this.processId = processId;
		this.processName = processName;
		this.bpmOrderProcesses = bpmOrderProcesses;
		this.bpmWorkSteps = bpmWorkSteps;
	}

	/**
	 * Getter method for processId. PROCESS_ID mapped to PROCESS_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "PROCESS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getProcessId() {
		return this.processId;
	}

	/**
	 * @param processId to processId set.
	 */
	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	/**
	 * Getter method for processName. PROCESS_NAME mapped to PROCESS_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "PROCESS_NAME", nullable = false, length = 100)
	public String getProcessName() {
		return this.processName;
	}

	/**
	 * @param processName to processName set.
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}

	/**
	 * Getter method for bpmOrderProcesses.
	 * 
	 * @return Set<BpmOrderProcess>.
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmProcess")
	public Set<BpmOrderProcess> getBpmOrderProcesses() {
		return this.bpmOrderProcesses;
	}

	/**
	 * @param bpmOrderProcesses to bpmOrderProcesses set.
	 */
	public void setBpmOrderProcesses(Set<BpmOrderProcess> bpmOrderProcesses) {
		this.bpmOrderProcesses = bpmOrderProcesses;
	}

	/**
	 * Getter method for bpmWorkSteps.
	 * 
	 * @return Set<BpmWorkStep>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmProcess")
	public Set<BpmWorkStep> getBpmWorkSteps() {
		return this.bpmWorkSteps;
	}

	/**
	 * @param bpmWorkSteps to bpmWorkSteps set.
	 */
	public void setBpmWorkSteps(Set<BpmWorkStep> bpmWorkSteps) {
		this.bpmWorkSteps = bpmWorkSteps;
	}

}
