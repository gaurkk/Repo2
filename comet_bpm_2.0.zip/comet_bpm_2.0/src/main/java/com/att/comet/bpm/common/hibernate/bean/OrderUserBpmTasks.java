package com.att.comet.bpm.common.hibernate.bean;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ORDER_USER_BPM_TASKS")
@Getter
@Setter
public class OrderUserBpmTasks implements Serializable {

	private static final long serialVersionUID = -4099757827928228335L;

	@Id
	@Column(name = "BPM_TASK_ID", unique = true, nullable = false, length = 20)
	private String bpmTaskId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID")
	private Orders orders;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TASK_ID")
	private BpmTask bpmTask;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TASK_CATEGORY_ID")
	private TaskCategory taskCategory;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TASK_STATUS_ID")
	private TaskStatus taskStatus;

	@Column(name = "ATTUID", nullable = true, length = 6)
	private String attuid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID")
	private Role role;

	@Column(name = "EXPEDITE", length = 1)
	private Character expedite;

	@Column(name = "OPEN_REMINDER", length = 1)
	private Character openReminder;

	@Column(name = "ACCOUNT_NAME", length = 100)
	private String accountName;

	@Column(name = "APN_NAME", length = 100)
	private String apnName;

	@Column(name = "SUBJECT", length = 100)
	private String subject;

	@Column(name = "CREATION_DATE")
	private Date creationDate;

	@Column(name = "COMPLETION_DATE")
	private Date completionDate;
	
	@Column(name = "ORDER_OPERATION", length = 50)
	private String orderOperation;
	
	@Column(name = "PROCESS_ID", length = 20)
	private Long processId;
	
	@Column(name = "DASHBOARD_FLAG", length = 1)
	private Character dashboardFlag;
	
	@Column(name = "DASHBOARD_LINK_COMPLETE", length = 1)
	private Character dashboardLinkComplete;
	
	@Column(name = "PROCESS_INSTANCE_ID", length = 300)
	private String processInstanceId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "OrderUserBpmTasks")
	private List<OrderUserTaskFaults> orderUserBpmTasksList = new ArrayList<>();
}