package com.att.comet.bpm.ttu.service;

import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;



public interface OSDTTUApplicabilityService {
	void preOperationOSDTTUApplicability(CommonBO commonBO) throws CamundaServiceException;
	void postOperationOSDTTUApplicability(CommonBO commonBO, String OSDComments, String isTTURequired) throws CamundaServiceException;
	
}
