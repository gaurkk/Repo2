package com.att.comet.bpm.decom.apniwos.helper;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.decom.apnhlr.helper.APNHLRDecomHelper;

@Component
public class APNIWOSDecomHelper {

	private static final Logger logger = LoggerFactory.getLogger(APNIWOSDecomHelper.class);

	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private OrderDAO orderDAO;

	public void preOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		logger.info("Start preOperationAPNIWOSDecom method ::", this);
		
		String assigneeNI = null;
		commonBO.setOrderContactTypeId(1007L); //Mapped with ORDER_CONTACT_TYPE ; Network Implementation
		assigneeNI = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeNI);
		
		/* Set Reminder1 & Reminder2 SLA Dates for APNIWOSDecom */
		genericDAO.setReminder1And2FromSlaWorkingDayForAPNIWOSDecom(commonBO);

		/* Save BpmOrderWorkStep */
		commonBO.setWorkStepId(1032L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		
		commonBO.setBpmProcessId(1014L); //Mapped with BPM_PROCESS table ; COMET DECOMMISSION PROCESS
		logger.info("End preOperationAPNIWOSDecom method ::", this);
	}

	public void postOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		logger.info("Start postOperationAPNIWOSDecom method ::", this);
		
		String assigneeNI = null;
		commonBO.setOrderContactTypeId(1007L); //Mapped with ORDER_CONTACT_TYPE ; Network Implementation
		assigneeNI = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAttuid(assigneeNI);
				
		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3091L);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3091L);
		commonBO.setBusinessStepStatus("DECOMMISSION_COMPLETE");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);

		/* Update OrderContactInfo */
		commonBO.setOrderContactTypeId(1007L);
		orderDAO.updateOrderContactInfo(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setWorkStepId(1032L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		logger.info("End postOperationAPNIWOSDecom method ::", this);
	}
}
