package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for TaskData. Mapped to TASK_INFO table in the database.
 */
@Entity
@Table(name = "TASKS")
public class Tasks implements java.io.Serializable {

	private static final long serialVersionUID = 5572583300951683499L;

	private Long taskDisplayId;
	private String taskId;
	private Long orderId;
	private String inventoryId; 
	private String taskDisplayName;
	private String subject;
	private String status;

	public Tasks() {
	}

	@Id
	@Column(name = "TASK_DISPLAY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_TASK_ID", strategy = "sequence", 
						parameters = {@Parameter(name = "sequence", value = "SEQ_TASK_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TASK_ID")
	public Long getTaskDisplayId() {
		return taskDisplayId;
	}

	public void setTaskDisplayId(Long taskDisplayId) {
		this.taskDisplayId = taskDisplayId;
	}

	@Column(name = "TASK_ID", unique = true, nullable = false, length = 64)
	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	@Column(name = "ORDER_ID", nullable = true, precision = 12, scale = 0)
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "INVENTORY_ID", nullable = true, length = 64)
	public String geInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(String inventoryId) {
		this.inventoryId = inventoryId;
	}

	@Column(name = "TASK_DISPLAY_NAME", nullable = false, length = 128)
	public String getTaskDisplayName() {
		return taskDisplayName;
	}

	public void setTaskDisplayName(String taskDisplayName) {
		this.taskDisplayName = taskDisplayName;
	}
	
	@Column(name = "SUBJECT", nullable = false, length = 256)
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	@Column(name = "STATUS", nullable = true, length = 16)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}

