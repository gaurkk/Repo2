package com.att.comet.bpm.dapn.dapncancellation.delegate;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.DapnInventoryDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;

@Component
public class DAPNCancellationDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(DAPNCancellationDelegate.class);

	@Autowired
	CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	DapnInventoryDAO dapnInventoryDAO;

	@Autowired
	OrderDAO orderDAO;

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = variables.get("OPERATION") != null ? (String) variables.get("OPERATION") : null;
			if (operationType != null) {
				switch (operationType) {
				case BpmConstant.DAPN_CANCELLATION_DAPN_OPERATION:
					dapnOPeration(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(DAPN_CANCELLATION_BPM_ERROR_CODE should be same for delegate and BPMN
			 * mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.DAPN_CANCELLATION_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void dapnOPeration(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start dapnOPeration method ::", this);
		Map<String, Object> variables = execution.getVariables();
		Long orderId = variables.get(BpmConstant.ORDER_ID) != null ? (Long) variables.get(BpmConstant.ORDER_ID) : null;
		CommonBO commonBO = commonService.getDapnCommonBO(orderId);
		commonBO.setUpdatedOn(new Date());
		// update order

		commonBO.setOrderStatusId(1003L);
		orderDAO.updateOrders(commonBO);
		// save OrderStatusHistory
		orderDAO.saveOrderStatusHistory(commonBO);

		// save DapnInventoryByOrderId
		dapnInventoryDAO.saveDapnInventoryByOrderId(orderId);

		dapnInventoryDAO.updateDapnInventoryByOrderIdAndId(orderId);

		dapnInventoryDAO.updateDapnInventoryByOrderId(orderId);
		logger.info("End dapnOPeration method ::", this);
	}
}
