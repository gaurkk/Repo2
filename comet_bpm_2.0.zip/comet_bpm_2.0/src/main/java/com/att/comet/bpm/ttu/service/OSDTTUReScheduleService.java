package com.att.comet.bpm.ttu.service;

import java.text.ParseException;
import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OSDTTUReScheduleService {
	void postOperationOSDTTUReSchedule(CommonBO commonBO, String reasonForReschedule, String rescheduleDate) throws CamundaServiceException, ParseException;
	void preOperationOSDTTUReSchedule(CommonBO commonBO) throws CamundaServiceException;
}
