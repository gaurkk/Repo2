package com.att.comet.bpm.core.processes.delegate;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.service.CoreProcessService;
@Component
public class CancelOrderBpmDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(CancelOrderBpmDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	private CoreProcessService coreProcessService;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.CANCEL_ORDER_PRE_OPERATION:
					cancelOrderPreOperation(execution);
					break;
				case BpmConstant.PENDING_TASK_STATUS:
					pendingTaskStatusCheck(execution);
					break;
				case BpmConstant.COMPLETE_PROCESS:
					completeProcess(execution);
					break;
				case BpmConstant.CHECK_USER_DECESION:
					userDecisionCheck(execution);
					break;
				case BpmConstant.CANCEL_ORDER_POST_OPERATION:
					cancelOrderPostOperation(execution);
					break;
				}
			}

		} catch (Exception e) {
			logger.error("Comet request does not have::" + new CamundaServiceException("DB Operation failure Cancel Order Delegate"), this);
			throw new BpmnError("ERROR_BPM_001", "CANCEL ORDER EXCEPTION");
		}
	}
	private void cancelOrderPreOperation(DelegateExecution execution) {
		logger.info("Starting cancelOrderPreOperation method ");
		CommonBO commonBO = null;
		String cancelOrderProcessInstanceId = null;
		cancelOrderProcessInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
					execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
					execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
					execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessId(1020L);
					commonBO.setBpmProcessInstanceId(cancelOrderProcessInstanceId);
					coreProcessService.cancelOrderPreOperation(commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed in Cancel Order Pre Opration"));
		}

		logger.info("Exiting cancelOrderPreOperation method ");
	}
	private void pendingTaskStatusCheck(DelegateExecution execution) {
		logger.info("Starting pendingTaskStatusCheck method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			
			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				coreProcessService.pendingTaskStatusCheck(commonBO);
				
				execution.setVariable(BpmConstant.OM_TASK_STATUS, commonBO.getOmTaskStatus());
				execution.setVariable(BpmConstant.APN_IT_OPS_TASK_STATUS, commonBO.getApnItOpsTaskStatus());
				execution.setVariable(BpmConstant.APN_IWOS_TASK_STATUS, commonBO.getApnIwosTaskStatus());
				execution.setVariable(BpmConstant.TTU_PREFLIGHT_TASK_STATUS, commonBO.getTtuPreflightTaskStatus());
				execution.setVariable(BpmConstant.TTU_APPLICABILITY_TASK_STATUS, commonBO.getTtuApplicabilityTaskStatus());
				execution.setVariable(BpmConstant.TTU_PERFORM_TASK_STATUS, commonBO.getTtuPerformTaskStatus());
				execution.setVariable(BpmConstant.TTU_RESCHEDULE_TASK_STATUS, commonBO.getTtuRescheduleTaskStatus());
				execution.setVariable(BpmConstant.TTU_RESULT_TASK_STATUS, commonBO.getTtuResultTaskStatus());
				execution.setVariable(BpmConstant.TTU_SCHEDULE_TASK_STATUS, commonBO.getTtuScheduleTaskStatus());
				commonServiceHelper.terminateAllTasks(commonBO, execution);

			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

			}

		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure TASK STATUS"), this);
			throw new BpmnError("ERROR_BPM_001", "CANCEL ORDER");
		}

		logger.info("Ending pendingTaskStatusCheck method ");
	}
	private void completeProcess(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting completeProcess method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			if (commonBO != null) {
				commonServiceHelper.terminateAllTasks(commonBO, execution);
				logger.info("All In-Progress Task have been completed for OrderId: "+commonBO.getOrderId(),this);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			}
		} catch (Exception e) {
			execution.setVariable("ERROR_CODE", "ErrorCodeConstant.COMET_MB001");
			throw new CamundaServiceException("In proper request from comet app");
		}
		logger.info("Ending completeProcess method ");
		
	}
	private void userDecisionCheck(DelegateExecution execution) {
		logger.info("Starting userDecisionCheck method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			
			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				coreProcessService.userDecisionCheck(commonBO);		
				execution.setVariable(BpmConstant.APN_IWOS_HLR_USER_DECISION, commonBO.getApnIwosUserDecision()); // need to change and take the value from DB
				execution.setVariable(BpmConstant.BILLING_USER_DECISION, commonBO.getBillingUserDecision());
		
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}

		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure getting User Decision"), this);
			throw new BpmnError("ERROR_BPM_001", "CANCEL ORDER");
		}
		logger.info("Ending userDecisionCheck method ");
	}
	private void cancelOrderPostOperation(DelegateExecution execution) {
		logger.info("Starting cancelOrderPostOperation method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			
			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				coreProcessService.cancelOrderPostOperation(commonBO);
				commonBO.setApproved(BpmConstant.APPROVED);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure Post Operation"), this);
			throw new BpmnError("ERROR_BPM_001", "CANCEL ORDER");
		}
		logger.info("Ending cancelOrderPostOperation method ");
		
	}
		
	

}
