package com.att.comet.bpm.common.dao.impl;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.OrderContact;
import com.att.comet.bpm.common.hibernate.bean.OrderContactInfo;
import com.att.comet.bpm.common.hibernate.bean.OrderContactInfoId;
import com.att.comet.bpm.common.hibernate.bean.Users;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderContactInfoRepository;
import com.att.comet.bpm.common.repository.OrderContactRepository;
@Component
public class OrderContactInfoDAOImpl implements OrderContactInfoDAO{
	private static final Logger logger = LoggerFactory.getLogger(OrderContactInfoDAOImpl.class);
	@Autowired
	private OrderContactInfoRepository orderContactInfoRepository;
	@Autowired
	private OrderContactRepository orderContactRepository;
	

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void updateOrderContactInfoForAttUidByOrderContactDetails(CommonBO commonBO) throws CamundaServiceException{
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)+ "] " ,this);
		String sql = "update order_contact_info set attuid=:attid "
				+ "where order_contact_id=(select order_contact_id from order_contact where order_id=:orderId) "
				+ "and  order_contact_type_id=:orderContactTypeId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("attid", commonBO.getAttuid());
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("orderContactTypeId", commonBO.getOrderContactTypeId());
		query.executeUpdate();
		logger.info("@Ending updateOrderContactInfoForAttUidByOrderContactDetails" ,this);
	}
	
	@Override
	public void updateOrderContactInfo(CommonBO commonBO) throws CamundaServiceException{
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)+ "] " ,this);
		OrderContact contactInfo = orderContactRepository.findByOrders_orderId(commonBO.getOrderId());
		Long orderContactId = contactInfo.getOrderContactId();
		commonBO.setOrderContactId(orderContactId);
		OrderContactInfoId orderContactInfoId = new OrderContactInfoId();
		orderContactInfoId.setOrderContactId(commonBO.getOrderContactId());
		orderContactInfoId.setOrderContactTypeId(commonBO.getOrderContactTypeId()); //order_contact_type_id=1003"
		Optional<OrderContactInfo> optional = orderContactInfoRepository.findById(orderContactInfoId);
		if (optional.isPresent()) {
			OrderContactInfo orderContactInfo = optional.get();
			logger.info("[orderContactInfo : " + (orderContactInfo == null ? "" : orderContactInfo)+ "] " ,this);
			Users users = new Users();
			users.setAttuid(commonBO.getUpdatedBy());
			orderContactInfo.setUsers(users);
			orderContactInfoRepository.save(orderContactInfo);
		}
		
	}
}
