package com.att.comet.bpm.oabilling.service;

import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.oabilling.helper.OABillingHelper;

@Service
public class OABillingSubmissionServiceImpl implements OABillingSubmissionService {
	private static final Logger logger = LoggerFactory.getLogger(OABillingSubmissionServiceImpl.class);
	@Autowired
	CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	OABillingHelper oaBillingHelper;
	@Autowired
	OrderDAO orderDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	
	@Override
	public void preOperationOABilling(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		oaBillingHelper.oaBillingPreOprCRUD(commonBO, processInstanceId);
	}

	@Override
	public void operationOABillingTask(CommonBO commonBO) throws CamundaServiceException {
		oaBillingHelper.oaBillingTaskCRUD(commonBO);
	}

	@Override
	public void postOperationOABilling(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {

		oaBillingHelper.oaBillingPostOprCRUD(commonBO, execution);
		commonBO.setProcessId(1003L);// APN HLR IWOS PROCESS
		commonBO.setBpmProcessId(1003L);// APN HLR IWOS PROCESS
		Orders order = new Orders();
		Long taskId = 0L;
		order.setOrderId(commonBO.getOrderId());
		if (commonBO.getOrderOperation().equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
			taskId = 1030L;
			commonBO.setTaskId(1030L);// BPM_TASK table , TASK_NAME = OA : Billing Request - Submission(CR)
		} else {
			taskId = 1020L;
			commonBO.setTaskId(1020L);// BPM_TASK table , TASK_NAME = OA : Billing Request - Submission
		}
		commonBO.setOrderOperation(commonBO.getOrderOperation());
		// Long taskId = 1014L;
		commonBO.setTaskId(commonBO.getTaskId());
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if (null != orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			// (1028L);//Mapped from BPM_task table (CR OA : Approval Task)
			if (taskId.equals(commonBO.getTaskId())) {
				// logger.info("Task ID request " + 1021L, this);
				for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
					if (taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()) && taskObj.getTaskStatus().getTaskStatusId().equals(1001L)) {
						commonBO.setBpmTaskId(taskObj.getBpmTaskId());
						commonBO.setTaskDescription(taskObj.getSubject());
						break;
					} else {
						logger.info("bpmTaskId is null for orderId ::  " + commonBO.getOrderId()
								+ " for the task :: " + commonBO.getTaskId());
					}
				}
			}
		}
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L); // TASK_CATEGORY table , TASK_CATEG_DESC = SERVICE
		commonBO.setTaskStatusId(1002L); // TASK_STATUS table , TASK_STATUS_DESC = COMPLETED
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		
		Long count = orderDAO.countOrderEvent(commonBO);
		if(count.equals(1L) && taskId.equals(1020L)) {
			logger.info("@@@ Pick Operation for Change Request @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
		}else if(commonBO.getOrderTypeId().equals(1004L)){
			logger.info("@@@ Pick Operation for Change Order @@@ "+commonBO.getOrderId(), this);
			commonServiceHelper.pickOperationForBillingTask(commonBO, execution);
			
		}else {
			logger.info(" @@@ No Change Request created against the order id :::  @@@  "+commonBO.getOrderId(), this);
		}
	}

}
