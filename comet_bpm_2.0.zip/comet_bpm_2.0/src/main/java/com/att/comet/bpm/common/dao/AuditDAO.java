package com.att.comet.bpm.common.dao;

import java.util.List;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;



public interface AuditDAO {
	void updateAuditOrders(CommonBO commonBO) throws CamundaServiceException;

	int getMaxEventId(Long orderId);
	
	List<Object[]> getAuditOrders(CommonBO commonBO, int eventId);

	void saveOrderStatusIdByOrderId(CommonBO commonBO) throws CamundaServiceException;

}
