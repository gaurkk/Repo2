package com.att.comet.bpm.common.dao.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.OrderStatusHistoryDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class OrderStatusHistoryDAOImpl implements OrderStatusHistoryDAO{

	private static final Logger logger = LoggerFactory.getLogger(OrderStatusHistoryDAOImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void saveOshByOrderIdAndOsIdUpdatedBy(CommonBO commonBO) throws CamundaServiceException{
		logger.info("@Starting method saveOshByOrderIdAndOsIdUpdatedBy ",this);
		Date today = new Date();
		String sql = "insert into order_status_history (order_status_history_id,order_id,order_status_id,updated_by,updated_on) values(seq_order_status_history_id.nextval,?,?,?,?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getOrderStatusId());
		if(null==commonBO.getOrderApprover()) {
			//Rejected case only
		query.setParameter(3, commonBO.getUpdatedBy());
		}else {
			//Approval case only 
		query.setParameter(3, commonBO.getOrderApprover());
		}
		query.setParameter(4, today);
		query.executeUpdate();
		logger.info("@Ending method saveOshByOrderIdAndOsIdUpdatedBy ",this);
	}
}
