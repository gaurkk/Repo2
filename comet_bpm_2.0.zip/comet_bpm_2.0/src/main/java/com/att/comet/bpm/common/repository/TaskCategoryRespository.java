package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.bpm.common.hibernate.bean.TaskCategory;

public interface TaskCategoryRespository extends JpaRepository<TaskCategory, Long>{

}
