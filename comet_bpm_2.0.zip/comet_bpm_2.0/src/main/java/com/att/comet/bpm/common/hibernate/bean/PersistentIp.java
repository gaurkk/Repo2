package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for PersistentIp. Mapped to PERSISTENT_IP table in the
 * database.
 */
@Entity
@Table(name = "PERSISTENT_IP")
public class PersistentIp implements Serializable {

	private static final long serialVersionUID = 7581486368716789437L;

	private Long persistentIpId;
	private String ipAddress;
	private String username;
	private String password;
	private Apn apn;

	/**
	 * Getter method for persistentIpId. PERSISTENT_IP_ID mapped to
	 * PERSISTENT_IP_ID in the database table. The sequence used to generate the
	 * persistentIpId is SEQ_PERSISTENT_IP_ID
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "PERSISTENT_IP_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_PERSISTENT_IP_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_PERSISTENT_IP_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PERSISTENT_IP_ID")
	public Long getPersistentIpId() {
		return persistentIpId;
	}

	/**
	 * @param persistentIpId
	 *            to persistentIpId set.
	 */
	public void setPersistentIpId(Long persistentIpId) {
		this.persistentIpId = persistentIpId;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for ipAddress. IP_ADDRESS mapped to IP_ADDRESS in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * @param ipAddress
	 *            to ipAddress set.
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Getter method for username. USERNAME mapped to USERNAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "USERNAME", length = 100)
	public String getUsername() {
		return this.username;
	}

	/**
	 * @param username
	 *            to username set.
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Getter method for password. PASSWORD mapped to PASSWORD in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "PASSWORD", length = 100)
	public String getPassword() {
		return this.password;
	}

	/**
	 * @param password
	 *            to password set.
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}