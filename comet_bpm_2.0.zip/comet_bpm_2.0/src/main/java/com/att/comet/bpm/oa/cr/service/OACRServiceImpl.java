package com.att.comet.bpm.oa.cr.service;


import java.net.URISyntaxException;
import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.oa.cr.helper.OACRHelper;

@Service
public class OACRServiceImpl implements OACRService{
	private static final Logger logger = LoggerFactory.getLogger(OACRServiceImpl.class);
	@Autowired
	OACRHelper oaCRHelper;
	@Autowired
	CommonService commonService;
	@Override
	public CommonBO processDBInteractionOperation(CommonBO commonBO, String processInstanceId)
			throws CamundaServiceException {
		logger.info("Start processDBInteractionOperation method ::", this);
		return oaCRHelper.processDBInteractionOperation(commonBO, processInstanceId);
		
		
	}
	@Override
	public CommonBO postOperation(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException, URISyntaxException {
		logger.info("Start postOperation method ::", this);
		return oaCRHelper.postOperation(commonBO,  execution);
	}
	@Override
	public void rejected(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start rejected method ::", this);
		oaCRHelper.rejected(commonBO);
		commonBO.setTaskStatusId(1002L);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setRoleId(1002L);
		commonBO.setCategoryId(1003L);
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}
	@Override
	public void approved(CommonBO commonBO) throws CamundaServiceException {
		logger.info("Start approved method ::", this);
		oaCRHelper.approved(commonBO);
		commonBO.setTaskStatusId(1002L);
		commonBO.setRoleId(1002L);
		commonBO.setTaskCompletionTime(new Date());
		//commonBO.setTaskId(1028L);
		commonBO.setCategoryId(1003L);
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
