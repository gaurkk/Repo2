package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "IMSI_MSISDN_INVENTORY")
public class ImsiMsisdnInventory implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private ImsiMsisdnDataCenterId imsiMsisdnDataCenterId;
	private DataCenter dataCenter;
	private Long orderId;

	/**
	 * @return the insideOutsideDataCenterId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "imsiMsisdn", column = @Column(name = "IMSI_MSISDN", nullable = false, length = 100)) })
	public ImsiMsisdnDataCenterId getImsiMsisdnDataCenterId() {
		return imsiMsisdnDataCenterId;
	}

	/**
	 * @param imsiMsisdnDataCenterId the imsiMsisdnDataCenterId to set
	 */
	public void setImsiMsisdnDataCenterId(ImsiMsisdnDataCenterId imsiMsisdnDataCenterId) {
		this.imsiMsisdnDataCenterId = imsiMsisdnDataCenterId;
	}

	/**
	 * @return the dataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return dataCenter;
	}

	/**
	 * @param dataCenter the dataCenter to set
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * @return the orderId
	 */
	@Column(name = "ORDER_ID", nullable = true, precision = 12, scale = 0)
	public Long getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

}
