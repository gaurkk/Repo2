package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "EMAIL_TEMPLATE_INFORMATION")
public class EmailTemplateInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8170391383049548032L;

	private Long emailTemplateId;
	private String emailTemplateName;
	private String from;
	private String toList;
	private String ccList;
	private String messageHeader;
	private String messageFooter;
	private String message;
	private String subject;

	@Id
	@Column(name = "Email_Template_Id", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_EMAIL_TEMPLATE_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_EMAIL_TEMPLATE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_EMAIL_TEMPLATE_ID")
	public Long getEmailTemplateId() {
		return emailTemplateId;
	}

	public void setEmailTemplateId(Long emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	@Column(name = "Email_Template_Name", length = 100)
	public String getEmailTemplateName() {
		return emailTemplateName;
	}

	public void setEmailTemplateName(String emailTemplateName) {
		this.emailTemplateName = emailTemplateName;
	}

	@Column(name = "From_user", length = 100)
	public String getFrom() {
		return from;
	}

	public void setFrom(String fromList) {
		this.from = fromList;
	}

	@Column(name = "TO_List", length = 100)
	public String getToList() {
		return toList;
	}

	public void setToList(String toList) {
		this.toList = toList;
	}

	@Column(name = "CC_List", length = 200)
	public String getCcList() {
		return ccList;
	}

	public void setCcList(String ccList) {
		this.ccList = ccList;
	}

	@Column(name = "Message_Header", length = 100)
	public String getMessageHeader() {
		return messageHeader;
	}

	public void setMessageHeader(String messageHeader) {
		this.messageHeader = messageHeader;
	}

	@Column(name = "Message_Footer", length = 100)
	public String getMessageFooter() {
		return messageFooter;
	}

	public void setMessageFooter(String messageFooter) {
		this.messageFooter = messageFooter;
	}

	@Column(name = "Message", length = 500)
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Column(name = "Subject", length = 100)
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
}
