package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for APN_RADIUS. Mapped to APN_RADIUS table in the database.
 */
@Entity
@Table(name = "APN_RADIUS")
public class ApnRadius implements Serializable {

	private static final long serialVersionUID = -4255705217535269729L;

	private ApnRadiusId id;
	private DataCenter dataCenter;
	private Apn apn;
	private Long custRadServer;
	private String rasClientIp;
	private Set<ApnCustomerRadius> apnCustomerRadiuses = new HashSet<ApnCustomerRadius>();

	/**
	 * Getter method for id.
	 * 
	 * @return ApnRadiusId
	 */
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public ApnRadiusId getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            to id set.
	 */
	public void setId(ApnRadiusId id) {
		this.id = id;
	}

	/**
	 * Getter method for dataCenter. DATA_CENTER_ID mapped to DATA_CENTER_ID of
	 * the database table.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 *            to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for apn. ORDER_ID mapped to ORDER_ID of the database table.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for custRadServer. CUST_RAD_SERVER mapped to
	 * CUST_RAD_SERVER in database table.
	 * 
	 * @return Long
	 */
	@Column(name = "CUST_RAD_SERVER", length = 12)
	public Long getCustRadServer() {
		return this.custRadServer;
	}

	/**
	 * @param custRadServer
	 *            to custRadServer set.
	 */
	public void setCustRadServer(Long custRadServer) {
		this.custRadServer = custRadServer;
	}

	/**
	 * Getter method for rasClientIp. RAS_CLIENT_IP mapped to RAS_CLIENT_IP in
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "RAS_CLIENT_IP", length = 100)
	public String getRasClientIp() {
		return this.rasClientIp;
	}

	/**
	 * @param rasClientIp
	 *            to rasClientIp set.
	 */
	public void setRasClientIp(String rasClientIp) {
		this.rasClientIp = rasClientIp;
	}

	/**
	 * Getter method for apnCustomerRadiuses.
	 * 
	 * @return Set<ApnCustomerRadius>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "apnRadius")
	public Set<ApnCustomerRadius> getApnCustomerRadiuses() {
		return this.apnCustomerRadiuses;
	}

	/**
	 * @param apnCustomerRadiuses
	 *            to apnCustomerRadiuses set.
	 */
	public void setApnCustomerRadiuses(
			Set<ApnCustomerRadius> apnCustomerRadiuses) {
		this.apnCustomerRadiuses = apnCustomerRadiuses;
	}
}