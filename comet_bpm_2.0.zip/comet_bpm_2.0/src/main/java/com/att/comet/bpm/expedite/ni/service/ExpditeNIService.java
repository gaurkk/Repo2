package com.att.comet.bpm.expedite.ni.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ExpditeNIService {
	public void preOperation(CommonBO commonBO) throws CamundaServiceException;
	public void postOperation(CommonBO commonBO) throws CamundaServiceException;
}
