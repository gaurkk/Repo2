package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for OrderDataCenter. Mapped to ORDER_DATA_CENTER table in the database.
 */
@Entity
@Table(name = "ORDER_DATA_CENTER")
public class OrderDataCenter implements java.io.Serializable {

	private static final long serialVersionUID = 8054965568725364834L;

	private OrderDataCenterId id;
	private Orders orders;
	private DataCenter dataCenter;
	private Long numNewBackhauls;
	private Character active;
	private String prDcRouterFailoverConfig;
	private String activeRouter;
	private String activeInterface;
	private Character dataCenterType;
	private Integer dcSortOrder;
	private Character snapActive;  

	/**
	 * Getter method for id. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return OrderDataCenterId
	 */
	@EmbeddedId
	@AttributeOverrides( { @AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public OrderDataCenterId getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            to id set.
	 */
	public void setId(OrderDataCenterId id) {
		this.id = id;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 *            to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for numNewBackhauls. NUM_NEW_BACKHAULS mapped to NUM_NEW_BACKHAULS in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "NUM_NEW_BACKHAULS", nullable = false, precision = 12, scale = 0)
	public Long getNumNewBackhauls() {
		return this.numNewBackhauls;
	}

	/**
	 * @param numNewBackhauls
	 *            to numNewBackhauls set.
	 */
	public void setNumNewBackhauls(Long numNewBackhauls) {
		this.numNewBackhauls = numNewBackhauls;
	}

	/**
	 * Getter method for active. ACTIVE mapped to ACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ACTIVE", nullable = false, length = 1)
	public Character getActive() {
		return this.active;
	}

	/**
	 * @param active
	 *            to active
	 */
	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for prDcRouterFailoverConfig. PR_DC_ROUTER_FAILOVER_CONFIG mapped to PR_DC_ROUTER_FAILOVER_CONFIG in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "PR_DC_ROUTER_FAILOVER_CONFIG", length = 100)
	public String getPrDcRouterFailoverConfig() {
		return this.prDcRouterFailoverConfig;
	}

	/**
	 * @param prDcRouterFailoverConfig
	 *            to prDcRouterFailoverConfig set.
	 */
	public void setPrDcRouterFailoverConfig(String prDcRouterFailoverConfig) {
		this.prDcRouterFailoverConfig = prDcRouterFailoverConfig;
	}

	/**
	 * Getter method for activeRouter. ACTIVE_ROUTER mapped to ACTIVE_ROUTER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ACTIVE_ROUTER", length = 100)
	public String getActiveRouter() {
		return this.activeRouter;
	}

	/**
	 * @param activeRouter
	 *            to activeRouter set.
	 */
	public void setActiveRouter(String activeRouter) {
		this.activeRouter = activeRouter;
	}

	/**
	 * Getter method for activeInterface. ACTIVE_INTERFACE mapped to ACTIVE_INTERFACE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ACTIVE_INTERFACE", length = 100)
	public String getActiveInterface() {
		return this.activeInterface;
	}

	/**
	 * @param activeInterface
	 *            to activeInterface set.
	 */
	public void setActiveInterface(String activeInterface) {
		this.activeInterface = activeInterface;
	}

	/**
	 * Getter method for dataCenterType. DATA_CENTER_TYPE mapped to DATA_CENTER_TYPE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "DATA_CENTER_TYPE", nullable = false, length = 1)
	public Character getDataCenterType() {
		return dataCenterType;
	}

	/**
	 * @param dataCenterType
	 *            to dataCenterType set.
	 */
	public void setDataCenterType(Character dataCenterType) {
		this.dataCenterType = dataCenterType;
	}

	/**
	 * @return the dcSortOrder
	 */
	@Column(name = "DC_SORT_ORDER", nullable = false, precision = 12, scale = 0)
	public Integer getDcSortOrder() {
		return dcSortOrder;
	}

	/**
	 * @param dcSortOrder
	 *            the dcSortOrder to set
	 */
	public void setDcSortOrder(Integer dcSortOrder) {
		this.dcSortOrder = dcSortOrder;
	}
	
	/**
	 * Getter method for snapActive. SNAPACTIVE mapped to SNAPACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "SNAPACTIVE", nullable = true, length = 1)
	public Character getSnapActive() {
		return snapActive;
	}
	
	/**
	 * @param snapActive
	 *            to snapActive
	 */
	public void setSnapActive(Character snapActive) {
		this.snapActive = snapActive;
	}
	
	

}