package com.att.comet.bpm.core.processes.delegate;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.codashboard.delegate.NiRollbackTaskDelegate;
import com.att.comet.bpm.codashboard.service.NiRollbackTaskService;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.service.ExpediteOrderService;

@Component
public class ExpediteOrderBpmDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(ExpediteOrderBpmDelegate.class);
	@Autowired
	ExpediteOrderService expediteOrderService;
	@Autowired
	CommonService commonService;
	@Autowired
	OrderDAO orderDAO;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {

				case BpmConstant.PRE_EXPEDITE_OPERATION:
					expeditePreOperation(execution);
					break;
				case BpmConstant.EXPEDITE_FLAG_BEFORE:
					setExpediteFlagBefore(execution);
					break;
				case BpmConstant.EXPEDITE_FLAG_AFTER:
					setExpediteFlagAfter(execution);
					break;
				case BpmConstant.REJECTED_BY_OA:
					expediteRejectedByOA(execution);
					break;
				case BpmConstant.REJECTED_BY_OM:
					expediteRejectedByOM(execution);
					break;
				case BpmConstant.POST_EXPEDITE_OPERATION:
					expeditePostOperation(execution);
					break;
				}
			}

		} catch (Exception e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure EXPEDITE ORDER"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE ORDER EXCEPTION");
		}
	}

	private void setExpediteFlagBefore(DelegateExecution execution) {
		logger.info("Starting setExpediteFlagBefore method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			expediteOrderService.setExpediteFlagBefore(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure setExpediteFlagBefore"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Starting setExpediteFlagBefore method ");

	}

	private void setExpediteFlagAfter(DelegateExecution execution) {
		logger.info("Starting setExpediteFlagAfter method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			expediteOrderService.setExpediteFlagAfter(commonBO);
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure setExpediteFlagAfter"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Starting setExpediteFlagAfter method ");

	}

	private void expeditePreOperation(DelegateExecution execution) {
		logger.info("Starting expeditePreOperation method ");
		CommonBO commonBO = null;
		String expediteOrderProcessInstanceId = null;
		expediteOrderProcessInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
					execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
					execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
					execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
					execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
					execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
					execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName());
					execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
					execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
					execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessInstanceId(expediteOrderProcessInstanceId);
					expediteOrderService.preOperation(commonBO);
		
					execution.setVariable("apnIwosCreationTaskStatus", commonBO.getApnIwosTaskStatus());
					
					
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed in Expedite Order Pre Opration"));
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}

		logger.info("Exiting expeditePreOperation method ");

	}

	private void expeditePostOperation(DelegateExecution execution) {
		logger.info("Starting expeditePostOperation method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			expediteOrderService.postOperation(commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure setExpediteFlagAfter"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Exiting expeditePostOperation method ");

	}
	private void expediteRejectedByOA(DelegateExecution execution) {
		logger.info("Starting expediteRejectedByOA method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		String response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOaComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOaComments);
		try {
			expediteOrderService.rejectedByOA(commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure expediteRejectedByOA"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Exiting expediteRejectedByOA method ");

	
	}
	private void expediteRejectedByOM(DelegateExecution execution) {
		logger.info("Starting expediteRejectedByOM method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		String response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOmComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOmComments);
		try {
			expediteOrderService.rejectedByOM(commonBO);
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure expediteRejectedByOM"), this);
			throw new BpmnError("ERROR_BPM_001", "EXPEDITE_ORDER_EXCEPTION");
		}
		logger.info("Exiting expediteRejectedByOM method ");

	
	}

}
