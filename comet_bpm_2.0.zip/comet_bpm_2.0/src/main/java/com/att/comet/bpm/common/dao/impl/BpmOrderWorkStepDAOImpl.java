package com.att.comet.bpm.common.dao.impl;

import java.util.Date;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStepId;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.BpmOrderWorkStepRepository;


@Component
public class BpmOrderWorkStepDAOImpl implements BpmOrderWorkStepDAO{
	private static final Logger logger = LoggerFactory.getLogger(BpmOrderWorkStepDAOImpl.class);
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	BpmOrderWorkStepRepository bpmOrderWorkStepRepository;
	
	@Override
	public void deleteBpmOrderWorkStepForOrderIdAndWorkStepId(CommonBO commonBO) throws CamundaServiceException{
		logger.debug("@Starting deleteBpmOrderWorkStepForOrderIdAndWorkStepId", this);
		String sql = "delete from bpm_order_work_step where order_id=:orderId and work_step_id=:workStepId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("workStepId", commonBO.getWorkStepId());
		query.executeUpdate();
		logger.debug("@Ending deleteBpmOrderWorkStepForOrderIdAndWorkStepId", this);
	}
	
	@Override
	public void updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(CommonBO commonBO) throws CamundaServiceException{
		logger.debug("@Starting updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn", this);
		Date today = new Date();
		String sql = "UPDATE BPM_ORDER_WORK_STEP SET bpm_status_id=:bpmStepId, UPDATED_ON=:updatedOn,DISPLAY_FLAG=:displayFlag WHERE WORK_STEP_ID=:workStepId AND ORDER_ID=:orderId AND ORDER_TYPE_ID=(SELECT ORDER_TYPE_ID FROM ORDER_TYPE WHERE LOWER(ORDER_TYPE_NAME)=:orderType)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("bpmStepId", commonBO.getBpmStepId());
		query.setParameter("updatedOn", today);
		query.setParameter("workStepId", commonBO.getWorkStepId());
		query.setParameter("orderId", commonBO.getOrderId());
		query.setParameter("orderType", commonBO.getOrderTypeName());
		if(commonBO.getDisplayFlag()!=' ') {
		query.setParameter("displayFlag", commonBO.getDisplayFlag());
		}
		query.executeUpdate();
		logger.debug("@Ending updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn", this);
	}

	@Override
	public Date getUpdatedOnFromBpmOrderWorkStep(CommonBO commonBO) {
		logger.debug("@Starting getUpdatedOnFromBpmOrderWorkStep", this);
		
	    Date updatedOn = null;
		BpmOrderWorkStepId bpmOrderWorkStepId = new BpmOrderWorkStepId();
		bpmOrderWorkStepId.setOrderId(commonBO.getOrderId());
		bpmOrderWorkStepId.setOrderTypeId(commonBO.getOrderTypeId());
		bpmOrderWorkStepId.setWorkStepId(commonBO.getWorkStepId());
		
		Optional<BpmOrderWorkStep> bpmOrderWorkStepOp = bpmOrderWorkStepRepository.findById(bpmOrderWorkStepId);
		if(bpmOrderWorkStepOp.isPresent())
		{ 
			BpmOrderWorkStep bpmOrderWorkStep = bpmOrderWorkStepOp.get();
			updatedOn = bpmOrderWorkStep.getUpdatedOn();
		}
		logger.debug("@Ending getUpdatedOnFromBpmOrderWorkStep", this);
		return updatedOn;
	}
}
