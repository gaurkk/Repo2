package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "INOUT_INTERFACE")
public class InOutInterfaceBaseInterface implements java.io.Serializable {
	private static final long serialVersionUID = 3538013363480413683L;

	private int id;
	private String dataCenter;
	private String insideBase;
	private String outsideBase;

	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_INOUT_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_INOUT_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INOUT_ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "DATACENTER", length = 20)
	public String getDataCenter() {
		return dataCenter;
	}

	public void setDataCenter(String dataCenter) {
		this.dataCenter = dataCenter;
	}

	@Column(name = "INSIDE_BASE", length = 10)
	public String getInsideBase() {
		return insideBase;
	}

	public void setInsideBase(String insideBase) {
		this.insideBase = insideBase;
	}

	@Column(name = "OUTSIDE_BASE", length = 10)
	public String getOutsideBase() {
		return outsideBase;
	}

	public void setOutsideBase(String outsideBase) {
		this.outsideBase = outsideBase;
	}
}