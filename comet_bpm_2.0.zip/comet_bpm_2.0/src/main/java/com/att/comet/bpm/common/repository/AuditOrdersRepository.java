package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.comet.bpm.common.hibernate.bean.AuditOrders;


public interface AuditOrdersRepository extends JpaRepository<AuditOrders, Long>{

	@Query(value="select max(eventId) from AuditOrders where orderId=:orderId")
	Long getMaxEventId(@Param(value="orderId") Long orderId);
	
	@Modifying
	@Query(value = "update AuditOrders set order_status_id =:orderStatusId where orderId=:orderId")
	public void updateOrderStatusIdByOrderId(Long orderId, Long orderStatusId);
}
