package com.att.comet.bpm.codashboard.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OABillingCancellationService {
	void preOperationOABilling(CommonBO commonBO, String processInstanceId) throws CamundaServiceException;
	
	void operationOABillingTask(CommonBO commonBO) throws CamundaServiceException;

	void postOperationOABilling(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

}
