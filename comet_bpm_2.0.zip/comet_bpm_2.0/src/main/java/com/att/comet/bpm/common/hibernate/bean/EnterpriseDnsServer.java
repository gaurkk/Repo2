/**
 * 
 */
package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 *
 */
@Entity
@Table(name = "ENTERPRISE_DNS_SERVER")
public class EnterpriseDnsServer implements Serializable{
	private static final long serialVersionUID = 506545787827325698L;
	
	private Long enterpriseServerId;
	private DataCenter dataCenter;
	private Apn apn;
	private String primaryEntServerIp;
	private String secondaryEntServerIp;
	private String dnsServerNotes;
	private String apnProtocol;
	
	/**
	 * @return the enterpriseServerId
	 */
	@Id
	@Column(name = "ENTERPRISE_SERVER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ENTERPRISE_DNS_SERVER_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ENTERPRISE_DNS_SERVER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ENTERPRISE_DNS_SERVER_ID")
	public Long getEnterpriseServerId() {
		return enterpriseServerId;
	}
	/**
	 * @param enterpriseServerId the enterpriseServerId to set
	 */
	public void setEnterpriseServerId(Long enterpriseServerId) {
		this.enterpriseServerId = enterpriseServerId;
	}
	/**
	 * @return the dataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false)
	public DataCenter getDataCenter() {
		return dataCenter;
	}
	/**
	 * @param dataCenter the dataCenter to set
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}
	/**
	 * @return the apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return apn;
	}
	/**
	 * @param apn the apn to set
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}
	/**
	 * @return the primaryEntServerId
	 */
	@Column(name = "PRIMARY_ENT_SERVER_ID", length = 100)
	public String getPrimaryEntServerIp() {
		return primaryEntServerIp;
	}
	/**
	 * @param primaryEntServerIp the primaryEntServerId to set
	 */
	public void setPrimaryEntServerIp(String primaryEntServerIp) {
		this.primaryEntServerIp = primaryEntServerIp;
	}
	/**
	 * @return the secondaryEntServerId
	 */
	@Column(name = "SECONDARY_ENT_SERVER_ID", length = 100)
	public String getSecondaryEntServerIp() {
		return secondaryEntServerIp;
	}
	/**
	 * @param secondaryEntServerIp the secondaryEntServerId to set
	 */
	public void setSecondaryEntServerIp(String secondaryEntServerIp) {
		this.secondaryEntServerIp = secondaryEntServerIp;
	}
	/**
	 * @return the dnsServerNotes
	 */
	@Column(name = "DNS_SERVER_NOTES", length = 100)
	public String getDnsServerNotes() {
		return dnsServerNotes;
	}
	/**
	 * @param dnsServerNotes the dnsServerNotes to set
	 */
	public void setDnsServerNotes(String dnsServerNotes) {
		this.dnsServerNotes = dnsServerNotes;
	}
	
	/**
	 * @return the dnsServerNotes
	 */
	@Column(name = "APN_PROTOCOL")
	public String getApnProtocol() {
		return apnProtocol;
	}
	public void setApnProtocol(String apnProtocol) {
		this.apnProtocol = apnProtocol;
	}
}
