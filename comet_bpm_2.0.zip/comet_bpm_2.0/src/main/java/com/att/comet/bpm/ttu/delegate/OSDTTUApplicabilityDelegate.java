package com.att.comet.bpm.ttu.delegate;

import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.CometAppRequestException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.ttu.service.OSDTTUApplicabilityService;

@Component
public class OSDTTUApplicabilityDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUApplicabilityDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	private OSDTTUApplicabilityService osdTTTUApplicability;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			Map<String, Object> variables = execution.getVariables();
			String operationType = (String) variables.get("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.ORDER_STATUS_CHECK:
					orderStatusCheck(execution);
					break;
				case BpmConstant.PRE_OPERATION_TTU_APPLICABILITY:
					preOperationTTUApplicability(execution);
					break;
				case BpmConstant.POST_OPERATION_TTU_APPLICABILITY:
					postOperationTTUApplicability(execution);
					break;
				default:
					logger.debug("Please provide valid value for OPERATION:{}", operationType);
				}
			} else {
				logger.error("COMET Request Does not have operationType::", this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_APPLICABILITY_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void orderStatusCheck(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting orderStatusCheck method ");
		CommonBO commonBO = null;
		String OSDTTUApplicabilityInstanceId = null;
		OSDTTUApplicabilityInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					String orderStatus = commonBO.getOrderStatusName();
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable(BpmConstant.ORDER_STATUS, orderStatus);
					}
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
				// throw new BpmnError("TTU_Error001");
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_APPLICABILITY_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending orderStatusCheck method ");
	}

	private void preOperationTTUApplicability(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting preOperationTTUApplicability method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			String OSDTTUPreflightInstanceId = null;
			OSDTTUPreflightInstanceId = execution.getProcessInstanceId();
			CommonBO commonBO = null;
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OSD_TTU_APPLICABILITY_ERR_PRE_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1023L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, commonBO.getWorkFlowUrl());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, commonBO.getOrderOperation());
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");// User task
				commonBO.setUpdatedOn(new Date());
				commonBO.setRoleId(1001L);// Setting OSD roleID

				commonBO.setTaskStatusId(1001L);// OA Task Id//Creation
				commonBO.setTaskStatusName("TTUApplicabilityOSD");
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(commonBO.getWorkFlowUrl());
				commonBO.setTaskId(1023L);// Mapped from BPM_task table (OSD : TTU - Applicability)
				commonBO.setBpmProcessInstanceId(OSDTTUPreflightInstanceId);
				osdTTTUApplicability.preOperationOSDTTUApplicability(commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.BPM_STATUS_ID, commonBO.getTaskStatusName());
				execution.setVariable(BpmConstant.USER_DECISION, commonBO.getTaskUserDecision());
				execution.setVariable(BpmConstant.ORDER_OPERATION, orderOperation);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

			}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_APPLICABILITY_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending preOperationTTUApplicability method ");

	}

	private void postOperationTTUApplicability(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting preOperationTTUApplicability method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String OSDComments = (String) execution.getVariable(BpmConstant.COMMENTS);
			String isTTURequired = (String) execution.getVariable(BpmConstant.IS_TTU_REQUIRED);
			CommonBO commonBO = null;
			// OrderUserTaskFaults
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
			orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OSD_TTU_APPLICABILITY_ERR_POST_001);
			orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
			orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
			orderUserTaskFaultsBO.setRoleId(1001L);// CCS PM Role Id
			orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
			orderUserTaskFaultsBO.setTaskId(1023L);
			orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
			orderUserTaskFaultsBO.setCreationOn(new Date());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				osdTTTUApplicability.postOperationOSDTTUApplicability(commonBO, OSDComments, isTTURequired);

				commonBO.setTaskStatusId(1002L);
				commonBO.setTaskCompletionTime(new Date());
				commonBO.setCategoryId(1003L);// Service

				commonService.updateOrderUserBpmTasksRepository(commonBO);

				execution.setVariable(BpmConstant.IS_TTU_REQUIRED, isTTURequired);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.TTU_APPLICABILITY_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("Ending preOperationTTUApplicability method ");

	}
}
