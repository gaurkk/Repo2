package com.att.comet.bpm.iwos.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.iwos.helper.APNHLRIWOSCompletionHelper;

@Service
public class APNHLRIWOSCompletionServiceImpl implements APNHLRIWOSCompletionService {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRIWOSCompletionServiceImpl.class);
	@Autowired
	private APNHLRIWOSCompletionHelper apnhlriwosCompletionHelper;

	@Autowired
	CommonService commonService;
	private OrderDAO orderDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;

	@Override
	public void preOperationIWOSCompletion(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setProcessId(1024L);//APN HLR IWOS PROCESS
		commonBO.setBpmProcessId(1024L);//APN HLR IWOS PROCESS
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlriwosCompletionHelper.preOperationIWOSCompletion(commonBO);
	}

	@Override
	public void postOperationIWOSCompletion(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		apnhlriwosCompletionHelper.postOperationIWOSCompletion(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);//Task Status COMPLETED Id
		commonBO.setRoleId(1005L);// CCS PM Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1015L); // Mapped from BPM_task table (CCS PM : APN HLR/HSS IWOS Completion)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}
}
