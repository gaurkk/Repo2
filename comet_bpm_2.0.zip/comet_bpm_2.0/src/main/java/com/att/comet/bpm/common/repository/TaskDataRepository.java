package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.att.comet.bpm.common.hibernate.bean.TaskData;

public interface TaskDataRepository extends JpaRepository<TaskData, Long> {
	@Query("from TaskData where taskDataId=:taskDataId")
	TaskData getTaskDetails(Long taskDataId);
}
