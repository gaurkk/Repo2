package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ON_HOLD_STATUS")
public class OnHoldStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long onHoldStatusId;
	private String onHoldStatusName;

	@Id
	@Column(name = "ON_HOLD_STATUS_ID", nullable = false, length = 12)
	public Long getOnHoldStatusId() {
		return onHoldStatusId;
	}

	public void setOnHoldStatusId(Long onHoldStatusId) {
		this.onHoldStatusId = onHoldStatusId;
	}

	@Column(name = "ON_HOLD_STATUS_NAME", nullable = false, length = 50)
	public String getOnHoldStatusName() {
		return onHoldStatusName;
	}

	public void setOnHoldStatusName(String onHoldStatusName) {
		this.onHoldStatusName = onHoldStatusName;
	}

}
