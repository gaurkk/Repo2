package com.att.comet.bpm.oabilling.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.oabilling.service.OABillingSubmissionService;

@Component
public class OABillingSubmissionDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OABillingSubmissionDelegate.class);

	@Autowired
	OABillingSubmissionService oaBillingSubmissionService;

	@Autowired
	CommonService commonService;

	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.VERIFY_ORDER_STATUS:
					verifyOrderStatus(execution);
					break;
				case BpmConstant.PRE_OPERATION_OA_BILLING:
					preOperationOABilling(execution);
					break;
				case BpmConstant.OPERATION_OA_BILLING_TASK:
					operationOABillingTask(execution);
					break;
				case BpmConstant.POST_OPERATION_OA_BILLING:
					postOperationOABilling(execution);
					break;
			}
		}

		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OA_BILLING_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
	}

	private void verifyOrderStatus(DelegateExecution execution)
			throws RecordNotFoundException, CamundaServiceException {
		logger.info("Start verifyOrderStatus method ::", this);
		CommonBO commonBO = null;
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String)execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					String orderStatus = commonBO.getOrderStatusName();
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable(BpmConstant.ORDER_STATUS, orderStatus);
					}
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (Exception e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OA_BILLING_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End verifyOrderStatus method ::", this);
	}

	private void preOperationOABilling(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperationOABilling method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_BILLING_SUBMISSION_ERR_PRE_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1003L);// Setting OSD roleID
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
				orderUserTaskFaultsBO.setOrderId(commonBO.getOrderId());// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url()+commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");// TASK_CATEGORY table , TASK_CATEG_DESC = USER

				commonBO.setRoleId(1002L);// ROLE table , ROLE_NAME = Order Approver
				commonBO.setTaskStatusId(1001L); // TASK_STATUS table , TASK_STATUS_DESC = CREATED
				commonBO.setUpdatedOn(new Date());
				commonBO.setCategoryId(1002L); // TASK_CATEGORY table , TASK_CATEG_DESC = USER
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setUserDecision((String) execution.getVariable("billingUserDecision"));

				if (orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
					orderUserTaskFaultsBO.setTaskId(1020L);
					commonBO.setTaskId(1030L);// BPM_TASK table , TASK_NAME = OA : Billing Request - Submission(CR)
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				} else {
					orderUserTaskFaultsBO.setTaskId(1020L);
					commonBO.setTaskId(1020L);// BPM_TASK table , TASK_NAME = OA : Billing Request - Submission
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				}
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				// ALL CRUD PREOPERATION for OA Billing Submission
				oaBillingSubmissionService.preOperationOABilling(commonBO, execution.getProcessInstanceId());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable("duration", commonBO.getBillingSla());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
		}
		logger.info("End preOperationOABilling method ::", this);
	}

	private void operationOABillingTask(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Inside operationOABillingTask");
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_BILLING_SUBMISSION_ERR_POST_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1002L);// Setting OSD roleID
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1020L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
				orderUserTaskFaultsBO.setOrderId(commonBO.getOrderId());// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
		if (null != commonBO) {
			oaBillingSubmissionService.operationOABillingTask(commonBO);
		}
		logger.info("end operationOABillingTask");
	}

	private void postOperationOABilling(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Inside postOperationOABilling");
		String oaBillingComment = (String) execution.getVariable(BpmConstant.COMMENTS);
		CommonBO commonBO = null;
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		// OrderUserTaskFaults
		OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
		orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_BILLING_SUBMISSION_ERR_TASK_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
		orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
		orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
		orderUserTaskFaultsBO.setRoleId(1002L);// Setting OSD roleID
		orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
		orderUserTaskFaultsBO.setTaskId(1020L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
		orderUserTaskFaultsBO.setOrderId(commonBO.getOrderId());// OrderId
		orderUserTaskFaultsBO.setCreationOn(new Date());
		execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
		commonBO.setComments(oaBillingComment);
		oaBillingSubmissionService.postOperationOABilling(commonBO, execution);
		logger.info("end postOperationOABilling");
	}
}
