package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMSI_MSISDN_TEMPLATE")
public class ImsiMsisdnTemplate implements Serializable {

	private static final long serialVersionUID = 1L;

	public ImsiMsisdnTemplate() {
	}

	private Long columnNumber;
	private String fieldName;
	private String fieldDatatype;
	private String mandatory;

	/**
	 * @return the columnNumber
	 */
	@Id
	@Column(name = "COLUMN_NUMBER", unique = true, nullable = false, precision = 5, scale = 0)
	public Long getColumnNumber() {
		return columnNumber;
	}

	/**
	 * @param columnNumber the columnNumber to set
	 */
	public void setColumnNumber(Long columnNumber) {
		this.columnNumber = columnNumber;
	}

	/**
	 * @return the fieldName
	 */
	@Column(name = "FIELD_NAME", length = 100)
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the fieldDatatype
	 */
	@Column(name = "FIELD_DATATYPE", length = 100)
	public String getFieldDatatype() {
		return fieldDatatype;
	}

	/**
	 * @param fieldDatatype the fieldDatatype to set
	 */
	public void setFieldDatatype(String fieldDatatype) {
		this.fieldDatatype = fieldDatatype;
	}

	/**
	 * @return the mandatory
	 */
	@Column(name = "MANDATORY", length = 5)
	public String getMandatory() {
		return mandatory;
	}

	/**
	 * @param mandatory the mandatory to set
	 */
	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}

}
