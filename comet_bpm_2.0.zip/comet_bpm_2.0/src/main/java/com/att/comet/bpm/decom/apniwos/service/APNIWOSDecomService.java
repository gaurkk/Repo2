package com.att.comet.bpm.decom.apniwos.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface APNIWOSDecomService {

	void preOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationAPNIWOSDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

}
