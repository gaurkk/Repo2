package com.att.comet.bpm.crdashboard.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class CRProcessDelegateHelper {
	private static final Logger logger = LoggerFactory.getLogger(CRProcessDelegateHelper.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;

	public void crPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crPreOprCRUD");

		List<String> ccspmEmailList = null;
		// saving camunda process instance ID
		commonBO.setUpdatedOn(new Date());
		if(commonBO.getOrderOperation().equalsIgnoreCase("CHANGE_REQUEST")) {
			commonBO.setBpmProcessId(1021L);//CHANGE request dashboard process
			commonBO.setProcessId(1021L);
		}else {
			commonBO.setBpmProcessId(1032L);//CHANGE Order dashboard process
			commonBO.setProcessId(1032L);
		}
		commonBO.setBpmProcessInstanceId(processInstanceId);
		// commonBO.setWorkFlowUrl(bpmUrl.getUrl());
		camundaDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		// deleting process ID from bpm_order_process
		bpmDAO.deleteBpmOrderProcess(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmStatusId(1001L);
		//commonBO.setOrderTypeId(1005L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3137L);
		businessStepIdList.add(3187L);
		businessStepIdList.add(3188L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1006L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String ccsPM = attUidList.get(0);
			commonBO.setAttuid(ccsPM);
			commonBO.setAssignee(ccsPM);
			ccspmEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(ccspmEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1005L);
			ccspmEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(ccspmEmailList);
		}
		// Fetching COMET Admin email
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList())
			// + CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		}
		// update bpm_order_work_step
		List<Long> idList = new ArrayList<Long>();
		idList.add(1069L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		//commonBO.setWorkStepId(1069L);
		//commonBO.setBpmStatusId(1001L);
		//bpmDAO.updateBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForCRDashboard(commonBO);
		commonBO.setRoleId(1005L);
		logger.info("[::Ending Method crPreOprCRUD");
	}

	public void crPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crPostOprCRUD");
		// fetching all users
		// Fetching all Users
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		orderContactTypeIdList.add(1024L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		List<String> allUsersEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					allUsersEmailList.add((String) obj[1]);
				}
			}
			commonBO.setAdminEmailList(allUsersEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		commonBO.setBusinessStepId(3137L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepValue("Completed");
		commonBO.setComments(commonBO.getComments());
		// commonBO.setUpdatedOn(PreFlightTestingDateTime);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		commonBO.setWorkStepId(1069L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1069L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmStatusId(1002L);
		//commonBO.setOrderTypeId(1005L);
		bpmDAO.saveBpmOrderProcess(commonBO);

	}

	public void crDashboardTaskStatus(CommonBO commonBO) {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crDashboardTaskStatus");
		commonBO.setBusinessStepId(3116L);
		//commonBO.setOrderTypeId(1005L);
		String taskStatus = bpmDAO.findBpmOrderBusinessStepById(commonBO) != null
				? bpmDAO.findBpmOrderBusinessStepById(commonBO).getBusinessStepStatus()
				: null;
		if (CommonUtils.isNotNullEmpty(taskStatus)) {
			logger.info("task Status of Change Request Dashboard Task is ::  " + taskStatus);
			commonBO.setBusinessStepStatus("true");
		} else {
			commonBO.setBusinessStepStatus("false");
			logger.info("task Status of Change Request Dashboard Task is ::  " + taskStatus);
		}
	}

	public void coPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method coPreOprCRUD");

		List<String> osdEmailList = null;
		// saving camunda process instance ID
		commonBO.setProcessId(1032L);
		commonBO.setBpmProcessId(1032L);
		commonBO.setBpmProcessInstanceId(processInstanceId);
		// commonBO.setWorkFlowUrl(bpmUrl.getUrl());
		camundaDAO.deleteAVOSProcessInstancesByCamundaProcessInstanceId(commonBO);
		// deleting process ID from bpm_order_process
		bpmDAO.deleteBpmOrderProcess(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3088L);
		businessStepIdList.add(3089L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1006L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String ccsPM = attUidList.get(0);
			commonBO.setAttuid(ccsPM);
			commonBO.setAssignee(ccsPM);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1005L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(osdEmailList);
		}
		// Fetching COMET Admin email
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList())
			// + CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		}
		// update bpm_order_work_step
		commonBO.setWorkStepId(1030L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1030L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForCRDashboard(commonBO);
		commonBO.setRoleId(1005L);
		logger.info("[::Ending Method coPreOprCRUD");

	}

	public void coDashboardTaskStatus(CommonBO commonBO) {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crDashboardTaskStatus");
		commonBO.setBusinessStepId(3116L);

		String taskStatus = bpmDAO.findBpmOrderBusinessStepById(commonBO) != null
				? bpmDAO.findBpmOrderBusinessStepById(commonBO).getBusinessStepStatus()
				: null;
		if (CommonUtils.isNotNullEmpty(taskStatus)) {
			logger.info("task Status of Change Order Dashboard Task is ::  " + taskStatus);
			commonBO.setBusinessStepStatus("true");
		} else {
			commonBO.setBusinessStepStatus("false");
			logger.info("task Status of Change Order Dashboard Task is ::  " + taskStatus);
		}
	}

	public void coPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method coPostOprCRUD");
		// Fetching all Users
		List<Long> orderContactTypeIdList = new ArrayList<Long>();
		orderContactTypeIdList.add(1003L);
		orderContactTypeIdList.add(1004L);
		orderContactTypeIdList.add(1005L);
		orderContactTypeIdList.add(1006L);
		orderContactTypeIdList.add(1007L);
		orderContactTypeIdList.add(1023L);
		orderContactTypeIdList.add(1024L);
		commonBO.setOrderContactTypeIdList(orderContactTypeIdList);
		List<Object[]> emailList = userDAO.findContactTypeIdAndEmail(commonBO);
		List<String> allUsersEmailList = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(emailList)) {
			logger.debug("osdEmailList is not empty : ", +emailList.size());
			for (Object[] obj : emailList) {
				if (null != obj[1]) {
					allUsersEmailList.add((String) obj[1]);
				}
			}
			commonBO.setAdminEmailList(allUsersEmailList);
		} else {
			logger.error("osdEmailList is empty: ", +emailList.size());
		}
		commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		commonBO.setBusinessStepId(3221L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepValue("Completed");
		commonBO.setComments(commonBO.getComments());
		
		// commonBO.setUpdatedOn(PreFlightTestingDateTime);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		List<Long> idList = new ArrayList<Long>();
		idList.add(1030L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmProcessId(1032L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.saveBpmOrderProcess(commonBO);

	}

}
