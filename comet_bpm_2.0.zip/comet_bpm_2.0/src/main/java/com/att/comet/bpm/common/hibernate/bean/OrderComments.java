package com.att.comet.bpm.common.hibernate.bean;

// Generated Sep 17, 2012 12:51:46 PM by Hibernate Tools 3.3.0.GA

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderComments. Mapped to ORDER_COMMENTS table in the
 * database.
 */
@Entity
@Table(name = "ORDER_COMMENTS")
public class OrderComments implements Serializable {
	private static final long serialVersionUID = -4034292555480365171L;

	private long commentId;
	private Role role;
	private Orders orders;
	private Users users;
	private String orderProcess;
	private String userAction;
	private Date createdOn;
	private String comments;

	/**
	 * No-argument constructor of the class
	 */
	public OrderComments() {
	}

	/**
	 * Multiple arguments of the class.
	 * 
	 * @param commentId
	 * @param role
	 * @param orders
	 * @param users
	 * @param createdOn
	 */
	public OrderComments(long commentId, Role role, Orders orders, Users users, Date createdOn) {
		this.commentId = commentId;
		this.role = role;
		this.orders = orders;
		this.users = users;
		this.createdOn = createdOn;
	}

	/**
	 * Multiple arguments of the class.
	 * 
	 * @param commentId
	 * @param role
	 * @param orders
	 * @param users
	 * @param orderProcess
	 * @param userAction
	 * @param createdOn
	 * @param comments
	 */
	public OrderComments(long commentId, Role role, Orders orders, Users users, String orderProcess, String userAction,
			Date createdOn, String comments) {
		this.commentId = commentId;
		this.role = role;
		this.orders = orders;
		this.users = users;
		this.orderProcess = orderProcess;
		this.userAction = userAction;
		this.createdOn = createdOn;
		this.comments = comments;
	}

	/**
	 * Getter method for commentId. COMMENT_ID mapped to COMMENT_ID in the database
	 * table.
	 * 
	 * @return long
	 */
	@Id
	@Column(name = "COMMENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "ORDER_COMMENTS_SEQ", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "ORDER_COMMENTS_SEQ") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORDER_COMMENTS_SEQ")
	public long getCommentId() {
		return this.commentId;
	}

	/**
	 * @param commentId to commentId set.
	 */
	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}

	/**
	 * Getter method for role. ROLE_ID mapped to ROLE_ID in the database table.
	 * 
	 * @return Role
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false)
	public Role getRole() {
		return this.role;
	}

	/**
	 * @param role to role set.
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for users.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ATTUID", nullable = false)
	public Users getUsers() {
		return this.users;
	}

	/**
	 * @param users to users set.
	 */
	public void setUsers(Users users) {
		this.users = users;
	}

	/**
	 * Getter method for orderProcess. ORDER_PROCESS mapped to ORDER_PROCESS in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_PROCESS", length = 100)
	public String getOrderProcess() {
		return this.orderProcess;
	}

	/**
	 * @param orderProcess to orderProcess set.
	 */
	public void setOrderProcess(String orderProcess) {
		this.orderProcess = orderProcess;
	}

	/**
	 * Getter method for userAction. USER_ACTION mapped to USER_ACTION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_ACTION", length = 100)
	public String getUserAction() {
		return this.userAction;
	}

	/**
	 * @param userAction to userAction set.
	 */
	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

}
