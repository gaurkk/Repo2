package com.att.comet.bpm.decom.apnhlr.helper;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class APNHLRDecomHelper {
	private static final Logger logger = LoggerFactory.getLogger(APNHLRDecomHelper.class);
	@Autowired
	GenericDAO genericDAO;

	@Autowired
	private BpmDAO bpmDAO;

	@Autowired
	private OrderDAO orderDAO;

	public void preOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperationAPNHLRDecom method ::", this);
		
		String assigneeCCSPM = null;
		commonBO.setOrderContactTypeId(1006L); //Mapped with ORDER_CONTACT_TYPE ; CCSPM
		assigneeCCSPM = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeCCSPM);
		
		/* Set Reminder1 & Reminder2 SLA Dates for APNHLRDecom */
		genericDAO.setReminder1And2FromSlaWorkingDayForAPNHLRDecom(commonBO);

		/* Save BpmOrderWorkStep */
		commonBO.setWorkStepId(1031L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.saveBpmOrderWorkStep(commonBO);

		commonBO.setBpmProcessId(1014L); //Mapped with BPM_PROCESS table ; COMET DECOMMISSION PROCESS
		
		logger.info("End preOperationAPNHLRDecom method ::", this);
	}

	public void postOperationAPNHLRDecom(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		logger.info("Start postOperationAPNHLRDecom method ::", this);
		String assigneeCCSPM = null;
		commonBO.setOrderContactTypeId(1006L); //Mapped with ORDER_CONTACT_TYPE ; CCSPM
		assigneeCCSPM = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAttuid(assigneeCCSPM);
		
		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3090L);
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);

		/* Save BpmOrderBusinessStep */
		commonBO.setBusinessStepId(3090L);
		commonBO.setBusinessStepStatus("DECOMMISSION_COMPLETE");
		bpmDAO.saveBpmOrderBusStepHistory(commonBO);

		/* Update OrderContactInfo */
		commonBO.setOrderContactTypeId(1006L);
		orderDAO.updateOrderContactInfo(commonBO);

		/* Update BpmOrderWorkStep */
		commonBO.setWorkStepId(1031L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		logger.info("End postOperationAPNHLRDecom method ::", this);

	}
}
