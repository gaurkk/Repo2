package com.att.comet.bpm.om.delegate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.config.CometYamlPropertySourceFactory;


@Component
@Configuration
@PropertySource(value = "classpath:application.yml", factory = CometYamlPropertySourceFactory.class)
public class CROMApprovalDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(CROMApprovalDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	RestTemplate restTemplate;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
	try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.CR_OM_PRE_OPERATION:
					fetchTaskProcessStatus(execution);
					break;
				case BpmConstant.CR_OM_TERMINATION:
					terminateTask(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			throw new CamundaServiceException("NO INPUT FOUND FOR NEXT FLOW STEPS");
		}
	}
	
	private void fetchTaskProcessStatus(DelegateExecution execution) throws CamundaServiceException, URISyntaxException {
		logger.info("Start fetchTaskProcessStatus method ::", this);
		Long orderId = null;
		String orderOperation = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String)execution.getVariable(BpmConstant.ORDER_OPERATION);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		Orders order = new Orders();
		order.setOrderId(orderId);
		Long taskStatusId = 1001L;
		String taskStatusName = null;
		Long taskId = 1011L;//OM
		List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
		if(null!=orderUserBpmTaskList && !CollectionUtils.isEmpty(orderUserBpmTaskList)) {
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				//checking for Delegate taskId for each subtask 
				
					if ((taskObj.getBpmTask().getTaskId().equals(taskId))) {
						taskStatusName = taskObj.getTaskStatus().getTaskStatusDesc();
						if (CommonUtils.isNotNullEmpty(taskStatusName)) {
							logger.info("taskStatusName :: " + taskStatusName);
							if (taskStatusName.equalsIgnoreCase("CREATED")) {
								//commonBO.setTaskStatusName(taskStatusName);
								break;
							}
						}
					
					} else {
						logger.info("No In progress task for OrderID:"+orderId+"for BPM progress 1011L OM", this);
					}
			}
			//commonBO.setOrderOperation(orderOperation);
			execution.setVariable(BpmConstant.BPM_STATUS_NAME, taskStatusName);
			execution.setVariable(BpmConstant.USER_DECISION, "Applicable");
			//execution.setVariable("commonBO", commonBO);
		}
		logger.info("Existing fetchTaskProcessStatus method ::", this);
	}
	
	private void terminateTask(DelegateExecution execution) throws CamundaServiceException, URISyntaxException{
		logger.info("Starting terminateTask method ::", this);
		Long orderId = null;
		String orderOperation = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String)execution.getVariable(BpmConstant.ORDER_OPERATION);
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		logger.info("OrderOperation:::"+orderOperation,this);
		Orders order = new Orders();
		order.setOrderId(orderId);
		Long taskId = 1011L;//OM
		commonBO.setTaskId(taskId);
		commonServiceHelper.taskCompletedService(commonBO, execution);
		logger.info("Existing terminateTask method ::", this);
		
	}

}
