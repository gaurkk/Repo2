package com.att.comet.bpm.ttu.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Service
public class OSDTTUResultServiceImpl implements OSDTTUResultService {
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUResultServiceImpl.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	GenericDAO genericDAO;
	
	@Override
	public void preOperationOSDTTUResult(CommonBO commonBO) throws CamundaServiceException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method preOperationOSDTTUResult");

		List<String> osdEmailList = null;
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1023L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String orderSubmitter = attUidList.get(0);
			commonBO.setAttuid(orderSubmitter);
			commonBO.setAssignee(orderSubmitter);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1001L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(osdEmailList);
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
		}
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp

			System.out.println("hkhkk");
		} else {
			// commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));//All
			// grp
		}
		// delete bpm_order_work_step
		List<Long> workStepIdList = new ArrayList<Long>();
		workStepIdList.add(1024L);
		commonBO.setWorkStepIdList(workStepIdList);
		bpmDAO.deleteBpmOrderWorkStep(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3078L);
		businessStepIdList.add(3079L);
		businessStepIdList.add(3029L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		if (commonBO.getOrderOperation().equalsIgnoreCase("NEW_ORDER")) {
			commonBO.setWorkStepId(1024L);
			List<Long> idList = new ArrayList<Long>();
			idList.add(1024L);
			commonBO.setWorkStepIdList(idList);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.saveBpmOrderWorkStep(commonBO);
		} else {
		
			commonBO.setWorkStepId(1024L);
			commonBO.setBpmStatusId(1001L);
			bpmDAO.updateBpmOrderWorkStep(commonBO);
		}
		genericDAO.setReminder1And2FromSlaWorkingDayByAdminConfigIdForTTUResult(commonBO);
		
		/*
		 * SLA Calculation select cast(SLA_Working_Day(TIMESTAMP '2020-05-17
		 * 11:56:22',1046) as timestamp(3))targetSLADate from dual select
		 * cast(SLA_Working_Day(TIMESTAMP '2020-05-17 11:56:22',1047) as
		 * timestamp(3))targetSLADate from dual
		 */

	}

	@Override
	public void postOperationOSDTTUResult(CommonBO commonBO, String OSDComments, String ttuStatus, String completionDate)
			throws CamundaServiceException, ParseException {
		logger.info(
				"[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method postOperationOSDTTUPerform");
		String actorName = null;
		if (!StringUtils.isEmpty(OSDComments)) {
			commonBO.setComments(OSDComments);
		} else {
			commonBO.setComments("N/A");
		}
		commonBO.setUpdatedOn(CommonUtils.stringToDateFormat(completionDate));
		/* fetching order submiiter from order_contact_info table */
		commonBO.setOrderContactTypeId(1023L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			actorName = attUidList.get(0);
			commonBO.setAttuid(actorName);
		}

		/* insert in to bpm_order_business_step */
		commonBO.setBusinessStepId(3029L);
		commonBO.setBusinessStepValue(ttuStatus);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepStatus("Completed");
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		commonBO.setWorkStepId(1024L);
		List<Long> idList = new ArrayList<Long>();
		idList.add(1024L);
		commonBO.setWorkStepIdList(idList);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);

		if (commonBO.getApnSelection().equalsIgnoreCase("New")) {
			Date apnProductionDate = orderDAO.getBackHaulConfig(commonBO);
			if (null == apnProductionDate) {
				commonBO.setApnProductionDate(commonBO.getUpdatedOn());
				orderDAO.updateBackhaulConfig(commonBO);
			} else {
				logger.error("apnProductionDate is null");
				commonBO.setApnProductionDate(apnProductionDate);
				orderDAO.updateBackhaulConfig(commonBO);
			}

		}

	}
	

}
