package com.att.comet.bpm.decom.dashboard.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.decom.dashboard.helper.DecomDashboardlHelper;

@Service
public class DecomDashboardServiceImpl implements DecomDashboardService{

	@Autowired
	DecomDashboardlHelper decomDashboardlHelper;
	
	@Autowired
	CommonService commonService;
	
	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		decomDashboardlHelper.preOprCRUD(commonBO,processInstanceId);
	}
	
	@Override
	public String checkUserEntry(CommonBO commonBO) throws CamundaServiceException {
		return decomDashboardlHelper.checkUserEntry(commonBO);
	}
	
	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		decomDashboardlHelper.postOprCRUD(commonBO,execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Completed 
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
