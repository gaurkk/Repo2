package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "INFRA_GI_INFORMATION")
public class InfraGiInformation implements Serializable {
	
	private static final long serialVersionUID = -1066453547117707730L;
	private Long orderId;
	private Long ccsRouterBaseRd;
	private String vrfName;
	private Orders orders;
	private Set<VlanGi> vlanGiSet = new HashSet<VlanGi>();


	
	public InfraGiInformation(){
		
	}
	
	 public InfraGiInformation(Orders orders) {
			this.orders = orders;
		}
	/**
	 * Getter method for the OrderId ORDER_ID mapped to ORDER_ID column if the table in database.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "CCS_Router_Base_RD", precision = 12, scale = 0)
	public Long getCcsRouterBaseRd() {
		return ccsRouterBaseRd;
	}

	public void setCcsRouterBaseRd(Long ccsRouterBaseRd) {
		this.ccsRouterBaseRd = ccsRouterBaseRd;
	}

	@Column(name = "VRF_Name", length = 100)
	public String getVrfName() {
		return vrfName;
	}

	public void setVrfName(String vrfName) {
		this.vrfName = vrfName;
	}

	/**
	 * Getter method for the Orders.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * @return the vlanGiSet
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "infraGiInfo")
	public Set<VlanGi> getVlanGiSet() {
		return vlanGiSet;
	}

	/**
	 * @param vlanGiSet the vlanGiSet to set
	 */
	public void setVlanGiSet(Set<VlanGi> vlanGiSet) {
		this.vlanGiSet = vlanGiSet;
	}

}
