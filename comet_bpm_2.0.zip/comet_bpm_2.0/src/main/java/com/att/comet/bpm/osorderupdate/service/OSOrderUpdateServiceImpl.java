package com.att.comet.bpm.osorderupdate.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.osorderupdate.helper.OSOrderUpdateHelper;

@Service
public class OSOrderUpdateServiceImpl implements OSOrderUpdateService {

	@Autowired
	OSOrderUpdateHelper osOrderUpdateHelper;

	@Autowired
	CommonService commonService;

	@Override
	public void preOperationOAReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessId(0L);
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		osOrderUpdateHelper.preOperationOAReject(commonBO);
	}

	@Override
	public void postOperationOAReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		osOrderUpdateHelper.postOperationOAReject(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setRoleId(1001L);// Order Approver Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setTaskId(1012L); // Mapped from BPM_task table (OS : Order Update Task (Rejected by OA))
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

	@Override
	public void preOperationOMReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessId(0L);
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		osOrderUpdateHelper.preOperationOMReject(commonBO);
	}

	@Override
	public void postOperationOMReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		osOrderUpdateHelper.postOperationOMReject(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setRoleId(1001L);// Order Manager Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setTaskId(1013L); // Mapped from BPM_task table (OS : Order Update Task (Rejected by OM))
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
