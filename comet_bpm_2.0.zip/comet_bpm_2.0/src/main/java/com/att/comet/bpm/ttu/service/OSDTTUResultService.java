package com.att.comet.bpm.ttu.service;

import java.text.ParseException;
import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OSDTTUResultService {
	void preOperationOSDTTUResult(CommonBO commonBO) throws CamundaServiceException;
	void postOperationOSDTTUResult(CommonBO commonBO, String OSDComments, String ttuStatus, String taskCompletionDate) throws CamundaServiceException, ParseException;
}
