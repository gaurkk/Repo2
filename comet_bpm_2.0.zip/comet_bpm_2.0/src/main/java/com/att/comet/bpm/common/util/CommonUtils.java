package com.att.comet.bpm.common.util;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
@Component
public class CommonUtils {
	private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);
	
	/**
	 * Returns true if string is not null and not empty, otherwise returns false.
	 * 
	 * @param string
	 * @return boolean
	 */
	public static boolean isValidString(String string) {
		return (string != null && string.trim().length() > 0);
	}
	

	//validate  String date. it throws exception for invalid date
	public static void isValidDateString(String stringDate, String format)throws ParseException{
		DateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		sdf.parse(stringDate);
	}
	
	/**
	 * The method is used to convert String to Date
	 * 
	 * @param date
	 * @return String
	 */
	public static String convertStringToDate(String date) {

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date theDate = null;
		try {
			if (isValidString(date)) {
				theDate = dateFormat.parse(date);
				logger.debug("Date parsed = " + dateFormat.format(theDate));
			} else {
				String dateform = dateFormat.format(new Date());
				theDate = dateFormat.parse(dateform);
				logger.debug("Date parsed = " + dateFormat.format(theDate));
			}

		} catch (Exception e) {
			logger.error("Error parsing date " + e.getMessage());
		}
		return dateFormat.format(theDate);
	}

	/**
	 * Converts date to string as per specified format.
	 * 
	 * @param date
	 * @param format
	 * @return date in String format
	 */
	public static String dateToString(Date date, String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}

	
	/**
	 * Converts string to date as per specified format.
	 * 
	 * @param dateString
	 * @param format
	 * @return Date
	 * @throws ParseException
	 */
	public static Date stringToDate(String dateString, String format) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.parse(dateString);
	}

	/**
	 * The method is used to compare to Dates whether they are the same or not.
	 * 
	 * @param date1
	 * @param date2
	 * @return a long value suggesting that whether the dates are the same , or the
	 *         date1 is before date2 or after date2.
	 */
	public static long compareDates(Date date1, Date date2) {
		return date1.getTime() - date2.getTime();
	}

	/**
	 * Converts the Date into mm/dd/yyyy hh:mm:ss am/pm format
	 * 
	 * @param date
	 * @return String
	 */
	public static String formatDate(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		DateFormatSymbols dateFormatSymbols = dateFormat.getDateFormatSymbols();
		dateFormatSymbols.setAmPmStrings(new String[] { "AM", "PM" });
		dateFormat.setDateFormatSymbols(dateFormatSymbols);
		return dateFormat.format(date);
	}

	
	/**
	 * Formats the content of the string for the Grid.
	 * 
	 * @param str
	 * @return String
	 */
	public static String formatContentForGrid(String str) {
		if (str == null)
			return "";
		try {
			if (str.contains("\r\n")) {
				str = str.replaceAll("\r\n", "<br />");
			}
			if (str.contains("\n")) {
				str = str.replaceAll("\n", "<br />");
			}
			if (str.contains("&")) {
				str = str.replaceAll("&", "&amp;");
			}
			if (str.contains("'")) {
				str = str.replaceAll("'", "\\\\'");
			}
			if (str.contains("\"")) {
				str = str.replaceAll("\"", "&quot;");
			}

			return str;
		} catch (Exception e) {
			/// logger.error(e);
			return "";
		}
	}

	/**
	 * Checks whether the string passed is not null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNotNullEmpty(String arg) {
		if ((arg != null) && (arg.isEmpty() == false)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the string passed is null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNullEmpty(String arg) {
		if ((arg == null) || (arg.isEmpty() == true)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the long argument passed is null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNullEmpty(Long arg) {
		if ((arg == null) || (arg.longValue() == 0)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the string passed is not null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNotNullEmpty(Long arg) {
		if ((arg != null) && (arg.longValue() != 0)) {
			return true;
		}
		return false;
	}

	/**
	 * The method checks whether the string passed is null.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean checkStringEmptyandNull(String arg) {
		if (arg != null && !arg.isEmpty())
			return true;
		else
			return false;
	}

	/**
	 * Formats the string passed by using appropriate arguments.
	 * 
	 * @param str
	 * @return String
	 */
	public static String formatQueryString(String str) {
		if (str == null)
			return "";
		try {
			if (str.contains("'")) {
				str = str.replaceAll("'", "''");
			}
			return str;
		} catch (Exception e) {
			///logger.error(e);
			return "";
		}
	}
	
	 // Generic function to convert list to set 
    public static <T> Set<T> convertListToSet(List<T> list) 
    { 
        // create an empty set 
        Set<T> set = new HashSet<>(); 
  
        // Add each element of list into the set 
        for (T t : list) 
            set.add(t); 
  
        // return the set 
        return set; 
    }
    
    public static String formatDate1(java.util.Date date) {
		SimpleDateFormat newFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		String formatedDate = newFormat.format(date);
		return formatedDate;
	}
    
    public static Date stringToDateFormat(String inputDate) throws ParseException {
    	//change  yyyy-MM-dd'T'HH:mm:ss.SSSZ format
    	SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); 
		SimpleDateFormat outFormatter = new SimpleDateFormat("dd-MMM-yy");
		
		Date iwosTicketCreationDate = inputFormat.parse(inputDate);
		String outIWOSCreationDate = outFormatter.format(iwosTicketCreationDate);
		return new SimpleDateFormat("dd-MMM-yy").parse(outIWOSCreationDate);
    }
    
	/**
	 * Removes the last space of the string passed.
	 * 
	 * @param str
	 * @return String
	 */
	public static String getStringTillSpace(String str) {
		if (str == null)
			return "";
		try {

			int space = str.indexOf(' ');
			if (space != -1) {
				return (str.substring(0, space));
			}
		} catch (Exception e) {
			logger.error("Error"+e, "Method :getStringTillSpace");
		}
		return "";
	}
	
	
	public static boolean isNullOrEmpty(String str) {
		if (str == null || "".equalsIgnoreCase(str)) {
			return true;
		}
		return false;
	}
	
	
	public static String replaceListToStringByComma(List<String> emailList) {
		return String.join("", emailList);
	}
}
