package com.att.comet.bpm.decom.confirmation.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface DecomConfirmationService {

	void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void preOperation(CommonBO commonBO) throws CamundaServiceException;

}
