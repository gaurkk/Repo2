package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent Class for ApnRadiusId.
 */
@Embeddable
public class ApnRadiusId implements java.io.Serializable {

	private static final long serialVersionUID = -4211401338235355587L;
	private Long orderId;
	private Long dataCenterId;

	/**
	 * Getter method for orderId. ORDER_ID mapped with ORDER_ID of the database
	 * table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId
	 *            to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for the dataCenterId. DATA_CENTER_ID mapped to
	 * DATA_CENTER_ID in the database tables.
	 * 
	 * @return
	 */
	@Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return this.dataCenterId;
	}

	/**
	 * @param dataCenterId
	 *            to dataCenterId set.
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ApnRadiusId))
			return false;
		ApnRadiusId castOther = (ApnRadiusId) other;

		return (this.getOrderId() == castOther.getOrderId())
				&& (this.getDataCenterId() == castOther.getDataCenterId());
	}
}