package com.att.comet.bpm.decom.billing.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OABillingDecomService {
	void preOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationOABillingDecom(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

}
