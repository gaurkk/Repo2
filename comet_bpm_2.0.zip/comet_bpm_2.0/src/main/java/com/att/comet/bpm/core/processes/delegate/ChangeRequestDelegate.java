package com.att.comet.bpm.core.processes.delegate;

import java.util.List;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;
import com.att.comet.bpm.core.processes.service.CoreProcessService;

@Component
public class ChangeRequestDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(ChangeRequestDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	AvosDAO avosDAO;
	@Autowired
	CoreProcessService coreProcessService;
	@Autowired
	private CoreProcessDelegateHelper coreProcessDelegateHelper;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String operationType = (String) execution.getVariable("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.CR_PRE_OPERATION:
				preOperationCR(execution);
				break;
			case BpmConstant.ORDER_STATUS_CHECK:
				orderStatusCheck(execution);
				break;
			case BpmConstant.USER_DECISION_CHECK:
				gettingUserDecision(execution);
				break;
			case BpmConstant.AMP_ELIGIBILTY_CHECK:
				ampEligibilityCheck(execution);
				break;
			case BpmConstant.ORDER_STATUS_UPDATE:
				orderStatusUpdate(execution);
				break;
			case BpmConstant.CR_POST_OPERATION:
				postOperationCR(execution);
				break;
			case BpmConstant.BILLING_TASK_STATUS:
				billingTaskStatusCheck(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void billingTaskStatusCheck(DelegateExecution execution) {
		logger.info("Starting billingTaskStatusCheck method ");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		String billingTaskStatus = coreProcessService.billingTaskStatus(commonBO);
		logger.info("@@@ billingTaskStatus @@@ ::: "+billingTaskStatus, this);
		execution.setVariable(BpmConstant.OA_BILLING_TASK_STATUS, billingTaskStatus);
		logger.info("Starting billingTaskStatusCheck method ");

	}

	private void preOperationCR(DelegateExecution execution) {
		logger.info("Starting preOperationCR method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String changeRequestProcessInstanceId = execution.getProcessInstanceId();
		CommonBO commonBO = null;
		try {
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				commonBO = commonService.getCommonBO(orderId);
				if (null != commonBO) {
					commonBO.setOrderOperation(orderOperation);
					commonBO.setBpmProcessInstanceId(changeRequestProcessInstanceId);
					commonBO.setBpmProcessId(1019L);
					//avosDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
			}
		} catch (CamundaServiceException e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TTU Applicability TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Ending preOperationCR method ");
	}

	private void orderStatusUpdate(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting orderStatusUpdate method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		CommonBO commonBO = null;
		String isTTURequired = (String) execution.getVariable(BpmConstant.IS_TTU_REQUIRED);
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setOrderStatusId(1047L);
		coreProcessDelegateHelper.updateOrderStaus(commonBO);
		coreProcessDelegateHelper.updateAuditOrderStaus(commonBO);
		execution.setVariable(BpmConstant.COMMON_BO, commonBO);
		execution.setVariable(BpmConstant.IS_TTU_REQUIRED, isTTURequired);
		logger.info("Ending orderStatusUpdate method ");

	}

	private void postOperationCR(DelegateExecution execution) {
		logger.info("Starting postOperationCR method ");
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);

			CommonBO commonBO = null;

			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != commonBO) {
				// update order status as in production
				commonBO.setOrderStatusId(1009L);
				orderDAO.updateOrderStatus(orderId, 1009L);
				// coreProcessService.cancelOrderPostOperation(commonBO);
				coreProcessService.completeProcess(commonBO, execution);
				commonBO.setApproved(BpmConstant.APPROVED);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			} else {
				logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);
			}
		} catch (Exception e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure Post Operation"), this);
			throw new BpmnError("ERROR_BPM_001", "Change Request");
		}

		logger.info("Ending postOperationCR method ");

	}

	private void gettingUserDecision(DelegateExecution execution) {
		logger.info("Starting gettingUserDecision method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String userDecision = null;
		// List<Object[]> processDetails = null;
		String apnIwosHlrUserDecision = null;
		String itOpsUserDecision = null;
		String apnIwosUserDecision = null;
		String ttuUserDecision = null;
		String billingUserDecision = null;
		CommonBO commonBO = null;
		try {
			commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
				if (null == commonBO) {
					commonBO = commonService.getCommonBO(orderId);
				} else {
					logger.debug("commonBO is not null :::: ");
				}
				//commonBO.setOrderTypeId(1005L);
				List<Object[]> processDetails = bpmDAO.getProcessUserDecision(commonBO);
				if (!CollectionUtils.isEmpty(processDetails)) {
					for (Object[] processDetailsdata : processDetails) {
						String processId = processDetailsdata[0].toString();
						if (null != processId && CommonUtils.isNotNullEmpty(processId)) {
							logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
							if (null != processDetailsdata[1]) {
								userDecision = processDetailsdata[1].toString();
								if (null != userDecision && CommonUtils.isNotNullEmpty(userDecision)) {
									if (processId.equalsIgnoreCase("1024")) {
										apnIwosHlrUserDecision = userDecision;
										logger.info("apnIwosHlrUserDecision  :: " + apnIwosHlrUserDecision, this);
									} else if (processId.equalsIgnoreCase("1004")) {
										itOpsUserDecision = userDecision;
										logger.info("itOpsUserDecision  :: " + itOpsUserDecision, this);
									} else if (processId.equalsIgnoreCase("1005")) {
										apnIwosUserDecision = userDecision;
										logger.info("apnIwosUserDecision  :: " + apnIwosUserDecision, this);
									} else if (processId.equalsIgnoreCase("1012")) {
										ttuUserDecision = userDecision;
										logger.info("ttuUserDecision  :: " + ttuUserDecision, this);
									} else if (processId.equalsIgnoreCase("1011")) {
										billingUserDecision = userDecision;
										logger.info("billingUserDecision  :: " + billingUserDecision, this);
									}
								} else {
									logger.error("userDecision is null: " + userDecision, this);
								}
							} else {
								logger.error("processDetailsdata[1] is null: ", this);
							}

						} else {
							logger.debug("processId::" + processId + "::for OrderId=" + commonBO.getOrderId(), this);
						}
					}
				} else {
					logger.error("processDetails is empty: ", +processDetails.size());
				}
				execution.setVariable(BpmConstant.TTU_USER_DECISION, ttuUserDecision);
				execution.setVariable(BpmConstant.APN_IWOS_USER_DECISION, apnIwosUserDecision);
				
				execution.setVariable(BpmConstant.ITOPS_USER_DECISION, itOpsUserDecision);
				
				execution.setVariable(BpmConstant.APN_IWOS_HLR_USER_DECISION, apnIwosHlrUserDecision);
				
				execution.setVariable(BpmConstant.BILLING_USER_DECISION, billingUserDecision);
				
				execution.setVariable(BpmConstant.DASHBOARD_RESPONSE, "COMPLETED");
			}

		} catch (CamundaServiceException e) {
			logger.error("",
					new CamundaServiceException("DB Operation failed for TTU Schedule Change Request TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Ending gettingUserDecision method ");

	}

	private void orderStatusCheck(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Starting orderStatusCheck method ");
		CommonBO commonBO = null;
		String changeRequestProcessInstanceId = null;
		changeRequestProcessInstanceId = execution.getProcessInstanceId();
		try {
			Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {

				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
					if (null == commonBO) {
						commonBO = commonService.getCommonBO(orderId);
					} else {
						logger.debug("commonBO is null :::: ");
					}
					String orderStatus = commonBO.getOrderStatusName();
					commonBO.setBpmProcessInstanceId(changeRequestProcessInstanceId);
					commonBO.setOrderOperation(orderOperation);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					if (!StringUtils.isEmpty(orderStatus)) {
						execution.setVariable(BpmConstant.ORDER_STATUS, orderStatus);
					}
					// update order status "Implementation In-Progress"
					commonBO.setUpdatedBy(commonBO.getAttuid());
					commonBO.setOrderStatusId(1046L);
					coreProcessDelegateHelper.updateOrderStaus(commonBO);
					coreProcessDelegateHelper.updateAuditOrderStaus(commonBO);
				} else {
					logger.error("COMET DATABASE RETRIVAL ISSUE FOR ," + "ORDER_ID::[" + orderId + "]", this);

				}
			} else {
				logger.error("COMET REQUEST DOEST NOT HAVE::" + "DATA", this);
				// throw new BpmnError("TTU_Error001");
			}
		} catch (CamundaServiceException e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TTU Applicability TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Ending orderStatusCheck method ");
	}

	private void ampEligibilityCheck(DelegateExecution execution) {
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		logger.info("Start ampEligibilityCheck method ::", this);
		if (null != orderId && null != execution) {
			String ampEligible = coreProcessDelegateHelper.checkApmEligibility(execution, orderId);
			logger.info("ampEligible :::  " + ampEligible, this);
			execution.setVariable(BpmConstant.AMP_ELIGIBILTIY, ampEligible);
		} else {
			logger.error("@@@@ NO ORDER ID and OPERATIONYPE", this);
		}
		logger.info("Existing ampEligibilityCheck method ::", this);

	}

}
