package com.att.comet.bpm.osorderupdate.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OSOrderUpdateService {

	void preOperationOAReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationOAReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void preOperationOMReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

	void postOperationOMReject(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;

}
