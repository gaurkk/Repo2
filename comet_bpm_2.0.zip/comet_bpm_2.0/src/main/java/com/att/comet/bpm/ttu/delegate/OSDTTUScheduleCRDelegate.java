package com.att.comet.bpm.ttu.delegate;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmTask;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
@Component
public class OSDTTUScheduleCRDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(OSDTTUScheduleCRDelegate.class);

	@Autowired
	CommonService commonService;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Map<String, Object> variables = execution.getVariables();
		String operationType = (String) variables.get("OPERATION");
		if (!StringUtils.isEmpty(operationType)) {
			switch (operationType) {
			case BpmConstant.USER_DECISION_CHECK:
				gettingUserDecision(execution);
				break;
			case BpmConstant.TERMINATE_TASK:
				terminatingInProgressTask(execution);
				break;
			default:
				logger.debug("Please provide valid value for OPERATION:{}", operationType);
			}
		} else {
			logger.error("COMET Request Does not have operationType::", this);
		}
	}

	private void gettingUserDecision(DelegateExecution execution) {
		logger.info("Starting gettingUserDecision method ");
		Long orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String userDecision = null;
		CommonBO commonBO = null;
		try {
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);
			commonBO.setOrderOperation(orderOperation);
			List<Long> workStepIdList = new ArrayList<>();
			workStepIdList.add(1025L);
			commonBO.setWorkStepIdList(workStepIdList);
		
			List<Object[]> applicabilityTaskUserDecisionList = bpmDAO.findWorkStepIdAndUserDecision(commonBO);
			if (!CollectionUtils.isEmpty(applicabilityTaskUserDecisionList)) {
				for (Object[] obj : applicabilityTaskUserDecisionList) {
					if (null != obj[1]) {
						String applicabilityTaskUserDecision = obj[1].toString();
						commonBO.setTaskUserDecision(applicabilityTaskUserDecision);
					} else {
						commonBO.setTaskUserDecision("NotApplicable");
					}
				}
			} else {
				logger.error("applicabilityTaskUserDecisionList is empty: ",+applicabilityTaskUserDecisionList.size());
			}
			// fetching process status
			BpmTask bpmTask = new BpmTask();
			Orders order = new Orders();
			commonBO.setTaskId(1024L);
			bpmTask.setTaskId(commonBO.getTaskId());
			order.setOrderId(orderId);
			String taskStatusName = null;
			List<OrderUserBpmTasks> orderUserBpmTaskList = orderUserBpmTasksRepository.findByOrders(order);
			for (OrderUserBpmTasks taskObj : orderUserBpmTaskList) {
				if (null != taskObj) {
					if ((taskObj.getBpmTask().getTaskId().equals(commonBO.getTaskId()))) {
						taskStatusName = taskObj.getTaskStatus().getTaskStatusDesc();
						if (CommonUtils.isNotNullEmpty(taskStatusName)) {
							logger.info("taskStatusName :: " + taskStatusName);
							if (taskStatusName.equalsIgnoreCase("CREATED")) {
								commonBO.setTaskStatusName(taskStatusName);
								break;
							}
						}
					
					} else {
						logger.info("taskStatusName is null for orderId ::  " + commonBO.getOrderId()
								+ " for the task :: " + commonBO.getTaskId());
					}
				}
			}
			commonBO.setOrderOperation(orderOperation);
			execution.setVariable(BpmConstant.BPM_STATUS_ID, taskStatusName);
			execution.setVariable(BpmConstant.USER_DECISION, commonBO.getTaskUserDecision());
			execution.setVariable(BpmConstant.COMMON_BO, commonBO);
			
		}else {
			logger.error("orderId and orderOperation are null ::: ");
		}
		
		} catch (Exception e) {
			logger.error("", new CamundaServiceException("DB Operation failed for TTU Schedule Change Request TTU_Error001"));
			throw new BpmnError("TTU_Error001");
		}
		logger.info("Ending gettingUserDecision method ");
	}

	private void terminatingInProgressTask(DelegateExecution execution) throws URISyntaxException, CamundaServiceException {
		Long orderId = (Long) execution.getVariable("orderId");
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		try {
			if (commonBO != null) {
				commonServiceHelper.taskCompletedService(commonBO, execution);
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.USER_DECISION, commonBO.getTaskUserDecision());
				execution.setVariable(BpmConstant.ORDER_ID, orderId);
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
			}
		}catch (Exception e) {
			execution.setVariable("ERROR_CODE", "ErrorCodeConstant.COMET_MB001");
			throw new CamundaServiceException("In proper request from comet app");
		}
	}

}
