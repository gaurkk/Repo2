package com.att.comet.bpm.common.constant;

public class BpmConstant {
	/*
	 * Common
	 */
	public static final String ORDER_ID = "orderId";
	public static final String APN_NAME = "apnName";
	public static final String ACCOUNT_NAME = "accountName";
	public static final String CIPN = "cipn";
	public static final String BACKHAUL_IDS = "backhaulIds";
	public static final String URL = "url";
	public static final String PDP_NAME = "pdpName";
	public static final String PROCESS_TYPE = "processType";
	public static final String ORDER_TYPE = "orderType";
	public static final String EXPEDITE = "expediteOrder";
	public static final String CATEGORY = "categoryId";
	public static final String COMMON_BO = "commonBO";
	public static final String REJECTED_BY = "rejectedBy";
	public static final String TICKET_NUM = "ticketNum";
	public static final String TICKET_CREATION_DATE = "ticketCreateDate";
	public static final String TTU_RESULT = "ttuResult";
	public static final String IS_TTU_REQUIRED = "isTTURequired";
	public static final String USER_DECISION = "userDecision";
	public static final String BPM_STATUS_ID = "bpmStatusId";
	public static final String TTU_PERFORMED = "ttuIsPerformedForTheOrder";
	public static final String RESCHEDULED = "rescheduled";
	public static final String IS_PRE_FLIGHT_TEST_OCCURED = "isPreFlightTestOccurred";
	public static final String PRE_FLIGHT_TESTING_DATE_TIME = "PreFlightTestingDateTime";
	public static final String PRE_FLGIHT_TESTING_RESULT = "preFlightTestingResult";
	public static final String REASON_FOR_RESCHEDULE = "reasonForReschedule";
	public static final String TTU_RE_SCHEDULE_DATE = "ttuRescheduleDateTime";
	public static final String TTU_SCHEDULE_DATE = "ttuScheduleDateTime";
	public static final String BASE_ORDER = "BASE_ORDER"; 
	public static final String COMPLETE_WORK_FLOW = "completeWorkFlow";
	public static final String ORDER_USER_TASK_FALULTS = "orderUserTaskFaults";

	public static final String BPM_ERROR_CODE = "BPM_ERROR_CODE";
	public static final String APN_HLR_IWOS_CREATION_BPM_ERROR_CODE = "APN_HLR_IWOS_CREATION_BPM_ERROR_CODE";
	public static final String APN_HLR_IWOS_COMPLETION_BPM_ERROR_CODE = "APN_HLR_IWOS_COMPLETION_BPM_ERROR_CODE";
	public static final String DECOM_APN_HLR_BPM_ERROR_CODE = "DECOM_APN_HLR_BPM_ERROR_CODE";
	public static final String NI_DECOM_BPM_ERROR_CODE = "NI_DECOM_BPM_ERROR_CODE";
	public static final String DECOM_OA_BILLING_SUBMISSION_BPM_ERROR_CODE = "DECOM_OA_BILLING_SUBMISSION_BPM_ERROR_CODE";
	public static final String DECOM_DASHBOARD_BPM_ERROR_CODE = "DECOM_DASHBOARD_BPM_ERROR_CODE";
	public static final String DECOM_CONFIRMATION_BPM_ERROR_CODE = "DECOM_CONFIRMATION_BPM_ERROR_CODE";
	public static final String EXPEDITE_OA_BPM_ERROR_CODE = "EXPEDITE_OA_BPM_ERROR_CODE";
	public static final String EXPEDITE_OM_BPM_ERROR_CODE = "EXPEDITE_OM_BPM_ERROR_CODE";
	public static final String EXPEDITE_OSD_BPM_ERROR_CODE = "EXPEDITE_OSD_BPM_ERROR_CODE";
	public static final String EXPEDITE_NI_BPM_ERROR_CODE = "EXPEDITE_NI_BPM_ERROR_CODE";
	public static final String TTU_APPLICABILITY_BPM_ERROR_CODE = "TTU_APPLICABILITY_BPM_ERROR_CODE";
	public static final String TTU_PREFLIGHT_BPM_ERROR_CODE = "TTU_PREFLIGHT_BPM_ERROR_CODE";
	public static final String TTU_RESULT_BPM_ERROR_CODE = "TTU_RESULT_BPM_ERROR_CODE";
	public static final String TTU_SCHEDULE_BPM_ERROR_CODE = "TTU_SCHEDULE_BPM_ERROR_CODE";
	public static final String TTU_RESCHEDULE_BPM_ERROR_CODE = "TTU_RESCHEDULE_BPM_ERROR_CODE";
	public static final String TTU_PERFORM_BPM_ERROR_CODE = "TTU_PERFORM_BPM_ERROR_CODE";
	public static final String APN_ITOPS_BPM_ERROR_CODE = "APN_ITOPS_BPM_ERROR_CODE";
	public static final String OA_APPROVAL_BPM_ERROR_CODE = "OA_APPROVAL_BPM_ERROR_CODE";
	public static final String OM_APPROVAL_BPM_ERROR_CODE = "OM_APPROVAL_BPM_ERROR_CODE";
	public static final String OA_BILLING_BPM_ERROR_CODE = "OA_BILLING_BPM_ERROR_CODE";
	public static final String NI_BPM_ERROR_CODE = "NI_BPM_ERROR_CODE";
	public static final String APN_IWOS_COMPLETION_SUSPENSION_BPM_ERROR_CODE = "APN_IWOS_COMPLETION_SUSPENSION_BPM_ERROR_CODE";
	public static final String OS_ORDER_UPDATE_BPM_ERROR_CODE = "OS_ORDER_UPDATE_BPM_ERROR_CODE";
	public static final String CO_DASHBOARD_BPM_ERROR_CODE = "CO_DASHBOARD_BPM_ERROR_CODE";
	public static final String CO_NI_BPM_ERROR_CODE = "CO_NI_BPM_ERROR_CODE";
	public static final String CO_BILLING_BPM_ERROR_CODE = "CO_BILLING_BPM_ERROR_CODE";
	public static final String CO_CR_OA_BPM_ERROR_CODE = "CO_CR_OA_BPM_ERROR_CODE";
	public static final String DAPN_OA_BPM_ERROR_CODE = "DAPN_OA_BPM_ERROR_CODE";
	public static final String DAPN_OSD_BPM_ERROR_CODE = "DAPN_OSD_BPM_ERROR_CODE";
	public static final String DAPN_BUILD_BPM_ERROR_CODE = "DAPN_BUILD_BPM_ERROR_CODE";
	public static final String DAPN_BILLING_BPM_ERROR_CODE = "DAPN_BILLING_BPM_ERROR_CODE";

	public static final String APN_IWOS_CREATION_BPM_ERROR_CODE = "APN_IWOS_CREATION_BPM_ERROR_CODE";

	public static final String APN_IWOS_OSD_ORDER_UPDATE_BPM_ERROR_CODE = "APN_IWOS_OSD_ORDER_UPDATE_BPM_ERROR_CODE";

	public static final String DAPN_RELEASE_BPM_ERROR_CODE = "DAPN_RELEASE_BPM_ERROR_CODE";

	public static final String OA_DAPN_BUILD_CANCELLATION_BPM_ERROR_CODE = "OA_DAPN_BUILD_CANCELLATION_BPM_ERROR_CODE";

	public static final String ITOPS_DAPN_CANCELLATION_BPM_ERROR_CODE = "ITOPS_DAPN_CANCELLATION_BPM_ERROR_CODE";
	
	public static final String DAPN_CANCELLATION_BPM_ERROR_CODE = "DAPN_CANCELLATION_BPM_ERROR_CODE";
	
	public static final String PCRF = "pcrf";
	public static final String ORDER_TYPE_ID = "orderTypeId";
	public static final String IS_TERMINATED = "isTerminated";
	public static final String TTU_USER_DECISION = "ttuUserDecision";
	public static final String APN_IWOS_USER_DECISION = "apnIwosUserDecision";
	public static final String ITOPS_USER_DECISION = "itOpsUserDecision";
	public static final String APN_IWOS_HLR_USER_DECISION = "apnIwosHlrUserDecision";
	public static final String BILLING_USER_DECISION = "billingUserDecision";
	public static final String DASHBOARD_RESPONSE = "dashboardResponse";
	public static final String AMP_ELIGIBILTIY = "ampEligible";
	public static final String OA_BILLING_TASK_STATUS= "newOrderBillingTask";

	public static final String APN_IWOS_BUILD_CONFIRMATION = "apnIWOSbuildConfirmation";
	public static final String RESPONSE = "response";
	public static final String COMMENTS = "comments";
	public static final String APPROVED = "Approved";
	public static final String REJECTED = "Rejected";
	public static final String BPM_STATUS_NAME = "bpmStatusName";
	public static final String CREATED = "CREATED";
	public static final String COMPLETED = "COMPLETED";
	public static final String ORDER_OPERATION = "orderOperation";
	public static final String ORDER_STATUS = "orderStatus";
	public static final String CANCEL_IN_PROGRESS = "Cancel – In Progress";
	public static final String COMPLETION_DATE = "completionDate";
	public static final String COMPLETED_DATE = "completedDate";
	public static final String EXPEDITE_FINAL_COMPLETED_DATE = "finalExpediteBuildCompletionDate";
	public static final String EXPEDITE_PROPOSED_COMPLETED_DATE = "proposedExpediteBuildCompletionDate";

	/*
	 * OS Order Update
	 */
	public static final String ORDER_REJECTED_BY_INFO = "OrderRejectedByInfo";
	public static final String PRE_OPERATION_OA_REJECT = "PreOperationOAReject";
	public static final String POST_OPERATION_OA_REJECT = "PostOperationOAReject";
	public static final String PRE_OPERATION_OM_REJECT = "PreOperationOMReject";
	public static final String POST_OPERATION_OM_REJECT = "PostOperationOMReject";

	/*
	 * OA Billing Submission
	 */
	public static final String VERIFY_ORDER_STATUS = "VerifyOrderStatus";
	public static final String PRE_OPERATION_OA_BILLING = "OABillingPreOperation";
	public static final String OPERATION_OA_BILLING_TASK = "OperationOABillingTask";
	public static final String POST_OPERATION_OA_BILLING = "OABillingPostOperation";
	public static final String BILLING_TASK_STATUS = "billingTaskStatusCheck";
	/*
	 * OA Approval
	 */
	public static final String OA_PRE_OPERATION = "OAPreOperation";
	public static final String APPROVED_BY_OA = "ApprovedByOA";
	public static final String REJECTED_BY_OA = "RejectedByOA";
	/*
	 * OM Approval
	 */
	public static final String OM_PRE_OPERATION = "OMPreOperation";
	public static final String OM_USER_TASK = "OMUserTask";
	public static final String APPROVED_BY_OM = "ApprovedByOM";
	public static final String REJECTED_BY_OM = "RejectedByOM";
	/*
	 * APNHLRIWOS Creation
	 */
	public static final String CHECK_ORDER_STATUS = "CheckOrderStatus";
	public static final String PRE_OPERATION_IWOS_CREATION = "PreOperationIWOSCreation";
	public static final String POST_OPERATION_IWOS_CREATION = "PostOperationIWOSCreation";

	/*
	 * APNHLRIWOS Completion
	 */
	public static final String PRE_OPERATION_IWOS_COMPLETION = "PreOperationIWOSCompletion";
	public static final String POST_OPERATION_IWOS_COMPLETION = "PostOperationIWOSCompletion";
	/*
	 * CCS PM Network IWOS Creation
	 */
	public static final String PRE_OPERATION_NETWORK_IWOS_CREATION = "PreOperationNetworkIWOSCreation";
	public static final String POST_OPERATION_NETWORK_IWOS_CREATION = "PostOperationNetworkIWOSCreation";
	public static final String NI_APN_BUILD_TASK = "NIAPNBuildTask";

	/*
	 * CCS PM Network IWOS Completion
	 */
	public static final String APN_IWOS_PRE_ORDER_STATUS = "preOrderStatusCheck";
	public static final String APN_IWOS_PRE_OPERATION = "preOperationApnIwosCreation";
	public static final String APN_IWOS_POST_OPERATION = "postOperationApnIwosCompletion";
	public static final String APN_IWOS_POST_OPERATION_SUS_COM = "postOperationApnIwosComSus";
	/*
	 * CCS PM Network IWOS Suspension
	 */
	public static final String APN_IWOS_ORDER_TYPE = "preOrderTypeCheck";
	public static final String APN_IWOS_OSD_PRE_OPERATION = "preOperationApnIwosOSDUpdate";
	public static final String APN_IWOS_OSD_POST_OPERATION = "postOperationApnIwosOSDUpdate";
	public static final String NEW_ORDER_UPDATE_OPERATION = "newOrderUpdateOperation";
	public static final String CR_CO_UPDATE_OPERATION = "COCRUpdateOperation";

//Need to remove
	public static final String PRE_OPERATION_NETWORK_IWOS_COMPLETION = "PreOperationNetworkIWOSCompletion";
	public static final String IWOS_STATUS_TASK = "IwosStatusTask";
	public static final String IWOS_COMPLETED_TASK = "IwosCompletedTask";
	public static final String OS_NI_FEEDBACK_COMPLETE_PRE_OPERATION = "OsNiFeedbackCompletePreOperation";
	public static final String OS_NI_FEEDBACK_COMPLETE_POST_OPERATION = "OsNIFeedbackCompletePostOperation";
	/*
	 * CCS PM : Change Request Dashboard Task
	 */
	public static final String PRE_OPERATION_DASHBOARD_TASK = "PreOperationDashBoardTask";
	public static final String POST_OPERATION_DASHBOARD_TASK = "PostOperationDashBoardTask";
	/*
	 * NI Order Update
	 */
	public static final String PRE_OPERATION = "PreOperationNIOrderUpdate";
	public static final String POST_OPERATION = "PostOperationNIOrderUpdate";

	/*
	 * OA CR Approval
	 */
	public static final String PRE_OPERATION_OA_CR_APPROVAL = "PreOperationOACRApproval";
	public static final String POST_OPERATION_OA_CR_APPROVAL = "PostOperationOACRApproval";
	/*
	 * OSD TTU Task
	 */
	public static final String PRE_OPERATION_TTU_PRE_FLIGHT = "PreOperationTtuPreflight";
	public static final String POST_OPERATION_TTUPRE_FLIGHT = "PostOperationTtuPreflight";
	public static final String PRE_OPERATION_TTU_APPLICABILITY = "PreOperationTtuApplicability";
	public static final String POST_OPERATION_TTU_APPLICABILITY = "PostOperationTtuApplicability";
	public static final String PRE_OPERATION_TTU_SCHEDULE = "PreOperationTtuSchedule";
	public static final String POST_OPERATION_TTU_SCHEDULE = "PostOperationTtuSchedule";
	public static final String PRE_OPERATION_TTU_PERFORM = "PreOperationTtuPerform";
	public static final String POST_OPERATION_TTU_PERFORM = "PostOperationTtuPerform";
	public static final String PRE_OPERATION_TTU_RESULT = "PreOperationTtuResult";
	public static final String POST_OPERATION_TTU_RESULT = "PostOperationTtuResult";
	public static final String PRE_OPERATION_TTU_RESCHEDULE = "PreOperationTtuReSchedule";
	public static final String POST_OPERATION_TTU_RESCHEDULE = "PostOperationTtuReSchedule";
	public static final String ORDER_STATUS_CHECK = "orderStatusCheck";
	public static final String USER_DECISION_CHECK = "userDesicionCheck";
	public static final String TERMINATE_TASK = "terminatingTask";
	public static final String TASK_COMPLETION = "taskCompletion";
	public static final String URL_NAME = "SEARCH_ORDER_URL";
	public static final String TTU_PRE_OPERATION = "ttuProcessPreOpration";

	/*
	 * IT OPS : APN IT OPS
	 */
	public static final String PRE_OPERATION_ITOPS = "PreOperationItOps";
	public static final String POST_OPERATION_ITOPS = "PostOperationItOps";
	public static final String EXPEDITE_ORDER_TASK = "expediteOrder";
	public static final String AMP_ELIGIBILTY_CHECK = "ampEligibilityCheck";
	public static final String UPDATE_AMP_SKIP = "updateSkipAmp";
	// Order operation
	public static final String CHANGE_REQUEST = "CHANGE_REQUEST";
	public static final String NEW_ORDER = "NEW_ORDER";
	public static final String CHANGE_ORDER = "CHANGE_ORDER";
	public static final String EXPEDITE_ORDER = "EXPEDITE_ORDER";
	public static final String CANCEL_ORDER = "CANCEL_ORDER";
	public static final String DECOMMISSION_ORDER = "DECOMMISSION_ORDER";
	public static final String ONHOLD_ORDER = "ONHOLD_ORDER";
	public static final String DAPN_ORDER = "DAPN_ORDER";

	/**
	 * CR OA
	 */
	public static final String OA_CR_PRE_OPERATION = "preOperationOACRApproval";
	public static final String OA_CR_POST_OPERATION = "postOperationOACRApproval";
	public static final String OA_CR_APPROVED = "oaCRApproved";
	public static final String OA_CR_REJECTED = "oaCRRejected";

	/**
	 * CR Dashboard
	 */
	public static final String CR_PRE_OPERATION = "preOperation";
	public static final String CR_PRE_ORDER_STATUS = "checkOrderType";
	public static final String CR_POST_OPERATION = "postOperation";
	public static final String CR_POST_ORDER_STATUS = "postOrderStatusCheck";
	public static final String NEW_ORDER_PRE_OPERATION = "preOperation";
	public static final String NEW_ORDER_POST_OPERATION = "postOperation";
	/**
	 * CR OM
	 */
	public static final String CR_OM_PRE_OPERATION = "fetchTaskProcessStatus";
	public static final String CR_OM_TERMINATION = "terminateTask";

	/*
	 * CCS PM : Change Request ApnIwosCreation Task
	 */
	public static final String CHECK_USERDECESION = "CheckUserDecesion";
	public static final String COMPLETE_PROCESS = "CompleteProcess";

	/*
	 * OA CR Billing Submission
	 */
	public static final String PRE_OPERATION_OA_CR_BILLING = "OACRBillingPreOperation";
	public static final String OPERATION_OA_CR_BILLING_TASK = "OperationOACRBillingTask";
	public static final String POST_OPERATION_OA_CR_BILLING = "OACRBillingPostOperation";

	/**
	 * CR Process
	 */

	public static final String ORDER_STATUS_UPDATE = "orderStatusUpdate";
	public static final String CO_PRE_OPERATION = "preOperation";
	/**
	 * CANCEL ORDER Process
	 */
	public static final String CANCEL_ORDER_PRE_OPERATION = "cancelOrderPreOperation";
	public static final String PENDING_TASK_STATUS = "pendingTaskStatusCheck";
	public static final String CHECK_USER_DECESION = "userDecisionCheck";
	public static final String CANCEL_ORDER_POST_OPERATION = "cancelOrderPostOperation";
	public static final String PREOPERATION_MAIN = "preOperation";
	public static final String OM_TASK_STATUS = "omTaskStatus";
	public static final String APN_IT_OPS_TASK_STATUS = "apnItOpsTaskStatus";
	public static final String APN_IWOS_TASK_STATUS = "apnIwosTaskStatus";
	public static final String TTU_PREFLIGHT_TASK_STATUS = "ttuPreflightTaskStatus";
	public static final String TTU_APPLICABILITY_TASK_STATUS = "ttuApplicabilityTaskStatus";
	public static final String TTU_RESULT_TASK_STATUS = "ttuResultTaskStatus";
	public static final String TTU_RESCHEDULE_TASK_STATUS = "ttuRescheduleTaskStatus";
	public static final String TTU_PERFORM_TASK_STATUS = "ttuPerformTaskStatus";
	public static final String TTU_SCHEDULE_TASK_STATUS = "ttuScheduleTaskStatus";
	public static final String CO_DASHBOARD_PRE_OPERATION = "cancelDashboardPreOperation";
	public static final String CO_DASHBOARD_POST_OPERATION = "cancelDashboardPostOperation";
	public static final String NI_ROLLBACK_PRE_OPERATION = "niRollbackPreOperation";
	public static final String NI_ROLLBACK_POST_OPERATION = "niRollbackPostOperation";

	/**
	 * DECOMMISSION Process
	 */
	public static final String PRE_OPERATION_DECOM = "preOperation";
	public static final String CHECK_USER_DECISION = "checkUserDecision";
	public static final String POST_USER_TASK_OPERATION = "postUserTaskOperation";
	public static final String POST_CONFIRMATION_TASK_OPERATION = "postConfirmationTaskOperation";

	/**
	 * DECOMMISSION Dashboard
	 */
	public static final String PRE_DASHBOARD_OPERATION = "preDashboardOperation";
	public static final String CHECK_USER_ENTRY = "checkUserEntry";
	public static final String POST_DASHBOARD_OPERATION = "postDashboardOperation";
	public static final String USER_ENTRY = "userEntry";

	/**
	 * DECOMMISSION APNHLR_DECOM
	 */
	public static final String PRE_OPERATION_APNHLR_DECOM = "PreOperationAPNHLRDecom";
	public static final String POST_OPERATION_APNHLR_DECOM = "PostOperationAPNHLRDecom";
	/**
	 * EXPEDITE ORDER Process
	 */
	public static final String PRE_EXPEDITE_OPERATION = "preExpediteOperation";
	public static final String POST_EXPEDITE_OPERATION = "postExpediteOperation";
	public static final String EXPEDITE_FLAG_BEFORE = "setExpediteFlagBefore";
	public static final String EXPEDITE_FLAG_AFTER = "setExpediteFlagAfter";
	/**
	 * EXPEDITE OA Process
	 */
	public static final String PRE_EXPEDITE_OA_OPERATION = "preExpediteOAOperation";
	public static final String POST_EXPEDITE_OA_OPERATION = "postExpediteOAOperation";
	/**
	 * EXPEDITE OM Process
	 */
	public static final String PRE_EXPEDITE_OM_OPERATION = "preExpediteOMOperation";
	public static final String POST_EXPEDITE_OM_OPERATION = "postExpediteOMOperation";
	/**
	 * EXPEDITE OSD Process
	 */
	public static final String PRE_EXPEDITE_OSD_OPERATION = "preExpediteOSDOperation";
	public static final String POST_EXPEDITE_OSD_OPERATION = "postExpediteOSDOperation";
	/**
	 * EXPEDITE NI Process
	 */
	public static final String PRE_EXPEDITE_NI_OPERATION = "preExpediteNIOperation";
	public static final String POST_EXPEDITE_NI_OPERATION = "postExpediteNIOperation";

	/**
	 * DECOMMISSION APNIWOS_DECOM
	 */
	public static final String PRE_OPERATION_APNIWOS_DECOM = "PreOperationAPNIWOSDecom";
	public static final String POST_OPERATION_APNIWOS_DECOM = "PostOperationAPNIWOSDecom";

	/**
	 * DECOMMISSION OABILLING_DECOM
	 */
	public static final String PRE_OPERATION_OABILLING_DECOM = "PreOperationOABillingDecom";
	public static final String POST_OPERATION_OABILLING_DECOM = "PostOperationOABillingDecom";

	/**
	 * DECOMMISSION CONFIRMATION
	 */
	public static final String PRE_OPERATION_CONFIRMATION_DECOM = "preOperationConfirmationDecom";
	public static final String POST_OPERATION_CONFIRMATION_DECOM = "postOperationConfirmationDecom";

	public static final String COMPLETE_ORDER_WORKFLOW = "COMET_ORDER_PKG.COMPLETE_ORDER_WORKFLOW";
	/**
	 * D-APN ORDER Process
	 */
	public static final String PRE_DAPN_OPERATION = "preDAPNOperation";
	public static final String POST_DAPN_OPERATION = "postDAPNOperation";
	public static final String DAPN_STATUS_UPDATE = "dapnStatusUpdate";
	public static final String DAPN_STATUS_UPDATE_PROD = "dapnStatusUpdateProd";
	public static final String DAPN_BILLING_SLA = "dapnBillingSla";
	/**
	 * D-APN OA Process
	 */
	public static final String PRE_DAPN_OA_OPERATION = "preDapnOAOperation";
	public static final String POST_DAPN_OA_OPERATION = "postDapnOAOperation";
	/**
	 * D-APN Billing Process
	 */
	public static final String PRE_DAPN_BILLING_OPERATION = "preDapnBillingOperation";
	public static final String POST_DAPN_BILLING_OPERATION = "postDapnBillingOperation";
	/**
	 * D-APN Build Process
	 */
	public static final String PRE_DAPN_BUILD_OPERATION = "preDapnBuildOperation";
	public static final String POST_DAPN_BUILD_OPERATION = "postDapnBuildOperation";
	/**
	 * D-APN OSD Process
	 */
	public static final String PRE_DAPN_OSD_OPERATION = "preDapnOsdOperation";
	public static final String POST_DAPN_OSD_OPERATION = "postDapnOsdOperation";
	
	public static final String ONHOLD_REQUEST_BPM_ERROR_CODE = "ONHOLD_REQUEST_BPM_ERROR_CODE";
	/**
	 * ONHOLD Process
	 */
	public static final String ONHOLD_PRE_OPERATION = "onHoldPreOperation";
	public static final String ONHOLD_CANCEL_OPERATION = "onHoldCancelOperation";
	public static final String ONHOLD_RESUME_OPERATION = "onHoldResumeOperation";
	public static final String ONHOLD_OTHER_OPERATION = "onHoldOtherOperation";
	
	/**
	 * ONHOLD REQUEST
	 */
	public static final String PRE_REQUEST_OPERATION = "preRequestOperation";
	public static final String POST_REQUEST_OPERATION = "postRequestOperation";
	public static final String UPDATE_ORDERS_OPERATION = "updateOrdersOperation";
	public static final String SLA_SPECIFIED_OPERATION = "slaSpecifiedOperation";
	public static final String SLA_NOT_SPECIFIED_OPERATION = "slaNotSpecifiedOperation";
	public static final String REJECT_OPERATION = "rejectOperation";
	public static final String OH_INTERRUPTED = "ohInterrupted";
	public static final String SLA_SPECIFIED_REMINDER_X_OPERATION = "slaSpecifiedReminderXOperation";
	public static final String SLA_NOT_SPECIFIED_REMINDER_X_OPERATION = "slaNotSpecifiedReminderXOperation";
	public static final String ONHOLD_REQUESTED_DATE = "onHoldRequestedDate";
	public static final String ONHOLD_PROPOSED_COMPLETION_DATE = "onHoldPropCompletionDate";
	public static final String ONHOLD_REASON = "onHoldReason";
	public static final String ONHOLD_NOTES = "onHoldNotes";
	public static final String COUNT_REMINDER_EMAILS = "countReminderEmails";
	
	/**
	 * DAPN_RELEASE
	 */
	public static final String PRE_OPERATION_DAPN_RELEASE = "PreOperationDapnRelease";
	public static final String POST_OPERATION_DAPN_RELEASE = "PostOperationDapnRelease";
	
	/**
	 * OA_DAPN_BUILD_CANCELLATION
	 */
	public static final String PRE_OPERATION_OA_DAPN_BUILD_CANCELLATION = "PreOADAPNBuildCancellation";
	public static final String POST_OPERATION_OA_DAPN_BUILD_CANCELLATION = "PostOADAPNBuildCancellation";
	
	/**
	 * ITOPS_DAPN_CANCELLATION 
	 */
	public static final String PRE_OPERATION_ITOPS_DAPN_CANCELLATION = "PreITOPSDAPNCancellation";
	public static final String POST_OPERATION_ITOPS_DAPN_CANCELLATION = "PostITOPSDAPNCancellation";
	
	/**
	 * DAPN_CANCELLATION
	 */
	public static final String DAPN_CANCELLATION_CHECK_BPM_STATUS = "CheckBpmStatus";
	public static final String DAPN_CANCELLATION_DAPN_OPERATION = "DapnOperation";
	/*
	 * Email Reminders
	 * 
	 */
	public static final String EMAIL_REMINDER_1 = "emailReminder1";
	public static final String EMAIL_REMINDER_2 = "emailReminder2";
}