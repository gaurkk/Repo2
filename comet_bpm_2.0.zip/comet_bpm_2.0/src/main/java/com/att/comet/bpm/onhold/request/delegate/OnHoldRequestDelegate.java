package com.att.comet.bpm.onhold.request.delegate;

import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.core.processes.delegate.helper.CoreProcessDelegateHelper;
import com.att.comet.bpm.onhold.request.service.OnHoldRequestService;

@Component
public class OnHoldRequestDelegate implements JavaDelegate {

	private static final Logger logger = LoggerFactory.getLogger(OnHoldRequestDelegate.class);

	@Autowired
	private CommonService commonService;
	@Autowired
	CoreProcessDelegateHelper coreProcessDelegateHelper;
	@Autowired
	private OnHoldRequestService onHoldRequestService;

	public static final String URL_NAME = "SEARCH_ORDER_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.PRE_REQUEST_OPERATION:
					preRequestOperation(execution);
					break;
				case BpmConstant.POST_REQUEST_OPERATION:
					postRequestOperation(execution);
					break;
				case BpmConstant.UPDATE_ORDERS_OPERATION:
					updateOrdersOperation(execution);
					break;
				case BpmConstant.SLA_SPECIFIED_OPERATION:
					slaSpecifiedOperation(execution);
					break;
				case BpmConstant.SLA_SPECIFIED_REMINDER_X_OPERATION:
					slaSpecifiedReminderXOperation(execution);
					break;
				case BpmConstant.SLA_NOT_SPECIFIED_OPERATION:
					slaNotSpecifiedOperation(execution);
					break;
				case BpmConstant.SLA_NOT_SPECIFIED_REMINDER_X_OPERATION:
					slaNotSpecifiedReminderXOperation(execution);
					break;
				case BpmConstant.REJECT_OPERATION:
					rejectOperation(execution);
					break;
				default:
					logger.debug("Please provide valid value for OPERATION:{}", operationType);
				}
			} else {
				logger.error("COMET Request Does not have operationType::", this);
			}
		} catch (Exception e) {// catch all exception
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			/*
			 * this will throw bpmn error and will be catch into bpmn
			 * model(ONHOLD_REQUEST_BPM_ERROR_CODE should be same for delegate and BPMN
			 * mapping)
			 */
			throw new CamundaBpmnError(BpmConstant.ONHOLD_REQUEST_BPM_ERROR_CODE, orderUserTaskFaultsBO.getErrorCode());
		}

	}

	private void slaNotSpecifiedReminderXOperation(DelegateExecution execution) {
		logger.info("Start slaNotSpecifiedReminderXOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		int countReminderEmails;
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			countReminderEmails = (int) execution.getVariable(BpmConstant.COUNT_REMINDER_EMAILS);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				commonBO.setCountReminderEmails(countReminderEmails);
				if (null != commonBO) {
					commonBO.setUpdatedOn(new Date());
					onHoldRequestService.slaNotSpecifiedReminderXOperation(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable("reminderXSlaDate", commonBO.getReminderXSlaDate());
					execution.setVariable("countReminderEmails", commonBO.getCountReminderEmails());
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST REMINDERX SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST REMINDERX SERVICE EXCEPTION");
		}
		logger.info("End slaNotSpecifiedReminderXOperation method ::", this);

	}

	private void slaSpecifiedReminderXOperation(DelegateExecution execution) {
		logger.info("Start slaSpecifiedReminderXOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		int countReminderEmails;
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			countReminderEmails = (int) execution.getVariable(BpmConstant.COUNT_REMINDER_EMAILS);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				commonBO.setCountReminderEmails(countReminderEmails);
				if (null != commonBO) {
					onHoldRequestService.slaSpecifiedReminderXOperation(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable("reminderXSlaDate", commonBO.getReminderXSlaDate());
					execution.setVariable("countReminderEmails", commonBO.getCountReminderEmails());
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST REMINDERX SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST REMINDERX SERVICE EXCEPTION");
		}
		logger.info("End slaSpecifiedReminderXOperation method ::", this);

	}

	private void rejectOperation(DelegateExecution execution) throws CamundaServiceException {
		CommonBO commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		commonBO.setOrderStatusId(1047L);
		//commonBO.setDateInProduction(sysdate);
		coreProcessDelegateHelper.updateOrderStaus(commonBO);
		commonBO.setTaskId(1046L); // 
		commonBO.setApproved((String)execution.getVariable(BpmConstant.RESPONSE));
		commonBO.setApproved(BpmConstant.REJECTED);
		execution.setVariable(BpmConstant.COMMON_BO, commonBO);
	}

	private void slaNotSpecifiedOperation(DelegateExecution execution) {
		logger.info("Start slaNotSpecifiedOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		int countReminderEmails = 3; // Since 2 Reminder Emails have already been sent . Count should start from 3
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					onHoldRequestService.slaNotSpecifiedOperation(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable("reminderXSlaDate", commonBO.getReminderXSlaDate());
					execution.setVariable(BpmConstant.COUNT_REMINDER_EMAILS, countReminderEmails);
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST SLANOTSPECIFIED SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST SLANOTSPECIFIED SERVICE EXCEPTION");
		}
		logger.info("End slaNotSpecifiedOperation method ::", this);

	}

	private void slaSpecifiedOperation(DelegateExecution execution) {
		logger.info("Start slaSpecifiedOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		int countReminderEmails = 3; // Since 2 Reminder Emails have already been sent . Count should start from 3
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					onHoldRequestService.slaSpecifiedOperation(commonBO);
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable("reminder1SlaDate", commonBO.getReminder1SlaDate());
					execution.setVariable("reminder2SlaDate", commonBO.getReminder2SlaDate());
					execution.setVariable("reminderXSlaDate", commonBO.getReminderXSlaDate());
					execution.setVariable(BpmConstant.COUNT_REMINDER_EMAILS, countReminderEmails); // countReminderEmails
																									// = 3
				}
				commonBO.setCountReminderEmails(countReminderEmails);
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST SLASPECIFIED SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST SLASPECIFIED SERVICE EXCEPTION");
		}
		logger.info("End slaSpecifiedOperation method ::", this);

	}

	private void updateOrdersOperation(DelegateExecution execution) {
		logger.info("Start updateOrdersOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		try {
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					onHoldRequestService.updateOrdersOperation(commonBO);
					// setting for email subject
					commonBO.setTaskDescription(
							"On-hold pending to be resolved for Order ID -" + commonBO.getOrderId() + " with APN -"
									+ commonBO.getApnName() + "  " + "for Account - " + commonBO.getAccountName());
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST UPDATEORDERS SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST UPDATEORDERS SERVICE EXCEPTION");
		}
		logger.info("End updateOrdersOperation method ::", this);

	}

	private void postRequestOperation(DelegateExecution execution) {
		logger.info("Start postRequestOperation method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		try {
			// value fetch from COMET FRONTEND by Assign USER
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			String response = (String) execution.getVariable(BpmConstant.RESPONSE);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					/*
					 * commonBO.setOnHoldProposedCompletionDate( (String)
					 * execution.getVariable(BpmConstant.ONHOLD_PROPOSED_COMPLETION_DATE));
					 */
					commonBO.setApproved(response);
					onHoldRequestService.postRequestOperation(commonBO, execution);
					// setting for email subject
					if (execution.getVariable(BpmConstant.RESPONSE).toString().equalsIgnoreCase(BpmConstant.APPROVED)) {
						commonBO.setTaskDescription("On-hold Request has been approved for Order ID - "
								+ commonBO.getOrderId() + " with APN -" + commonBO.getApnName() + "  "
								+ "for Account - " + commonBO.getAccountName());
					} else {
						commonBO.setTaskDescription("On-hold Request has been rejected for Order ID - "
								+ commonBO.getOrderId() + " with APN -" + commonBO.getApnName() + "  "
								+ "for Account - " + commonBO.getAccountName());
					}
					commonBO.setApproved(response);
					execution.setVariable(BpmConstant.ONHOLD_REQUESTED_DATE, (Date) commonBO.getOnHoldRequestedDate());
					execution.setVariable(BpmConstant.ONHOLD_PROPOSED_COMPLETION_DATE,
							commonBO.getOnHoldProposedCompletionDate() != null
									? (Date) commonBO.getOnHoldProposedCompletionDate()
									: null);
					execution.setVariable(BpmConstant.ONHOLD_REASON, commonBO.getOnHoldReason());
					execution.setVariable(BpmConstant.ONHOLD_NOTES, commonBO.getOnHoldNotes());
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.RESPONSE, commonBO.getApproved());
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
				throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST APPROVED SERVICE EXCEPTION");

			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::"
					+ new CamundaServiceException("DB Operation failure On Hold Process"), this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST APPROVED POST SERVICE EXCEPTION");
		}
		logger.info("End postRequestOperation method ::", this);

	}

	private void preRequestOperation(DelegateExecution execution) throws CamundaServiceException {

		logger.info("Start preRequestOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		String onHoldProcessInstanceId = (String) execution.getVariable("onHoldProcessInstanceId");
		commonBO = (CommonBO) execution.getVariable(BpmConstant.COMMON_BO);
		if (null != commonBO) {
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO) {
				execution.setVariable(BpmConstant.ORDER_ID, commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url() + commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");// User task
				commonBO.setRoleId(1001L);// Setting OS roleID
				commonBO.setBpmProcessInstanceId(onHoldProcessInstanceId);
				commonBO.setTaskStatusId(1001L);// Created
				commonBO.setTaskStatusName("OS : On-hold Request");
				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				commonBO.setTaskId(1046L);// Mapped from BPM_task table (OS : On-hold Request)
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				// ALL CRUD PREOPERATION for On HOLD REQUEST TASK
				onHoldRequestService.preOperation(commonBO, execution.getProcessInstanceId());
				// setting for email subject
				commonBO.setTaskDescription("On-hold Request for Order ID -" + commonBO.getOrderId() + " with APN -"
						+ commonBO.getApnName() + "  " + "for Account - " + commonBO.getAccountName());
				/*
				 * commonBO.setOnHoldRequestedDate((String)
				 * execution.getVariable(BpmConstant.ONHOLD_REQUESTED_DATE));
				 * commonBO.setOnHoldProposedCompletionDate( (String)
				 * execution.getVariable(BpmConstant.ONHOLD_PROPOSED_COMPLETION_DATE));
				 * commonBO.setOnHoldReason((String)
				 * execution.getVariable(BpmConstant.ONHOLD_REASON));
				 * commonBO.setOnHoldNotes((String)
				 * execution.getVariable(BpmConstant.ONHOLD_NOTES));
				 */
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} 
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "ON HOLD REQUEST TASK PREOPERATION SERVICE EXCEPTION");

		}
		logger.info("End preRequestOperation method ::", this);

	}

}
