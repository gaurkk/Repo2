package com.att.comet.bpm.decom.dashboard.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface DecomDashboardService {

	void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException;
	
	String checkUserEntry(CommonBO commonBO) throws CamundaServiceException;
	
	void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException;
	
}
