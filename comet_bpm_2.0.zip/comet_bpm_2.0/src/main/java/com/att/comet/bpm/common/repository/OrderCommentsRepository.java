package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.OrderComments;


@Repository
public interface OrderCommentsRepository extends JpaRepository<OrderComments, Long> {

	@Query(value = "select oc.comments from OrderComments oc where oc.orders.orderId=:orderId and oc.userAction=:userAction and oc.orderProcess=:orderProcess")
	String getOrderComments(Long orderId, String userAction, String orderProcess);
}
