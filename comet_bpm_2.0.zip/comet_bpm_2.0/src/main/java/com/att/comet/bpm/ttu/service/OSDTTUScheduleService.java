package com.att.comet.bpm.ttu.service;

import java.text.ParseException;
import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OSDTTUScheduleService {

	void postOperationOSDTTUSchedule(CommonBO commonBO, String OSDComments, String ttuScheduleDateTime) throws CamundaServiceException, ParseException;
	void preOperationOSDTTUSchedule(CommonBO commonBO) throws CamundaServiceException;
}
