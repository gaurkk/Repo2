package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for GraphicalReport. Mapped to BPM_READONLY_URL table in the
 * database.
 */

@Entity
@Table(name = "BPM_READONLY_URL")
public class GraphicalReport implements Serializable {

	private static final long serialVersionUID = -5237159375306788459L;

	private Long orderId;
	private String readOnlyURL;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_ID", unique = true, nullable = false)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for readOnlyURL. READ_ONLY_URL mapped to READ_ONLY_URL in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "READ_ONLY_URL", nullable = false, length = 300)
	public String getReadOnlyURL() {
		return this.readOnlyURL;
	}

	/**
	 * @param readOnlyURL to readOnlyURL set.
	 */
	public void setReadOnlyURL(String readOnlyURL) {
		this.readOnlyURL = readOnlyURL;
	}

}
