package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for BpmUrl. Mapped to BPM_URL table in the database.
 */
@Entity
@Table(name = "BPM_URL")
public class BpmUrl implements java.io.Serializable {

	private static final long serialVersionUID = 8927246436277379435L;

	private String urlName;
	private String url;
	private String new_url;

	/**
	 * No-argument constructor of the class.
	 */
	public BpmUrl() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param urlName
	 * @param url
	 */
	public BpmUrl(String urlName, String url,String new_url) {
		this.urlName = urlName;
		this.url = url;
		this.new_url = new_url;
	}

	/**
	 * Getter method for urlName. URL_NAME mapped to URL_NAME in the database table.
	 * 
	 * @return String
	 */
	@Id
	@Column(name = "URL_NAME", unique = true, nullable = false, length = 100)
	public String getUrlName() {
		return this.urlName;
	}

	/**
	 * @param urlName to urlName set.
	 */
	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	/**
	 * Getter method for url URL mapped to URL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "URL", nullable = false, length = 500)
	public String getUrl() {
		return this.url;
	}

	/**
	 * @param url to url set.
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "NEW_URL", nullable = false, length = 500)
	public String getNew_url() {
		return new_url;
	}

	public void setNew_url(String new_url) {
		this.new_url = new_url;
	}
	
	

}
