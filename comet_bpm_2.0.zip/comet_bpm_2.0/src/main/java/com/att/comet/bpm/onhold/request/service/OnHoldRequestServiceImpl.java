package com.att.comet.bpm.onhold.request.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.onhold.request.helper.OnHoldRequestHelper;

@Service
public class OnHoldRequestServiceImpl implements OnHoldRequestService {

	@Autowired
	OnHoldRequestHelper onHoldRequestHelper;

	@Autowired
	CommonService commonService;

	@Override
	public void preOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		onHoldRequestHelper.preOprCRUD(commonBO, processInstanceId);
	}

	@Override
	public void postRequestOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		onHoldRequestHelper.postOprCRUD(commonBO, execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setRoleId(1001L);
		commonBO.setCategoryId(1003L);// Service
		commonBO.setTaskStatusId(1002L);// Completed
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

	@Override
	public void updateOrdersOperation(CommonBO commonBO) throws CamundaServiceException {
		onHoldRequestHelper.updateOrdersOperation(commonBO);
		
	}

	@Override
	public void slaSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException {
		onHoldRequestHelper.slaSpecifiedOperation(commonBO);
		
	}
	
	@Override
	public void slaNotSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException {
		onHoldRequestHelper.slaNotSpecifiedOperation(commonBO);
		
	}

	@Override
	public void slaSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException {
		onHoldRequestHelper.slaSpecifiedReminderXOperation(commonBO);
		
	}

	@Override
	public void slaNotSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException {
		onHoldRequestHelper.slaNotSpecifiedReminderXOperation(commonBO);
		
	}

}
