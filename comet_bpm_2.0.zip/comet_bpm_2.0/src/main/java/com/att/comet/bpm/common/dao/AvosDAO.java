package com.att.comet.bpm.common.dao;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface AvosDAO {
	void saveAVOSProcessInstancesForCamundaProcessInstanceId(CommonBO commonBO) throws CamundaServiceException;

	void deleteAVOSProcessInstancesByCamundaProcessInstanceId(CommonBO commonBO) throws CamundaServiceException;

	String getActiveBpmProcessInstanceId(CommonBO commonBO);

}
