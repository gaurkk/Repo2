package com.att.comet.bpm.dapn.dapnrelease.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.dapn.dapnrelease.helper.DapnReleaseHelper;

@Component
public class DapnReleaseServiceImpl implements DapnReleaseService {

	@Autowired
	private DapnReleaseHelper dapnReleaseHelper;

	@Autowired
	CommonService commonService;

	@Override
	public void preOperationDapnRelease(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		dapnReleaseHelper.preOperationDapnRelease(commonBO);
	}

	@Override
	public void postOperationDapnRelease(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		dapnReleaseHelper.postOperationDapnRelease(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1008L);// IT OPS Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1051L);// Mapped from BPM_task table (IT OPS : D-APN Release Request)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
