package com.att.comet.bpm.common.dao;

import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface BpmOrderWorkStepDAO {
	void deleteBpmOrderWorkStepForOrderIdAndWorkStepId(CommonBO commonBO) throws CamundaServiceException;

	void updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(CommonBO commonBO) throws CamundaServiceException;

	Date getUpdatedOnFromBpmOrderWorkStep(CommonBO commonBO) throws CamundaServiceException;
}
