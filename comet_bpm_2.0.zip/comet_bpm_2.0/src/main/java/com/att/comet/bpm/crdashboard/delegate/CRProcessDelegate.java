package com.att.comet.bpm.crdashboard.delegate;

import java.util.Optional;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrdersRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.crdashboard.service.CRProcessService;

@Component
public class CRProcessDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(CRProcessDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	CRProcessService crProcessService;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private OrdersRepository ordersRepository;
	public static final String URL_NAME = "SEARCH_ORDER_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.CR_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.CR_POST_OPERATION:
					postOperation(execution);
					break;
				case BpmConstant.CR_POST_ORDER_STATUS:
					dashboardStatus(execution);
					break;
				case BpmConstant.CR_PRE_ORDER_STATUS:
					orderTypeCheck(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			throw new CamundaServiceException("NO INPUT FOUND FOR NEXT FLOW STEPS");
		}

	}

	private void orderTypeCheck(DelegateExecution execution) {
		Long orderId = (Long) execution.getVariable("orderId");
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			execution.setVariable("orderId", orderId);
			execution.setVariable("orderOperation", orderOperation);
		}
	}

	private void dashboardStatus(DelegateExecution execution) {
		CommonBO commonBO = (CommonBO) execution.getVariable("commonBO");
		try {
			if (null != commonBO) {
				crProcessService.taskStatus(commonBO, execution);
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "CR CO dashboardStatus SERVICE EXCEPTION");
		}

	}

	private void preOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperation method ::", this);
		CommonBO commonBO = null;
		Long orderId = (Long) execution.getVariable("orderId");
		String orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			commonBO = commonService.getCommonBO(orderId);
			if (null != commonBO) {
				execution.setVariable("orderId", commonBO.getOrderId());
				execution.setVariable("apnName", commonBO.getApnName());
				execution.setVariable("accountName", commonBO.getAccountName());
				execution.setVariable("cipn", commonBO.getCipn());
				execution.setVariable("backhaulIds", commonBO.getBackHaulIds());
				execution.setVariable("url", bpmUrl.getUrl());
				execution.setVariable("pdpName", commonBO.getPdpName()); // Need to check PdpIdInfoRepository
				execution.setVariable("processType", commonBO.getOrderTypeName());
				execution.setVariable("expediteOrder", commonBO.isExpediteOrder());

				commonBO.setRoleId(1005L);// Setting OA roleID
				commonBO.setTaskStatusId(1001L);// OA Task Id//Creation

				commonBO.setCategoryId(1002L);// category ID (user task)
				commonBO.setUrlName(bpmUrl.getNew_url() + commonBO.getOrderId());
				if (orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_REQUEST)) {
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setTaskId(1029L);// Mapped from BPM_task table (CR Dashboard Task)
					commonBO.setTaskStatusName("DashBoardTask");
				} else if (orderOperation.equalsIgnoreCase(BpmConstant.CHANGE_ORDER)) {
					commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
					commonBO.setTaskId(1032L);// Mapped from BPM_task table (CO Dash Board Task)
					commonBO.setTaskStatusName("CCSPM_Change_Order_Task");
				}
				commonBO.setOrderOperation(orderOperation);// Order Type coming from Frontend //2:OPERATION TYPE
															// ("NEW_ORDER" | "CHANGE_ORDER" | "CHANGE_REQUEST" |
															// "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER"
															// | "ONHOLD_ORDER" | "DAPN_ORDER" )
				crProcessService.preOperation(commonBO, execution.getProcessInstanceId());
				execution.setVariable("taskStatus", commonBO.getBusinessStepStatus());
				execution.setVariable("commonBO", commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				throw new BpmnError("ERROR_BPM_001", "CR CO PREOPERATION SERVICE EXCEPTION");
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
					this);
			throw new BpmnError("ERROR_BPM_001", "CR CO PREOPERATION SERVICE EXCEPTION");

		}

	}

	private void postOperation(DelegateExecution execution) {
		logger.info("Start postOperation method ::", this);
		CommonBO commonBO = (CommonBO) execution.getVariable("commonBO");
		String CCSPMComments = (String) execution.getVariable("comments");

		if (null != commonBO) {
			try {
				commonBO.setComments(CCSPMComments);
				crProcessService.postOperation(commonBO, execution);
				commonServiceHelper.crPendingTasks(commonBO, execution);
				Optional<Orders> orders = ordersRepository.findById(commonBO.getOrderId());
				if(orders.isPresent() && null !=orders.get().getExpedite() 
						&& orders.get().getExpedite()=='Y') {
					commonServiceHelper.pickOperation(commonBO, execution);

					logger.info("pick operation performed successfully for the order : " + commonBO.getOrderId());

					commonBO.setApnCreationStatus("post");
					bpmDAO.updateBpmOrderExpedite(commonBO);
				}
				
				execution.setVariable("commonBO", commonBO);
			} catch (CamundaServiceException e) {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"),
						this);
				throw new BpmnError("ERROR_BPM_001", "CR CO POSTOPERATION SERVICE EXCEPTION");
			}

		}
		logger.info("Existing postOperation method ::", this);

	}

}
