package com.att.comet.bpm.codashboard.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface NiRollbackTaskService {
	
	void niRollbackTaskPostOperation(CommonBO commonBO) throws CamundaServiceException;
	void niRollbackTaskPreOperation(CommonBO commonBO, String processInstanceId) throws CamundaServiceException;
}
