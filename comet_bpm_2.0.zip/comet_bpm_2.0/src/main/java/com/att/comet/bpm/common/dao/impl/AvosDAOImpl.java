package com.att.comet.bpm.common.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.oa.helper.OAApprovalHelper;


@Component
public class AvosDAOImpl implements AvosDAO {
	private static final Logger logger = LoggerFactory.getLogger(AvosDAOImpl.class);
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public void saveAVOSProcessInstancesForCamundaProcessInstanceId(CommonBO commonBO)throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)+ "] " ,this);
		String sql = "insert into AVOS_Process_Instances(ORDER_ID,BPM_PROCESS_ID,ORDER_PROCESS,CAMUNDA_PROCESS_INSTANCE_ID) values(?,?,?,?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getBpmProcessId());
		query.setParameter(3, commonBO.getOrderOperation());
		query.setParameter(4, commonBO.getBpmProcessInstanceId());
		query.executeUpdate();
	}

	@Override
	public void deleteAVOSProcessInstancesByCamundaProcessInstanceId(CommonBO commonBO)throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO)+ "] " ,this);
		String sql = "delete from  AVOS_Process_Instances where CAMUNDA_PROCESS_INSTANCE_ID=?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getBpmProcessInstanceId());
		query.executeUpdate();
		
	}
	@Override
	public String getActiveBpmProcessInstanceId(CommonBO commonBO) {
		String processInstanceId = null;
		String sql = "select camunda_process_instance_id from AVOS_Process_Instances where order_id =? and bpm_process_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getBpmProcessId());
		processInstanceId = (String) query.getSingleResult();
		return processInstanceId;
	}
	

}
