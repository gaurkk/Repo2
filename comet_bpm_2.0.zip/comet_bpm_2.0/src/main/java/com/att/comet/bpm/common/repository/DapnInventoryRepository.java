package com.att.comet.bpm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.bpm.common.hibernate.bean.DapnInventory;

@Repository
public interface DapnInventoryRepository extends JpaRepository<DapnInventory, String>{

}
