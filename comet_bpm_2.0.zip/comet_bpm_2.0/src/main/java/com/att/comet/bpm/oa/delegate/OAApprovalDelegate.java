package com.att.comet.bpm.oa.delegate;


import java.util.Date;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.constant.BpmErrorCodeConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaBpmnError;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.exception.RecordNotFoundException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.modal.OrderUserTaskFaultsBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.oa.service.OAApprovalService;


@Component
public class OAApprovalDelegate implements JavaDelegate {
	private static final Logger logger = LoggerFactory.getLogger(OAApprovalDelegate.class);

	@Autowired
	private OAApprovalService oaApprovalService;
	@Autowired
	private CommonService commonService;
	
	public static final String URL_NAME = "OSD_ORDER_UPDATE_URL";

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.OA_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.APPROVED_BY_OA:
					approvedByOA(execution);
					break;
				case BpmConstant.REJECTED_BY_OA:
					rejectedByOA(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OA_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}

	}

	/**
	 * OA APPROVAL PREOPERATION
	 * @param execution
	 * @throws CamundaServiceException
	 * @throws RecordNotFoundException
	 */
	private void preOperation(DelegateExecution execution) throws CamundaServiceException, RecordNotFoundException {

		logger.info("Start preOperation method ::", this);
		Long orderId = null;
		String orderOperation = null;
		CommonBO commonBO = null;
		orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
		orderOperation = (String)execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			commonBO = commonService.getCommonBO(orderId);
			
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			if (null != commonBO ) {
				// OrderUserTaskFaults
				OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
				orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_ERR_PRE_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
				orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
				orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
				orderUserTaskFaultsBO.setRoleId(1002L);// Setting OSD roleID
				orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
				orderUserTaskFaultsBO.setTaskId(1010L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
				orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
				orderUserTaskFaultsBO.setCreationOn(new Date());
				execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
				
				execution.setVariable(BpmConstant.ORDER_ID,commonBO.getOrderId());
				execution.setVariable(BpmConstant.APN_NAME, commonBO.getApnName());
				execution.setVariable(BpmConstant.ACCOUNT_NAME, commonBO.getAccountName());
				execution.setVariable(BpmConstant.CIPN, commonBO.getCipn());
				execution.setVariable(BpmConstant.BACKHAUL_IDS, commonBO.getBackHaulIds());
				execution.setVariable(BpmConstant.URL, bpmUrl.getNew_url()+commonBO.getOrderId());
				execution.setVariable(BpmConstant.PDP_NAME, commonBO.getPdpName()); //Need to check PdpIdInfoRepository
				execution.setVariable(BpmConstant.ORDER_TYPE, orderOperation);
				execution.setVariable(BpmConstant.EXPEDITE, commonBO.isExpediteOrder());
				execution.setVariable(BpmConstant.CATEGORY, "1002");//User task 

				commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setRoleId(1002L);//Setting OA roleID
				commonBO.setTaskStatusId(1001L);//OA Task Id//Creation
				commonBO.setTaskStatusName("Order_Approver_Task");
				commonBO.setCategoryId(1002L);//category ID (user task)
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setTaskId(1010L);//Mapped from BPM_task table (OA : Approval Task)
				commonBO.setOrderOperation(orderOperation);//Order Type coming from Frontend //2:OPERATION TYPE ("NEW_ORDER"  | "CHANGE_ORDER" | "CHANGE_REQUEST" | "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER" | "ONHOLD_ORDER" | "DAPN_ORDER" )
				//ALL CRUD PREOPERATION for OA Approval
				commonBO.setUpdatedOn(new Date());
				oaApprovalService.preOperation(commonBO,execution.getProcessInstanceId());
				execution.setVariable(BpmConstant.COMMON_BO, commonBO);
				execution.setVariable(BpmConstant.EMAIL_REMINDER_1, commonBO.getReminder1SlaDate());
				execution.setVariable(BpmConstant.EMAIL_REMINDER_2, commonBO.getReminder2SlaDate());
			} else {
				logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
				
			}
		} else {
			logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"), this);
			
			
		}
		logger.info("End preOperation method ::", this);

	}

	/**
	 * OA APPROVAL POST OPERATION FOR APPROVAL
	 * @param execution
	 * @throws Exception
	 */
	private void approvedByOA(DelegateExecution execution) throws Exception {
		logger.info("Start approvedByOA method ::", this);
		Long orderId = 0L;
		String orderOperation = null;
		CommonBO commonBO = null;
		try {
		//value fetch from COMET FRONTEND by Assign USER
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			orderOperation = (String) execution.getVariable(BpmConstant.ORDER_OPERATION);
			if (null != orderId || null != orderOperation) {
				commonBO = (CommonBO)execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					// OrderUserTaskFaults
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_ERR_APPROVED_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1002L);// Setting OSD roleID
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1010L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
					oaApprovalService.approvedByOA(commonBO,execution);
					//setting for email subject
					commonBO.setTaskDescription("Request for Approval of Order ID -"+commonBO.getOrderId()+" with APN -"+commonBO.getApnName()+"  "
							+ "for Account - "+commonBO.getAccountName() + "- Approved by Order Approver");
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.RESPONSE, commonBO.getApproved());
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OA_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End approvedByOA method ::", this);

	}

	/**
	 * OA APPROVAL POST OPERATION FOR REJECTED
	 * @param execution
	 * @throws Exception
	 */
	private void rejectedByOA(DelegateExecution execution) throws Exception {

		logger.info("Start rejectedByOA method ::", this);
		Long orderId = 0L;
		String processType = null;
		CommonBO commonBO = null;
		try {
			//value fetch from COMET FRONTEND by Assign USER
			orderId = (Long) execution.getVariable(BpmConstant.ORDER_ID);
			if (null != orderId) {
				commonBO = (CommonBO)execution.getVariable(BpmConstant.COMMON_BO);
				if (null != commonBO) {
					// OrderUserTaskFaults
					OrderUserTaskFaultsBO orderUserTaskFaultsBO = new OrderUserTaskFaultsBO();
					orderUserTaskFaultsBO.setErrorCode(BpmErrorCodeConstant.OA_ERR_REJECTED_001);// APN_IWOS_OSD_ORDER_UPDATE_ERR_PRE_001
					orderUserTaskFaultsBO.setBpmTaskId(Long.valueOf(execution.getId()));
					orderUserTaskFaultsBO.setCategoryId(1003L);// category ID (Service task)
					orderUserTaskFaultsBO.setRoleId(1002L);// Setting OSD roleID
					orderUserTaskFaultsBO.setTaskStatusId(1004L);// FAULTED
					orderUserTaskFaultsBO.setTaskId(1010L);// Mapped from BPM_task table (OSD : TTU - Preflight Testing)
					orderUserTaskFaultsBO.setOrderId(orderId);// OrderId
					orderUserTaskFaultsBO.setCreationOn(new Date());
					execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);

					oaApprovalService.rejectedByOA(commonBO ,execution);
					execution.setVariable(BpmConstant.REJECTED_BY, 1002L);
					// setting for email subject
					commonBO.setTaskDescription("Order Approver has rejected the Request for: Order ID -"
							+ commonBO.getOrderId() + " with APN -" + commonBO.getApnName() + "  for Account - "
							+ commonBO.getAccountName());
					execution.setVariable(BpmConstant.COMMON_BO, commonBO);
					execution.setVariable(BpmConstant.RESPONSE, commonBO.getApproved());
				} 
			} else {
				logger.error("Comet request does not have::" + "data", this);
				
			}
		} catch (CamundaServiceException e) {
			OrderUserTaskFaultsBO orderUserTaskFaultsBO = (OrderUserTaskFaultsBO) execution
					.getVariable(BpmConstant.ORDER_USER_TASK_FALULTS);
			orderUserTaskFaultsBO.setErrorDesc(e.getMessage());
			execution.setVariable(BpmConstant.ORDER_USER_TASK_FALULTS, orderUserTaskFaultsBO);
			throw new CamundaBpmnError(BpmConstant.OA_APPROVAL_BPM_ERROR_CODE,
					orderUserTaskFaultsBO.getErrorCode());
		}
		logger.info("End rejectedByOA method ::", this);
	}

}
