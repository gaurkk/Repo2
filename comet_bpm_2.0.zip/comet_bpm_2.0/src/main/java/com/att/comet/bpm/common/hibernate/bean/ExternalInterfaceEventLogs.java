package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_INT_EVENT_LOGS")
public class ExternalInterfaceEventLogs implements Serializable {

	private static final long serialVersionUID = 3301006291842128180L;

	private Long id;
	private ExternalInterfaceDetails extInterfaceDetails;
	private Clob requestJson;
	private Clob responseJson;
	private String responseCode;
	private EventType eventType;
	private Character sucess;
	private Date updatedOn;
	private String updatedBy;

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the extInterfaceDetails
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EXT_INTERFACE_ID", nullable = false)
	public ExternalInterfaceDetails getExtInterfaceDetails() {
		return extInterfaceDetails;
	}

	/**
	 * @param extInterfaceDetails the extInterfaceDetails to set
	 */
	public void setExtInterfaceDetails(ExternalInterfaceDetails extInterfaceDetails) {
		this.extInterfaceDetails = extInterfaceDetails;
	}

	/**
	 * @return the requestJson
	 */
	@Column(name = "REQUEST_JSON")
	public Clob getRequestJson() {
		return requestJson;
	}

	/**
	 * @param requestJson the requestJson to set
	 */
	public void setRequestJson(Clob requestJson) {
		this.requestJson = requestJson;
	}

	/**
	 * @return the responseJson
	 */
	@Column(name = "RESPONSE_JSON")
	public Clob getResponseJson() {
		return responseJson;
	}

	/**
	 * @param responseJson the responseJson to set
	 */
	public void setResponseJson(Clob responseJson) {
		this.responseJson = responseJson;
	}

	/**
	 * @return the responseCode
	 */
	@Column(name = "RESPONSE_CODE", length = 100)
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the eventType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EVENT_TYPE_ID", nullable = false)
	public EventType getEventType() {
		return eventType;
	}

	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	/**
	 * @return the success
	 */
	@Column(name = "SUCCESS", length = 1)
	public Character getSucess() {
		return sucess;
	}

	/**
	 * @param sucess the success to set
	 */
	public void setSucess(Character sucess) {
		this.sucess = sucess;
	}

	/**
	 * @return the updatedOn
	 */
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the updatedBy
	 */
	@Column(name = "UPDATED_BY", length = 100)
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
