package com.att.comet.bpm.dapn.oadapnbuildcancellation.service;

import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.helper.CommonServiceHelper;
import com.att.comet.bpm.common.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.OrderUserBpmTasksRepository;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.dapn.oadapnbuildcancellation.helper.OADAPNBuildCancellationHelper;

@Component
public class OADAPNBuildCancellationServiceImpl implements OADAPNBuildCancellationService {
	private static final Logger logger = LoggerFactory.getLogger(OADAPNBuildCancellationServiceImpl.class);
	@Autowired
	private OADAPNBuildCancellationHelper oadapnBuildCancellationHelper;
	@Autowired
	CommonServiceHelper commonServiceHelper;
	@Autowired
	CommonService commonService;

	@Override
	public void preOperationOADAPNBuildCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		oadapnBuildCancellationHelper.preOperationOADAPNBuildCancellation(commonBO);
	}

	@Override
	public void postOperationOADAPNBuildCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		oadapnBuildCancellationHelper.postOperationOADAPNBuildCancellation(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1002L);// Order Approver Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1052L);// Mapped from BPM_task table (OA : D-APN Build Cancellation Review)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
		commonServiceHelper.crPendingTasks(commonBO, execution);
	}

}
