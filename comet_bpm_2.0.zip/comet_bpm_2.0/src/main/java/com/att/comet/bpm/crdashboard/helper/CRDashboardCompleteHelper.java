package com.att.comet.bpm.crdashboard.helper;

import java.util.ArrayList;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.bpm.common.dao.AvosDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.dao.UserDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;
@Component
public class CRDashboardCompleteHelper {
	private static final Logger logger = LoggerFactory.getLogger(CRDashboardCompleteHelper.class);
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private BpmDAO bpmDAO;
	@Autowired
	private AvosDAO camundaDAO;
	@Autowired
	private UserDAO userDAO;

	public void crPreOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crPreOprCRUD");

		List<String> osdEmailList = null;
		// saving camunda process instance ID
		commonBO.setProcessId(1023L);
		commonBO.setBpmProcessId(1023L);//CHANGE REQUEST COMPELET DASHBOARD PROCESS
		commonBO.setBpmProcessInstanceId(processInstanceId);
		// commonBO.setWorkFlowUrl(bpmUrl.getUrl());
		camundaDAO.saveAVOSProcessInstancesForCamundaProcessInstanceId(commonBO);
		// deleting process ID from bpm_order_process
		bpmDAO.deleteBpmOrderProcess(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmStatusId(1001L);
		commonBO.setOrderTypeId(1005L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		// delete bpm_order_business_step table
		List<Long> businessStepIdList = new ArrayList<Long>();
		businessStepIdList.add(3138L);
		businessStepIdList.add(3189L);
		businessStepIdList.add(3190L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);
		// fetching dynamic user from order_contact_info table
		commonBO.setOrderContactTypeId(1006L);
		List<String> attUidList = orderDAO.getOrderContactInfoATTUId(commonBO);
		if (!CollectionUtils.isEmpty(attUidList)) {
			logger.debug("osdEmailList is not empty : ", +attUidList.size());
			String ccsPM = attUidList.get(0);
			commonBO.setAttuid(ccsPM);
			commonBO.setAssignee(ccsPM);
			osdEmailList = userDAO.getUserEmail(commonBO);
			commonBO.setEmailList(osdEmailList);
		} else {
			logger.debug("attUidList is empty: ", +attUidList.size());
			commonBO.setRoleId(1005L);
			osdEmailList = userDAO.getGroupUserEmail(commonBO);
			commonBO.setGroupEmailList(osdEmailList);
		}
		// Fetching COMET Admin email
		commonBO.setRoleId(1006L);
		List<String> adminEmailList = userDAO.getGroupUserEmail(commonBO);
		commonBO.setAdminEmailList(adminEmailList);
		if (CommonUtils.isNotNullEmpty(commonBO.getAttuid())) {// if no Assignee , email will sent to grp
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getEmailList()));// All grp
			// commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList())
			// + CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));//All
			// grp
		} else {
			commonBO.setToEmail(CommonUtils.replaceListToStringByComma(commonBO.getGroupEmailList()));// All grp
			commonBO.setCcEmail(CommonUtils.replaceListToStringByComma(commonBO.getAdminEmailList()));// All grp
		}
		// update bpm_order_work_step
		commonBO.setWorkStepId(1070L);
		commonBO.setBpmStatusId(1001L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		commonBO.setRoleId(1005L);
		logger.info("[::Ending Method crPreOprCRUD");
		
	}

	public void crPostOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		logger.info("[commonBO : " + (commonBO == null ? "" : commonBO) + "]::Starting Method crPostOprCRUD");
		commonBO.setBusinessStepId(3138L);
		commonBO.setUpdatedBy(commonBO.getAttuid());
		commonBO.setBusinessStepValue("Completed");
		commonBO.setComments(commonBO.getComments());
		// commonBO.setUpdatedOn(PreFlightTestingDateTime);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		// update bpm_order_work_step
		commonBO.setWorkStepId(1070L);
		commonBO.setBpmStatusId(1002L);
		bpmDAO.updateBpmOrderWorkStep(commonBO);
		// inserting data into bpm_order_process
		commonBO.setBpmStatusId(1002L);
		commonBO.setOrderTypeId(1005L);
		bpmDAO.saveBpmOrderProcess(commonBO);
		
	}

}
