package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for InternetVpn. Mapped to INTERNET_VPN table in the
 * database.
 */
@Entity
@Table(name = "INTERNET_VPN")
public class InternetVpn implements Serializable {

	private static final long serialVersionUID = 4387981632604647240L;

	private Long backhaulId;
	
	private String tunnelType;
	private String internetVpnEndpoint;
	private Backhaul backhaul;	
	private String pfs;
	private String vpnGwType;
	private String concentratorPublicIp;
	private String preSharedSecret;
	private String saLifetime;
	private String routProtocol;
	private String tunnelInsideNatIp;
	private Character vti = 'N';
	private String uniqueLoopBackIp;
	private String attTunnelEndpointIp;
	private String custTunnelEndpointIp;
	private Long interfaceTunnelNumber;
	private String cryptoVlanId;
	
	private String ikeVersion;
	private String ike;
	private String ipsecEsp;
	private String npuInterface;
	private String msinoutinterface;
	private String msnum01_99;
	/**
	 * Getter method for backhaulId. BACKHAUL_ID mapped to BACKHAUL_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "backhaul"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "BACKHAUL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	/**
	 * Getter method for tunnelType. TUNNEL_TYPE mapped to TUNNEL_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "TUNNEL_TYPE", length = 100)
	public String getTunnelType() {
		return this.tunnelType;
	}

	/**
	 * @param tunnelType
	 *            to tunnelType set.
	 */
	public void setTunnelType(String tunnelType) {
		this.tunnelType = tunnelType;
	}

	/**
	 * Getter method for internetVpnEndpoint. INTERNET_VPN_ENDPOINT mapped to
	 * INTERNET_VPN_ENDPOINT in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INTERNET_VPN_ENDPOINT")
	public String getInternetVpnEndpoint() {
		return this.internetVpnEndpoint;
	}

	/**
	 * @param internetVpnEndpoint
	 *            to internetVpnEndpoint set.
	 */
	public void setInternetVpnEndpoint(String internetVpnEndpoint) {
		this.internetVpnEndpoint = internetVpnEndpoint;
	}

	/**
	 * Getter method for backhaul.
	 * 
	 * @return Backhaul
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Backhaul getBackhaul() {
		return this.backhaul;
	}

	/**
	 * @param backhaul
	 *            to backhaul set.
	 */
	public void setBackhaul(Backhaul backhaul) {
		this.backhaul = backhaul;
	}

	/**
	 * Getter method for pfs. PFS mapped to PFS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PFS", length = 100)
	public String getPfs() {
		return this.pfs;
	}

	/**
	 * @param pfs
	 *            to pfs set.
	 */
	public void setPfs(String pfs) {
		this.pfs = pfs;
	}

	/**
	 * Getter method for vpnGwType. VPN_GW_TYPE mapped to VPN_GW_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_GW_TYPE", length = 100)
	public String getVpnGwType() {
		return this.vpnGwType;
	}

	/**
	 * @param vpnGwType
	 *            to vpnGwType set.
	 */
	public void setVpnGwType(String vpnGwType) {
		this.vpnGwType = vpnGwType;
	}

	/**
	 * Getter method for concentratorPublicIp. CONCENTRATOR_PUBLIC_IP mapped to
	 * CONCENTRATOR_PUBLIC_IP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CONCENTRATOR_PUBLIC_IP", length = 100)
	public String getConcentratorPublicIp() {
		return this.concentratorPublicIp;
	}

	/**
	 * @param concentratorPublicIp
	 *            to concentratorPublicIp set.
	 */
	public void setConcentratorPublicIp(String concentratorPublicIp) {
		this.concentratorPublicIp = concentratorPublicIp;
	}

	/**
	 * Getter method for preSharedSecret. PRE_SHARED_SECRET mapped to
	 * PRE_SHARED_SECRET in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PRE_SHARED_SECRET", length = 100)
	public String getPreSharedSecret() {
		return this.preSharedSecret;
	}

	/**
	 * @param preSharedSecret
	 *            to preSharedSecret set.
	 */
	public void setPreSharedSecret(String preSharedSecret) {
		this.preSharedSecret = preSharedSecret;
	}

	/**
	 * Getter method for saLifetime. SA_LIFETIME mapped to SA_LIFETIME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "SA_LIFETIME", length = 100)
	public String getSaLifetime() {
		return this.saLifetime;
	}

	/**
	 * @param saLifetime
	 *            to saLifetime set.
	 */
	public void setSaLifetime(String saLifetime) {
		this.saLifetime = saLifetime;
	}

	/**
	 * Getter method for routProtocol. ROUTING_PROTOCOL mapped to
	 * ROUTING_PROTOCOL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ROUTING_PROTOCOL", length = 10)
	public String getRoutProtocol() {
		return routProtocol;
	}

	/**
	 * @param routProtocol
	 *            to routProtocol set
	 */
	public void setRoutProtocol(String routProtocol) {
		this.routProtocol = routProtocol;
	}

	/**
	 * @return the tunnelInsideNatIp
	 */
	@Column(name = "TUNNEL_INSIDE_NAT_IP", length = 100)
	public String getTunnelInsideNatIp() {
		return tunnelInsideNatIp;
	}

	/**
	 * @param tunnelInsideNatIp the tunnelInsideNatIp to set
	 */
	public void setTunnelInsideNatIp(String tunnelInsideNatIp) {
		this.tunnelInsideNatIp = tunnelInsideNatIp;
	}

	@Column(name = "vti", length = 1)
	public Character getVti() {
		return vti;
	}

	/**
	 * to set vti checkbox value
	 * @param vti
	 */
	public void setVti(Character vti) {
		this.vti = vti;
	}

	/**
	 * @return the uniqueLoopBackIP
	 */
	@Column(name = "UNIQUE_LOOPBACK_IP", length = 100)
	public String getUniqueLoopBackIp() {
		return uniqueLoopBackIp;
	}

	/**
	 * @param uniqueLoopBackIp the uniqueLoopBackIp to set
	 */
	public void setUniqueLoopBackIp(String uniqueLoopBackIp) {
		this.uniqueLoopBackIp = uniqueLoopBackIp;
	}

	/**
	 * @return the attTunnelEndpointIp
	 */
	@Column(name = "ATT_TUNNEL_ENDPOINT_IP", length = 100)
	public String getAttTunnelEndpointIp() {
		return attTunnelEndpointIp;
	}

	/**
	 * @param attTunnelEndpointIp the attTunnelEndpointIp to set
	 */
	public void setAttTunnelEndpointIp(String attTunnelEndpointIp) {
		this.attTunnelEndpointIp = attTunnelEndpointIp;
	}

	/**
	 * @return the custTunnelEndpointIp
	 */
	@Column(name = "CUST_TUNNEL_ENDPOINT_IP", length = 100)
	public String getCustTunnelEndpointIp() {
		return custTunnelEndpointIp;
	}

	/**
	 * @param custTunnelEndpointIp the custTunnelEndpointIp to set
	 */
	public void setCustTunnelEndpointIp(String custTunnelEndpointIp) {
		this.custTunnelEndpointIp = custTunnelEndpointIp;
	}
	
	/**
	 * @return the InterfaceTunnelNumber
	 */
		@Column(name = "INTERFACE_TUNNEL_NUM" , precision = 12, scale = 0)
	public Long getInterfaceTunnelNumber() {
		return interfaceTunnelNumber;
	}

	/**
	 * @param InterfaceTunnelNumber the InterfaceTunnelNumber to set
	 */
	public void setInterfaceTunnelNumber(Long interfaceTunnelNumber) {
		this.interfaceTunnelNumber = interfaceTunnelNumber;
	}
	
	/**
	 * @return the CryptoVlanId
	 */
	@Column(name = "CRYPTO_VLAN_ID")
	public String getCryptoVlanId() {
		return cryptoVlanId;
	}

	/**
	 * @param cryptoVlanId the cryptoVlanId to set
	 */
	public void setCryptoVlanId(String cryptoVlanId) {
		this.cryptoVlanId = cryptoVlanId;
	}

	/**
	 * @return the ikeVersion
	 */
	@Column(name = "IKE_VERSION")
	public String getIkeVersion() {
		return ikeVersion;
	}

	/**
	 * @param ikeVersion the ikeVersion to set
	 */
	public void setIkeVersion(String ikeVersion) {
		this.ikeVersion = ikeVersion;
	}

	/**
	 * @return the ike
	 */
	@Column(name = "IKE")
	public String getIke() {
		return ike;
	}

	/**
	 * @param ike the ike to set
	 */
	public void setIke(String ike) {
		this.ike = ike;
	}

	/**
	 * @return the ipsecEsp
	 */
	@Column(name = "IPSECESP")
	public String getIpsecEsp() {
		return ipsecEsp;
	}

	/**
	 * @param ipsecEsp the ipsecEsp to set
	 */
	public void setIpsecEsp(String ipsecEsp) {
		this.ipsecEsp = ipsecEsp;
	}

	/**
	 * @return the npuInterface
	 */
	@Column(name = "NPU_INTERFACE")
	public String getNpuInterface() {
		return npuInterface;
	}

	/**
	 * @param npuInterface the npuInterface to set
	 */
	public void setNpuInterface(String npuInterface) {
		this.npuInterface = npuInterface;
	}

	/**
	 * @return the msinoutinterface
	 */
	@Column(name = "MS_INOUT_INTERFACE")
	public String getMsinoutinterface() {
		return msinoutinterface;
	}

	/**
	 * @param msinoutinterface the msinoutinterface to set
	 */
	public void setMsinoutinterface(String msinoutinterface) {
		this.msinoutinterface = msinoutinterface;
	}

	/**
	 * @return the msnum01_99
	 */
	@Column(name = "MSNUM01_99")
	public String getMsnum01_99() {
		return msnum01_99;
	}

	/**
	 * @param msnum01_99 the msnum01_99 to set
	 */
	public void setMsnum01_99(String msnum01_99) {
		this.msnum01_99 = msnum01_99;
	}
}