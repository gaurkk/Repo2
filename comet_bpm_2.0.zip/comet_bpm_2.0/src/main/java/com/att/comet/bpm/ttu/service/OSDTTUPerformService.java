package com.att.comet.bpm.ttu.service;

import java.util.Date;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OSDTTUPerformService {
	void preOperationOSDTTUPerform(CommonBO commonBO) throws CamundaServiceException;
	void postOperationOSDTTUPerform(CommonBO commonBO, String OSDComments, String ttuPerformedOrRescheduled) throws CamundaServiceException;
}
