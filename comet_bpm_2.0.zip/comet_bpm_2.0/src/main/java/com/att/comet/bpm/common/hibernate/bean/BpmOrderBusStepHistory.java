package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderBusStepHistory. Mapped to
 * BPM_ORDER_BUS_STEP_HISTORY in the database table.
 */
@Entity
@Table(name = "BPM_ORDER_BUS_STEP_HISTORY")
public class BpmOrderBusStepHistory implements java.io.Serializable {

	private static final long serialVersionUID = 7903101352212823771L;

	private BpmOrderBusStepHistoryId id;

	/**
	 * No-argument constructor of the class.
	 */
	public BpmOrderBusStepHistory() {
	}

	/**
	 * SIngle argument constructor of the class.
	 * 
	 * @param id
	 */
	public BpmOrderBusStepHistory(BpmOrderBusStepHistoryId id) {
		this.id = id;
	}

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderBusStepHistoryId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "businessStepId", column = @Column(name = "BUSINESS_STEP_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", precision = 12, scale = 0)),
			@AttributeOverride(name = "businessStepStatus", column = @Column(name = "BUSINESS_STEP_STATUS", nullable = false, length = 100)),
			@AttributeOverride(name = "businessStepValue", column = @Column(name = "BUSINESS_STEP_VALUE", length = 500)),
			@AttributeOverride(name = "businessStepExecutedOn", column = @Column(name = "BUSINESS_STEP_EXECUTED_ON")),
			@AttributeOverride(name = "comments", column = @Column(name = "COMMENTS", length = 3500)),
			@AttributeOverride(name = "createdOn", column = @Column(name = "CREATED_ON", nullable = false)),
			@AttributeOverride(name = "updatedOn", column = @Column(name = "UPDATED_ON", nullable = false)) })
	public BpmOrderBusStepHistoryId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderBusStepHistoryId id) {
		this.id = id;
	}

}
