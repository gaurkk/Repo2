package com.att.comet.bpm.common.dao;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OrderStatusHistoryDAO {

	void saveOshByOrderIdAndOsIdUpdatedBy(CommonBO commonBO) throws CamundaServiceException;

}
