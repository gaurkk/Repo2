package com.att.comet.bpm.dapn.itopsdapncancellation.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.dapn.itopsdapncancellation.helper.ITOPSDAPNCancellationHelper;

@Component
public class ITOPSDAPNCancellationServiceImpl implements ITOPSDAPNCancellationService {

	@Autowired
	private ITOPSDAPNCancellationHelper itopsdapnCancellationHelper;

	@Autowired
	CommonService commonService;

	@Override
	public void preOperationITOPSDAPNCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {
		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		itopsdapnCancellationHelper.preOperationITOPSDAPNCancellation(commonBO);
	}

	@Override
	public void postOperationITOPSDAPNCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException {

		commonBO.setBpmProcessInstanceId(execution.getProcessInstanceId());
		itopsdapnCancellationHelper.postOperationITOPSDAPNCancellation(commonBO);

		// Update OrderUserBpmTasks
		commonBO.setTaskStatusId(1002L);// Task Status COMPLETED Id
		commonBO.setRoleId(1008L);// IT OPS Role Id
		commonBO.setTaskCompletionTime(new Date());// User Task Completion Time
		commonBO.setCategoryId(1003L);// Category Id(SERVICE)
		commonBO.setTaskId(1053L);// Mapped from BPM_task table (IT OPS : D-APN Build Cancellation Request)
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}

}
