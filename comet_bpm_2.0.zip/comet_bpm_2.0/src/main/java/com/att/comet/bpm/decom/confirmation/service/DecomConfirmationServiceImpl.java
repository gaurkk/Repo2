package com.att.comet.bpm.decom.confirmation.service;

import java.util.Date;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.decom.confirmation.helper.DecomConfirmationHelper;

@Service
public class DecomConfirmationServiceImpl implements DecomConfirmationService{
	
	@Autowired
	DecomConfirmationHelper decomConfirmationHelper;
	
	@Autowired
	CommonService commonService;

	@Override
	public void preOperation(CommonBO commonBO) throws CamundaServiceException {
		decomConfirmationHelper.preOprCRUD(commonBO);
	}

	@Override
	public void postOperation(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {
		decomConfirmationHelper.postOprCRUD(commonBO,execution);
		commonBO.setTaskCompletionTime(new Date());
		commonBO.setCategoryId(1003L);//Service
		commonBO.setTaskStatusId(1002L);//Completed 
		commonService.updateOrderUserBpmTasksRepository(commonBO);
	}
	
}
