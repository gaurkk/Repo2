package com.att.comet.bpm.common.dao;

import java.util.List;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;


public interface BpmDAO {
	void saveBpmOrderProcess(CommonBO commonBO);

	void deleteBpmOrderProcess(CommonBO commonBO) throws CamundaServiceException;

	void updateBpmOrderProcess(CommonBO commonBO);

	void saveBpmOrderWorkStep(CommonBO commonBO) throws CamundaServiceException;

	void deleteBpmOrderWorkStep(CommonBO commonBO);

	void updateBpmOrderWorkStep(CommonBO commonBO);

	void saveBpmOrderBusinessStep(CommonBO commonBO) throws CamundaServiceException;

	void deleteBpmOrderBusinessStep(CommonBO commonBO) throws CamundaServiceException;

	List<String> getBpmOrderBusinessStepComments(CommonBO commonBO);

	void saveBpmOrderBusStepHistory(CommonBO commonBO);

	List<Object[]> findWorkStepIdAndUserDecision(CommonBO commonBO);

	BpmOrderBusinessStep findBpmOrderBusinessStepById(CommonBO commonBO);

	void updateBpmOrderExpedite(CommonBO commonBO);

	void updateBpmOrderBusinessStep(CommonBO commonBO);

	void updateBpmOrderWorkStepDisplayFlag(CommonBO commonBO);

	BpmOrderWorkStep getBpmOrderWorkStep(CommonBO commonBO);

	BpmUrl finBpmUrlById(String urlName);

	List<String> findExpediteProcessStatus(Long orderId);

	List<Object[]> getBpmOrderProcess(Long orderId);

	void deleteBpmOrderProcessByOrderIdAndProcessId(CommonBO commonBO) throws CamundaServiceException;

	void saveBpmOrderProcessForOrderIdAndOrderTypeId(CommonBO commonBO) throws CamundaServiceException;

	void deleteBpmOrderProcessbyOrderProcessName(CommonBO commonBO) throws CamundaServiceException;

	String findBusinessStepValue(CommonBO commonBO);
	
	String findUserDecision(CommonBO commonBO);

	void updateBpmOrderProcessForOrderIdAndOrderTypeId(CommonBO commonBO);

	String getExpediteStatus(CommonBO commonBO);

	String findBpmStatusName(CommonBO commonBO);

	List<Object[]> getProcessUserDecision(CommonBO commonBO);
	
	String getBpmOrderBusinessStepStatus(CommonBO commonBO);

	List<Object[]> getExpBuildDateAndReason(Long orderId);

	void updateDapnInventory(CommonBO commonBO);
	
	
}
