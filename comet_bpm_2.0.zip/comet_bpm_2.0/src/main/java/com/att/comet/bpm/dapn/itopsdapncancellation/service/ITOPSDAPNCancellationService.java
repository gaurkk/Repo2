package com.att.comet.bpm.dapn.itopsdapncancellation.service;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ITOPSDAPNCancellationService {
	public void preOperationITOPSDAPNCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException;

	public void postOperationITOPSDAPNCancellation(CommonBO commonBO, DelegateExecution execution)
			throws CamundaServiceException;
}
