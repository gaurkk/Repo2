package com.att.comet.bpm.common.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class OrderFlagsDetailsPK implements Serializable{

	private static final long serialVersionUID = 1045269773508787169L;
	
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long orderId;
	
	@Column(name = "FLAG_ID", unique = true, nullable = false)
	private Long flagId;
	
	public OrderFlagsDetailsPK(){
		
	}
	public OrderFlagsDetailsPK(Long orderId,Long flag_id) {
		super();
		this.orderId=orderId;
		this.flagId=flag_id;
	}

	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getFlagId() {
		return flagId;
	}

	public void setFlagId(Long flagId) {
		this.flagId = flagId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flagId == null) ? 0 : flagId.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderFlagsDetailsPK other = (OrderFlagsDetailsPK) obj;
		if (flagId == null) {
			if (other.flagId != null)
				return false;
		} else if (!flagId.equals(other.flagId))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderFlagsDetailsPK [flagId=" + flagId + ", orderId=" + orderId + "]";
	}
	
}
