package com.att.comet.bpm.common.dao.impl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.BpmOrderBusinessStepDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmBusinessStep;
import com.att.comet.bpm.common.hibernate.bean.BpmOrderBusinessStepId;
import com.att.comet.bpm.common.hibernate.bean.OrderType;
import com.att.comet.bpm.common.hibernate.bean.Orders;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.repository.BpmOrderBusinessStepRepository;

@Component
public class BpmOrderBusinessStepDAOIml implements BpmOrderBusinessStepDAO{
	private static final Logger logger = LoggerFactory.getLogger(BpmOrderBusinessStepDAOIml.class);
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private BpmOrderBusinessStepRepository bpmOrderBusinessStepRepository;
	@Override
	public void saveBpmOrderBusinessStepForOrderIdAndOaDetails(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting saveBpmOrderBusinessStepForOrderIdAndOaDetails", this);
		Date today = new Date();
		String sql = "insert into bpm_order_business_step (order_id, business_step_id, order_type_id, business_step_status,business_step_value, comments, business_step_executed_on, created_on, updated_on, attuid) values(?, ?, (select order_type_id from order_type where lower(order_type.order_type_name)=lower(?)),?,?,?,?,?,?,?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getBusinessStepId());
		query.setParameter(3, commonBO.getOrderTypeName());
		if (commonBO.getApproved().equalsIgnoreCase("Approved")) {
			query.setParameter(4, "Approved");
		} else {
			query.setParameter(4, "Rejected");
		}
		query.setParameter(5, "");
		query.setParameter(6, commonBO.getComments());
		query.setParameter(7, today);
		query.setParameter(8, today);
		query.setParameter(9, today);
		query.setParameter(10, commonBO.getAssignee());
		query.executeUpdate();
		logger.info("@Ending saveBpmOrderBusinessStepForOrderIdAndOaDetails", this);	
	}

	@Override
	public void saveBpmOrderBusinessStepIWOACreation(CommonBO commonBO,String iwosTicketNumber, Date iwosCreationDate, String comments) {
		logger.info("@Starting saveBpmOrderBusinessStepIWOACreation", this);
		Date today = new Date();
		String sql = "insert into bpm_order_business_step (order_id, business_step_id, order_type_id, business_step_status,business_step_value, comments, business_step_executed_on, created_on, updated_on, attuid) values(?, ?, (select order_type_id from order_type where lower(order_type.order_type_name)=lower(?)),?,?,?,?,?,?,?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, commonBO.getOrderId());
		query.setParameter(2, commonBO.getBusinessStepId());
		query.setParameter(3, commonBO.getOrderTypeName());
		query.setParameter(4, "Created");
		query.setParameter(5, "");
		query.setParameter(6, comments);
		query.setParameter(7, today);
		query.setParameter(8, today);
		query.setParameter(9, today);
		query.setParameter(10, commonBO.getAdminEmail());
		query.executeUpdate();
		logger.info("@Ending saveBpmOrderBusinessStepIWOACreation", this);	
	}

	
	
}
