/**
 * 
 */
package com.att.comet.bpm.common.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author GB00476665
 *
 */
@Entity
@Table(name = "IMSI_DATACENTER_DETAILS")
public class ImsiDataCenterDetails implements java.io.Serializable {
	
	private static final long serialVersionUID = 173600822775132049L;
		
	private Apn apn;
	private Long dataCenterId;
	private String imsiMsisdn;
	private String imsiMsisdn2;
	
	/**
	 * @return the dataCenterId
	 */
	@Id
	@Column(name = "DATA_CENTER_ID", nullable = true, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return dataCenterId;
	}
	/**
	 * @param dataCenterId the dataCenterId to set
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}
	
	/**
	 * @return the insideOutside
	 */
	@Column(name = "IMSI_MSISDN", nullable = true, length = 100)
	public String getImsiMsisdn() {
		return imsiMsisdn;
	}
	/**
	 * @param imsiMsisdn the imsiMsisdn to set
	 */
	public void setImsiMsisdn(String imsiMsisdn) {
		this.imsiMsisdn = imsiMsisdn;
	}
	/**
	 * @return the insideOutside
	 */
	@Column(name = "IMSI_MSISDN2", nullable = true, length = 100)
	public String getImsiMsisdn2() {
		return imsiMsisdn2;
	}
	/**
	 * @param imsiMsisdn2 the imsiMsisdn2 to set
	 */
	public void setImsiMsisdn2(String imsiMsisdn2) {
		this.imsiMsisdn2 = imsiMsisdn2;
	}	
	/**
	 * @return the apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return apn;
	}
	/**
	 * @param apn the apn to set
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}
	
}
