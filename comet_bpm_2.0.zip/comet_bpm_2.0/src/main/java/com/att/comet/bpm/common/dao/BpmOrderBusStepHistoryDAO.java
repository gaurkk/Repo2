package com.att.comet.bpm.common.dao;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface BpmOrderBusStepHistoryDAO {

	void saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(CommonBO commonBO) throws CamundaServiceException;

}
