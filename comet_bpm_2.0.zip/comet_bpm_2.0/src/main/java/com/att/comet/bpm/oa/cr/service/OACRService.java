package com.att.comet.bpm.oa.cr.service;

import java.net.URISyntaxException;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OACRService {
	public CommonBO processDBInteractionOperation(CommonBO commonBO ,String processInstanceId) throws CamundaServiceException;

	public CommonBO postOperation(CommonBO commonBO,DelegateExecution execution)throws CamundaServiceException, URISyntaxException;

	public void rejected(CommonBO commonBO)throws CamundaServiceException;

	public void approved(CommonBO commonBO)throws CamundaServiceException;
}
