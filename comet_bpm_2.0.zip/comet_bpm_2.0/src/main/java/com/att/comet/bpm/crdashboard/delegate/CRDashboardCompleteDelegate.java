package com.att.comet.bpm.crdashboard.delegate;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.exception.BPMInvalidRequestException;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.hibernate.bean.BpmUrl;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.service.CommonService;
import com.att.comet.bpm.common.util.CommonUtils;
import com.att.comet.bpm.crdashboard.service.CRDashboardCompleteService;
@Component
public class CRDashboardCompleteDelegate implements JavaDelegate{
	private static final Logger logger = LoggerFactory.getLogger(CRDashboardCompleteDelegate.class);
	@Autowired
	private CommonService commonService;
	@Autowired
	CRDashboardCompleteService crDashboardCompleteService;
	public static final String URL_NAME = "SEARCH_ORDER_URL";
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String operationType = (String) execution.getVariable("OPERATION");
			if (!StringUtils.isEmpty(operationType)) {
				switch (operationType) {
				case BpmConstant.CR_PRE_OPERATION:
					preOperation(execution);
					break;
				case BpmConstant.CR_POST_OPERATION:
					postOperation(execution);
					break;
				}
			} else {
				logger.error("Comet request does not have::" + "data", this);
			}
		} catch (Exception e) {
			throw new CamundaServiceException("NO INPUT FOUND FOR NEXT FLOW STEPS");
		}
		
	}
	private void preOperation(DelegateExecution execution) throws CamundaServiceException {
		logger.info("Start preOperation method ::", this);
		CommonBO commonBO = null;
		Long orderId = (Long) execution.getVariable("orderId");
		String orderOperation = (String)execution.getVariable(BpmConstant.ORDER_OPERATION);
		if (null != orderId && CommonUtils.isNotNullEmpty(orderOperation)) {
			BpmUrl bpmUrl = commonService.getBpmUrl(URL_NAME);
			commonBO = commonService.getCommonBO(orderId);
			if(null!=commonBO) {
				execution.setVariable("orderId",commonBO.getOrderId());
				execution.setVariable("apnName", commonBO.getApnName());
				execution.setVariable("accountName", commonBO.getAccountName());
				execution.setVariable("cipn", commonBO.getCipn());
				execution.setVariable("backhaulIds", commonBO.getBackHaulIds());
				//execution.setVariable("url", bpmUrl.getUrl());
				execution.setVariable("pdpName", commonBO.getPdpName()); //Need to check PdpIdInfoRepository
				execution.setVariable("processType",commonBO.getOrderTypeName());
				execution.setVariable("expediteOrder", commonBO.isExpediteOrder());
				
				commonBO.setRoleId(1002L);//Setting OA roleID
				commonBO.setTaskStatusId(1001L);//OA Task Id//Creation
				
				commonBO.setCategoryId(1002L);//category ID (user task)
				commonBO.setUrlName(bpmUrl.getNew_url()+commonBO.getOrderId());
				commonBO.setProcessInstanceId(execution.getProcessInstanceId());
				commonBO.setTaskId(1031L);//Mapped from BPM_task table (CR Dashboard Complete Task)	
				commonBO.setTaskStatusName("ChangeRequestDashBaordComplete");
				commonBO.setOrderOperation(orderOperation);//Order Type coming from Frontend //2:OPERATION TYPE ("NEW_ORDER"  | "CHANGE_ORDER" | "CHANGE_REQUEST" | "EXPEDITE_ORDER" | "CANCEL_ORDER" | "DECOMMISSION_ORDER" | "ONHOLD_ORDER" | "DAPN_ORDER" )
				crDashboardCompleteService.preOperation(commonBO, execution.getProcessInstanceId());
				execution.setVariable("taskStatus", commonBO.getBusinessStepStatus());
				execution.setVariable("commonBO", commonBO);
			}
			 else {
					logger.error("Comet database retrival issue for ," + "order_id::[" + orderId + "]", this);
					throw new BpmnError("ERROR_BPM_001", "CR CO PREOPERATION SERVICE EXCEPTION");
				}
			} else {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"), this);
				throw new BpmnError("ERROR_BPM_001", "CR CO PREOPERATION SERVICE EXCEPTION");
				
			}
		
	}
	private void postOperation(DelegateExecution execution) {
		logger.info("Start postOperation method ::", this);
		CommonBO commonBO = (CommonBO)execution.getVariable("commonBO");
		String CCSPMComments = (String) execution.getVariable("comments");
		
		if(null!=commonBO) {
			try {
				commonBO.setComments(CCSPMComments);
				crDashboardCompleteService.postOperation(commonBO,execution);
				execution.setVariable("commonBO", commonBO);
			} catch (CamundaServiceException e) {
				logger.error("Comet request does not have::" + new BPMInvalidRequestException("ORDER IS IS NOT VALID"), this);
				throw new BpmnError("ERROR_BPM_001", "CR CO POSTOPERATION SERVICE EXCEPTION");
			}
			
		}
		logger.info("Existing postOperation method ::", this);
		
	}

}
