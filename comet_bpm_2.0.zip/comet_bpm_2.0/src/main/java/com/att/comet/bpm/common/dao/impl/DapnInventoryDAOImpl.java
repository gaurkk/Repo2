package com.att.comet.bpm.common.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.att.comet.bpm.common.dao.DapnInventoryDAO;
import com.att.comet.bpm.common.modal.CommonBO;

@Component
public class DapnInventoryDAOImpl implements DapnInventoryDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void saveDapnInventoryByOrderId(Long orderId) {

		String sql = "INSERT INTO dapn_inventory ( id, dapn_id, apn_type, apn_size, apn_name, pdp_name, ud_pdpid, mobile_ip, data_center_id, p_dns_add, s_dns_add, dns_notes, amp_info, created_on, created_by, updated_on, updated_by, dapn_status_id , batch_id, pdp_id, order_id, source_of_ip_addr, dns_server_ip, bhi_instance_type, m2m, mt)\r\n" + 
				"SELECT \r\n" + 
				"seq_dapn_upload_id.nextval, dapn_id, apn_type, apn_size, apn_name, pdp_name, ud_pdpid, mobile_ip, data_center_id, p_dns_add, s_dns_add, dns_notes, amp_info, created_on, created_by, updated_on, updated_by, dapn_status_id , batch_id, pdp_id, order_id, source_of_ip_addr, dns_server_ip, bhi_instance_type, m2m, mt FROM dapn_inventory WHERE order_id = ?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		query.executeUpdate();
	}

	@Override
	public void updateDapnInventoryByOrderIdAndId(Long orderId) {

		String sql = "UPDATE dapn_inventory SET order_id = ?, dapn_status_id = 1001 WHERE id = (SELECT max(id) FROM dapn_inventory WHERE order_id = ?)";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		query.setParameter(2, orderId);
		query.executeUpdate();
	}

	@Override
	public void updateDapnInventoryByOrderId(Long orderId) {
		String sql = "UPDATE dapn_inventory SET dapn_status_id = 1005 WHERE order_id =?";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, orderId);
		query.executeUpdate();
		
	}

}
