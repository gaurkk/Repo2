package com.att.comet.bpm.oa.service;


import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface OAApprovalService {

	void preOperation(CommonBO commonBO,String processInstanceId) throws CamundaServiceException;

	void approvedByOA(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

	void rejectedByOA(CommonBO commonBO,DelegateExecution execution) throws CamundaServiceException;

}
