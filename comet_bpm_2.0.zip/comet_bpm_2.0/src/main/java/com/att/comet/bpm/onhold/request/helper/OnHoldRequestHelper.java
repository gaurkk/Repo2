package com.att.comet.bpm.onhold.request.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.att.comet.bpm.common.constant.BpmConstant;
import com.att.comet.bpm.common.dao.AuditDAO;
import com.att.comet.bpm.common.dao.BpmDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusStepHistoryDAO;
import com.att.comet.bpm.common.dao.BpmOrderBusinessStepDAO;
import com.att.comet.bpm.common.dao.BpmOrderWorkStepDAO;
import com.att.comet.bpm.common.dao.GenericDAO;
import com.att.comet.bpm.common.dao.OrderCommentsDAO;
import com.att.comet.bpm.common.dao.OrderContactInfoDAO;
import com.att.comet.bpm.common.dao.OrderDAO;
import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;
import com.att.comet.bpm.common.util.CommonUtils;

@Component
public class OnHoldRequestHelper {
	private static final Logger logger = LoggerFactory.getLogger(OnHoldRequestHelper.class);

	@Autowired
	GenericDAO genericDAO;

	@Autowired
	OrderDAO orderDAO;

	@Autowired
	BpmDAO bpmDAO;

	@Autowired
	BpmOrderBusinessStepDAO bpmOrderBusinessStepDAO;

	@Autowired
	BpmOrderBusStepHistoryDAO bpmOrderBusStepHistoryDAO;

	@Autowired
	BpmOrderWorkStepDAO bpmOrderWorkStepDAO;

	@Autowired
	OrderContactInfoDAO orderContactInfoDAO;

	@Autowired
	OrderCommentsDAO orderCommentsDAO;

	@Autowired
	AuditDAO auditDAO;

	public void preOprCRUD(CommonBO commonBO, String processInstanceId) throws CamundaServiceException {

		logger.info("@Starting method preOprCRUD ", this);
		
		commonBO.setBpmProcessId(1028L);
		
		/* Get count, CRcount as per legacy implementation */
		Long count = orderDAO.countOrderEvent(commonBO);
		String crCountValue = "CR-00" + count;
		commonBO.setCrCountValue(crCountValue);

		String assigneeOS = null;
		Boolean User_or_group_exist = false;
		commonBO.setOrderContactTypeId(1003L);
		assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOS)) {
			User_or_group_exist = true;
			commonBO.setAssignee(assigneeOS);
			commonBO.setOrderManager(assigneeOS);
		}

		/* Get OS Email details */
		if (User_or_group_exist) {
			commonBO.setUser_or_group(assigneeOS);
			commonBO.setOsEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		/* Get Admin Email details */
		commonBO.setAdminEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1006L));

		/* Get OA Email details */
		String assigneeOA = null;
		commonBO.setOrderContactTypeId(1004L);
		assigneeOA = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOA)) {
			commonBO.setUser_or_group(assigneeOA);
			commonBO.setOaEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOaEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1002L));
		}

		/* Get OSD Email details */
		String assigneeOSD = null;
		commonBO.setOrderContactTypeId(1023L);
		assigneeOSD = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		if (CommonUtils.isNotNullEmpty(assigneeOSD)) {
			commonBO.setUser_or_group(assigneeOSD);
			commonBO.setOsdEmail(genericDAO.getEmailAssignedUserFromUsersByActiveAndUserorgroup(commonBO));
		} else {
			commonBO.setOsdEmail(genericDAO.getEmailFromUsersAndUserRoleByRoleIdAndActiveAndApproved(1001L));
		}

		// email to be sent to OS as TO in Notification , Reminder 1 , Reminder 2
		commonBO.setToEmail(commonBO.getOsEmail());

		// email to be sent to OA as CC in Notification , Reminder 1 , Reminder 2
		commonBO.setCcEmail(commonBO.getOaEmail());

		/* Set Reminder1 & Reminder2 SLA Dates */
		genericDAO.setReminderFromSlaWorkingDayForOnHoldRequestTask(commonBO);

		logger.info("@Ending method preOprCRUD ", this);
	}

	public void postOprCRUD(CommonBO commonBO, DelegateExecution execution) throws CamundaServiceException {

		logger.info("@Starting method postOprCRUD ", this);

		/* UPDATE ON_HOLD_STATUS_ID record in ORDER_ON_HOLD */
		commonBO.setOnHoldStatusId(1003L);
		orderDAO.updateOrderOnHoldStatusId(commonBO);

		/* DELETE record from BPM_ORDER_BUSINESS_STEP */
		List<Long> businessStepIdList = new ArrayList<>();
		businessStepIdList.add(3197L);
		commonBO.setBusinessStepIdList(businessStepIdList);
		bpmDAO.deleteBpmOrderBusinessStep(commonBO);

		/* INSERT record into BPM_Order_Business_Step */
		String assigneeOS = null;
		String response = (String) execution.getVariable(BpmConstant.RESPONSE);
		String reviewOsComments = (String) execution.getVariable(BpmConstant.COMMENTS);
		commonBO.setOrderContactTypeId(1003L);
		assigneeOS = genericDAO.getAttuidFromUsersAndOrderContactByOrderIdRoleIdAndActiveAndApproved(commonBO);
		commonBO.setAssignee(assigneeOS);
		commonBO.setOrderApprover(assigneeOS);
		commonBO.setApproved(response);
		commonBO.setComments(reviewOsComments);
		commonBO.setUpdatedBy(assigneeOS);
		commonBO.setUpdatedOn(new Date());
		commonBO.setBusinessStepStatus(response);
		commonBO.setBusinessStepId(3197L);
		//bpmOrderBusinessStepDAO.saveBpmOrderBusinessStepForOrderIdAndOaDetails(commonBO);
		bpmDAO.saveBpmOrderBusinessStep(commonBO);
		if (commonBO.getApproved().equalsIgnoreCase(BpmConstant.APPROVED)) {
			commonBO.setResponseHTAction("On-hold (OS) Approved");
			/* UPDATE ON_HOLD_APPROVED record in ORDER_ON_HOLD */
			orderDAO.updateOrderOnHoldApprovedDate(commonBO);
		} else {
			commonBO.setResponseHTAction("On-hold (OS) Rejected");
		}

		bpmOrderBusStepHistoryDAO.saveBpmOrderBusStepHistoryForOrderIdAndOaDetails(commonBO);

		commonBO.setBpmStepId(1002L);
		commonBO.setWorkStepId(1072L);
		bpmOrderWorkStepDAO.updateBpmOrderWorkStepForBpmStepIdAndUpdatedOn(commonBO);

		commonBO.setAttuid(assigneeOS);
		orderContactInfoDAO.updateOrderContactInfoForAttUidByOrderContactDetails(commonBO);

		commonBO.setRoleId(1001L);
		updatingOrderComments(commonBO);
		/* Get details from ORDER_ON_HOLD */
		List<Object[]> detailsOnHoldList = orderDAO.getOrderOnHoldDetails(commonBO);
		if(!CollectionUtils.isEmpty(detailsOnHoldList)) {
		for (Object[] detailsOnHold : detailsOnHoldList) {
			commonBO.setOnHoldRequestedDate(detailsOnHold[0] != null ? (Date) detailsOnHold[0] : null);
			commonBO.setOnHoldProposedCompletionDate(detailsOnHold[1] != null ? (Date) detailsOnHold[1] : null);
			commonBO.setOnHoldReason(detailsOnHold[2] != null ? detailsOnHold[2].toString() : "N/A");
			commonBO.setOnHoldNotes(detailsOnHold[3] != null ? detailsOnHold[3].toString() : "N/A");
		}
		}else {
			logger.debug("@@@ detailsOnHoldList is empty @@@ "+detailsOnHoldList.size(), this);
		}
		logger.info("@Ending method postOprCRUD ", this);
	}
		

	/**
	 * Updating On Hold Request Task Comments
	 * 
	 * @param commonBO
	 */
	private void updatingOrderComments(CommonBO commonBO) throws CamundaServiceException {
		/// Need to check order Type from Initial FE request from Main delegate
		if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_REQUEST)) {
			logger.info("@Starting method updatingOrderComments::" + commonBO.getOrderOperation(), this);
			commonBO.setOrderProcess(commonBO.getCrCountValue());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else if (commonBO.getOrderOperation().equals(BpmConstant.CHANGE_ORDER)) {
			logger.info("@Starting method updatingOrderComments::" + commonBO.getOrderOperation(), this);
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		} else {
			logger.info("@Starting method updatingOrderComments ::" + commonBO.getOrderOperation(), this);
			commonBO.setOrderProcess(commonBO.getOrderTypeName());
			orderCommentsDAO.insertOrderCommentsForOrderIdAndDetails(commonBO);
		}
	}

	public void updateOrdersOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method updateOrdersOperation ", this);

		commonBO.setOrderStatusId(1067L);
		orderDAO.updateOrderStatus(commonBO.getOrderId(), commonBO.getOrderStatusId());

		auditDAO.updateAuditOrders(commonBO);

		logger.info("@Ending method updateOrdersOperation ", this);
	}

	public void slaSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method slaSpecifiedOperation ", this);
		/* Set Reminder1 , Reminder2 , Reminder X SLA Dates */
		genericDAO.setReminderFromSlaWorkingDayForOnHoldRequest(commonBO);
		logger.info("@Ending method slaSpecifiedOperation ", this);
	}

	public void slaNotSpecifiedOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method slaNotSpecifiedOperation ", this);

		commonBO.setWorkStepId(1072L);
		Date updatedOn = bpmOrderWorkStepDAO.getUpdatedOnFromBpmOrderWorkStep(commonBO);
		/* Set Reminder1 , Reminder2 , Reminder X SLA Dates */
		commonBO.setOnHoldProposedCompletionDate(updatedOn);
		genericDAO.setReminderFromSlaWorkingDayForOnHoldRequest(commonBO);
		logger.info("@Ending method slaNotSpecifiedOperation ", this);

	}

	public void slaSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method slaSpecifiedReminderXOperation ", this);
		/* Set Reminder X SLA Dates */
		genericDAO.setReminderXFromSlaWorkingDayForOnHoldRequest(commonBO);
		int countReminderEmails = commonBO.getCountReminderEmails();
		countReminderEmails = countReminderEmails + 1;
		commonBO.setCountReminderEmails(countReminderEmails);
		logger.info("@Ending method slaSpecifiedReminderXOperation ", this);
	}

	public void slaNotSpecifiedReminderXOperation(CommonBO commonBO) throws CamundaServiceException {
		logger.info("@Starting method slaNotSpecifiedReminderXOperation ", this);
		/* Set Reminder X SLA Dates */
		genericDAO.setReminderXFromSlaWorkingDayForOnHoldRequest(commonBO);
		int countReminderEmails = commonBO.getCountReminderEmails();
		countReminderEmails += countReminderEmails;
		commonBO.setCountReminderEmails(countReminderEmails);
		logger.info("@Ending method slaNotSpecifiedReminderXOperation ", this);

	}

}
