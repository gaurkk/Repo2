package com.att.comet.bpm.apniwos.service;

import com.att.comet.bpm.common.exception.CamundaServiceException;
import com.att.comet.bpm.common.modal.CommonBO;

public interface ApnIwosOsdOrderUpdateService {
	void preOperationOrderUpdate(CommonBO commonBO) throws CamundaServiceException;
	void postOperationOrderUpdate(CommonBO commonBO, String osdComments) throws CamundaServiceException;
	void newOrderDBOperation(CommonBO commonBO) throws CamundaServiceException;
	void crcoDBOperation(CommonBO commonBO) throws CamundaServiceException;
}
