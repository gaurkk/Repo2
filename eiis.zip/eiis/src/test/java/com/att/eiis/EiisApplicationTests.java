package com.att.eiis;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EiisApplicationTests {

	@Test
	void contextLoads() {
	}

}
