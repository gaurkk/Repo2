package com.att.eiis.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.eiis.dao.hibernate.bean.Users;
import com.att.eiis.repository.UserRepository;

@Component
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	UserRepository userRepository;

	public Users findByUserAttId(String attuid)  {
		return userRepository.findByAttuid(attuid);
	}
}
