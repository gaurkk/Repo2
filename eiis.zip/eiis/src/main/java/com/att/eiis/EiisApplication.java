package com.att.eiis;

import javax.sql.DataSource;

import org.quartz.core.QuartzScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

import com.att.eiis.constants.EiisCommonConstants;

@SpringBootApplication
public class EiisApplication {

	public static void main(String[] args) {
		SpringApplication.run(EiisApplication.class, args);
	}

	@Bean
	public JndiDataSourceLookup getDSLookup() {
		return new JndiDataSourceLookup();
	}

	@Profile("dev")
	@Bean
	public DataSource getDevDS(@Autowired Environment env) {
		return getDSLookup().getDataSource(env.getProperty(EiisCommonConstants.JNDINAME));
	}

	@Profile("test")
	@Bean
	public DataSource getTestDS(@Autowired Environment env) {
		return getDSLookup().getDataSource(env.getProperty(EiisCommonConstants.JNDINAME));
	}

	@Profile("stg")
	@Bean
	public DataSource getStgDS(@Autowired Environment env) { 
		return  getDSLookup().getDataSource(env.getProperty(EiisCommonConstants.JNDINAME));
	}

	@Profile("uat")
	@Bean
	public DataSource getUatDS(@Autowired Environment env) { 
		return  getDSLookup().getDataSource(env.getProperty(EiisCommonConstants.JNDINAME));
	}

	@Profile("prod")
	@Bean
	public DataSource getProdDS(@Autowired Environment env) { 
		return  getDSLookup().getDataSource(env.getProperty(EiisCommonConstants.JNDINAME));
	}

}
