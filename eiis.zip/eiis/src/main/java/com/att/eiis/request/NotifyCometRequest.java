package com.att.eiis.request;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.request.RequestClient;
import com.att.eiis.email.EmailUtils;
import com.att.eiis.util.RequestType;

public class NotifyCometRequest extends AmpRequest {
	Logger logger = LoggerFactory.getLogger(NotifyCometRequest.class);
	
	private List<String> requestIdList;
	private String requestId;
	
	public NotifyCometRequest(List<String> requestIdList, String requestId) {
		this.requestIdList = requestIdList;
		this.requestId = requestId;
		logger.debug("Initialized notify comet thread for Request Id list of size : " + (requestIdList != null ? requestIdList.size() : 0));
	}

	@Override
	public void run() {
		logger.debug("Starting run() method in NotifyCometRequest.");

		Exception exception = null;
		int counter = 0;
		do {
			if (counter > 0) {
				try {
				
					Thread.sleep(waitForTimeInMillies);
		
				} catch (Exception e) {
					logger.warn("Error in waiting of details thread for Request Id : " + requestId, e);
				}
			}
			counter ++;
			exception = null;
			try {
				RequestClient.notifyComet(requestIdList);
				logger.debug("Successfully notified the Comet for request id : " + requestId);
			} catch (Exception e) {
				logger.error("Error in details thread for Request Id : " + requestId, e);
				exception = e;
			}
		} while (counter < retryCount && exception != null);

		if (exception != null) {
			logger.error("Error is not got resolved re-throwing exception along with notifying Comet support.");
			EmailUtils.sendDynamicllyCreatedEmail(3L, this.requestIdList, RequestType.NotifyComet);
			throw new RuntimeException(exception);
		}
	}

	@Override
	public String getRequestId() {
		return requestId;
	}

	@Override
	public String getRequestType() {
		return RequestType.NotifyComet.name();
	}
}