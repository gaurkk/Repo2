package com.att.eiis.listener;

import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.att.eiis.scheduler.EiisSchedularContext;
import com.att.eiis.threadpool.EiisThreadPoolManager;
import com.att.eiis.util.DatabaseUtil;

/**
 * 1) Initialize threads pool 2) Initialize scheduler
 */
@Component
public class EiisStartupListener implements ServletContextListener {

	Logger logger = LoggerFactory.getLogger(EiisStartupListener.class);

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		EiisThreadPoolManager.shutdownThreadPool();
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		try {
			
			Properties props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG");
			boolean startScheduler = Boolean.valueOf(props.getProperty("amp.use.scheduler.start"));
			logger.info("Initializing thread pool......"+startScheduler);
			
			EiisThreadPoolManager.initializeThreadPool();
			
			logger.info("Thread pool initialized successfully.");
			logger.info("Initializing quartz scheduler.");
			
			if (startScheduler) {
				EiisSchedularContext.startScheduler();
				logger.info("Quartz scheduler initialized successfully.");
			}
			
		} catch (Exception e) {
			logger.error(
					"There is some issue in initializing thread pool / quartz scheduler.",
					e);
		}
	}
}