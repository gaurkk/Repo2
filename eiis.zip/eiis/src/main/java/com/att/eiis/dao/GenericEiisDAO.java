package com.att.eiis.dao;

public interface GenericEiisDAO {

}
