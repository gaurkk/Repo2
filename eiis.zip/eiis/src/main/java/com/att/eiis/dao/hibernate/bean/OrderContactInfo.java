package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for OrderContactInfo. Mapped to ORDER_CONTACT_INFO table in
 * the database.
 */
@Entity
@Table(name = "ORDER_CONTACT_INFO")
public class OrderContactInfo implements Serializable {

	private static final long serialVersionUID = -1446354394088606311L;

	private OrderContactInfoId id;
	private OrderContactType orderContactType;
	private OrderContact orderContact;
	private Users users;
	private String name;
	private String phone;
	private String email;
	private String extention;

	/**
	 * Getter method for id. ORDER_CONTACT_ID mapped to ORDER_CONTACT_ID in the
	 * database table.
	 * 
	 * @return OrderContactInfoId
	 */
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "orderContactTypeId", column = @Column(name = "ORDER_CONTACT_TYPE_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderContactId", column = @Column(name = "ORDER_CONTACT_ID", nullable = false, precision = 12, scale = 0)) })
	public OrderContactInfoId getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            to id set.
	 */
	public void setId(OrderContactInfoId id) {
		this.id = id;
	}

	/**
	 * Getter method for orderContactType.
	 * 
	 * @return OrderContactType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_CONTACT_TYPE_ID", nullable = false, insertable = false, updatable = false)
	public OrderContactType getOrderContactType() {
		return this.orderContactType;
	}

	/**
	 * @param orderContactType
	 *            to orderContactType set.
	 */
	public void setOrderContactType(OrderContactType orderContactType) {
		this.orderContactType = orderContactType;
	}

	/**
	 * Getter method for orderContact.
	 * 
	 * @return OrderContact
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_CONTACT_ID", nullable = false, insertable = false, updatable = false)
	public OrderContact getOrderContact() {
		return this.orderContact;
	}

	/**
	 * @param orderContact
	 *            to orderContact set.
	 */
	public void setOrderContact(OrderContact orderContact) {
		this.orderContact = orderContact;
	}

	/**
	 * Getter method for users.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ATTUID")
	public Users getUsers() {
		return this.users;
	}

	/**
	 * @param users
	 *            to users set.
	 */
	public void setUsers(Users users) {
		this.users = users;
	}

	/**
	 * Getter method for name. NAME mapped to NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "NAME", length = 100)
	public String getName() {
		return this.name;
	}

	/**
	 * @param name
	 *            to name set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Getter method for phone. PHONE mapped to PHONE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PHONE", length = 100)
	public String getPhone() {
		return this.phone;
	}

	/**
	 * @param phone
	 *            to phone set.
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Getter method for extention. PHONE_EXTENTION mapped to PHONE_EXTENTION in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PHONE_EXTENTION", length = 100)
	public String getExtention() {
		return extention;
	}

	/**
	 * @param extention
	 *            to extention set.
	 */
	public void setExtention(String extention) {
		this.extention = extention;
	}

	/**
	 * Getter method for email. EMAIL mapped to EMAIL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EMAIL", length = 100)
	public String getEmail() {
		return this.email;
	}

	/**
	 * @param email
	 *            to email set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}