package com.att.eiis.dao;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.EiisOrderBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;
import com.att.eiis.dao.GenericEiisDAO;
import com.att.eiis.dao.hibernate.bean.FetchEmailTemplateInfo;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.exception.EiisServiceException;

public interface EiisDAO extends GenericEiisDAO {
	
	public AmpResponseBO create(EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public AmpResponseBO cancel(EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public String login(UserBean userBO,String orderId,String requestId,int serverNo) throws EiisDataException;
	
	public AmpResponseBO getStatusById(EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public AmpResponseBO getDetailsById(EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public List<AmpResponseBO> createAcca(EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public AmpResponseBO getAccaStatusById(RequestBO requestBO,EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public AmpResponseBO getAccaDetailsById(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException;
	
	public Properties getEiisConfigProperties(String key) throws EiisDataException;
	
	public String getExtInterfaceOrderId(String requestId) throws EiisDataException;
	
	public Map<String,Object> getFirstNetCcsMxFlag(String orderId) throws EiisDataException;
	
	public FetchEmailTemplateInfo getFetchEmailTemplateInfo(Long emailTemplateId) throws EiisDataException;
	
	public void updateEventDetails(String rid, Long statusId) throws EiisDataException;
	
	public AmpResponseBO checkAmpMaintance() throws EiisDataException;
	
	public String updateEventStatus(String rid) throws EiisDataException;
}
