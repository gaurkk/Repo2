package com.att.eiis.constants;

/**
 * Holds the scalar constant for native sql queries.
 */
public class EiisScalarConstants {

	public static final String FIRSTNET_EPC = "FIRSTNET_EPC";
	public static final String CCSMX = "CCSMX";
	

}