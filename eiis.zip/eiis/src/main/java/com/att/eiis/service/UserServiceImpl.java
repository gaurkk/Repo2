package com.att.eiis.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.att.eiis.bean.RoleBO;
import com.att.eiis.bean.UserBO;
import com.att.eiis.dao.UserDAO;
import com.att.eiis.dao.hibernate.bean.Role;
import com.att.eiis.dao.hibernate.bean.UserRole;
import com.att.eiis.dao.hibernate.bean.Users;

@Service
public class UserServiceImpl implements UserService {
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	UserDAO userDAO;
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public UserBO getUser(String attuId) {
		logger.info("[attuId : " + (attuId == null ? "" : attuId) + "] "+ "Starting method getUser : ", this);
		Users users = null;

		try {
			users = userDAO.findByUserAttId(attuId);
		} catch (Exception exception) {
			logger.error("Exception in getting user data");
		}

		UserBO userBO = new UserBO();
		Set<UserRole> userRole = null;
		List<RoleBO> lstRoleBO = new ArrayList<RoleBO>();

		if (null != users) {
			userRole = users.getUserRoles();
			if (userRole != null && !CollectionUtils.isEmpty(userRole)) {
				for (UserRole userRoleBean : userRole) {
					Role role = userRoleBean.getRole();
					lstRoleBO.add(new RoleBO(role.getRoleId(), role.getRoleName()));
				}
				// sorting roles based on RoleName
				lstRoleBO.sort((roleBO1, roleBO2)->roleBO1.getRoleName().compareTo(roleBO2.getRoleName()));
				userBO = new UserBO();
				BeanUtils.copyProperties(users, userBO);
				userBO.setCityName(users.getCity() == null ? null:users.getCity().getCityName()); 
				userBO.setStateName(users.getState() == null ? null:users.getState().getStateName());
				userBO.setCountryName(users.getCountry() == null ? null:users.getCountry().getCountryName());
				userBO.setIsActive(users.getActive());
				userBO.setRoleList(lstRoleBO);
			}

		} else {
			logger.error("getUserRoles() :: users DAO is having NULL value::", this);
		}
		logger.info("[attuId : " + (attuId == null ? "" : attuId) + "] "+ "Exiting method getUser : ", this);
		return userBO;
	}

	@Transactional
	public boolean isAuthorizeUser(String attuId, long roleId) {
		logger.info("[attuId : " + (attuId == null ? "" : attuId) + "] "+"Starting method isAuthorizeUser : ", this);
		Users users = userDAO.findByUserAttId(attuId);
		Optional<UserRole> role = users.getUserRoles().stream()
				.filter(userRole -> userRole.getId().getRoleId().equals(roleId)).findFirst();
		if (role.isPresent()) {
			logger.debug("End method isAuthorizeUser", this);
			return true;
		}
		logger.info("[attuId : " + (attuId == null ? "" : attuId) + "] "+"Exiting method isAuthorizeUser : ", this);
		return false;
	}
	
}
