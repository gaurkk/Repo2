package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Country. Mapped to COUNTRY table in the database.
 */
@Entity
@Table(name = "COUNTRY")
public class Country implements Serializable {

	private static final long serialVersionUID = -3427530836240319124L;

	private Long countryId;
	private String countryName;
	private Character active;
	private Set<Users> userses = new HashSet<Users>(0);
	private Set<State> states = new HashSet<State>(0);
	private Set<SubAccount> subAccountsForClCountryId = new HashSet<SubAccount>(
			0);
	private Set<SubAccount> subAccountsForBlCountryId = new HashSet<SubAccount>(
			0);
	private Set<SubAccount> subAccountsForMccCountryId = new HashSet<SubAccount>(
			0);
	private Set<SubAccount> subAccountsForHlCountryId = new HashSet<SubAccount>(
			0);

	/**
	 * Getter method for countryId. COUNTRY_ID mapped to COUNTRY_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Id
	@GenericGenerator(name = "SEQ_COUNTRY_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_COUNTRY_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_COUNTRY_ID")
	@Column(name = "COUNTRY_ID", nullable = false, precision = 12, scale = 0)
	public Long getCountryId() {
		return this.countryId;
	}

	/**
	 * @param countryId
	 *            to countryId.
	 */
	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	/**
	 * Getter method for countryName. COUNTRY_NAME mapped to COUNTRY_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "COUNTRY_NAME", nullable = false, length = 100)
	public String getCountryName() {
		return this.countryName;
	}

	/**
	 * @param countryName
	 *            to countryName set.
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	@Column(name = "ACTIVE", length = 1)
	public Character getActive() {
		return active;
	}

	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for userses.
	 * 
	 * @return Set<Users>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "country")
	public Set<Users> getUserses() {
		return this.userses;
	}

	/**
	 * @param userses
	 *            to userses set.
	 */
	public void setUserses(Set<Users> userses) {
		this.userses = userses;
	}

	/**
	 * Getter method for states.
	 * 
	 * @return Set<State>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "country")
	public Set<State> getStates() {
		return this.states;
	}

	/**
	 * @param states
	 *            to states.
	 */
	public void setStates(Set<State> states) {
		this.states = states;
	}

	/**
	 * Getter method for subAccountsForClCountryId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryByClCountryId")
	public Set<SubAccount> getSubAccountsForClCountryId() {
		return this.subAccountsForClCountryId;
	}

	/**
	 * @param subAccountsForClCountryId
	 *            to subAccountsForClCountryId set.
	 */
	public void setSubAccountsForClCountryId(
			Set<SubAccount> subAccountsForClCountryId) {
		this.subAccountsForClCountryId = subAccountsForClCountryId;
	}

	/**
	 * Getter method for subAccountsForBlCountryId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryByBlCountryId")
	public Set<SubAccount> getSubAccountsForBlCountryId() {
		return this.subAccountsForBlCountryId;
	}

	/**
	 * @param subAccountsForBlCountryId
	 *            to subAccountsForBlCountryId set.
	 */
	public void setSubAccountsForBlCountryId(
			Set<SubAccount> subAccountsForBlCountryId) {
		this.subAccountsForBlCountryId = subAccountsForBlCountryId;
	}

	/**
	 * Getter method for subAccountsForMccCountryId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryByMccCountryId")
	public Set<SubAccount> getSubAccountsForMccCountryId() {
		return this.subAccountsForMccCountryId;
	}

	/**
	 * @param subAccountsForMccCountryId
	 *            to subAccountsForMccCountryId set.
	 */
	public void setSubAccountsForMccCountryId(
			Set<SubAccount> subAccountsForMccCountryId) {
		this.subAccountsForMccCountryId = subAccountsForMccCountryId;
	}

	/**
	 * Getter method for subAccountsForHlCountryId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryByHlCountryId")
	public Set<SubAccount> getSubAccountsForHlCountryId() {
		return this.subAccountsForHlCountryId;
	}

	/**
	 * @param subAccountsForHlCountryId
	 *            to subAccountsForHlCountryId set.
	 */
	public void setSubAccountsForHlCountryId(
			Set<SubAccount> subAccountsForHlCountryId) {
		this.subAccountsForHlCountryId = subAccountsForHlCountryId;
	}
}