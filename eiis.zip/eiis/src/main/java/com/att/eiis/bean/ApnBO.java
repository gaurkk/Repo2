package com.att.eiis.bean;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ApnBO {

	private String zone_name;
	
	@JsonProperty("APN_name")
	private String apnName;
	
	@JsonProperty("customer_name")
	private String customerName;
	
	@JsonProperty("destination_IP")
	private String destinationIp;
	
	@JsonProperty("protocol")
	private String protocol;
	
	@JsonProperty("threshold")
	private long threshold;
	
	@JsonProperty("IMSI_1")
	private String imsi1;
	
	@JsonProperty("IMSI_2")
	private String imsi2;
	
	@JsonProperty("MSISDN_1")
	private String msisdn1;
	
	@JsonProperty("MSISDN_2")
	private String msisdn2;
	
	@JsonProperty("monitoring_status")
	private String monitoringStatus;
	
}
