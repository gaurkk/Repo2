package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for OrderContactInfoId.
 */
@Embeddable
public class OrderContactInfoId implements Serializable {

	private static final long serialVersionUID = 1530024979935995515L;

	private Long orderContactTypeId;
	private Long orderContactId;

	/**
	 * Getter method for orderContactTypeId. ORDER_CONTACT_TYPE_ID mapped to
	 * ORDER_CONTACT_TYPE_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_CONTACT_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderContactTypeId() {
		return this.orderContactTypeId;
	}

	/**
	 * @param orderContactTypeId
	 *            to orderContactTypeId set.
	 */
	public void setOrderContactTypeId(Long orderContactTypeId) {
		this.orderContactTypeId = orderContactTypeId;
	}

	/**
	 * Getter method for orderContactId. ORDER_CONTACT_ID mapped to
	 * ORDER_CONTACT_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_CONTACT_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderContactId() {
		return this.orderContactId;
	}

	/**
	 * @param orderContactId
	 *            to orderContactId set.
	 */
	public void setOrderContactId(Long orderContactId) {
		this.orderContactId = orderContactId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof OrderContactInfoId))
			return false;
		OrderContactInfoId castOther = (OrderContactInfoId) other;

		return (this.getOrderContactTypeId() == castOther
				.getOrderContactTypeId())
				&& (this.getOrderContactId() == castOther.getOrderContactId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;
		result = 37 * result + (int) this.getOrderContactTypeId().hashCode();
		result = 37 * result + (int) this.getOrderContactId().hashCode();
		return result;
	}
}