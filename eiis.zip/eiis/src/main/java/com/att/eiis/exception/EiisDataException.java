/**
 * 
 */
package com.att.eiis.exception;

import java.util.List;

/**
 * Base exception class for COMET data layer.
 */
public class EiisDataException extends EiisException {

	private static final long serialVersionUID = 9036263879592175565L;

	/**
	 * CometDataException Constructor with String argument errorCode.
	 * 
	 * @param errorCode
	 */
	public EiisDataException(String errorCode) {
		super(errorCode);
	}

	/**
	 * CometDataException Constructor with multiple arguments.
	 * 
	 * @param errorCode
	 * @param message   DL001:Account information CIPN can not be null DL002:Account
	 *                  information BCID can not be null DL003:Number of data center
	 *                  can not be null DL004:APN selection can not be null
	 *                  DL005:Backhaul selection can not be null
	 */

	public EiisDataException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * CometDataException Constructor with multiple arguments.
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public EiisDataException(String errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * CometDataException Constructor with multiple arguments.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public EiisDataException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

	/**
	 * CometException Constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 */
	public EiisDataException(String errorCode, List<String> errorList) {
		super(errorList);
	}
}