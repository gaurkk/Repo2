package com.att.eiis.request;

import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.att.eiis.util.DatabaseUtil;

@Component
public class RequestClient {
	
	private static String cometRestUrl = "http://localhost:8282/comet-web/notifyComet";

	private static RestTemplate restTemplate = null;
	private static Logger logger = LoggerFactory.getLogger(RequestClient.class); 

	//Initializing the variable at the time of class load
	static {
		logger.info("Initializing COMET REST server attributes.");
	    restTemplate = new RestTemplate();
	    Properties props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG");
		boolean useTestUrls = Boolean.valueOf(props.getProperty("comet.use.request.test.url"));
		if (useTestUrls) {
			logger.info("Initializing class attributes i.e. test server urls.");
			cometRestUrl = props.getProperty("comet.rest.request.test.url");
		} else {
			logger.info("Initializing class attributes i.e. server urls.");
			cometRestUrl = props.getProperty("comet.rest.request.url");
		}
		logger.info("COMET REST server attributes are initialized i.e. server urls.");
	}

	/**
	 * Notifies to the COMET server
	 * @param list of request ids
	 */
	public static void notifyComet(List<String> requestIdList) {
		logger.debug("Starting notifyComet() method with requestIds : " + requestIdList);
		
		try {
			restTemplate.getForObject(cometRestUrl, String.class);
		} catch (Exception e) {
			logger.error("Error while notifying to COMET.", e);
			throw new RuntimeException(e);
		}
	 
		logger.debug("Exiting notifyComet() method.");
	}
}