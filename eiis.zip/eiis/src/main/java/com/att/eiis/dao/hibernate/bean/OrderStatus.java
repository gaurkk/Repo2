package com.att.eiis.dao.hibernate.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for OrderStatus. Mapped to ORDER_STATUS table in the database.
 */
@Entity
@Table(name = "ORDER_STATUS")
public class OrderStatus implements java.io.Serializable {

	private static final long serialVersionUID = 8073725946256810325L;
	private Long orderStatusId;
	private String orderStatusName;
	private Set<Orders> orderses = new HashSet<Orders>(0);
	private String orderStatusDescription;

	/**
	 * No-argument constructor of the class.
	 */
	public OrderStatus() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderStatusId
	 * @param orderStatusName
	 */
	public OrderStatus(Long orderStatusId, String orderStatusName) {
		this.orderStatusId = orderStatusId;
		this.orderStatusName = orderStatusName;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderStatusId
	 * @param orderStatusName
	 * @param orderses
	 * @param orderStatusHistories
	 */
	public OrderStatus(Long orderStatusId, String orderStatusName, Set<Orders> orderses) {
		this.orderStatusId = orderStatusId;
		this.orderStatusName = orderStatusName;
		this.orderses = orderses;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderStatusId
	 * @param orderStatusName
	 * @param orderStatusDescription
	 */
	public OrderStatus(Long orderStatusId, String orderStatusName, String orderStatusDescription) {
		this.orderStatusId = orderStatusId;
		this.orderStatusName = orderStatusName;
		this.orderStatusDescription = orderStatusDescription;
	}

	/**
	 * Getter method for orderStatusId. ORDER_STATUS_ID mapped to ORDER_STATUS_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_STATUS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderStatusId() {
		return this.orderStatusId;
	}

	/**
	 * @param orderStatusId
	 *            to orderStatusId set.
	 */
	public void setOrderStatusId(Long orderStatusId) {
		this.orderStatusId = orderStatusId;
	}

	/**
	 * Getter method for orderStatusName. ORDER_STATUS_NAME mapped to ORDER_STATUS_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_STATUS_NAME", nullable = false, length = 50)
	public String getOrderStatusName() {
		return this.orderStatusName;
	}

	/**
	 * @param orderStatusName
	 *            to orderStatusName set.
	 */
	public void setOrderStatusName(String orderStatusName) {
		this.orderStatusName = orderStatusName;
	}

	/**
	 * Getter method for orderStatusDescription. ORDER_STATUS_NAME mapped to ORDER_STATUS_DESCRIPTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_STATUS_DESCRIPTION", nullable = false, length = 100)
	public String getOrderStatusDescription() {
		return orderStatusDescription;
	}

	/**
	 * @param orderStatusDescription
	 *            to orderStatusDescription set.
	 */
	public void setOrderStatusDescription(String orderStatusDescription) {
		this.orderStatusDescription = orderStatusDescription;
	}

	/**
	 * Getter method for orderses.
	 * 
	 * @return Set<Orders>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orderStatus")
	public Set<Orders> getOrderses() {
		return this.orderses;
	}

	/**
	 * @param orderses
	 *            to orderses set.
	 */
	public void setOrderses(Set<Orders> orderses) {
		this.orderses = orderses;
	}

}
