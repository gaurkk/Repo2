package com.att.eiis.bean;

/**
 * Enum constants for Roles
 * 
 */
public enum RoleEnum {
	ORDER_SUBMITTERS(1001L, "Order Submitter", "OS/OSD"), ORDER_APPROVER(1002L, "Order Approver", "OA"),
	ORDER_MANAGER(1003L, "Order Manager", "OM"), NETWORK_IMPLEMENTATION(1004L, "Network Implementation", "NI"),
	CCS_PM(1005L, "CCS PM", "CCS PM"), COMET_ADMIN(1006L, "COMET Admin", "Admin"), GUEST(1007L, "Guest", "Guest"),
	IT_OPS(1008L, "IT Operations", "IT OPS");

	private Long roleId;
	private String roleName;
	private String roleShortCode;

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public String getRoleShortCode() {
		return roleShortCode;
	}

	public static RoleEnum getByRoleId(Long roleId) {
		RoleEnum roleEnum = null;
		for (RoleEnum role : values()) {
			if (role.getRoleId().equals(roleId)) {
				roleEnum = role;
			}
		}
		return roleEnum;
	}

	private RoleEnum(Long roleId, String roleName, String roleShortCode) {
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleShortCode = roleShortCode;
	}
}