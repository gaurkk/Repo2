package com.att.eiis.constants;

public class EiisSQLConstants {
	
	public static final String FETCH_EIIS_CONFIGURATION = "SELECT VALUE "
			+ "FROM EIIS_CONFIGURATION "
			+ "WHERE KEY = ?";

	public static final String REQUEST_ID_FOR_ORDER_ID = "SELECT EXT_INTERFACE_ID "
			+ "FROM EXT_INTERFACE_DETAILS "
			+ "WHERE ORDER_ID = :orderId "
			+ "AND UPDATED_ON = (SELECT max(UPDATED_ON) FROM EXT_INTERFACE_DETAILS where order_id = :orderId) ";

	public static final String ORDER_ID_FOR_REQUEST_ID = "SELECT ORDER_ID "
			+ "FROM EXT_INTERFACE_DETAILS "
			+ "WHERE EXT_INTERFACE_ID IN (?)";

	public static final String REQUEST_JSON_FOR_ORDER_ID = "SELECT GET_AMP_CREATE_REQUEST_JSON(?) responseJson "
			+ "FROM dual";
	
	public static final String APPLICABLE_REQUEST_IDS_FOR_STATUS_SYNC = "SELECT EXT_INTERFACE_ID "
			+ "FROM EXT_INTERFACE_DETAILS "
			//+ "WHERE EVENT_STATUS_ID = 1002 AND EXT_INTERFACE_ID   LIKE ('RANDOM%')";
			+ "WHERE EVENT_STATUS_ID = 1001 AND EXT_INTERFACE_ID NOT LIKE ('RANDOM%')"; //to revert back changes

	public static final String APPLICABLE_REQUEST_IDS_FOR_DETAILS_SYNC = "SELECT EXT_INTERFACE_ID "
			+ "FROM EXT_INTERFACE_DETAILS "
			//+ "WHERE EVENT_STATUS_ID = 1001 AND EXT_INTERFACE_ID LIKE ('RANDOM%')";  // to revert changes for LIKE condition
			+ "WHERE EVENT_STATUS_ID = 1002 AND EXT_INTERFACE_ID NOT LIKE ('RANDOM%')";
	
	public static final String FETCH_EMAIL_TEMPLATE_INFO = "SELECT EMAIL_TEMPLATE_NAME, FROM_USER, TO_LIST, CC_LIST, "
			+ "MESSAGE_HEADER, MESSAGE_FOOTER, MESSAGE, SUBJECT "
			+ "FROM EMAIL_TEMPLATE_INFORMATION "
			+ "WHERE EMAIL_TEMPLATE_ID = ?";
	
	public static final String MAX_QUERY = "SELECT MAX(ID) FROM EXT_INT_EVENT_LOGS";
	
	public static final String INSERT_EVENT_LOGS = " INSERT INTO EXT_INT_EVENT_LOGS "
			+ "(ID, EXT_INTERFACE_ID, REQUEST_JSON, RESPONSE_JSON, RESPONSE_CODE, SUCCESS, EVENT_TYPE_ID, UPDATED_BY, UPDATED_ON) "
			+ "VALUES (SEQ_EVENT_EVENT_LOGS.nextval, ?, ?, ?, ?, ?, ?, ?, ?) ";
	
	public static final String INSERT_EVENT_DETAILS = "INSERT INTO EXT_INTERFACE_DETAILS "
			+ "(EXT_INTERFACE_ID, ORDER_ID, CREATED_AT, UPDATED_ON, EVENT_STATUS_ID, ORDER_STATUS_NAME,REQUEST_TYPE)"
			+ " VALUES (?, ?, ?, ?, ?, ?, ?) ";

	public static final String UPDATE_EVENT_DETAILS = "UPDATE EXT_INTERFACE_DETAILS "
			+ "SET UPDATED_ON = ?, EVENT_STATUS_ID = ? "
			+ "WHERE EXT_INTERFACE_ID = ?";
	
	public static final String INSERT_EVENT_STATUS = " INSERT INTO EXT_INT_EVENT_STATUSES "
			+ "(ID,EXT_INTERFACE_ID,STATUS_DESC,STATUS_TIME,UPDATED_BY) "
			+ "VALUES (SEQ_EVENT_STATUSES_ID.nextval, ?, ?, ?, ?) ";
	
	public static final String AMP_MAINTAINACE_TIME = "SELECT CATEGORY_VALUE FROM ADMIN_CONFIG WHERE ADMIN_CATEGORY_ID = '1072'";

	
	public static final String ORDER_STATUS_QUERY = " SELECT OS.ORDER_STATUS_NAME "
			+ "FROM ORDER_STATUS OS,ORDERS ORD "
			+ "WHERE ORD.ORDER_STATUS_ID = OS.ORDER_STATUS_ID AND ORD.ORDER_ID = ? ";
	
	public static final String ORDER_FIRSTNET_CCSMX_FLAG = " SELECT NVL(O.FIRSTNET_EPC,'N') AS FIRSTNET_EPC,NVL(APN.CCSMX,'N') AS CCSMX "
			+ "FROM ORDERS O,APN APN "
			+ "WHERE O.ORDER_ID = APN.ORDER_ID AND O.ORDER_ID = :order_id ";
	
	public static final String GET_ORDER_ID_QUERY = " SELECT ORDER_ID FROM EXT_INTERFACE_DETAILS WHERE EXT_INTERFACE_ID = ? ";
	
	public static final String ACCA_REQUEST_JSON_FOR_ORDER_ID = "SELECT GET_ACCA_REQUEST_JSON(?) responseJson "
			+ "FROM dual";
	
	public static final String UPDATE_ORDER_DATA_CENTER = "UPDATE  ORDER_DATA_CENTER SET EXT_INTERFACE_ID = ? WHERE ORDER_ID = ? AND DATA_CENTER_ID = (SELECT DATA_CENTER_ID from DATA_CENTER where UPPER(DATA_CENTER_NAME) = ?)";

	public static final String SELCT_ORDER_FLAG = "SELECT flag_value FROM order_flags_details WHERE order_id= ? and flag_id=1003";

	public static final String UPDATE_ORDER_FLAG = "update order_flags_details set flag_value ='Y' WHERE order_id= ? and flag_id=1003";
	
	public static final String INSERT_ORDER_FLAG = "insert into order_flags_details (flag_ID,order_id,flag_value,updated_on) values (1003,?,'Y',SYSDATE)";
}
