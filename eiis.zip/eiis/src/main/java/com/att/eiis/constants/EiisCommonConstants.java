package com.att.eiis.constants;

public class EiisCommonConstants {
	public static final String BLANK_USERNAME = "User name field is mandatory";
	public static final String BLANK_PASSWORD = "Password field is mandatory";
	public static final String WRONG_USERNAME ="Incorrect Username";
	public static final String WRONG_PASSWORD ="Incorrect Password";
	public static final String SUCCESS ="success";
	
	//Generic Constants
	public static final String AMP_TOKEN = "AMP_TOKEN";
	
	
	//JDBC Constatnts
	public static final String DB_JNDI = "javax.persistence.jndi.name";
	public static final String DB_DRIVER = "javax.persistence.jdbc.driver";
	public static final String DB_URL = "comet.connection.url";
	public static final String DB_USER = "comet.connection.username";
	public static final String DB_PASSWD = "comet.connection.password";
	public static final String DB_DIALECT = "javax.persistence.jdbc.dialect";

	public static final String ORDER_ID_KEY = "%orderId%";
	public static final String REQUEST_TYPE_KEY = "%requestType%";
	public static final String ORDER_ID_MAP_KEY = "orderId";
	public static final String REQUEST_TYPE_MAP_KEY = "requestType";
	
	//Rest Call Constant 
	public static final String HTTP_CODE="HTTPCode";
	public static final String COMET_CSP_AUTH = "REST_URL_COMET_CSP_AUTH";
	
	public static final String REQUEST_FOR_ORDER_ID = "SELECT GET_AMP_CREATE_REQUEST_JSON(:p_order_id) FROM DUAL";
	public static final String ACCA_REQUEST_FOR_ORDER_ID = "SELECT GET_ACCA_REQUEST_JSON(:p_order_id) responseJson FROM DUAL";
	public static final String ORDER_ID = "p_order_id";
	public static int WAIT_FOR_TIME_IN_MILLIES = 5000;
	public static int RETRY_COUNT = 3;
	public static int SERVER_COUNT = 3;
	public static String AMP_REQUEST="AMP";
	public static String ACCA_REQUEST="ACCA";
	public static String UPDATE_EVENT_STATUS="UPDATE_EVENT_STATUS";
	public static final String JNDINAME = "spring.datasource.jndi-name";
	public final static char NAME_VALUE_SEPARATOR = '=';
	public final static String CSPMONITOR_ID="CSPmonitor_id";
	public final static String CSPMONITOR_PASSWORD="CSPmonitor_password";
	public final static String MECHID="MechID";
}
