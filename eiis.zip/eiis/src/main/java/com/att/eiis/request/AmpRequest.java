package com.att.eiis.request;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.eiis.dao.EiisDAO;
import com.att.eiis.util.DatabaseUtil;

@Component
public abstract class AmpRequest extends Thread {
	private static Logger logger = LoggerFactory.getLogger(AmpRequest.class);
	
	protected static int retryCount = 3;
	protected static int serverCount = 1;
	protected static int waitForTimeInMillies = 5000;

	static {
		logger.debug("Initializing attributes in AmpRequest.");
		 Properties props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG");
		 
		try {
			retryCount = Integer.valueOf(props.getProperty("amp.request.retry.count"));
			serverCount = Integer.valueOf(props.getProperty("amp.server.count"));
		} catch (Exception e) {
			logger.warn("Error in reading retryCount from properties file.", e);
		}
		
		try {
			waitForTimeInMillies = Integer.valueOf(props.getProperty("amp.request.wait.for.time.in.milli.seconds"));
		} catch (Exception e) {
			logger.warn("Error in reading waitForTimeInMillies from properties file.", e);
		}
		
		logger.debug("Attributes in AmpRequest initialized successfully - retryCount : " + retryCount + ", waitForTimeInMillies : " + waitForTimeInMillies);
	}

	public abstract void run();

	public abstract String getRequestId();

	public abstract String getRequestType();
}