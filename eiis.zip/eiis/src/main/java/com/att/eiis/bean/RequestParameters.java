package com.att.eiis.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestParameters {
	private String action;
	private AccaInput accaInput;
	
}
