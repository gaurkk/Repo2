package com.att.eiis.bean;

import java.util.List;

import com.att.eiis.bean.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Business object for User.
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class UserBO extends CometGenericBO {

	private static final long serialVersionUID = 723225125095544664L;
	private String attuid; 
	private String firstName; 
	private String lastName; 
	private String cellPhone; 
	private String deskPhone; 
	private String email; 
	private String streetAddress; 
	private String zipCode; 
	private String deskPhoneExtention;
	private String cityName; 
	private String stateName; 
	private String countryName;
	@JsonInclude(Include.NON_NULL)
	private Character isActive;
	@JsonInclude(Include.NON_NULL)
	private List<RoleBO> roleList;
}
