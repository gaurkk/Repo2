package com.att.eiis.dao.hibernate.bean;

import java.sql.Blob;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.att.eiis.bean.CodePrefixedSequenceIdGenerator;


@Entity
@Table(name = "INTERNAL_PRODUCT_ACCOUNT")
public class InternalProductAccount implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8362043508035015287L;
	private String cipn;
	private AccountClass accountClass;
	private String internalProductAccountName;
	private String federalTaxId;
	private Character tsp;
	private Character feeWaiverApproved;
	private String waiverNotes;
	private Blob waiverAttachment;
	private String createdBy;
	private Date createdOn;
	private String updatedBy;
	private Date updatedOn;
	private Character active;
	private String waiverAttachmentFilename;
	private Set<Orders> orderses = new HashSet<Orders>(0);
	private Set<Vpn> vpns = new HashSet<Vpn>(0);

	/**
	 * Getter method for cipn. CIPN mapped to CIPN in the database table.
	 * 
	 * @return String
	 */
	
	@Id
	@Column(name = "CIPN", unique = true, nullable = false, precision = 12, scale = 0)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cipn_id")
    @GenericGenerator(
        name = "seq_cipn_id", 
        strategy = "com.att.eiis.bean.CodePrefixedSequenceIdGenerator", 
        parameters = {
            @Parameter(name = CodePrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "1"),
            @Parameter(name = CodePrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "CIPN"),
            @Parameter(name = CodePrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%06d") })
	public String getCipn() {
		return this.cipn;
	}

	/**
	 * @param cipn
	 *            to cipn set.
	 */
	public void setCipn(String cipn) {
		this.cipn = cipn;
	}

	/**
	 * Getter method for accountClass.
	 * 
	 * @return AccountClass
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_CLASS_ID", nullable = false)
	public AccountClass getAccountClass() {
		return this.accountClass;
	}

	/**
	 * @param accountClass
	 *            to accountClass set.
	 */
	public void setAccountClass(AccountClass accountClass) {
		this.accountClass = accountClass;
	}

	/**
	 * Getter method for internalProductAccountName.
	 * INTERNAL_PRODUCT_ACCOUNT_NAME mapped to INTERNAL_PRODUCT_ACCOUNT_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INTERNAL_PRODUCT_ACCOUNT_NAME", nullable = false, length = 100)
	public String getInternalProductAccountName() {
		return this.internalProductAccountName;
	}

	/**
	 * @param internalProductAccountName
	 *            to internalProductAccountName set.
	 */
	public void setInternalProductAccountName(String internalProductAccountName) {
		this.internalProductAccountName = internalProductAccountName;
	}

	/**
	 * Getter method for federalTaxId. FEDERAL_TAX_ID mapped to FEDERAL_TAX_ID
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "FEDERAL_TAX_ID", length = 100)
	public String getFederalTaxId() {
		return this.federalTaxId;
	}

	/**
	 * @param federalTaxId
	 *            to federalTaxId set
	 */
	public void setFederalTaxId(String federalTaxId) {
		this.federalTaxId = federalTaxId;
	}

	/**
	 * Getter method for tsp. TSP mapped to TSP in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "TSP", length = 100)
	public Character getTsp() {
		return this.tsp;
	}

	/**
	 * @param tsp
	 *            to tsp set.
	 */
	public void setTsp(Character tsp) {
		this.tsp = tsp;
	}

	/**
	 * Getter method for feeWaiverApproved. FEE_WAIVER_APPROVED mapped to
	 * FEE_WAIVER_APPROVED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FEE_WAIVER_APPROVED", length = 100)
	public Character getFeeWaiverApproved() {
		return this.feeWaiverApproved;
	}

	/**
	 * @param feeWaiverApproved
	 *            to feeWaiverApproved set.
	 */
	public void setFeeWaiverApproved(Character feeWaiverApproved) {
		this.feeWaiverApproved = feeWaiverApproved;
	}

	/**
	 * Getter method for waiverNotes. WAIVER_NOTES mapped to WAIVER_NOTES in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_NOTES", length = 2000)
	public String getWaiverNotes() {
		return this.waiverNotes;
	}

	/**
	 * @param waiverNotes
	 *            to waiverNotes set.
	 */
	public void setWaiverNotes(String waiverNotes) {
		this.waiverNotes = waiverNotes;
	}

	/**
	 * Getter method for waiverAttachment. WAIVER_ATTACHMENT mapped to
	 * WAIVER_ATTACHMENT in the database table.
	 * 
	 * @return Blob
	 */
	@Column(name = "WAIVER_ATTACHMENT")
	public Blob getWaiverAttachment() {
		return this.waiverAttachment;
	}

	/**
	 * @param waiverAttachment
	 *            to waiverAttachment set.
	 */
	public void setWaiverAttachment(Blob waiverAttachment) {
		this.waiverAttachment = waiverAttachment;
	}

	/**
	 * Getter method for createdBy. CREATED_BY mapped to CREATED_BY in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "CREATED_BY", length = 100)
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 *            to createdBy set.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON")
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn
	 *            to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedBy. UPDATED_BY mapped to UPDATED_BY in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "UPDATED_BY", length = 100)
	public String getUpdatedBy() {
		return this.updatedBy;
	}

	/**
	 * @param updatedBy
	 *            to updatedBy set.
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn
	 *            to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for active. ACTIVE mapped to ACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ACTIVE", nullable = false, length = 1)
	public Character getActive() {
		return this.active;
	}

	/**
	 * @param active
	 *            to active set.
	 */
	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for waiverAttachmentFilename. WAIVER_ATTACHMENT_FILENAME
	 * mapped to WAIVER_ATTACHMENT_FILENAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_ATTACHMENT_FILENAME", length = 100)
	public String getWaiverAttachmentFilename() {
		return this.waiverAttachmentFilename;
	}

	/**
	 * @param waiverAttachmentFilename
	 *            to waiverAttachmentFilename set.
	 */
	public void setWaiverAttachmentFilename(String waiverAttachmentFilename) {
		this.waiverAttachmentFilename = waiverAttachmentFilename;
	}

	/**
	 * Getter method for orderses.
	 * 
	 * @return Set<Orders>
	 */
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "internalProductAccount")
//	public Set<Orders> getOrderses() {
//		return this.orderses;
//	}
//
//	/**
//	 * @param orderses
//	 *            to orderses set.
//	 */
//	public void setOrderses(Set<Orders> orderses) {
//		this.orderses = orderses;
//	}

	/**
	 * Getter method for vpns.
	 * 
	 * @return Set<Vpn>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "internalProductAccount")
	public Set<Vpn> getVpns() {
		return this.vpns;
	}

	/**
	 * @param vpns
	 *            to vpns set.
	 */
	public void setVpns(Set<Vpn> vpns) {
		this.vpns = vpns;
	}
	
}
