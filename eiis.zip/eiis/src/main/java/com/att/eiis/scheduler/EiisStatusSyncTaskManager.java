package com.att.eiis.scheduler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.bean.RequestBO;
import com.att.eiis.email.EmailUtils;
import com.att.eiis.request.StatusRequest;
import com.att.eiis.threadpool.EiisDetailsExceptionHandler;
import com.att.eiis.threadpool.EiisThreadPoolManager;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.RequestType;
import com.att.eiis.util.TaskStatus;

/**
 * This is the manager class which actually invoke the threads to sync the 
 * status of the order based on provided request ids. Once execution is done 
 * this class also responsible to notify the COMET application for 
 * further processing.
 */
@Component
public class EiisStatusSyncTaskManager {

	private ConcurrentHashMap<String, String> statussHashMap = null;
	private static EiisStatusSyncTaskManager statusTaskManager = null;
	private static Logger logger = LoggerFactory.getLogger(EiisStatusSyncTaskManager.class);

	private EiisStatusSyncTaskManager() {
		logger.info("Initializing hash map.");
		statussHashMap = new ConcurrentHashMap<String, String>();
	}

	/**
	 * Singleton instance 
	 * @return instance
	 */
	public static EiisStatusSyncTaskManager getInstance() {
		logger.debug("Initializing instance.");
		if (statusTaskManager == null) {
			synchronized(EiisStatusSyncTaskManager.class) {
				if (statusTaskManager == null) {
					statusTaskManager = new EiisStatusSyncTaskManager();
					logger.info("Instance initialized.");
				}
			}
		}
		logger.debug("Returning initialized instance.");
		return statusTaskManager;
	}

	/**
	 * Adding / updating mappings in this map is responsibility of 
	 * each thread / job invoked by this manager
	 * 
	 * [{ "requestId1" : "Success" }, { "requestId2" : "Failure" }]
	 * @param requestId - request id
	 * @param requestStatus - task status
	 */
	public synchronized void updateStatusMap(String requestId, String requestStatus) {
		logger.debug("Entering updateStatusMap() method.");
		if (statussHashMap.containsKey(requestId)) {
			statussHashMap.replace(requestId, requestStatus);
		} else {
			statussHashMap.put(requestId, requestStatus);
		}
		logger.debug("Exiting updateStatusMap() method.");
	}

	/**
	 * This method is to cleanup the map before each execution of task
	 * kept this method as default so that it doesn't get called 
	 * from outside package
	 */
	void cleanupStatusMap() {
		logger.debug("Entering cleanupStatusMap() method.");
		if (statussHashMap != null) { 
			statussHashMap.clear();
		}
		logger.debug("Exiting cleanupStatusMap() method.");
	}

	/**
	 * Initiates task for given request ids.
	 * @param requestIdList
	 */
	public void initiateTaskForGivenIds(List<String> requestIdList) {
		logger.debug("Entering initiateTaskForGivenIds() method.");
		if (requestIdList != null && requestIdList.size() > 0) {

			logger.debug("Got " + requestIdList.size() + " records of request ids.");
			
			for (String requestId : requestIdList) {
				logger.debug("Invoking thread for request id : " + requestId);
				RequestBO reqObject = new RequestBO();
				reqObject.setRid(requestId);
				StatusRequest statusRequest = new StatusRequest(reqObject);
				EiisDetailsExceptionHandler exceptionHandler = new EiisDetailsExceptionHandler();
				statusRequest.setUncaughtExceptionHandler(exceptionHandler);
	
				try {
					EiisThreadPoolManager.invokeThread(statusRequest);
					logger.debug("Thread for request id : " + requestId + " executed successfully.");
				} catch (Exception e) {
					logger.error("Error while invoking thread for request id : " + requestId, e);
					throw new RuntimeException(e);
				}
			}
	
			List<String> failedRequests = null;
			while (true) {
				if (statussHashMap.size() >= requestIdList.size()) {
					logger.debug("Creating list of request ids for failed execution.");
					Set<Entry<String, String>> entrySet = statussHashMap.entrySet();
					for (Entry<String, String> entry : entrySet) {
						if (TaskStatus.Failure.name().equals(entry.getValue())) {
							if (failedRequests == null) {
								failedRequests = new ArrayList<String>();
							}
							failedRequests.add(entry.getKey());
							logger.debug("AMP request failed for request id : " + entry.getKey());
						} else {
							//logging for failed requests
							logger.warn("AMP request was successful for request id : " + entry.getKey());
						}
					}
					break;
				} else {
					//wait for some time for map to get updated for all the requests
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						logger.warn("Error in waiting for thread.");
					}
				}
			}

			//Gives the call to the REST service exposed by COMET
			if (failedRequests != null && failedRequests.size() > 0) {
				logger.debug("Notifiying to COMET support for failed execution of : " + failedRequests.size() + " request ids.");
				this.notifyCometSupport(failedRequests);
				logger.debug("Notified to COMET support for failed execution of request ids.");
			}
		}
		logger.debug("Exiting initiateTaskForGivenIds() method.");
	}

	/**
	 * Send email to COMET support for failed requests
	 * @param failedRequest
	 */
	private void notifyCometSupport(List<String> failedRequest) {
		logger.debug("Entering notifyCometSupport() method.");
		List<String> failedOrders = DatabaseUtil.getOrderIdForRequestId(failedRequest);
		EmailUtils.sendDynamicllyCreatedEmail(3L, failedOrders, RequestType.StatusBySystem);
		logger.debug("Exiting notifyCometSupport() method.");
	}
}