package com.att.eiis.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.dao.EiisDAO;

@Component
public class AmpSimpleClientHttpRequestFactory extends SimpleClientHttpRequestFactory {
	private static SSLSocketFactory sslSocketFactory = null;
	
	 @Override
	    protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
	        if(connection instanceof HttpsURLConnection ){
	        	((HttpsURLConnection) connection).setSSLSocketFactory( cert("amp.use.certificate.server").getSocketFactory());
	        	((HttpsURLConnection) connection).setHostnameVerifier(ALL_TRUSTING_HOSTNAME_VERIFIER);
				 /*setAcceptAllVerifier((HttpsURLConnection)httpConnection);*/
	        	((HttpsURLConnection) connection).setRequestMethod("POST");
	        }
	        super.prepareConnection(connection, httpMethod);
	    }
	
	
	protected static void setAcceptAllVerifier(HttpsURLConnection connection) throws NoSuchAlgorithmException, KeyManagementException {

        // Create the socket factory.
        // Reusing the same socket factory allows sockets to be
        // reused, supporting persistent connections.
        if( null == sslSocketFactory) {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, ALL_TRUSTING_TRUST_MANAGER, new java.security.SecureRandom());
            sslSocketFactory = sc.getSocketFactory();
        }

        connection.setSSLSocketFactory(sslSocketFactory);

        // Since we may be using a cert with a different name, we need to ignore
        // the hostname as well.
        connection.setHostnameVerifier(ALL_TRUSTING_HOSTNAME_VERIFIER);
    }

    private static final TrustManager[] ALL_TRUSTING_TRUST_MANAGER = new TrustManager[] {
        new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
        }
    };

    public static final HostnameVerifier ALL_TRUSTING_HOSTNAME_VERIFIER  = new HostnameVerifier() {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    };
    
    public static SSLContext cert(String certificateName) {
    	SSLContext sslContext =null;
    	//CERTIFICATE
    	Properties props = DatabaseUtil.getEiisConfigProperties("CERTIFICATE");
    	String CERTIFICATE = props.getProperty(certificateName);
    	
         try {
        	 ByteArrayInputStream derInputStream = new ByteArrayInputStream(CERTIFICATE.getBytes());
             CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
             X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(derInputStream);
             String alias = "alias";//cert.getSubjectX500Principal().getName();
             
             KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
			 trustStore.load(null);
			 trustStore.setCertificateEntry(alias, cert);
	         final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	         kmf.init(trustStore, null);
	         KeyManager[] keyManagers = kmf.getKeyManagers();
	         
	         TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
	         tmf.init(trustStore);
	         TrustManager[] trustManagers = tmf.getTrustManagers();
	         
//	         sslContext = SSLContext.getInstance("TLS");
	         sslContext = SSLContext.getInstance("TLSv1.2");
	         sslContext.init(keyManagers, trustManagers, null);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			e.printStackTrace();
		}
         
         return sslContext;
    }
}
