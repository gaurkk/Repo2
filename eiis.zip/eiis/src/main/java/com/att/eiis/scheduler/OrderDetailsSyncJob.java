package com.att.eiis.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.util.DatabaseUtil;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


/**
 * This job will perform following tasks:
 * 1) Fetch the details of job qualified for data sync
 * 2) Invoke the manager to sync status by providing details. 
 */
@Component
public class OrderDetailsSyncJob implements Job {

	private static Logger logger = LoggerFactory.getLogger(OrderDetailsSyncJob.class);

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		logger.info("Starting method execute in OrderDetailsSyncJob : ", this);
		
		List<String> applicableRequestIds = getRequstIdListForDetails();
		if (applicableRequestIds != null && !applicableRequestIds.isEmpty()) {
			
			logger.debug("Got : " + applicableRequestIds.size() + " records of request ids.");
			this.executeSyncTask(applicableRequestIds);
		} else {
			logger.debug("No data found for syncing of order details.");
		}
		logger.info("Exiting method execute : ", this);
	}

	protected void executeSyncTask(List<String> applicableRequestIds) {
		logger.info("Starting executeSyncTask() method :",this);
		
		EiisDetailsSyncTaskManager manager = EiisDetailsSyncTaskManager.getInstance();
		manager.cleanupDetailsMap();
		manager.initiateTaskForGivenIds(applicableRequestIds);
		
		logger.debug("Exiting executeSyncTask() method.");
	}

	/**
	 * Database call to fetch list of all applicable request ids for which 
	 * status is complete and data sync is remaining
	 *  
	 * @return list of request ids
	 */
	private List<String> getRequstIdListForDetails() {
		logger.debug("Starting getRequstIdListForDetails() method.");
		
		List<String> requestIds = DatabaseUtil.getApplicableRequestIdsForDetailsSync();
		logger.debug("Exiting getRequstIdListForDetails() method with : " + (requestIds != null ? requestIds.size() : 0) + " results.");
		return requestIds;
	}
}