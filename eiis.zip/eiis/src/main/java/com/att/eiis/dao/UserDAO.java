package com.att.eiis.dao;

import com.att.eiis.dao.hibernate.bean.Users;

public interface UserDAO extends GenericEiisDAO {

	/**
	 * Return Users object if user exists with specified attuid
	 * 
	 * @param attuid 
	 * @return Users 
	 * @throws
	 */
	public Users findByUserAttId(String attuid) ;

}
