package com.att.eiis.util;

/**
 * This enum have value of all the REST request types. 
 * For status & details request types there are 2 different approaches so 2 different request types are mentioned. 
 */
public enum RequestType {

	Create, Status, StatusBySystem, Details, DetailsBySystem, Cancel, Login, NotifyComet;
}
