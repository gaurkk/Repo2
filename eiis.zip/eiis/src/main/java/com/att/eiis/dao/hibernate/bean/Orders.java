package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Orders. Mapped to ORDERS table in the database.
 */
@Entity
@Table(name = "ORDERS")
public class Orders implements Serializable {

	private static final long serialVersionUID = 1776647983510711028L;
	private Long orderId;
	private OrderStatus orderStatus;
	private Long numDataCenters;
	private String apnSelection;
	private String backhaulSelection;
	private Date createdOn;
	private Date submittedOn;
	private Date updatedOn;
	private Long derivedFromOrder;
	@Lob
	private byte[] recoveryFlowChart;
	private String recoveryFlowChartFilename;
	private Apn apn;
	private Character expedite;
	private Character exceptional;
	private Character baseOrder;
	private String baseOrderNotes;
	private String comments;
	private Character changeRequest;
	private String customerPrefDCComments;
	private String lteSweep;
	private Character cancelRequest;
	private Character crFlag;
	@Lob
	private byte[] ipSecLetterAttachment;
	private String ipSecLetterAttachmentName;
	private Date dateInProduction;
	private Character firstNetEpc;


	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * The sequence used to generate the orderId is SEQ_ORDER_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_ORDER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_ID")
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orderStatus.
	 * 
	 * @return OrderStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_STATUS_ID", nullable = false)
	public OrderStatus getOrderStatus() {
		return this.orderStatus;
	}

	/**
	 * @param orderStatus to orderStatus set.
	 */
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * Getter method for numDataCenters. NUM_DATA_CENTERS mapped to NUM_DATA_CENTERS
	 * in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "NUM_DATA_CENTERS", precision = 2, scale = 0)
	public Long getNumDataCenters() {
		return this.numDataCenters;
	}

	/**
	 * @param numDataCenters to numDataCenters set.
	 */
	public void setNumDataCenters(Long numDataCenters) {
		this.numDataCenters = numDataCenters;
	}

	/**
	 * Getter method for baseOrder. BASE_ORDER mapped to BASE_ORDER in the database
	 * table.
	 * 
	 * @return Character
	 */
	@Column(name = "BASE_ORDER", length = 1)
	public Character getBaseOrder() {
		return baseOrder;
	}

	/**
	 * @param baseOrder to baseOrder set.
	 */
	public void setBaseOrder(Character baseOrder) {
		this.baseOrder = baseOrder;
	}

	/**
	 * Getter method for recoveryFlowChartFilename. RECOVERY_FLOW_CHART_FILENAME
	 * mapped to RECOVERY_FLOW_CHART_FILENAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "RECOVERY_FLOW_CHART_FILENAME", length = 100)
	public String getRecoveryFlowChartFilename() {
		return recoveryFlowChartFilename;
	}

	/**
	 * @param recoveryFlowChartFilename to recoveryFlowChartFilename set.
	 */
	public void setRecoveryFlowChartFilename(String recoveryFlowChartFilename) {
		this.recoveryFlowChartFilename = recoveryFlowChartFilename;
	}

	/**
	 * Getter method for recoveryFlowChart. RECOVERY_FLOW_CHART mapped to
	 * RECOVERY_FLOW_CHART in the database table.
	 * 
	 * @return Blob
	 */
	@Column(name = "RECOVERY_FLOW_CHART", length = 100)
	public byte[] getRecoveryFlowChart() {
		return recoveryFlowChart;
	}

	/**
	 * @param recoveryFlowChart to recoveryFlowChart set.
	 */
	public void setRecoveryFlowChart(byte[] recoveryFlowChart) {
		this.recoveryFlowChart = recoveryFlowChart;
	}

	/**
	 * Getter method for ipSecLetterAttachmentName. IP_SEC_LETTER_FILENAME mapped to
	 * IP_SEC_LETTER_FILENAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_SEC_LETTER_FILENAME", length = 100)
	public String getIpSecLetterAttachmentName() {
		return ipSecLetterAttachmentName;
	}

	/**
	 * @param ipSecLetterAttachmentName to ipSecLetterAttachmentName set.
	 */
	public void setIpSecLetterAttachmentName(String ipSecLetterAttachmentName) {
		this.ipSecLetterAttachmentName = ipSecLetterAttachmentName;
	}

	/**
	 * Getter method for recoveryFlowChart. IP_SEC_LETTER mapped to IP_SEC_LETTER in
	 * the database table.
	 * 
	 * @return Blob
	 */
	@Column(name = "IP_SEC_LETTER", length = 100)
	public byte[] getIpSecLetterAttachment() {
		return ipSecLetterAttachment;
	}

	/**
	 * @param ipSecLetterAttachment to ipSecLetterAttachment set.
	 */
	public void setIpSecLetterAttachment(byte[] ipSecLetterAttachment) {
		this.ipSecLetterAttachment = ipSecLetterAttachment;
	}

	/**
	 * Getter method for derivedFromOrder. DERIVED_FROM_ORDER mapped to
	 * DERIVED_FROM_ORDER in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "DERIVED_FROM_ORDER", precision = 12, scale = 0)
	public Long getDerivedFromOrder() {
		return derivedFromOrder;
	}

	/**
	 * @param derivedFromOrder to derivedFromOrder set.
	 */
	public void setDerivedFromOrder(Long derivedFromOrder) {
		this.derivedFromOrder = derivedFromOrder;
	}

	/**
	 * Getter method for changeRequest. CHANGE_REQUEST mapped to CHANGE_REQUEST in
	 * the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "CHANGE_REQUEST", length = 1)
	public Character getChangeRequest() {
		return changeRequest;
	}

	/**
	 * @param changeRequest to changeRequest set.
	 */
	public void setChangeRequest(Character changeRequest) {
		this.changeRequest = changeRequest;
	}

	/**
	 * Getter method for apnSelection. APN_SELECTION mapped to APN_SELECTION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "APN_SELECTION", length = 20)
	public String getApnSelection() {
		return this.apnSelection;
	}

	/**
	 * @param apnSelection to apnSelection set.
	 */
	public void setApnSelection(String apnSelection) {
		this.apnSelection = apnSelection;
	}

	/**
	 * Getter method for backhaulSelection. BACKHAUL_SELECTION mapped to
	 * BACKHAUL_SELECTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BACKHAUL_SELECTION", length = 20)
	public String getBackhaulSelection() {
		return this.backhaulSelection;
	}

	/**
	 * @param backhaulSelection to backhaulSelection set.
	 */
	public void setBackhaulSelection(String backhaulSelection) {
		this.backhaulSelection = backhaulSelection;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON")
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	
	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	

	/**
	 * Getter method for submittedOn. SUBMITTED_ON mapped to SUBMITTED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "SUBMITTED_ON")
	public Date getSubmittedOn() {
		return submittedOn;
	}

	/**
	 * @param submittedOn to submittedOn set.
	 */
	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}

	

	/**
	 * Getter method for expedite. EXPEDITE mapped to EXPEDITE in the database
	 * table.
	 * 
	 * @return Character
	 */
	@Column(name = "EXPEDITE", length = 1)
	public Character getExpedite() {
		return this.expedite;
	}

	/**
	 * @param expedite to expedite set.
	 */
	public void setExpedite(Character expedite) {
		this.expedite = expedite;
	}

	/**
	 * Getter method for exceptional. EXCEPTIONAL mapped to EXCEPTIONAL in the
	 * database table.
	 * 
	 * @return Character
	 */
	@Column(name = "EXCEPTIONAL", length = 1)
	public Character getExceptional() {
		return exceptional;
	}

	/**
	 * @param exceptional to exceptional set.
	 */
	public void setExceptional(Character exceptional) {
		this.exceptional = exceptional;
	}

	/**
	 * Getter method for baseOrderNotes. BASE_ORDER_NOTES mapped to BASE_ORDER_NOTES
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BASE_ORDER_NOTES", length = 3500)
	public String getBaseOrderNotes() {
		return baseOrderNotes;
	}

	/**
	 * @param baseOrderNotes to baseOrderNotes set.
	 */
	public void setBaseOrderNotes(String baseOrderNotes) {
		this.baseOrderNotes = baseOrderNotes;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * 
	 * @return String
	 */
	@Column(name = "CUS_PREF_DC_COMMENTS", length = 3500)
	public String getCustomerPrefDCComments() {
		return customerPrefDCComments;
	}

	/**
	 * 
	 * @param customerPrefDCComments
	 */
	public void setCustomerPrefDCComments(String customerPrefDCComments) {
		this.customerPrefDCComments = customerPrefDCComments;
	}

	/**
	 * @return the lteSweep
	 */
	@Column(name = "LTE_SWEEP", length = 100)
	public String getLteSweep() {
		return lteSweep;
	}

	/**
	 * @param lteSweep the lteSweep to set
	 */
	public void setLteSweep(String lteSweep) {
		this.lteSweep = lteSweep;
	}

	/**
	 * @return the cancelRequest
	 */
	@Column(name = "CANCEL_ORDER", length = 1)
	public Character getCancelRequest() {
		return cancelRequest;
	}

	/**
	 * @param cancelRequest the cancelRequest to set
	 */
	public void setCancelRequest(Character cancelRequest) {
		this.cancelRequest = cancelRequest;
	}

	/**
	 * @return the crFlag
	 */
	@Column(name = "CR_FLAG", length = 1)
	public Character getCrFlag() {
		return crFlag;
	}

	/**
	 * @param crFlag the crFlag to set
	 */
	public void setCrFlag(Character crFlag) {
		this.crFlag = crFlag;
	}

	/**
	 * Getter for Date when order went to production
	 * 
	 * @return dateInProduction
	 */
	@Column(name = "DATE_IN_PRODUCTION")
	public Date getDateInProduction() {
		return dateInProduction;
	}

	/**
	 * Setter for Date when order went to production
	 * 
	 * @param dateInProduction
	 */
	public void setDateInProduction(Date dateInProduction) {
		this.dateInProduction = dateInProduction;
	}

	@Column(name = "FIRSTNET_EPC", length = 1)
	public Character getFirstNetEpc() {
		return firstNetEpc;
	}

	public void setFirstNetEpc(Character firstNetEpc) {
		this.firstNetEpc = firstNetEpc;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", createdBy=" + ", internalProductAccount="
				+ ", orderStatus=" + orderStatus + ", updatedBy=" + ", subAccount="
				+ ", orderType=" + ", numDataCenters=" + numDataCenters + ", apnSelection="
				+ apnSelection + ", backhaulSelection=" + backhaulSelection + ", createdOn=" + createdOn
				+ ", submittedOn=" + submittedOn + ", updatedOn=" + updatedOn + ", derivedFromOrder=" + derivedFromOrder
				+ ", recoveryFlowChart=" + recoveryFlowChart + ", recoveryFlowChartFilename="
				+ recoveryFlowChartFilename + ", orderStatusHistories=" 
				+ ", orderDataCenterBackhauls=" +  ", orderDataCenters="
				+ ", apn=" + apn + ", orderAccount=" +  ", orderContact=" +  ", vpns="
				+  ", orderExpedite=" + ", expedite=" + expedite + ", exceptional=" + exceptional
				+ ", baseOrder=" + baseOrder + ", baseOrderNotes=" + baseOrderNotes + ", comments=" + comments
				+ ", changeRequest=" + changeRequest + ", orderInitiator=" 
				+ ", customerPrefDCComments=" + customerPrefDCComments + ", lteSweep=" + lteSweep + ", cancelRequest="
				+ cancelRequest + ", crFlag=" + crFlag + ", ipSecLetterAttachment=" + ipSecLetterAttachment
				+ ", ipSecLetterAttachmentName=" + ipSecLetterAttachmentName + ", dateInProduction=" + dateInProduction
				+ ", orderFlagsDetails=" +  ", infraGiInformation=" 
				+ ", extIntDetails=" +  ", firstNetEpc=" + firstNetEpc + "]";
	}
}