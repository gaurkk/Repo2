package com.att.eiis.threadpool;

import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.util.DatabaseUtil;


/**
 * This class is responsible to manage the thread pool by initializing, shutting down and 
 * invoking the thread of the thread pool.
 * This class initializes the thread pool at the server startup and 
 * shuts down at the time of server shut down.  
 */
public class EiisThreadPoolManager {

	private static ThreadPoolExecutor executor = null;
	private static Logger logger = LoggerFactory.getLogger(EiisThreadPoolManager.class);

	/**
	 * Call this method from startup listener.
	 */
	public static void initializeThreadPool() {
		logger.debug("Starting initializeThreadPool() method.");
		
		Properties props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG");
		String threadPoolSize = props.getProperty("eiis.thread.core.pool.size");
		int corePoolSize = 1;
		if (threadPoolSize != null && !threadPoolSize.isEmpty())
			corePoolSize = Integer.valueOf(threadPoolSize.trim());
		int maximumPoolSize = 5;
		String maxThreadPoolSize = props.getProperty("eiis.thread.maximum.pool.size");
		if (maxThreadPoolSize != null && !maxThreadPoolSize.isEmpty())
			maximumPoolSize = Integer.valueOf(maxThreadPoolSize.trim());
		
		// when the number of threads is greater than the core, this is the maximum time 
		// that excess idle threads will wait for new tasks before terminating.
		
		long keepAliveTime = 0;
		String keepAliveTimeInSeconds = props.getProperty("eiis.thread.keep.alive.time.in.seconds");
		if (keepAliveTimeInSeconds != null && !keepAliveTimeInSeconds.isEmpty())
			keepAliveTime = Long.valueOf(keepAliveTimeInSeconds.trim());
		TimeUnit timeUnit = TimeUnit.SECONDS;
		
		logger.debug("corePoolSize : " + corePoolSize + ", maximumPoolSize : " + maximumPoolSize 
				+ ", keepAliveTime : " + keepAliveTime + ", timeUnit : " + timeUnit);

		BlockingQueue<Runnable> linkedBlockingQueue = new LinkedBlockingQueue<Runnable>(maximumPoolSize);
		EiisRejectedExecutionHandler rejectedHandler = new EiisRejectedExecutionHandler();

		executor = new EiisThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, timeUnit, 
				linkedBlockingQueue, Executors.defaultThreadFactory(), rejectedHandler);
		
		logger.debug("Exiting initializeThreadPool() method.");
	}

	/**
	 * Using this method one can invoke the job / task 
	 * using thread from the pool.
	 * @param thread task / job to be executed.
	 */
	public static void invokeThread(Runnable thread) {
		logger.debug("Starting invokeThread() method. ");
		
		executor.execute(thread);
		logger.debug("Exiting invokeThread() method.");
	}

	/**
	 * Call this method at the time of server shutdown
	 */
	public static void shutdownThreadPool() {
		logger.debug("Starting shutdownThreadPool() method.");
		
		executor.shutdown();
		while (!executor.isTerminated()) {
		}
		logger.debug("Exiting shutdownThreadPool() method.");
	}
}

