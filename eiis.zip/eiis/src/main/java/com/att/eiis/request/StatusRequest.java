package com.att.eiis.request;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.simple.JSONObject;

import com.att.eiis.amp.AmpRequestClient;
import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.EiisServerUtil;
import com.att.eiis.util.RequestType;

import springfox.documentation.spring.web.json.Json;

/**
 * Thread to invoke the status request. 
 */
public class StatusRequest extends AmpRequest {
	private static Logger logger = LoggerFactory.getLogger(StatusRequest.class);
	
	private RequestBO reqObject= new RequestBO();
	private AmpRequestClient ampRequestClient;
	private EiisServerUtil eiisServerUtil;

	public StatusRequest(RequestBO reqObject) {
		this.reqObject = reqObject;
		logger.debug("Initialized status thread for Request Id : " + reqObject.getRid());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		logger.debug("Starting StatusRequest.run() method.");
		
		AmpResponseBO ampResponseBO = new AmpResponseBO();
		Exception exception = null;
		int counter = 0;
		String token = null;
		String httpCode = null;
		JSONObject requestJson ;
		eiisServerUtil = new EiisServerUtil();
		ampResponseBO = eiisServerUtil.checkAmpMaintance();
		if(null != ampResponseBO){
			ampResponseBO.setHTTP_CODE("400");
			ampResponseBO.setErrorCode("400");
			exception = new Exception();
		}else{
			for(int serverNo = 1 ; serverNo <= serverCount ; serverNo++){
				do {
					logger.debug("Executing status sync attempt # " + (counter + 1) + " for request id : " + this.reqObject.getRid());
					if (counter > 0) {
						try {
							Thread.sleep(waitForTimeInMillies);
						} catch (Exception e) {
							logger.warn("Error in waiting of status thread for Request Id : " + reqObject.getRid(), e);
						}
					}
					counter ++;
					exception = null;
					try {
						eiisServerUtil = new EiisServerUtil();
						ampResponseBO = eiisServerUtil.getToken("",reqObject.getRid(),serverNo);
						token = ampResponseBO.getToken();
						if(token == null || token.equalsIgnoreCase("")){
							ampResponseBO.setHTTP_CODE("501");
							ampResponseBO.setErrorCode("501");
							ampResponseBO.setMessage("Authentication Failed");
							ampResponseBO.setJsonResponse("Authentication Failed:Get login token failed");
							throw new Exception();
						}else{
							ampRequestClient = new AmpRequestClient();
							ampResponseBO= ampRequestClient.status(token, this.reqObject,serverNo);
							if(ampResponseBO.getHTTP_CODE() == "0"){
								throw new Exception();
							}
						}
					} catch (Exception e) {
						logger.error("Error in status thread for Request Id : " + reqObject.getRid(), e);
						exception = e;
					}
				} while (counter < retryCount && exception != null);
			}
		}
		if (exception != null) {
			logger.error("Error is not got resolved re-throwing exception.");
			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			requestJson = new JSONObject();
			requestJson.put("rid",this.reqObject.getRid());
			logger.error("Re-throwing exception while fetching status of order : " + reqObject.getRid() + ".");
			
			DatabaseUtil.insertEventLogs(reqObject.getRid(), requestJson.toString(), ampResponseBO.getMessage()+ampResponseBO.getJsonResponse(), 1002,httpCode,"EIIS");
			throw new RuntimeException(exception);
		}else{
			httpCode = ampResponseBO.getHTTP_CODE() != null?ampResponseBO.getHTTP_CODE():"500";
			requestJson = new JSONObject();
			requestJson.put("rid",reqObject.getRid());
			
			DatabaseUtil.insertEventLogs(reqObject.getRid(), requestJson.toString(), ampResponseBO.getJsonResponse().toString(), 1002,httpCode,"EIIS");
			
			DatabaseUtil.updateEventStatus(reqObject.getRid());
		}
		logger.debug("Exiting run() method.");
	}

	@Override
	public String getRequestId() {
		return this.reqObject.getRid();
	}

	@Override
	public String getRequestType() {
		return RequestType.StatusBySystem.name();
	}
}