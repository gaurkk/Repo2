package com.att.eiis.threadpool;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is implemented to create new thread for thread pool. 
 */
public class EiisThreadFactory implements ThreadFactory {

	private static AtomicInteger counter = new AtomicInteger();
	private static Logger logger = LoggerFactory.getLogger(EiisThreadFactory.class);
	
	public Thread newThread(Runnable runnable) {
		int currentCount = counter.getAndIncrement();
		logger.debug("Creating new thread : " + currentCount);
		return new Thread(runnable, "mythread -> " + currentCount);
	}
}
