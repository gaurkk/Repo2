package com.att.eiis.util;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

import com.att.eiis.constants.EiisCommonConstants;


public class JDBCUtil {

	private static Logger logger = LoggerFactory.getLogger(JDBCUtil.class);
	private static DataSource dataSource = null;

	static {
		logger.info("Initializing data source property.");
		logger.info("System.getProperty..........."+System.getProperty("javax.persistence.jdbc.url"));
		
		dataSource = getDataSourceUtil(System.getProperty(EiisCommonConstants.DB_URL), System.getProperty(EiisCommonConstants.DB_USER), 
				System.getProperty(EiisCommonConstants.DB_PASSWD), "oracle.jdbc.OracleDriver","jdbc/cometDS");
		/*dataSource = getDataSourceUtil("jdbc:oracle:thin:@d7com1d1.az.3pc.att.com:1521:d7com1d1", 
				"ccs_uat", 
				"oracle123", 
				"oracle.jdbc.OracleDriver", "");*/
		logger.info("Datasource property " + (dataSource != null ? "initialized successfully." : "could not initialized."));
		
	}

	public static DataSource getDataSource() {
		return dataSource;
	}
	
	private static DataSource getDataSourceUtil(String url, String userName, String password, 
			String driverName, String jndiName) {
		logger.debug("Entering getDataSourceUtil() method with arguments : " + url + ", " 
				+ userName + ", ********, " + driverName + ", " + jndiName); 
		try {
			if (jndiName != null && !jndiName.isEmpty()) {
				JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
				dataSourceLookup.setResourceRef(true);
				DataSource dataSource = dataSourceLookup.getDataSource(jndiName);
				logger.info("JNDI data source initialized successfully.");
				return dataSource;
			} else {
				BasicDataSource basicDS = new BasicDataSource();
				basicDS.setDriverClassName(driverName);
				basicDS.setUrl(url);
				basicDS.setUsername(userName);
				basicDS.setPassword(password);
				basicDS.setMinIdle(5);
				basicDS.setMaxIdle(10);
				basicDS.setMaxOpenPreparedStatements(100);
				return basicDS;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("There is some error in initializing data source.", e);
			return null;
		}
	}
}