package com.att.eiis.email;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.LoggerFactory;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.slf4j.Logger;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

import com.att.eiis.constants.EiisCommonConstants;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.RequestType;

@Component
public class EmailUtils {
	private static Logger logger = LoggerFactory.getLogger(EmailUtils.class);
	private static Properties globalProperties = null;

	static {
		globalProperties = DatabaseUtil.getEiisConfigProperties("EMAIL_CONFIG");
	}

	public static void sendEmail(EmailData emailData) {
		logger.debug("Starting method sendEmail() with data : "+ emailData.toString());
		
		Properties properties = new Properties();
		properties.setProperty("mail.smtp.host",globalProperties.getProperty("emailHost"));
		Session session = Session.getDefaultInstance(properties);

		switch (emailData.getMessageType()) {
		case MIMEMESSAGE:
			MimeMessage mimeMessage = new MimeMessage(session);
			try {
				mimeMessage.setFrom(new InternetAddress(emailData.getSender()));
				mimeMessage.setRecipients(Message.RecipientType.TO,
						emailData.getRecipientsTo());
				mimeMessage.setRecipients(Message.RecipientType.CC,
						emailData.getRecipientsCc());
				mimeMessage.setSubject(emailData.getSubject());
				mimeMessage.setContent(getDynamicMessage(emailData),
						"text/html; charset=utf-8");
				Transport.send(mimeMessage);
			} catch (AddressException e) {
				e.printStackTrace();
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			break;

		case SIMPLEMESSAGE:
			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			SimpleMailMessage simpleMessage = new SimpleMailMessage();
			try {
				String ccList = convertInternetAddressToString(emailData
						.getRecipientsCc());
				String toList = convertInternetAddressToString(emailData
						.getRecipientsTo());

				simpleMessage.setTo(toList);
				simpleMessage.setCc(ccList);
				simpleMessage.setSubject(emailData.getSubject());
				simpleMessage.setText(getDynamicMessage(emailData));
				simpleMessage.setFrom(emailData.getSender());
				mailSender.setSession(session);
				mailSender.send(simpleMessage);
				break;
			} catch (AddressException e) {
				e.printStackTrace();
			}
		}
		logger.debug("Exiting method sendEmail().");
	}

	public static void sendDynamicllyCreatedEmail(Long emailTemplateInfoId,String orderId, RequestType requestType) {
		logger.debug("Starting method sendDynamicllyCreatedEmail().");
		
		List<String> orderIdList = new ArrayList<String>();
		orderIdList.add(orderId);
		sendDynamicllyCreatedEmail(emailTemplateInfoId, orderIdList,requestType);
		
		logger.debug("Exiting method sendDynamicllyCreatedEmail().");
	}

	public static void sendDynamicllyCreatedEmail(Long emailTemplateInfoId,List<String> orderIdList, RequestType requestType) {
		logger.debug("Starting method sendDynamicllyCreatedEmail() with template Id : "+ emailTemplateInfoId);
		
		VelocityEngine velocityEngine = new VelocityEngine();
		String fileName = globalProperties.getProperty("templateFileName");
		Properties p = new Properties();
		p.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		p.setProperty("classpath.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		velocityEngine.init(p);
		Template template = velocityEngine.getTemplate("/templates/"+ fileName);
		Map<String, Object> emailInfoMap = DatabaseUtil.fetchEmailTemplateInfo(emailTemplateInfoId);

		try {
			InternetAddress[] toList = getInternetAddressFromString((String) emailInfoMap.get("TO_LIST"));
			InternetAddress[] ccList = getInternetAddressFromString((String) emailInfoMap.get("CC_LIST"));

			/* create context object */
			VelocityContext context = new VelocityContext();
			context.put("message_header",(String) emailInfoMap.get("MESSAGE_HEADER"));
			context.put("message_footer",(String) emailInfoMap.get("MESSAGE_FOOTER"));
			context.put("message", (String) emailInfoMap.get("MESSAGE"));

			/* now render the template into a Writer */
			StringWriter writer = new StringWriter();
			template.merge(context, writer);

			/* use the output in your email body */
			String emailMessage = writer.toString();
			EmailData emailData = new EmailData();
			emailData.setMessageBody(emailMessage);
			emailData.setSubject((String) emailInfoMap.get("SUBJECT"));
			emailData.setSender((String) emailInfoMap.get("FROM_USER"));
			emailData.setRecipientsTo(toList);
			emailData.setRecipientsCc(ccList);
			emailData.setMessageType(EmailData.MessageType.MIMEMESSAGE);
			Map<String, String> configMap = new HashMap<String, String>();
			configMap.put(EiisCommonConstants.ORDER_ID_MAP_KEY, orderIdList.toString());
			if (requestType.name().equalsIgnoreCase(
					RequestType.StatusBySystem.name())) {
				configMap.put(EiisCommonConstants.REQUEST_TYPE_MAP_KEY,
						"Status sync request by scheduler");
			} else if (requestType.name().equalsIgnoreCase(
					RequestType.DetailsBySystem.name())) {
				configMap.put(EiisCommonConstants.REQUEST_TYPE_MAP_KEY,
						"Details sync request by scheduler");
			} else if (requestType.name().equalsIgnoreCase(
					RequestType.NotifyComet.name())) {
				configMap.put(EiisCommonConstants.REQUEST_TYPE_MAP_KEY,
						"Comet to sync order details");
			} else {
				configMap.put(EiisCommonConstants.REQUEST_TYPE_MAP_KEY,
						requestType.name() + " request by user");
			}
			emailData.setConfigMap(configMap);
			sendEmail(emailData);
			logger.debug("Mail sent successfully.");
		} catch (AddressException e) {
			e.printStackTrace();
		}
		
		logger.debug("Exiting method sendDynamicllyCreatedEmail ."); 
	}

	private static String getDynamicMessage(EmailData emailData) {
		logger.debug("Starting method getDynamicMessage ."); 
		
		String staticMesage = emailData.getMessageBody();
		String dynamicMessage = staticMesage.replaceAll(EiisCommonConstants.ORDER_ID_KEY,
				emailData.getConfigMap().get(EiisCommonConstants.ORDER_ID_MAP_KEY));
		dynamicMessage = dynamicMessage.replaceAll(EiisCommonConstants.REQUEST_TYPE_KEY,
				emailData.getConfigMap().get(EiisCommonConstants.REQUEST_TYPE_MAP_KEY));
		
		logger.debug("Exiting method getDynamicMessage ."); 
		return dynamicMessage;
	}

	private static InternetAddress[] getInternetAddressFromString(String internetAddressList) throws AddressException {
		logger.debug("Starting method getInternetAddressFromString ."); 
		
		InternetAddress[] internetAddress = new InternetAddress[0];
		if (internetAddressList != null && !internetAddressList.isEmpty()) {
			String[] addressList = internetAddressList.split(",");
			internetAddress = new InternetAddress[addressList.length];
			int counter = 0;
			for (String address : addressList) {
				internetAddress[counter] = new InternetAddress(address.trim());
				counter++;
			}
		}
		
		logger.debug("Exiting method getInternetAddressFromString ."); 
		return internetAddress;
	}

	private static String convertInternetAddressToString(InternetAddress[] internetAddress) throws AddressException {
		logger.debug("Starting method convertInternetAddressToString ."); 
		
		String emailAddress = "";
		if (internetAddress != null) {
			for (InternetAddress address : internetAddress) {
				emailAddress.concat(address.getAddress() + ",");
			}
		}
		
		logger.debug("Exiting method convertInternetAddressToString ."); 
		return emailAddress;
	}
}