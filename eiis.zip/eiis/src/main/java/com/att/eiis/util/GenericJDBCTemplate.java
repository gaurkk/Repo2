package com.att.eiis.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class GenericJDBCTemplate {

	private static Logger logger = LoggerFactory.getLogger(GenericJDBCTemplate.class);

	public static List<Map<String, Object>> getQueryResult(String sql) throws DataAccessException {
		logger.debug("Entering method getQueryResult().");
		List<Map<String, Object>> objects = new ArrayList<Map<String, Object>>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> map : queryForList) {
			objects.add(map);
		}
		logger.debug("Exiting method queryForList() with list of size : " 
				+ (objects != null ? objects.size() : 0));
		return objects;
	}

	public static <T> T queryForObject(String sqlQuery, Class<T> requiredType) {
		logger.debug("Entering method queryForObject().");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		T result = jdbcTemplate.queryForObject(sqlQuery, requiredType);
		logger.debug("Exiting method queryForObject() with : " 
				+ (result != null ? "valid" : "null") + " result.");
		return result;
	}

	public static <T> T queryForObject(String sqlQuery, Class<T> requiredType,Object... args) {
		logger.debug("Entering method queryForObject().");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		T result = jdbcTemplate.queryForObject(sqlQuery, requiredType, args);
		logger.debug("Exiting method queryForObject() with : " 
				+ (result != null ? "valid" : "null") + " result.");
		return result;
	}
	
	public static <T> List<T> queryForList(String sql, Class<T> elementType, Object... args) {
		logger.debug("Starting method queryForList() .");
		List<T> queryResult = new ArrayList<T>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
			queryResult = jdbcTemplate.queryForList(sql, elementType, args);
		}catch(Exception e) {
			e.printStackTrace();
		}
		logger.debug("Exiting method queryForList() with list of size : "+ (queryResult != null ? queryResult.size() : 0));
		return queryResult;
	}

	public static Map<String, Object> queryForMap(String sql, Object... args) {
		logger.debug("Entering method queryForMap().");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		Map<String, Object> queryResult = jdbcTemplate.queryForMap(sql, args);
		logger.debug("Exiting method queryForMap() with " 
				+ ((queryResult != null && !queryResult.isEmpty()) ? "valid" : "empty") + " map.");
		return queryResult;
	}

	public static List<Map<String, Object>> queryForMapList(String sql, Object... args) {
		logger.debug("Entering method queryForMapList().");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		List<Map<String, Object>> queryResult = jdbcTemplate.queryForList(sql, args);
		logger.debug("Exiting method queryForMapList() with list of size : " 
				+ (queryResult != null ? queryResult.size() : 0));
		return queryResult;
	}

	public static int insertOrUpdate(String sqlQuery, Object[] objArray, Object[] argTypes) {
		logger.debug("Entering method insertOrUpdate().");
		int result = -1;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		if (argTypes != null && argTypes.length > 0) {
			result = jdbcTemplate.update(sqlQuery, objArray, argTypes);
		} else {
			result = jdbcTemplate.update(sqlQuery, objArray);
		}
		logger.debug("Exiting method insertOrUpdate() with result : " + result);
		return result;
	}

	public static int update(String sqlQuery) {
		logger.debug("Entering method update().");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		int result = jdbcTemplate.update(sqlQuery);
		logger.debug("Exiting method update() with result : " + result);
		return result;
	}

	public static SimpleJdbcCall getJDBCCallForFunction(String functionName) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
		jdbcTemplate.setResultsMapCaseInsensitive(true);
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withFunctionName(functionName);
		return simpleJdbcCall;
	}
}