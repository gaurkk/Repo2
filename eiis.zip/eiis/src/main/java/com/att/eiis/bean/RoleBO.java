package com.att.eiis.bean;

import com.att.eiis.bean.CometGenericBO;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Business object for Role.
 */

@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@EqualsAndHashCode(callSuper=true)
public class RoleBO extends CometGenericBO implements Comparable<RoleBO> {

	private static final long serialVersionUID = -4490283901241367125L;

	private long roleId;
	private String roleName;

	@Override
	public int compareTo(RoleBO roleBO) {
		return (int) (this.roleId - roleBO.getRoleId());
	}
}
