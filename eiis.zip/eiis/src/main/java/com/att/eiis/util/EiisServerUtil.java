package com.att.eiis.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.att.eiis.amp.AmpRequestClient;
import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.CspBO;
import com.att.eiis.bean.User;
import com.att.eiis.bean.UserBean;

import springfox.documentation.spring.web.json.Json;


@Service
public class EiisServerUtil {
	private static Logger logger = LoggerFactory.getLogger(EiisServerUtil.class);

	private static UserBean userObject;
	private static boolean isAuthRequired;
	private static CspBO cspObject;
	public static String ampMaintainaceStartDt = "";
	public static String ampMaintainaceEndDt = "";
	AmpRequestClient ampReqclient =null;

	static {
		logger.info("Initializing attributes.");
		Properties props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG");
		String userName = props.getProperty("amp.rest.user.name");
		String password = props.getProperty("amp.rest.user.password");
		String CSPmonitor_id = props.getProperty("amp.rest.sso.cspmonitor.id");
		String CSPmonitor_password = props.getProperty("amp.rest.sso.cspmonitor.password");
		String MechID = props.getProperty("amp.rest.sso.mechid");
		User user = new User(userName, password);
		userObject = new UserBean(user);
		cspObject = new CspBO(CSPmonitor_id, CSPmonitor_password, MechID);
		isAuthRequired = Boolean.valueOf(props.getProperty("amp.rest.auth.required"));
	}

	/**
	 * Returns login token of AMP
	 *  
	 * @return - token
	 */
	public AmpResponseBO getToken(String orderId,String requestId,int serverNo) {
		String token = null;
		AmpResponseBO ampResponseBO = new AmpResponseBO();
		try{
			if(isAuthRequired){
				ampResponseBO = getCspAuthToken(cspObject,orderId,requestId,serverNo);
			}else{
				ampResponseBO = login(userObject,orderId,requestId,serverNo);
				logger.debug("else block Eiisrestserverservice getToken end csp login: received token>>");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return ampResponseBO;
	}

	/**
	 * logins to the AMP
	 * 
	 * @param userObj - credentials to login to AMP
	 * 
	 * @return - login token
	 */
	public AmpResponseBO getCspAuthToken(CspBO userObj,String orderId,String requestId,int serverNo) {
		String token = "";
		AmpResponseBO ampRestResponseBO = new AmpResponseBO();

		try {
			ampReqclient = new AmpRequestClient();
			ampRestResponseBO = ampReqclient.getCspAuthToken(userObj,orderId,requestId,serverNo);
			logger.debug("Http Code  for Auth ... ! "+ ampRestResponseBO.getHTTP_CODE());
			
			if(ampRestResponseBO.getHTTP_CODE().equalsIgnoreCase("200"))
				token = ampRestResponseBO.getToken();
			
		} catch (Exception e) {
			logger.error("Error while EiisRestServerService.getCspAuthToken to login AMP server ");
		}

		return ampRestResponseBO;
	}

	public AmpResponseBO login(UserBean userObj,String orderId,String requestId,int serverNo) {
		logger.debug("Entering login() method.");
		String token = "";
		AmpResponseBO ampRestResponseBO = new AmpResponseBO();

		try {
			ampReqclient = new AmpRequestClient();
			ampRestResponseBO= ampReqclient.login(userObj,orderId,requestId,serverNo);
			//token = ampRestResponseBO.getToken();

		} catch (Exception e) {
			logger.error("Error while login to AMP server for user : " + userObj.getUser().getUsername() + ".");
		}
		logger.debug("Exiting login() method.from service >>" +token);
		return ampRestResponseBO;
	}
	
	public AmpResponseBO checkAmpMaintance() {
		logger.info("Starting methode checkAmpMaintance in DetailsRequest:");
		
		boolean checkAmpTime=false;
		String maintainaceTime =null;
		String ampMaintainaceStartDt = null;
		String ampMaintainaceEndDt = null;
		AmpResponseBO ampResponseBO = null;
		try {
				maintainaceTime = DatabaseUtil.getAMPMaintainceTime();
				if(StringUtils.isNoneBlank(maintainaceTime)) {
					ampResponseBO = new AmpResponseBO();
					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
					ampMaintainaceStartDt = maintainaceTime.replace("@@$$@@","#####").split("#####")[0];
					ampMaintainaceEndDt = maintainaceTime.replace("@@$$@@","#####").split("#####")[1];
					Date startDt  = sdf.parse(ampMaintainaceStartDt);
					Date endDt = sdf.parse(ampMaintainaceEndDt);
					Date currentDate = sdf.parse(sdf.format(new Date()));
					checkAmpTime = ((startDt.compareTo(currentDate) <= 0 && endDt.compareTo(currentDate) >=0));
					if(checkAmpTime) {
						ampResponseBO.setMessage("Currently AMP maintenance is in progress from "+ ampMaintainaceStartDt +" To "+ ampMaintainaceEndDt);
						ampResponseBO.setJsonResponse("Currently AMP maintenance is in progress from "+ ampMaintainaceStartDt +" To "+ ampMaintainaceEndDt);
					}
				}
		}catch(Exception e) {
			checkAmpTime=false;
			e.printStackTrace();
		}
		
		logger.info("Exiting methode checkAmpMaintance in DetailsRequest :");
		return ampResponseBO;
	}
}