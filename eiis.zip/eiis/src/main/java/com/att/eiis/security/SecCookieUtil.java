package com.att.eiis.security;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.exception.IncorrectRequestOrHeaderInfoException;

import esGateKeeper.esGateKeeper;
import esGateKeeper.hrCookie;

@Component
public class SecCookieUtil {
	Logger logger = LoggerFactory.getLogger(SecCookieUtil.class);
	
	static final String CSP_PROPERTIES_BASE = "com.att.security.CSP.";
	static final String CSP_FILTER_OPTS_BASE = CSP_PROPERTIES_BASE + "filterOpts.";
	static final String CSP_SEC_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESSec.";
	public static final String CSP_HR_COOKIE_SIG = CSP_SEC_COOKIE_BASE + "hrCookieSignature";
	public static final String CSP_EMPTYPE = CSP_SEC_COOKIE_BASE + "employeeType";
	public static final String CSP_AUTHSTR = CSP_SEC_COOKIE_BASE + "authStrength";
	public static final String CSP_ATT_UID = CSP_SEC_COOKIE_BASE + "attUid";
	public static final String CSP_AUTHENV = CSP_SEC_COOKIE_BASE + "authEnv";
	static final String CSP_HR_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESHr.";
	public static final String CSP_HR_FIRST_NAME = CSP_HR_COOKIE_BASE + "firstName";
	public static final String CSP_HR_LAST_NAME = CSP_HR_COOKIE_BASE + "lastName";
	public static final String CSP_HR_EMAIL = CSP_HR_COOKIE_BASE + "emailAddress";
	public static final String CSP_HR_NAME_SUFFIX = CSP_HR_COOKIE_BASE + "nameSuffix";
	private int secCookieTokenCount = 8;
	private int hrEmpCookieTokenCount = 12;
	private int hrPwCookieTokenCount = 11;
	private int minAuthStrength = 20;

	public HashMap<String, String> decodeCookie(String attESHr, String attESSec) throws UnsupportedEncodingException {
		logger.info("Starting method decodeCookie : ", this);
		String eSSec = esGateKeeper.esGateKeeper(attESSec, "CSP", "PROD");
		logger.debug("attESSec After esGateKeeper :" + eSSec);
		if (StringUtils.isBlank(eSSec) || StringUtils.isBlank(attESHr)) {
			throw new IncorrectRequestOrHeaderInfoException("Cookies are expired");
		}
		
		HashMap<String, String> map = new HashMap<String, String>();
		String authStr;
		String[] tokens = StringUtils.split(eSSec, "|");
		int tokCount = tokens.length;
		if (tokCount != secCookieTokenCount)
			throw new IncorrectRequestOrHeaderInfoException(
					"broken cookie attESSec: token count (" + tokCount + ") not equal to " + secCookieTokenCount);
		map.put(CSP_HR_COOKIE_SIG, tokens[1]);
		map.put(CSP_EMPTYPE, tokens[2]);
		map.put(CSP_AUTHSTR, authStr = tokens[3]);
		map.put(CSP_ATT_UID, tokens[5]);
		map.put(CSP_AUTHENV, tokens[6]);
		if (Integer.parseInt(authStr) < minAuthStrength) {
			throw new IncorrectRequestOrHeaderInfoException("Authorization string is too weak");
		}
		hrCookie oCookieVerifier = new hrCookie();
		int hrCookieValid = oCookieVerifier.verify(URLDecoder.decode(attESHr, "utf-8"),
				(String) map.get(CSP_HR_COOKIE_SIG));
		if (hrCookieValid != 0)
			throw new IncorrectRequestOrHeaderInfoException(
					"broken cookie attESHr: signature check returned " + hrCookieValid);
		String eSHr = fixAdjacentDelimiters(URLDecoder.decode(attESHr, "utf-8"));
		tokens = StringUtils.split(eSHr, "|");
		tokCount = tokens.length;
		String empType = (String) map.get(CSP_EMPTYPE);
		int expectedTokenCount = "E".equals(empType) ? hrEmpCookieTokenCount : hrPwCookieTokenCount;
		if (tokCount != expectedTokenCount)
			throw new IncorrectRequestOrHeaderInfoException(
					"broken cookie attESHr : token count (" + tokCount + ") not equal to " + expectedTokenCount);
		map.put(CSP_HR_FIRST_NAME, tokens[0]);
		map.put(CSP_HR_LAST_NAME, tokens[1]);
		map.put(CSP_HR_NAME_SUFFIX, tokens[6]);
		logger.info("Exiting method decodeCookie : ", this);
		return map;
	}

	private String fixAdjacentDelimiters(String str) {
		StringBuffer fixBuf = new StringBuffer(str);

		int n = 1;
		while (fixBuf.toString().indexOf("||", n) != -1) {
			n = fixBuf.toString().indexOf("||", n);
			fixBuf = fixBuf.replace(n, n + 2, "| |");
			n = n + 2;
		}
		return fixBuf.toString();
	}
}
