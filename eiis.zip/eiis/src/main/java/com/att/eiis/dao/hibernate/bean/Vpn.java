package com.att.eiis.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Vpn. Mapped to VPN table in the database.
 */
@Entity
@Table(name = "VPN")
public class Vpn implements java.io.Serializable {

	private static final long serialVersionUID = 8080966277785646082L;

	private Long vpnId;
	private InternalProductAccount internalProductAccount;
	private SubAccount subAccount;
	private String vpnName;
	private String vpnCustContact;
	private String vpnCompanyName;
	private String vpnType;
	private String vpnMcn;
	private String vpnGrc;
	private String status;
	private Long derivedFromVpn;
	private Orders orders;
	private Long icoreCustId;
	private String icoreCustName;
	private String primaryRT;
	private Long instarVPNId;
	private Long instarOrderId;
	private Long cometOrderId;
	private String instarVPNStatus;
	private String orderDrivenBy;

	/**
	 * Getter method for vpnId. VPN_ID mapped to VPN_ID in the database table. The
	 * sequence of vpnId is generated using the sequence SEQ_VPN_ID
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "VPN_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_VPN_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_VPN_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_VPN_ID")
	public Long getVpnId() {
		return this.vpnId;
	}

	/**
	 * @param vpnId to vpnId set.
	 */
	public void setVpnId(Long vpnId) {
		this.vpnId = vpnId;
	}

	/**
	 * Getter method for internalProductAccount.
	 * 
	 * @return InternalProductAccount
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CIPN")
	public InternalProductAccount getInternalProductAccount() {
		return this.internalProductAccount;
	}

	/**
	 * @param internalProductAccount to internalProductAccount set.
	 */
	public void setInternalProductAccount(InternalProductAccount internalProductAccount) {
		this.internalProductAccount = internalProductAccount;
	}

	/**
	 * Getter method for subAccount.
	 * 
	 * @return SubAccount
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BCID")
	public SubAccount getSubAccount() {
		return this.subAccount;
	}

	/**
	 * @param subAccount to subAccount set.
	 */
	public void setSubAccount(SubAccount subAccount) {
		this.subAccount = subAccount;
	}

	/**
	 * Getter method for vpnName. VPN_NAME mapped to VPN_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_NAME", length = 100)
	public String getVpnName() {
		return this.vpnName;
	}

	/**
	 * @param vpnName to vpnName set.
	 */
	public void setVpnName(String vpnName) {
		this.vpnName = vpnName;
	}

	/**
	 * Getter method for vpnCustContact. VPN_CUST_CONTACT mapped to VPN_CUST_CONTACT
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_CUST_CONTACT", length = 100)
	public String getVpnCustContact() {
		return this.vpnCustContact;
	}

	/**
	 * @param vpnCustContact to vpnCustContact set.
	 */
	public void setVpnCustContact(String vpnCustContact) {
		this.vpnCustContact = vpnCustContact;
	}

	/**
	 * Getter method for vpnCompanyName. VPN_COMPANY_NAME mapped to VPN_COMPANY_NAME
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_COMPANY_NAME", length = 100)
	public String getVpnCompanyName() {
		return this.vpnCompanyName;
	}

	/**
	 * @param vpnCompanyName to vpnCompanyName set.
	 */
	public void setVpnCompanyName(String vpnCompanyName) {
		this.vpnCompanyName = vpnCompanyName;
	}

	/**
	 * Getter method for vpnType. VPN_TYPE mapped to VPN_TYPE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_TYPE", length = 100)
	public String getVpnType() {
		return this.vpnType;
	}

	/**
	 * @param vpnType to vpnType set.
	 */
	public void setVpnType(String vpnType) {
		this.vpnType = vpnType;
	}

	/**
	 * Getter method for vpnMcn. VPN_MCN mapped to VPN_MCN in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_MCN", length = 100)
	public String getVpnMcn() {
		return this.vpnMcn;
	}

	/**
	 * @param vpnMcn to vpnMcn set.
	 */
	public void setVpnMcn(String vpnMcn) {
		this.vpnMcn = vpnMcn;
	}

	/**
	 * Getter method for vpnGrc. VPN_GRC mapped to VPN_GRC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "VPN_GRC", length = 100)
	public String getVpnGrc() {
		return this.vpnGrc;
	}

	/**
	 * @param vpnGrc to vpnGrc set.
	 */
	public void setVpnGrc(String vpnGrc) {
		this.vpnGrc = vpnGrc;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATED_BY_ORDER_ID", nullable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for status. STATUS mapped to STATUS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "STATUS", length = 100)
	public String getStatus() {
		return status;
	}

	/**
	 * @param status to status set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter method for derivedFromVpn. DERIVED_FROM_VPN mapped to DERIVED_FROM_VPN
	 * in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "DERIVED_FROM_VPN", length = 12)
	public Long getDerivedFromVpn() {
		return derivedFromVpn;
	}

	/**
	 * @param derivedFromVpn to derivedFromVpn set.
	 */
	public void setDerivedFromVpn(Long derivedFromVpn) {
		this.derivedFromVpn = derivedFromVpn;
	}

	/**
	 * Getter method for icoreCustId. ICORE_CUST_ID mapped to ICORE_CUST_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ICORE_CUST_ID", length = 16)
	public Long getIcoreCustId() {
		return icoreCustId;
	}

	/**
	 * @param icoreCustId to icoreCustId set.
	 */
	public void setIcoreCustId(Long icoreCustId) {
		this.icoreCustId = icoreCustId;
	}

	/**
	 * Getter method for icoreCustName. ICORE_CUST_NAME mapped to ICORE_CUST_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ICORE_CUST_NAME", length = 60)
	public String getIcoreCustName() {
		return icoreCustName;
	}

	/**
	 * @param icoreCustName to icoreCustName set.
	 */
	public void setIcoreCustName(String icoreCustName) {
		this.icoreCustName = icoreCustName;
	}

	/**
	 * Getter method for primaryRT. PRIMARY_RT mapped to PRIMARY_RT in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "PRIMARY_RT", length = 100)
	public String getPrimaryRT() {
		return primaryRT;
	}

	/**
	 * @param primaryRT to primaryRT set.
	 */
	public void setPrimaryRT(String primaryRT) {
		this.primaryRT = primaryRT;
	}

	/**
	 * Getter method for instarVPNId. INSTAR_VPN_ID mapped to INSTAR_VPN_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "INSTAR_VPN_ID", length = 16)
	public Long getInstarVPNId() {
		return instarVPNId;
	}

	/**
	 * @param instarVPNId to instarVPNId set.
	 */
	public void setInstarVPNId(Long instarVPNId) {
		this.instarVPNId = instarVPNId;
	}

	/**
	 * Getter method for instarOrderId. INSTAR_ORDER_ID mapped to INSTAR_ORDER_ID in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "INSTAR_ORDER_ID", length = 16)
	public Long getInstarOrderId() {
		return instarOrderId;
	}

	/**
	 * @param instarOrderId to instarOrderId set.
	 */
	public void setInstarOrderId(Long instarOrderId) {
		this.instarOrderId = instarOrderId;
	}

	/**
	 * Getter method for cometOrderId. COMET_ORDER_ID mapped to COMET_ORDER_ID in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "COMET_ORDER_ID", length = 19)
	public Long getCometOrderId() {
		return cometOrderId;
	}

	/**
	 * @param cometOrderId to cometOrderId set.
	 */
	public void setCometOrderId(Long cometOrderId) {
		this.cometOrderId = cometOrderId;
	}

	/**
	 * 
	 * @param instarVPNStatus to instarVPNStatus set.
	 */
	public void setInstarVPNStatus(String instarVPNStatus) {
		this.instarVPNStatus = instarVPNStatus;
	}

	/**
	 * Getter method for instarVPNStatus. INSTAR_VPN_STATUS mapped to
	 * INSTAR_VPN_STATUS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INSTAR_VPN_STATUS", length = 10)
	public String getInstarVPNStatus() {
		return instarVPNStatus;
	}

	/**
	 * Getter method for orderDrivenBy. ORDER_DRIVEN_BY mapped to ORDER_DRIVEN_BY in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_DRIVEN_BY", length = 100)
	public String getOrderDrivenBy() {
		return orderDrivenBy;
	}

	/**
	 * @param orderDrivenBy to orderDrivenBy set.
	 */
	public void setOrderDrivenBy(String orderDrivenBy) {
		this.orderDrivenBy = orderDrivenBy;
	}

}