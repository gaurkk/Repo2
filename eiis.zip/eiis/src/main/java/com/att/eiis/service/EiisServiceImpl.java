package com.att.eiis.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.EiisOrderBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;
import com.att.eiis.constants.EiisCommonConstants;
import com.att.eiis.controller.EiisController;
import com.att.eiis.dao.EiisDAO;
import com.att.eiis.dao.EiisHelper;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.exception.EiisServiceException;
import com.att.eiis.util.ApplicationConfig;
import com.att.eiis.util.MessageConfigService;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("unused")
@Service
public class EiisServiceImpl implements EiisService {
	Logger logger = LoggerFactory.getLogger(EiisServiceImpl.class);

	@Autowired
	EiisDAO eiisDAO;

	@Autowired
	EiisHelper eiisHelper;
	
	@Override
	@Transactional
	public AmpResponseBO create(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.create(orderBO,attuid);	
	}

	@Override
	@Transactional
	public AmpResponseBO cancel(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.cancel(orderBO,attuid);	
	}

	@Override
	@Transactional
	public String login(UserBean userBO,String orderId,String requestId,int serverNo) throws EiisDataException,EiisServiceException{
		return eiisDAO.login(userBO,orderId,requestId,serverNo);	
	}

	@Override
	@Transactional
	public AmpResponseBO status(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		AmpResponseBO ampResponseBO = eiisDAO.getStatusById(orderBO,attuid);
		if(null == ampResponseBO.getException()) {
			eiisHelper.process(Long.valueOf(orderBO.getOrderId()));
		}
		return ampResponseBO;
	}

	@Override
	@Transactional
	public AmpResponseBO details(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.getDetailsById(orderBO,attuid);	
	}

	@Override
	@Transactional
	public AmpResponseBO skip(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisHelper.process(Long.valueOf(orderBO.getOrderId()));
	}

	@Override
	@Transactional
	public List<AmpResponseBO> createAccaRequest(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.createAcca(orderBO,attuid);	
	}

	@Override
	@Transactional
	public AmpResponseBO accaStatus(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.getAccaStatusById(requestBO,orderBO,attuid);	
	}

	@Override
	@Transactional
	public AmpResponseBO accaDetails(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException{
		return eiisDAO.getAccaDetailsById(requestBO,orderBO,attuid);	
	}

}
