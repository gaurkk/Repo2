package com.att.eiis.util;

public enum TaskStatus {

	Success, Failure; 
}
