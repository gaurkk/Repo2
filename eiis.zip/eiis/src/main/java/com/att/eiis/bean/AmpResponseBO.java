package com.att.eiis.bean;

import lombok.Getter;
import lombok.Setter;
import springfox.documentation.spring.web.json.Json;

@Setter
@Getter
public class AmpResponseBO implements java.io.Serializable{

	private static final long serialVersionUID = -6424150157956747451L;
	
	private String rid;
	private String HTTP_CODE;
	private String requestStatus;
	private boolean isRedayForSync;
	private boolean cancelledAmp;
	private String token;
	private String errorCode;
	private String message;
	private String jsonResponse;
	private String dataCenterName;
	private String exception;
	
}
