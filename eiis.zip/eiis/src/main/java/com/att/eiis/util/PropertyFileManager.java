package com.att.eiis.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class PropertyFileManager {

	public static String getProperty(String fileName, String propName) {
		Properties confProps = loadPropertyFile(fileName);
		if (propName != null && !propName.isEmpty()) {
			String propValue = confProps.getProperty(propName.trim());
			if (propValue != null) {
				return propValue.trim();
			} else {
				return null;
			}
		}
		return null;
	}

	public static Properties getProperties(String fileName) {
		Properties confProps = loadPropertyFile(fileName);
		return confProps;
	}

	private static Properties loadPropertyFile(String fileName) {
		Properties confProps = new Properties();
		try {
			InputStream is = null;
			if (fileName != null && !fileName.isEmpty()) {

				is = Thread.currentThread().getContextClassLoader()
						.getResourceAsStream(fileName);
				if (is == null) {
					File file = new File(fileName);
					is = new FileInputStream(file);
				}
				confProps.load(is);
			}
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException is found when reading Property file : " + fileName + e);
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IOException is found when reading Property file : "	+ fileName + e);
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception is found when reading Property file : " + fileName + e);
			e.printStackTrace();
		}
		return confProps;
	}
}