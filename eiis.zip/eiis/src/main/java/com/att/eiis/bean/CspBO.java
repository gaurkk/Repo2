package com.att.eiis.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode
@AllArgsConstructor
public class CspBO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String CSPmonitor_id;
	private String CSPmonitor_password;
	private String MechID;
}
