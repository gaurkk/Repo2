package com.att.eiis.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.att.eiis.dao.hibernate.bean.OrderDataCenter;
import com.att.eiis.dao.hibernate.bean.OrderDataCenterId;

@Repository
public interface OrderDataCenterRepository extends JpaRepository<OrderDataCenter, OrderDataCenterId> {
	OrderDataCenter findById_OrderIdAndDataCenter_DataCenterName(Long orderId, String dataCenterName);
	
}
