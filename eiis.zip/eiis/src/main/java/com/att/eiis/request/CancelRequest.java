package com.att.eiis.request;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.simple.JSONObject;
import com.att.eiis.amp.AmpRequestClient;
import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.RequestType;


public class CancelRequest extends AmpRequest {
	private static Logger logger = LoggerFactory.getLogger(CancelRequest.class);

	private AmpRequestClient ampReqClient;
	private RequestBO requestBO= new RequestBO();
	private String token;
	
	public CancelRequest(String token, RequestBO requestBO) {
		this.token = token;
		this.requestBO = requestBO;
		logger.debug("Initialized details thread for Request Id : " + requestBO.getRid());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		logger.debug("Entering run() method.");
		String result = null;
		AmpResponseBO ampResponseBO = null;
		Exception exp = null;
		int counter = 0;
		for(int serverNo = 1 ; serverNo <= serverCount ; serverNo++){
			do {
				logger.debug("Executing cancel request attempt # " + (counter + 1) + " for request id : " + requestBO.getRid());

				if (counter > 0) {
					try {

						Thread.sleep(waitForTimeInMillies);

					} catch (Exception e) {
						logger.warn("Error in waiting of cancel thread for Request Id : " + requestBO.getRid(), e);
					}
				}
				counter ++;
				try {
					ampResponseBO = new AmpResponseBO();
					ampReqClient = new AmpRequestClient();
					ampResponseBO = ampReqClient.cancel(token, requestBO, serverNo);
					result = ampResponseBO.getJsonResponse().toString();
					
					logger.debug("Result for request id : " + requestBO.getRid() + " is => " + result);

				} catch (Exception e) {
					logger.error("Error in cancel thread for Request Id : " + requestBO.getRid(), e);
					exp = e;
				}
			} while (counter < retryCount && exp != null);
		}
		if (exp != null) {
			logger.error("Error is not got resolved re-throwing exception.");
			throw new RuntimeException(exp);
		}
		String httpCode = ampResponseBO.getHTTP_CODE() != null?ampResponseBO.getHTTP_CODE():"500";
		JSONObject requestJson = new JSONObject();
		requestJson.put("rid", requestBO.getRid());
		
		DatabaseUtil.insertEventLogs(requestBO.getRid(),requestJson.toString(), result,1004,httpCode,"EIIS");
		DatabaseUtil.updateEventDetails(requestBO.getRid(), 1005);

	}

	@Override
	public String getRequestId() {
		return requestBO.getRid();
	}

	@Override
	public String getRequestType() {
		return RequestType.Cancel.name();
	}
}