package com.att.eiis.service;

import com.att.eiis.service.GenericEiisService;

import java.util.List;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.EiisOrderBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.exception.EiisServiceException;

public interface EiisService extends GenericEiisService{
	
	public AmpResponseBO create(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO cancel(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public String login(UserBean userBO,String orderId,String requestId,int serverNo) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO status(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO details(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO skip(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public List<AmpResponseBO> createAccaRequest(EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO accaStatus(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;
	
	public AmpResponseBO accaDetails(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException,EiisServiceException;

}
