/**
 * 
 */
package com.att.eiis.exception;

import java.util.List;

/**
 * Base exception class for COMET service layer.
 */
public class EiisServiceException extends EiisException {

	private static final long serialVersionUID = 9036263879592175565L;

	/**
	 * CometServiceException constructor with String argument.
	 * 
	 * @param errorCode
	 */
	public EiisServiceException(String errorCode) {
		super(errorCode);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 */
	public EiisServiceException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public EiisServiceException(String errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public EiisServiceException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

	/**
	 * CometServiceException constructor with list of error messages.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public EiisServiceException(List<String> errorList) {
		super(errorList);
	}
}