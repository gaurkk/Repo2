package com.att.eiis.email;

import java.util.Arrays;
import java.util.Map;

import javax.mail.internet.InternetAddress;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmailData {
	
	public enum MessageType {
		MIMEMESSAGE, SIMPLEMESSAGE
	}
	
	private InternetAddress[] recipientsTo;
	private InternetAddress[] recipientsCc;
	private String subject;
	private String sender;
	private String messageBody;
	private MessageType messageType;
	private Map<String, String> configMap;
}
