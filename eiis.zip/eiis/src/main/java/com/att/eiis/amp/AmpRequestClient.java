package com.att.eiis.amp;

import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.CspBO;
import com.att.eiis.bean.CspResponseBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;
import com.att.eiis.controller.HttpRestTemplate;
import com.att.eiis.security.CspCookies;
import com.att.eiis.util.AmpSimpleClientHttpRequestFactory;
import com.att.eiis.util.DatabaseUtil;
import com.google.gson.Gson;

import springfox.documentation.spring.web.json.Json;

@Component
public class AmpRequestClient {

	private static final Logger logger = LoggerFactory.getLogger(AmpRequestClient.class);

	private static String CSPLoginUrl = "https://www.e-access.att.com/empsvcs/hrmonitor/?retURL=";
	private String loginUrl = "http://localhost:8282/ampsystem/login";
	private String statusUrl = "http://localhost:8282/ampsystem/request/status?token=";
	private String detailsUrl = "http://localhost:8282/ampsystem/request/details?token=";
	private String cancelUrl = "http://localhost:8282/ampsystem/cancelRequest?token=";
	private String createUrl = "http://localhost:8282/ampsystem/createRequest?token=";
	private String accSatatusUrl = "http://localhost:8282/ampsystem/request/accaStatus?token=";
	private String accaDetailsUrl = "http://localhost:8282/ampsystem/request/accaDetails?token=";
	private String accaCreateUrl = "http://localhost:8282/ampsystem/createAccaRequest?token=";
	private static RestTemplate restTemplate = null;
	private static ClientHttpRequestFactory clientHttpRequestFactory = null;
	private static AmpResponseBO responseBo=null;
	private final static char NAME_VALUE_SEPARATOR = '=';
	private static Properties  props=null;
	private static String certificateName=null;
	private CspCookies cspCookies;
	private static String cSPmonitorId;
	private static String cSPmonitorPassword;
	private static String mechID;

	static {
		clientHttpRequestFactory = new AmpSimpleClientHttpRequestFactory();
		restTemplate = new RestTemplate(clientHttpRequestFactory);
		props = DatabaseUtil.getEiisConfigProperties("AMP_CONFIG"); 
		CSPLoginUrl = props.getProperty("amp.rest.sso.login.url");
		cSPmonitorId = props.getProperty("amp.rest.sso.cspmonitor.id");
		cSPmonitorPassword = props.getProperty("amp.rest.sso.cspmonitor.password");
		mechID = props.getProperty("amp.rest.sso.mechid");
	}
	public void getUrl(String orderId,String requestId,int selectedServer){
		boolean useTestUrls = Boolean.valueOf(props.getProperty("amp.use.request.test.url"));
		certificateName = "amp.use.certificate.server";
		loginUrl = props.getProperty("amp.login.request.url.server1");
		statusUrl = props.getProperty("amp.status.request.url.server1");
		detailsUrl = props.getProperty("amp.details.request.url.server1");
		cancelUrl = props.getProperty("amp.cancel.request.url.server1");
		createUrl = props.getProperty("amp.create.request.url.server1");
		accSatatusUrl = props.getProperty("acca.create.request.url.server1");
		accaDetailsUrl =props.getProperty("acca.create.request.url.server1");
		accaCreateUrl = props.getProperty("acca.create.request.url.server1");
		if (!(useTestUrls)) {
			if((orderId == null || orderId.trim().equals("")) && null != requestId){
				orderId = DatabaseUtil.getOrderIdFromRequestId(requestId);
			}
			if(null != orderId) {
				Map<String,Object> orderData = DatabaseUtil.getFirstNetCcsMxFlag(orderId);
				if(orderData != null && orderData.get("FIRSTNET_EPC").toString().equalsIgnoreCase("Y")){
					logger.info("Initializing class FirstNet attributes i.e. server urls."+selectedServer);

					certificateName = "amp.use.certificate.firstnet.server"+selectedServer;
					loginUrl = props.getProperty("amp.login.request.url.firstnet.server"+selectedServer);
					statusUrl = props.getProperty("amp.status.request.url.firstnet.server"+selectedServer);
					detailsUrl = props.getProperty("amp.details.request.url.firstnet.server"+selectedServer);
					cancelUrl = props.getProperty("amp.cancel.request.url.firstnet.server"+selectedServer);
					createUrl = props.getProperty("amp.create.request.url.firstnet.server"+selectedServer);
					accSatatusUrl = props.getProperty("acca.status.request.url.firstnet.server"+selectedServer);
					accaDetailsUrl =props.getProperty("acca.details.request.url.firstnet.server"+selectedServer);
					accaCreateUrl = props.getProperty("acca.create.request.url.firstnet.server"+selectedServer);
					logger.info("Initialized class attributes i.e. server urls.");
				}else if(orderData != null && orderData.get("CCSMX").toString().equalsIgnoreCase("Y")){
					certificateName = "amp.use.certificate.ccsmx.server"+selectedServer;
					loginUrl = props.getProperty("amp.login.request.url.ccsmx.server"+selectedServer);
					logger.info("Initializing class ccsmx attributes i.e. server urls."+selectedServer);
					statusUrl = props.getProperty("amp.status.request.url.ccsmx.server"+selectedServer);
					detailsUrl = props.getProperty("amp.details.request.url.ccsmx.server"+selectedServer);
					cancelUrl = props.getProperty("amp.cancel.request.url.ccsmx.server"+selectedServer);
					createUrl = props.getProperty("amp.create.request.url.ccsmx.server"+selectedServer);
					accSatatusUrl = props.getProperty("acca.status.request.url.ccsmx.server"+selectedServer);
					accaDetailsUrl =props.getProperty("acca.details.request.url.ccsmx.server"+selectedServer);
					accaCreateUrl = props.getProperty("acca.create.request.url.ccsmx.server"+selectedServer);
				}else{
					certificateName = "amp.use.certificate.server"+selectedServer;
					loginUrl = props.getProperty("amp.login.request.url.server"+selectedServer);
					logger.info("Initializing class non ccsmx attributes i.e. server urls."+selectedServer);
					statusUrl = props.getProperty("amp.status.request.url.server"+selectedServer);
					detailsUrl = props.getProperty("amp.details.request.url.server"+selectedServer);
					cancelUrl = props.getProperty("amp.cancel.request.url.server"+selectedServer);
					createUrl = props.getProperty("amp.create.request.url.server"+selectedServer);
					accSatatusUrl = props.getProperty("acca.status.request.url.server"+selectedServer);
					accaDetailsUrl =props.getProperty("acca.details.request.url.server"+selectedServer);
					accaCreateUrl = props.getProperty("acca.create.request.url.server"+selectedServer);
				}
			}
		}else{
			logger.info("Initializing class default test attributes i.e. test server urls.");
			certificateName = "amp.use.certificate.server.test";
			statusUrl = props.getProperty("amp.status.request.test.url");
			detailsUrl = props.getProperty("amp.details.request.test.url");
			cancelUrl = props.getProperty("amp.cancel.request.test.url");
			createUrl = props.getProperty("amp.create.request.test.url");

			accSatatusUrl = props.getProperty("acca.status.request.test.url");
			accaDetailsUrl =props.getProperty("acca.details.request.test.url");
			accaCreateUrl = props.getProperty("acca.create.request.test.url");
		}
	}

	/**
	 * Login to the AMP server
	 * 
	 * @param userObject
	 * @return token
	 */
	public  AmpResponseBO login(UserBean userObject,String orderId,String requestId,int serverNo) {
		logger.info("Starting methode login. ",this);
		String result = null;
		responseBo = new AmpResponseBO();
		try {
			getUrl(orderId,requestId,serverNo);
			logger.info("Login URL for login >>>>>>>>>>>>>>>>>>>>>>>:"+loginUrl);
			ResponseEntity<String> response = restTemplate.postForEntity(loginUrl, userObject, String.class);
			HttpStatus status = response.getStatusCode();
			result = response.getBody();
			responseBo.setJsonResponse(result);
			responseBo.setHTTP_CODE(String.valueOf(status.value()));
			logger.info("Http Status Code for login >>>>>>>>>>>>>>>>>>>>>>>:"+status.value());
			if (result != null && !result.equalsIgnoreCase(StringUtils.EMPTY) && status.value() == 200) {
				responseBo.setToken(result);
			}

		}catch (HttpStatusCodeException  e) { 
			logger.debug("URISyntaxException during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for order id: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("501");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code ." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("501");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}
		
		logger.info("Exiting methode login. ",this);
		return responseBo;
	}

	/**
	 * getCspAuthToken for Login to the AMP server
	 * 
	 * @param userObject
	 * @return token
	 */
	public AmpResponseBO getCspAuthToken(CspBO cspObject,String orderId,String requestId,int serverNo) {
		logger.debug("Entering AmpRestRequestClient.getCspAuthToken() method.");
		getUrl(orderId,requestId,serverNo);
		String result = null;
		responseBo = new AmpResponseBO();
		cspCookies = new CspCookies();
		CspResponseBO cspResponseBO = cspCookies.getCSPCookies(CSPLoginUrl,cSPmonitorId,cSPmonitorPassword,mechID);
		
		try {
			if(null!=cspResponseBO && null!=cspResponseBO.getUser() && null!=cspResponseBO.getUser().getSec() && null!=cspResponseBO.getUser().getHr()) {
				String reqBody = "{\"user\":{\"sec\":\""
						+ cspResponseBO.getUser().getSec() + "\",\"hr\":\""
						+ cspResponseBO.getUser().getHr() + "\"}}";
				
				logger.debug("loginUrl for AMP ... !"+ loginUrl);
				logger.debug("reqBody for AMP ... !"+ reqBody);
				
				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(loginUrl, reqBody, "POST",certificateName);
				int status = (Integer) postForEntity.get("RESPONSE_CODE");
				Object object = postForEntity.get("result");
				result = object.toString();
				responseBo.setJsonResponse(result);
				
				logger.debug("result for token ... !"+ result);
				logger.debug("status for token ... !"+ status);
				
				if (status == 0 || result == null
						|| result.equalsIgnoreCase(StringUtils.EMPTY)) {
					responseBo.setHTTP_CODE(String.valueOf("501"));
					responseBo.setErrorCode(String.valueOf("501"));
					responseBo.setMessage("Authentication Failed");
					logger.debug("501 HTTP code");
				} else {
					responseBo.setHTTP_CODE(String.valueOf(status));
					responseBo.setToken(result);
				}
			}else {
				logger.debug("CspResponseBO is null");
			}
			
		} catch (HttpClientErrorException e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getStatusCode().value()));
			responseBo.setMessage(e.getMessage());
		} catch (HttpServerErrorException e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getStatusCode().value()));
			responseBo.setMessage(e.getMessage());
		} catch (Exception e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("501");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}

		return responseBo;
	}

	/**
	 * Fetches the status of the provided request id
	 * 
	 * @param token
	 * @param reqObject
	 * @return status
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO status(String token,RequestBO reqObject,int serverNo) {
		logger.debug("Entering status() method.");

		getUrl("",reqObject.getRid(),serverNo);
		String result = null;
		int status;
		Exception ex = null;
		String statusUrlUpdate = statusUrl;
		statusUrlUpdate = statusUrlUpdate.replace("{{request_id}}",reqObject.getRid());
		statusUrlUpdate = statusUrlUpdate.replace("{{login-token}}", token);

		logger.debug("Status URL : "+statusUrlUpdate);

		responseBo = new AmpResponseBO();
		try {
			if (statusUrlUpdate != null
					&& statusUrlUpdate.length() > 5
					&& statusUrlUpdate.substring(0, 5)
					.equalsIgnoreCase("https")) {

				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(statusUrlUpdate, reqObject, "GET",certificateName);
				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.getForEntity(
						statusUrlUpdate, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setJsonResponse(result);
			responseBo.setHTTP_CODE(String.valueOf(status));

			logger.debug("Status Code : "+status);
			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, String> responseJson = new Gson().fromJson(result, Map.class);
						if (responseJson.containsKey("rid")) {
							responseBo.setRid(responseJson.get("rid"));
						}
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(
									String.valueOf(responseJson.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message")+":"+responseJson.get("details"));
							else
								responseBo.setMessage(responseJson.get("message"));
						}
					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("Status during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for status: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code for status." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}

		logger.debug("Exiting status() method. > " + result);
		return responseBo;
	}

	/**
	 * Fetches the details of the provided request id
	 * 
	 * @param token
	 * @param reqObject
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO details(String token,RequestBO reqObject,int serverNo) {
		logger.debug("Entering details() method.");
		getUrl("",reqObject.getRid(),serverNo);
		String result = null;
		int status;
		Exception ex = null;
		responseBo = new AmpResponseBO();
		String detailsUrlUpdate = detailsUrl;
		detailsUrlUpdate = detailsUrlUpdate.replace("{{request_id}}",reqObject.getRid());
		detailsUrlUpdate = detailsUrlUpdate.replace("{{login-token}}", token);
		try {
			if (detailsUrlUpdate != null
					&& detailsUrlUpdate.length() > 5
					&& detailsUrlUpdate.substring(0, 5).equalsIgnoreCase("https")) {
				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(detailsUrlUpdate, reqObject, "GET",certificateName);
				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.getForEntity(detailsUrlUpdate, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setHTTP_CODE(String.valueOf(status));
			responseBo.setJsonResponse(result);
			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, String> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("rid")) {
							responseBo.setRid(responseJson.get("rid"));
							responseBo.setRedayForSync(true);
						}
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(String.valueOf(responseJson.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message")+":"+responseJson.get("details"));
							else
								responseBo.setMessage(responseJson.get("message"));
						}
					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("details during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for details : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("details for error code ." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}
		
		logger.debug("Exiting details() method. > ");
		return responseBo;
	}

	/**
	 * Cancels the provided request id
	 * 
	 * @param token
	 * @param reqObject
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO cancel(String token,
			RequestBO reqObject,int serverNo) {
		logger.debug("Entering cancel() method.");
		getUrl("",reqObject.getRid(),serverNo);
		String result = null;
		int status;
		Exception ex = null;
		responseBo = new AmpResponseBO();
		try {
			if (cancelUrl != null && cancelUrl.length() > 5
					&& cancelUrl.substring(0, 5).equalsIgnoreCase("https")) {
				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(cancelUrl + token, reqObject, "POST",certificateName);

				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.postForEntity(
						cancelUrl + token, reqObject, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setHTTP_CODE(String.valueOf(status));
			responseBo.setJsonResponse(result);
			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, String> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("rid")) {
							responseBo.setRid(responseJson.get("rid"));
							responseBo.setCancelledAmp(true);
						}
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(String.valueOf(responseJson
									.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message")+":"+responseJson.get("details"));
							else
								responseBo.setMessage(responseJson.get("message"));
						}
					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");						
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("cancel during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for cancel: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code for cancel." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}

		return responseBo;
	}

	/**
	 * Creates object at AMP server
	 * 
	 * @param token
	 * @param ampObject
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO create(String token, String ampRequestJson,String orderId,int serverNo) {
		logger.debug("Entering create() method." + createUrl);

		getUrl(orderId,"",serverNo);
		String result = null;
		int status;
		Exception ex = null;
		responseBo = new AmpResponseBO();
		try {
			if (createUrl != null && createUrl.length() > 5
					&& createUrl.substring(0, 5).equalsIgnoreCase("https")) {
				Map<String, Object> postForEntity = HttpRestTemplate
						.postForEntity(createUrl + token, ampRequestJson,
								"POST",certificateName);

				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.postForEntity(
						createUrl + token, ampRequestJson, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setHTTP_CODE(String.valueOf(status));
			responseBo.setJsonResponse(result);

			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, Object> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("rid"))
							responseBo.setRid(responseJson.get("rid").toString());
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(String.valueOf(responseJson
									.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message").toString()+":"+responseJson.get("details").toString());
							else
								responseBo.setMessage(responseJson.get("message").toString());
						}

					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("Create during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for create: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code for create." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}

		logger.debug("Exiting create() method. > " + result);
		return responseBo;
	}

	//ACCA CODE CHANGES STARTED


	/**
	 * Creates object at AMP server
	 * 
	 * @param token
	 * @param ampObject
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO createAccaRequest(String token, String ampRequestJson,String orderId,int serverNo) {

		getUrl(orderId,"",serverNo);
		String result = null;
		int status;
		Exception ex = null;
		responseBo = new AmpResponseBO();

		try {
			if (accaCreateUrl != null && accaCreateUrl.length() > 5
					&& accaCreateUrl.substring(0, 5).equalsIgnoreCase("https")) {
				Map<String, Object> postForEntity = HttpRestTemplate
						.postForEntity(accaCreateUrl + token, ampRequestJson,
								"POST",certificateName);
				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.postForEntity(
						accaCreateUrl + token, ampRequestJson, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setHTTP_CODE(String.valueOf(status));
			responseBo.setJsonResponse(result);

			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, Object> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("request_id"))
							responseBo.setRid(responseJson.get("request_id").toString());
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(String.valueOf(responseJson
									.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message").toString()+":"+responseJson.get("details").toString());
							else
								responseBo.setMessage(responseJson.get("message").toString());
						}

					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		} catch (HttpClientErrorException e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getStatusCode().value()));
			responseBo.setMessage(e.getMessage());

		} catch (HttpServerErrorException e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getStatusCode().value()));
			responseBo.setMessage(e.getMessage());

		} catch (Exception e) {
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}

		logger.debug("Exiting accaCreate() method. > " + result);
		return responseBo;
	}


	/**
	 * Fetches the status of the provided request id
	 * 
	 * @param token
	 * @param reqObject
	 * @return status
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO accaStatus(String token,
			RequestBO reqObject,int serverNo) {
		logger.debug("Entering accaStatus() method.");

		getUrl("",reqObject.getRid(),serverNo);
		String result = null;
		int status;
		Exception ex = null;
		String statusUrlUpdate = accSatatusUrl;
		statusUrlUpdate = statusUrlUpdate.replace("{{request_id}}",
				reqObject.getRid());
		statusUrlUpdate = statusUrlUpdate.replace("{{login-token}}", token);
		responseBo = new AmpResponseBO();
		try {
			if (statusUrlUpdate != null
					&& statusUrlUpdate.length() > 5
					&& statusUrlUpdate.substring(0, 5)
					.equalsIgnoreCase("https")) {
				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(statusUrlUpdate, reqObject, "GET",certificateName);
				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.getForEntity(
						statusUrlUpdate, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setJsonResponse(result);
			responseBo.setHTTP_CODE(String.valueOf(status));
			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");
			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, String> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("rid")) {
							responseBo.setRid(responseJson.get("rid"));
						}
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(
									String.valueOf(responseJson.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message")+":"+responseJson.get("details"));
							else
								responseBo.setMessage(responseJson.get("message"));
						}
					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("Acca Status during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for Acca Status: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code for Acca Status." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}
		logger.debug("Exiting accaStatus() method. > " + result);
		return responseBo;
	}

	/**
	 * Fetches the details of the provided request id
	 * 
	 * @param token
	 * @param reqObject
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public AmpResponseBO accaDetails(String token,RequestBO reqObject,int serverNo) {
		logger.debug("Entering accaDetails() method.");

		getUrl("",reqObject.getRid(),serverNo);
		String result = null;
		int status;
		Exception ex = null;
		responseBo = new AmpResponseBO();
		String detailsUrlUpdate = accaDetailsUrl;
		detailsUrlUpdate = detailsUrlUpdate.replace("{{request_id}}",reqObject.getRid());
		detailsUrlUpdate = detailsUrlUpdate.replace("{{login-token}}", token);
		try {
			if (detailsUrlUpdate != null
					&& detailsUrlUpdate.length() > 5
					&& detailsUrlUpdate.substring(0, 5).equalsIgnoreCase(
							"https")) {
				Map<String, Object> postForEntity = HttpRestTemplate.postForEntity(detailsUrlUpdate, reqObject, "GET",certificateName);
				status = (Integer) postForEntity.get("RESPONSE_CODE");
				if(status == 0){
					ex = (Exception) postForEntity.get("result");
				}
				Object object = postForEntity.get("result");
				result = object.toString();
			} else {
				ResponseEntity<String> response = restTemplate.getForEntity(
						detailsUrlUpdate, String.class);
				status = response.getStatusCode().value();
				result = response.getBody();
			}
			responseBo.setHTTP_CODE(String.valueOf(status));
			responseBo.setJsonResponse(result);
			if (result == null || result.equalsIgnoreCase(StringUtils.EMPTY)) {
				responseBo.setHTTP_CODE(String.valueOf(status));
				responseBo.setJsonResponse("Empty Response Body");

			} else {
				if (status == 200 || status == 500) {
					try{
						Map<String, String> responseJson = new Gson().fromJson(
								result, Map.class);
						if (responseJson.containsKey("rid")) {
							responseBo.setRid(responseJson.get("rid"));
							responseBo.setRedayForSync(true);
						}
						if (responseJson.containsKey("code")) {
							Double errCode = new Double(String.valueOf(responseJson
									.get("code")));
							responseBo.setErrorCode(String.valueOf(errCode
									.intValue()));
						}
						if (responseJson.containsKey("message")){
							if(responseJson.containsKey("details"))
								responseBo.setMessage(responseJson.get("message")+":"+responseJson.get("details"));
							else
								responseBo.setMessage(responseJson.get("message"));
						}
					}catch (Exception e) {
						responseBo.setHTTP_CODE("0");
						responseBo.setErrorCode("500");
						responseBo.setMessage("Get Invalid Response from Amp");
					}
				} else {
					if(status == 403){
						responseBo.setErrorCode("403");
						responseBo.setMessage("Request is not authorized in AMP");
					}else if(status == 404){
						responseBo.setErrorCode("404");
						responseBo.setMessage("AMP is not reachable. Please try after sometime");			
					}else if(status == 400){
						responseBo.setErrorCode("400");
						responseBo.setMessage("Invalid request json in AMP");			
					}else{	
						responseBo.setMessage(result);
						if(status == 0){
							responseBo.setMessage(ex.getMessage()!=null?ex.getMessage():result);
						}
					}
				}

			}
		}catch (HttpStatusCodeException  e) { 
			logger.debug("Acca Details during URI generate : " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode(String.valueOf(e.getRawStatusCode()));
			responseBo.setMessage(e.getStatusText());
			e.printStackTrace();
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for Acca Details: " + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMostSpecificCause().toString());
			e.printStackTrace();
		}catch (Exception e) {
			logger.debug("error code for Acca Details ." + e.getMessage());
			responseBo.setHTTP_CODE("0");
			responseBo.setErrorCode("500");
			responseBo.setMessage(e.getMessage());
			e.printStackTrace();
		}
		logger.debug("Exiting accaDetails() method. > ");
		return responseBo;
	}
}