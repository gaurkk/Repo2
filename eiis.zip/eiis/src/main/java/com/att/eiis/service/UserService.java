package com.att.eiis.service;

import com.att.eiis.bean.UserBO;

public interface UserService extends GenericEiisService {

	public UserBO getUser(String attuId);
	
	public boolean isAuthorizeUser(String attuId, long roleId);

}
