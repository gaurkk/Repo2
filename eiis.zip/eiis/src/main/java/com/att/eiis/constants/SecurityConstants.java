package com.att.eiis.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class SecurityConstants {
	@Value("${comet.jwt.secret}")
	private String secret;
	@Value("${comet.jwt.token.expirationTime}")
	private long expirationTime;
	@Value("${comet.oidc.responseType}")
	private String responseType;
	@Value("${comet.oidc.codeChallengeMethod}")
	private String codeChallengeMethod;
	@Value("${comet.oidc.state}")
	private String state;
	@Value("${comet.oidc.scope}")
	private String scope;
	
	public String getSecret() {
		return secret;
	}
	public long getExpirationTime() {
		return expirationTime;
	}

	public String getResponseType() {
		return responseType;
	}

	public String getCodeChallengeMethod() {
		return codeChallengeMethod;
	}

	public String getState() {
		return state;
	}

	public String getScope() {
		return scope;
	}
}
