/**
 * 
 */
package com.att.eiis.exception;

import java.util.List;

/**
 * Base exception class for COMET application.
 */
public class EiisException extends Exception {

	private static final long serialVersionUID = 9036263879592175565L;
	private String errorCode;
	private List<String> errorList;

	/**
	 * CometException Constructor with String argument.
	 * 
	 * @param errorCode
	 */
	public EiisException(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * CometException Constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 */
	public EiisException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	/**
	 * CometException Constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public EiisException(String errorCode, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
	}

	/**
	 * CometException Constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public EiisException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode;
	}

	/**
	 * Getter method for the errorCode
	 * 
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Setter method for errorCode
	 * 
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * 
	 * @param errorCode
	 * @param message
	 */
	public EiisException(List<String> errorList) {
		this.errorList = errorList;
	}

	public List<String> getErrorList() {
		return errorList;
	}

	public void setErrorList(List<String> errorList) {
		this.errorList = errorList;
	}
}