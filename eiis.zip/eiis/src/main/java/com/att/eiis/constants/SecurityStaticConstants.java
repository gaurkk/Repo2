package com.att.eiis.constants;

public class SecurityStaticConstants {
	static final String CSP_PROPERTIES_BASE = "com.att.security.CSP.";
	static final String CSP_FILTER_OPTS_BASE = CSP_PROPERTIES_BASE + "filterOpts.";
	static final String CSP_SEC_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESSec.";
	public static final String CSP_ATT_UID = CSP_SEC_COOKIE_BASE + "attUid";
	static final String CSP_HR_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESHr.";
	public static final String CSP_HR_FIRST_NAME = CSP_HR_COOKIE_BASE + "firstName";
	public static final String CSP_HR_LAST_NAME = CSP_HR_COOKIE_BASE + "lastName";
	public static final String CSP_HR_NAME_SUFFIX = CSP_HR_COOKIE_BASE + "nameSuffix";
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
	
}
