package com.att.eiis.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode
@AllArgsConstructor
public class UserBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public UserBean() {
        super();
    }
	
	private User user;
}