package com.att.eiis.threadpool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.request.AmpRequest;
import com.att.eiis.request.DetailsRequest;
import com.att.eiis.request.StatusRequest;
import com.att.eiis.scheduler.EiisDetailsSyncTaskManager;
import com.att.eiis.scheduler.EiisStatusSyncTaskManager;
import com.att.eiis.util.TaskStatus;

/**
 * This class will provide the thread pool to the application. 
 */
public class EiisThreadPoolExecutor extends ThreadPoolExecutor {

	private static Logger logger = LoggerFactory.getLogger(EiisThreadPoolExecutor.class);

	public EiisThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit timeUnit,
			BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory, RejectedExecutionHandler rejectedHandler) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, timeUnit, workQueue, threadFactory, rejectedHandler);
		logger.debug("corePoolSize : " + corePoolSize + ", maximumPoolSize : " + maximumPoolSize 
				+ ", keepAliveTime : " + keepAliveTime + ", timeUnit : " + timeUnit);
	}

	/**
	 * Implemented this method to log error in case of failure of thread
	 */
	protected void afterExecute(Runnable runnable, Throwable throwable) {
		logger.debug("Entering afterExecute() method.");
		super.afterExecute(runnable, throwable);
		if (runnable instanceof AmpRequest) {
			if (runnable instanceof StatusRequest) {
				StatusRequest statusRequest = (StatusRequest) runnable;
				if(throwable != null) {
					EiisStatusSyncTaskManager.getInstance().updateStatusMap(statusRequest.getRequestId(), TaskStatus.Failure.name());	
					logger.debug("Got an error : " + throwable + " for request id : " + statusRequest.getRequestId());
				} else {
					EiisStatusSyncTaskManager.getInstance().updateStatusMap(statusRequest.getRequestId(), TaskStatus.Success.name());
					logger.debug("Updating status map result 'Successful' for request id : " + statusRequest.getRequestId());
				}
			} else if (runnable instanceof DetailsRequest) {
				DetailsRequest detailsRequest = (DetailsRequest) runnable;
				if(throwable != null) {
					EiisDetailsSyncTaskManager.getInstance().updateDetailsMap(detailsRequest.getRequestId(), TaskStatus.Failure.name());	
					logger.debug("Got an error : " + throwable + " for request id : " + detailsRequest.getRequestId());
				} else {
					EiisDetailsSyncTaskManager.getInstance().updateDetailsMap(detailsRequest.getRequestId(), TaskStatus.Success.name());
					logger.debug("Updating details map result 'Successful' for request id : " + detailsRequest.getRequestId());
				} 
			}
		} else {
			logger.debug("Unknown thread ...");
		}
		logger.debug("Exiting afterExecute() method.");
	}
}