package com.att.eiis.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.att.eiis.dao.hibernate.bean.EiisConfiguration;
import java.lang.String;
import java.lang.Long;

@Repository
public interface EiisConfigurationRepository extends JpaRepository<EiisConfiguration,Long>{
	
	List<EiisConfiguration> findByKey(String key);
	
	
}
