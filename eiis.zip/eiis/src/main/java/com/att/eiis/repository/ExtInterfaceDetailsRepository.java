package com.att.eiis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.att.eiis.dao.hibernate.bean.ExternalInterfaceDetails;

@Repository
public interface ExtInterfaceDetailsRepository extends JpaRepository<ExternalInterfaceDetails,String>{
	
	ExternalInterfaceDetails findByExtInterfaceId(String extInterfaceId);
	
	List<ExternalInterfaceDetails> findByExtInterfaceIdNotLikeAndEventStatus_EventStatusId(String extInterfaceId,Long eventStatusID); 
	
	List<String> findByExtInterfaceIdIn(List<String> failedRequests);	
}
