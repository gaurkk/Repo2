package com.att.eiis.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Generic super class for all comet business objects.
 */
@Getter
@Setter
@EqualsAndHashCode
public class CometGenericBO implements Serializable {

	private static final long serialVersionUID = -6493546597703499750L;
	@JsonIgnore
	private boolean markForDeletion;
	@JsonIgnore
	private boolean instarAvailable;
}
