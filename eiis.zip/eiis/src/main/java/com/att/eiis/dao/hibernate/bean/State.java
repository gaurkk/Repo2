package com.att.eiis.dao.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for State. Mapped to STATE table in the database.
 */
@Entity
@Table(name = "STATE")
public class State implements java.io.Serializable {

	private static final long serialVersionUID = 6559684191722771713L;

	private Long stateId;
	private Country country;
	private String stateName;
	private Set<SubAccount> subAccountsForBlStateId = new HashSet<SubAccount>(0);
	private Set<SubAccount> subAccountsForClStateId = new HashSet<SubAccount>(0);
	private Set<SubAccount> subAccountsForHlStateId = new HashSet<SubAccount>(0);
	private Set<SubAccount> subAccountsForMccStateId = new HashSet<SubAccount>(
			0);
	private Set<Users> userses = new HashSet<Users>(0);
	private Set<City> cities = new HashSet<City>(0);
	private Character active;

	/**
	 * Getter method for stateId. STATE_ID mapped to STATE_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Id
	@GenericGenerator(name = "SEQ_STATE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_STATE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_STATE_ID")
	@Column(name = "STATE_ID", nullable = false, precision = 12, scale = 0)
	public Long getStateId() {
		return this.stateId;
	}

	/**
	 * @param stateId to stateId set.
	 */
	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	/**
	 * Getter method for country.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COUNTRY_ID", nullable = false)
	public Country getCountry() {
		return this.country;
	}

	/**
	 * @param country
	 *            to country set.
	 */
	public void setCountry(Country country) {
		this.country = country;
	}

	/**
	 * Getter method for stateName. STATE_NAME mapped to STATE_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "STATE_NAME", nullable = false, length = 100)
	public String getStateName() {
		return this.stateName;
	}

	/**
	 * @param stateName
	 *            to stateName set.
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	/**
	 * Getter method for subAccountsForBlStateId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stateByBlStateId")
	public Set<SubAccount> getSubAccountsForBlStateId() {
		return this.subAccountsForBlStateId;
	}

	/**
	 * @param subAccountsForBlStateId
	 *            to subAccountsForBlStateId set.
	 */
	public void setSubAccountsForBlStateId(
			Set<SubAccount> subAccountsForBlStateId) {
		this.subAccountsForBlStateId = subAccountsForBlStateId;
	}

	/**
	 * Getter method for subAccountsForClStateId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stateByClStateId")
	public Set<SubAccount> getSubAccountsForClStateId() {
		return this.subAccountsForClStateId;
	}

	/**
	 * @param subAccountsForClStateId
	 *            to subAccountsForClStateId set.
	 */
	public void setSubAccountsForClStateId(
			Set<SubAccount> subAccountsForClStateId) {
		this.subAccountsForClStateId = subAccountsForClStateId;
	}

	/**
	 * Getter method for subAccountsForHlStateId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stateByHlStateId")
	public Set<SubAccount> getSubAccountsForHlStateId() {
		return this.subAccountsForHlStateId;
	}

	/**
	 * @param subAccountsForHlStateId
	 *            to subAccountsForHlStateId set.
	 */
	public void setSubAccountsForHlStateId(
			Set<SubAccount> subAccountsForHlStateId) {
		this.subAccountsForHlStateId = subAccountsForHlStateId;
	}

	/**
	 * Getter method for subAccountsForMccStateId.
	 * 
	 * @return Set<SubAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stateByMccStateId")
	public Set<SubAccount> getSubAccountsForMccStateId() {
		return this.subAccountsForMccStateId;
	}

	/**
	 * @param subAccountsForMccStateId
	 *            to subAccountsForMccStateId set.
	 */
	public void setSubAccountsForMccStateId(
			Set<SubAccount> subAccountsForMccStateId) {
		this.subAccountsForMccStateId = subAccountsForMccStateId;
	}

	/**
	 * Getter method for userses.
	 * 
	 * @return Set<Users>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "state")
	public Set<Users> getUserses() {
		return this.userses;
	}

	/**
	 * @param userses
	 *            to userses set.
	 */
	public void setUserses(Set<Users> userses) {
		this.userses = userses;
	}

	/**
	 * Getter method for cities.
	 * 
	 * @return Set<City>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "state")
	public Set<City> getCities() {
		return this.cities;
	}

	/**
	 * @param cities
	 *            to cities set.
	 */
	public void setCities(Set<City> cities) {
		this.cities = cities;
	}

	@Column(name = "ACTIVE", length = 1)
	public Character getActive() {
		return active;
	}

	public void setActive(Character active) {
		this.active = active;
	}
}