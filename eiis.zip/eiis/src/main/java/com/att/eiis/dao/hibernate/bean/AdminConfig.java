package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent Class for AdminC0nfig. Mapped with the ADMIN_CONFIG table in
 * database.
 */
@Entity
@Table(name = "ADMIN_CONFIG")
public class AdminConfig implements Serializable {

	private static final long serialVersionUID = -6664893941963813493L;

	private Long adminConfigId;
	private AdminCategory adminCategory;
	private String categoryValue;
	private String description;
	private Character defaultValue;
	
	/**
	 * Getter method for the AdminConfigId. ADMIN_CONFIG_ID mapped to
	 * ADMIN_CONFIG_ID in Database.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ADMIN_CONFIG_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ADMIN_CONFIG_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ADMIN_CONFIG_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ADMIN_CONFIG_ID")
	public Long getAdminConfigId() {
		return this.adminConfigId;
	}

	/**
	 * @param adminConfigId
	 *            to adminConfigId set.
	 */
	public void setAdminConfigId(Long adminConfigId) {
		this.adminConfigId = adminConfigId;
	}
	
	/**
	 * Getter for the AdminCategory.
	 * 
	 * @return AdminCategory.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ADMIN_CATEGORY_ID", nullable = false)
	public AdminCategory getAdminCategory() {
		return this.adminCategory;
	}

	/**
	 * @param adminCategory
	 *            to adminCategory set.
	 */
	public void setAdminCategory(AdminCategory adminCategory) {
		this.adminCategory = adminCategory;
	}

	/**
	 * Getter method for the CategoryValue. CATEGORY_VALUE mapped to
	 * CATEGORY_VALUE in database.
	 * 
	 * @return String.
	 */
	@Column(name = "CATEGORY_VALUE", nullable = false, length = 1000)
	public String getCategoryValue() {
		return this.categoryValue;
	}

	/**
	 * @param categoryValue
	 *            to categoryValue set.
	 */
	public void setCategoryValue(String categoryValue) {
		this.categoryValue = categoryValue;
	}

	/**
	 * Getter method for the description. DESCRIPTION mapped to DESCRIPTION in
	 * database.
	 * 
	 * @return String
	 */
	@Column(name = "DESCRIPTION", length = 1000)
	public String getDescription() {
		return this.description;
	}

	/**
	 * @param description
	 *            to description set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name = "DEFAULT_FLAG", length = 1)
	public Character getDefaultValue() {
		return defaultValue;
	}

	/**
	 * 
	 * @param defaultValue
	 */
	public void setDefaultValue(Character defaultValue) {
		this.defaultValue = defaultValue;
	}

}
