package com.att.eiis.request;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.json.simple.JSONObject;

import com.att.eiis.amp.AmpRequestClient;
import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.scheduler.EiisDetailsSyncTaskManager;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.EiisServerUtil;
import com.att.eiis.util.RequestType;
import com.att.eiis.util.TaskStatus;

import springfox.documentation.spring.web.json.Json;

public class DetailsRequest extends AmpRequest {
	Logger logger = LoggerFactory.getLogger(DetailsRequest.class);
	
	private AmpRequestClient ampReqclient;
	private EiisServerUtil eiisServerUtil;
	private RequestBO requestBO= new RequestBO();
	
	public DetailsRequest(RequestBO requestBO) {
		this.requestBO = requestBO;
		logger.debug("Initialized details thread for Request Id : " + requestBO.getRid());
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		logger.debug("Starting DetailsRequest.run() method.");

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		Exception exception = null;
		int counter = 0;
		String token = null;
		String httpCode = null;
		JSONObject requestJson ;
		
		eiisServerUtil = new EiisServerUtil();
		ampResponseBO = eiisServerUtil.checkAmpMaintance();
		if(null != ampResponseBO){
			ampResponseBO.setHTTP_CODE("400");
			ampResponseBO.setErrorCode("400");
			exception = new Exception();
		}else{
			for(int serverNo = 1 ; serverNo <= serverCount ; serverNo++){
				do {
					logger.debug("Executing details sync attempt # " + (counter + 1) + " for request id : " + requestBO.getRid());
					
					if (counter > 0) {
						try {
							Thread.sleep(waitForTimeInMillies);
						} catch (Exception e) {
							logger.warn("Error in waiting of details thread for Request Id : " + requestBO.getRid(), e);
						}
					}
					counter ++;
					exception = null;
					try {
						eiisServerUtil = new EiisServerUtil();
						ampResponseBO = eiisServerUtil.getToken("",requestBO.getRid(),serverNo);
						token = ampResponseBO.getToken();
						if(token == null || token.equalsIgnoreCase("")){
							ampResponseBO.setHTTP_CODE("501");
							ampResponseBO.setErrorCode("501");
							ampResponseBO.setMessage("Authentication Failed");
							ampResponseBO.setJsonResponse("Authentication Failed:Get login token failed");
							throw new Exception();
						}else{
							ampReqclient = new AmpRequestClient();
							ampResponseBO = ampReqclient.details(token, requestBO,serverNo);
							
							if(ampResponseBO.getHTTP_CODE() == "0"){
								throw new Exception();
							}
						}
					} catch (Exception e) {
						logger.error("Error in details thread for Request Id : " + requestBO.getRid(), e);
						exception = e;
					}
				} while (counter < retryCount && exception != null);
			}
		}
		if (exception != null) {
			logger.error("Error is not got resolved re-throwing exception.");
			
			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			requestJson = new JSONObject();
			requestJson.put("rid",requestBO.getRid());
			logger.error("Re-throwing exception while fetching details of order : " + requestBO.getRid() + ".");

			DatabaseUtil.insertEventLogs(requestBO.getRid(), requestJson.toString(), ampResponseBO.getMessage()+ampResponseBO.getJsonResponse(), 1003,httpCode,"EIIS");
			throw new RuntimeException(exception);
		}else{
			httpCode = ampResponseBO.getHTTP_CODE() != null?ampResponseBO.getHTTP_CODE():"500";
			requestJson = new JSONObject();
			requestJson.put("rid",requestBO.getRid());

			DatabaseUtil.insertEventLogs(requestBO.getRid(), requestJson.toString(), ampResponseBO.getJsonResponse().toString(), 1003,httpCode,"EIIS");
			DatabaseUtil.updateEventDetails(requestBO.getRid(), 1007);

			EiisDetailsSyncTaskManager.getInstance().updateDetailsMap(requestBO.getRid(), TaskStatus.Success.name());
		}
		logger.debug("Exiting run() method.");
	}

	@Override
	public String getRequestId() {
		return requestBO.getRid();
	}

	@Override
	public String getRequestType() {
		return RequestType.DetailsBySystem.name();
	}
}