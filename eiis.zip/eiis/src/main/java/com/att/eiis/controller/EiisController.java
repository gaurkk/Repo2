package com.att.eiis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.EiisOrderBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.exception.EiisServiceException;
import com.att.eiis.service.EiisService;

import io.swagger.annotations.ApiOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class EiisController {

	Logger logger = LoggerFactory.getLogger(EiisController.class);

	@Autowired
	EiisService eiisService;
	
	@GetMapping(value = { "/healthCheckStatus/{test}", "/healthCheckStatus" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Health Check Status", notes = "Health Check Status")
	public String getHealthCheckStatus(@PathVariable String test) {
		logger.info("Starting method getHealthCheckStatus : ", this);
		String healthCheckStatusCode = null;
		if (test.equalsIgnoreCase("test")) {
			healthCheckStatusCode = "200 Success";
		} else {
			healthCheckStatusCode = "500 Failure"; // Failure
		}
		logger.info("Exiting method getHealthCheckStatus : ", this);
		return healthCheckStatusCode;
	}

	@PostMapping(value = "/createrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Create AMP Request", notes = "Create AMP Request")
	public AmpResponseBO create(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling CREATE METHOD START", this);
		EiisOrderBO orderBO = new EiisOrderBO();
		orderBO.setOrderId(orderId.toString());
		AmpResponseBO responseBO;
		try {
			responseBO = eiisService.create(orderBO,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while creating order for ID : "+ orderBO.getOrderId(), e);
		}
		logger.info("Calling CREATE METHOD END", this);
		return responseBO;
	}

	@PostMapping(value = "/cancelrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Cancel AMP Request", notes = "Cancel AMP Request")
	public AmpResponseBO cancel(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling cancel METHOD START", this);
		EiisOrderBO orderBO = new EiisOrderBO();
		orderBO.setOrderId(orderId.toString());
		AmpResponseBO responseBO;
		try {
			responseBO = eiisService.cancel(orderBO,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while canceling order for request id : "+ orderBO.getOrderId() + ".", e);
		}
		logger.info("Calling cancel METHOD END", this);
		return responseBO;
	}

	@PostMapping(value = "/login", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Login AMP Request", notes = "Login AMP Request")
	public String login(@RequestBody UserBean userBO) throws EiisDataException,EiisServiceException{
		String token = null;
		try {
			 token = eiisService.login(userBO,null,null,1);
		} catch (Exception e) {
			throw new EiisDataException("Error while login to AMP server.", e);
		}
		return token;
	}

	@PostMapping(value = "/statusrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Status AMP Request", notes = "Status AMP Request")
	public AmpResponseBO getStatusById(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling statusrequest getDetailsById METHOD START", this);
		EiisOrderBO eiisOrderBO = new EiisOrderBO();
		eiisOrderBO.setOrderId(orderId.toString());
		AmpResponseBO responseBO;
		try {
			responseBO = eiisService.status(eiisOrderBO,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while fetching order status for request id : "+ eiisOrderBO.getOrderId(), e);
		}
		logger.info("Calling statusrequest getDetailsById METHOD END", this);
		return responseBO;
	}

	@PostMapping(value = "/detailrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Login AMP Request", notes = "Login AMP Request")
	public AmpResponseBO getDetailsById(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling detailrequest getDetailsById METHOD START", this);
		EiisOrderBO orderIdObject = new EiisOrderBO();
		orderIdObject.setOrderId(orderId.toString());
		if (orderIdObject == null || orderIdObject.getOrderId() == null || orderIdObject.getOrderId().isEmpty()) {
			throw new EiisDataException("Request Id can not be null / empty.");
		}
		AmpResponseBO responseBO;
		try {
			responseBO = eiisService.details(orderIdObject,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while fetching order details for request id : "+ orderIdObject.getOrderId(), e);
		}
		logger.info("Calling detailrequest getDetailsById METHOD END", this);
		return responseBO;
	}
	@PostMapping(value = "/skiprequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Skip AMP Request", notes = "Skip AMP Request")
	public AmpResponseBO skip(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling SKIP METHOD START", this);
		EiisOrderBO orderBO = new EiisOrderBO();
		orderBO.setOrderId(orderId.toString());
		AmpResponseBO responseBO;
		try {
			responseBO = eiisService.skip(orderBO, attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while skiping order for ID : "+ orderBO.getOrderId(), e);
		}
		logger.info("Calling SKIP METHOD END", this);
		return responseBO;
	}
	
	@PostMapping(value = "/accacreaterequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Create Account AMP Request", notes = "Create Account AMP Request")
	public List<AmpResponseBO> createAcca(@PathVariable Long orderId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling accacreaterequest createAcca METHOD START", this);
		EiisOrderBO orderIdObject = new EiisOrderBO();
		orderIdObject.setOrderId(orderId.toString());
		List<AmpResponseBO> responseBO;
		try {
			responseBO = eiisService.createAccaRequest(orderIdObject,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while creating order for ID : "
					+ orderIdObject.getOrderId(), e);
		}
		logger.info("Calling accacreaterequest createAcca METHOD END", this);
		return responseBO;
	}


	@PostMapping(value = "/accastatusrequest/{orderId}/{requestId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Account Status AMP Request", notes = "Account Status AMP Request")
	public AmpResponseBO getAccaStatusById(@PathVariable Long orderId,@PathVariable String requestId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling accastatusrequest createAcca METHOD START", this);
		EiisOrderBO orderBO = new EiisOrderBO();
		orderBO.setOrderId(orderId.toString());
		RequestBO requestBO = new RequestBO();
		requestBO.setRid(requestId);
		
		AmpResponseBO responseBO=null;
		try {
			responseBO = eiisService.accaStatus(requestBO,orderBO,attuid);

		} catch (Exception e) {
			throw new EiisDataException("Error while fetching order status for request id : "+ requestBO.getRid(), e);
		}
		logger.info("Calling accastatusrequest createAcca METHOD END", this);
		return responseBO;
	}

	@PostMapping(value = "/accadetailrequest/{orderId}/{requestId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Account Details AMP Request", notes = "Account Details AMP Request")
	public AmpResponseBO getAccaDetailsById(@PathVariable Long orderId,@PathVariable String requestId,@PathVariable String attuid) throws EiisDataException,EiisServiceException{
		logger.info("Calling accadetailrequest createAcca METHOD START", this);
		EiisOrderBO orderBO = new EiisOrderBO();
		orderBO.setOrderId(orderId.toString());
		RequestBO requestBO = new RequestBO();
		requestBO.setRid(requestId);
		AmpResponseBO responseBO=null;
		try {
			responseBO = eiisService.accaDetails(requestBO,orderBO,attuid);
		} catch (Exception e) {
			throw new EiisDataException("Error while fetching order details for request id : "+ requestBO.getRid(), e);
		}
		logger.info("Calling accadetailrequest createAcca METHOD END", this);
		return responseBO;
	}
}