package com.att.eiis.util;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


@Configuration
@PropertySource("classpath:/MessageResources_en.properties")
public class MessageConfigProperties {

}
