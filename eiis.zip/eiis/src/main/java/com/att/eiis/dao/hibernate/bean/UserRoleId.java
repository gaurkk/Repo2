package com.att.eiis.dao.hibernate.bean;


import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for UserRoleId.
 */
@Embeddable
public class UserRoleId implements java.io.Serializable {

	private static final long serialVersionUID = 2111505058117209958L;
	
	private String attuid;
	private Long roleId;

	/**
	 * No-argument constructor of the class.
	 */
	public UserRoleId() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * @param attuid
	 * @param roleId
	 */
	public UserRoleId(String attuid, Long roleId) {
		this.attuid = attuid;
		this.roleId = roleId;
	}

	/**
	 * Getter method for attuid. ATTUID mapped to ATTUID in the database table.
	 * @return String
	 */
	@Column(name = "ATTUID", nullable = false, length = 6)
	public String getAttuid() {
		return this.attuid;
	}

	/**
	 * @param attuid to attuid set.
	 */
	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	/**
	 * Getter method for roleId. ROLE_ID mapped to ROLE_ID in the database table.
	 * @return Long
	 */
	@Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)
	public Long getRoleId() {
		return this.roleId;
	}

	/**
	 * @param roleId to roleId set.
	 */
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof UserRoleId))
			return false;
		UserRoleId castOther = (UserRoleId) other;

		return ((this.getAttuid() == castOther.getAttuid()) || (this
				.getAttuid() != null
				&& castOther.getAttuid() != null && this.getAttuid().equals(
				castOther.getAttuid())))
				&& (this.getRoleId() == castOther.getRoleId());
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAttuid() == null ? 0 : this.getAttuid().hashCode());
		return result;
	}

}
