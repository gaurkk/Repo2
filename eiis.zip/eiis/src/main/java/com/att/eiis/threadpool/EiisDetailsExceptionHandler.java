package com.att.eiis.threadpool;

import java.lang.Thread.UncaughtExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.request.AmpRequest;
import com.att.eiis.scheduler.EiisDetailsSyncTaskManager;
import com.att.eiis.util.TaskStatus;

/**
 * This class is to handle any uncaught exception in the thread 
 * created to fetch the details of the order 
 */
public class EiisDetailsExceptionHandler implements UncaughtExceptionHandler {

	private static Logger logger = LoggerFactory.getLogger(EiisDetailsExceptionHandler.class);

	@Override
	public void uncaughtException(Thread thread, Throwable exception) {
		logger.debug("Entering uncaughtException() method.");
		if (thread instanceof AmpRequest) {
			AmpRequest restRequest = (AmpRequest) thread;
			String requestId = restRequest.getRequestId();
			logger.debug("Thread - " + requestId + " is failed and caught in the exception handler.");
			EiisDetailsSyncTaskManager.getInstance().updateDetailsMap(requestId, TaskStatus.Failure.name());
		}
		logger.debug("Exiting uncaughtException() method.");
	}
}
