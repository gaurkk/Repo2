package com.att.eiis.scheduler;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.bean.RequestBO;
import com.att.eiis.email.EmailUtils;
import com.att.eiis.request.DetailsRequest;
import com.att.eiis.request.NotifyCometRequest;
import com.att.eiis.threadpool.EiisDetailsExceptionHandler;
import com.att.eiis.threadpool.EiisStatusExceptionHandler;
import com.att.eiis.threadpool.EiisThreadPoolExecutor;
import com.att.eiis.threadpool.EiisThreadPoolManager;
import com.att.eiis.util.DatabaseUtil;
import com.att.eiis.util.RequestType;
import com.att.eiis.util.TaskStatus;

/**
 * This is the manager class which actually invoke the threads to sync the 
 * details of the order based on provided request ids. Once execution is done 
 * this class also responsible to notify the COMET application for 
 * further processing.
 */
@Component
public class EiisDetailsSyncTaskManager {

	private ConcurrentHashMap<String, String> detailsHashMap = null;
	private static EiisDetailsSyncTaskManager detailsTaskManager = null;
	private static Logger logger = LoggerFactory.getLogger(EiisDetailsSyncTaskManager.class);

	private EiisDetailsSyncTaskManager() {
		logger.info("Initializing hash map.");
		detailsHashMap = new ConcurrentHashMap<String, String>();
	}

	/**
	 * Singleton instance 
	 * @return instance
	 */
	public static EiisDetailsSyncTaskManager getInstance() {
		logger.debug("Initializing instance.");
		if (detailsTaskManager == null) {
			synchronized(EiisDetailsSyncTaskManager.class) {
				if (detailsTaskManager == null) {
					detailsTaskManager = new EiisDetailsSyncTaskManager();
					logger.info("Instance initialized.");
				}
			}
		}
		logger.debug("Returning initialized instance.");
		return detailsTaskManager;
	}

	/**
	 * Adding / updating mappings in this map is responsibility of 
	 * each thread / job invoked by this manager
	 * 
	 * [{"requestId1":"Successful"}, {"requestId2":"Failed"}]
	 * @param key - request id
	 * @param value - task status
	 */
	public synchronized void updateDetailsMap(String key, String value) {
		logger.debug("Starting updateDetailsMap() method.");
		
		if (detailsHashMap.containsKey(key)) {
			detailsHashMap.replace(key, value);
		} else {
			detailsHashMap.put(key, value);
		}
		logger.debug("Exiting updateDetailsMap() method.");
	}

	/**
	 * This method is to cleanup the map before each execution of task
	 * kept this method as default so that it doesn't get called 
	 * from outside package
	 */
	void cleanupDetailsMap() {
		logger.debug("Starting cleanupDetailsMap() method.");
		
		if (detailsHashMap != null) { 
			detailsHashMap.clear();
		}
		logger.debug("Exiting cleanupDetailsMap() method.");
	}

	/**
	 * Invokes the thread for details request
	 * @param requestIdList
	 */
	public void initiateTaskForGivenIds(List<String> requestIdList) {
		logger.debug("Starting initiateTaskForGivenIds() method.");
		
		if (requestIdList != null && requestIdList.size() > 0) {
			logger.debug("Got : " + requestIdList.size() + " records of request ids.");
	
			for (String requestId : requestIdList) {
				logger.debug("Invoking thread for request id : " + requestId);
				
				RequestBO reqObject = new RequestBO();
				reqObject.setRid(requestId);
				DetailsRequest detailsRequest = new DetailsRequest(reqObject);
				EiisDetailsExceptionHandler exceptionHandler = new EiisDetailsExceptionHandler();
				detailsRequest.setUncaughtExceptionHandler(exceptionHandler);
	
				try {
					EiisThreadPoolManager.invokeThread(detailsRequest);
					logger.debug("Thread for request id : " + requestId + " executed successfully.");
				} catch (Exception e) {
					logger.error("Error while invoking thread for request id : " + requestId, e);
					throw new RuntimeException(e);
				}
			}
	
			List<String> successfulRequests = null;
			List<String> failedRequests = null;
			while (true) {
				if (detailsHashMap.size() >= requestIdList.size()) {
					
					logger.debug("Creating list of request ids for successful execution .");
					
					Set<Entry<String, String>> entrySet = detailsHashMap.entrySet();
					for (Entry<String, String> entry : entrySet) {
						if (TaskStatus.Success.name().equals(entry.getValue())) {
							if (successfulRequests == null) {
								successfulRequests = new ArrayList<String>();
							}
							successfulRequests.add(entry.getKey());
							logger.debug("AMP request successful for request id : " + entry.getKey());
						} else {
							if (failedRequests == null) {
								failedRequests = new ArrayList<String>();
							}
							failedRequests.add(entry.getKey());
							//logging for failed requests
							logger.warn("AMP request got failed for request id : " + entry.getKey());
						}
					}
					break;
				} else {
					//wait for some time for map to get updated for all the requests
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						logger.warn("Error in waiting for thread.");
					}
				}
			}

			//Gives the call to the REST service exposed by COMET
			if (successfulRequests != null && successfulRequests.size() > 0) {
				logger.debug("Notifiying to COMET for successful execution of : " + successfulRequests.size() + " request ids.");
				
				notifyCometRestServer(successfulRequests);
				logger.debug("Notified to COMET for successful execution of request id ");
			}

			//Notify COMET support for failed requests
			if (failedRequests != null && failedRequests.size() > 0) {
				logger.debug("Notifiying to COMET support for failed execution of : " + failedRequests.size() + " request ids.");
				
				notifyCometSupport(failedRequests);
				
				logger.debug("Notified to COMET support for failed execution of request ids :");
			}
		}
		logger.debug("Exiting initiateTaskForGivenIds() method.");
	}

	/**
	 * REST call to COMET server for successful requests
	 * @param successfulRequests
	 */
	private void notifyCometRestServer(List<String> successfulRequests) {
		logger.debug("Starting notifyCometRestServer() method ");

		//Creating unique request id to distinguish it from other requests
		//Request Id Value example : "Friday, September 16, 2016 3:16:48 PM IST >> 8"
		String requestId = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL).format(new Date()) + " >> " + successfulRequests.size();

		//Notify COMET server for further processing of order details
		NotifyCometRequest notifyCometRequest = new NotifyCometRequest(successfulRequests, requestId);
		EiisDetailsExceptionHandler exceptionHandler = new EiisDetailsExceptionHandler();
		notifyCometRequest.setUncaughtExceptionHandler(exceptionHandler);

		try {
			EiisThreadPoolManager.invokeThread(notifyCometRequest);
			logger.debug("Notify Comet thread for :" + requestId + " executed successfully.");
			
		} catch (Exception e) {
			logger.error("Error while invoking notify comet thread for request id : " + requestId, e);
			throw new RuntimeException(e);
		}
		logger.debug("Exiting notifyCometRestServer() method.");
	}

	/**
	 * Send email to COMET support for failed requests
	 * @param failedRequests
	 */
	private void notifyCometSupport(List<String> failedRequests) {
		logger.debug("Entering notifyCometSupport() method............................");
		
		List<String> failedOrders = DatabaseUtil.getOrderIdForRequestId(failedRequests);
		EmailUtils.sendDynamicllyCreatedEmail(3L, failedOrders, RequestType.DetailsBySystem);
		logger.debug("Exiting notifyCometSupport() method................................");
	}
}