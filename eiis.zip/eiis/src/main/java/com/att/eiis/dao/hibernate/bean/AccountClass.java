package com.att.eiis.dao.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Account persistence class. Mapped with the ACCOUNT_CLASS table in database.
 */
@Entity
@Table(name = "ACCOUNT_CLASS")
public class AccountClass implements java.io.Serializable {
	private static final long serialVersionUID = -7434062488056033846L;

	private Long accountClassId;
	private String accountClassName;
	private Set<MasterAccount> masterAccounts = new HashSet<MasterAccount>(0);
	private Set<InternalProductAccount> internalProductAccounts = new HashSet<InternalProductAccount>(0);

	/**
	 * Getter method of AccountClassId. ACCOUNT_CLASS_ID mapped with
	 * ACCOUNT_CLASS_ID in the database
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ACCOUNT_CLASS_ID", nullable = false, precision = 12, scale = 0)
	public Long getAccountClassId() {
		return this.accountClassId;
	}

	/**
	 * Setter method for the accountClassId.
	 * 
	 * @param accountClassId
	 *            to accountClassId set.
	 */
	public void setAccountClassId(Long accountClassId) {
		this.accountClassId = accountClassId;
	}

	/**
	 * Getter method of AccountClassName. ACCOUNT_CLASS_NAME mapped with
	 * ACCOUNT_CLASS_NAME in the database
	 * 
	 * @return String
	 */
	@Column(name = "ACCOUNT_CLASS_NAME", nullable = false, length = 100)
	public String getAccountClassName() {
		return this.accountClassName;
	}

	/**
	 * Setter method for the accountClassName.
	 * 
	 * @param accountClassName
	 *            to accountClassName set.
	 */
	public void setAccountClassName(String accountClassName) {
		this.accountClassName = accountClassName;
	}

	/**
	 * @return Set<MasterAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "accountClass")
	public Set<MasterAccount> getMasterAccounts() {
		return this.masterAccounts;
	}

	/**
	 * @param masterAccounts
	 *            to masterAccounts set.
	 */
	public void setMasterAccounts(Set<MasterAccount> masterAccounts) {
		this.masterAccounts = masterAccounts;
	}

	/**
	 * @return Set<InternalProductAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "accountClass")
	public Set<InternalProductAccount> getInternalProductAccounts() {
		return this.internalProductAccounts;
	}

	/**
	 * @param internalProductAccounts
	 *            to internalProductAccounts set.
	 */
	public void setInternalProductAccounts(
			Set<InternalProductAccount> internalProductAccounts) {
		this.internalProductAccounts = internalProductAccounts;
	}
}