package com.att.eiis.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AccaJson {

	private String workflowType;
	private RequestParameters requestParameters;
	
}
