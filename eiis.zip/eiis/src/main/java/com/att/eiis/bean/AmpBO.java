package com.att.eiis.bean;

import java.io.Serializable;
import java.util.Map;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode
public class AmpBO implements Serializable {

	private static final long serialVersionUID = 1L;

	private int rid;
	private String workflow;
	private String description;
	private Map<String, String> variables;
}