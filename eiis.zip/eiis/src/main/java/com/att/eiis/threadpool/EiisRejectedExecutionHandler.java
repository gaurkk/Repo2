package com.att.eiis.threadpool;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.request.AmpRequest;

/**
 * This class is to handle the threads for which their execution is 
 * rejected due to thread pool is not initialized / shutdown. 
 */
public class EiisRejectedExecutionHandler implements RejectedExecutionHandler {

	private static Logger logger = LoggerFactory.getLogger(EiisRejectedExecutionHandler.class);

	@Override
	public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {
		logger.debug("Entering rejectedExecution() method.");
		if (runnable instanceof AmpRequest) {
			AmpRequest restRequest = (AmpRequest) runnable;
			logger.debug("Rejected task with request " + restRequest.getName());

			// Will start the rejected thread again
			try {
				final Thread newThread = new Thread(runnable, "Rejected task for " 
						+ restRequest.getName() + " executor");
				newThread.start();
				logger.debug("Started new thread for rejected thread : " + restRequest.getName());
			} catch (Throwable e) {
				logger.error("Failed to start a new thread", e);
				throw new RejectedExecutionException("Failed to start a new thread", e);
			}
		}
		logger.debug("Exiting rejectedExecution() method.");
	}
}