package com.att.eiis.service;


/**
 * Marker interface for Eiis service classes.
 * 
 */
public interface GenericEiisService {

}
