package com.att.eiis.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMAIL_TEMPLATE_INFORMATION")
public class FetchEmailTemplateInfo {
	Long emailTemplateId;
	String emailTempateName;
	String fromUser;
	String toList;
	String ccList;
	String messageHeader;
	String messageFooter;
	String message;
	String subject;
	
	@Id
	@Column(name = "EMAIL_TEMPLATE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getEmailTemplateId() {
		return emailTemplateId;
	}
	public void setEmailTemplateId(Long emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	@Column(name = "EMAIL_TEMPLATE_NAME")
	public String getEmailTempateName() {
		return emailTempateName;
	}
	public void setEmailTempateName(String emailTempateName) {
		this.emailTempateName = emailTempateName;
	}
	
	@Column(name = "FROM_USER")
	public String getFromUser() {
		return fromUser;
	}
	public void setFromUser(String fromUser) {
		this.fromUser = fromUser;
	}
	
	@Column(name = "TO_LIST")
	public String getToList() {
		return toList;
	}
	public void setToList(String toList) {
		this.toList = toList;
	}
	
	@Column(name = "CC_LIST")
	public String getCcList() {
		return ccList;
	}
	public void setCcList(String ccList) {
		this.ccList = ccList;
	}
	
	@Column(name = "MESSAGE_HEADER")
	public String getMessageHeader() {
		return messageHeader;
	}
	public void setMessageHeader(String messageHeader) {
		this.messageHeader = messageHeader;
	}
	
	@Column(name = "MESSAGE_FOOTER")
	public String getMessageFooter() {
		return messageFooter;
	}
	public void setMessageFooter(String messageFooter) {
		this.messageFooter = messageFooter;
	}
	
	@Column(name = "MESSAGE")
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Column(name = "SUBJECT")
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

}
