package com.att.eiis.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;

import com.att.eiis.bean.RequestBO;
import com.att.eiis.util.AmpSimpleClientHttpRequestFactory;

public class HttpRestTemplate {
	private static Logger logger = LoggerFactory.getLogger(HttpRestTemplate.class);

	public static Map<String, Object> postForEntity(String ampURL,RequestBO reqObject, String methodType,String certificateName) {
		logger.info("Start methode  postForEntity:",ampURL);
		Map<String, Object> map = new HashMap<String, Object>();
		map = getResponseMap(getHttpsURLConnectionInstance(ampURL, methodType,certificateName),
				reqObject);
		
		logger.info("Exit methode  postForEntity:");
		return map;
	}

	public static Map<String, Object> postForEntity(String ampURL,String ampJson, String methodType,String certificateName) {
		logger.info("Start methode  postForEntity:",ampURL);
		Map<String, Object> map = new HashMap<String, Object>();
		map = getResponseMap(getHttpsURLConnectionInstance(ampURL, methodType,certificateName),
				ampJson);
		
		logger.info("Exit methode  postForEntity:");
		return map;
	}

	private static HttpsURLConnection getHttpsURLConnectionInstance(
			String ampUrl, String methodType,String certificateName) {
		logger.info("Start methode  getHttpsURLConnectionInstance:",ampUrl);
		HttpsURLConnection httpConnection = null;
		try {
			URL url = new URL(ampUrl);
			httpConnection = (HttpsURLConnection) url.openConnection();
			httpConnection
					.setSSLSocketFactory(AmpSimpleClientHttpRequestFactory
							.cert(certificateName).getSocketFactory());
			httpConnection
					.setHostnameVerifier(AmpSimpleClientHttpRequestFactory.ALL_TRUSTING_HOSTNAME_VERIFIER);
			httpConnection.setRequestMethod(methodType);
			httpConnection.setDoOutput(true);
			httpConnection.setUseCaches(false);
			httpConnection.setRequestProperty("Content-Type",
					"application/json");

		} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.debug("Exit methode getHttpsURLConnectionInstance");
		return httpConnection;
	}

	private static Map<String, Object> getResponseMap(
			HttpsURLConnection httpConnection, Object T) {
		logger.info("Start methode getResponseMap");
		Map<String, Object> map = new HashMap<String, Object>();
		OutputStream out = null;
		int responseCode = 0;
		try {
			if (httpConnection.getRequestMethod() == "POST") {
				out = httpConnection.getOutputStream();
				out.write(T.toString().getBytes());
				out.close();
			}
			
			responseCode = ((HttpsURLConnection) httpConnection)
					.getResponseCode();
			BufferedReader br;
			if (responseCode == 200) {
				br = new BufferedReader(new InputStreamReader(
						((HttpsURLConnection) httpConnection).getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(
						((HttpsURLConnection) httpConnection).getErrorStream()));
			}
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line + "\n");
			}
			br.close();
			map.put("result", sb.toString());
			map.put("RESPONSE_CODE", responseCode);
		} catch (MalformedURLException e) {
			map.put("RESPONSE_CODE", 0);
			map.put("result", e);
			e.printStackTrace();
		} catch (IOException e) {
			map.put("RESPONSE_CODE", 0);
			map.put("result", e);
			e.printStackTrace();
		} catch (Exception e) {
			map.put("RESPONSE_CODE", 0);
			map.put("result", e);
			e.printStackTrace();
		}
		logger.debug("Exit methode getResponseMap");
		return map;
	}
}