package com.att.eiis.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;

import com.att.eiis.bean.CspResponseBO;
import com.att.eiis.bean.CspUser;
import com.att.eiis.constants.EiisCommonConstants;

import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;

@Component
public class CspCookies {
	Logger logger = LoggerFactory.getLogger(CspCookies.class);
	
	public CspResponseBO getCSPCookies(String CSPLoginUrl,String cSPmonitorId,String cSPmonitorPassword, String mechID) {
		//String CSPLoginUrl = "https://www.e-access.att.com/empsvcs/hrmonitor/?retURL=http://comet-mcs.it.att.com:8008/Comet/index.jsp";
		Map<String, String> cookies = new HashMap<String, String>();
		
		logger.debug("CSPLoginUrl for Cookies ... !"+ CSPLoginUrl);
		logger.debug("CSPmonitorId for Cookies ... !"+ cSPmonitorId);
		logger.debug("CSPmonitorPassword for Cookies ... !"+ cSPmonitorPassword);
		logger.debug("MechID for Cookies ... ! "+ mechID);
		
		HttpClient client = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(CSPLoginUrl);
		post.setHeader("User-Agent", "Mozilla/4.0");
		post.setHeader("Accept", "application/x-www-form-urlencoded");

		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair(EiisCommonConstants.CSPMONITOR_ID,cSPmonitorId));
		urlParameters.add(new BasicNameValuePair(EiisCommonConstants.CSPMONITOR_PASSWORD,cSPmonitorPassword));
		urlParameters.add(new BasicNameValuePair(EiisCommonConstants.MECHID, mechID));
		
		post.setEntity(new UrlEncodedFormEntity(urlParameters, Consts.UTF_8));
	
		HttpResponse response;
		CspResponseBO responseBo = null;
		try {
			response = client.execute(post);
			logger.debug("CSP Response header:"+response.getAllHeaders(), this);

			Header[] headers = response.getAllHeaders();
			for (Header header : headers) {
				if (header.getName().equalsIgnoreCase("Set-Cookie")) {
					StringTokenizer st = new StringTokenizer(header.getValue(),";");
					if (st.hasMoreTokens()) {
						String token = st.nextToken();
						String name = token.substring(0,token.indexOf(EiisCommonConstants.NAME_VALUE_SEPARATOR));
						String value = token.substring(token.indexOf(EiisCommonConstants.NAME_VALUE_SEPARATOR) + 1,token.length());
						logger.debug("CSP Response token:"+token, this);
						cookies.put(name, value);
					}
				}
			}

			CspUser user = new CspUser(cookies.get("attESSec"),cookies.get("attESHr"));
			responseBo = new CspResponseBO(user);

			if (cookies.get("attESSec") != null) {
				logger.debug("cookies of attESSec" + cookies.get("attESSec"));
			} else {
				logger.error("cookies of attESSec are null");
			}
			if (cookies.get("attESHr") != null) {
				logger.debug("cookies of attESHr" + cookies.get("attESHr"));
			} else {
				logger.error("cookies of attESHr are null");
			}
			logger.debug("cookies set inside response BO");

		} catch (ClientProtocolException e) {
			logger.error("Client Protocal Exception catch on POST CAll ::"+e.getMessage()+" ::Exception ::"+e);
		} catch (IOException e) {
			logger.error("IO Exception catch on POST CAll ::"+e.getMessage()+" ::Exception ::"+e);
		} catch(Exception e) {
			logger.error("Exception catch on POST CAll ::"+e.getMessage()+" ::Exception ::"+e);
		}

		return responseBo;
	}

}
