package com.att.eiis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.eiis.dao.hibernate.bean.Users;


@Repository
public interface UserRepository extends JpaRepository<Users, String> {
	
	Users findByAttuid(String attuid);
	
	List<Users> findByUserRoles_ItOpsDefault(String itOpSDefault);
}
