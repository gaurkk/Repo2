package com.att.eiis.threadpool;

import java.lang.Thread.UncaughtExceptionHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.eiis.request.AmpRequest;
import com.att.eiis.scheduler.EiisStatusSyncTaskManager;
import com.att.eiis.util.TaskStatus;

/**
 * This class is to handle any uncaught exception in the thread 
 * created to fetch the status of the order 
 */
public class EiisStatusExceptionHandler implements UncaughtExceptionHandler {

	private static Logger logger = LoggerFactory.getLogger(EiisStatusExceptionHandler.class);

	@Override
	public void uncaughtException(Thread thread, Throwable exception) {
		logger.debug("Entering uncaughtException() method.");

		if (thread instanceof AmpRequest) {
			AmpRequest restRequest = (AmpRequest) thread;
			String requestId = restRequest.getRequestId();
			logger.debug("Thread - " + requestId + " is failed and caught in the exception handler.");
			EiisStatusSyncTaskManager.getInstance().updateStatusMap(requestId, TaskStatus.Failure.name());
		}
		logger.debug("Exiting uncaughtException() method.");
	}
}
