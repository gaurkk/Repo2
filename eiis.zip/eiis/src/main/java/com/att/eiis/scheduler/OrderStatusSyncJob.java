package com.att.eiis.scheduler;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.util.DatabaseUtil;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


/**
 * This job will perform following tasks: 1) Fetch the details of job qualified
 * for status sync 2) Invoke the manager to sync status by providing details.
 */
@Component
public class OrderStatusSyncJob implements Job {

	private static Logger logger = LoggerFactory.getLogger(OrderStatusSyncJob.class);

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		logger.debug("Starting execute() method.");
		List<String> applicableRequestIds = getRequstIdListForStatus();
		if (applicableRequestIds != null && !applicableRequestIds.isEmpty()) {
			logger.debug("Got " + applicableRequestIds.size()+ " records of request ids.");
			
			executeSyncTask(applicableRequestIds);
		} else {
			logger.debug("No data found for syncing of order status.");
		}
	}

	/**
	 * Method to execute sync task
	 * 
	 * @param applicableRequestIds
	 */
	protected void executeSyncTask(List<String> applicableRequestIds) {
		logger.debug("Starting executeSyncTask() method.");
		EiisStatusSyncTaskManager manager = EiisStatusSyncTaskManager.getInstance();
		// This should always get cleared to store new mapping
		manager.cleanupStatusMap();
		manager.initiateTaskForGivenIds(applicableRequestIds);
		logger.debug("Exiting executeSyncTask() method.");
	}

	/**
	 * Database call to fetch list of all applicable request ids
	 * 
	 * @return list of request ids
	 */
	private List<String> getRequstIdListForStatus() {
		logger.debug("Starting getRequstIdListForStatus() method.");

		List<String> requestIds = DatabaseUtil.getApplicableRequestIdsForStatusSync();
		logger.debug("Exiting getRequstIdListForStatus() method with : "+ (requestIds != null ? requestIds.size() : 0) + " results.");
		return requestIds;
	}
}