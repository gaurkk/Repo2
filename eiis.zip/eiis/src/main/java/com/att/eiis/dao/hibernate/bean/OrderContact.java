package com.att.eiis.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderContact. Mapped to ORDER_CONTACT table in the
 * database.
 */
@Entity
@Table(name = "ORDER_CONTACT")
public class OrderContact implements Serializable {

	private static final long serialVersionUID = -5782991997163683469L;

	private long orderContactId;
	
	private DapnInventory dapnInventory;
	
	private Orders orders;
	private String deploymentInstruction;
	private Set<OrderContactInfo> orderContactInfos = new HashSet<OrderContactInfo>(
			0);

	/**
	 * Getter method for orderContactId. ORDER_CONTACT_ID mapped to
	 * ORDER_CONTACT_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_CONTACT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_CONTACT_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ORDER_CONTACT_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_CONTACT_ID")
	public Long getOrderContactId() {
		return this.orderContactId;
	}

	/**
	 * @param orderContactId
	 *            to orderContactId set.
	 */
	public void setOrderContactId(Long orderContactId) {
		this.orderContactId = orderContactId;
	}

	/**
	 * Getter method for dedicatedApn.
	 * 
	 * @return DedicatedApn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "APN_ID")
	public DapnInventory getDapnInventory() {
		return this.dapnInventory;
	}

	/**
	 * @param dedicatedApn
	 *            to dedicatedApn set.
	 */
	public void setDapnInventory(DapnInventory dapnInventory) {
		this.dapnInventory = dapnInventory;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID")
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for deploymentInstruction. DEPLOYMENT_INSTRUCTION mapped to
	 * DEPLOYMENT_INSTRUCTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DEPLOYMENT_INSTRUCTION", length = 3500)
	public String getDeploymentInstruction() {
		return this.deploymentInstruction;
	}

	/**
	 * @param deploymentInstruction
	 *            to deploymentInstruction set.
	 */
	public void setDeploymentInstruction(String deploymentInstruction) {
		this.deploymentInstruction = deploymentInstruction;
	}

	/**
	 * Getter method for orderContactInfos.
	 * 
	 * @return Set<OrderContactInfo>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orderContact")
	public Set<OrderContactInfo> getOrderContactInfos() {
		return this.orderContactInfos;
	}

	/**
	 * @param orderContactInfos
	 *            to orderContactInfos set.
	 */
	public void setOrderContactInfos(Set<OrderContactInfo> orderContactInfos) {
		this.orderContactInfos = orderContactInfos;
	}
}