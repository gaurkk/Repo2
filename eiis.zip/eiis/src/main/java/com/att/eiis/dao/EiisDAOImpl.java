package com.att.eiis.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.sql.Clob;
import java.sql.NClob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.sql.rowset.serial.SerialClob;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.engine.jdbc.NonContextualLobCreator;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.att.eiis.constants.EiisCommonConstants;
import com.att.eiis.constants.EiisScalarConstants;
import com.att.eiis.dao.hibernate.bean.AdminConfig;
import com.att.eiis.dao.hibernate.bean.DataCenter;
import com.att.eiis.dao.hibernate.bean.EiisConfiguration;
import com.att.eiis.dao.hibernate.bean.EventStatus;
import com.att.eiis.dao.hibernate.bean.EventType;
import com.att.eiis.dao.hibernate.bean.ExternalInterfaceDetails;
import com.att.eiis.dao.hibernate.bean.ExternalInterfaceEventLogs;
import com.att.eiis.dao.hibernate.bean.ExternalInterfaceEventStatuses;
import com.att.eiis.dao.hibernate.bean.FetchEmailTemplateInfo;
import com.att.eiis.dao.hibernate.bean.OrderDataCenter;
import com.att.eiis.dao.hibernate.bean.OrderDataCenterId;
import com.att.eiis.dao.hibernate.bean.Orders;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.exception.EiisServiceException;
import com.att.eiis.repository.AdminConfigRepository;
import com.att.eiis.repository.EiisConfigurationRepository;
import com.att.eiis.repository.ExtInEventStatusesRepository;
import com.att.eiis.repository.ExtIntEventLogsRepository;
import com.att.eiis.repository.ExtInterfaceDetailsRepository;
import com.att.eiis.repository.FetchEmailTemplateInfoRepository;
import com.att.eiis.repository.OrderDataCenterRepository;
import com.att.eiis.repository.OrderRepository;
import com.att.eiis.util.EiisServerUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.att.eiis.amp.AmpRequestClient;
import com.att.eiis.bean.AccaAmpResponseBO;
import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.bean.EiisOrderBO;
import com.att.eiis.bean.RequestBO;
import com.att.eiis.bean.UserBean;

@Component
public class EiisDAOImpl implements EiisDAO {
	private static final Logger logger = LoggerFactory.getLogger(EiisDAOImpl.class);

	@PersistenceContext
	EntityManager em;

	@Autowired
	AdminConfigRepository adminConfigRepository;

	@Autowired
	EiisConfigurationRepository eiisConfigurationRepository; 

	@Autowired
	AmpRequestClient ampRequestClient;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	ExtInterfaceDetailsRepository extInterfaceDetailsRepository;

	@Autowired
	ExtInEventStatusesRepository extInEventStatusesRepository;

	@Autowired
	OrderDataCenterRepository orderDataCenterRepository;

	@Autowired
	EiisHelper eiisHelper;

	@Autowired
	FetchEmailTemplateInfoRepository fetchEmailTemplateInfoRepository;

	@Autowired
	EiisServerUtil eiisServerUtil;

	@Autowired
	ExtIntEventLogsRepository extIntEventLogsRepository;

	@Override
	public AmpResponseBO create(EiisOrderBO eiisOrderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode create :",this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String ampRequest = null;
		String orderStatus = null;
		String httpCode = null;
		EventType eventType =null;
		EventStatus eventStatus =null;
		Orders orders =null;
		Long eventStatusId = 1001L;
		RequestBO requestBO = new RequestBO();
		requestBO.setRid(null);

		try {
			if(null != eiisOrderBO) {
				Query query = em.createNativeQuery(EiisCommonConstants.REQUEST_FOR_ORDER_ID);
				query.setParameter(EiisCommonConstants.ORDER_ID, eiisOrderBO.getOrderId());
				Clob clob=(Clob)query.getSingleResult();

				StringBuffer str = new StringBuffer();
				String strng;

				BufferedReader bufferRead = new BufferedReader(clob.getCharacterStream());
				while ((strng=bufferRead.readLine())!=null)
					str.append(strng);
				ampRequest= str.toString();
			}

			ampResponseBO = getAmpResponseDetails(requestBO,eiisOrderBO,ampRequest,"Create");
			orders = orderRepository.findByOrderId(Long.valueOf(eiisOrderBO.getOrderId()));
			if(null != orders) {
				orderStatus = orders.getOrderStatus().getOrderStatusName();
			}

			if (ampResponseBO.getException() != null) {
				String errMsg = "Order -> ID : " + eiisOrderBO.getOrderId();

				String uuid = generateUUID(8);
				if(ampResponseBO.getHTTP_CODE()!= null){
					httpCode= ampResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampResponseBO.setHTTP_CODE(httpCode);
					ampResponseBO.setErrorCode(httpCode);
				}

				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(eiisOrderBO.getOrderId()));
				eventStatus.setEventStatusId(eventStatusId);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1001L);
				saveEventDetails(eiisOrderBO, eventStatus, eventType, orders, "RANDOM_"+uuid, EiisCommonConstants.AMP_REQUEST);
				saveEventLogs("RANDOM_"+uuid, eventStatus, orders, EiisCommonConstants.AMP_REQUEST, ampRequest, ampResponseBO, eventType, httpCode, attuid);
			} else {
				String rid = null;
				String uuid = generateUUID(8);
				if(ampResponseBO.getHTTP_CODE()!= null){
					httpCode= ampResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampResponseBO.setHTTP_CODE(httpCode);
					ampResponseBO.setErrorCode(httpCode);
				}
				if(ampResponseBO.getRid() == null) {
					rid="RANDOM_"+uuid;
				}else {
					rid=ampResponseBO.getRid();
				}

				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(eiisOrderBO.getOrderId()));
				eventStatus.setEventStatusId(eventStatusId);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1001L);
				saveEventDetails(eiisOrderBO, eventStatus, eventType, orders, rid, EiisCommonConstants.AMP_REQUEST);
				saveEventLogs(rid, eventStatus, orders, EiisCommonConstants.AMP_REQUEST, ampRequest,ampResponseBO, eventType, httpCode, attuid);
				updateEventStatus(rid, eventStatus, eventType, orders, EiisCommonConstants.AMP_REQUEST, "IN_APPROVAL", attuid);
			}
		}catch(Exception e) {
			logger.debug("Create AMP order failed :", e.getMessage());
		}

		logger.info("Exiting methode create :",this);
		return ampResponseBO;	
	}

	private String generateUUID(int length) throws EiisDataException{
		logger.info("Starting methode generateUUID:",this);

		StringBuffer buffer = new StringBuffer();
		while (buffer.length() < length) {
			buffer.append(UUID.randomUUID().toString().replaceAll("-", ""));
		}

		logger.info("Exiting methode generateUUID:",this);
		return buffer.substring(0, length);
	}
	private int getCount(String inputValue) throws EiisDataException{
		logger.info("Starting methode getServerCount :",this);

		int count = 0;
		Properties eiisProp = getEiisConfigProperties("AMP_CONFIG");
		count = Integer.parseInt(eiisProp.getProperty(inputValue));
		if(eiisProp.getProperty(inputValue) != null) {
			count = Integer.parseInt(eiisProp.getProperty(inputValue));
		}

		logger.info("Exiting methode getServerCount :",this);
		return count;
	}

	@Override
	public AmpResponseBO checkAmpMaintance() throws EiisDataException{
		logger.info("Starting methode checkAmpMaintance :",this);

		boolean checkAmpTime=false;
		String maintainaceTime =null;
		String ampMaintainaceStartDt = null;
		String ampMaintainaceEndDt = null;
		AmpResponseBO ampResponseBO = null;
		try {
			Optional<AdminConfig> adminConfigOptional = adminConfigRepository.findById(1072L);
			if(adminConfigOptional.isPresent()) {
				ampResponseBO = new AmpResponseBO();
				AdminConfig adminConfig=adminConfigOptional.get();
				maintainaceTime =adminConfig.getCategoryValue();
				if(StringUtils.isNoneBlank(maintainaceTime)) {
					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
					ampMaintainaceStartDt = maintainaceTime.replace("@@$$@@","#####").split("#####")[0];
					ampMaintainaceEndDt = maintainaceTime.replace("@@$$@@","#####").split("#####")[1];
					Date startDt  = sdf.parse(ampMaintainaceStartDt);
					Date endDt = sdf.parse(ampMaintainaceEndDt);
					Date currentDate = sdf.parse(sdf.format(new Date()));
					checkAmpTime = ((startDt.compareTo(currentDate) <= 0 && endDt.compareTo(currentDate) >=0));
					if(checkAmpTime) {
						ampResponseBO.setMessage("Currently AMP maintenance is in progress from "+ ampMaintainaceStartDt +" To "+ ampMaintainaceEndDt);
						ampResponseBO.setJsonResponse("Currently AMP maintenance is in progress from "+ ampMaintainaceStartDt +" To "+ ampMaintainaceEndDt);
					}
				}
			}
		}catch(Exception e) {
			checkAmpTime=false;
			logger.error("Check Amp Maintance failed :", e);
		}

		logger.info("Exiting methode checkAmpMaintance :",this);
		return ampResponseBO;
	}

	@Override
	public Properties getEiisConfigProperties(String key) throws EiisDataException{
		logger.info("Starting methode getEiisConfigProperties :",this);

		Properties eiisConfigProperties = new Properties();
		List<EiisConfiguration> eiisConfigList = eiisConfigurationRepository.findByKey(key);
		if(!CollectionUtils.isEmpty(eiisConfigList)) {
			for(EiisConfiguration eiisConfiguration : eiisConfigList) {
				eiisConfigProperties = parseIntoProperties(eiisConfiguration.getValue());
			}
		}

		logger.info("Exiting methode getEiisConfigProperties :",this);
		return eiisConfigProperties;
	}

	private Properties parseIntoProperties(String propertiesValues) throws EiisDataException{
		logger.info("Starting methode parseIntoProperties :",this);

		final Properties properties = new Properties();
		if (propertiesValues != null && !propertiesValues.isEmpty()) {
			try {
				properties.load(new StringReader(propertiesValues));
			} catch (IOException e) {
				throw new EiisDataException(" Error when parsing :",e);
			}
		}

		logger.info("Exiting methode parseIntoProperties :",this);
		return properties;
	}


	@Override
	public AmpResponseBO cancel(EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode cancel:",this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders =null;
		String httpCode=null;
		String orderStatus = null;

		try {
			RequestBO requestBO = getRequestBO(orderBO.getOrderId());
			JSONObject requestJson = new JSONObject();
			requestJson.put("rid",requestBO.getRid());
			ampResponseBO = getAmpResponseDetails(requestBO, orderBO, null, "Cancel");
			orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
			if(null != orders) {
				orderStatus = orders.getOrderStatus().getOrderStatusName();
			}

			if (ampResponseBO.getException() != null) {
				if(ampResponseBO.getHTTP_CODE()!= null){
					httpCode= ampResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampResponseBO.setHTTP_CODE(httpCode);
					ampResponseBO.setErrorCode(httpCode);
				}
				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1001L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1001L);
				saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);

			} else {
				if(ampResponseBO.getHTTP_CODE()!= null){
					httpCode= ampResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampResponseBO.setHTTP_CODE(httpCode);
					ampResponseBO.setErrorCode(httpCode);
				}

				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1004L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1004L);
				saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);

				if(httpCode.equalsIgnoreCase("200")){
					eventStatus= new EventStatus();
					eventType = new EventType();
					orders = new Orders();
					orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
					eventStatus.setEventStatusId(1005L);
					eventStatus.setEventStatusDec(orderStatus);
					eventType.setEventTypeId(1005L);
					saveEventDetails(orderBO, eventStatus, eventType, orders, requestBO.getRid(), EiisCommonConstants.AMP_REQUEST);
					updateEventStatus(requestBO.getRid(), eventStatus, eventType, orders, EiisCommonConstants.AMP_REQUEST, "CANCELLED", attuid);
				}
			}
		}catch(Exception e) {
			logger.debug("Cancel AMP order failed :", e.getMessage());
		}
		logger.info("Exiting methode cancel:",this);
		return ampResponseBO;	
	}

	@SuppressWarnings("unchecked")
	private RequestBO getRequestBO(String orderId) throws EiisDataException{
		logger.info("Starting methode getRequestBO:",this);

		String requestId =null;
		RequestBO requestBO = null;

		try {
			StringBuilder query = eiisHelper.getRequestIdQuery(orderId);
			Query sqlQuery = em.createNativeQuery(query.toString());

			List<String> list = sqlQuery.getResultList();
			if (list.size() > 0) {
				requestId = list.get(0);
			}

			requestBO = new RequestBO();
			requestBO.setRid(requestId);

		}catch(Exception e) {
			logger.debug("RequestBO failed :", e.getMessage());
		}

		logger.info("Exiting methode getRequestBO :",this);
		return requestBO;
	}

	@Override
	public String login(UserBean userBO,String orderId,String requestId,int serverNo) throws EiisDataException{
		logger.info("Starting methode login:",this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String token = null;
		try {
			ampResponseBO= ampRequestClient.login(userBO,orderId,requestId,serverNo);
			token = ampResponseBO.getToken();

		} catch (Exception e) {
			logger.debug("Login AMP order failed :", e.getMessage());
		}

		logger.info("Exiting methode login:",this);
		return token;	
	}

	@Override
	public AmpResponseBO getStatusById(EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode getStatusById:",this);

		AmpResponseBO ampRestResponseBO = new AmpResponseBO();
		String httpCode=null;
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders =null;
		String orderStatus = null;

		try {
			RequestBO requestBO = getRequestBO(orderBO.getOrderId());
			JSONObject requestJson = new JSONObject();
			requestJson.put("rid",requestBO.getRid());

			ampRestResponseBO = getAmpResponseDetails(requestBO, orderBO, null, "Status");
			orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
			if(null != orders) {
				orderStatus = orders.getOrderStatus().getOrderStatusName();
			}
			if (ampRestResponseBO.getException() != null) {
				if(ampRestResponseBO.getHTTP_CODE()!= null){
					httpCode= ampRestResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampRestResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampRestResponseBO.setHTTP_CODE(httpCode);
					ampRestResponseBO.setErrorCode(httpCode);
				}
				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1002L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1002L);
				saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampRestResponseBO, eventType, httpCode, attuid);
			} else {
				if(ampRestResponseBO.getHTTP_CODE()!= null){
					httpCode= ampRestResponseBO.getHTTP_CODE();
				}
				if(httpCode == null || ampRestResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
					httpCode="500";
					ampRestResponseBO.setHTTP_CODE(httpCode);
					ampRestResponseBO.setErrorCode(httpCode);
				}

				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1002L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1002L);
				saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampRestResponseBO, eventType, httpCode, attuid);
				String status = updateEventStatus(requestBO.getRid());
				ampRestResponseBO.setRequestStatus(status);

			}
		}catch(Exception e) {
			logger.debug("Status AMP order failed :", e.getMessage());
		}

		logger.info("Exiting methode getStatusById:",this);
		return ampRestResponseBO;	
	}

	@Override
	public AmpResponseBO getDetailsById(EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode getDetailsById:",this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders =null;
		String orderStatus = null;
		String httpCode=null;

		RequestBO requestBO= getRequestBO(orderBO.getOrderId());
		JSONObject requestJson = new JSONObject();
		requestJson.put("rid",requestBO.getRid());

		ampResponseBO = getAmpResponseDetails(requestBO, orderBO, null, "Details");
		orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
		if(null != orders) {
			orderStatus = orders.getOrderStatus().getOrderStatusName();
		}
		if (ampResponseBO.getException() != null) {
			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1003L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1003L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
		} else {
			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1003L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1003L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.AMP_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
			if(httpCode.equalsIgnoreCase("200")){
				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1002L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1002L);
				saveEventDetails(orderBO, eventStatus, eventType, orders, requestBO.getRid(), EiisCommonConstants.AMP_REQUEST);
			}
		}

		logger.info("Exiting methode getDetailsById:",this);
		return ampResponseBO;	
	}

	@Override
	public List<AmpResponseBO> createAcca(EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode createAcca:",this);

		String exception = null;
		AccaAmpResponseBO accaAmpRestResponseBO = null;
		AmpResponseBO ampRestResponseBO = null;
		ObjectMapper mapper = new ObjectMapper();
		List<AmpResponseBO> ampResponseBOList = new ArrayList<AmpResponseBO>();
		String orderStatus=null;
		DataCenter dataCenter = null;
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders = null;

		try{
			String orderAccaReq = getAccaRequest(orderBO.getOrderId());
			accaAmpRestResponseBO = mapper.readValue(orderAccaReq, AccaAmpResponseBO.class);
		}catch(Exception e){
			exception = "Failed";
		}

		int counter = 0;
		String httpCode = null;
		String token = null;
		try {
			ampRestResponseBO = checkAmpMaintance();
			if(null != ampRestResponseBO){
				ampRestResponseBO.setHTTP_CODE("400");
				ampRestResponseBO.setErrorCode("400");
				ampResponseBOList.add(ampRestResponseBO);
			}else{
				String inputPropValue ="amp.server.count";
				int serverCount = getCount(inputPropValue);

				String retryValue ="amp.server.count";
				int retryCount = getCount(retryValue);

				for (int i = 0; i < accaAmpRestResponseBO.getDataCenterList().size(); i++) {
					String dataCenterName = accaAmpRestResponseBO.getDataCenterList().get(i).getName();
					String requestJson = "";
					ampRestResponseBO = new AmpResponseBO();
					try{
						requestJson = mapper.writeValueAsString(accaAmpRestResponseBO.getDataCenterList().get(i).getAccaJson());
					}catch(Exception e){
						exception = "Failed";
					}

					if (exception == null) {
						for (int serverNo = 1; serverNo <= serverCount; serverNo++) {
							do {
								if (counter > 0) {
									try {
										Thread.sleep(EiisCommonConstants.WAIT_FOR_TIME_IN_MILLIES);
									} catch (Exception e) {
										logger.debug("Error in waiting.");
									}
								}

								exception = null;
								counter++;
								try {
									ampRestResponseBO = eiisServerUtil.getToken(orderBO.getOrderId(), "",serverNo);
									token = ampRestResponseBO.getToken();
									if (token == null || token.equalsIgnoreCase("")) {
										if (ampRestResponseBO.getHTTP_CODE() == "0" || ampRestResponseBO.getHTTP_CODE() == null) {
											ampRestResponseBO.setHTTP_CODE("501");
											ampRestResponseBO.setErrorCode("501");
											ampRestResponseBO.setMessage("CSP Authentication Failed");
											//ampRestResponseBO.setJsonResponse("CSP Authentication Failed");
										}
										throw new EiisDataException("Token Generation Failed .");
									} else {
										ampRestResponseBO = ampRequestClient.createAccaRequest(token,requestJson,orderBO.getOrderId(),serverNo);
										ampRestResponseBO.setHTTP_CODE("200");
										if (ampRestResponseBO.getHTTP_CODE() == "0") {
											throw new EiisDataException("Create Acca Failed :"+orderBO.getOrderId());
										}
									}
								} catch (Exception e) {
									exception = "Failed";
								}
							} while (exception != null && retryCount > counter);

							if (!((ampRestResponseBO.getHTTP_CODE() == "501"
									|| (ampRestResponseBO.getHTTP_CODE() == "500" 
									&& (ampRestResponseBO.getErrorCode() == "" || ampRestResponseBO.getErrorCode() == null))
									|| ampRestResponseBO.getHTTP_CODE() == "" || ampRestResponseBO.getHTTP_CODE() == "404"))) {
								break;
							}
						}
					}

					orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
					if(null != orders) {
						orderStatus = orders.getOrderStatus().getOrderStatusName();
					}

					if (exception != null) {
						String uuid = generateUUID(8);
						if (ampRestResponseBO.getHTTP_CODE() != null) {
							httpCode = ampRestResponseBO.getHTTP_CODE();
						}
						if (httpCode == null || ampRestResponseBO.getHTTP_CODE().equalsIgnoreCase("0")) {
							httpCode = "500";
							ampRestResponseBO.setHTTP_CODE(httpCode);
							ampRestResponseBO.setErrorCode(httpCode);
						}

						eventStatus= new EventStatus();
						eventType = new EventType();
						orders = new Orders();
						orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
						eventStatus.setEventStatusId(1005L);
						eventStatus.setEventStatusDec(orderStatus);
						eventType.setEventTypeId(1005L);
						saveEventDetails(orderBO, eventStatus, eventType, orders, "RANDOM_" + uuid, EiisCommonConstants.ACCA_REQUEST);
						saveEventLogs("RANDOM_" + uuid, eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampRestResponseBO, eventType, httpCode, attuid);

					} else {
						String rid = null;
						String uuid = generateUUID(8);
						if (ampRestResponseBO.getHTTP_CODE() != null) {
							httpCode = ampRestResponseBO.getHTTP_CODE();
						}
						if (httpCode == null || ampRestResponseBO.getHTTP_CODE().equalsIgnoreCase("0")) {
							httpCode = "500";
							ampRestResponseBO.setHTTP_CODE(httpCode);
							ampRestResponseBO.setErrorCode(httpCode);
						}
						if (ampRestResponseBO.getRid() == null) {
							rid = "RANDOM_" + uuid;
						}else {
							rid = ampRestResponseBO.getRid();
						}

						eventStatus= new EventStatus();
						eventType = new EventType();
						orders = new Orders();
						orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
						eventStatus.setEventStatusId(1005L);
						eventStatus.setEventStatusDec(orderStatus);
						eventType.setEventTypeId(1005L);
						saveEventDetails(orderBO, eventStatus, eventType, orders, rid, EiisCommonConstants.ACCA_REQUEST);

						if(rid.indexOf("RANDOM")==-1) {
							dataCenter = new DataCenter();
							String orderId = orderBO.getOrderId();
							OrderDataCenter odCenter = orderDataCenterRepository.findById_OrderIdAndDataCenter_DataCenterName(Long.valueOf(orderId), dataCenterName);
							orders.setOrderId(Long.valueOf(orderId));
							dataCenter.setDataCenterName(dataCenterName);
							dataCenter.setDataCenterId(odCenter.getId().getDataCenterId());
							OrderDataCenterId id = new OrderDataCenterId();
							id.setDataCenterId(odCenter.getId().getDataCenterId());
							id.setOrderId(Long.valueOf(orderId));
							Optional<OrderDataCenter> orderDataCenterOptional = orderDataCenterRepository.findById(id);
							if (orderDataCenterOptional.isPresent()) {
								OrderDataCenter oldOrderDataCenter = orderDataCenterOptional.get();
								oldOrderDataCenter.setExtInterfaceId("RANDOM_" + uuid);
								oldOrderDataCenter.setOrders(orders);
								oldOrderDataCenter.setDataCenter(dataCenter);
								orderDataCenterRepository.save(oldOrderDataCenter);
							}
						}
						
						saveEventLogs(rid, eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampRestResponseBO, eventType, httpCode, attuid);
						updateEventStatus(rid, eventStatus, eventType, orders, EiisCommonConstants.ACCA_REQUEST, "IN_APPROVAL", attuid);
					}
					ampRestResponseBO.setDataCenterName(dataCenterName);
					ampResponseBOList.add(ampRestResponseBO);
				}
			}
		}catch(Exception e) {
			logger.debug("Create ACCA order failed :", e);
		}
		logger.info("Exiting methode createAcca:",this);
		return ampResponseBOList;	
	}

	private String getAccaRequest(String orderId) throws EiisDataException{
		logger.info("Starting methode getAccaRequest:",this);

		String requestAcca = null; 
		try {
			if(null != orderId) {
				Query query = em.createNativeQuery(EiisCommonConstants.ACCA_REQUEST_FOR_ORDER_ID);
				query.setParameter(EiisCommonConstants.ORDER_ID, Long.valueOf(orderId));
				Clob clob=(Clob)query.getSingleResult();
				StringBuffer str = new StringBuffer();
				String strng;
				BufferedReader bufferRead = new BufferedReader(clob.getCharacterStream());
				while ((strng=bufferRead.readLine())!=null)
					str.append(strng);
				requestAcca= str.toString();
			}
		}catch(Exception e) {
			logger.debug("Get ACCA Request failed :", e);
		}
		logger.info("Exiting methode getAccaRequest:",this);
		return requestAcca;
	}

	@Override
	public AmpResponseBO getAccaStatusById(RequestBO requestBO,EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode getAccaStatusById:",this);

		String httpCode=null;
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders = null;
		String orderStatus =null;

		JSONObject requestJson = new JSONObject();
		requestJson.put("rid",requestBO.getRid());
		AmpResponseBO ampResponseBO = new AmpResponseBO();
		ampResponseBO = getAmpResponseDetails(requestBO,orderBO,null,"ACCASTATUS");
		orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
		if(null != orders) {
			orderStatus = orders.getOrderStatus().getOrderStatusName();
		}
		if(null != ampResponseBO.getException()) {

			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}

			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1002L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1002L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
		}else {

			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1002L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1002L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
			ampResponseBO.setRequestStatus(updateEventStatus(requestBO.getRid()));
		}

		logger.info("Exiting methode getAccaStatusById:",this);
		return ampResponseBO;	
	}

	private AmpResponseBO getAmpResponseDetails(RequestBO requestBO,EiisOrderBO orderBO,String ampRequest,String type) throws EiisDataException{
		logger.info("Starting methode getAmpResponseDetails:",this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		int counter = 0;
		String exception=null;
		String token=null;
		String httpCode=null;

		ampResponseBO = checkAmpMaintance();
		if(null != ampResponseBO){
			ampResponseBO.setHTTP_CODE("400");
			ampResponseBO.setErrorCode("400");
		}else{

			String inputPropValue ="amp.server.count";
			int serverCount = getCount(inputPropValue);

			String retryValue ="amp.server.count";
			int retryCount = getCount(retryValue);

			for(int serverNo = 1 ; serverNo <= serverCount ; serverNo++){
				do {
					if (counter > 0) {
						try {
							Thread.sleep(EiisCommonConstants.WAIT_FOR_TIME_IN_MILLIES);
						} catch (Exception e) {
							logger.warn("Error in waiting.");
						}
					}

					counter ++;
					try {
						ampResponseBO = eiisServerUtil.getToken(orderBO.getOrderId(),requestBO.getRid(),serverNo);
						token = ampResponseBO.getToken();
						logger.debug("token ... !"+ token);
						logger.debug("Http Code  for token ... !"+ ampResponseBO.getHTTP_CODE());
						
						if(token == null || token.equalsIgnoreCase("")){
							if(ampResponseBO.getHTTP_CODE() == "0" || ampResponseBO.getHTTP_CODE() == null){
								ampResponseBO.setHTTP_CODE("501");
								ampResponseBO.setErrorCode("501");
								ampResponseBO.setMessage("CSP Authentication Failed");
								//ampResponseBO.setJsonResponse("CSP Authentication Failed");
							}
							throw new EiisDataException("Token Generation Failed :"+orderBO.getOrderId());
						}else{
							if(type.equalsIgnoreCase("ACCASTATUS")) {
								ampResponseBO= ampRequestClient.accaStatus(token,requestBO,serverNo);
							}else if(type.equalsIgnoreCase("ACCADETAILS")) {
								ampResponseBO= ampRequestClient.accaDetails(token,requestBO,serverNo);
							}else if(type.equalsIgnoreCase("Create")) {
								ampResponseBO = ampRequestClient.create(token, ampRequest, orderBO.getOrderId(), serverNo);
							}else if(type.equalsIgnoreCase("Cancel")) {
								ampResponseBO = ampRequestClient.cancel(token, requestBO,serverNo);
							}else if(type.equalsIgnoreCase("Status")) {
								ampResponseBO= ampRequestClient.status(token, requestBO,serverNo);
							}else if(type.contentEquals("Details")) {
								ampResponseBO = ampRequestClient.details(token, requestBO,serverNo);
							}

							if(ampResponseBO.getHTTP_CODE() == "0"){
								throw new EiisDataException("Amp Calling Failed :"+orderBO.getOrderId());
							}
						}
					} catch (Exception e) {
						exception = "Failed";
						ampResponseBO.setException(exception);
						logger.debug("AMP Response Failed :");
					}
				} while (exception != null && retryCount > counter);
				if(!((ampResponseBO.getHTTP_CODE() == "501" || (ampResponseBO.getHTTP_CODE() == "500" 
						&& (ampResponseBO.getErrorCode() == "" || ampResponseBO.getErrorCode() == null))
						|| ampResponseBO.getHTTP_CODE() == "" || ampResponseBO.getHTTP_CODE() == "404"))){
					break;
				}
			}
		}

		logger.info("Exiting methode getAmpResponseDetails:",this);
		return ampResponseBO;
	}

	@Override
	public AmpResponseBO getAccaDetailsById(RequestBO requestBO, EiisOrderBO orderBO, String attuid) throws EiisDataException{
		logger.info("Starting methode getAccaDetailsById:",this);

		AmpResponseBO ampResponseBO =null;
		String httpCode=null;
		EventStatus eventStatus = null;
		EventType eventType = null;
		Orders orders = null;
		String orderStatus =null;

		JSONObject requestJson = new JSONObject();
		requestJson.put("rid",requestBO.getRid());

		ampResponseBO = getAmpResponseDetails(requestBO,orderBO,null,"ACCADETAILS");
		orders = orderRepository.findByOrderId(Long.valueOf(orderBO.getOrderId()));
		if(null != orders) {
			orderStatus = orders.getOrderStatus().getOrderStatusName();
		}
		if(null != ampResponseBO.getException()) {
			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1003L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1003L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
		}else {

			if(ampResponseBO.getHTTP_CODE()!= null){
				httpCode= ampResponseBO.getHTTP_CODE();
			}
			if(httpCode == null || ampResponseBO.getHTTP_CODE().equalsIgnoreCase("0")){
				httpCode="500";
				ampResponseBO.setHTTP_CODE(httpCode);
				ampResponseBO.setErrorCode(httpCode);
			}
			eventStatus= new EventStatus();
			eventType = new EventType();
			orders = new Orders();
			orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
			eventStatus.setEventStatusId(1003L);
			eventStatus.setEventStatusDec(orderStatus);
			eventType.setEventTypeId(1003L);
			saveEventLogs(requestBO.getRid(), eventStatus, orders, EiisCommonConstants.ACCA_REQUEST, requestJson.toString(),ampResponseBO, eventType, httpCode, attuid);
			if(httpCode.equalsIgnoreCase("200")){
				eventStatus= new EventStatus();
				eventType = new EventType();
				orders = new Orders();
				orders.setOrderId(Long.valueOf(orderBO.getOrderId()));
				eventStatus.setEventStatusId(1002L);
				eventStatus.setEventStatusDec(orderStatus);
				eventType.setEventTypeId(1002L);
				saveEventDetails(orderBO, eventStatus, eventType, orders, requestBO.getRid(), EiisCommonConstants.ACCA_REQUEST);
			}
		}

		logger.info("Exiting methode getAccaDetailsById:",this);
		return ampResponseBO;	
	}

	@Override
	public String getExtInterfaceOrderId(String requestId) throws EiisDataException{
		logger.info("Starting methode getExtInterfaceOrderId:",this);

		ExternalInterfaceDetails ExtInterfaceDetails = extInterfaceDetailsRepository.findByExtInterfaceId(requestId);
		String orderId = ExtInterfaceDetails.getOrders().getOrderId().toString();

		logger.info("Exiting methode getExtInterfaceOrderId:",this);
		return orderId;
	}

	@Override
	public Map<String,Object> getFirstNetCcsMxFlag(String orderId) throws EiisDataException{
		logger.info("Starting methode getFirstNetCcsMxFlag:",this);

		Map<String, Object> firstNetCcsMxFlagMap = new HashMap<String, Object>();

		try {
			StringBuilder query = eiisHelper.getFirstNetCcsmxQuery(orderId);
			Query sqlQuery = em.createNativeQuery(query.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(EiisScalarConstants.FIRSTNET_EPC, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(EiisScalarConstants.CCSMX, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			Map<String, Object> resultMap = null;
			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();
				while (itr.hasNext()) {
					resultMap = itr.next();

					firstNetCcsMxFlagMap.put("FIRSTNET_EPC",(String) resultMap.get(EiisScalarConstants.FIRSTNET_EPC));
					firstNetCcsMxFlagMap.put("CCSMX",(String) resultMap.get(EiisScalarConstants.CCSMX));

				}
			}
		} catch (Exception exception) {
			logger.debug("Getting FirstNetCcsMxFlag Failed :",exception);
		}

		logger.info("Exiting methode getFirstNetCcsMxFlag:",this);
		return firstNetCcsMxFlagMap;	
	}

	@Override
	public FetchEmailTemplateInfo getFetchEmailTemplateInfo(Long emailTemplateId) throws EiisDataException{
		logger.info("Starting methode FetchEmailTemplateInfo:",this);

		FetchEmailTemplateInfo fetchEmailTemplateInfo=null;
		Optional<FetchEmailTemplateInfo> optional = fetchEmailTemplateInfoRepository.findById(emailTemplateId);
		if (optional.isPresent()) {
			fetchEmailTemplateInfo = optional.get();
		}

		logger.info("Starting methode FetchEmailTemplateInfo:",this);
		return fetchEmailTemplateInfo;
	}

	@Override
	public void updateEventDetails(String rid, Long statusId) throws EiisDataException{
		logger.info("Starting methode updateEventDetails:",this);

		ExternalInterfaceDetails extInterfaceDetails = new ExternalInterfaceDetails();
		EventStatus eventStatus = new EventStatus();
		eventStatus.setEventStatusId(statusId);
		extInterfaceDetails.setExtInterfaceId(rid);
		extInterfaceDetails.setUpdatedOn(new Date());
		extInterfaceDetails.setEventStatus(eventStatus);
		extInterfaceDetailsRepository.save(extInterfaceDetails);

		logger.info("Exiting methode updateEventDetails:",this);
	}

	@Override
	public String updateEventStatus(String rid) throws EiisDataException{
		logger.info("Starting methode updateEventStatus:",this);

		String status=null;
		String errorCode = null;
		String errorMsg = null;
		try {
			if (StringUtils.isNotBlank(rid)) {
				StoredProcedureQuery sProcQury = em.createStoredProcedureQuery(EiisCommonConstants.UPDATE_EVENT_STATUS);
				sProcQury.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
				sProcQury.registerStoredProcedureParameter(2, String.class, ParameterMode.OUT);
				sProcQury.registerStoredProcedureParameter(3, String.class, ParameterMode.OUT);
				sProcQury.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
				sProcQury.setParameter(1, rid);

				sProcQury.execute();

				status = (String) sProcQury.getOutputParameterValue(2);
				errorCode = (String) sProcQury.getOutputParameterValue(3);
				errorMsg = (String) sProcQury.getOutputParameterValue(4);

			}
		} catch (Exception exception) {
			throw new EiisDataException("Update Event Status Failed :"+rid);
		}

		logger.info("Exiting methode updateEventStatus:",this);
		return status;
	}

	private void saveEventDetails(EiisOrderBO eiisOrderBO, EventStatus eventStatus, EventType eventType, Orders orders, String interfaceId, String requestType) throws EiisDataException{
		logger.info("Starting methode saveEventDetails:",this);
		try {
			ExternalInterfaceDetails extInterfaceDetails = new ExternalInterfaceDetails();
			extInterfaceDetails.setExtInterfaceId(interfaceId);
			extInterfaceDetails.setCreatedAt(new Date());
			extInterfaceDetails.setUpdatedOn(new Date());
			extInterfaceDetails.setEventStatus(eventStatus);
			extInterfaceDetails.setOrders(orders);
			extInterfaceDetails.setRequestType(requestType);
			extInterfaceDetailsRepository.save(extInterfaceDetails);
		}catch(Exception e) {
			logger.debug("Error in Saving Event details :", e);
		}
		logger.info("Exiting methode saveEventDetails:",this);
	}

	private void saveEventLogs(String extInterfaceId, EventStatus eventStatus, Orders orders, String requestType, String ampRequest,AmpResponseBO ampResponseBO, EventType eventType, String httpCode, String attuid) throws EiisDataException{
		logger.info("Starting methode saveEventLogs:",this);

		try {
			ObjectMapper objMapper = new ObjectMapper();
			ExternalInterfaceEventLogs externalInterfaceEventLogs = new ExternalInterfaceEventLogs();

			ExternalInterfaceDetails extInterfaceDetails = new ExternalInterfaceDetails();
			extInterfaceDetails.setExtInterfaceId(extInterfaceId);
			extInterfaceDetails.setCreatedAt(new Date());
			extInterfaceDetails.setUpdatedOn(new Date());
			extInterfaceDetails.setEventStatus(eventStatus);
			extInterfaceDetails.setOrders(orders);
			extInterfaceDetails.setRequestType(requestType);

			externalInterfaceEventLogs.setExtInterfaceDetails(extInterfaceDetails);
			externalInterfaceEventLogs.setRequestJson(ampRequest);
			if(null != ampResponseBO) {
				String resJson = objMapper.writeValueAsString(ampResponseBO);
				externalInterfaceEventLogs.setResponseJson(resJson);
			}
			externalInterfaceEventLogs.setEventType(eventType);
			externalInterfaceEventLogs.setResponseCode(httpCode);
			externalInterfaceEventLogs.setSucess('Y');
			externalInterfaceEventLogs.setUpdatedOn(new Date());
			externalInterfaceEventLogs.setUpdatedBy(attuid);
			externalInterfaceEventLogs.setId(0L);
			extIntEventLogsRepository.save(externalInterfaceEventLogs);

		}catch(Exception e) {
			logger.debug("Saving EVent Logs Failed.", e);
		}
		logger.info("Exiting methode saveEventLogs:",this);
	}

	private void updateEventStatus(String interfaceId, EventStatus eventStatus, EventType eventType, Orders orders, String requestType, String statusDesc, String attuid) throws EiisDataException{
		logger.info("Starting methode updateEventStatus:",this);
		try {
			ExternalInterfaceEventStatuses extIntEventStatuses = new ExternalInterfaceEventStatuses();
			ExternalInterfaceDetails extInterfaceDetails = new ExternalInterfaceDetails();

			extInterfaceDetails.setExtInterfaceId(interfaceId);
			extInterfaceDetails.setCreatedAt(new Date());
			extInterfaceDetails.setUpdatedOn(new Date());
			extInterfaceDetails.setEventStatus(eventStatus);
			extInterfaceDetails.setOrders(orders);
			extInterfaceDetails.setRequestType(requestType);

			extIntEventStatuses.setExtInterfaceDetails(extInterfaceDetails);
			extIntEventStatuses.setStatusDesc(statusDesc);
			extIntEventStatuses.setStatusTime(new Date());
			extIntEventStatuses.setUpdatedBy(attuid);
			extIntEventStatuses.setId(0L);
			extInEventStatusesRepository.save(extIntEventStatuses);
		}catch(Exception e) {
			logger.debug("Error to update Event Status :", e);
		}
		logger.info("Exiting methode updateEventStatus:",this);
	}
}
