package com.att.eiis.bean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class CspUser {

	private String sec;
    private String hr;
}
