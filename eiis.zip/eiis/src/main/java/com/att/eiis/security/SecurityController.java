package com.att.eiis.security;


import static com.att.eiis.constants.SecurityStaticConstants.CSP_ATT_UID;
import static com.att.eiis.constants.SecurityStaticConstants.CSP_HR_FIRST_NAME;
import static com.att.eiis.constants.SecurityStaticConstants.CSP_HR_LAST_NAME;
import static com.att.eiis.constants.SecurityStaticConstants.CSP_HR_NAME_SUFFIX;
import static com.auth0.jwt.algorithms.Algorithm.HMAC512;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.att.eiis.constants.SecurityConstants;
import com.att.eiis.service.UserService;
import com.auth0.jwt.JWT;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class SecurityController {
	Logger logger = LoggerFactory.getLogger(SecurityController.class);

	@Autowired
	SecurityConstants secConstants;

	@Autowired
	SecCookieUtil cookieUtil;

	@Autowired
	UserService userService;
	
	@GetMapping(value = "/getToken/{attUid}/{roleId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Produce JWT token based on Valid user credentials", notes = "Return JWT Token")
	public Map<String, String> getToken(@PathVariable String attUid, @PathVariable int roleId,
			@RequestHeader("attESSec") String attESSec, @RequestHeader("attESHr") String attESHr)
			throws NumberFormatException, Exception {
		logger.info("[AttUid : " + (attUid == null ? "" : attUid) + "] "+ "Starting method getToken : ", this);
		logger.debug("attESSec :" + attESSec);

		HashMap<String, String> map = cookieUtil.decodeCookie(attESHr, attESSec);
		String token = "";
		if (StringUtils.isNotBlank(map.get(CSP_ATT_UID)) && attUid.equalsIgnoreCase(map.get(CSP_ATT_UID))
				&& userService.isAuthorizeUser(attUid, roleId)) {
			token = JWT.create().withSubject((String) map.get(CSP_ATT_UID)).withClaim("Suffix",
					StringUtils.isNotBlank((String) map.get(CSP_HR_NAME_SUFFIX)) ? (String) map.get(CSP_HR_NAME_SUFFIX)
							: "")
					.withClaim("FirstName",
							StringUtils.isNotBlank((String) map.get(CSP_HR_FIRST_NAME))
									? (String) map.get(CSP_HR_FIRST_NAME)
									: "")
					.withClaim("LastName",
							StringUtils.isNotBlank((String) map.get(CSP_HR_LAST_NAME))
									? (String) map.get(CSP_HR_LAST_NAME)
									: "")
					.withClaim("RoleId", roleId)
					.withExpiresAt(new Date(System.currentTimeMillis() + secConstants.getExpirationTime()))
					.sign(HMAC512(secConstants.getSecret().getBytes()));
		} else {
			throw new Exception("Unauthorized user");
		}
		logger.info("[AttUid : " + (attUid == null ? "" : attUid) + "] "+ "Exiting method getToken : ", this);
		return Collections.singletonMap("token", token);
	}
}
