package com.att.eiis.util;

public enum ErrorCodes {
	BLANKUSERNAME(100), BLANKPASSWORD(101);
	private int value;

	private ErrorCodes(int value) {
		this.setValue(value);
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

	public static String getErrorCode(int errorCode) {
		switch (errorCode) {
		case 100:
			return BLANKUSERNAME.name();
		case 101:
			return BLANKPASSWORD.name();
		default:
			return "500";
		}
	}
}
