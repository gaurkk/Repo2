package com.att.eiis.util;

import java.io.IOException;
import java.io.StringReader;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import org.json.simple.JSONObject;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.att.eiis.constants.EiisSQLConstants;

public class DatabaseUtil {

	private static Logger logger = LoggerFactory.getLogger(DatabaseUtil.class);

	/**
	 * 
	 * @param requestId
	 * @return
	 */
	private static Map<String, Object> callUpdateEventStatusProcedure(final String requestId) {
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(JDBCUtil.getDataSource())
			.withProcedureName("UPDATE_EVENT_STATUS")
				 .withoutProcedureColumnMetaDataAccess()
				 .useInParameterNames("P_EXT_INTERFACE_ID")
				  .declareParameters(
                                new SqlParameter("P_EXT_INTERFACE_ID", Types.VARCHAR),
                                new SqlOutParameter("p_return_status", Types.VARCHAR),
                                new SqlOutParameter("err_code", Types.VARCHAR),
                                new SqlOutParameter("err_msg", Types.VARCHAR)
                        );
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("P_EXT_INTERFACE_ID", requestId);
		
		Map<String, Object> execute = simpleJdbcCall.execute(result);
		return execute;
		
				
	}

	/**
	 * Prepares request json for given order id
	 * 
	 * @param orderId - order id
	 * @return - request json
	 */
	public static String getRequestJsonForOrderId(String orderId) {
		logger.debug("propertyName : " + orderId);
		String responseJson = null;
		List<String> propertiesList = GenericJDBCTemplate.queryForList(
				EiisSQLConstants.REQUEST_JSON_FOR_ORDER_ID, String.class, new Object[]{orderId});
		if (propertiesList != null && !propertiesList.isEmpty() && propertiesList.size() == 1) {
			responseJson = propertiesList.get(0);
		} else {
			logger.debug("No / multiple proeprties found.");
		}
		
		return responseJson;
	}

	/**
	 * Gives EIIS configuration properties
	 * 
	 * @param propertyName - name of property 
	 * @return - value of property
	 */
	public static Properties getEiisConfigProperties(String propertyName) {
		logger.debug("propertyName : " + propertyName);
		Properties queryMap = new Properties();
		List<String> propertiesList = GenericJDBCTemplate.queryForList(
				EiisSQLConstants.FETCH_EIIS_CONFIGURATION, String.class, new Object[]{propertyName});
		if (propertiesList != null && !propertiesList.isEmpty() && propertiesList.size() == 1) {
			queryMap = parsePropertiesString(propertiesList.get(0));
		} else {
			logger.debug("No / multiple proeprties found.");
		}
		return queryMap;
	}

	/**
	 * Gives external interface id for order id
	 * 
	 * @param orderId - order id
	 * @return - external interface id
	 */
	public static String getRequestIdForOrder(String orderId) {
		String requestId = null;
		List<String> list = GenericJDBCTemplate.queryForList(
				EiisSQLConstants.REQUEST_ID_FOR_ORDER_ID, String.class, new Object[]{orderId, orderId});
		if (list != null && !list.isEmpty() && list.size() == 1) {
			requestId = list.get(0);
		} else {
			logger.debug("No / multiple proeprties found.");
		}
		return requestId;
	}

	/**
	 * Returns list of order ids for provided list of external interface ids  
	 *  
	 * @param requestIds - list of external interface ids
	 * @return - list of order ids
	 */
	public static List<String> getOrderIdForRequestId(List<String> requestIds) {
		List<String> orderIds = null;
		List<String> list = GenericJDBCTemplate.queryForList(
				EiisSQLConstants.ORDER_ID_FOR_REQUEST_ID, String.class, requestIds.toArray(new Object[]{}));
		if (list != null && !list.isEmpty()) {
			orderIds = list;
		} else {
			logger.debug("No result found.");
		}
		return orderIds;
	}

	/**
	 * 
	 * @param proeprtiesString
	 * @return
	 */
	private static Properties parsePropertiesString(String proeprtiesString) {
	    final Properties properties = new Properties();
	    if (proeprtiesString != null && !proeprtiesString.isEmpty()) {
	    	try {
	    		properties.load(new StringReader(proeprtiesString));
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		throw new RuntimeException(e);
	    	}
	    }
	    return properties;
	}

	/**
	 * Returns applicable external interface ids for details sync
	 * 
	 * @return - list of ids
	 */
	public static List<String> getApplicableRequestIdsForDetailsSync() {
		logger.debug("Starting getApplicableRequestIdsForDetailsSync() method.");
		
		List<String> requestIdList = GenericJDBCTemplate.queryForList(EiisSQLConstants.APPLICABLE_REQUEST_IDS_FOR_DETAILS_SYNC, String.class);
		
		if (requestIdList != null && !requestIdList.isEmpty()) {
			logger.debug(requestIdList.size() + " request(s) found for details sync."); 
			return requestIdList;
		} else {
			logger.debug("0 request(s) found for details sync.");
			return null;
		}
	}

	/**
	 * Returns applicable external interface ids for status sync
	 * 
	 * @return - list of ids
	 */
	public static List<String> getApplicableRequestIdsForStatusSync() {
		logger.debug("Entering getApplicableRequestIdsForStatusSync() method."+EiisSQLConstants.APPLICABLE_REQUEST_IDS_FOR_STATUS_SYNC);
		List<String> requestIdList = GenericJDBCTemplate.queryForList(EiisSQLConstants.APPLICABLE_REQUEST_IDS_FOR_STATUS_SYNC, String.class);
		
		logger.debug("requestIdList..............."+requestIdList.size());
		
		if (requestIdList != null && !requestIdList.isEmpty()) {
			logger.debug(requestIdList.size() + " request(s) found for status sync."); 
			return requestIdList;
		} else {
			logger.debug("0 request(s) found for status sync.");
			return null;
		}
	}

	/**
	 * Updates event details in the table
	 * 
	 * @param requestId - external interface id
	 * @param eventStatusId - event status id
	 */
	public static void updateEventDetails(String requestId, int eventStatusId) {
		logger.debug("Insert data in event logs table start ");
		java.sql.Timestamp timeStamp = new java.sql.Timestamp(new Date().getTime());
		//Setting event status id as 'IN_PROGRESS' i.e. 1001
		Object[] detailsArguments = new Object[] {timeStamp, eventStatusId, requestId};
		int detailsResult = -1;
		try {
			logger.debug("update status procedure called");
			detailsResult = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.UPDATE_EVENT_DETAILS, detailsArguments, null);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error while inserting logs details : " + detailsResult, e);
			throw new RuntimeException(e);
		}
		logger.debug("Insert data in event logs table end");
	}

	/**
	 * Updates event status using response received from server
	 * 
	 * @param requestId - external interface id
	 * @return - status of event status update
	 */
	public static JSONObject updateEventStatus(String requestId) {
		logger.debug("Entering updateEventStatus() method.");
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			logger.debug("update status procedure called");
			resultMap = callUpdateEventStatusProcedure(requestId);
			jsonObject.put("status", resultMap.get("p_return_status").toString());
			jsonObject.put("rid", requestId);
		} catch (Exception e) {
			logger.error("Error while updating event status.", e);
			throw new RuntimeException(e);
		}
		logger.debug("Exiting updateEventStatus() method.");
		
		return jsonObject;
	}

	/**
	 * Inserts event logs in the table
	 * 
	 * @param rid - external interface id 
	 * @param responseJson - response from server
	 * @param eventTypeId - event type id
	 */
	public static void insertEventLogs(String rid, String requestJson, String responseJson, int eventTypeId,String errorCode,String attuid) {
		logger.debug("Entering insertOrderEventLogs() method.");
		Object[] logsArguments = new Object[] {rid, requestJson, responseJson, errorCode , "Y", eventTypeId, attuid, 
				new java.sql.Timestamp(new Date().getTime())};
		int result = -1;

		try {
			result = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.INSERT_EVENT_LOGS, logsArguments, null);
			logger.debug("Successfully inserted event logs : " + result);
		} catch (Exception e) {
			logger.error("Error while inserting logs details for rid : " + rid + ", eventTypeId : " + eventTypeId, e);
			throw new RuntimeException("Error while inserting logs details for rid : " + rid + ", eventTypeId : " + eventTypeId, e);
		}
		logger.debug("Insert data in event logs table end");
	}

	/**
	 * Inserts event details in table
	 * 
	 * @param requestId - external interface id
	 * @param orderId - order id
	 */
	public static void insertEventDetails(String requestId, String orderId,String orderStatus,String... requestList ) {
		logger.debug("Insert data in event logs table start"+requestId);
		
		java.sql.Timestamp timeStamp = new java.sql.Timestamp(new Date().getTime());
		//Setting event status id as 'IN_PROGRESS' i.e. 1001
		
		logger.debug("requestId:::"+requestId);
		logger.debug("orderId:::"+orderId);
		logger.debug("orderStatus:::"+orderStatus);
		Long eventStatusId = 1001L;
	
		Object[] detailsArguments = new Object[] {requestId, orderId, timeStamp, timeStamp, eventStatusId,orderStatus,requestList[0]};
		int detailsResult = 0;
		try {
			System.out.println("insertUpdate call");
			detailsResult = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.INSERT_EVENT_DETAILS, detailsArguments, null);
			System.out.println("insertUpdate call333");
			if(requestList[0].equalsIgnoreCase("ACCA") && requestList.length > 1 && requestId.toUpperCase().indexOf("RANDOM")==-1){
				System.out.println("requestId : "+requestId);
				System.out.println("orderId : "+orderId);
				System.out.println("requestList[1].toUpperCase() : "+requestList[1].toUpperCase());
				Object[] updateParameters = new Object[] {requestId, orderId, requestList[1].toUpperCase()};
				detailsResult = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.UPDATE_ORDER_DATA_CENTER, updateParameters, null);
			}
			System.out.println("insertUpdate call33ddddd3");
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error while inserting details : " + detailsResult, e);
			throw new RuntimeException(e);
		}
		logger.debug("Insert data in event logs table end");
	}
	
	/**
	 * Inserts event status in the table
	 * 
	 * @param rid - external interface id 
	 * @param status - event status
	 */
	public static void updateEventStatus(String rid, String status,String updatedBy) {
		logger.debug("Insert data in event status table start");
		logger.debug("requestId:::"+rid);
		Object[] logsArguments = new Object[] {rid, status, new java.sql.Timestamp(new Date().getTime()),updatedBy};
		int result = -1;

		try {
			result = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.INSERT_EVENT_STATUS, logsArguments, null);
			logger.debug("Successfully inserted event status : " + result);
		} catch (Exception e) {
			logger.error("Error while inserting event status for rid : " + rid , e);
			throw new RuntimeException("Error while inserting status for rid : " + rid, e);
		}
		logger.debug("Insert data in event status table end");
	}

	/**
	 * Gives max identifier
	 * 
	 * @return - max identifier
	 */
//	private static int getMaxId() {
//		int maxId = 0;
//		JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());
//		try {
//			maxId = jdbcTemplate.queryForObject(
//					EiisSQLConstants.MAX_QUERY, Integer.class);
//			logger.debug("maxId >> " + maxId);
//		} catch (Exception e) {
//			maxId = 0;
//			throw new RuntimeException(e);
//		}
//		return maxId;
//	}

	/**
	 * Fetches email template from database
	 * 
	 * @param emailTemplateId - identifier of template
	 * @return - email template
	 */
	public static Map<String, Object> fetchEmailTemplateInfo(Long emailTemplateId) {
		logger.debug("Entering fetchEmailTemplateInfo() method.");
		Map<String, Object> map = null;
		try {
			map = GenericJDBCTemplate.queryForMap(EiisSQLConstants.FETCH_EMAIL_TEMPLATE_INFO, 
					new Object[]{emailTemplateId});
		} catch (Exception e) {
			logger.error("There is some error while reading database.", e);
			throw new RuntimeException(e);
		}
		logger.debug("Exiting fetchEmailTemplateInfo() method.");
		return map;
	}
	
	
	/**
	 * Gives external interface id for order id
	 * 
	 * @param orderId - order id
	 * @return - external interface id
	 */
	public static String getAMPMaintainceTime() {
		String maintainaceTime = "";
		maintainaceTime = GenericJDBCTemplate.queryForObject(EiisSQLConstants.AMP_MAINTAINACE_TIME,String.class);
		if (maintainaceTime != null && !maintainaceTime.isEmpty()) {
			return maintainaceTime;
		} else {
			logger.debug("No Value Found.");
			return "";
		}
		
	}
	public static String getOrderStatus(String orderId) {
		logger.debug("Getting order_status_id from orders table start");
		Object[] orderStatusTemp = new Object[] {orderId};
		String detailsResult = null;
		try {
			logger.debug("Getting order_status procedure called");
			detailsResult = GenericJDBCTemplate.queryForObject(EiisSQLConstants.ORDER_STATUS_QUERY,String.class,orderStatusTemp);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error while getting order_status_id : " + detailsResult, e);
			throw new RuntimeException(e);
		}
		logger.debug("Getting order_status_id from orders table end");
		return detailsResult;
	}
	
	public static Map<String,Object> getFirstNetCcsMxFlag(String orderId) {
		logger.debug("Getting FirstNet from orders table start");
		Map<String, Object> map = new HashMap<String,Object>();
		try {
			logger.debug("Getting FirstNet procedure called");
			map = GenericJDBCTemplate.queryForMap(EiisSQLConstants.ORDER_FIRSTNET_CCSMX_FLAG,new Object[]{orderId});
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		logger.debug("Getting FirstNet and CCSMX Values  from orders and APN table end");
		return map;
	}
	
	public static String getOrderIdFromRequestId(String requestId) {
		logger.debug("Getting Order Id from ext_interface_details table start");
		Object[] orderIdTemp = new Object[] {requestId};
		String result = null;
		try {
			logger.debug("Getting order_status procedure called");
			result = GenericJDBCTemplate.queryForObject(EiisSQLConstants.GET_ORDER_ID_QUERY,String.class,orderIdTemp);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error while getting order_status_id : " + result, e);
			throw new RuntimeException(e);
		}
		logger.debug("Getting Order Id from ext_interface_details  table end");
		return result;
	}
	
	/**
	 * Prepares request json for given order id
	 * 
	 * @param orderId - order id
	 * @return - request json
	 */
	public static String getAccaRequestJsonForOrderId(String orderId) {
		logger.debug("propertyName : " + orderId);
		String responseJson = null;
		List<String> propertiesList = GenericJDBCTemplate.queryForList(
				EiisSQLConstants.ACCA_REQUEST_JSON_FOR_ORDER_ID, String.class, new Object[]{orderId});
		if (propertiesList != null && !propertiesList.isEmpty() && propertiesList.size() == 1) {
			responseJson = propertiesList.get(0);
		} else {
			logger.debug("No / multiple proeprties found.");
		}
		
		return responseJson;
	}
}