package com.att.eiis.dao;

import static com.att.eiis.constants.EiisSQLConstants.REQUEST_ID_FOR_ORDER_ID;

import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.eiis.bean.AmpResponseBO;
import com.att.eiis.constants.EiisCommonConstants;
import com.att.eiis.constants.EiisSQLConstants;
import com.att.eiis.dao.hibernate.bean.EiisConfiguration;
import com.att.eiis.dao.hibernate.bean.ExternalInterfaceDetails;
import com.att.eiis.exception.EiisDataException;
import com.att.eiis.repository.EiisConfigurationRepository;
import com.att.eiis.repository.ExtInterfaceDetailsRepository;
import com.att.eiis.util.ApplicationConfig;
import com.att.eiis.util.GenericJDBCTemplate;
import com.att.eiis.util.MessageConfigService;

import static com.att.eiis.constants.EiisSQLConstants.ORDER_FIRSTNET_CCSMX_FLAG;
import static com.att.eiis.constants.EiisSQLConstants.APPLICABLE_REQUEST_IDS_FOR_DETAILS_SYNC;

@Component
public class EiisHelper {
	Logger logger = LoggerFactory.getLogger(EiisHelper.class);
	private static RestTemplate restTemplate = null;

	@Autowired
	EiisConfigurationRepository eiisConfigurationRepository;

	@Autowired
	ExtInterfaceDetailsRepository extInterfaceDetailsRepository;

	@PersistenceContext
	EntityManager em;

	@Autowired
	ApplicationConfig applicationConfig;

	@Autowired
	MessageConfigService messageConfig;

	static {
		restTemplate = new RestTemplate();
	}

	private String CAMMUNDA_SERVICE_URL;

	@PostConstruct
	public void init() {
		CAMMUNDA_SERVICE_URL = applicationConfig.getCamundaRestUrl();
	}

	public StringBuilder getRequestIdQuery(String orderId) {
		logger.info("Starting methode getRequestIdQuery",this);
		String sqlQuery = REQUEST_ID_FOR_ORDER_ID;
		StringBuilder query = new StringBuilder(sqlQuery.replaceAll(":orderId", orderId));

		logger.info("Exiting methode getRequestIdQuery",this);
		return query;
	}

	public StringBuilder getFirstNetCcsmxQuery(String orderId) {
		logger.info("Starting methode getFirstNetCcsmxQuery",this);
		String sqlQuery = ORDER_FIRSTNET_CCSMX_FLAG;
		StringBuilder query = new StringBuilder(sqlQuery.replaceAll(":order_id", orderId));
		logger.info("Exiting methode getFirstNetCcsmxQuery",this);
		return query;

	}

	public Properties getEiisConfigProperties(String key) {
		logger.info("Starting methode getEiisConfigProperties",this);
		Properties eiisConfigProperties = new Properties();
		List<EiisConfiguration> eiisConfigList = eiisConfigurationRepository.findByKey(key);
		if(!CollectionUtils.isEmpty(eiisConfigList)) {
			for(EiisConfiguration eiisConfiguration : eiisConfigList) {
				eiisConfigProperties = parseIntoProperties(eiisConfiguration.getValue());
			}
		}

		logger.info("Exiting methode getEiisConfigProperties",this);
		return eiisConfigProperties;
	}

	private Properties parseIntoProperties(String propertiesValues) {
		logger.info("Starting methode parseIntoProperties",this);
		final Properties properties = new Properties();
		if (propertiesValues != null && !propertiesValues.isEmpty()) {
			try {
				properties.load(new StringReader(propertiesValues));
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		logger.info("Exiting methode parseIntoProperties",this);
		return properties;
	}

	public StringBuilder getDetailsRequestIdsQuery() {
		logger.info("Starting methode getDetailsRequestIdsQuery",this);
		String sqlQuery1 = APPLICABLE_REQUEST_IDS_FOR_DETAILS_SYNC;
		StringBuilder query = new StringBuilder(sqlQuery1);
		logger.info("Exiting methode getDetailsRequestIdsQuery",this);
		return query;
	}

	public List<String> getDetailsRequestIdsForSync() {
		logger.info("Starting methode getDetailsRequestIdsForSync",this);
		String requestId =null;
		List<String> list = new ArrayList<String>();		
		try {
			StringBuilder query = getDetailsRequestIdsQuery();
			Query sqlQuery = em.createNativeQuery(query.toString());
			list = sqlQuery.getResultList();
			if (list.size() > 0) {
				requestId = list.get(0);
			}
			logger.info("requestId : "+requestId);
		}catch(Exception e) {
			logger.debug("Failed Data Fetching :");
		}
		logger.info("Exiting methode getDetailsRequestIdsForSync",this);
		return list;
	}

	public List<String> getRequstIdListForDetails() {
		logger.info("Starting getRequstIdListForDetails() method.");
		List<String> requestIds =  new ArrayList<String>();
		try {
			List<ExternalInterfaceDetails> requestIdsList = extInterfaceDetailsRepository.findByExtInterfaceIdNotLikeAndEventStatus_EventStatusId("RANDOM%", 1002L);
			logger.debug("RequestIdsList :"+requestIdsList.size());

			for(ExternalInterfaceDetails externalInterfaceDetails : requestIdsList) {
				String extInerfaceId = externalInterfaceDetails.getExtInterfaceId();
				requestIds.add(extInerfaceId);
			}
			logger.info("request Ids :"+requestIds.size());
		}catch(Exception e) {
			logger.debug("List of Request Ids For Details Failed :",e);
		}
		logger.info("Exiting getRequstIdListForDetails() method with : " + (requestIds != null ? requestIds.size() : 0) + " results.");
		return requestIds;
	}

	public AmpResponseBO process(Long orderId) throws EiisDataException{
		logger.info("Starting methode process",this);
		AmpResponseBO operationBO = new AmpResponseBO();
		try {
			logger.info("CAMMUNDA_SERVICE_URL >>>>>>>>>>>"+CAMMUNDA_SERVICE_URL);
			String requestUri = CAMMUNDA_SERVICE_URL;
			//String reqVariables = " { \"businessKey\" : \"" + orderId.toString() + "\", \"messageName\" : \"uiApmReq\"} ";
			JSONObject jsonSkipRequest = createJsonRequest(orderId);
			logger.info("reqVariables >>>>>>>>>>>"+jsonSkipRequest);
			operationBO = processBPMService(requestUri, jsonSkipRequest.toString(), orderId);
		}catch(Exception e) {
			logger.debug("Process BPM Operation Failed : ",e);
		}
		logger.info("Exiting methode process",this);
		return operationBO;
	}
	private AmpResponseBO processBPMService(String requestUri, String variables, Long orderId) throws EiisDataException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method processBPMService : ", this);
		AmpResponseBO operationresponseBO = new AmpResponseBO();
		try {
			URI uri = new URI(requestUri);
			logger.info("Uri For BPM  >>>>>>>>>>:"+uri);
			logger.info("Request JSON For BPM  >>>>>>>>>>>>>:"+variables);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request =  new HttpEntity<String>(variables, headers);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, request, String.class);
			
			logger.info("Response body from BPM  >:"+response.getBody());
			logger.info("Response code from BPM  >:"+response.getStatusCodeValue());
			String detailsResult = null;
			int updateResult = -1;
			int insertResult = -1;
			if(response.getStatusCodeValue()==204) {
				try {
					Object[] orderIdOnFocus = new Object[] {orderId};
					detailsResult = GenericJDBCTemplate.queryForObject(EiisSQLConstants.SELCT_ORDER_FLAG,String.class,orderIdOnFocus);
					logger.info("detailsResult >>>>>>>>>>>>>>>>>>>"+Integer.valueOf(detailsResult));
					if(null!=detailsResult && detailsResult!="" && Integer.valueOf(detailsResult) > 0) {
						updateResult = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.UPDATE_ORDER_FLAG,orderIdOnFocus,null);
						logger.info("updateResult >>>>>>>>>>>>>>>>>>>"+updateResult);
						if(updateResult != -1) {
							logger.info("UPDATE_ORDER_FLAG to Y for SKIP APM"); 
						}
					}else {
						insertResult = GenericJDBCTemplate.insertOrUpdate(EiisSQLConstants.INSERT_ORDER_FLAG, orderIdOnFocus, null);
						logger.info("insert UPDATE_ORDER_FLAG for Skip AMP >>>>>>"+insertResult);
						if(insertResult != -1) {
							logger.info("NO RESULT FOUND , SO INSERT NEW ROW WITH Y FLAG TO SKIP APM"); 
						}
					}
				}catch(Exception e) {
					logger.error("Error while inserting/updating flag for skip Amp : ", e);	
				}
			}
			operationresponseBO = createOperationBO(String.valueOf(response.getStatusCodeValue()),orderId);

		} catch (HttpStatusCodeException  e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + e.getRawStatusCode());
			logger.debug("URISyntaxException during URI generate for URL : " + e.getMessage());
			operationresponseBO = createOperationBO(String.valueOf(e.getRawStatusCode()),orderId);
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks: " + e.getMessage());
			operationresponseBO = createOperationBO("599",orderId);
		} catch (Exception e) {
			logger.debug("error   >: " + e.getMessage());
			operationresponseBO = createOperationBO("599",orderId);
		}

		logger.info("Exiting methode processBPMService.",this);
		return operationresponseBO;
	}
	private AmpResponseBO createOperationBO(String errorCode,Long orderId) {
		logger.info("Starting methode createOperationBO.",this);

		AmpResponseBO operationresponseBO = new AmpResponseBO();
		String statusAndErrorCode = messageConfig.properties().getProperty("errors.and.success.operation.http.bpm.statuscodes");
		String message = messageConfig.properties().getProperty("errors.operation.http.bpm.message");

		HashMap<String, String> hashMap = (HashMap<String, String>) Arrays.asList(statusAndErrorCode.split(",")).stream().map(s -> s.split(":")).collect(Collectors.toMap(e -> e[0], e -> e[1]));

		if(hashMap.containsKey(errorCode)) {
			operationresponseBO.setHTTP_CODE(errorCode);
			operationresponseBO.setErrorCode(errorCode);
			if(hashMap.get(errorCode).equalsIgnoreCase("SUCCESS")) {
				operationresponseBO.setMessage(hashMap.get(errorCode));
				operationresponseBO.setRequestStatus("Success");
			}else {
				operationresponseBO.setMessage("("+hashMap.get(errorCode)+") ".concat(message.replaceAll("0", orderId.toString())));
				operationresponseBO.setRequestStatus("Failed");
			}
		}else {
			operationresponseBO.setHTTP_CODE(errorCode);
			operationresponseBO.setErrorCode(errorCode);
			operationresponseBO.setMessage("(Comet_BPM000) ".concat(message.replaceAll("0", orderId.toString())));
			operationresponseBO.setRequestStatus("Failed");
		}

		logger.info("Exiting methode createOperationBO.",this);
		return operationresponseBO;
	}
	private JSONObject createJsonRequest(Long orderId) {
		logger.info("Starting methode createJsonRequest.",this);
		try {
			JSONObject variableValue = new JSONObject();
			variableValue.put("businessKey", orderId.toString());
			variableValue.put("messageName", "uiApmReq");
			return variableValue;
		}catch(Exception e) { 
			e.printStackTrace();
		}
		logger.info("Exiting methode createJsonRequest.",this);
		return null;
	}
}
