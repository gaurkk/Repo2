package com.att.eiis.scheduler;

import java.util.Properties;

import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.stereotype.Component;

import com.att.eiis.util.DatabaseUtil;

@Component
public class EiisSchedularContext {

	@SuppressWarnings("unchecked")
	public static void startScheduler() {
		Properties properties = DatabaseUtil.getEiisConfigProperties("QUARTZ_CONFIG");
		Scheduler scheduler = null;
		try {
			scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}

		//Status
		JobKey statusJobKey = new JobKey(properties.getProperty("statusJobName").toString(), 
				properties.getProperty("statusGroupName").toString());
		Class<? extends Job> statusClazz = null;
		try {
			 statusClazz = (Class<? extends Job>) Class.forName(properties.getProperty("statusJobClassFQDN").toString());
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		JobDetail statusQuartzJob = JobBuilder.newJob(statusClazz).withIdentity(statusJobKey).build();
		Trigger statusTrigger = TriggerBuilder.newTrigger()
				.withIdentity(properties.getProperty("statusTriggerName").toString(), 
						properties.getProperty("statusGroupName").toString())
				.withSchedule(CronScheduleBuilder.cronSchedule(properties.getProperty("statusCronExpression").toString()))   // "0 */1 * ? * *"
				.build();
		try {
			scheduler.scheduleJob(statusQuartzJob, statusTrigger);
		} catch (SchedulerException e1) {
			e1.printStackTrace();
		}

		//Details
		JobKey detailsJobKey = new JobKey(properties.getProperty("detailsJobName").toString(), 
				properties.getProperty("detailsGroupName").toString());
		Class<? extends Job> detailsClazz = null;
		try {
			 detailsClazz = (Class<? extends Job>) Class.forName(properties.getProperty("detailsJobClassFQDN").toString());
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		JobDetail detailsQuartzJob = JobBuilder.newJob(detailsClazz).withIdentity(detailsJobKey).build();
		Trigger detailsTrigger = TriggerBuilder.newTrigger()
				.withIdentity(properties.getProperty("detailsTriggerName").toString(), 
						properties.getProperty("detailsGroupName").toString())
				.withSchedule(CronScheduleBuilder.cronSchedule(properties.getProperty("detailsCronExpression").toString()))
				.build();
		try {
			scheduler.scheduleJob(detailsQuartzJob, detailsTrigger);
		} catch (SchedulerException e1) {
			e1.printStackTrace();
		}

	}
}