package com.att.comet.order.constant;

public enum ContactTypeUserRoleEnum {
	ORDER_SUBMITTER				(1003L, 1001L),
	ORDER_APPROVER				(1004L, 1002L),
	ORDER_MANAGER				(1005L, 1003L),
	CCSPM						(1006L, 1005L),
	NETWORK_IMPLEMENTATION		(1007L, 1004L),
	OSD							(1023L, 1001L),
	IT_OPS						(1024L, 1008L)
	;
	
	private Long contactTypeId;
	private Long roleId;
	
	public Long getContactTypeId() {
		return contactTypeId;
	}
	
	public Long getRoleId() {
		return roleId;
	}
	
	public static ContactTypeUserRoleEnum getByContactTypeId(Long contactTypeId) {
		ContactTypeUserRoleEnum contactTypeUserRoleEnum = null;
		for (ContactTypeUserRoleEnum cturEnum : values()) {
			if (cturEnum.getContactTypeId().equals(contactTypeId)) {
				contactTypeUserRoleEnum = cturEnum;
			}
		}
		return contactTypeUserRoleEnum;
	}

	private ContactTypeUserRoleEnum(Long contactTypeId, Long roleId) {
		this.contactTypeId = contactTypeId;
		this.roleId = roleId;
	}	
}
