package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_USER_TRACKER_LOG")
public class OrderUserTrackerLog implements Serializable {

	private static final long serialVersionUID = -2978379040255476724L;
	
	private long trackLogId;
	private Orders orders;
	private String attuid;
	private long roleId;
	private String action;
	private String tabName;
	private Date accessOn;
	private String ipAddress;
	private String browser;

	public OrderUserTrackerLog() {
	}

	public OrderUserTrackerLog(long trackLogId, Orders orders, String attuid,
			long roleId, String action) {
		this.trackLogId = trackLogId;
		this.orders = orders;
		this.attuid = attuid;
		this.roleId = roleId;
		this.action = action;
	}

	public OrderUserTrackerLog(long trackLogId, Orders orders, String attuid,
			long roleId, String action, String tabName, Date accessOn,
			String ipAddress, String browser) {
		this.trackLogId = trackLogId;
		this.orders = orders;
		this.attuid = attuid;
		this.roleId = roleId;
		this.action = action;
		this.tabName = tabName;
		this.accessOn = accessOn;
		this.ipAddress = ipAddress;
		this.browser = browser;
	}

	@Id
	@Column(name = "TRACK_LOG_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_TRACK_LOG_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_TRACK_LOG_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRACK_LOG_ID")
	public long getTrackLogId() {
		return this.trackLogId;
	}

	public void setTrackLogId(long trackLogId) {
		this.trackLogId = trackLogId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return this.orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	@Column(name = "ATTUID", nullable = false, length = 6)
	public String getAttuid() {
		return this.attuid;
	}

	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	@Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)
	public long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	@Column(name = "ACTION", nullable = false, length = 100)
	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Column(name = "TAB_NAME", length = 100)
	public String getTabName() {
		return this.tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	@Column(name = "ACCESS_ON")
	public Date getAccessOn() {
		return this.accessOn;
	}

	public void setAccessOn(Date accessOn) {
		this.accessOn = accessOn;
	}

	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Column(name = "BROWSER", length = 100)
	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}
}