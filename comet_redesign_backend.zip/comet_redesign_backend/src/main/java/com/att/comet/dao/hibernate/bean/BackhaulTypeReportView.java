package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BACKHAUL_TYPE_REPORT_VIEW")
public class BackhaulTypeReportView implements Serializable{

	private static final long serialVersionUID = -2713510690718401054L;
	
	private Long orderId;
	private Long bhId;
	private String bhDisplayId;
	private String status;
	private Long bhTypeId;
	private String bhTypeName;
	private String dcName;
	private String createdBy;
	private Long derivedFromBH;
	private String masterAccName;
	private String ubcId;
	private String subAccName;
	private String bcId;
	private String internalProductAccName;
	private String cipn;
	private String apnName;
	private String orderCreatedOn;
	
	@Column(name = "ORDER_CREATED_ON")
	public String getOrderCreatedOn() {
		return orderCreatedOn;
	}
	public void setOrderCreatedOn(String orderCreatedOn) {
		this.orderCreatedOn = orderCreatedOn;
	}
	
	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	@Id
	@Column(name = "BACKHAUL_ID")
	public Long getBhId() {
		return bhId;
	}
	public void setBhId(Long bhId) {
		this.bhId = bhId;
	}
	@Column(name = "BACKHAUL_DISPLAY_ID")
	public String getBhDisplayId() {
		return bhDisplayId;
	}
	public void setBhDisplayId(String bhDisplayId) {
		this.bhDisplayId = bhDisplayId;
	}
	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Column(name = "BACKHAUL_TYPE_ID")
	public Long getBhTypeId() {
		return bhTypeId;
	}
	public void setBhTypeId(Long bhTypeId) {
		this.bhTypeId = bhTypeId;
	}
	@Column(name = "BACKHAUL_TYPE_NAME")
	public String getBhTypeName() {
		return bhTypeName;
	}
	public void setBhTypeName(String bhTypeName) {
		this.bhTypeName = bhTypeName;
	}
	@Column(name = "DATA_CENTER_NAME")
	public String getDcName() {
		return dcName;
	}
	public void setDcName(String dcName) {
		this.dcName = dcName;
	}
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Column(name = "DERIVED_FROM_BACKHAUL")
	public Long getDerivedFromBH() {
		return derivedFromBH;
	}
	public void setDerivedFromBH(Long derivedFromBH) {
		this.derivedFromBH = derivedFromBH;
	}
	@Column(name = "MASTER_ACCOUNT_NAME")
	public String getMasterAccName() {
		return masterAccName;
	}
	public void setMasterAccName(String masterAccName) {
		this.masterAccName = masterAccName;
	}
	@Column(name = "UBCID")
	public String getUbcId() {
		return ubcId;
	}
	public void setUbcId(String ubcId) {
		this.ubcId = ubcId;
	}
	@Column(name = "SUB_ACCOUNT_NAME")
	public String getSubAccName() {
		return subAccName;
	}
	public void setSubAccName(String subAccName) {
		this.subAccName = subAccName;
	}
	@Column(name = "BCID")
	public String getBcId() {
		return bcId;
	}
	public void setBcId(String bcId) {
		this.bcId = bcId;
	}
	@Column(name = "INTERNAL_PRODUCT_ACCOUNT_NAME")
	public String getInternalProductAccName() {
		return internalProductAccName;
	}
	public void setInternalProductAccName(String internalProductAccName) {
		this.internalProductAccName = internalProductAccName;
	}
	@Column(name = "CIPN")
	public String getCipn() {
		return cipn;
	}
	public void setCipn(String cipn) {
		this.cipn = cipn;
	}
	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}
}
