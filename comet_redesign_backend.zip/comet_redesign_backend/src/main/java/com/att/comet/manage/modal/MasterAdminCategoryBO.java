package com.att.comet.manage.modal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import lombok.Data;

@Data
public class MasterAdminCategoryBO {

	private Long categoryId;

	private String categoryName;

	private Boolean isSpecialCategory = false;

	private List<String> categoryDropDownNameList = new ArrayList<>();

}
