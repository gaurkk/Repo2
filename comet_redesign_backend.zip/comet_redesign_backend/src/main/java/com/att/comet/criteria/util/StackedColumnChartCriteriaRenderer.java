package com.att.comet.criteria.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.exception.SQLGrammarException;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.charts.modal.ChartNameEnum;
import com.att.comet.charts.modal.OrderScheduleColumnsEnum;
import com.att.comet.charts.result.OrderScheduleColumnChartBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.dao.ChartsSqlConstants;
import com.att.comet.dao.ScalarConstants;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.order.OrderScheduleRestriction;

@Component
public class StackedColumnChartCriteriaRenderer extends CriteriaRenderer {
	private static final Logger logger = LoggerFactory.getLogger(StackedColumnChartCriteriaRenderer.class);
	private static final String ORDER_SCHEDULE_COLUMN_NAME_KEY = "name";
	private static final String ORDER_SCHEDULE_COLUMN_TYPE_KEY = "type";

	@PersistenceContext
	EntityManager em;

	@Override
	public ResultBO createExecuteQuery(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQuery : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();
		if (criteria.getRestrictions().size() > 0) {
			// Get Base query
			sql.append(ChartsSqlConstants.BASE_QUERY_FOR_STACKEDCOLUMNCHART);
			if (CommonUtils.isNullEmpty(sql.toString()))
				return null;
			for (Restriction res : criteria.getRestrictions()) {
				if (CommonUtils.isNotNullEmpty(res.toSqlString())) {
					if (res instanceof OrderScheduleRestriction) {
						while (sql.lastIndexOf("@STEPID") != -1) {
							sql.replace(sql.indexOf("@STEPID"), sql.indexOf("@STEPID") + 7, res.toSqlString());
						}

					}
				}
			}
			sql = createQueryFromOtherInfo(criteria, sql);
			if (criteria.getRestrictions().size() > 0) {
				sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
			}
			result = executeQuery(sql.toString(), criteria);
		}
		logger.info("Exiting method createExecuteQuery : ", this);
		return result;
	}

	/**
	 * Add other criteria to main query (user id, role id)
	 * 
	 * @param criteria
	 * @param sql
	 * @return StringBuilder
	 */
	private StringBuilder createQueryFromOtherInfo(SearchCriteria criteria, StringBuilder sql) {
		logger.info("Starting method createQueryFromOtherInfo : ", this);
		StringBuilder sqlQuery = new StringBuilder(sql);
		if (criteria.getOther() != null) {
			OtherDetails other = criteria.getOther();
			if (CommonUtils.isNotNullEmpty(other.getUserId())) {
				String role = "";
				if (CommonUtils.isNotNullEmpty(other.getRoleId())) {
					switch (other.getRoleId().intValue()) {
					case 1001:
						role = "1003,1023";
						break;
					case 1002:
						role = "1004";
						break;
					case 1003:
						role = "1005";
						break;
					case 1004:
						role = "1007";
						break;
					case 1005:
						role = "1006";
						break;
					case 1006:
						role = "";
						break;
					case 1007:
						role = "0";
						break;
					case 1008:
						role = "1024";
						break;
					default:
						role = "1003,1023";
						break;
					}
				}
				while (sqlQuery.lastIndexOf("@USER") != -1) {
					sqlQuery.replace(sqlQuery.indexOf("@USER"), sqlQuery.indexOf("@USER") + 5,
							"'" + other.getUserId() + "' "
									+ (CommonUtils.isNotNullEmpty(role)
											? " and oci.order_contact_type_id in (" + role + ") "
											: ""));
					}
			}
		}
		logger.info("Exiting method createQueryFromOtherInfo : ", this);
		return sqlQuery;
	}

	/**
	 * Execute query for Stacked Column chart
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeQuery : ", this);
		ResultBO objBO = null;
		try {

			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.THE_DATE, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ALL_COUNT, IntegerType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.USER_COUNT, IntegerType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			objBO = new ResultBO();

			if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.TTU_SCHEDULED.toString())) {
				objBO.getOtherBO().setTitle("TTU Scheduled for next 10 days");
			} else if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.IWOS_EXPECTED.toString())) {
				objBO.getOtherBO().setTitle("IWOS Expected Complete for next 10 days");
			}

			OrderScheduleColumnChartBO columnChartBO = new OrderScheduleColumnChartBO();

			List<Map<String, String>> colMapList = new ArrayList<Map<String, String>>();
			for (OrderScheduleColumnsEnum columnEnum : OrderScheduleColumnsEnum.values()) {
				HashMap<String, String> colMap = new HashMap<String, String>();
				colMap.put(ORDER_SCHEDULE_COLUMN_NAME_KEY, columnEnum.getColumnName());
				colMap.put(ORDER_SCHEDULE_COLUMN_TYPE_KEY, columnEnum.getColumnType());
				colMapList.add(colMap);
			}
			columnChartBO.setLstColumns(colMapList);

			List<List<String>> rowList = new ArrayList<List<String>>();
			list.stream().forEach(mapsData -> {
				List<String> row = new ArrayList<>();
				mapsData.entrySet().forEach(mapData -> {
					row.add(mapData.getValue().toString());
				});
				if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.TTU_SCHEDULED.toString())) {
					row.add("color:#c0504d");/// ["#c0504d", "#4f81bd"]
				} else if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.IWOS_EXPECTED.toString())) {
					row.add("color:#a99bbd");/// ["#a99bbd", "#71588f"]
				}
				rowList.add(row);
			});
			columnChartBO.setLstRows(rowList);

			objBO.setLstResult(columnChartBO);
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeQuery : ", this);
		return objBO;
	}
}
