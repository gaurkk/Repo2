package com.att.comet.manage.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.constant.ErrorConstants;
import com.att.comet.common.constant.TypeAdminCategory;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.AdminCategoryBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CityBO;
import com.att.comet.common.modal.CountryBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.StateBO;
import com.att.comet.common.repository.AdminCategoryRepository;
import com.att.comet.common.repository.AdminConfigInfoRepository;
import com.att.comet.common.repository.CityRepository;
import com.att.comet.common.repository.CountryRepository;
import com.att.comet.common.repository.DataCenterNameRepository;
import com.att.comet.common.repository.OrderStatusRepository;
import com.att.comet.common.repository.StateRepository;
import com.att.comet.common.util.CometValidationRegExp;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.AdminConfig;
import com.att.comet.dao.hibernate.bean.City;
import com.att.comet.dao.hibernate.bean.Country;
import com.att.comet.dao.hibernate.bean.DapnInventory;
import com.att.comet.dao.hibernate.bean.DapnUploadStatus;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnDataCenterId;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnInventory;
import com.att.comet.dao.hibernate.bean.InsideOutsideBaseInterface;
import com.att.comet.dao.hibernate.bean.InsideOutsideDataCenterId;
import com.att.comet.dao.hibernate.bean.InsideOutsideStgPatInterface;
import com.att.comet.dao.hibernate.bean.InventoryTemplate;
import com.att.comet.dao.hibernate.bean.OrderStatus;
import com.att.comet.dao.hibernate.bean.State;
import com.att.comet.manage.helper.ManageDataCenterHelper;
import com.att.comet.manage.helper.ManageInventoryHelper;
import com.att.comet.manage.modal.AdminConfigParamBO;
import com.att.comet.manage.modal.DapnCSVLineBO;
import com.att.comet.manage.modal.ImsiMsisdnCSVLineBO;
import com.att.comet.manage.modal.InOutCSVLineBO;
import com.att.comet.manage.modal.InOutInterfaceCSVLineBO;
import com.att.comet.manage.modal.InventoryTemplateBO;
import com.att.comet.manage.modal.LineBO;
import com.att.comet.manage.modal.MasterAdminCategoryBO;
import com.att.comet.manage.modal.ParseResultBO;
import com.att.comet.manage.repository.DapnUploadStatusRepository;
import com.att.comet.manage.repository.ManageInventoryRepository;
import com.att.comet.order.repository.DapnInventoryRepository;
import com.att.comet.order.repository.ImsiMsisdnInventoryRepository;
import com.att.comet.order.repository.InsideOutsideBaseInterfaceRepository;
import com.att.comet.order.repository.InsideOutsideStgPatInterfaceRepository;
import com.att.comet.order.repository.OrderDataCenterRepository;

import oracle.jdbc.OracleTypes;

@Component
public class ManageDAOImpl implements ManageDAO {

	Logger logger = LoggerFactory.getLogger(ManageDAOImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	ManageInventoryHelper manageInventoryHelper;

	@Autowired
	ManageDataCenterHelper manageDataCenterHelper;

	@Autowired
	InsideOutsideStgPatInterfaceRepository insideOutsideStgPatInterfaceRepository;

	@Autowired
	ImsiMsisdnInventoryRepository imsiMsisdnInventoryRepository;

	@Autowired
	InsideOutsideBaseInterfaceRepository insideOutsideBaseInterfaceRepository;

	@Autowired
	DapnInventoryRepository dapnInventoryRepository;

	@Autowired
	ManageInventoryRepository manageInventoryRepository;

	@Autowired
	CountryRepository countryRepository;

	@Autowired
	StateRepository stateRepository;

	@Autowired
	CityRepository cityRepository;

	@Autowired
	DataCenterNameRepository dataCenterNameRepository;

	@Autowired
	AdminConfigInfoRepository adminConfigInfoRepository;

	@Autowired
	AdminCategoryRepository adminCategoryRepository;

	@Autowired
	OrderDataCenterRepository orderDataCenterRepository;

	@Autowired
	OrderStatusRepository orderStatusRepository;

	@Autowired
	DapnUploadStatusRepository  dapnUploadStatusRepository;

	@Override
	public List<InsideOutsideStgPatInterface> getInsideOutsidePAT(Long dataCenterId) {
		return insideOutsideStgPatInterfaceRepository.findByInsideOutsideDataCenterId_DataCenterId(dataCenterId);
	}

	@Override
	public List<ImsiMsisdnInventory> getImsiMsisdn(Long dataCenterId) {
		return imsiMsisdnInventoryRepository.findByImsiMsisdnDataCenterId_DataCenterId(dataCenterId);
	}

	@Override
	public List<InsideOutsideBaseInterface> getInOutBaseInterface(Long dataCenterId) {
		return insideOutsideBaseInterfaceRepository.findByInsideOutsideDataCenterId_DataCenterId(dataCenterId);
	}

	@Override
	public List<DapnInventory> getDapnInventory(Long dataCenterId) {
		return dapnInventoryRepository.findByDataCenter_DataCenterIdAndDapnStatus_DapnStatusIdNotIn(dataCenterId,
				1005L);
	}

	@Override
	public List<InventoryTemplateBO> downloadManageInventoryTemplate(String inventory) {
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Starting method downloadManageInventoryTemplate.");
		List<InventoryTemplateBO> inventoryTemplateBOList = new ArrayList<InventoryTemplateBO>();
		InventoryTemplateBO inventoryTemplateBO = null;
		List<InventoryTemplate> inventoryTemplateList = manageInventoryRepository
				.findDistinctByTemplateNameOrderByColumnNumberAsc(inventory);
		if (inventoryTemplateList != null) {
			for (InventoryTemplate inventoryTemplate : inventoryTemplateList) {
				inventoryTemplateBO = new InventoryTemplateBO();
				inventoryTemplateBO.setFieldName(inventoryTemplate.getFieldName());
				inventoryTemplateBO.setColNumber(inventoryTemplate.getColumnNumber());
				inventoryTemplateBOList.add(inventoryTemplateBO);
			}
		}
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Exiting method downloadManageInventoryTemplate.");
		return inventoryTemplateBOList;
	}

	@Override
	public List<InventoryTemplateBO> getInventoryNameList() {
		logger.info("Starting method getInventoryNameList");
		List<InventoryTemplateBO> inventoryTemplateBOList = new ArrayList<InventoryTemplateBO>();
		InventoryTemplateBO inventoryTemplateBO = null;
		List<String> inventoryTemplateList = manageInventoryRepository.findDistinctTemplates();
		if (inventoryTemplateList != null) {
			for (String inventoryTemplate : inventoryTemplateList) {
				inventoryTemplateBO = new InventoryTemplateBO();
				inventoryTemplateBO.setTemplateName(inventoryTemplate);
				inventoryTemplateBOList.add(inventoryTemplateBO);
			}
		}
		logger.info("Exiting method getInventoryNameList");
		return inventoryTemplateBOList;
	}

	@Override
	public ParseResultBO saveInOutStgPATs(ParseResultBO parseResultBO) {
		logger.info("Starting method saveInOutStgPATs", this);
		for (LineBO lineBO : parseResultBO.getLines()) {
			InOutCSVLineBO inOutBO = (InOutCSVLineBO) lineBO;
			try {
				CriteriaBuilder builder = entityManager.getCriteriaBuilder();
				CriteriaQuery<DataCenter> query = builder.createQuery(DataCenter.class);
				Root root = query.from(DataCenter.class);
				Predicate templateDetails = builder.equal(root.get("dataCenterName"), inOutBO.getDataCenterName());
				query.where(builder.and(templateDetails));
				@SuppressWarnings("unchecked")
				List<DataCenter> results = entityManager.createQuery(query.select(root)).getResultList();
				if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('N')) {
					DataCenter dataCenter = results.get(0);
					InsideOutsideStgPatInterface insideOutsideStgPatInterface = insideOutsideStgPatInterfaceRepository
							.findByInsideOutsideDataCenterId_DataCenterIdAndInsideOutsideDataCenterId_InsideOutside(
									dataCenter.getDataCenterId(),
									inOutBO.getInsidePat() + "-" + inOutBO.getOutsidePat());
					if (null!=insideOutsideStgPatInterface && insideOutsideStgPatInterface.getInsideOutsideDataCenterId().getDataCenterId()
							.equals(dataCenter.getDataCenterId())
							&& insideOutsideStgPatInterface.getInsideOutsideDataCenterId().getInsideOutside()
							.equals(inOutBO.getInsidePat() + "-" + inOutBO.getOutsidePat())) {
						parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
								"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsidePat() + "-"
										+ inOutBO.getOutsidePat() + " channel range already exists for data center "
										+ inOutBO.getDataCenterName(),
										"ERROR", null));
					} else {
						InsideOutsideStgPatInterface inOutStgPat = new InsideOutsideStgPatInterface();
						InsideOutsideDataCenterId inOutDcId = new InsideOutsideDataCenterId(
								dataCenter.getDataCenterId(), (inOutBO.getInsidePat() + "-" + inOutBO.getOutsidePat()));
						inOutStgPat.setInsideOutsideDataCenterId(inOutDcId);
						inOutStgPat.setDataCenter(dataCenter);
						insideOutsideStgPatInterfaceRepository.save(inOutStgPat);
						// PAT Records added successfully
						parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
								"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsidePat() + "-"
										+ inOutBO.getOutsidePat() + " channel range for data center "
										+ inOutBO.getDataCenterName() + " added successfully",
										"SUCCESS", null));
					}
				} else if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('Y')) {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " is dummy",
							"ERROR", null));
				} else {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " does not exists",
							"ERROR", null));
				}
			} catch (Exception e) {
				e.printStackTrace();
				parseResultBO.getMessages()
				.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
						"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsidePat() + "-"
								+ inOutBO.getOutsidePat() + " channel range already exists for data center "
								+ inOutBO.getDataCenterName(),
								"ERROR", null));
			}
		}
		logger.info("Existing method saveInOutStgPATs", this);
		return parseResultBO;
	}

	@Override
	public ParseResultBO saveINOUTInterfaceFile(ParseResultBO parseResultBO, LineBO lineBo)
			throws CometDataException, CometServiceException {
		logger.info("Starting method saveINOUTInterfaceFile", this);
		InOutInterfaceCSVLineBO inOutBO = (InOutInterfaceCSVLineBO) lineBo;
		try {
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<DataCenter> query = builder.createQuery(DataCenter.class);
			Root root = query.from(DataCenter.class);
			Predicate templateDetails = builder.equal(root.get("dataCenterName"), inOutBO.getDataCenter());
			query.where(builder.and(templateDetails));
			@SuppressWarnings("unchecked")
			List<DataCenter> results = entityManager.createQuery(query.select(root)).setMaxResults(1).getResultList();
			if (results != null && results.size() > 0 && results.get(0) != null
					&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
					&& results.get(0).getDummy().equals('N')) {
				DataCenter dataCenter = results.get(0);
				InsideOutsideBaseInterface inOutBase = insideOutsideBaseInterfaceRepository
						.findByInsideOutsideDataCenterId_DataCenterIdAndInsideOutsideDataCenterId_InsideOutside(
								dataCenter.getDataCenterId(),
								(inOutBO.getInsideBase() + "-" + inOutBO.getOutsideBase()));
				if (null!=inOutBase && inOutBase.getInsideOutsideDataCenterId().getDataCenterId().equals(dataCenter.getDataCenterId())
						&& inOutBase.getInsideOutsideDataCenterId().getInsideOutside()
						.equalsIgnoreCase(inOutBO.getInsideBase() + "-" + inOutBO.getOutsideBase())) {
					// PAT Records already exist
					parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
							"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsideBase() + "-"
									+ inOutBO.getOutsideBase() + " channel range already exists for data center "
									+ inOutBO.getDataCenter(),
									"ERROR", null));
				} else {
					InsideOutsideBaseInterface inOutBaseNew = new InsideOutsideBaseInterface();
					InsideOutsideDataCenterId inOutDcId = new InsideOutsideDataCenterId(dataCenter.getDataCenterId(),
							(inOutBO.getInsideBase() + "-" + inOutBO.getOutsideBase()));
					inOutBaseNew.setDataCenter(dataCenter);
					inOutBaseNew.setInsideOutsideDataCenterId(inOutDcId);
					inOutBaseNew.setGwSgiContext(inOutBO.getGwSgiContext());
					inOutBaseNew.setRdRt(inOutBO.getRdRt());
					insideOutsideBaseInterfaceRepository.save(inOutBaseNew);
					// PAT Records added successfully
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
							"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsideBase() + "-"
									+ inOutBO.getOutsideBase() + " channel range for data center "
									+ inOutBO.getDataCenter() + " added successfully",
									"SUCCESS", null));
				}
			} else if (results != null && results.size() > 0 && results.get(0) != null
					&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
					&& results.get(0).getDummy().equals('Y')) {
				parseResultBO.getMessages()
				.add(manageInventoryHelper
						.getErrorBO(
								inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
								+ ": Data center " + inOutBO.getDataCenter() + " is dummy",
								"ERROR", null));
			} else {
				parseResultBO.getMessages()
				.add(manageInventoryHelper
						.getErrorBO(
								inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
								+ ": Data center " + inOutBO.getDataCenter() + " does not exists",
								"ERROR", null));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Existing method saveINOUTInterfaceFile", this);
		return parseResultBO;
	}

	@Override
	public ParseResultBO saveImsiMsisdnFile(ParseResultBO parseResultBO)
			throws CometDataException, CometServiceException {
		for (LineBO lineBO : parseResultBO.getLines()) {
			ImsiMsisdnCSVLineBO inOutBO = (ImsiMsisdnCSVLineBO) lineBO;
			try {

				CriteriaBuilder builder = entityManager.getCriteriaBuilder();
				CriteriaQuery<DataCenter> query = builder.createQuery(DataCenter.class);
				Root root = query.from(DataCenter.class);
				Predicate templateDetails = builder.equal(root.get("dataCenterName"), inOutBO.getDataCenterName());
				query.where(builder.and(templateDetails));
				@SuppressWarnings("unchecked")
				List<DataCenter> results = entityManager.createQuery(query.select(root)).setMaxResults(1)
				.getResultList();
				if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('N')) {
					if (!CometValidationRegExp.invalidNumeric(inOutBO.getImsi()) && inOutBO.getImsi().length() < 21
							&& !CometValidationRegExp.invalidNumeric(inOutBO.getMsisdn())
							&& inOutBO.getMsisdn().length() < 21) {
						DataCenter dataCenter = results.get(0);
						ImsiMsisdnInventory imsiMsisdnInventory = imsiMsisdnInventoryRepository
								.findByImsiMsisdnDataCenterId_DataCenterIdAndImsiMsisdnDataCenterId_ImsiMsisdn(
										dataCenter.getDataCenterId(), inOutBO.getImsi() + "-" + inOutBO.getMsisdn());
						if (null!=imsiMsisdnInventory && imsiMsisdnInventory.getImsiMsisdnDataCenterId().getDataCenterId()
								.equals(dataCenter.getDataCenterId())
								&& imsiMsisdnInventory.getImsiMsisdnDataCenterId().getImsiMsisdn()
								.equalsIgnoreCase(inOutBO.getImsi() + "-" + inOutBO.getMsisdn())) {
							parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
									"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-"
											+ inOutBO.getMsisdn() + " channel range already exists for data center "
											+ inOutBO.getDataCenterName(),
											"ERROR", null));
						} else {
							ImsiMsisdnInventory imsiInv = new ImsiMsisdnInventory();
							ImsiMsisdnDataCenterId imsiDcId = new ImsiMsisdnDataCenterId(dataCenter.getDataCenterId(),
									(inOutBO.getImsi() + "-" + inOutBO.getMsisdn()));
							imsiInv.setImsiMsisdnDataCenterId(imsiDcId);
							imsiInv.setDataCenter(dataCenter);
							imsiMsisdnInventoryRepository.save(imsiInv);
							// IMSI/MSISDN Records added successfully
							parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
									"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-"
											+ inOutBO.getMsisdn() + " channel range for data center "
											+ inOutBO.getDataCenterName() + " added successfully",
											"SUCCESS", null));
						}
					} else if (CometValidationRegExp.invalidNumeric(inOutBO.getImsi())
							|| CometValidationRegExp.invalidNumeric(inOutBO.getMsisdn())) {
						parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
								"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-"
										+ inOutBO.getMsisdn() + " is not valid as it contains special characters",
										"ERROR", null));
					} else {
						parseResultBO.getMessages()
						.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
								"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-"
										+ inOutBO.getMsisdn() + " is not valid as the entry length exceeds 20",
										"ERROR", null));
					}

				} else if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('Y')) {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " is dummy",
							"ERROR", null));
				} else {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " does not exists",
							"ERROR", null));
				}
			} catch (Exception e) {
				e.printStackTrace();
				parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
						"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-" + inOutBO.getMsisdn()
						+ " channel range already exists for data center " + inOutBO.getDataCenterName(),
						"ERROR", null));
			}
		}
		return parseResultBO;
	}

	@Override
	public ParseResultBO saveRDRTFile(ParseResultBO resultBO) throws CometDataException, CometServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ParseResultBO updateINOUTInterfaceFile(ParseResultBO parseResultBO, LineBO lineBo)
			throws CometDataException, CometServiceException {
		logger.info("Starting method updateINOUTInterfaceFile", this);
		InOutInterfaceCSVLineBO inOutBO = (InOutInterfaceCSVLineBO) lineBo;
		try {
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<DataCenter> query = builder.createQuery(DataCenter.class);
			Root root = query.from(DataCenter.class);
			Predicate templateDetails = builder.equal(root.get("dataCenterName"), inOutBO.getDataCenter());
			query.where(builder.and(templateDetails));
			@SuppressWarnings("unchecked")
			List<DataCenter> results = entityManager.createQuery(query.select(root)).getResultList();

			// criteria.setMaxResults(1);
			if (results != null && results.size() > 0 && results.get(0) != null
					&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
					&& results.get(0).getDummy().equals('N')) {
				DataCenter dataCenter = results.get(0);
				InsideOutsideDataCenterId inoutDataCenterId = new InsideOutsideDataCenterId();
				inoutDataCenterId.setDataCenterId(dataCenter.getDataCenterId());
				inoutDataCenterId.setInsideOutside(inOutBO.getInsideBase() + "-" + inOutBO.getOutsideBase());

				Object object = entityManager.getReference(InsideOutsideBaseInterface.class, inoutDataCenterId);

				if (object == null) {
					InsideOutsideBaseInterface inOutBase = new InsideOutsideBaseInterface();
					InsideOutsideDataCenterId inOutDcId = new InsideOutsideDataCenterId(dataCenter.getDataCenterId(),
							(inOutBO.getInsideBase() + "-" + inOutBO.getOutsideBase()));
					inOutBase.setDataCenter(dataCenter);
					inOutBase.setInsideOutsideDataCenterId(inOutDcId);
					inOutBase.setGwSgiContext(inOutBO.getGwSgiContext());
					inOutBase.setRdRt(inOutBO.getRdRt());
					insideOutsideBaseInterfaceRepository.save(inOutBase);
					// PAT Records added successfully
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
							"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsideBase() + "-"
									+ inOutBO.getOutsideBase() + " channel range for data center "
									+ inOutBO.getDataCenter() + " added successfully",
									"SUCCESS", null));
				} else {
					InsideOutsideBaseInterface inOutBase = (InsideOutsideBaseInterface) object;
					inOutBase.setDataCenter(dataCenter);
					inOutBase.setGwSgiContext(inOutBO.getGwSgiContext());
					inOutBase.setRdRt(inOutBO.getRdRt());
					insideOutsideBaseInterfaceRepository.save(inOutBase);
					// PAT Records added successfully
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
							"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsideBase() + "-"
									+ inOutBO.getOutsideBase() + " channel range for data center "
									+ inOutBO.getDataCenter() + " updated successfully",
									"SUCCESS", null));
				}
			} else if (results != null && results.size() > 0 && results.get(0) != null
					&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
					&& results.get(0).getDummy().equals('Y')) {
				parseResultBO.getMessages()
				.add(manageInventoryHelper
						.getErrorBO(
								inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
								+ ": Data center " + inOutBO.getDataCenter() + " is dummy",
								"ERROR", null));
			} else {
				parseResultBO.getMessages()
				.add(manageInventoryHelper
						.getErrorBO(
								inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
								+ ": Data center " + inOutBO.getDataCenter() + " does not exists",
								"ERROR", null));
			}
		} catch (Exception e) {
			e.printStackTrace();
			parseResultBO.getMessages()
			.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
					"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getInsideBase() + "-"
							+ inOutBO.getOutsideBase() + " channel range can not updated for data center "
							+ inOutBO.getDataCenter(),
							"ERROR", null));
		}
		logger.info("Existing method updateINOUTInterfaceFile", this);
		return parseResultBO;
	}

	@Override
	public ParseResultBO updateImsiMsisdnFile(ParseResultBO parseResultBO)
			throws CometDataException, CometServiceException {
		for (LineBO lineBO : parseResultBO.getLines()) {
			ImsiMsisdnCSVLineBO inOutBO = (ImsiMsisdnCSVLineBO) lineBO;
			try {
				CriteriaBuilder builder = entityManager.getCriteriaBuilder();
				CriteriaQuery<DataCenter> query = builder.createQuery(DataCenter.class);
				Root root = query.from(DataCenter.class);
				Predicate templateDetails = builder.equal(root.get("dataCenterName"), inOutBO.getDataCenterName());
				query.where(builder.and(templateDetails));
				@SuppressWarnings("unchecked")
				List<DataCenter> results = entityManager.createQuery(query.select(root)).getResultList();

				if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('N')) {
					DataCenter dataCenter = results.get(0);
					ImsiMsisdnInventory imsiInv = new ImsiMsisdnInventory();
					ImsiMsisdnDataCenterId imsiDcId = new ImsiMsisdnDataCenterId(dataCenter.getDataCenterId(),
							(inOutBO.getImsi() + "-" + inOutBO.getMsisdn()));
					imsiInv.setImsiMsisdnDataCenterId(imsiDcId);
					imsiInv.setDataCenter(dataCenter);
					imsiMsisdnInventoryRepository.save(imsiInv);
					// IMSI/MSISDN Records added successfully
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
							"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-"
									+ inOutBO.getMsisdn() + " channel range for data center "
									+ inOutBO.getDataCenterName() + " updated successfully",
									"SUCCESS", null));
				} else if (results != null && results.size() > 0 && results.get(0) != null
						&& CommonUtils.isNotNullEmpty(results.get(0).getDataCenterId())
						&& results.get(0).getDummy().equals('Y')) {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " is dummy",
							"ERROR", null));
				} else {
					parseResultBO.getMessages()
					.add(manageInventoryHelper.getErrorBO(
							inOutBO.getRecordNumber(), "Record# " + (inOutBO.getRecordNumber())
							+ ": Data center " + inOutBO.getDataCenterName() + " does not exists",
							"ERROR", null));
				}
			} catch (Exception e) {
				e.printStackTrace();
				parseResultBO.getMessages().add(manageInventoryHelper.getErrorBO(inOutBO.getRecordNumber(),
						"Record# " + (inOutBO.getRecordNumber()) + ": " + inOutBO.getImsi() + "-" + inOutBO.getMsisdn()
						+ " channel range can not updated for data center " + inOutBO.getDataCenterName(),
						"ERROR", null));
			}
		}
		return parseResultBO;
	}

	@Override
	public List<CountryBO> getCountryList() {
		logger.info("Starting method getCountryList : ");
		List<Country> countryNameList = countryRepository.findAll(Sort.by(Sort.Direction.ASC, "countryName"));
		List<CountryBO> countryList = new ArrayList<CountryBO>();
		CountryBO countryTypeBO = null;
		for (Country country : countryNameList) {
			if (country != null) {
				countryTypeBO = new CountryBO();
				countryTypeBO.setCountryId(country.getCountryId());
				countryTypeBO.setCountryName(country.getCountryName());
				countryTypeBO.setActive(country.getActive());
				countryList.add(countryTypeBO);
			}
		}
		logger.info("Exiting method getCountryList : ");
		return countryList;
	}

	@Override
	public List<StateBO> getStateList(Long countryId) {
		logger.info("Starting method getStateList : ");
		List<State> stateNameList = stateRepository.findByCountry_CountryId(countryId);
		List<StateBO> stateList = new ArrayList<StateBO>();
		StateBO stateTypeBO = null;
		for (State state : stateNameList) {
			if (state != null) {
				stateTypeBO = new StateBO();
				stateTypeBO.setStateId(state.getStateId());
				stateTypeBO.setStateName(state.getStateName());
				stateList.add(stateTypeBO);
				Collections.sort(stateList);
			}
		}
		logger.info("Exiting method getStateList : ");
		return stateList;
	}

	@Override
	public List<CityBO> getCityList(Long stateId, String criteria) {
		logger.info("Starting method getCityList : ");
		List<String> cityNameList = cityRepository.getCityNameList(stateId, criteria);
		List<CityBO> cityList = new ArrayList<CityBO>();
		CityBO cityTypeBO = null;
		for (String city : cityNameList) {
			if (city != null) {
				cityTypeBO = new CityBO();
				String city_Id[] = city.split(",");
				cityTypeBO.setCityId(Long.parseLong(city_Id[0]));
				cityTypeBO.setCityName(city_Id[1]);
				cityList.add(cityTypeBO);
			}
		}
		logger.info("Exiting method getCityList : ");
		return cityList;
	}

	@Override
	public String saveAndUpdateCountryName(CountryBO countryBO) throws CometDataException, CometServiceException {
		logger.info("Starting method saveAndUpdateCountryName : ");
		Country country = null;
		String msg = null;
		if ((countryBO.getCountryName() != null && countryBO.getCountryName() != "") && countryBO.getActive() != null) {
			Country countryInfo = countryRepository.findByCountryNameIgnoreCase(countryBO.getCountryName());
			if (countryBO.getActive().equals('Y') || countryBO.getActive().equals('N')) {
				if (countryInfo == null && countryBO.getCountryId() == null) {
					country = new Country();
					country.setCountryName(countryBO.getCountryName());
					country.setActive(countryBO.getActive());
				}else if (countryBO.getCountryId() != null) {
					Optional<Country> updateCountryInfo = countryRepository.findById(countryBO.getCountryId());
					country = updateCountryInfo.get();
					if(updateCountryInfo.isPresent() && (countryInfo == null ||country.getCountryName().equalsIgnoreCase(countryInfo.getCountryName()))) {
						country = new Country();
						country.setCountryId(countryBO.getCountryId());
						country.setCountryName(countryBO.getCountryName());
						country.setActive(countryBO.getActive());
					} else {
						logger.error(
								"[Country Name : " + countryBO.getCountryName() +
										"CountryInfo Name And Country Name are different ",
										this);
						throw new CometDataException("CountryInfo Name And Country Name are different");
					}
				}else {
					logger.error(
							"[CountryName : " + countryBO.getCountryName() + "] "+"[CountryId : " + countryBO.getCountryId()+ "] " + 
									"Country Name already available or countryId can not be null",
									this);
					throw new CometDataException("Country Name already available or countryId can not be null");
				}
				country = countryRepository.save(country);
				if(countryBO.getCountryId() != null) {
					msg = "Country updated successfully.";
				}else {
					msg = "Country added successfully.";
				}
			} else {
				logger.error("[IsActive : " + countryBO.getActive() + "] " + "Enter value Y or N", this);
				throw new CometDataException("Enter value Y or N");
			}
		} else {
			logger.error("[CountryName : " + countryBO.getCountryName() + "] " + "Country Name having null value",
					this);
			throw new CometDataException("Country Name having null value");
		}
		logger.info("Exiting method saveAndUpdateCountryName : ");
		return msg;
	}

	@Override
	public String saveDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		logger.info("Starting method addDataCenter", this);
		DataCenter dataCenter = new DataCenter();
		String msg = null;
		boolean duplicateFlag = checkDuplicateDataCenter(dataCenterBO.getDataCenterName());
		if (!duplicateFlag) {
			dataCenter = manageDataCenterHelper.populateDataCenter(dataCenterBO, dataCenter);
			dataCenterNameRepository.saveAndFlush(dataCenter);
			msg = "Data Center [" + dataCenterBO.getDataCenterName() + "] has been added.";
		} else {
			msg = "Please change the data center name as [" + dataCenterBO.getDataCenterName() + "] already exists.";
		}
		logger.info("End of method addDataCenter", this);
		return msg;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	private boolean checkDuplicateDataCenter(String dataCenterName) throws CometDataException {

		logger.info("Starting method addDataCenter", this);
		boolean flag = false;
		try {
			if (CommonUtils.isNotNullEmpty(dataCenterName)) {
				Query query = entityManager.createNativeQuery(CometCommonConstant.CHECK_DUPLICATE_DATA_CENTER);
				query.setParameter(CometCommonConstant.DATA_CENTER_NAME, dataCenterName);
				query.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				Map<String, Object> resultMap = null;
				List<Map<String, Object>> lstResult = query.getResultList();
				Integer count = 0;
				if (!CollectionUtils.isEmpty(lstResult)) {
					Iterator<Map<String, Object>> iterator = lstResult.iterator();
					while (iterator.hasNext()) {
						resultMap = iterator.next();
						count = Integer.parseInt(resultMap.values().iterator().next().toString());
					}
				}
				if (count >= 1) {
					flag = true;
				}
			}
		} catch (Exception exception) {
			logger.error("[DataCenterName : " + (dataCenterName == null ? "" : dataCenterName) + "] "
					+ exception.getStackTrace());
			throw new CometDataException("Error", "Add DataCenter Failed", exception);
		}
		logger.info("End of method addDataCenter", this);
		return flag;
	}

	@Override
	public List<MasterAdminCategoryBO> getCategoryInfo() throws CometDataException {
		logger.info("Starting method getCategoryInfo :", this);
		List<AdminCategory> adminCategoryList = adminCategoryRepository
				.findAll(Sort.by(Direction.ASC, "adminCategoryName"));
		if (null == adminCategoryList) {
			logger.error("No Record Found For Category Of Master Data Maintenance.", this);
			throw new CometDataException("No Record Found For Category Of Master Data Maintenance.");
		}
		List<String> dropDownList = null;
		List<MasterAdminCategoryBO> masterAdminCategoryBOList = new ArrayList<>();
		for (AdminCategory adminCategory : adminCategoryList) {
			MasterAdminCategoryBO masterAdminCategoryBO = new MasterAdminCategoryBO();
			if (TypeAdminCategory.ATT_VPN_END_POINTS.toString().equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("Data Center");
				dropDownList.add("CCSMX ");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.PRIMARY_DNS_SERVER_ADDRESS.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("Data Center");
				dropDownList.add("APN Protocol");
				dropDownList.add("Source Of IP Address");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.SECONDARY_DNS_SERVER_ADDRESS.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("Data Center");
				dropDownList.add("APN Protocol");
				dropDownList.add("Source Of IP Address");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.IKE_LIST.toString().equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("CCS-MX Router");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.DC_COUNT_LIST.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("FirstNet");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.IPSECESP_LIST.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("CCS-MX Router");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_FIREWALL.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("APN Protocol");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_ROUTE.toString()
					.equals(adminCategory.getAdminCategoryId().toString())) {
				dropDownList = new ArrayList<>();
				dropDownList.add("APN Protocol");
				masterAdminCategoryBO.setIsSpecialCategory(true);
				masterAdminCategoryBO.setCategoryDropDownNameList(dropDownList);
			}
			masterAdminCategoryBO.setCategoryId(adminCategory.getAdminCategoryId());
			masterAdminCategoryBO.setCategoryName(adminCategory.getAdminCategoryName());
			masterAdminCategoryBOList.add(masterAdminCategoryBO);
		}
		logger.info("Existing method getCategoryInfo :", this);
		return masterAdminCategoryBOList;
	}

	@Override
	public AdminCategoryBO getConfigInfo(AdminConfigParamBO adminConfigParamBO) throws CometDataException {
		logger.info("Starting method getConfigInfo :", this);
		Long categoryId = adminConfigParamBO.getCategoryId();
		Boolean isSpecialCategory = adminConfigParamBO.getIsSpecialCategory();
		AdminCategoryBO adminCategoryBO = new AdminCategoryBO();
		List<AdminConfigBO> adminConfigInfoList = new ArrayList<AdminConfigBO>();
		if (null != adminConfigParamBO) {
			if (isSpecialCategory) {
				String tempCategoryValue = "";
				if (TypeAdminCategory.ATT_VPN_END_POINTS.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getDataCenter() + "@@$$@@"
							+ adminConfigParamBO.getCcsmx();
				} else if (TypeAdminCategory.PRIMARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getDataCenter() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol() + "@@$$@@" + adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.SECONDARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getDataCenter() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol() + "@@$$@@" + adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.IKE_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.DC_COUNT_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getFirstNet();
				} else if (TypeAdminCategory.IPSECESP_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_FIREWALL.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getApnProtocol();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_ROUTE.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = "@@$$@@" + adminConfigParamBO.getApnProtocol();
				}
				tempCategoryValue = tempCategoryValue.replaceAll("[^a-zA-Z0-9@@$$@@.:-]", "");
				List<AdminConfig> adminConfigList = adminConfigInfoRepository
						.findByAdminCategory_adminCategoryIdAndCategoryValueContains(categoryId, tempCategoryValue);
				for (AdminConfig adminConfig : adminConfigList) {
					AdminConfigBO configBO = new AdminConfigBO();
					String categoryValue = CommonUtils.replaceContent(adminConfig.getCategoryValue(),
							tempCategoryValue);
					configBO.setCategoryValue(categoryValue);
					configBO.setConfigId(adminConfig.getAdminConfigId());
					configBO.setDescription(adminConfig.getDescription());
					configBO.setDefaultValue(adminConfig.getDefaultValue());
					configBO.setCategoryId(adminConfigParamBO.getCategoryId());
					AdminConfigParamBO paramBO = new AdminConfigParamBO();
					paramBO.setApnProtocol(adminConfigParamBO.getApnProtocol());
					paramBO.setCcsmx(adminConfigParamBO.getCcsmx());
					paramBO.setCcsmxRouter(adminConfigParamBO.getCcsmxRouter());
					paramBO.setDataCenter(adminConfigParamBO.getDataCenter());
					paramBO.setSourceIPAddress(adminConfigParamBO.getSourceIPAddress());
					paramBO.setIsSpecialCategory(adminConfigParamBO.getIsSpecialCategory());
					paramBO.setFirstNet(adminConfigParamBO.getFirstNet());
					paramBO.setCategoryId(adminConfigParamBO.getCategoryId());
					configBO.setAdminConfigParam(paramBO);
					adminConfigInfoList.add(configBO);
				}
				adminCategoryBO.setAdminConfigInfoList(adminConfigInfoList);
				Optional<AdminCategory> categoryOptional = adminCategoryRepository.findById(categoryId);
				if (categoryOptional.isPresent()) {
					AdminCategory adminCategory = categoryOptional.get();
					adminCategoryBO.setCategoryId(adminCategory.getAdminCategoryId());
					adminCategoryBO.setCategoryName(adminCategory.getAdminCategoryName());
					adminCategoryBO.setCategoryValueType(adminCategory.getAdminCategoryValueType());
				}

			} else {
				List<AdminConfig> adminConfigList = adminConfigInfoRepository
						.findByAdminCategory_adminCategoryId(adminConfigParamBO.getCategoryId());
				for (AdminConfig adminConfig : adminConfigList) {
					AdminConfigBO configBO = new AdminConfigBO();
					configBO.setConfigId(adminConfig.getAdminConfigId());
					configBO.setDescription(adminConfig.getDescription());
					configBO.setCategoryValue(adminConfig.getCategoryValue());
					configBO.setDefaultValue(adminConfig.getDefaultValue());
					configBO.setCategoryId(adminConfigParamBO.getCategoryId());
					adminConfigInfoList.add(configBO);
				}
				adminCategoryBO.setAdminConfigInfoList(adminConfigInfoList);
				Optional<AdminCategory> categoryOptional = adminCategoryRepository.findById(categoryId);
				if (categoryOptional.isPresent()) {
					AdminCategory adminCategory = categoryOptional.get();
					adminCategoryBO.setCategoryId(adminCategory.getAdminCategoryId());
					adminCategoryBO.setCategoryName(adminCategory.getAdminCategoryName());
					adminCategoryBO.setCategoryValueType(adminCategory.getAdminCategoryValueType());
				}
			}
		}
		logger.info("Existing method getConfigInfo :", this);
		return adminCategoryBO;
	}

	@Override
	public String delDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		logger.info("Starting method delDataCenter", this);
		String msg = null;
		if (CommonUtils.isNotNullEmpty(dataCenterBO.getDataCenterId())) {
			java.util.Optional<DataCenter> optDC = dataCenterNameRepository.findById(dataCenterBO.getDataCenterId());
			if (optDC.isPresent()) {
				boolean flag = checkDataCenter(dataCenterBO.getDataCenterId());
				if (flag) {
					DataCenter dc = optDC.get();
					dataCenterNameRepository.deleteById(dc.getDataCenterId());
					msg = "Data Center [" + dataCenterBO.getDataCenterName() + "] has been Deleted.";
				} else {
					msg = "Data center [" + dataCenterBO.getDataCenterName()
					+ "] cannot be deleted as it is being used in Order.";
				}
			}
		} else {
			logger.error("[DataCenterId : "
					+ (dataCenterBO.getDataCenterId() == null ? "" : dataCenterBO.getDataCenterId()) + "] Null");
			throw new CometDataException("Error", "DataCenter Id Null");
		}
		logger.info("End method delDataCenter", this);
		return msg;
	}

	private boolean checkDataCenter(Long dataCenterId) throws CometDataException {
		logger.info("Starting method checkDataCenter", this);
		boolean flag = false;
		try {
			if (CommonUtils.isNotNullEmpty(dataCenterId)) {
				long count = orderDataCenterRepository.countById_DataCenterId(dataCenterId);
				if (count < 1) {
					flag = true;
				}
			}
		} catch (Exception exception) {
			logger.error(
					"[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] " + exception.getStackTrace());
			throw new CometDataException("Error", "Delete DataCenter Failed", exception);
		}
		logger.info("End of method checkDataCenter", this);
		return flag;
	}

	@Override
	public String deleteCountryName(Long countryId) throws CometDataException, CometServiceException {
		logger.info("Starting method deleteCountryName", this);
		StringBuilder query = manageInventoryHelper.checkUseOfTheCountryInComet(countryId);
		int sqlCountryCount = ((BigDecimal) entityManager.createNativeQuery(query.toString()).getSingleResult()).intValue();
		String countryDeletedSuccess = null;
		if (sqlCountryCount == 0) {
			List<State> lstState = stateRepository.findByCountry_CountryId(countryId);
			if (lstState != null && !lstState.isEmpty()) {
				for (State state : lstState) {
					List<City> lstCity = cityRepository.findByState_StateId(state.getStateId());
					if (lstCity != null && !lstCity.isEmpty()) {
						for (City city : lstCity) {
							cityRepository.deleteById(city.getCityId());
						}
					}
					stateRepository.deleteById(state.getStateId());
				}
			}
			Optional<Country> country = countryRepository.findById(countryId);
			if (country.isPresent()) {
				countryRepository.deleteById(countryId);
				countryDeletedSuccess = ErrorConstants.DELETE_COUNTRY_MSG+countryId;
			}
		} else {
			countryDeletedSuccess = ErrorConstants.DONTDELETE_INUSED_MSG;
		}
		logger.info("Exiting method deleteCountryName", this);
		return countryDeletedSuccess;
	}

	@Override
	public boolean addConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method addConfigInfo :", this);
		boolean isSaved = false;
		if (null != adminConfigBO) {
			Long categoryId = adminConfigBO.getCategoryId();
			AdminConfigParamBO adminConfigParamBO = adminConfigBO.getAdminConfigParam();
			Boolean isSpecialCategory = adminConfigParamBO.getIsSpecialCategory();
			if (null != isSpecialCategory && isSpecialCategory) {
				String tempCategoryValue = "";
				if (TypeAdminCategory.ATT_VPN_END_POINTS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getCcsmx();
				} else if (TypeAdminCategory.PRIMARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getApnProtocol() + "@@$$@@"
					+ adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.SECONDARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getApnProtocol() + "@@$$@@"
					+ adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.IKE_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.DC_COUNT_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getFirstNet();
				} else if (TypeAdminCategory.IPSECESP_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_FIREWALL.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_ROUTE.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol();
				}
				tempCategoryValue = tempCategoryValue.replaceAll("[^a-zA-Z0-9@@$$@@.:-]", "");
				long recordCount = adminConfigInfoRepository
						.countByAdminCategory_adminCategoryIdAndCategoryValueContains(categoryId, tempCategoryValue);
				if (recordCount == 0) {
					AdminConfig adminConfig = new AdminConfig();

					AdminCategory adminCategory = new AdminCategory();
					adminCategory.setAdminCategoryId(categoryId);

					adminConfig.setAdminCategory(adminCategory);
					adminConfig.setCategoryValue(tempCategoryValue);
					adminConfig.setDescription(adminConfigBO.getDescription());
					adminConfig.setDefaultValue(adminConfigBO.getDefaultValue());
					adminConfigInfoRepository.save(adminConfig);
					isSaved = true;
				}
			} else {
				long recordCount = adminConfigInfoRepository
						.countByAdminCategory_adminCategoryIdAndCategoryValueContains(categoryId,
								adminConfigBO.getCategoryValue());
				if (recordCount == 0) {
					AdminConfig adminConfig = new AdminConfig();

					AdminCategory adminCategory = new AdminCategory();
					adminCategory.setAdminCategoryId(categoryId);

					adminConfig.setAdminCategory(adminCategory);
					adminConfig.setCategoryValue(adminConfigBO.getCategoryValue());
					adminConfig.setDescription(adminConfigBO.getDescription());
					adminConfig.setDefaultValue(adminConfigBO.getDefaultValue());
					adminConfigInfoRepository.save(adminConfig);
					isSaved = true;
				}
			}

		}
		logger.info("Existing method addConfigInfo :", this);
		return isSaved;
	}

	@Override
	public boolean updateConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method updateConfigInfo :", this);
		boolean isEdited = false;
		if (null != adminConfigBO.getConfigId()) {
			AdminConfigParamBO adminConfigParamBO = adminConfigBO.getAdminConfigParam();
			Boolean isSpecialCategory = adminConfigParamBO.getIsSpecialCategory();
			if (null != isSpecialCategory && isSpecialCategory) {
				Long categoryId = adminConfigBO.getCategoryId();
				String tempCategoryValue = "";
				if (TypeAdminCategory.ATT_VPN_END_POINTS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getCcsmx();
				} else if (TypeAdminCategory.PRIMARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getApnProtocol() + "@@$$@@"
					+ adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.SECONDARY_DNS_SERVER_ADDRESS.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getDataCenter()
					+ "@@$$@@" + adminConfigParamBO.getApnProtocol() + "@@$$@@"
					+ adminConfigParamBO.getSourceIPAddress();
				} else if (TypeAdminCategory.IKE_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.DC_COUNT_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getFirstNet();
				} else if (TypeAdminCategory.IPSECESP_LIST.toString().equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@" + adminConfigParamBO.getCcsmxRouter();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_FIREWALL.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol();
				} else if (TypeAdminCategory.ENTERPRISE_TARGET_IP_RANGES_ROUTE.toString()
						.equals(categoryId.toString())) {
					tempCategoryValue = adminConfigBO.getCategoryValue() + "@@$$@@"
							+ adminConfigParamBO.getApnProtocol();
				}
				tempCategoryValue = tempCategoryValue.replaceAll("[^a-zA-Z0-9@@$$@@.:-]", "");
				Optional<AdminConfig> configOptional = adminConfigInfoRepository.findById(adminConfigBO.getConfigId());
				if (configOptional.isPresent()) {
					AdminConfig adminConfig = configOptional.get();
					adminConfig.setCategoryValue(tempCategoryValue);
					adminConfig.setDescription(adminConfigBO.getDescription());
					adminConfig.setDefaultValue(adminConfigBO.getDefaultValue());
					adminConfigInfoRepository.save(adminConfig);
					isEdited = true;
				}
			} else {
				Optional<AdminConfig> configOptional = adminConfigInfoRepository.findById(adminConfigBO.getConfigId());
				if (configOptional.isPresent()) {
					AdminConfig adminConfig = configOptional.get();
					adminConfig.setCategoryValue(adminConfigBO.getCategoryValue());
					adminConfig.setDescription(adminConfigBO.getDescription());
					adminConfig.setDefaultValue(adminConfigBO.getDefaultValue());
					adminConfigInfoRepository.save(adminConfig);
					isEdited = true;
				}
			}
		}
		logger.info("Existing method updateConfigInfo :", this);
		return isEdited;
	}

	@Override
	public boolean deleteConfigInfo(Long configId) throws CometDataException {
		boolean isDeleted = false;
		if (null != configId) {
			Optional<AdminConfig> configOptional = adminConfigInfoRepository.findById(configId);
			if (configOptional.isPresent()) {
				adminConfigInfoRepository.deleteById(configId);
				isDeleted = true;
			}
		}
		return isDeleted;
	}

	@Override
	public List<OrderStatusBO> getOrderStatusList() throws CometDataException {
		logger.info("Starting method getOrderStatusList :", this);
		List<OrderStatusBO> orderStatusBOList = new ArrayList<>();
		List<OrderStatus> orderStatusList = orderStatusRepository.findAll(Sort.by(Direction.ASC, "orderStatusName"));
		if (null != orderStatusList) {
			for (OrderStatus orderStatus : orderStatusList) {
				OrderStatusBO statusBO = new OrderStatusBO();
				statusBO.setOrderstatusId(orderStatus.getOrderStatusId());
				statusBO.setOrderStatusName(orderStatus.getOrderStatusName());
				statusBO.setOrderStatusDescription(orderStatus.getOrderStatusDescription());
				orderStatusBOList.add(statusBO);
			}
		}
		logger.info("Existing method getOrderStatusList :", this);
		return orderStatusBOList;
	}

	@Override
	public boolean updateOrderStatus(OrderStatusBO orderStatusBO) throws CometDataException {
		logger.info("Starting method updateOrderStatus :", this);
		boolean isEdited = false;
		if (null != orderStatusBO && null != orderStatusBO.getOrderstatusId()) {
			Optional<OrderStatus> statusOptional = orderStatusRepository.findById(orderStatusBO.getOrderstatusId());
			if (statusOptional.isPresent()) {
				OrderStatus orderStatus = statusOptional.get();
				orderStatus.setOrderStatusName(orderStatusBO.getOrderStatusName());
				orderStatus.setOrderStatusDescription(orderStatusBO.getOrderStatusDescription());
				orderStatusRepository.save(orderStatus);
				isEdited = true;
			}
		}
		logger.info("Existing method updateOrderStatus :", this);
		return isEdited;
	}

	@Override
	public List<StateBO> getState() {
		logger.info("Starting method getState : ");
		List<State> stateNameList = stateRepository.findAll(Sort.by(Sort.Direction.ASC, "stateName"));
		List<StateBO> stateList = new ArrayList<StateBO>();
		StateBO stateTypeBO = null;
		for (State state : stateNameList) {
			if (state != null) {
				stateTypeBO = new StateBO();
				stateTypeBO.setStateId(state.getStateId());
				stateTypeBO.setStateName(state.getStateName());
				stateTypeBO.setActive(state.getActive());
				stateTypeBO.setCountryName(state.getCountry().getCountryName());
				stateList.add(stateTypeBO);
			}
		}
		logger.info("Exiting method getState : ");
		return stateList;
	}

	@Override
	public String updateDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		logger.info("Starting method updateDataCenter", this);
		boolean updateFlag = true;
		String msg = null;
		if (dataCenterBO !=null) {
			updateFlag = checkDataCenterValues(dataCenterBO);
			if(updateFlag) {
				msg = "Details of Data Center ["+dataCenterBO.getDataCenterName()+"] have been updated.";
			} else {
				msg = "Data Center Not Found.";
			}
		} else {
			logger.error("No Data Found", this);
			throw new CometDataException("No Data Found to update Data Center ");
		}
		logger.info("End of method updateDataCenter", this);
		return msg;
	}

	private boolean checkDataCenterValues(DataCenterBO dataCenterBO) throws CometDataException {
		logger.info("Starting method checkDataCenterValues", this);
		boolean updateFlag = false;
		DataCenter dc = null;
		java.util.Optional<DataCenter> optDC = dataCenterNameRepository.findById(dataCenterBO.getDataCenterId());
		if (optDC.isPresent()) {
			dc = optDC.get();
			dc = manageDataCenterHelper.populateDataCenter(dataCenterBO, dc);
			dataCenterNameRepository.save(dc);
			updateFlag = true;
		}else {
			return updateFlag;
		}
		logger.info("End of method checkDataCenterValues", this);
		return updateFlag;
	}

	@Override
	public String deleteStateName(Long stateId) throws CometDataException, CometServiceException {
		logger.info("Starting method deleteStateName", this);
		StringBuilder query = manageInventoryHelper.checkUseOfTheStateInComet(stateId);
		int sqlStateCount = ((BigDecimal) entityManager.createNativeQuery(query.toString()).getSingleResult()).intValue();
		String stateDeletedSuccess = null;
		if (sqlStateCount == 0) {
			List<City> lstCity = cityRepository.findByState_StateId(stateId);
			if (lstCity != null && !lstCity.isEmpty()) {
				for (City city : lstCity) {
					cityRepository.deleteById(city.getCityId());
				}
			}
			Optional<State> state = stateRepository.findById(stateId);
			if(state.isPresent()) {
				stateRepository.deleteById(stateId);
				stateDeletedSuccess = ErrorConstants.DELETE_STATE_MSG+stateId;
			}
		}else {
			stateDeletedSuccess = ErrorConstants.DONTDELETE_INUSED_MSG;
		}
		logger.info("Exiting method deleteStateName", this);
		return stateDeletedSuccess;
	}

	@Override
	public String deleteCityName(Long cityId) throws CometDataException, CometServiceException {
		logger.info("Starting method deleteCityName", this);
		StringBuilder query = manageInventoryHelper.checkUseOfTheCityInComet(cityId);
		int sqlCityCount = ((BigDecimal) entityManager.createNativeQuery(query.toString()).getSingleResult()).intValue();
		String cityDeletedSuccess = null;
		if (sqlCityCount == 0) {
			Optional<City> city = cityRepository.findById(cityId);
			if(city.isPresent()) {
				cityRepository.deleteById(cityId);
				cityDeletedSuccess = ErrorConstants.DELETE_CITY_MSG+cityId;
			}
		}else {
			cityDeletedSuccess = ErrorConstants.DONTDELETE_INUSED_MSG;
		}
		logger.info("Exiting method deleteCityName", this);
		return cityDeletedSuccess;
	}

	@Override
	public void insertDapnRecords(List<LineBO> dapnBO, String attuId, long status) throws CometDataException, ParseException {
		String batchId =manageInventoryHelper.createBatchId(attuId);
		for(int i = 0 ; i < dapnBO.size(); i++){
			DapnInventory dapnInventory = manageInventoryHelper.convertBOToEntityforInsert((DapnCSVLineBO)dapnBO.get(i),attuId,status,batchId);
			dapnInventoryRepository.save(dapnInventory);
			if( i % 500 == 0 ) {
				dapnInventoryRepository.flush();
			}
		}
	}

	@Override
	public String validateDapnRecords() throws CometDataException, SQLException {
		Object batchId =null;
		Query query = entityManager.createNativeQuery(CometCommonConstant.VALIDATE_DAPN_RECORDS);
		query.setParameter(1, OracleTypes.VARCHAR);
		batchId = (Object) query.getParameterValue(1);
		return batchId.toString();
	}

	@Override
	public List<DapnUploadStatus> getDapnUploadResultMessage(String batchId) {
		List<DapnUploadStatus>  dapnList = new ArrayList<DapnUploadStatus>();
		dapnList = dapnUploadStatusRepository.findByBatchId(batchId);
		if(!CollectionUtils.isEmpty(dapnList)) {
			return dapnList;
		}
		return null;
	}

	@Override
	public List<CityBO> getCity(Long countryId, Long stateId) throws CometDataException, CometServiceException {
		logger.info("Starting method getCity", this);
		List<CityBO> cityBOList = new ArrayList<CityBO>();
		CityBO cityBO= null;
		if(null!=stateId && null!=countryId){
			List<State> stateList = stateRepository.findByCountry_CountryId(countryId);
			if (stateList != null && !stateList.isEmpty()) {
				for (State state : stateList) {
					List<City> cityList = cityRepository.findByState_StateId(state.getStateId());
					if (cityList != null && !cityList.isEmpty() && state.getStateId().equals(stateId)) {
						for (City city : cityList) {
							if(null!= city) {
								cityBO = new CityBO();
								cityBO.setCityId(city.getCityId());
								cityBO.setCityName(city.getCityName());
								cityBO.setStateId(city.getState().getStateId());
								cityBO.setStateName(city.getState().getStateName());
								cityBO.setActive(city.getActive());
								cityBO.setCountryId(city.getState().getCountry().getCountryId());
								cityBO.setCountryName(city.getState().getCountry().getCountryName());
								cityBOList.add(cityBO);
								Collections.sort(cityBOList);
							}
						}
					}
				}
			}
		}else {
			logger.error("[CountryId : " + countryId + "] "+"[StateId : " + stateId + "] " + "StateId and CountryId values are mandatory", this);
			throw new CometDataException("StateId and CountryId values are mandatory");
		}
		logger.info("Exiting method getCity", this);
		return cityBOList;
	}

	@Override
	public String saveAndUpdateStateName(StateBO stateBO) throws CometDataException, CometServiceException {
		logger.info("Starting method saveAndUpdateStateName : ");
		State state = null;
		String msg = null;
		if ((stateBO.getStateName() != null || stateBO.getStateName() != "") && stateBO.getActive() != null) {
			if(stateBO.getStateId() == null) {
				Optional<State> stateInfo = stateRepository.findByStateName(stateBO.getStateName());
				if (!stateInfo.isPresent()) {
					state = new State();
					state.setActive(stateBO.getActive());
					Optional<Country> country = countryRepository.findById(stateBO.getCountryId());
					if(country.isPresent()){
						state.setCountry(country.get());
					}
					state.setStateName(stateBO.getStateName());
					stateRepository.save(state);
					msg = "State added successfully.";
				}else {
					msg = ErrorConstants.DONTDELETE_INUSED_MSG;
				}
			} else {
				Optional<State> updateStateInfo = stateRepository.findById(stateBO.getStateId());
				if(updateStateInfo.isPresent()) {
					state = updateStateInfo.get();
					state.setActive(stateBO.getActive());
					state.setStateName(stateBO.getStateName());
					stateRepository.save(state);
					List<City> lstCity = cityRepository.findByState_StateId(state.getStateId());
					if (lstCity != null && !lstCity.isEmpty()) {
						for (City city : lstCity) {
							city.setActive(state.getActive());
							cityRepository.save(city);
						}
					}
					msg = "State updated successfully."; 
				}
			}
		} else {
			logger.error("[StateName : " + stateBO.getStateName() + "] " + "StateName having null value",
					this);
			throw new CometDataException("State Name having null value");
		}
		logger.info("Exiting method saveAndUpdateStateName : ");
		return msg;
	}

	@Override
	public String saveAndUpdateCityName(CityBO cityBO) throws CometDataException, CometServiceException {
		logger.info("Starting method saveAndUpdateCityName : ");
		City city = null;
		String msg = null;
		if ((cityBO.getCityName() != null || cityBO.getCityName() != "") && cityBO.getActive() != null) {
			if(cityBO.getCityId() == null) {
				Optional<City> cityInfo = cityRepository.findByCityName(cityBO.getCityName());
				if (!cityInfo.isPresent()) {
					city = new City();
					city.setActive(cityBO.getActive());
					city.setCityName(cityBO.getCityName());
					Optional<State> stateInfo = stateRepository.findById(cityBO.getStateId());
					if(stateInfo.isPresent()) {
						city.setState(stateInfo.get());
					}
					cityRepository.save(city);
					msg = "City added successfully.";
				}else {
					msg = ErrorConstants.DONTDELETE_INUSED_MSG;
				}
			} else {
				Optional<City> updateCityInfo = cityRepository.findById(cityBO.getCityId());
				if(updateCityInfo.isPresent()) {
					city = updateCityInfo.get();
					city.setActive(cityBO.getActive());
					city.setCityName(cityBO.getCityName());
					cityRepository.save(city);
					msg = "City updated successfully."; 
				}
			}
		} else {
			logger.error("[CityName : " + cityBO.getCityName() + "] " + "CityName having null value",
					this);
			throw new CometDataException("CityName having null value");
		}
		logger.info("Exiting method saveAndUpdateCityName : ");
		return msg;
	}

	@Override
	public DataCenterBO getDataCenterInfo(Long dcId){
		logger.info("Starting method getDataCenterInfo : ", dcId);
		DataCenter dc = dataCenterNameRepository.findByDataCenterId(dcId);
		DataCenterBO dcBO = new DataCenterBO();
		dcBO.setDataCenterId(dc.getDataCenterId());
		dcBO.setDataCenterName(dc.getDataCenterName());
		dcBO.setDummy(dc.getDummy().toString());
		dcBO.setFirstNet(dc.getFirstNet());
		dcBO.setZoneName(dc.getZoneName());
		logger.info("End method getDataCenterInfo : ", dcId);
		return dcBO;
	}	
	
	@Override
	public StateBO getStateById(long stateId) throws CometDataException, CometServiceException {
		StateBO stateBO = null;
		 Optional<State> opState = stateRepository.findById(stateId);
		if(opState.isPresent()) {
			State state = opState.get();
			stateBO = new StateBO();
			stateBO.setStateId(state.getStateId());
			stateBO.setStateName(state.getStateName());
		}
		return stateBO;
	}
	
	@Override
	public CityBO getCityById(long cityId) throws CometDataException, CometServiceException {
		CityBO cityBO=null;
		Optional<City> opCity = cityRepository.findById(cityId);
		if(opCity.isPresent()) {
			City city = opCity.get();
			cityBO = new CityBO();
			cityBO.setCityId(city.getCityId());
			cityBO.setCityName(city.getCityName());
			cityBO.setStateId(city.getState().getStateId());
			cityBO.setStateName(city.getState().getStateName());
			cityBO.setActive(city.getActive());
			cityBO.setCountryId(city.getState().getCountry().getCountryId());
			cityBO.setCountryName(city.getState().getCountry().getCountryName());
		}
		return cityBO;
	}
}