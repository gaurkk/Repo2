package com.att.comet.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.OrderCapacityForecast;
import com.att.comet.dao.hibernate.bean.OrderCapacityForecastId;

@Repository
public interface OrderCapacityForecastRepository extends JpaRepository<OrderCapacityForecast, OrderCapacityForecastId> {

}
