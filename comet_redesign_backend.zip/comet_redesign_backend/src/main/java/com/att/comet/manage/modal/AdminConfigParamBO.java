package com.att.comet.manage.modal;

import lombok.Data;

@Data
public class AdminConfigParamBO {

	private Long categoryId;

	private Boolean isSpecialCategory = false;

	private String dataCenter;

	private String ccsmx;

	private String apnProtocol;

	private String sourceIPAddress;

	private String ccsmxRouter;

	private String firstNet;

	public AdminConfigParamBO() {
		super();
	}

	public AdminConfigParamBO(Long categoryId, Boolean isSpecialCategory, String dataCenter, String ccsmx,
			String apnProtocol, String sourceIPAddress, String ccsmxRouter, String firstNet) {
		super();
		this.categoryId = categoryId;
		this.isSpecialCategory = isSpecialCategory;
		this.dataCenter = dataCenter;
		this.ccsmx = ccsmx;
		this.apnProtocol = apnProtocol;
		this.sourceIPAddress = sourceIPAddress;
		this.ccsmxRouter = ccsmxRouter;
		this.firstNet = firstNet;
	}

}
