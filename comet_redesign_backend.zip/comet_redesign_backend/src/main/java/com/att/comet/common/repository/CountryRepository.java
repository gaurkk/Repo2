package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {
	Country findByCountryName(String countryName);
	Country findByCountryNameIgnoreCase(String countryName);
}
