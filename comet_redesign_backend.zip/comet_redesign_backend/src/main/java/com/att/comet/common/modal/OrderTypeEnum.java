package com.att.comet.common.modal;

import org.apache.commons.lang3.StringUtils;

public enum OrderTypeEnum {
	DECOMMISSION(1006, "Decommission"),
	CHANGE_ORDER(1004, "Change Order"),
	NEW(1001, "New"),
	CANCEL_ORDER(1002, "Cancel Order"),
	EXPEDITE(1003, "Expedite"),
	CHANGE_REQUEST(1005, "Change Request"); 

	public int getOrderTypeId() {
		return orderTypeId;
	}

	public String getOrderTypeName() {
		return orderTypeName;
	}

	private final int orderTypeId;
	private final String orderTypeName;

	public static OrderTypeEnum getEnum(String value) {
		OrderTypeEnum getStat = null;
		if (StringUtils.isNotBlank(value)) {
			for (OrderTypeEnum stat : OrderTypeEnum.values()) {
				if (stat.name().equalsIgnoreCase(value)) {
					getStat = stat;
					break;
				}
			}
		}
		return getStat;
	}

	private OrderTypeEnum(int orderTypeId, String orderTypeName) {
		this.orderTypeId = orderTypeId;
		this.orderTypeName = orderTypeName;
	}
}
