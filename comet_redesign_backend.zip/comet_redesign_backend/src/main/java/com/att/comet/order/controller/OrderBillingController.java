package com.att.comet.order.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.account.controller.AccountController;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.order.modal.BillingBO;
import com.att.comet.order.modal.BillingDetailsBO;
import com.att.comet.order.service.OrderServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderBillingController {

	Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	OrderServiceImpl orderServiceImpl;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/order/billing/{orderId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get Billing Data using OrderId", notes = "Fetching Billing Tab Info Details")
	public CometResponse<BillingBO> getBillingDataInfo(@PathVariable Long orderId) throws CometDataException { 
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getBillingDataInfo : ", this);
		CometResponse<BillingBO> cometResponse = new CometResponse<BillingBO>();
		BillingBO billingDataInfo = null;

		try {
			billingDataInfo = orderServiceImpl.getBillingDetailsInfo(orderId);
			cometResponse.setMethodReturnValue(billingDataInfo);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getBillingDataInfo : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN", "ROLE_CCS_PM"})
	@PutMapping(value = "/order/billing/{orderId}", produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1") 
	@ApiOperation(value = "Storing billing data info", notes = "Storing or updating billing data info") 
	public CometResponse<BillingDetailsBO> saveOrUpdateOrderBilling(@RequestBody BillingDetailsBO billingDetailsBO, @PathVariable Long orderId, Authentication authentication) throws CometDataException { 
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+"Starting method saveOrUpdateOrderBilling : ", this); 
		CometResponse<BillingDetailsBO> cometResponse = new CometResponse<BillingDetailsBO>();
		try {
			if (billingDetailsBO != null) { 
				billingDetailsBO = orderServiceImpl.saveOrUpdateBillingInfo(billingDetailsBO, orderId, authentication);
				if(billingDetailsBO == null) {
					cometResponse.setMethodReturnValue(billingDetailsBO); 
					cometResponse.setStatusCode(Status.USER_INPUT.getCode()); 
					cometResponse.setStatus(Status.USER_INPUT);
				}else {
					cometResponse.setMethodReturnValue(billingDetailsBO); 
					cometResponse.setStatusCode(Status.SUCCESS.getCode()); 
					cometResponse.setStatus(Status.SUCCESS); 
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to save or update details");
			}
		}catch(Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+"Exiting method saveOrUpdateOrderBilling : ", this); 
		return cometResponse; 
	}
}
