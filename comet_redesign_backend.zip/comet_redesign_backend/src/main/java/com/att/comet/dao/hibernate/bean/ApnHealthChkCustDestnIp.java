package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "APN_HEALTH_CHK_CUST_DESTN")
public class ApnHealthChkCustDestnIp  implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Apn apn;
	
	private Long healthChkCustId;
	private String  healthChkCustIpLbl;
	private String  healthChkCustIpVal;
	private DataCenter dataCenter;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false)
	public DataCenter getDataCenter() {
		return dataCenter;
	}
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}
	@Id
	@Column(name = "HEALTH_CHK_CUST_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_HEALTH_CHK_CUST_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_HEALTH_CHK_CUST_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HEALTH_CHK_CUST_ID")
	public Long getHealthChkCustId() {
		return healthChkCustId;
	}
	public void setHealthChkCustId(Long healthChkCustId) {
		this.healthChkCustId = healthChkCustId;
	}
	
	@Column(name = "HEALTH_CHK_CUST_IP_LBL", length = 100)
	public String getHealthChkCustIpLbl() {
		return healthChkCustIpLbl;
	}
	public void setHealthChkCustIpLbl(String healthChkCustIpLbl) {
		this.healthChkCustIpLbl = healthChkCustIpLbl;
	}
	@Column(name = "HEALTH_CHK_CUST_IP_VAL", length = 100)
	public String getHealthChkCustIpVal() {
		return healthChkCustIpVal;
	}
	public void setHealthChkCustIpVal(String healthChkCustIpVal) {
		this.healthChkCustIpVal = healthChkCustIpVal;
	}
	/**
	 * @return the apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return apn;
	}
	/**
	 * @param apn the apn to set
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}
}
