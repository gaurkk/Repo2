package com.att.comet.eiis.modal;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import springfox.documentation.spring.web.json.Json;

@Data
public class AmpResponseBO implements java.io.Serializable{

	private static final long serialVersionUID = -6424150157956747451L;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String rid;
	
	private String HTTP_CODE;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String requestStatus;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private boolean isRedayForSync;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private boolean cancelledAmp;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String token;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorCode;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String message;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Json jsonResponse;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dataCenterName;
	
	private String exception;
	
}
