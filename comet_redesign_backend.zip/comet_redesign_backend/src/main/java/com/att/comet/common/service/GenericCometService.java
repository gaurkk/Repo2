package com.att.comet.common.service;

/**
 * Marker interface for comet service classes.
 * 
 */
public interface GenericCometService {

}
