package com.att.comet.manage.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.AdminCategoryBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CityBO;
import com.att.comet.common.modal.CountryBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.StateBO;
import com.att.comet.manage.modal.AdminConfigParamBO;
import com.att.comet.manage.modal.DapnUploadStatusBO;
import com.att.comet.manage.modal.InventoryBO;
import com.att.comet.manage.modal.InventoryTemplateBO;
import com.att.comet.manage.modal.LineBO;
import com.att.comet.manage.modal.ManageInvetoryDownloadBO;
import com.att.comet.manage.modal.MasterAdminCategoryBO;
import com.att.comet.manage.modal.ParseResultBO;

public interface ManageService {

	public ManageInvetoryDownloadBO downloadManageInventoryTemplate(String inventory)
			throws CometDataException, IOException;

	List<InventoryTemplateBO> getInventoryNameList() throws CometDataException;

	public ParseResultBO uploadManageInventory(MultipartFile file, String isActivated,String userId)
			throws CometDataException, IOException;

	public ParseResultBO saveInOutPatFile(ParseResultBO uploadFileBO) throws CometDataException, CometServiceException;

	public ParseResultBO saveImsiMsisdnFile(ParseResultBO uploadFileBO)
			throws CometDataException, CometServiceException;

	public ParseResultBO saveRDRTFile(ParseResultBO uploadFileBO) throws CometDataException, CometServiceException;

	public ParseResultBO saveINOUTInterfaceFile(ParseResultBO resultBO)
			throws CometDataException, CometServiceException;

	public String insertDapnRecords(List<LineBO> dapnBO,String status, long attuId,ParseResultBO resultBO) throws CometDataException; 

	public List<DapnUploadStatusBO> getDapnUploadResultMessage(String batchId);

	List<InventoryBO> getInventoryInfo(Long dataCenterId, String templateName) throws CometDataException;

	/**
	 * Get Country Name List
	 * 
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<CountryBO> getCountryList() throws CometServiceException, CometDataException;

	/**
	 * Get State Name List
	 * 
	 * @param countryId
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<StateBO> getStateList(Long countryId) throws CometServiceException, CometDataException;

	/**
	 * Get City Name List
	 * 
	 * @param stateId, criteria
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<CityBO> getCityList(Long stateId, String criteria) throws CometServiceException, CometDataException;

	/**
	 * Add Country Name List
	 * 
	 * @param countryBO
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public String saveCountryName(CountryBO countryBO) throws CometServiceException, CometDataException;

	public String saveDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;

	List<MasterAdminCategoryBO> getCategoryInfo() throws CometDataException;

	AdminCategoryBO getConfigInfo(AdminConfigParamBO adminConfigParamBO) throws CometDataException;

	public String delDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;

	/**
	 * Update Country Name
	 * 
	 * @param countryBO
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public String updateCountry(CountryBO countryBO) throws CometServiceException, CometDataException;

	/**
	 * Delete Country Name
	 * 
	 * @param countryId
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public String deleteCountryName(Long countryId) throws CometServiceException, CometDataException;

	String addConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException;

	String updateConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException;

	String deleteConfigInfo(Long configId) throws CometDataException;

	List<OrderStatusBO> getOrderStatusList() throws CometDataException;

	String updateOrderStatus(OrderStatusBO orderStatusBO) throws CometDataException;

	public List<StateBO> getState() throws CometServiceException, CometDataException;

	public String updateDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;

	/**
	 * Delete State Name
	 * @param stateId
	 * @throws CometServiceException 
	 * @throws CometDataException
	 */
	public String deleteStateName(Long stateId)throws CometServiceException, CometDataException;

	/**
	 * Delete City Name
	 * @param cityId
	 * @throws CometServiceException 
	 * @throws CometDataException
	 */
	public String deleteCityName(Long cityId)throws CometServiceException, CometDataException;

	/**
	 * Get City Name
	 * @param countryID, stateId
	 * @throws CometServiceException 
	 * @throws CometDataException
	 */
	public List<CityBO> getCity(Long countryId, Long stateId)throws CometServiceException, CometDataException;
	
	public String saveStateName(StateBO stateBO) throws CometServiceException, CometDataException;
	
	public String updateState(StateBO stateBO) throws CometServiceException, CometDataException;
	
    public String saveCityName(CityBO cityBO) throws CometServiceException, CometDataException;
	
	public String updateCity(CityBO cityBO) throws CometServiceException, CometDataException;
	
	public DataCenterBO getDataCenterInfo(Long dcId) throws CometServiceException, CometDataException;
	
	public StateBO getStateInfoById(long stateId)  throws CometServiceException, CometDataException;
	
	public CityBO getCityInfoById(long cityId)  throws CometServiceException, CometDataException;
}
