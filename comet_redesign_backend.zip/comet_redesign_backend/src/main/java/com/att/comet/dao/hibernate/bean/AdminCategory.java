package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for AdminCategory. Mapped with the ADMIN_CATEGORY table in
 * database.
 */
@Entity
@Table(name = "ADMIN_CATEGORY")
public class AdminCategory implements Serializable {

	private static final long serialVersionUID = 8892772974361222132L;

	private Long adminCategoryId;
	private String adminCategoryName;
	private String adminCategoryValueType;
	private String tableMapping;
	
	private Set<AdminConfig> adminConfigs = new HashSet<AdminConfig>(0);

	/**
	 * Getter method of AdminCategoryId ADMIN_CATEGORY_ID mapped to
	 * ADMIN_CATEGORY_ID in database.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ADMIN_CATEGORY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getAdminCategoryId() {
		return this.adminCategoryId;
	}

	/**
	 * @param adminCategoryId to adminCategoryId set.
	 */
	public void setAdminCategoryId(Long adminCategoryId) {
		this.adminCategoryId = adminCategoryId;
	}

	/**
	 * Getter method of AdminCategoryValueType ADMIN_CATEGORY_TYPE mapped to
	 * ADMIN_CATEGORY_TYPE in database.
	 * 
	 * @return String
	 */
	@Column(name = "ADMIN_CATEGORY_TYPE", length = 100)
	public String getAdminCategoryValueType() {
		return adminCategoryValueType;
	}

	/**
	 * @param adminCategoryValueType to adminCategoryValueType set.
	 */
	public void setAdminCategoryValueType(String adminCategoryValueType) {
		this.adminCategoryValueType = adminCategoryValueType;
	}

	/**
	 * Getter method for AdminCategoryName ADMIN_CATEGORY_NAME mapped to
	 * ADMIN_CATEGORY_NAME in database.
	 * 
	 * @return String
	 */
	@Column(name = "ADMIN_CATEGORY_NAME", nullable = false, length = 100)
	public String getAdminCategoryName() {
		return this.adminCategoryName;
	}

	/**
	 * @param adminCategoryName to adminCategoryName set.
	 */
	public void setAdminCategoryName(String adminCategoryName) {
		this.adminCategoryName = adminCategoryName;
	}

	/**
	 * @return Set<AdminConfig>
	 */
	
	  @OneToMany(fetch = FetchType.LAZY, mappedBy = "adminCategory") public
	  Set<AdminConfig> getAdminConfigs() { return this.adminConfigs; }
	  
	 /**
		 * @param adminConfigs to adminConfigs set.
		 */
			  public void setAdminConfigs(Set<AdminConfig> adminConfigs) {
			  this.adminConfigs = adminConfigs; }

	/**
	 * @return the tableMapping
	 */
	@Column(name = "TABLE_MAPPING", nullable = true, length = 1000)
	public String getTableMapping() {
		return tableMapping;
	}

	/**
	 * @param tableMapping the tableMapping to set
	 */
	public void setTableMapping(String tableMapping) {
		this.tableMapping = tableMapping;
	}
}
