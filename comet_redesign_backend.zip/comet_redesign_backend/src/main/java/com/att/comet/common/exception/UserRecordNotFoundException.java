package com.att.comet.common.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * USER define exception which extend Runtime exception  
 * @author pd6080
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class UserRecordNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	
	public UserRecordNotFoundException(String message) {
		super(message);
	}
}
