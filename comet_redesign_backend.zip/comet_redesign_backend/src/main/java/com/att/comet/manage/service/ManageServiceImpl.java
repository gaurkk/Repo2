package com.att.comet.manage.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.exception.DapnValidationException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.AdminCategoryBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CityBO;
import com.att.comet.common.modal.CountryBO;
import com.att.comet.common.modal.DapnInventoryBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.StateBO;
import com.att.comet.common.service.MessageConfigService;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.DapnInventory;
import com.att.comet.dao.hibernate.bean.DapnUploadStatus;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnInventory;
import com.att.comet.dao.hibernate.bean.InsideOutsideBaseInterface;
import com.att.comet.dao.hibernate.bean.InsideOutsideStgPatInterface;
import com.att.comet.manage.constant.ManageInventoryConstant;
import com.att.comet.manage.dao.ManageDAO;
import com.att.comet.manage.helper.ManageInventoryHelper;
import com.att.comet.manage.modal.AdminConfigParamBO;
import com.att.comet.manage.modal.DapnUploadStatusBO;
import com.att.comet.manage.modal.ImsiMsisdnCSVLineBO;
import com.att.comet.manage.modal.InOutInterfaceCSVLineBO;
import com.att.comet.manage.modal.InOutStgPatBO;
import com.att.comet.manage.modal.InventoryBO;
import com.att.comet.manage.modal.InventoryTemplateBO;
import com.att.comet.manage.modal.LineBO;
import com.att.comet.manage.modal.ManageInvetoryDownloadBO;
import com.att.comet.manage.modal.MasterAdminCategoryBO;
import com.att.comet.manage.modal.ParseResultBO;
import com.att.comet.manage.util.CSVUtils;
import com.att.comet.order.modal.ImsiMsisdnBO;
import com.att.comet.order.modal.InsideOutsideBaseInterfaceBO;

@Service
public class ManageServiceImpl implements ManageService {

	private static final Logger logger = LoggerFactory.getLogger(ManageServiceImpl.class);

	private static final String DAPN_FILE_HEADER_DOWNLOAD = "COMET-DAPN-INV-IMP-TEMP-VER1.0";
	private static final String PAT_FILE_HEADER_DOWNLOAD = "COMET-PAT-CHNL-IMP-TEMP-VER1.0";
	private static final String INOUT_INTERFACE_FILE_HEADER_DOWNLOAD = "COMET-INSIDE-OUTSIDE-INV-VER1.0";
	private static final String IMSI_MSISDN_FILE_HEADER_DOWNLOAD = "COMET-IMSI-MSISDN-INV-VER1.0";
	private static final String IMSI_MSISDN_TEMPLATE = "IMSI_MSISDN_Inventory.csv";
	private static final String IN_OUT_TEMPLATE = "INOUT_INTERFACE_Inventory.csv";
	private static final String INSIDE_OUTSIDE_PAT_TEMPLATE = "INSIDE_OUTSIDE_PAT_Inventory.csv";
	private static final String DAPN_TEMPLATE = "DAPN_Inventory.csv";
	private static final String EOR = "EOR";

	@Autowired
	ManageDAO manageDAO;
	@Autowired
	ManageInventoryHelper manageInventoryHelper;
	
	@Autowired
	MessageConfigService messageConfig;

	@Override
	public List<InventoryBO> getInventoryInfo(Long dataCenterId, String templateName) throws CometDataException {
		logger.info("Starting method getInventoryInfo : ", this);
		List<InventoryBO> inventoryBOList = null;
		List<InsideOutsideStgPatInterface> insideOutsideStgPatInterfaceList = null;
		List<ImsiMsisdnInventory> imsiMsisdnInventoryList = null;
		List<InsideOutsideBaseInterface> insideOutsideBaseInterfaceList = null;
		List<DapnInventory> dapnInventoryList = null;
		try {
			if (dataCenterId != null && templateName != null) {
				if (templateName.equalsIgnoreCase("INSIDE_OUTSIDE_PAT")) {
					try {
						insideOutsideStgPatInterfaceList = manageDAO.getInsideOutsidePAT(dataCenterId);
					} catch (Exception exception) {
						logger.error("Exception in getting Inside Outside PAT");
						throw new CometDataException("Error", exception);
					}
					InOutStgPatBO inOutStgPatBO = null;
					inventoryBOList = new ArrayList<InventoryBO>();
					if (insideOutsideStgPatInterfaceList != null) {
						for (InsideOutsideStgPatInterface insideOutsideStgPatInterface : insideOutsideStgPatInterfaceList) {
							inOutStgPatBO = new InOutStgPatBO();
							if (CommonUtils.isNotNullEmpty(
									insideOutsideStgPatInterface.getInsideOutsideDataCenterId().getInsideOutside())) {
								String temp[] = insideOutsideStgPatInterface.getInsideOutsideDataCenterId()
										.getInsideOutside().split("-");
								inOutStgPatBO.setInsidePat(temp[0]);
								inOutStgPatBO.setOutsidePat(temp[1]);
							}
							if (CommonUtils.isNotNullEmpty(insideOutsideStgPatInterface.getOrderId())) {
								inOutStgPatBO.setInventoryStatus("Assigned");
							} else {
								inOutStgPatBO.setInventoryStatus("Available");
							}
							inOutStgPatBO.setDataCenterId(dataCenterId);
							inOutStgPatBO.setDataCenterName(
									insideOutsideStgPatInterface.getDataCenter().getDataCenterName());
							inventoryBOList.add(inOutStgPatBO);
						}
					}
				} else if (templateName.equalsIgnoreCase("IMSI_MSISDN")) {
					try {
						imsiMsisdnInventoryList = manageDAO.getImsiMsisdn(dataCenterId);
					} catch (Exception exception) {
						logger.error("Exception in getting ImsiMsisDN");
						throw new CometDataException("Error", exception);
					}
					ImsiMsisdnBO imsiMsisdnBO = null;
					inventoryBOList = new ArrayList<InventoryBO>();
					if (imsiMsisdnInventoryList != null) {
						for (ImsiMsisdnInventory imsiMsisdnInventory : imsiMsisdnInventoryList) {
							imsiMsisdnBO = new ImsiMsisdnBO();
							imsiMsisdnBO.setImsiMsisdn(imsiMsisdnInventory.getImsiMsisdnDataCenterId().getImsiMsisdn());
							if (CommonUtils.isNotNullEmpty(imsiMsisdnInventory.getOrderId())) {
								imsiMsisdnBO.setInventoryStatus("Assigned");
							} else {
								imsiMsisdnBO.setInventoryStatus("Available");
							}
							imsiMsisdnBO.setDataCenterName(imsiMsisdnInventory.getDataCenter().getDataCenterName());
							inventoryBOList.add(imsiMsisdnBO);
						}
					}
				} else if (templateName.equalsIgnoreCase("INOUT_INTERFACE")) {
					try {
						insideOutsideBaseInterfaceList = manageDAO.getInOutBaseInterface(dataCenterId);
					} catch (Exception exception) {
						logger.error("Exception in getting InOutBaseInterface");
						throw new CometDataException("Error", exception);
					}
					InsideOutsideBaseInterfaceBO insideOutsideBaseInterfaceBO = null;
					inventoryBOList = new ArrayList<InventoryBO>();
					if (insideOutsideBaseInterfaceList != null) {
						for (InsideOutsideBaseInterface insideOutsideBaseInterface : insideOutsideBaseInterfaceList) {
							insideOutsideBaseInterfaceBO = new InsideOutsideBaseInterfaceBO();
							if (CommonUtils.isNotNullEmpty(
									insideOutsideBaseInterface.getInsideOutsideDataCenterId().getInsideOutside())) {
								String temp[] = insideOutsideBaseInterface.getInsideOutsideDataCenterId()
										.getInsideOutside().split("-");
								insideOutsideBaseInterfaceBO.setInsideBase(temp[0]);
								insideOutsideBaseInterfaceBO.setOutsideBase(temp[1]);
							}
							if (CommonUtils.isNotNullEmpty(insideOutsideBaseInterface.getOrderId())) {
								insideOutsideBaseInterfaceBO.setInventoryStatus("Assigned");
							} else {
								insideOutsideBaseInterfaceBO.setInventoryStatus("Available");
							}
							insideOutsideBaseInterfaceBO
							.setDataCenterName(insideOutsideBaseInterface.getDataCenter().getDataCenterName());
							insideOutsideBaseInterfaceBO.setGwSgiContext(insideOutsideBaseInterface.getGwSgiContext());
							insideOutsideBaseInterfaceBO.setRdRt(insideOutsideBaseInterface.getRdRt());
							inventoryBOList.add(insideOutsideBaseInterfaceBO);
						}
					}
				} else if (templateName.equalsIgnoreCase("DAPN")) {
					try {
						dapnInventoryList = manageDAO.getDapnInventory(dataCenterId);
					} catch (Exception exception) {
						logger.error("Exception in getting dapnInventory");
						throw new CometDataException("Error", exception);
					}
					DapnInventoryBO dapnInventoryBO = null;
					inventoryBOList = new ArrayList<InventoryBO>();
					if (dapnInventoryList != null) {
						for (DapnInventory dapnInventory : dapnInventoryList) {
							dapnInventoryBO = new DapnInventoryBO();
							if (dapnInventory.getDapnStatus().getDapnStatusId() == 1001
									|| dapnInventory.getDapnStatus().getDapnStatusId() == 1002) {
								dapnInventoryBO.setInventoryStatus("Available");
							} else {
								dapnInventoryBO.setInventoryStatus("Assigned");
							}
							dapnInventoryBO.setDataCenterName(dapnInventory.getDataCenter().getDataCenterName());
							dapnInventoryBO.setDapnId(dapnInventory.getDapnId());
							dapnInventoryBO.setApnType(dapnInventory.getApnType());
							dapnInventoryBO.setApnSize(dapnInventory.getApnSize());
							dapnInventoryBO.setApnName(dapnInventory.getApnName());
							dapnInventoryBO.setPdpName(dapnInventory.getPdpName());
							dapnInventoryBO.setUdPDPId(dapnInventory.getUdPDPId());
							dapnInventoryBO.setMobileIP(dapnInventory.getMobileIP());
							dapnInventoryBO.setPDNSAddress(dapnInventory.getpDNSAddress());
							dapnInventoryBO.setSDNSAddress(dapnInventory.getsDNSAddress());
							dapnInventoryBO.setDnsNotes(dapnInventory.getDnsNotes());
							dapnInventoryBO.setAmpInfo(dapnInventory.getAmpInfo());
							dapnInventoryBO.setCreatedOn(CommonUtils.formatDate1(dapnInventory.getCreatedOn()));
							dapnInventoryBO.setCreatedBy(dapnInventory.getCreatedBy());
							dapnInventoryBO.setPcrf(dapnInventory.getPcrf());
							inventoryBOList.add(dapnInventoryBO);
						}
					}
				}
			}
		} catch (Exception exception) {
			logger.error("Exception in getting Inventory Info");
			throw new CometDataException("Error", exception);
		}
		logger.info("Exiting method getInventoryInfo : ", this);
		return inventoryBOList;
	}

	@Override
	@Transactional
	public ManageInvetoryDownloadBO downloadManageInventoryTemplate(String inventory)
			throws CometDataException, IOException {
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Starting method downloadManageInventoryTemplate.");
		if (StringUtils.isEmpty(inventory)) {
			logger.error("Inventory Template Name is null.", this);
			return null;
		}
		ByteArrayOutputStream byteArrayOutputStream = null;
		ManageInvetoryDownloadBO manageInvetoryDownloadBO = null;
		List<InventoryTemplateBO> inventoryTemplateBOList = manageDAO.downloadManageInventoryTemplate(inventory);
		try {
			if (null != inventoryTemplateBOList && inventoryTemplateBOList.size() > 0) {
				if (inventory.equalsIgnoreCase("INSIDE_OUTSIDE_PAT")) {
					byteArrayOutputStream = new ByteArrayOutputStream();
					manageInvetoryDownloadBO = new ManageInvetoryDownloadBO();
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(PAT_FILE_HEADER_DOWNLOAD));
					CSVUtils.writeLine(byteArrayOutputStream,
							Arrays.asList("" + inventoryTemplateBOList.get(0).getFieldName(),
									"" + inventoryTemplateBOList.get(1).getFieldName(),
									"" + inventoryTemplateBOList.get(2).getFieldName()));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList("\n"));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(EOR));
					manageInvetoryDownloadBO.setTemplateContentType("text/csv");
					manageInvetoryDownloadBO.setTemplateFileName(INSIDE_OUTSIDE_PAT_TEMPLATE);
					manageInvetoryDownloadBO.setTemplateAttachment(byteArrayOutputStream.toByteArray());

				} else if (inventory.equalsIgnoreCase("INOUT_INTERFACE")) {
					byteArrayOutputStream = new ByteArrayOutputStream();
					manageInvetoryDownloadBO = new ManageInvetoryDownloadBO();
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(INOUT_INTERFACE_FILE_HEADER_DOWNLOAD));
					CSVUtils.writeLine(byteArrayOutputStream,
							Arrays.asList("" + inventoryTemplateBOList.get(0).getFieldName(),
									"" + inventoryTemplateBOList.get(1).getFieldName(),
									"" + inventoryTemplateBOList.get(2).getFieldName(),
									"" + inventoryTemplateBOList.get(3).getFieldName(),
									"" + inventoryTemplateBOList.get(4).getFieldName(),
									"" + inventoryTemplateBOList.get(5).getFieldName()));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList("\n"));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(EOR));
					manageInvetoryDownloadBO.setTemplateContentType("text/csv");
					manageInvetoryDownloadBO.setTemplateFileName(IN_OUT_TEMPLATE);
					manageInvetoryDownloadBO.setTemplateAttachment(byteArrayOutputStream.toByteArray());

				} else if (inventory.equalsIgnoreCase("IMSI_MSISDN")) {
					byteArrayOutputStream = new ByteArrayOutputStream();
					manageInvetoryDownloadBO = new ManageInvetoryDownloadBO();
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(IMSI_MSISDN_FILE_HEADER_DOWNLOAD));
					CSVUtils.writeLine(byteArrayOutputStream,
							Arrays.asList("" + inventoryTemplateBOList.get(0).getFieldName(),
									"" + inventoryTemplateBOList.get(1).getFieldName(),
									"" + inventoryTemplateBOList.get(2).getFieldName(),
									"" + inventoryTemplateBOList.get(3).getFieldName()));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList("\n"));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(EOR));
					manageInvetoryDownloadBO.setTemplateContentType("text/csv");
					manageInvetoryDownloadBO.setTemplateFileName(IMSI_MSISDN_TEMPLATE);
					manageInvetoryDownloadBO.setTemplateAttachment(byteArrayOutputStream.toByteArray());

				} else if (inventory.equalsIgnoreCase("DAPN")) {
					byteArrayOutputStream = new ByteArrayOutputStream();
					manageInvetoryDownloadBO = new ManageInvetoryDownloadBO();
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(DAPN_FILE_HEADER_DOWNLOAD));
					CSVUtils.writeLine(byteArrayOutputStream,
							Arrays.asList("" + inventoryTemplateBOList.get(0).getFieldName(),
									"" + inventoryTemplateBOList.get(1).getFieldName(),
									"" + inventoryTemplateBOList.get(2).getFieldName(),
									"" + inventoryTemplateBOList.get(3).getFieldName(),
									"" + inventoryTemplateBOList.get(4).getFieldName(),
									"" + inventoryTemplateBOList.get(5).getFieldName(),
									"" + inventoryTemplateBOList.get(6).getFieldName(),
									"" + inventoryTemplateBOList.get(7).getFieldName(),
									"" + inventoryTemplateBOList.get(8).getFieldName(),
									"" + inventoryTemplateBOList.get(9).getFieldName(),
									"" + inventoryTemplateBOList.get(10).getFieldName(),
									"" + inventoryTemplateBOList.get(11).getFieldName(),
									"" + inventoryTemplateBOList.get(12).getFieldName(),
									"" + inventoryTemplateBOList.get(13).getFieldName(),
									"" + inventoryTemplateBOList.get(14).getFieldName(),
									"" + inventoryTemplateBOList.get(15).getFieldName()));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList("\n"));
					CSVUtils.writeLine(byteArrayOutputStream, Arrays.asList(EOR));
					manageInvetoryDownloadBO.setTemplateContentType("text/csv");
					manageInvetoryDownloadBO.setTemplateFileName(DAPN_TEMPLATE);
					manageInvetoryDownloadBO.setTemplateAttachment(byteArrayOutputStream.toByteArray());

				}
				byteArrayOutputStream.flush();
				byteArrayOutputStream.close();
			} else {
				logger.error("No Inventory Template Record Found.", this);
				throw new RecordNotFoundException("No Inventory Template Record Found.");
			}

		} catch (IOException e) {
			logger.error("Exception in downloadManageInventoryTemplate " + e);
		}
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Exiting method downloadManageInventoryTemplate.");
		return manageInvetoryDownloadBO;
	}

	@Override
	public List<InventoryTemplateBO> getInventoryNameList() throws CometDataException {
		return manageDAO.getInventoryNameList();
	}

	@Override
	public ParseResultBO uploadManageInventory(MultipartFile file, String isActivated,String userId)
			throws CometDataException, IOException {
		logger.info("Starting method uploadManageInventory.", this);
		ParseResultBO resultBO = null;
		resultBO =manageInventoryHelper.validateFileUpload(file,resultBO);
		if (null==resultBO.getInvalidFileMesage()) {
			if (manageInventoryHelper.isDapnFile(file)) {
				logger.info("[Inventory : " + "Calling method parseUploadDAPN.");
				resultBO=manageInventoryHelper.parseUploadDAPN(file,isActivated,userId);
			} else if (manageInventoryHelper.isPatFile(file)) {
				logger.info("[Inventory : " + "Calling method parseUploadInOutStgPat.");
				resultBO = manageInventoryHelper.parseUploadInOutStgPat(file);
			} else if (manageInventoryHelper.isInOutInterfaceFile(file)) {
				logger.info("[Inventory : " + "Calling method parseUploadInOutInterface.");
				resultBO = manageInventoryHelper.parseUploadInOutInterface(file);
			} else if (manageInventoryHelper.isMisiMsisdnFile(file)) {
				logger.info("[Inventory : " + "Calling method isMisiMsisdnFile.");
				resultBO = manageInventoryHelper.parseUploadImsiMsisdn(file);
			}
		}else {return resultBO;}
		logger.info("Existing method uploadManageInventory.", this);
		return resultBO;
	}

	@Override
	@Transactional
	/**
	 * Saving the inoutSTGPAT file to DB
	 */
	public ParseResultBO saveInOutPatFile(ParseResultBO parseResultBO)
			throws CometDataException, CometServiceException {
		parseResultBO = manageDAO.saveInOutStgPATs(parseResultBO);
		return parseResultBO;
	}

	@Override
	public ParseResultBO saveImsiMsisdnFile(ParseResultBO uploadFileBO)
			throws CometDataException, CometServiceException {
		String action = "";
		ParseResultBO parseResultBO = null;
		for (LineBO lineBO : uploadFileBO.getLines()) {
			ImsiMsisdnCSVLineBO dapnBO = (ImsiMsisdnCSVLineBO) lineBO;
			action = dapnBO.getActionField();

			if (action.equalsIgnoreCase("add")) {
				parseResultBO = manageDAO.saveImsiMsisdnFile(uploadFileBO);
				return parseResultBO;
			} else if (action.equalsIgnoreCase("update")) {
				parseResultBO = manageDAO.updateImsiMsisdnFile(uploadFileBO);
			}
		}
		return parseResultBO;
	}

	@Override
	public ParseResultBO saveRDRTFile(ParseResultBO uploadFileBO) throws CometDataException, CometServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional
	public ParseResultBO saveINOUTInterfaceFile(ParseResultBO resultBO)
			throws CometDataException, CometServiceException {
		logger.info("Starting method saveINOUTInterfaceFile", this);
		String action = "";
		ParseResultBO parseResultBO = null;
		for (LineBO lineBO : resultBO.getLines()) {
			InOutInterfaceCSVLineBO dapnBO = (InOutInterfaceCSVLineBO) lineBO;
			action = dapnBO.getActionField();

			if (action.equalsIgnoreCase("add")) {
				logger.info("Action ADD method saveINOUTInterfaceFile", this);
				parseResultBO = manageDAO.saveINOUTInterfaceFile(resultBO, lineBO);
			} else if (action.equalsIgnoreCase("update")) {
				logger.info("Action UPDATE method saveINOUTInterfaceFile", this);
				parseResultBO = manageDAO.updateINOUTInterfaceFile(resultBO, lineBO);
			}
		}
		logger.info("Existing method saveINOUTInterfaceFile", this);
		return parseResultBO;
	}

	@Override
	@Transactional
	public List<CountryBO> getCountryList() throws CometDataException {
		return manageDAO.getCountryList();
	}

	@Override
	@Transactional
	public List<StateBO> getStateList(Long countryId) throws CometDataException {
		return manageDAO.getStateList(countryId);
	}

	@Override
	@Transactional
	public List<CityBO> getCityList(Long stateId, String criteria) throws CometDataException {
		return manageDAO.getCityList(stateId, criteria);
	}

	@Override
	@Transactional
	public String saveCountryName(CountryBO countryBO) throws CometDataException, CometServiceException {
		return manageDAO.saveAndUpdateCountryName(countryBO);
	}

	@Override
	@Transactional
	public String saveDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		return manageDAO.saveDataCenter(dataCenterBO);
	}

	@Override
	@Transactional
	public List<MasterAdminCategoryBO> getCategoryInfo() throws CometDataException {
		logger.info("Starting method getCategoryInfo :", this);
		List<MasterAdminCategoryBO> masterAdminCategoryBOs = manageDAO.getCategoryInfo();
		logger.info("Existing method getCategoryInfo :", this);
		return masterAdminCategoryBOs;
	}

	@Override
	@Transactional
	public AdminCategoryBO getConfigInfo(AdminConfigParamBO adminConfigParamBO) throws CometDataException {
		logger.info("Starting method getConfigInfo :", this);
		if (StringUtils.isEmpty(adminConfigParamBO) && StringUtils.isEmpty(adminConfigParamBO.getCategoryId())) {
			logger.error("Category Id Missing.");
			throw new CometDataException("Error: Category Id Missing");
		}
		logger.info("Existing method getConfigInfo :", this);
		return manageDAO.getConfigInfo(adminConfigParamBO);
	}

	@Override
	@Transactional
	public String delDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		return manageDAO.delDataCenter(dataCenterBO);
	}

	@Override
	public String updateCountry(CountryBO countryBO) throws CometServiceException, CometDataException {
		return manageDAO.saveAndUpdateCountryName(countryBO);
	}

	@Override
	public String deleteCountryName(Long countryId) throws CometServiceException, CometDataException {
		return manageDAO.deleteCountryName(countryId);
	}

	@Override
	@Transactional
	public String addConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method addConfigInfo :", this);
		if (null == adminConfigBO || adminConfigBO.getCategoryId() == null) {
			logger.error("Category Id is empty for master data maintenance.", this);
			throw new CometDataException("Error", "Category Id is empty for master data maintenance.");
		}
		boolean isSaved = manageDAO.addConfigInfo(adminConfigBO);
		String message = null;
		if (isSaved) {
			message = "Record added successfully.";
		} else {
			message = "Record already exist.";
		}
		logger.info("Existing method addConfigInfo :", this);
		return message;
	}

	@Override
	@Transactional
	public String updateConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method updateConfigInfo :", this);
		if (null == adminConfigBO || null == adminConfigBO.getConfigId()) {
			logger.error("Admin Config Id is empty for master data maintenance.", this);
			throw new CometDataException("Error", "Admin Config Id is empty for master data maintenance.");
		}
		boolean isEdited = manageDAO.updateConfigInfo(adminConfigBO);
		String message = null;
		if (isEdited) {
			message = "Record updated successfully.";
		} else {
			message = "Record not updated.";
		}
		logger.info("Existing method updateConfigInfo :", this);
		return message;
	}

	@Override
	@Transactional
	public String deleteConfigInfo(Long configId) throws CometDataException {
		logger.info("Starting method deleteConfigInfo :", this);
		if (null == configId) {
			logger.error("Admin Config Id is empty for master data maintenance.", this);
			throw new CometDataException("Error", "Admin Config Id is empty for master data maintenance.");
		}
		boolean isDeleted = manageDAO.deleteConfigInfo(configId);
		String message = null;
		if (isDeleted) {
			message = "Record deleted.";
		} else {
			message = "Record not deleted.";
		}
		logger.info("Existing method deleteConfigInfo :", this);
		return message;
	}

	@Override
	@Transactional
	public List<OrderStatusBO> getOrderStatusList() throws CometDataException {
		return manageDAO.getOrderStatusList();
	}

	@Override
	@Transactional
	public String updateOrderStatus(OrderStatusBO orderStatusBO) throws CometDataException {
		logger.info("Starting method updateOrderStatus :", this);
		if (null == orderStatusBO || null == orderStatusBO.getOrderstatusId()) {
			logger.error("Order Status Id Is Empty.");
			throw new CometDataException("Error", "Order Status Id Is Empty.");
		}
		boolean isEdited = manageDAO.updateOrderStatus(orderStatusBO);
		String message = null;
		if (isEdited) {
			message = "Record updated successfully.";
		} else {
			message = "Record not updated.";
		}
		logger.info("Existing method updateOrderStatus :", this);
		return message;
	}

	@Override
	@Transactional
	public List<StateBO> getState() throws CometDataException {
		return manageDAO.getState();
	}

	@Override
	@Transactional
	public String updateDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		return manageDAO.updateDataCenter(dataCenterBO);
	}

	@Override
	public String deleteStateName(Long stateId) throws CometServiceException, CometDataException {
		return manageDAO.deleteStateName(stateId);
	}

	@Override
	public String deleteCityName(Long cityId) throws CometServiceException, CometDataException {
		return manageDAO.deleteCityName(cityId);
	}

	@Override
	@Transactional
	public String insertDapnRecords(List<LineBO> dapnBO, String status, long attuId,ParseResultBO resultBO) {
		String batchId = "";
		try {
			manageInventoryHelper.validateDapnFieldValues(dapnBO);
			manageDAO.insertDapnRecords(dapnBO, status, attuId);
			batchId = manageDAO.validateDapnRecords();
			logger.info("BATCH ID FOR DAPN::"+batchId);
			} catch (DapnValidationException e) {
			e.printStackTrace();
			resultBO.setInvalidFileMesage(messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.version")+"::"+e.getParams()[0]);
			return null;
		} catch (CometDataException e) {
			e.printStackTrace();
			resultBO.setInvalidFileMesage(e.getMessage());
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			resultBO.setInvalidFileMesage(e.getMessage());
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			resultBO.setInvalidFileMesage(e.getMessage());
			return null;
		}
		return batchId;
	
	}

	@Transactional
	@Override
	public List<DapnUploadStatusBO> getDapnUploadResultMessage(String batchId) {
		List<DapnUploadStatusBO> lstDapnUploadStatusBO = new ArrayList<DapnUploadStatusBO>();
		List<DapnUploadStatus> dapnUploadStatuslist =manageDAO.getDapnUploadResultMessage(batchId);
		DapnUploadStatusBO dapnUploadStatusBO;
		if(!CollectionUtils.isEmpty(dapnUploadStatuslist)) {
			for (DapnUploadStatus dapnUploadStatus : dapnUploadStatuslist) {
				dapnUploadStatusBO = new DapnUploadStatusBO();
				dapnUploadStatusBO.setLineNo(dapnUploadStatus.getLineNo());
				if (dapnUploadStatus.getStatus().equalsIgnoreCase(ManageInventoryConstant.FAILED)) {
					dapnUploadStatusBO.setMessageType("FAILED");
					dapnUploadStatusBO.setMessage(dapnUploadStatus.getErrorCode());
				}else {
					if (dapnUploadStatus.getActionField().equalsIgnoreCase("add")&& dapnUploadStatus.getStatus().equalsIgnoreCase(
							ManageInventoryConstant.SUCCESS)) {
						dapnUploadStatusBO.setMessageType("SUCCESS");
						dapnUploadStatusBO.setMessage(dapnUploadStatus.getErrorCode());
					}else {
						if (dapnUploadStatus.getActionField().equalsIgnoreCase("update") && dapnUploadStatus.getStatus().equalsIgnoreCase(
								ManageInventoryConstant.SUCCESS)) {
							dapnUploadStatusBO.setMessageType("SUCCESS");
							dapnUploadStatusBO.setMessage(dapnUploadStatus.getDapnId());
						}
					}
					lstDapnUploadStatusBO.add(dapnUploadStatusBO);
				}
			}
		}
		Collections.sort(lstDapnUploadStatusBO, new DapnUploadStatusBO());
		return lstDapnUploadStatusBO;
	}

	@Override
	public List<CityBO> getCity(Long countryId, Long stateId) throws CometServiceException, CometDataException {
		return manageDAO.getCity(countryId, stateId);
	}
	
	@Override
	@Transactional
	public String saveStateName(StateBO stateBO) throws CometDataException, CometServiceException {
		return manageDAO.saveAndUpdateStateName(stateBO);
	}
	
	@Override
	@Transactional
	public String updateState(StateBO stateBO) throws CometServiceException, CometDataException {
		return manageDAO.saveAndUpdateStateName(stateBO);
	}
	
	@Override
	@Transactional
	public String saveCityName(CityBO cityBO) throws CometDataException, CometServiceException {
		return manageDAO.saveAndUpdateCityName(cityBO);
	}
	
	@Override
	@Transactional
	public String updateCity(CityBO cityBO) throws CometServiceException, CometDataException {
		return manageDAO.saveAndUpdateCityName(cityBO);
	}
	
	@Override
	@Transactional
	public DataCenterBO getDataCenterInfo(Long dcId) throws CometServiceException, CometDataException {
		return manageDAO.getDataCenterInfo(dcId);
	}

	@Override
	@Transactional
	public StateBO getStateInfoById(long stateId) throws CometServiceException, CometDataException {
		return manageDAO.getStateById(stateId);
	}
	
	@Override
	@Transactional
	public CityBO getCityInfoById(long cityId) throws CometServiceException, CometDataException {
		 return manageDAO.getCityById(cityId);
	}
}
