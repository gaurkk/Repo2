package com.att.comet.bpm.service;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.client.RestClientException;

import com.att.comet.bpm.modal.BpmUserBO;
import com.att.comet.bpm.modal.BpmUserResponseBO;
import com.att.comet.bpm.modal.GroupBO;
import com.att.comet.bpm.modal.TaskInfoBO;
import com.att.comet.bpm.modal.TaskListRequestBO;
import com.att.comet.bpm.modal.TaskListResponseBO;
import com.att.comet.bpm.modal.TaskLocalVariablesBO;
import com.att.comet.common.exception.BPMException;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.order.task.modal.BpmTaskFieldDataBO;

public interface BPMService extends GenericCometService{
	TaskListResponseBO getOrderTaskList(TaskListRequestBO requestBO);
	List<TaskInfoBO> getOrderTaskList(Long orderId) throws RestClientException, URISyntaxException, BPMException;	
	BpmUserBO addUser(BpmUserBO userBO)  throws Exception;
	BpmUserResponseBO getUser(String attuid) throws RestClientException, URISyntaxException;
	GroupBO getOrCreateUserGroup(GroupBO groupBO) throws RestClientException, URISyntaxException;
	void addUserToGroup(GroupBO groupBO, BpmUserBO bpmUserBO) throws RestClientException, URISyntaxException, CometException;
	TaskListResponseBO getUserAssignedTasks(String attuid)  throws RestClientException, URISyntaxException;
	Map<String, Set<String>> assignTasksToUser(String assignUserAttuid, Set<String> taskIds) throws RestClientException, URISyntaxException;
	Boolean claimTask(String taskId, String attuid) throws RestClientException, URISyntaxException, BPMException;
	Boolean unclaimTask(String taskId) throws RestClientException, URISyntaxException, BPMException;
	Boolean assignTask(String taskId, String attuid) throws RestClientException, URISyntaxException, BPMException;
	Boolean completeTask(String taskId, BpmTaskFieldDataBO bpmTaskFieldDataBO) throws RestClientException, URISyntaxException, BPMException;
	Boolean saveTask(String taskId, BpmTaskFieldDataBO bpmTaskFieldDataBO) throws RestClientException, URISyntaxException, BPMException;
	List<TaskLocalVariablesBO> getTaskLocalVariables(String taskId, String name) throws RestClientException, URISyntaxException, BPMException;
}
