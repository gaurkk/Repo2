package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DAPN_STATUS")

public class DapnStatus {

	private Long dapnStatusId;
	private String dapnStatus;

	@Id
	@Column(name = "DAPN_STATUS_ID", nullable = false, length = 4)
	public Long getDapnStatusId() {
		return dapnStatusId;
	}

	public void setDapnStatusId(Long dapnStatusId) {
		this.dapnStatusId = dapnStatusId;
	}

	@Column(name = "DAPN_STATUS", nullable = false, length = 30)
	public String getDapnStatus() {
		return dapnStatus;
	}

	public void setDapnStatus(String dapnStatus) {
		this.dapnStatus = dapnStatus;
	}

}
