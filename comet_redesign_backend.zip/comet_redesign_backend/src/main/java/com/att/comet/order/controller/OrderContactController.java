package com.att.comet.order.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.exception.ErrorCodeConstant;
import com.att.comet.common.exception.UserRecordNotFoundException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.order.modal.OrderContactTabBO;
import com.att.comet.order.modal.OrderContactUserBO;
import com.att.comet.order.service.OrderServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderContactController {

	private static final Logger logger = LoggerFactory.getLogger(OrderContactController.class);

	@Autowired
	OrderServiceImpl orderService;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getContactInfo/{orderId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get Contact tab information", notes = "Get Contact tab information")
	public CometResponse<OrderContactTabBO> getOrderContactInfo(@PathVariable Long orderId) throws CometDataException { 
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getOrderContactInfo : ", this);
		CometResponse<OrderContactTabBO> cometResponse = new CometResponse<OrderContactTabBO>();
		OrderContactTabBO orderContactBO = null; 
		try {
			orderContactBO = orderService.getOrderContactTabInfo(orderId);
			if(null!=orderContactBO) {
				cometResponse.setMethodReturnValue(orderContactBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}else {
				logger.error("orderContactBO is having null value for ORDER ID :: ["+orderId+"]", this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getOrderContactInfo : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getUserlistForRole/{roleId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find User List Using Role Id", notes = "Get User List Using Role Id")
	public CometResponse<List<OrderContactUserBO>> getUserListByRoleId(@PathVariable Long roleId) throws CometDataException { 
		logger.info("[RoleId : " + (roleId == null ? "" : roleId) + "] "+ "Starting method getUserListByRoleId : ", this);
		CometResponse<List<OrderContactUserBO>> cometResponse = new CometResponse<List<OrderContactUserBO>>();
		List<OrderContactUserBO> orderContactUserListBO = null; 
		try {
			orderContactUserListBO = orderService.getUserlistForRole(roleId);
			if (CollectionUtils.isEmpty(orderContactUserListBO)) {
				logger.error("orderContactUserListBO is EMPTY for roleId::["+roleId+"]::"+ErrorCodeConstant.COMET_ROLE_NTF, this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode()); 
				cometResponse.setStatus(Status.BUSINESS_ERROR); 
			}
			cometResponse.setMethodReturnValue(orderContactUserListBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		if(cometResponse.getStatusCode().equals(CometResponse.Status.USER_INPUT.getCode()) && cometResponse.getStatus().equals(CometResponse.Status.USER_INPUT)){
			logger.info("RoleId::["+roleId+"]::"+ErrorCodeConstant.COMET_ROLE_NTF, this);
			throw new UserRecordNotFoundException("Role Id " + roleId +" Information not found for User");
		}
		logger.info("[RoleId : " + (roleId == null ? "" : roleId) + "] "+ "Exiting method getUserListByRoleId : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN","ROLE_ORDER_MANAGER"})
	@PutMapping(value = "order/orderContactUpdate", produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Updated Contact Info", notes = "Update Contact Info")
	public CometResponse<OrderContactTabBO> updateOrderContact(@RequestBody OrderContactTabBO orderContact, Authentication authentication) throws CometDataException, CometServiceException {
		logger.info("Starting method updateOrderContact : ", this);
		CometResponse<OrderContactTabBO> cometResponse = new CometResponse<OrderContactTabBO>();
		if (orderContact != null) {
			orderContact = orderService.updateOrderContact(orderContact, authentication);
			cometResponse.setMethodReturnValue(orderContact);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			logger.error("No Data Found", this);
			throw new CometDataException("No Data Found to update contact");
		}
		logger.info("Exiting method updateOrderContact : ", this);
		return cometResponse;
	}

}
