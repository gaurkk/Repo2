package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class BackhaulStatusBO extends CometGenericBO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3080264034200588447L;

	private int backhaulStatusId;
	private String backhaulStatusName;

}
