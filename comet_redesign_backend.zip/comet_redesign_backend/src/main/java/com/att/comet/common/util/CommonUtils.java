package com.att.comet.common.util;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.att.comet.order.dao.OrderConstants;
import com.att.comet.order.modal.IPv4;
import com.att.comet.order.modal.MobilePoolRangeBO;
import com.att.comet.user.modal.RoleEnum;

/**
 * Static utility class
 */
public class CommonUtils {
	private static Logger logger = LoggerFactory.getLogger(CommonUtils.class);

	/**
	 * Returns true if string is not null and not empty, otherwise returns false.
	 * 
	 * @param string
	 * @return boolean
	 */
	public static boolean isValidString(String string) {
		return (string != null && string.trim().length() > 0);
	}
	

	//validate  String date. it throws exception for invalid date
	public static void isValidDateString(String stringDate, String format)throws ParseException{
		DateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		sdf.parse(stringDate);
	}

	/**
	 * The method is used to convert String to Date
	 * 
	 * @param date
	 * @return String
	 */
	public static String convertStringToDate(String date) {

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date theDate = null;
		try {
			if (isValidString(date)) {
				theDate = dateFormat.parse(date);
				logger.debug("Date parsed = " + dateFormat.format(theDate));
			} else {
				String dateform = dateFormat.format(new Date());
				theDate = dateFormat.parse(dateform);
				logger.debug("Date parsed = " + dateFormat.format(theDate));
			}

		} catch (Exception e) {
			logger.error("Error parsing date " + e.getMessage());
		}
		return dateFormat.format(theDate);
	}

	/**
	 * Converts date to string as per specified format.
	 * 
	 * @param date
	 * @param format
	 * @return date in String format
	 */
	public static String dateToString(Date date, String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}

	/**
	 * Converts string to date as per specified format.
	 * 
	 * @param dateString
	 * @param format
	 * @return Date
	 * @throws ParseException
	 */
	public static Date stringToDate(String dateString, String format) throws ParseException {
		try {
			DateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.parse(dateString);
		} catch (ParseException e) {
			logger.error("CommonUtils.stringToDate: " + e.getMessage());
		}
		return null;
	}
	/**
	 * The method is used to compare to Dates whether they are the same or not.
	 * 
	 * @param date1
	 * @param date2
	 * @return a long value suggesting that whether the dates are the same , or the
	 *         date1 is before date2 or after date2.
	 */
	public static long compareDates(Date date1, Date date2) {
		return date1.getTime() - date2.getTime();
	}

	/**
	 * Converts the Date into mm/dd/yyyy hh:mm:ss am/pm format
	 * 
	 * @param date
	 * @return String
	 */
	public static String formatDate(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		DateFormatSymbols dateFormatSymbols = dateFormat.getDateFormatSymbols();
		dateFormatSymbols.setAmPmStrings(new String[] { "AM", "PM" });
		dateFormat.setDateFormatSymbols(dateFormatSymbols);
		return dateFormat.format(date);
	}

	
	/**
	 * Formats the content of the string for the Grid.
	 * 
	 * @param str
	 * @return String
	 */
	public static String formatContentForGrid(String str) {
		if (str == null)
			return "";
		try {
			if (str.contains("\r\n")) {
				str = str.replaceAll("\r\n", "<br />");
			}
			if (str.contains("\n")) {
				str = str.replaceAll("\n", "<br />");
			}
			if (str.contains("&")) {
				str = str.replaceAll("&", "&amp;");
			}
			if (str.contains("'")) {
				str = str.replaceAll("'", "\\\\'");
			}
			if (str.contains("\"")) {
				str = str.replaceAll("\"", "&quot;");
			}

			return str;
		} catch (Exception e) {
			/// logger.error(e);
			return "";
		}
	}

	/**
	 * Checks whether the string passed is not null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNotNullEmpty(String arg) {
		if ((arg != null) && (arg.isEmpty() == false)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the string passed is null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNullEmpty(String arg) {
		if ((arg == null) || (arg.isEmpty() == true)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the long argument passed is null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNullEmpty(Long arg) {
		if ((arg == null) || (arg.longValue() == 0)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether the string passed is not null or empty.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean isNotNullEmpty(Long arg) {
		if ((arg != null) && (arg.longValue() != 0)) {
			return true;
		}
		return false;
	}

	/**
	 * The method checks whether the string passed is null.
	 * 
	 * @param arg
	 * @return boolean
	 */
	public static boolean checkStringEmptyandNull(String arg) {
		if (arg != null && !arg.isEmpty())
			return true;
		else
			return false;
	}

	/**
	 * Formats the string passed by using appropriate arguments.
	 * 
	 * @param str
	 * @return String
	 */
	public static String formatQueryString(String str) {
		if (str == null)
			return "";
		try {
			if (str.contains("'")) {
				str = str.replaceAll("'", "''");
			}
			return str;
		} catch (Exception e) {
			///logger.error(e);
			return "";
		}
	}
	
	 // Generic function to convert list to set 
    public static <T> Set<T> convertListToSet(List<T> list) 
    { 
        // create an empty set 
        Set<T> set = new HashSet<>(); 
  
        // Add each element of list into the set 
        for (T t : list) 
            set.add(t); 
  
        // return the set 
        return set; 
    }
    
    public static String formatDate1(java.util.Date date) {
		SimpleDateFormat newFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		String formatedDate = newFormat.format(date);
		return formatedDate;
	}
    
	/**
	 * Removes the last space of the string passed.
	 * 
	 * @param str
	 * @return String
	 */
	public static String getStringTillSpace(String str) {
		if (str == null)
			return "";
		try {

			int space = str.indexOf(' ');
			if (space != -1) {
				return (str.substring(0, space));
			}
		} catch (Exception e) {
			logger.error("Error"+e, "Method :getStringTillSpace");
		}
		return "";
	}
	
	/**
	 * @return
	 */
	public static Date getExpireDate() {
		Calendar calendar = Calendar.getInstance();
	    calendar.add(Calendar.YEAR, 5);
	    Date dueDate = calendar.getTime();
	    return dueDate;
	}

	/**
	 * Get valid user
	 * 
	 * @param roleId
	 * @return
	 */
	public static Boolean isValidCrdUpdateUser(Long roleId) {
		Boolean isValid = false;
		
		if (roleId == RoleEnum.COMET_ADMIN.getRoleId() || roleId == RoleEnum.ORDER_SUBMITTERS.getRoleId()) {
			isValid = true;
		}
		
		return isValid;
	}
	
	public static boolean alphaNumericWithDotslash(String anyStr) {
		final Pattern stringEntry = Pattern.compile("^[a-zA-Z0-9\\-.]*$");
		return stringEntry.matcher(anyStr).matches();
	}
	
	public static boolean validateIpAddress(String iPaddress) {
		final Pattern IP_PATTERN = Pattern
				.compile("^([0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}
	
	public static boolean invalidNumeric(String string) {
		final Pattern NUMERIC = Pattern.compile("[0-9]*$");
		boolean isValid = NUMERIC.matcher(string).matches(); 
		return !isValid;
	}
	
	public static boolean isSubnetValid(String ipAddress, int subnet) {
		logger.debug("Method CommonUtils.isSubnetValid(): Start");

		boolean valid = false;

		if (CommonUtils.isNotNullEmpty(ipAddress)) {

			String[] ipAdd = ipAddress.split("\\.");

			double sum = 0;
			double subnetSize = Math.pow(2, (32 - subnet));

			for (int octet = 0, power = 3; octet <= 3; octet++, power--) {

				sum += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));

			}

			if (sum % subnetSize == 0) {
				valid = true;
			}else{
				valid = true;
			}
				
		}

		logger.debug("Method CommonUtils.isSubnetValid(): End");
		return valid;
	}
	
	public static boolean isSubnetValidIpv6(String ipAddress, int subnet) {
		logger.debug("Method CommonUtils.isSubnetValidIpv6(): Start");
		boolean valid = false;

		if (CommonUtils.isNotNullEmpty(ipAddress)) {

			String[] ipAdd = ipAddress.substring(0,(ipAddress.indexOf("::"))).split("\\:");

			long sum = 0;
			long subnetSize = (long) Math.pow(2, (128 - subnet));
			sum = (long) (Integer.parseInt(ipAdd[2],16)*(Math.pow(2, 16))+(Integer.parseInt(ipAdd[3],16)));
			if (sum % subnetSize == 0) {
				valid = true;
			}else{
				valid = true;
			}
		}

		logger.debug("Method CommonUtils.isSubnetValidIpv6(): End");
		return valid;
	}
	
	public static void updateMobilePoolRange(List<MobilePoolRangeBO> mobilePoolList) {
		logger.debug("Method CommonUtils.updateMobilePoolRange(): Start");

		if (mobilePoolList == null) {
			return;
		}

		String ipAddress;
		int subnet;
		double rangeStart;
		double rangeEnd;
		String[] ipAdd;

		for (MobilePoolRangeBO mobilePool : mobilePoolList) {

			ipAddress = mobilePool.getIpAddress();

			if (CommonUtils.isNotNullEmpty(ipAddress)) {

				ipAdd = ipAddress.split("\\.");
				subnet = mobilePool.getSubnet();

				rangeStart = 0;
				for (int octet = 0, power = 3; octet <= 3; octet++, power--) {

					rangeStart += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));

				}
				rangeEnd = (rangeStart + Math.pow(2, (32 - subnet))) - 1;

				mobilePool.setRangeStart(rangeStart);
				mobilePool.setRangeEnd(rangeEnd);
			}
		}
		logger.debug("Method CommonUtils.updateMobilePoolRange(): End");
	}
	
	public static boolean isNullOrEmpty(String str) {
		if (str == null || "".equalsIgnoreCase(str)) {
			return true;
		}
		return false;
	}
	
	public static boolean aplhaNumericWithSpace(String string) {
		final Pattern ALPHA_NUMERIC_SPACE = Pattern.compile("[a-zA-Z0-9\\s]*$");		
		return !ALPHA_NUMERIC_SPACE.matcher(string).matches();
	}
	public static boolean isInValidEmail(String email){
		final Pattern EMAIL_STRING = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$");
		boolean isValid = EMAIL_STRING.matcher(email.trim()).matches();
		return  !isValid;
	}
	public static boolean alphaNumeric(String string) {
		final Pattern ALPHA_NUMERIC = Pattern.compile("^[a-zA-Z0-9]*$");
		return ALPHA_NUMERIC.matcher(string).matches();
	}
	public static boolean validateFullyQDN(String domainName) {
		final Pattern IP_PATTERN = Pattern
				.compile("^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\\.[a-zA-Z]{2,})+$");
		return IP_PATTERN.matcher(domainName).matches();
	}
	public static boolean alphaNumericAccordingToPattern(String anyStr,String pattern) {
		final Pattern stringEntry = Pattern.compile("^[" + pattern +"]*$");
		return stringEntry.matcher(anyStr).matches();
	}
	public static boolean validateIpAddressIpv6(String iPaddress) {
		final Pattern IP_PATTERN = Pattern.compile("^(((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4}))?):((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4}))?)::/[0-9]{2,3})$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}
	public static boolean validateIpAddressDnsIpv6(String iPaddress) {
		final Pattern IP_PATTERN = Pattern.compile("^(((([0-9A-Fa-f]{1,4})?(:)){1,7}):)|([0-9A-Fa-f]{1,4}((:[0-9A-Fa-f]{1,4}){7}))$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}
	public static boolean aplhaNumericWithSpaceCheck(String string) {
		final Pattern ALPHA_NUMERIC_SPACE = Pattern.compile("[a-zA-Z0-9\\s]*$");
		boolean isValid = ALPHA_NUMERIC_SPACE.matcher(string).matches();
		return isValid;
	}
	public static boolean containsValidSpecialCharacters(String name) {
		if (name == null || name.trim().isEmpty()) {
			return false;
		}
		final Pattern alphaNumWithSpecialChars = Pattern.compile("^[a-zA-Z0-9~`!@#$%^&*()_+={}|:;\"'<>,.?/\\[\\]-]*$");
		return alphaNumWithSpecialChars.matcher(name).find();
	}
	public static String replaceContent(String str,String criteria) {
		if (str == null) {
			return null;
		}
		return StringUtils.replace(str, criteria, "");
	}
	
	public static String getPhoneValue(String arg) {
		if (isNotNullEmpty(arg)) {
			return arg.replaceAll("[\\s\\(\\)\\-]", "");
		}
		return null;
	}
	public static boolean alphaNumericWithDotslashUnderscore(String anyStr) {
		final Pattern stringEntry = Pattern.compile("^[a-zA-Z0-9\\-._]*$");
		return stringEntry.matcher(anyStr).matches();
	}
	public static boolean validSubnetRange(String string) {
		final Pattern NUMERIC = Pattern.compile("^[1-9]|[0-2][0-9]|3[0-2]$");
		boolean isValid = NUMERIC.matcher(string).matches(); 
		return isValid;
	}
	public static boolean isValidTunelInterfaceIp(String ipRange) {
		boolean isValidIP = false;
		try {
			IPv4 ipv4 = new IPv4(ipRange);
			Double hostRangeStart = new Double(0);
			Double hostRangeEnd = new Double(0);
			Double rangeStart = new Double(0);
			Double rangeEnd = new Double(0);
			String ipAddress = "";
			int subnet = 0;
			String[] ipAdd;
			for (String range : ipv4.getHostAddressRange().split(",")) {
				ipAddress = range.substring(0, range.indexOf("/"));
				subnet = Integer.parseInt(range.substring(range.indexOf("/") + 1, range.length()));

				if (ipAddress != null && !ipAddress.equals("")) {
					Double tempRangeStart = new Double(0);
					Double tempRangeEnd = new Double(0);
					ipAdd = ipAddress.split("\\.");
					for (int octet = 0, power = 3; octet <= 3; octet++, power--) {
						tempRangeStart += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));
					}
					tempRangeEnd = (tempRangeStart + Math.pow(2, (32 - subnet))) - 1;

					if (hostRangeStart == 0 || hostRangeStart > tempRangeStart)
						hostRangeStart = tempRangeStart;
					if (hostRangeEnd == 0 || hostRangeEnd < tempRangeEnd)
						hostRangeEnd = tempRangeEnd;
				}
			}
			ipAddress = ipRange.substring(0, ipRange.indexOf("/"));
			subnet = Integer.parseInt(ipRange.substring(ipRange.indexOf("/") + 1, ipRange.length()));

			if (ipAddress != null && !ipAddress.equals("")) {
				ipAdd = ipAddress.split("\\.");
				rangeStart = 0D;
				for (int octet = 0, power = 3; octet <= 3; octet++, power--) {
					rangeStart += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));
				}
				rangeEnd = (rangeStart + Math.pow(2, (32 - subnet))) - 1;
			}
			if (rangeStart >= hostRangeStart && rangeEnd <= hostRangeEnd) {
				isValidIP = true;
			}
		} catch (RuntimeException e) {
			e.printStackTrace();
		}
		return isValidIP;
	}
	
	public static boolean checkValidInput(String string, String columnType) {
		boolean result = true;
		if (columnType.equals("STRING")) {
			result = true;
		} else if (columnType.equals("NUMBER")) {
			String regex = "\\d+";
			result = string.matches(regex);
		} else if (columnType.equals("DATE")) {
			try {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				format.parse(string);
				return true;
			} catch (Exception e) {
				result = false;
			}
		}
		return result;
	}
	
	public static Boolean charToBoolean(Character input) {
		return (null != input 
				&& (input == 'Y' || input == 'y'));
	}
	
	public static boolean aplhabetsWithSpecialCharacters(String name) {
		final Pattern VLAN = Pattern.compile("^[a-zA-Z0-9\\s,&]*$");
		return VLAN.matcher(name).matches();
	}
	
	public static boolean validateDestinationIpAddress(String iPaddress) {
		final Pattern IP_PATTERN = Pattern
				.compile("^([0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}(\\/[0-9]{1,2})?$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}
		
	public static boolean validateIPv4AddressWithNetMask(String ipAddress) {
		final Pattern IP_PATTERN = Pattern
						.compile("^(([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){1}" + 	// initial first field, 1-255
						"(\\.([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){3}" +  			// following 3 fields, 0-255 
						"(\\/[1-9]|[1-2][0-9]|3[0-2])?$");  									// following the netmask field, 1-32
		
		return IP_PATTERN.matcher(ipAddress).matches();
	}
	
	public static boolean validateIPv6AddressWithNetMask(String ipAddress) {
		
		final Pattern IPV6_STD_PATTERN = Pattern.compile(
												"^[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}$" +
												"(\\/[1-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8])?$");  	// netmask field, 1-128
		
		final Pattern IPV6_HEX_COMPRESSED_PATTERN = Pattern.compile(
                								"^(([0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,5})?)" + 	// 0-6 hex fields
                								"::" +
                        						"(([0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,5})?)" + 	// 0-6 hex fields
                        						"(\\/[1-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8])?$"); 	// netmask field, 1-128
		boolean valid = false;
		valid = IPV6_STD_PATTERN.matcher(ipAddress).matches();
		
		if (!valid) {
			int colonCount = 0;
	        for(int i = 0; i < ipAddress.length(); i++) {
	            if (ipAddress.charAt(i) == ':') {
	                colonCount++;
	            }
	        }
	        valid = colonCount <= 7 && IPV6_HEX_COMPRESSED_PATTERN.matcher(ipAddress).matches();
		}
		
		return valid;
	}
	
	public static boolean validateIPv6Address(String ipAddress) {
		if (isNullEmpty(ipAddress)) {
			return false;
		}
		
		final Pattern IPV6_STD_PATTERN = Pattern.compile("^[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}$");
		
		final Pattern IPV6_HEX_COMPRESSED_PATTERN = Pattern.compile(
				"^(([0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,5})?)" + 	// 0-6 hex fields
				"::" +
				"(([0-9A-Fa-f]{1,4}(:[0-9A-Fa-f]{1,4}){0,5})?)");  	// 0-6 hex fields
				
		boolean valid = false;
		valid = IPV6_STD_PATTERN.matcher(ipAddress).matches();

		if (!valid) {
			int colonCount = 0;
			for(int i = 0; i < ipAddress.length(); i++) {
				if (ipAddress.charAt(i) == ':') {
					colonCount++;
				}
			}
			valid = colonCount <= 7 && IPV6_HEX_COMPRESSED_PATTERN.matcher(ipAddress).matches();
		}

		return valid;		
	}
	
	public static boolean validateIPv6Subnet(Integer subnet) {
		if (null == subnet) {
			return false;
		}
		
		final Pattern IPV6_SUBNET_PATTERN = Pattern.compile("^(0|[1-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8])$");
		
		return IPV6_SUBNET_PATTERN.matcher(subnet.toString()).matches();
	}
	
	public static boolean isValidPort(int port) {
		return (port >= OrderConstants.MIN_PORT && port <= OrderConstants.MAX_PORT);
	}

	public static void updateMobilePoolRangeIpv6(List<MobilePoolRangeBO> mobilePoolList) {
		logger.debug("Method OrderUtil.updateMobilePoolRange(): Start");

		if (mobilePoolList == null) {
			return;
		}

		String ipAddress;
		int subnet;
		double rangeStart;
		String[] ipAdd;

		for (MobilePoolRangeBO mobilePool : mobilePoolList) {

			ipAddress = mobilePool.getIpAddress();

			if (CommonUtils.isNotNullEmpty(ipAddress)) {
				ipAdd = ipAddress.split("\\:");
				subnet = mobilePool.getSubnet();
				rangeStart = ((Integer.parseInt(ipAdd[2],16)*(Math.pow(2,16)))+Integer.parseInt(ipAdd[3],16));
				mobilePool.setRangeStart(rangeStart);
				mobilePool.setRangeEnd(rangeStart + (Math.pow(2,(128-subnet))));
			}
		}
		logger.debug("Method OrderUtil.updateMobilePoolRange(): End");
	}
	public static boolean validateSubnet(String subNet) {
		final Pattern IP_SUBNET = Pattern.compile("^[0-9]{1,2}$");
		return IP_SUBNET.matcher(subNet).matches();
	}
	public static boolean validatePort(String value) {
		final Pattern IP_PATTERN = Pattern.compile("^[0-9](?:-?[0-9]+)*$");
		return IP_PATTERN.matcher(value).matches();
	}
	public static boolean subnetIpv4Range(String value) {
		if(null != value) {
			int i = Integer.parseInt(value);
			if (i >= 0 && i <= 32)
				return true;
			else
				return false;
		}else {
			return false;
		}
	}
	
	public static String getAttachmentExtension(String fileName) {
		String extensionName =null;
		extensionName= fileName.substring(fileName.lastIndexOf('.') + 1,fileName.length());
		if(extensionName.equalsIgnoreCase("ppt")){
			return "application/vnd.ms-powerpoint";
		}
		if(extensionName.equalsIgnoreCase("pptx")){
			return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
		}
		if(extensionName.equalsIgnoreCase("txt")){
				return "text/plain";	
		}
		if(extensionName.equalsIgnoreCase("vsd")){
			return "application/vnd.visio";
		}
		if(extensionName.equalsIgnoreCase("jpeg")){
			return "image/jpeg";
		}
		if(extensionName.equalsIgnoreCase("jpg")){
			return "image/jpeg";
		}
		if(extensionName.equalsIgnoreCase("doc")){
			return "application/msword"	;
		}
		if(extensionName.equalsIgnoreCase("csv")){
			return "text/csv";	
		}
		if(extensionName.equalsIgnoreCase("docx")){
			return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"	;	
		}
		if(extensionName.equalsIgnoreCase("pdf")){
			return "application/pdf";
		}
		if(extensionName.equalsIgnoreCase("png")){
			return "application/pdf	";
		}
		if(extensionName.equalsIgnoreCase("xls")){
			return "application/vnd.ms-excel";
		}
		if(extensionName.equalsIgnoreCase("xlsx")){
			return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		}
		if(extensionName.equalsIgnoreCase("msg")){
		return "application/octet-stream"	;		
		}
		if (extensionName.equalsIgnoreCase("rtf")) {
			return "application/rtf";
		}
		if (extensionName.equalsIgnoreCase("xml")) {
			return "application/xml";
		}
		if (extensionName.equalsIgnoreCase("zip")) {
			return "application/zip";
		}
		if (extensionName.equalsIgnoreCase("html")) {
			return "text/html";
		}
		if (extensionName.equalsIgnoreCase("gif")) {
			return "image/gif";
		}
		return null;
	}
}
