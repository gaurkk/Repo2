package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.Country;
import com.att.comet.dao.hibernate.bean.State;
import java.util.Optional;

@Repository
public interface StateRepository extends JpaRepository<State,Long>{
	List<State> findByCountry_CountryId(Long countryId);
	
	State findByCountryCountryIdAndStateName(Long countryId, String stateName);
	
	Optional<State> findByStateName(String stateName);
}
