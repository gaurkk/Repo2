package com.att.comet.common.modal;

import com.att.comet.manage.modal.AdminConfigParamBO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = true)
public class AdminConfigBO extends CometGenericBO {

	private static final long serialVersionUID = 7819968157488085310L;

	private Long categoryId;

	private String categoryValue;

	private String description;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long configId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character defaultValue;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AdminConfigParamBO adminConfigParam=new AdminConfigParamBO();

}
