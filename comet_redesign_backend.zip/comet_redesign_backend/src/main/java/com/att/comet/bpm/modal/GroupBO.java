package com.att.comet.bpm.modal;

import lombok.Data;

@Data
public class GroupBO {
	private String id;
	private String name;
	private String type;
}
