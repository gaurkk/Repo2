package com.att.comet.manage.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.manage.modal.ReleaseLockBO;
import com.att.comet.manage.modal.ReleaseLockResponseBO;
import com.att.comet.order.modal.OrderUserQueueBO;

public interface ReleaseLockService extends GenericCometService {
	
	ReleaseLockResponseBO getAllRequestLocks(String attuid);

	List<OrderUserQueueBO> getRequestLocksByOrderId(long orderId) throws CometServiceException;
	
	Boolean releaseLock(ReleaseLockBO releaseLockBO, HttpServletRequest request) throws CometServiceException;
}
