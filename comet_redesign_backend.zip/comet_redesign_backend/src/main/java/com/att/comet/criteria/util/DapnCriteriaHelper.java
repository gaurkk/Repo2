package com.att.comet.criteria.util;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.charts.dao.ChartsDAOImpl;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.SearchCriteriaImpl;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.dapn.DApnBatchRestriction;
import com.att.comet.restriction.dapn.DApnCreatedByRestriction;
import com.att.comet.restriction.dapn.DApnCreationDateRestriction;
import com.att.comet.restriction.dapn.DApnDataCenterRestriction;
import com.att.comet.restriction.dapn.DApnIdRestriction;
import com.att.comet.restriction.dapn.DApnMobileIPRangeRestriction;
import com.att.comet.restriction.dapn.DApnNameRestriction;
import com.att.comet.restriction.dapn.DApnNoRestriction;
import com.att.comet.restriction.dapn.DApnOrderIdRestriction;
import com.att.comet.restriction.dapn.DApnPDPIdRestriction;
import com.att.comet.restriction.dapn.DApnPDPNameRestriction;
import com.att.comet.restriction.dapn.DApnSizeRestriction;
import com.att.comet.restriction.dapn.DApnStatusRestriction;
import com.att.comet.restriction.dapn.DApnTypeRestriction;
import com.att.comet.restriction.dapn.DApnUserDefinedPPDIdRestriction;

@Component
public class DapnCriteriaHelper {

	@Autowired
	private static SearchCriteria criteria;

	@Autowired
	private List<CriteriaRenderer> listRenderers;

	private static final Logger logger = LoggerFactory.getLogger(ChartsDAOImpl.class);

	/**
	 * Get the object of Search Criteria
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria() throws Exception
	{
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl() : criteria.clone());
	}
	/**
	 * Get the object of Search Criteria with specified output format
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format) throws Exception
	{
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format) : criteria.clone());
	}
	/**
	 * Get the object of Search Criteria with specified output format and other details
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format, OtherDetails other) throws Exception
	{
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format, other) : criteria.clone());
	}
	/**
	 * Get Initial data to result
	 * @return Restriction
	 */
	public Restriction initalData()
	{
		return new DApnNoRestriction();
	}
	/**
	 * Add DApn Type of Addressing as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction typeOfAddressing(String propertyValue)
	{
		return new DApnTypeRestriction(propertyValue);
	}
	/**
	 * Add Apn size as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction apnSize(Long propertyValue)
	{
		return new DApnSizeRestriction(propertyValue);
	}
	/**
	 * Add Apn name as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction apnName(String propertyValue)
	{
		return new DApnNameRestriction(propertyValue);
	}
	/**
	 * Add PDP Name as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction pdpName(String propertyValue)
	{
		return new DApnPDPNameRestriction(propertyValue);
	}
	/**
	 * Add DApn Id as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction dapnId(String propertyValue)
	{
		return new DApnIdRestriction(propertyValue);
	}
	/**
	 * Add DApn Statuses as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction status(Set<Long> propertyValue)
	{
		return new DApnStatusRestriction(propertyValue);
	}
	/**
	 * Add Data center as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction dataCenter(Long propertyValue)
	{
		return new DApnDataCenterRestriction(propertyValue);
	}
	/**
	 * Add DApn Created by as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction createdBy(String propertyValue)
	{
		return new DApnCreatedByRestriction(propertyValue);
	}
	/**
	 * Add PDP Id as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction pdpId(Long propertyValue)
	{
		return new DApnPDPIdRestriction(propertyValue);
	}
	/**
	 * Add User Defined PDP Id as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction udpdpId(Long propertyValue)
	{
		return new DApnUserDefinedPPDIdRestriction(propertyValue);
	}
	/**
	 * Add Batch as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction batch(String propertyValue)
	{
		return new DApnBatchRestriction(propertyValue);
	}
	/**
	 * Add Order Id as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction orderId(Long propertyValue)
	{
		return new DApnOrderIdRestriction(propertyValue);
	}
	/**
	 * Add DApn creation date as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction createdOn(String fromDate, String toDate)
	{
		return new DApnCreationDateRestriction(fromDate,toDate);
	}
	/**
	 * Add DApn creation date as a restriction to result
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction mobileIpRange(String fromRange, String toRange)
	{
		return new DApnMobileIPRangeRestriction(fromRange,toRange);
	}
	/**
	 * Fetch Result with given Criteria
	 * @param criteria
	 * @return ResultBO
	 * @throws Exception 
	 */
	public ResultBO getOutput(SearchCriteria criteria) throws Exception
	{
		logger.info("Starting method getOutput : ", this);
		if(criteria.getRestrictions().size() == 0)
		{
			throw new Exception("No Criteria Found");
		}
		CriteriaRenderer renderer = null;
		switch(criteria.getFormat())
		{
		case GRID:
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		case PIE_CHART : 
			renderer = listRenderers.stream().filter(obj -> obj instanceof PieChartCriteriaRenderer).findFirst().get();
			break;
		case BAR_CHART :
			renderer = listRenderers.stream().filter(obj -> obj instanceof BarChartCriteriaRenderer).findFirst().get();
			break;
		case STACKED_COLUMN_CHART :
			renderer = listRenderers.stream().filter(obj -> obj instanceof StackedColumnChartCriteriaRenderer)
			.findFirst().get();
			break;
		case COLUMN_CHART :
			renderer = listRenderers.stream().filter(obj -> obj instanceof ColumnChartCriteriaRenderer).findFirst()
			.get();
			break;
		case LINE_CHART :
			renderer = listRenderers.stream().filter(obj -> obj instanceof LineChartCriteriaRenderer).findFirst().get();
			break;
		default :
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		}
		ResultBO result = renderer.getOutput(criteria);
		logger.info("Exiting method getOutput : ", this);
		return result;
	}
}

