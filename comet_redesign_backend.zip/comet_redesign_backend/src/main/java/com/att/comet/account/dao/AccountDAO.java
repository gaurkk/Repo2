package com.att.comet.account.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.web.multipart.MultipartFile;

import com.att.comet.account.modal.AccountBO;
import com.att.comet.account.modal.AccountFileDetailBO;
import com.att.comet.account.modal.AccountInfoBO;
import com.att.comet.account.modal.AccountSearchCriteriaBO;
import com.att.comet.account.modal.InternalProductAccountBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.account.modal.SubAccountBO;
import com.att.comet.common.dao.GenericCometDAO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;

public interface AccountDAO extends GenericCometDAO {

	/**
	 * The method for getting External Accounts in COMET based upon the criteria
	 * being passed as argument.
	 * 
	 * @param criteria
	 * @return List<AccountBO>
	 * @throws CometDataException
	 */
	public List<AccountBO> getExternalAccounts(AccountSearchCriteriaBO criteria) throws CometDataException;

	/**
	 * The method for getting Internal Accounts in COMET based upon the criteria
	 * being passed as argument.
	 * 
	 * @param criteria
	 * @return List<AccountBO>
	 * @throws CometDataException
	 */
	public List<AccountBO> getInternalAccounts(AccountSearchCriteriaBO criteria) throws CometDataException;

	public List<String> findMasterAccountNameList(String criteria) throws CometDataException;

	public List<String> findSubAccountNameList(String criteria) throws CometDataException;

	public List<String> findInternalInitiativeAccountNameList(String criteria) throws CometDataException;

	public List<String> findProductInitiativeAccountNameList(String criteria) throws CometDataException;

	public List<String> findApnNameList(String criteria) throws CometDataException;

	public AccountInfoBO getAccountInfo(String accountClassId, String accountId)
			throws CometServiceException, CometDataException;

	public AccountInfoBO updateAccountInfo(AccountInfoBO accountInfoBO) throws CometDataException, IOException;

	public boolean deleteSubAccount(String bcid) throws CometServiceException, CometDataException;

	public boolean deleteInternalProductAccount(String cipn) throws CometDataException;

	public AccountInfoBO createAccount(AccountInfoBO accountInfoBO)
			throws CometDataException, IOException, CometServiceException;

	public AccountFileDetailBO getFileDetails(String accountClassId, String accountId)
			throws CometDataException, SQLException;
	
	public String storeFile(MultipartFile file, String accountId, Long accClassId) throws CometDataException, IOException, CometServiceException, SerialException, SQLException;
	
	public List<MasterAccountBO> getExistingAccList() throws CometServiceException, CometDataException;
	
	public boolean delAccountAttachment(String accountClassId, String accountId) throws CometServiceException, CometDataException;
	
	public SubAccountBO getSubAccount(String bcid) throws CometDataException;
	
	public InternalProductAccountBO getInternalAndProductAccount(String cipn) throws CometDataException;
}
