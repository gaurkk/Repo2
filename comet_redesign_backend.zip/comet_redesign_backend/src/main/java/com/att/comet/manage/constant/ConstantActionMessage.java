package com.att.comet.manage.constant;

public class ConstantActionMessage {



	/**
	 * ORDER_SUBMIT_FAIL
	 */
	public final static String ORDER_SUBMIT_FAIL = "message.order.submit.fail";

	/**
	 * DAPN_SUBMIT_FAIL
	 */
	public final static String DAPN_SUBMIT_FAIL = "message.dapn.submit.fail";

	/**
	 * NO_FIELD
	 */
	public final static String NO_FIELD = "na";

	/**
	 * ORDER_SAVE_SUCCESS
	 */
	public final static String ORDER_SAVE_SUCCESS = "message.order.save.success";

	/**
	 * ORDER_SUBMIT_SUCCESS
	 */
	public final static String ORDER_SUBMIT_SUCCESS = "message.submit.success";

	/**
	 * ORDER_VALIDATE_SUCCESS
	 */
	public final static String ORDER_VALIDATE_SUCCESS = "message.order.validate.success";

	/**
	 * APN_VALIDATE_SUCCESS
	 */
	public final static String APN_VALIDATE_SUCCESS = "message.apn.validate.success";

	/**
	 * APN_NAME_NUMERIC_CHECK
	 */
	public final static String APN_NAME_NUMERIC_CHECK = "errors.apn.name.numeric.check";
	
	/**
	 * APN_NAME_NUMERIC_CHECK_FN
	 */
	public final static String APN_NAME_NUMERIC_CHECK_FN = "errors.apn.name.numeric.check.fn";

	/**
	 * PDP_NAME_NUMERIC_CHECK
	 */
	public final static String PDP_NAME_NUMERIC_CHECK = "errors.pdp.name.numeric.check";

	/**
	 * PDP_NAME_ALPHA_NUMERIC_CHECK
	 */
	public final static String PDP_NAME_ALPHA_NUMERIC_CHECK = "errors.pdp.name.alphanumeric.check";

	/**
	 * PDP_NAME_LENGTH_CHECK
	 */
	public final static String PDP_NAME_LENGTH_CHECK = "errors.pdp.name.length.check";

	/**
	 * ORDER_INITIATE_SUCCESS
	 */
	public final static String ORDER_INITIATE_SUCCESS = "message.order.initiate.success";
	
	//sp3599 Req#5.2.07
	public final static String ORDER_LOCK_REQ_SUCCESS="message.order.lock.request.success";
	public final static String ORDER_LOCK_REL_SUCCESS="message.order.lock.released.success";

	/**
	 * ORDER_CLAIM_SUCCESS
	 */
	public final static String ORDER_CLAIM_SUCCESS = "message.order.claim.success";

	/**
	 * ORDER_BACKHAUL_DELETE_SUCCESS
	 */
	public final static String ORDER_BACKHAUL_DELETE_SUCCESS = "message.order.backhaul.delete.success";

	/**
	 * ORDER_BACKHAUL_DELETE_SUCCESS_ADD
	 */
	public final static String ORDER_BACKHAUL_DELETE_SUCCESS_ADD = "message.order.backhaul.delete.successadd";

	/**
	 * ORDER_BACKHAUL_DELETE_SUCCESS_ACTIVATE
	 */
	public final static String ORDER_BACKHAUL_DELETE_SUCCESS_ACTIVATE = "message.order.backhaul.delete.successactivate";

	/**
	 * ORDER_BACKHAUL_VPN_DELETE_SUCCESS
	 */
	public final static String ORDER_BACKHAUL_VPN_DELETE_SUCCESS = "message.order.backhaul.vpn.delete.success";

	/**
	 * ORDER_BACKHAUL_VPN_DELETE_SUCCESS_ACTIVATE
	 */
	public final static String ORDER_BACKHAUL_VPN_DELETE_SUCCESS_ACTIVATE = "message.order.backhaul.vpn.delete.successactivate";

	/**
	 * ORDER_BACKHAUL_RESET_SUCCESS
	 */
	public final static String ORDER_BACKHAUL_RESET_SUCCESS = "message.order.backhaul.reset.success";

	/**
	 * ORDER_PDP_PACKAGE_SAVE
	 */
	public final static String ORDER_PDP_PACKAGE_SAVE = "message.order.pdp.success";

	/**
	 * ORDER_BACKHAUL_EMPTY
	 */
	public final static String ORDER_BACKHAUL_EMPTY = "message.order.backhaul.empty";

	/**
	 * ORDER_MPLS_VPN_NOTACTIVE
	 */
	public final static String ORDER_MPLS_VPN_NOTACTIVE = "message.order.mpls.vpn.nonactive";

	/**
	 * ERROR_REQUIRED
	 */
	public final static String ERROR_REQUIRED = "errors.required";

	/**
	 * NOT_ACTIVATED
	 */
	public final static String NOT_ACTIVATED = "errors.vpn.not.active";

	/**
	 * ERROR_ORDER_DC_IP_DUPLICATE
	 */
	public final static String ERROR_ORDER_DC_IP_DUPLICATE = "errors.order.dc.ip.duplicate";

	/**
	 * ERROR_MANDATORY_TAB
	 */
	public final static String ERROR_MANDATORY_TAB = "errors.tab.mandatory";

	/**
	 * DATA_SAVE_SUCCESS
	 */
	public final static String DATA_SAVE_SUCCESS = "message.data.save.success";

	/**
	 * MESSAGE_CANCEL_PRE_SUBMIT
	 */
	public final static String MESSAGE_CANCEL_PRE_SUBMIT = "message.order.cancel.presubmit";

	/**
	 * MESSAGE_CANCEL_POST_SUBMIT
	 */
	public final static String MESSAGE_CANCEL_POST_SUBMIT = "message.order.cancel.postsubmit";

	/**
	 * MESSAGE_EXPEDITE_SUCCESS
	 */
	public final static String MESSAGE_EXPEDITE_SUCCESS = "message.expedite.success";
	
	/**
	 * MESSAGE_ORDER_UPDATE_SUCCESS
	 */
	public final static String MESSAGE_ORDER_UPDATE_SUCCESS = "message.update.success";

	/**
	 * MESSAGE_ORDER_APN_SUBNET_INVALID
	 */
	public final static String MESSAGE_ORDER_APN_SUBNET_INVALID = "message.order.apn.subnet.invalid";

	/**
	 * MESSAGE_ORDER_APN_DC_SUBNET_INVALID
	 */
	public final static String MESSAGE_ORDER_APN_DC_SUBNET_INVALID = "message.order.apn.dc.subnet.invalid";

	/**
	 * MESSAGE_ORDER_APN_MP_OVERLAP
	 */
	public static final String MESSAGE_ORDER_APN_MP_OVERLAP = "message.order.apn.mobilepool.overlap";
	/**
	 * MESSAGE_ORDER_APN_DC_IP_INVALID
	 */
	public final static String MESSAGE_ORDER_APN_DC_IP_INVALID = "message.order.apn.dc.ip.invalid";

	/**
	 * MESSAGE_INVENTORY_DAPN_MP_OVERLAP
	 */
	public final static String MESSAGE_INVENTORY_DAPN_MP_OVERLAP = "message.inventory.dapn.mobilepool.overlap";

	/**
	 * MESSAGE_CHANGE_REQUEST_INITIATE
	 */
	public final static String MESSAGE_CHANGE_REQUEST_INITIATE = "message.order.changeRequest.initiate";
	
	/**
	 * MESSAGE_CHANGE_ORDER_INITIATE
	 */
	public final static String MESSAGE_CHANGE_ORDER_INITIATE = "message.order.changeOrder";

	/**
	 * MESSAGE_CHANGE_REQUEST_SUBMIT
	 */
	public final static String MESSAGE_CHANGE_REQUEST_SUBMIT = "message.order.changeRequest.submit";

	/**
	 * MESSAGE_CHANGE_REQUEST_CANCEL
	 */
	public final static String MESSAGE_CHANGE_REQUEST_CANCEL = "message.order.changeRequest.cancel";

	/**
	 * MESSAGE_OSD_REVIEW_SUCCESS
	 */
	public final static String MESSAGE_OSD_REVIEW_SUCCESS = "message.order.osdReview.success";

	/**
	 * MASTER_RECORD_EDITED
	 */
	public final static String MASTER_RECORD_EDITED = "message.master.edited.success";

	/**
	 * MASTER_RECORD_SAVED
	 */
	public final static String MASTER_RECORD_SAVED = "message.master.saved.success";

	/**
	 * MASTER_SELECT_RECORD
	 */
	public final static String MASTER_SELECT_RECORD = "message.master.select.record";

	/**
	 * MASTER_RECORD_DELETED
	 */
	public final static String MASTER_RECORD_DELETED = "message.master.delete.success";

	/**
	 * USER_GROUP_UPDATED
	 */
	public final static String USER_GROUP_UPDATED = "message.user.group.updated.success";

	/**
	 * ORDER_INVALID
	 */
	public final static String ORDER_INVALID = "message.order.invalid";

	/**
	 * DAPN_INVALID
	 */
	public final static String DAPN_INVALID = "message.dapn.invalid";

	/**
	 * DAPN_CREATE_SUCCESS
	 */
	public final static String DAPN_CREATE_SUCCESS = "message.dapn.create.success";

	/**
	 * DAPN_SAVE_SUCCESS
	 */
	public final static String DAPN_SAVE_SUCCESS = "message.dapn.save.success";

	/**
	 * DAPN_VALIDATE_SUCCESS
	 */
	public final static String DAPN_VALIDATE_SUCCESS = "message.dapn.validate.success";

	/**
	 * DAPN_CANCEL_SUCCESS
	 */
	public final static String DAPN_CANCEL_SUCCESS = "message.dapn.cancel.success";

	/**
	 * DAPN_SUBMIT_SUCCESS
	 */
	public final static String DAPN_SUBMIT_SUCCESS = "message.dapn.submit.success";

	/**
	 * DAPN_UPDATE_SUCCESS
	 */
	public final static String DAPN_UPDATE_SUCCESS = "message.dapn.update.success";

	/**
	 * DAPN_HOME_SAVE_FAIL
	 */
	public final static String DAPN_HOME_SAVE_FAIL = "message.dapn.home.save.fail";

	/**
	 * DAPN_CONTACT_SAVE_FAIL
	 */
	public final static String DAPN_CONTACT_SAVE_FAIL = "message.dapn.contact.save.fail";

	/**
	 * DAPN_CRD_SAVE_FAIL
	 */
	public final static String DAPN_CRD_SAVE_FAIL = "message.dapn.crd.save.fail";

	/**
	 * VPN_ADDED_SUCCESS
	 */
	public final static String VPN_ADDED_SUCCESS = "message.vpn.added.success";

	/**
	 * VPN_ACATIVATED_SUCCESS
	 */
	public final static String VPN_ACATIVATED_SUCCESS = "message.vpn.activated.success";

	/**
	 * VPN_CANCELLED_SUCCESS
	 */
	public final static String VPN_CANCELLED_SUCCESS = "message.vpn.cancelled.success";

	/**
	 * VPN_CANCELLED_FAILED
	 */
	public final static String VPN_CANCELLED_FAILED = "message.vpn.cancelled.failed";

	/**
	 * ORDER_VPN_CANCELLED_FAILED
	 */
	public final static String ORDER_VPN_CANCELLED_FAILED = "message.order.vpn.cancelled.failed";

	/**
	 * ORDER_VPN_DELETE_FAILED
	 */
	public final static String ORDER_VPN_DELETE_FAILED = "message.order.backhaul.vpn.delete.fail";

	/**
	 * VPN_CLOSE_SUCCESS
	 */
	public final static String VPN_CLOSE_SUCCESS = "message.vpn.close.success";

	/**
	 * VPN_REMOVED_SUCCESS
	 */
	public final static String VPN_REMOVED_SUCCESS = "message.vpn.removed.success";

	/**
	 * VPN_REMOVED_FAILED
	 */
	public final static String VPN_REMOVED_FAILED = "message.vpn.removed.failed";

	/**
	 * VPN_REMOVED_INTERNAL_SUCCESS
	 */
	public final static String VPN_REMOVED_INTERNAL_SUCCESS = "message.vpn.removed.internal.success";

	/**
	 * ORDER_VPN_REMOVED_FAILED
	 */
	public final static String ORDER_VPN_REMOVED_FAILED = "message.order.vpn.removed.failed";
	
	/**
	 * TASK_COMPLETE_SUCCESS
	 */
	public final static String TASK_COMPLETE_SUCCESS = "message.task.complete.success";

	/**
	 * TASK_SAVE_SUCCESS
	 */
	public final static String TASK_SAVE_SUCCESS = "message.task.save.success";
	
	/**
	 * TASK_CLAIM_SUCCESS
	 */
	public final static String TASK_CLAIM_SUCCESS = "message.task.claim.success";
	
	/**
	 * TASK_ASSIGN_SUCCESS
	 */
	public final static String TASK_ASSIGN_SUCCESS = "message.task.assign.success";
	
	/**
	 * TASK_RELEASE_SUCCESS
	 */
	public final static String TASK_RELEASE_SUCCESS = "message.task.release.success";
	
	/**
	 * SEARCH_TASK_RELEASE_SUCCESS
	 */
	public final static String SEARCH_TASK_RELEASE_SUCCESS = "message.search.task.release.success";
	
	/**
	 * SEARCH_TASK_RELEASE_SUCCESS
	 */
	public final static String SEARCH_TASK_ASSIGN_SUCCESS = "message.search.task.assign.success";
	

	/**
	 * DECOMMISSION_ORDER_SUCCESS
	 */
	public final static String MESSAGE_DECOMMISSION_ORDER_SUCCESS = "message.order.decommission";
	
	/**
	 * DECOMMISSION_ORDER_FAILURE
	 */
	public final static String MESSAGE_DECOMMISSION_ORDER_FAILURE = "message.order.decom.fail";
	
	/**
	 * COPY_ORDER_SUCCESS
	 */
	public final static String MESSAGE_COPY_ORDER_SUCCESS = "message.order.copyOrder";
	
	/**
	 * ADD_LOCATION_SUCCESS
	 */
	public final static String ADD_LOCATION_SUCCESS = "message.add.location.success";
	
	/**
	 * UPDATE_LOCATION_SUCCESS
	 */
	public final static String UPDATE_LOCATION_SUCCESS = "message.update.location.success";
	
	/**
	 * DELETE_LOCATION_SUCCESS
	 */
	public final static String DELETE_LOCATION_SUCCESS = "message.delete.location.success";
	
	/**
	 * DELETE_LOCATION_FAILURE
	 */
	public final static String DELETE_LOCATION_FAILURE = "message.delete.location.failure";
	
	/**
	 * MESSAGE_ON_HOLD_REQUEST_INITIATE
	 */
	public final static String MESSAGE_ON_HOLD_REQUEST_INITIATE = "message.on.hold.request.initiate";
	
	/**
	 * MESSAGE_ON_HOLD_REQUEST_CANCEL
	 */
	public final static String MESSAGE_ON_HOLD_REQUEST_CANCEL = "message.on.hold.request.cancel";
	
	/**
	 * MESSAGE_ON_HOLD_REQUEST_RESOLVE
	 */
	public final static String MESSAGE_ON_HOLD_REQUEST_RESOLVE = "message.on.hold.request.resolve";

	/**
	 * ORDER_IS_ON_HOLD
	 */
	public final static String ORDER_IS_ON_HOLD = "errors.order.onhold";
	
	
	/**
	 * ORDER_IS_ON_HOLD
	 */
	public final static String ORDER_IS_ON_HOLD_REQUEST_PENDING = "errors.order.onhold.request.pending";
	
	/**
	 * ORDER_IS_ON_HOLD
	 */
	public final static String ORDER_IS_ON_HOLD_REQUEST_PENDING_TTUAPPLICABILITY_NO = "errors.order.onhold.request.pending.ttuapplicability.no";
	
	
	/**
	 * NOT_A_VALID_FILE_FORMAT
	 */
	public final static String NOT_A_VALID_FILE_FORMAT = "errors.dapn.upload.invalid.file.format";
	
	/**
	 * COMMON_NOT_A_VALID_FILE_FORMAT
	 */
	public final static String COMMON_NOT_A_VALID_FILE_FORMAT = "errors.inventory.upload.invalid.file.format";
	
	/**
	 * FIELD_REQUIRED
	 */
	public static final String FIELD_REQUIRED="error.dapn.upload.field.required";
	
	/**
	 * INVALID_INPUT_VALUE
	 */
	public static final String INVALID_INPUT_VALUE="error.dapn.upload.field.invalid.input";
	
	/**
	 * FIELD_VALUE_ALREADY_EXIST
	 */
	public static final String FIELD_VALUE_ALREADY_EXIST="error.dapn.upload.field.already.exist";
	
	/**
	 * INVALID_RECORD
	 */
	public static final String INVALID_RECORD="error.dapn.upload.invalid.record";
	
	/**
	 * DAPN_RECORD_NOT_FOUND
	 */
	public static final String DAPN_RECORD_NOT_FOUND="error.dapn.upload.inventory.not.exists";
	
	/**
	 * DAPN_RECORD_ADDED_SUCCESSFULLY
	 */
	public static final String DAPN_RECORD_ADDED_SUCCESSFULLY="error.dapn.upload.record.added.successfully";
	
	/**
	 * DAPN_RECORD_UPDATED_SUCCESSFULLY
	 */
	public static final String DAPN_RECORD_UPDATED_SUCCESSFULLY="error.dapn.upload.record.updated.successfully";
	
	/**
	 * DAPN_RECORD_CROSS_MAX_LIMIT
	 */
	public static final String  DAPN_RECORD_CROSS_MAX_LIMIT="error.dapn.upload.cross.max.limit";
	/**
	 * ERROR_APN_STATIC_ADDRESSING_TYPE
	 */
	public final static String ERROR_APN_STATIC_ADDRESSING_TYPE = "errors.apn.addressing.type";

	/**
	 * MESSAGE_ON_RELEASE_DAPN_REQUEST
	 */
	public final static String MESSAGE_ON_RELEASE_DAPN_REQUEST = "message.on.release.dapn.request";
	/**
	 * MESSAGE_ON_CANCEL_RELEASE_DAPN_REQUEST
	 */
	public final static String MESSAGE_ON_CANCEL_RELEASE_DAPN_REQUEST = "message.on.cancel.release.dapn.request";
	
	/**
	 * CUSTOM_FILTER_SAVE_SUCCESS
	 */
	public final static String CUSTOM_FILTER_SAVE_SUCCESS = "message.save.customFilter.success";
	
	
	/**
	 * CUSTOM_FILTER_UPDATE_SUCCESS
	 */
	public final static String CUSTOM_FILTER_UPDATE_SUCCESS = "message.update.customFilter.success";
	
	
	/**
	 * CUSTOM_FILTER_DELETE_SUCCESS
	 */
	public final static String CUSTOM_FILTER_DELETE_SUCCESS = "message.delete.customFilter.success";
	
	public final static String ORDER_IN_INVALID_STATE = "error.order.invalid.state";
	
	/** 
	 * MESSAGE_VLANID_INVALID
	 */
	public final static String MESSAGE_VLAN_ID_INVALID = "message.order.bh.vlanId.invalid";
	
	/** 
	 * MESSAGE_VLANGI_INVALID
	 */
	public final static String MESSAGE_VLAN_GI_INVALID = "message.order.bh.vlanGi.invalid";
	
	/** 
	 * MESSAGE_CCS_ROUTER_BASE_RD_INVALID
	 */
	public final static String MESSAGE_CCS_ROUTER_BASE_RD_INVALID = "message.order.bh.ccsRouterBaseRd.invalid";
	
	/**
	 * ORDER_AMP_CREATE_JOB_SUCCESS
	 */
	public final static String MESSAGE_ORDER_AMP_CREATE_JOB_SUCCESS = "message.order.amp.createJob.success";
	/**
	 * MESSAGE_ORDER_AMP_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_AMP_CALL_ERROR = "message.order.ampCall.error";
	
	public final static String MESSAGE_ORDER_ACCA_CALL_ERROR = "message.order.accaCall.error";
	/**
	 * ORDER_AMP_GET_STATUS_SUCCESS 
	 */
	public final static String MESSAGE_ORDER_AMP_GET_STATUS_SUCCESS = "message.order.amp.get.status.success";
	/**
	 * ORDER_AMP_GET_STATUS_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_AMP_GET_STATUS_CALL_ERROR = "message.order.amp.getStatus.call.error";
	
	/**
	 * ORDER_CANCEL_AMP_REQUEST_SUCCESS
	 */
	public final static String MESSAGE_ORDER_CANCEL_AMP_REQUEST_SUCCESS = "message.order.cancel.ampRequest.success";
	/**
	 * ORDER_CANCEL_AMP_REQUEST_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_CANCEL_AMP_REQUEST_CALL_ERROR = "message.order.cancel.ampRequest.call.error";
	
	/**
	 * MESSAGE_ORDER_AMP_STATUS_CANCELLED
	 */
	public final static String MESSAGE_ORDER_AMP_STATUS_CANCELLED = "message.order.ampStatus.cancelled";
	/**
	 * MESSAGE_ORDER_AMP_STATUS_REJECTED
	 */
	public final static String MESSAGE_ORDER_AMP_STATUS_REJECTED = "message.order.ampStatus.rejected";
	/**
	 * MESSAGE_DATA_SYNC_SUCCESSFULLY
	 */
	public final static String MESSAGE_DATA_SYNC_SUCCESSFULLY = "message.dataSync.successfully";
	/**
	 * MESSAGE_DATA_SYNC_FAILED
	 */
	public final static String MESSAGE_DATA_SYNC_FAILED = "message.dataSync.error";
	/**
	 * MESSAGE_AMP_ELIGIBLE_OUT
	 */
	public final static String MESSAGE_ORDER_AMP_ELIGIBLE_OUT = "message.order.amp.eligible.out";
	/**
	 * HTTP_200
	 */
	public final static String MESSAGE_HTTP_200= "message.HTTP.200";
	/**
	 * HTTP_500
	 */
	public final static String MESSAGE_HTTP_500= "Request is not accepted, content will provide additional details.";
	/**
	 * ERROR_CODE_501
	 */
	public final static String MESSAGE_ERROR_CODE_501= "Authentication failed.";
	/**
	 * ERROR_CODE_403
	 */
	public final static String MESSAGE_ERROR_CODE_403= "Unauthorized permission";
	/**
	 * CREATE_REQUEST_ERROR_CODE_510
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_510= "Invalid input (unable to find request document).";
	/**
	 * CREATE_REQUEST_ERROR_CODE_410
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_410= "Invalid Workflow Type.";
	/**
	 * CREATE_REQUEST_ERROR_CODE_400
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_400= "Invalid JSON.";
	/**
	 * CREATE_REQUEST_ERROR_CODE_512
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_512= "Connectivity Engine Unreachable.";
	/**
	 * CREATE_REQUEST_ERROR_CODE_520
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_520= "Non-unique active customer+VRF Request.";
	/**
	 * CREATE_REQUEST_ERROR_CODE_521
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_521= "Invalid Request parameters.";
	/**
	 * CREATE_REQUEST_ERROR_CODE_599
	 */
	public final static String MESSAGE_AMP_CREATE_REQUEST_ERROR_CODE_599= "Create Request fail.";
	/**
	 * ERROR_CODE_510
	 */
	public final static String MESSAGE_ERROR_CODE_510= "Invalid input (unable to find request document).";
	/**
	 * ERROR_CODE_511
	 */
	public final static String MESSAGE_ERROR_CODE_511= "Database is unreachable."; 
	/**
	 * ERROR_CODE_512
	 */
	public final static String MESSAGE_ERROR_CODE_512= "Unable to cancel request (request is in progress).";
	/**
	 * ERROR_CODE_522
	 */
	public final static String MESSAGE_ERROR_CODE_522= "Invalid requestId.";
	/**
	 * ERROR_CODE_523
	 */
	public final static String MESSAGR_AMP_CANCEL_REQUEST_ERROR_CODE_523= "Cannot cancel Request after Approval.";
	
	/**
	 * ORDER_SAVE_NOT_ALLOW
	 */
	public final static String ORDER_SAVE_NOT_ALLOW = "message.order.save.not.allow";
	
	/**
	 * ORDER_DETAIL_AMP_REQUEST_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_DETAIL_AMP_REQUEST_CALL_ERROR = "message.order.details.ampRequest.call.error";
	
	/**
	 * ORDER SKIP AMP CALL FAIL
	 */
	public final static String MESSAGE_ORDER_SKIP_AMP_ERROR = "message.order.skipAmp.error";
	
	/**
	 * ORDER SKIP AMP CALL SUCCESS
	 */
	public final static String MESSAGE_ORDER_SKIP_AMP_SUCCESS = "message.skipAmp.successfully";
	
	/**
	 * MESSAGE_ORDER_AMP_VALIDATION_ERROR
	 */
	public static final String MESSAGE_ORDER_AMP_VALIDATION_ERROR = "message.order.ampCall.validation.error";
	
	/** 
	 * MESSAGE_ATT_TUNNEL_IP_INVALID
	 */
	public static final String MESSAGE_ATT_TUNNEL_IP_INVALID = "message.att.tunnel.interface.ip.invalid";
	
	/** 
	 * MESSAGE_CUSTOMER_TUNNEL_IP_INVALID
	 */
	public static final String MESSAGE_CUSTOMER_TUNNEL_IP_INVALID = "message.customer.tunnel.interface.ip.invalid";
	/** 
	 * MESSAGE_ATT_TUNNEL_IP_INVALID
	 */
	public static final String MESSAGE_ATT_TUNNEL_IP_DUPLICATE_VRFNAME = "message.order.ivpn.attTunnelIp.duplicate.error";
	
	/** 
	 * MESSAGE_CUSTOMER_TUNNEL_IP_INVALID
	 */
	public static final String MESSAGE_CUSTOMER_TUNNEL_IP_DUPLICATE_VRFNAME = "message.order.ivpn.custTunnelIp.duplicate.error";
	
	/** 
	 * MESSAGE_ATT_EXPORTLIST_APNDATA
	 */
	public static final String MESSAGE_ATT_EXPORTLIST_APNDATA = "message.order.ivpn.attExportList.ApnData.error";
	
	/** 
	 * MESSAGE_ERP_EXPORTLIST_APNDATA
	 */
	public static final String MESSAGE_ERP_EXPORTLIST_APNDATA = "message.order.ivpn.erpExportList.ApnData.error";
	/** 
	 * MESSAGE_CUSTOMER_TUNNEL_IP_INVALID
	 */
	public final static String MESSAGE_DUPLICATE_VRF_NAME = "message.order.bh.vrfName,duplicate.error";

	public final static String VALID_ORDER_ID = "message.order.valid.fail";
	
	public final static String NO_FIREWALL_CONDITION_FAIL_WARN = "message.order.nofirewallFail.conditionFail.warn";
	
	public final static String NO_FIREWALL_CONDITION_FAIL_WARN_WITHOUT_UNCHECKBOX = "message.order.nofirewallFail.conditionFail.warnWithoutUncheckBox";
	
	public final static String NO_FIREWALL_CONDITION_MEET_WARN = "message.order.nofirewall.conditionMeet.warn"; 
	/** 
	 * MESSAGE_INTERNET_VRF_NAME
	 */
	public final static String MESSAGE_INTERNET_VRF_NAME = "message.order.bh.vrfName.internet.error";
	
	public final static String PCRF_SELECTION_WARN = "message.order.pcrf.ipaddressingselection.warn"; 
	
	/**
	 * ORDER_AMP_CREATE_JOB_SUCCESS
	 */
	public final static String MESSAGE_ORDER_ACCA_CREATE_JOB_SUCCESS = "message.order.acca.createJob.success";
	public final static String MESSAGE_ACCA_DATASYNC_SUCCESS = "message.acca.dataSync.successfully";
	/**
	 * ORDER_DETAIL_AMP_REQUEST_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_DETAIL_ACCA_REQUEST_CALL_ERROR = "message.order.details.accaRequest.call.error";
	/**
	 * MESSAGE_ORDER_AMP_STATUS_CANCELLED
	 */
	public final static String MESSAGE_ORDER_ACCA_STATUS_CANCELLED = "message.order.accaStatus.cancelled";
	/**
	 * MESSAGE_ORDER_AMP_STATUS_REJECTED
	 */
	public final static String MESSAGE_ORDER_ACCA_STATUS_REJECTED = "message.order.accaStatus.rejected";
	
	/**
	 * ORDER_AMP_GET_STATUS_SUCCESS 
	 */
	public final static String MESSAGE_ORDER_ACCA_GET_STATUS_SUCCESS = "message.order.amp.get.status.success";
	
	/**
	 * ORDER_AMP_GET_STATUS_CALL_ERROR
	 */
	public final static String MESSAGE_ORDER_ACCA_GET_STATUS_CALL_ERROR = "message.order.acca.getStatus.call.error";
	
	/**
	 * ORDER_ACCA_STATUS_ENABLE_DISABLE_WARN
	 */
	public final static String MESSAGE_ORDER_ACCA_STATUS_ENABLE_DISABLE_WARN = "message.order.accaStatus.warn";

}
