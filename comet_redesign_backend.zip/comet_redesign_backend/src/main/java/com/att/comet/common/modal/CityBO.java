package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * POJO for StateBO
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class CityBO extends CometGenericBO implements Comparable<CityBO>{
	
	private static final long serialVersionUID = -1205745293702197797L;
	private Long cityId;
	private String cityName; 
	private Long stateId; 
	private Character active; 
	private Long countryId;
	private String countryName;
	private String stateName;
	@Override
	public int compareTo(CityBO cityBO) {		
		if (this.cityName != null && cityBO.cityName != null) {
			return this.cityName.compareTo(cityBO.cityName);
		}
		return -1;
	}
}