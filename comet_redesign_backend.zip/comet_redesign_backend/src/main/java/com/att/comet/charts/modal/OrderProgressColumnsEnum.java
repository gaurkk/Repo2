package com.att.comet.charts.modal;

public enum OrderProgressColumnsEnum {
	
	STATUS("STATUS", "string"), 
	COUNT("COUNT", "number"), 
	STYLE("STYLE", "string");

	private OrderProgressColumnsEnum(String orderProgressColumnName, String orderProgressColumnType) {
		this.columnName = orderProgressColumnName;
		this.columnType = orderProgressColumnType;
	}

	private String columnName;
	private String columnType;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

}
