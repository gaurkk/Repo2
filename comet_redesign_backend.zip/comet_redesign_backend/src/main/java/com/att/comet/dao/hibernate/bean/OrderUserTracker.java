package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_USER_TRACKER")
public class OrderUserTracker implements Serializable {

	private static final long serialVersionUID = -4185719562718579718L;

	private long orderId;
	private Orders orders;
	private String attuid;
	private long roleId;
	private Date accessOn;
	private String trackId;
	private String ipAddress;
	private String browser;
	private String action;
	private String tabName;
	private String httpMethod;
	private String httpStatusCode;
	private String contentType;

	public OrderUserTracker() {
	}

	public OrderUserTracker(Orders orders, String attuid, long roleId, String trackId) {
		this.orders = orders;
		this.attuid = attuid;
		this.roleId = roleId;
		this.trackId = trackId;
	}

	public OrderUserTracker(Orders orders, String attuid, long roleId, Date accessOn, String trackId) {
		this.orders = orders;
		this.attuid = attuid;
		this.roleId = roleId;
		this.accessOn = accessOn;
		this.trackId = trackId;
	}

	public OrderUserTracker(Orders orders, String attuid, long roleId, Date accessOn, String trackId, String ipAddress,
			String browser) {
		this.orders = orders;
		this.attuid = attuid;
		this.roleId = roleId;
		this.accessOn = accessOn;
		this.trackId = trackId;
		this.ipAddress = ipAddress;
		this.browser = browser;
	}

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public long getOrderId() {
		return this.orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	@Column(name = "ATTUID", nullable = false, length = 6)
	public String getAttuid() {
		return this.attuid;
	}

	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	@Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)
	public long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	@Column(name = "ACCESS_ON")
	public Date getAccessOn() {
		return this.accessOn;
	}

	public void setAccessOn(Date accessOn) {
		this.accessOn = accessOn;
	}

	@Column(name = "TRACK_ID", nullable = false, length = 100)
	public String getTrackId() {
		return this.trackId;
	}

	public void setTrackId(String trackId) {
		this.trackId = trackId;
	}

	@Column(name = "IP_ADDRESS")
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Column(name = "BROWSER")
	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	@Column(name = "ACTION")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Column(name = "TAB_NAME")
	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	@Column(name = "HTTP_METHOD")
	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	@Column(name = "STATUS_CODE")
	public String getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(String httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	@Column(name = "CONTENT_TYPE")
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

}
