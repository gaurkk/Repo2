package com.att.comet.common.constant;

public class BaseQueryNameConstant {

	public static final String BASE_QUERY_FOR_GRID = "BASE_QUERY_FOR_GRID";
	public static final String BASE_QUERY_FOR_DC_CONSUMPTION_GRID = "BASE_QUERY_FOR_DC_CONSUMPTION_GRID";
	public static final String BASE_QUERY_FOR_PIECHART = "BASE_QUERY_FOR_PIECHART";
	public static final String BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION = "BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION";
	public static final String BASE_QUERY_FOR_BARCHART = "BASE_QUERY_FOR_BARCHART";
	public static final String BASE_QUERY_FOR_STACKEDCOLUMNCHART = "BASE_QUERY_FOR_STACKEDCOLUMNCHART";
}
