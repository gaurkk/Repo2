package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.DataCenter;
@Repository
public interface DataCenterNameRepository extends JpaRepository<DataCenter,Long> {
	@Query("from DataCenter")
	List<DataCenter> getDataCenterNameList();
	
	List<DataCenter> findByDummyAndFirstNet(Character isDummy,String isFirstNet);
	
	DataCenter findByDataCenterId(Long dataCenterId);
	
	List<DataCenter> findByDummy(Character isDummy);
	
	DataCenter findByDataCenterName(String dataCenterName);
	
	@Query("from DataCenter where dummy ='N' and dataCenterName= :dcName")
	DataCenter getDateCenterDetails(String dcName);
	
	@Query("from DataCenter where dataCenterName= :dcName")
	DataCenter getDateCenterDetail(String dcName);
	
	
	
}
