package com.att.comet.charts.modal;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.common.modal.CometGenericBO;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ChartsRequestBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 1998885308980467124L;

	@Autowired
	private UserInfoBO userInfo;
	private String chartType;
	private String chartName;
	@Autowired
	private List<RestrictionBO> restrictions;

}
