package com.att.comet.common.util;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.configuration.ApplicationConfig;
import com.att.comet.user.modal.UserBO;

/**
 * LDAP Utility class to fetch the data from the LDAP.
 */
@Component
public class LDAPUtil implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(LDAPUtil.class);

	@Autowired
	private ApplicationConfig applicationConfig;

	/**
	 * SEARCHBASE
	 */
	private final static String SEARCHBASE = "ou=people, o=att, c=us";
	
	private String initctx;
	private String host;
	private String port;

	private String str_next = "";
	private NamingEnumeration<SearchResult> results;
	private String ldapstr;
	private Hashtable<Object, Object> env;
	private DirContext ctx;
	private SearchControls constraints;
	private SearchResult si;
	private Attributes attrs;

	private void init() {
		initctx = applicationConfig.getLdapInitContext();
		logger.info("LDAP initctx:: " + initctx);
		host = applicationConfig.getLdapHost();
		logger.info("LDAP Host:: " + host);
		port = applicationConfig.getLdapPort();
		logger.info("LDAP Port:: " + port);
	}
	
	public UserBO getUser(String str) {
		UserBO userBO = null;
		this.init();
		results = this.get(str);
		ldapstr = this.getNext();
		logger.info("ldapstr [" + ldapstr + "]");
		
		if (CommonUtils.isNotNullEmpty(ldapstr)) {
			userBO = new UserBO();
			userBO.setAttuid(this.getAttuid());
			userBO.setFirstName(this.getFirstname());
			userBO.setLastName(this.getLastname());
			userBO.setCellPhone(this.getMobileNumber());
			userBO.setDeskPhone(this.getTelephoneNumber());
			userBO.setEmail(this.getEmail());
			userBO.setStreetAddress(this.getStreet());
			userBO.setZipCode(this.getPostalCode());
			userBO.setDeskPhoneExtention(this.getTelephoneExtnNumber());
			userBO.setCityName(this.getCity());
			userBO.setStateName(this.getState());
			userBO.setCountryName(this.getCountry());
		}
		
		return userBO;
	}
	
	/**
	 * Returns the ATTUID as a string out of the string coming from LDAP.
	 * 
	 * @return String
	 */
	private String getAttuid() {
		String attuid = "";
		attuid = this.getAttributeValue("attuid");
		logger.info("ATTUID is ::" + attuid);
		return attuid;
	}

	/**
	 * Gets the First Name of the User based upon the ATTUID.
	 * 
	 * @return String
	 */
	private String getFirstname() {
		String fname = "";
		fname = this.getAttributeValue("nickname");
		logger.info("FirstName is ::" + fname);
		return fname;
	}

	/**
	 * Returns the Last name of the user based on the ATTUID.
	 * 
	 * @return String
	 */
	private String getLastname() {
		String lname = "";
		lname = this.getAttributeValue("sn");
		logger.info("LastName is ::" + lname);
		return lname;
	}

	/**
	 * Returns the full name of the user based upon the ATTUID passed. Method is
	 * being called from getFullName(String attuid).
	 * 
	 * @return String
	 */
	private String getFullName() {
		String name = "";
		name = this.getFirstname() + " " + this.getLastname();
		logger.info("FullName is ::" + name);
		return name;
	}

	/**
	 * Returns the Email of the user.
	 * 
	 * @return String
	 */
	private String getEmail() {
		String email = "";
		email = this.getAttributeValue("mail");
		logger.info("Email is ::" + email);
		return email;
	}

	/**
	 * Returns the State of the user.
	 * 
	 * @return String
	 */
	private String getState() {
		String state = "";
		state = this.getAttributeValue("st");
		logger.info("State is ::" + state);
		return state;
	}

	/**
	 * Returns the postal code of the user.
	 * 
	 * @return String
	 */
	private String getPostalCode() {
		String postalCode = "";
		postalCode = this.getAttributeValue("postalCode");
		logger.info("PostalCode is ::" + postalCode);
		return postalCode;
	}

	/**
	 * Returns the Street of the user's address.
	 * 
	 * @return String
	 */
	private String getStreet() {
		String street = "";
		street = this.getAttributeValue("street");
		logger.info("Street is ::" + street);
		return street;
	}

	/**
	 * Returns the user's telephone number.
	 * 
	 * @return String
	 */
	private String getTelephoneNumber() {
		String telephoneNumber = "";
		telephoneNumber = this.getAttributeValue("telephoneNumber");
		logger.info("Telephone Number is ::" + telephoneNumber);
		return telephoneNumber;
	}

	/**
	 * Returns the user's mobile number.
	 * 
	 * @return String
	 */
	private String getMobileNumber() {
		String mobileNumber = "";
		mobileNumber = this.getAttributeValue("mobilePhoneNumber");
		logger.info("Mobile Number is ::" + mobileNumber);
		return mobileNumber;
	}
	
	/**
	 * Returns the user's Telephone extension number.
	 * 
	 * @return String
	 */
	private String getTelephoneExtnNumber() {
		String extnNumber = "";
		extnNumber = this.getAttributeValue("ext");
		logger.info("Telephone Extension Number is ::" + extnNumber);
		return extnNumber;
	}

	/**
	 * Returns the user's city of residence as being mentioned in LDAP.
	 * 
	 * @return String
	 */
	private String getCity() {
		String city = "";
		city = this.getAttributeValue("l");
		logger.info("City is ::" + city);
		return city;
	}

	/**
	 * Country of the user as in LDAP.
	 * 
	 * @return String
	 */
	private String getCountry() {
		String country = "";
		String postalAddress = this.getAttributeValue("postalAddress");
		String address[] = postalAddress.split("\\$");
		if (address.length > 0) {
			country = address[address.length - 1];
		}
		logger.info("Country is ::" + country);
		return country;
	}

	/**
	 * Returns the LDAP string based upon the attuid.
	 * 
	 * @param str
	 * @return NamingEnumeration<SearchResult>
	 */
	private NamingEnumeration<SearchResult> get(String str) {
		String filter = "(" + str + ")";
		env = new Hashtable<Object, Object>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, initctx);
		env.put(Context.PROVIDER_URL, host+":"+port);

		try {
			/* get a handle to an Initial DirContext */
			ctx = new InitialDirContext(env);
			/* specify search constraints to search subtree */
			constraints = new SearchControls();
			constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
			/* search for all entries with str = args[0] */
			results = ctx.search(SEARCHBASE, filter, constraints);
		} catch (NamingException e) {
			logger.info("LDAP Search failed..Resource does not exist..");
			return (null);
		}
		return (results);
	}

	/**
	 * Seraches for the next item in the LDAP String.
	 * 
	 * @return String
	 */
	private String getNext() {
		/* for each entry print out name + all attrs and values */
		str_next = "";
		try {
			while (results != null && results.hasMore()) {
				si = (SearchResult) results.next();
				str_next += "|name:" + si.getName();
				attrs = si.getAttributes();
				if (attrs != null) {
					for (NamingEnumeration<? extends Attribute> ae = attrs
							.getAll(); ae.hasMoreElements();) {
						Attribute attr = (Attribute) ae.next();
						String attrId = attr.getID();
						for (Enumeration<?> vals = attr.getAll(); vals
								.hasMoreElements(); str_next += "|" + attrId
								+ ":" + vals.nextElement())
							;
					}
				}
				str_next += "|";
				logger.info("Next String is ::" + str_next);
				return (str_next);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			return ("");
		}
		return ("");
	}

	/**
	 * Returns the attribute value based upon the attribute passed.
	 * 
	 * @param attribute
	 * @return String
	 */
	private String getAttributeValue(String attribute) {
		String out = "";
		if (ldapstr.length() > 0) {
			String[] outAttr = toStringArray(ldapstr.substring(1, ldapstr
					.length()), "|");
			out = getLDAPValue(outAttr, attribute);
		}
		logger.info("Attribute Value is ::" + out);
		return out;
	}

	/**
	 * Returns an Array of String elements.
	 * 
	 * @param in
	 * @param delim
	 * @return String[]
	 */
	public static String[] toStringArray(String in, String delim) {
		StringTokenizer st = new StringTokenizer(in, delim);
		String[] temp = new String[st.countTokens()];
		int i = 0;
		while (st.hasMoreTokens()) {
			temp[i] = st.nextToken();
			i++;
		}
		logger.info("::" + temp);
		return temp;
	}

	/**
	 * Returns the LDAP value of the String with the Property name entered.
	 * 
	 * @param input
	 * @param propName
	 * @return String
	 */
	public static String getLDAPValue(String[] input, String propName) {
		String out = "";
		for (int i = 0; i < input.length; i++) {
			String row = input[i];
			if (row != null) {
				row = row.trim();
				String[] tokens = row.split(":");
				if (tokens.length == 2) {
					String key = tokens[0];
					String value = tokens[1];
					if (key != null && value != null) {
						key = key.trim();
						value = value.trim();
						if (key.equals(propName)) {
							out = value;
							break;
						}
					}
				}
			}
		}
		logger.info("LDAP Value is ::" + out);
		return out;
	}
}