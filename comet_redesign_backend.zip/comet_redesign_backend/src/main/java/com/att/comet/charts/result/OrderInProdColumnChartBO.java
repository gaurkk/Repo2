package com.att.comet.charts.result;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OrderInProdColumnChartBO implements Serializable {
	private static final long serialVersionUID = -5050598801110916179L;

	private String month;
	private int count;
}
