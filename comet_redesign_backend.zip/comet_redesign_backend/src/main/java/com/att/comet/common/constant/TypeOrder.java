package com.att.comet.common.constant;

/**
 * Contains all possible Order types available in a Comet Order 
 */
public enum TypeOrder {
	
	NEW 			(1001L, "New"),
	CANCELLED 		(1002L, "Cancelled"),
	EXPEDITE 		(1003L, "Expedite"),
	CHANGE_ORDER 	(1004L, "Change Order"),
	CHANGE_REQUEST 	(1005L, "Change Request"),
	DECOMMISSION 	(1006L, "Decommission"),
	UPDATE_ORDER 	(1007L, "Update Order");
	
	/**
	 * property variable id
	 */
	private final Long id;
	
	/**
	 * property variable name
	 */
	private final String name;

	/**
	 * Getter method for id
	 * @return Long
	 */
	public Long getId() {
		return id;
	}

	/**
	 * getter method for name
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * The method is used to get the name of the type of the order.
	 * @param id
	 * @return TypeOrder , if the id is not null otherwise null.
	 */
	public static TypeOrder getName(Long id) {
		if(id != null) {
			for(TypeOrder orderType : TypeOrder.values()) {
				if (orderType.getId().longValue() == id.longValue()) {
					return orderType;
				}
			}
		}
		return null;
	}

	/**
	 * Argument Constructor.
	 * @param id
	 * @param name
	 */
	private TypeOrder(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}