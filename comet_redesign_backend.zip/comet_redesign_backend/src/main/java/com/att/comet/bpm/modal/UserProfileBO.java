package com.att.comet.bpm.modal;

import lombok.Data;

@Data
public class UserProfileBO {
	private String id;
	private String firstName;
	private String lastName;
	private String email;
}
