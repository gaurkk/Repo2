package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class OrderUploadId implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "UPLOAD_FILE_TYPE_DOC_ID", nullable = false, precision = 12, scale = 0)
	private String uploadId;
	
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	private Long orderId;
}
