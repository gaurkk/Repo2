package com.att.comet.dao;

/**
 * Holds the scalar constant for native sql queries.
 */
public class ScalarConstants {

	/**
	 * Scalar constant for return column attuid. Used to get result of returned
	 * column by native sql.
	 */
	public static final String ATTUID = "attuid";

	/**
	 * Scalar constant for return column firstname. Used to get result of
	 * returned column by native sql.
	 */
	public static final String FIRSTNAME = "firstname";

	/**
	 * Scalar constant for return column APN_NAME_QUERY. Used to get result of
	 * returned column by native sql.
	 */
	public static final String APN_NAME_QUERY = ", orders ord, apn ap ";

	/**
	 * Scalar constant for return column lastname. Used to get result of
	 * returned column by native sql.
	 */
	public static final String LASTNAME = "lastname";

	/**
	 * Scalar constant for return column cell_phone. Used to get result of
	 * returned column by native sql.
	 */
	public static final String CELL_PHONE = "cell_phone";

	/**
	 * Scalar constant for return column active. Used to get result of returned
	 * column by native sql.
	 */
	public static final String ACTIVE = "active";

	/**
	 * Scalar constant for return column desk_phone. Used to get result of
	 * returned column by native sql.
	 */
	public static final String DESK_PHONE = "desk_phone";

	/**
	 * Scalar constant for return column email. Used to get result of returned
	 * column by native sql.
	 */
	public static final String EMAIL = "email";

	/**
	 * Scalar constant for return column street_address. Used to get result of
	 * returned column by native sql.
	 */
	public static final String STREET_ADDRESS = "street_address";

	/**
	 * Scalar constant for return column zip_code. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ZIP_CODE = "zip_code";

	/**
	 * Scalar constant for return column city_id. Used to get result of returned
	 * column by native sql.
	 */
	public static final String CITY_ID = "city_id";

	/**
	 * Scalar constant for return column city_name. Used to get result of
	 * returned column by native sql.
	 */
	public static final String CITY_NAME = "city_name";

	/**
	 * Scalar constant for return column state_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String STATE_ID = "state_id";

	/**
	 * Scalar constant for return column state_name. Used to get result of
	 * returned column by native sql.
	 */
	public static final String STATE_NAME = "state_name";

	/**
	 * Scalar constant for return column country_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String COUNTRY_ID = "country_id";

	/**
	 * Scalar constant for return column country_name. Used to get result of
	 * returned column by native sql.
	 */
	public static final String COUNTRY_NAME = "country_name";
	/**
	 * Scalar constant for return column UBCID. Used to get result of returned
	 * column by native sql.
	 */
	public static final String UBCID = "UBCID";
	/**
	 * Scalar constant for return column MASTER_ACCOUNT_NAME. Used to get result
	 * of returned column by native sql.
	 */
	public static final String MASTER_ACCOUNT_NAME = "MASTER_ACCOUNT_NAME";
	/**
	 * Scalar constant for return column BCID. Used to get result of returned
	 * column by native sql.
	 */
	public static final String BCID = "BCID";

	/**
	 * Scalar constant for return column BCID. Used to get result of returned
	 * column by native sql.
	 */
	public static final String V_BCID = "bcid";

	/**
	 * Scalar constant for return column SUB_ACCOUNT_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String SUB_ACCOUNT_NAME = "SUB_ACCOUNT_NAME";

	/**
	 * Scalar constant for return column ACCOUNT_TYPE_NAME. Used to get result
	 * of returned column by native sql.
	 */
	public static final String ACCOUNT_TYPE_NAME = "ACCOUNT_TYPE_NAME";

	/**
	 * Scalar constant for return column COMPANY_OWNER. Used to get result of
	 * returned column by native sql.
	 */
	public static final String COMPANY_OWNER = "COMPANY_OWNER";

	/**
	 * Scalar constant for return column PDP_PACKAGE_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PDP_PACKAGE_NAME = "PDP_PACKAGE_NAME";

	/**
	 * Scalar constant for return column PDP_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PDP_NAME = "PDP_NAME";

	/**
	 * Scalar constant for return column CREATED_BY. Used to get result of
	 * returned column by native sql.
	 */
	public static final String CREATED_BY = "CREATED_BY";

	/**
	 * Scalar constant for return column CREATED_ON. Used to get result of
	 * returned column by native sql.
	 */
	public static final String CREATED_ON = "TO_CHAR(SA.CREATED_ON,MM/DD/YYYY)";

	/**
	 * Scalar constant for return column CREATED_ON1. Used to get result of
	 * returned column by native sql
	 */
	public static final String CREATED_ON1 = "TO_CHAR(SA.CREATED_ON,'MM/DD/YYYY')";

	/**
	 * Scalar constant for return column CIPN. Used to get result of returned
	 * column by native sql.
	 */
	public static final String CIPN = "CIPN";

	/**
	 * Scalar constant for return column CIPN. Used to get result of returned
	 * column by native sql.
	 */
	public static final String V_CIPN = "cipn";

	/**
	 * Scalar constant for return column INTERNAL_PRODUCT_ACCOUNT_NAME. Used to
	 * get result of returned column by native sql.
	 */
	public static final String INTERNAL_PRODUCT_INITIATIVE_NAME = "INTERNAL_PRODUCT_ACCOUNT_NAME";

	/**
	 * Scalar constant for return column ACCOUNT_TYPE. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ACCOUNT_TYPE = "ACCOUNT_CLASS_NAME";

	/**
	 * Scalar constant for return column ACCOUNT_CREATED_BY. Used to get result
	 * of returned column by native sql.
	 */
	public static final String ACCOUNT_CREATED_BY = "CREATED_BY";

	/**
	 * Scalar constant for return column CREATED_ON. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ACCOUNT_CREATED_ON = "TO_CHAR(IPA.CREATED_ON,'MM/DD/YYYY')";

	/**
	 * Scalar constant for return column CREATED_ON. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ACCOUNT_CREATED_ON1 = "TO_CHAR(IPA.CREATED_ON,MM/DD/YYYY)";

	/**
	 * Scalar constant for return column APN_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String APN_NAME = "APN_NAME";

	/**
	 * Scalar constant for return column ORDER_ID. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ORDER_ID = "ORDER_ID";

	/**
	 * Scalar constant for return column IP_ADDRESS_SOURCE_ID. Used to get
	 * result of returned column by native sql.
	 */
	public static final String IP_ADDRESS_SOURCE = "IP_ADDRESS_SOURCE";

	/**
	 * Scalar constant for return column STATIC_ADDRESS_TYPE. Used to get result
	 * of returned column by native sql.
	 */
	public static final String ADDRESS_TYPE = "ADDRESS_TYPE";

	/**
	 * Scalar constant for return column TOTAL_MOBILE_POOL_SIZE. Used to get
	 * result of returned column by native sql.
	 */
	public static final String TOTAL_MOBILE_POOL_SIZE = "TOTAL_MOBILE_POOL_SIZE";

	/**
	 * Scalar constant for return column MOBILE_TO_MOBILE_ENABLED. Used to get
	 * result of returned column by native sql.
	 */
	public static final String MOBILE_TO_MOBILE_ENABLED = "MOBILE_TO_MOBILE_ENABLED";

	/**
	 * Scalar constant for return column MOBILE_TERMINATION_ENABLED. Used to get
	 * result of returned column by native sql.
	 */
	public static final String MOBILE_TERMINATION_ENABLED = "MOBILE_TERMINATION_ENABLED";

	/**
	 * Scalar constant for return column RAD_ACC_SERV_ENABLED. Used to get
	 * result of returned column by native sql.
	 */
	public static final String VPN_ID = "vpn_id";

	/**
	 * Scalar constant for return column VPN_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String VPN_NAME = "vpn_name";

	/**
	 * Scalar constant for return column VPN_CUST_CONTACT. Used to get result of
	 * returned column by native sql.
	 */
	public static final String VPN_CUST_CONTACT = "vpn_cust_contact";

	/**
	 * Scalar constant for return column VPN_COMPANY_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String VPN_COMPANY_NAME = "vpn_company_name";

	/**
	 * Scalar constant for return column VPN_TYPE. Used to get result of
	 * returned column by native sql.
	 */
	public static final String VPN_TYPE = "vpn_type";

	/**
	 * Scalar constant for return column VPN_MCN. Used to get result of returned
	 * column by native sql.
	 */
	public static final String VPN_MCN = "vpn_mcn";

	/**
	 * Scalar constant for return column VPN_GRC. Used to get result of returned
	 * column by native sql.
	 */
	public static final String VPN_GRC = "vpn_grc";

	/**
	 * Scalar constant for return column CREATED_BY_ORDER_ID. Used to get result
	 * of returned column by native sql.
	 */
	public static final String CREATED_BY_ORDER_ID = "created_by_order_id";

	/**
	 * Scalar constant for return column icore_cust_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String I_CORE_CUST_ID = "icore_cust_id";

	/**
	 * Scalar constant for return column icore_cust_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String I_CORE_CUST_NAME = "icore_cust_name";

	/**
	 * Scalar constant for return column instar_vpn_status. Used to get result
	 * of returned column by native sql.
	 */
	public static final String INSTAR_VPN_STATUS = "instar_vpn_status";

	/**
	 * Scalar constant for return column order_driven_by. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ORDER_DRIVEN_BY = "order_driven_by";

	/**
	 * Scalar constant for return column backhaul_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String BACKHAUL_ID = "backhaul_id";

	/**
	 * Scalar constant for return column DATA_CENTER_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String DATA_CENTER_NAME = "data_center_name";

	/**
	 * Scalar constant for return column apn_id. Used to get result of returned
	 * column by native sql.
	 */
	public static final String APN_ID = "apn_id";

	/**
	 * Scalar constant for return column data_center_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String DATA_CENTER_ID = "data_center_id";

	/**
	 * Scalar constant for return column backhaul_selection. Used to get result
	 * of returned column by native sql.
	 */
	public static final String BACKHAUL_SELECTION = "backhaul_selection";

	/**
	 * Scalar constant for return column BACKHAUL_DISPLAY_ID. Used to get result
	 * of returned column by native sql.
	 */
	public static final String BACKHAUL_DISPLAY_ID = "backhaul_display_id";

	/**
	 * Scalar constant for return column ip_address. Used to get result of
	 * returned column by native sql.
	 */
	public static final String IP_ADDRESS = "ip_address";

	/**
	 * Scalar constant for return column mobile_pool_address_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String MOBILE_POOL_ADDRESS_ID = "mobile_pool_address_id";


	/**
	 * Scalar constant for return column mobile_pool_address_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String IP_ADDRESS_TYPE = "ip_address_type";

	/**
	 * Scalar constant for return column pat_pool_address_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PAT_POOL_ADDRESS_ID = "pat_pool_address_id";

	/**
	 * Scalar constant for return column CONCENTRATOR_PUBLIC_IP. Used to get
	 * result of returned column by native sql.
	 */
	public static final String CONCENTRATOR_PUBLIC_IP = "concentrator_public_ip";

	/**
	 * Scalar constant for return column CUST_HOST_ROUTER_IP. Used to get result
	 * of returned column by native sql.
	 */
	public static final String CUST_HOST_ROUTER_IP = "cust_host_router_ip";

	/**
	 * Scalar constant for return column backhaul_type_name. Used to get result
	 * of returned column by native sql.
	 */
	public static final String BACKHAUL_TYPE_NAME = "backhaul_type_name";

	/**
	 * Scalar constant for return column resource_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String RESOURCE_ID = "resource_id";

	/**
	 * Scalar constant for return column resource_name. Used to get result of
	 * returned column by native sql.
	 */
	public static final String RESOURCE_NAME = "resource_name";

	/**
	 * Scalar constant for return column required. Used to get result of
	 * returned column by native sql.
	 */
	public static final String REQUIRED = "required";

	/**
	 * Scalar constant for return column editable. Used to get result of
	 * returned column by native sql.
	 */
	public static final String EDITABLE = "editable";

	/**
	 * Scalar constant for return column COMPANY_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String COMPANY_NAME = "COMPANY_NAME";

	/**
	 * Scalar constant for return column UPDATED_ON. Used to get result of
	 * returned column by native sql.
	 */
	public static final String UPDATED_ON = "UPDATED_ON";

	/**
	 * Scalar constant for return column ORDER_STATUS_NAME. Used to get result
	 * of returned column by native sql.
	 */
	public static final String ORDER_STATUS_NAME = "ORDER_STATUS_NAME";

	/**
	 * Scalar constant for return column ORDER_TYPE_NAME. Used to get result of
	 * returned column by native sql.
	 */
	public static final String ORDER_TYPE_NAME = "ORDER_TYPE_NAME";

	/**
	 * Scalar constant for return column CREATED_ON. Used to get result of
	 * returned column by native sql.
	 */
	public static final String CREATED_ON_ = "CREATED_ON";

	/**
	 * Scalar constant for return column TERMA_CIRCUIT_ID. Used to get result of
	 * returned column by native sql.
	 */
	public static final String TERMA_CIRCUIT_ID = "terma_circuit_id";

	/**
	 * Scalar constant for return column TERMZ_CIRCUIT_ID. Used to get result of
	 * returned column by native sql.
	 */
	public static final String TERMZ_CIRCUIT_ID = "termz_circuit_id";

	/**
	 * * Scalar constant for return column MCN. Used to get result of returned
	 * column by native sql.
	 */
	public static final String MCN = "mcn";

	/**
	 * Scalar constant for return column GRC. Used to get result of returned
	 * column by native sql.
	 */
	public static final String GRC = "grc";

	/**
	 * Scalar constant for return column PVC_TYPE_ORDER. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PVC_TYPE_ORDER = "pvc_type_order";

	/**
	 * Scalar constant for return column PVC_CIR. Used to get result of returned
	 * column by native sql.
	 */
	public static final String PVC_CIR = "pvc_cir";

	/**
	 * Scalar constant for return column TERMA_DLCI. Used to get result of
	 * returned column by native sql.
	 */
	public static final String TERMA_DLCI = "terma_dlci";

	/**
	 * Scalar constant for return column TERMZ_DLCI. Used to get result of
	 * returned column by native sql.
	 */
	public static final String TERMZ_DLCI = "termz_dlci";

	/**
	 * Scalar constant for return column PVC_NUMBER. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PVC_NUMBER = "pvc_number";

	/**
	 * Scalar constant for return column NPA_NXX. Used to get result of returned
	 * column by native sql.
	 */
	public static final String NPA_NXX = "npa_nxx";

	/**
	 * Scalar constant for return column TTU_DATE. Used to get result of
	 * returned column by native sql.
	 */
	public static final String TTU_DATE = "ttu_date";

	/**
	 * Scalar constant for return column PDP_ID_QUERY. Used to get result of
	 * returned column by native sql.
	 */
	public static final String PDP_ID_QUERY = ", pdp_id_info pdpinfo ";

	/**
	 * Scalar Constant for IT OPS Default
	 */
	public static final String IT_OPS_DEFAULT = "ITOPSDEFAULT";

	/**
	 * Scalar constant for return column CCS_VRF_NAME.
	 */
	public static final String CCS_VRF_NAME = "CCS_VRF_NAME";

	/**
	 * Scalar constant for return column COMET_ORDER_ID.
	 */
	public static final String COMET_ORDER_ID = "comet_order_id";

	/**
	 * Scalar constant for return column INSTAR_VPNID.
	 */
	public static final String INSTAR_VPNID = "instar_vpn_id";

	/**
	 * Scalar constant for return column CANCEL_ORDER_ID.
	 */
	public static final String CANCEL_ORDER_ID = "order_id";

	/**
	 * Scalar constant for return column ADD.
	 */
	public static final String ADD = "ADD";

	/**
	 * Scalar constant for return column ACTIVATED.
	 */
	public static final String ACTIVATED = "ACTIVATED";

	/**
	 * Scalar constant for return column ACTACK.
	 */
	public static final String ACTACK = "ACTACK";

	/**
	 * Scalar constant for return column REMACK.
	 */
	public static final String REMACK = "REMACK";

	/**
	 * Scalar constant for return column PRIMARY_RT.
	 */
	public static final String PRIMARY_RT = "primary_rt";

	/**
	 * Scalar constant for return column INSTAR_ORDER_ID.
	 */
	public static final String INSTAR_ORDER_ID = "instar_order_id";

	/**
	 * Scalar constant for return column VPN_STATUS.
	 */
	public static final String VPN_STATUS = "status";

	/**
	 * Scalar constant for return column ORDER_CREATED_ON.
	 */
	public static final String  ORDER_CREATED_ON = "CREATED_ON";

	/**
	 * Scalar constant for return column COUNT.
	 */
	public static final String  COUNT = "COUNT";
	/**
	 * Scalar constant for return column COLOR.
	 */
	public static final String  COLOR = "COLOR";
	/**
	 * Scalar constant for return column STATUS.
	 */
	public static final String  STATUS = "STATUS";
	/**
	 * Scalar constant for return column USERID.
	 */
	public static final String  USERID = "USERID";
	/**
	 * Scalar constant for return column THE_DATE.
	 */
	public static final String  THE_DATE = "THE_DATE";
	/**
	 * Scalar constant for return column ALL_COUNT.
	 */
	public static final String  ALL_COUNT = "ALL_COUNT";
	/**
	 * Scalar constant for return column USER_COUNT.
	 */
	public static final String  USER_COUNT = "USER_COUNT";
	/**
	 * Scalar constant for return column MONTH.
	 */
	public static final String  MONTH = "MONTH";
	/**
	 * Scalar constant for return column AVG_ORDERSUM_IMPLECOMPL.
	 */
	public static final String AVG_ORDERSUM_IMPLECOMPL = "AVG_ORDERSUM_IMPLECOMPL";
	/**
	 * Scalar constant for return column AVG_ORDERSUM_TTUPASS.
	 */
	public static final String AVG_ORDERSUM_TTUPASS = "AVG_ORDERSUM_TTUPASS";
	/**
	 * Scalar constant for return column AVG_OSDAPPR_IMPLECOMPL.
	 */
	public static final String AVG_OSDAPPR_IMPLECOMPL = "AVG_OSDAPPR_IMPLECOMPL";
	/**
	 * Scalar constant for return column FLAG.
	 */
	public static final String FLAG = "FLAG";
	/**
	 * Scalar constant for return column STATUS.
	 */
	public static final String BACKHAUL_STATUS = "STATUS";
	/**
	 * Scalar constant for return column TUNNELTYPE or VPNNAME.
	 */
	public static final String TUNNELTYPE_VPNNAME = "TUNNELTYPE_VPNNAME";
	/**
	 * Scalar constant for return column SHARED_APN.
	 */
	public static final String SHARED_APN = "SHARED_APN";
	/**
	 * Scalar constant for return column BACKHAUL_ID.
	 */
	public static final String SEARCH_BACKHAUL_ID = "BACKHAUL_ID";
	/**
	 * Scalar constant for return column BACKHAUL_TYPE_NAME. 
	 */
	public static final String SEARCH_BACKHAUL_TYPE_NAME = "BACKHAUL_TYPE_NAME";
	/**
	 * Scalar constant for return column BACKHAUL_TYPE_NAME. 
	 */
	public static final String SEARCH_BACKHAUL_TYPE_ID = "BACKHAUL_TYPE_ID";
	/**
	 * Scalar constant for return column DATA_CENTER_ID.
	 */
	public static final String SEARCH_DATA_CENTER_ID = "DATA_CENTER_ID";
	/**
	 * Scalar constant for return column DATA_CENTER_ID.
	 */
	public static final String SEARCH_DATA_CENTER_NAME = "DATA_CENTER_NAME";
	/**
	 * Scalar constant for return column BACKHAUL_DISPLAY_ID.
	 */
	public static final String SEARCH_BACKHAUL_DISPLAY_ID = "BACKHAUL_DISPLAY_ID";
	/**
	 * Scalar constant for return column CREATED_ON.
	 */
	public static final String SEARCH_CREATED_ON = "CREATED_ON";
	/**
	 * Scalar constant for return column PDP_ID.
	 */
	public static final String PDP_ID = "PDP_ID";
	/**
	 * Scalar constant for return column DOMAIN_NAME.
	 */
	public static final String DOMAIN_NAME ="DOMAIN_NAME";
	/**
	 * Scalar constant for return column ORDER_SUBMITTER.
	 */
	public static final String ORDER_SUBMITTER = "ORDER_SUBMITTER";
	/**
	 * Scalar constant for return column DAPN_ID.
	 */
	public static final String DAPN_ID = "DAPN_ID";
	/**
	 * Scalar constant for return column DAPN_STATUS.
	 */
	public static final String DAPN_STATUS = "DAPN_STATUS";
	/**
	 * Scalar constant for return column APN_TYPE.
	 */
	public static final String APN_TYPE = "APN_TYPE";
	/**
	 * Scalar constant for return column APN_SIZE.
	 */
	public static final String APN_SIZE = "APN_SIZE";
	/**
	 * Scalar constant for return column UD_PDPID.
	 */
	public static final String UD_PDPID = "UD_PDPID";
	/**
	 * Scalar constant for return column MOBILE_IP.
	 */
	public static final String MOBILE_IP = "MOBILE_IP";
	/**
	 * Scalar constant for return column DATA_CENTER_NAME.
	 */
	public static final String SEARCH_DAPN_DATA_CENTER_NAME = "DATA_CENTER_NAME";
	/**
	 * Scalar constant for return column BATCH_ID.
	 */
	public static final String BATCH_ID = "BATCH_ID";

	/**
	 * Scalar constant for return column OWNER. Used to get result
	 * of returned column by native sql.
	 */
	public static final String OWNER = "owner";

	/**
	 * Scalar constant for return column SHARED_STATUS. Used to get result
	 * of returned column by native sql.
	 */
	public static final String SHARED_STATUS = "shared_status";

	/**
	 * Scalar constant for return column data_center_id. Used to get result of
	 * returned column by native sql.
	 */
	public static final String IMSI_MSISDN = "imsi_msisdn";
	public static final String IMSI_MSISDN2 = "imsi_msisdn2";

	/**
	 * Scalar constants for Billing tab query
	 */
	public static final String order_id = "order_id";
	public static final String biling_task_id = "biling_task_id";
	public static final String previous_biling_task_id = "previous_biling_task_id";
	public static final String date_in_production = "date_in_production";
	public static final String order_type = "order_type";
	public static final String order_status = "order_status";
	public static final String account_class = "account_class";
	public static final String federal_tax_id = "federal_tax_id";
	public static final String master_account_name = "master_account_name";
	public static final String account_name = "account_name";
	public static final String expediteValue = "expediteValue";
	public static final String fan_id = "fan_id";
	public static final String ban_id = "ban_id";
	public static final String eod = "eod";
	public static final String eod_blu = "eod_blu";
	public static final String managed_avpn = "managed_avpn";
	public static final String apn_name = "apn_name";
	public static final String pdp_name = "pdp_name";
	public static final String backhaul_types = "backhaul_types";
	public static final String new_backhaul_instance = "new_backhaul_instance";
	public static final String existing_backhaul_instance = "existing_backhaul_instance";
	public static final String source_ip_addressing = "source_ip_addressing";
	public static final String type_addressing = "type_addressing";
	public static final String date_bill_setup_status = "date_bill_setup_status";
	public static final String fee_waivers = "fee_waivers";		
	public static final String contact_name = "contact_name";
	public static final String contact_phone = "contact_phone";
	public static final String sales_contact = "sales_contact";
	public static final String account_manager = "account_manager";
	public static final String os = "os";
	public static final String oa = "oa";
	public static final String date_submitted = "date_submitted";
	public static final String date_oa_approved = "date_oa_approved";
	public static final String billing_date_complete = "billing_date_complete";
	public static final String company_billing_address = "company_billing_address";
	public static final String ctn_sim = "ctn_sim";

	/**
	 * Scalar constants for VlanGi query
	 */
	public static final String vlan_gi= "vlan_gi";

	/**
	 * Scalar constants for RD_RT query
	 */
	public static final String rd_rt= "rd_rt";
	public static final String gateway_sgi_context= "gateway_sgi_context";
	public static final String in_out_interface= "in_out_interface";

	public static final String OCS = "OCS";

	/**
	 * 
	 */
	public static final String MOBILE_POOL_IP= "MOBILE_POOL_IP";
	public static final String NAS_CLIENT_IP= "NAS_CLIENT_IP";
	public static final String ENT_TARGET_IP_RANGE= "ENT_TARGET_IP_RANGE";
	public static final String APN_CUSTOMER_RADIUS= "APN_CUSTOMER_RADIUS";

	public static final String order_type_id = "order_type_id";

	public static final String derived_from_order = "derived_from_order";

	public static final String updated_by = "updated_by";

	public static final String updated_on = "updated_on";

	public static final String comments = "comments";

	public static final String order_status_name = "order_status_name";

	public static final String created_by = "created_by";

	public static final String created_on = "created_on";
	
	public static final String submitted_on = "submitted_on";

	public static final String orderType = "order_type_id";

	public static final String ROLE_ID = "ROLE_ID";

	public static final String ORDER_PROCESS = "ORDER_PROCESS";

	public static final String USER_ACTION  ="USER_ACTION";

	public final static String PDP_PACKAGE_ID = "pdp_package_id";

	public final static String PDP_PACKAGE_DESCRIPTION = "pdp_package_description";
	
	public static final String ADMIN_CATEGORY_ID = "ADMIN_CATEGORY_ID";
	
	public static final String CATEGORY_VALUE = "CATEGORY_VALUE";
	
	public static final String TASK_ID = "TASK_ID";
	
	public static final String TASK_NAME = "TASK_NAME";
	
	public static final String TASK_DISPLAYNAME = "TASK_DISPLAYNAME";
	
	public static final String TASK_SUBJECT = "SUBJECT";
	
	public static final String CREATION_DATE = "CREATION_DATE";
	
	public static final String TASK_STATUS = "TASK_STATUS";
	
	public static final String TASK_ATTUID = "ATTUID";
	
	public static final String EXPEDITE = "EXPEDITE";
	
	public static final String OPEN_REMINDER = "OPEN_REMINDER";
	
	public static final String COMPLETION_DATE = "COMPLETION_DATE";
	
	public static final String ACCOUNT_NAME = "ACCOUNT_NAME";
	
	public static final String BPM_TASK_ID = "BPM_TASK_ID";
	
	public static final String TASK_STATUS_ID = "TASK_STATUS_ID";
	
	public static final String TASK_TYPE = "TASK_TYPE";

}