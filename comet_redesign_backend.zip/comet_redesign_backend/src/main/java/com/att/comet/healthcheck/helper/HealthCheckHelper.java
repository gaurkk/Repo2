package com.att.comet.healthcheck.helper;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.BPMException;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BPMBusinessOrderStepBO;
import com.att.comet.common.modal.OrderTypeEnum;
import com.att.comet.common.service.MessageConfigService;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.configuration.ApplicationConfig;
import com.att.comet.configuration.CamundaConfig;
import com.att.comet.dao.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.dao.hibernate.bean.Orders;
import com.att.comet.order.dao.OrderConstants;
import com.att.comet.order.dao.OrderDAO;
import com.att.comet.order.operation.modal.OperationResponseBO;
import com.att.comet.order.repository.OrderEventRepository;
import com.att.comet.order.repository.OrderRepository;
import com.att.comet.order.service.OrderService;
import com.att.comet.order.task.modal.BpmTaskFieldDataBO;
import com.att.comet.order.task.repository.OrderUserBpmTasksRepository;

@Component
public class HealthCheckHelper {
	private static final Logger logger = LoggerFactory.getLogger(HealthCheckHelper.class);
	@Autowired
	OrderDAO orderDAO;	
	@Autowired
	OrderService orderService;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ApplicationConfig applicationConfig;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	MessageConfigService  messageConfig;
	
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	
	@Autowired
	OrderEventRepository orderEventRepository;

	private String CAMMUNDA_SERVICE_URL;
	
	private String BPM_BASE_URL;
	
	private final String TASK = "/task";
	
	public void getOrdersMainWorkFlow(Long orderId) throws CometDataException, CometServiceException {
		logger.info("Starting method getOrdersMainWorkFlow", this);
		Orders orders = orderDAO.findByOrderId(orderId);
		Long count = orderEventRepository.getEventCount(orderId);
		//CR count for order .
		if (orders.getOrderType().getOrderTypeId().equals(1001L) && count.equals(0L)) {
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "NEW_ORDER");
		}
		if (orders.getOrderType().getOrderTypeId().equals(1002L)) {
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "CANCEL_ORDER");
		}
		if (orders.getOrderType().getOrderTypeId().equals(1003L)) {
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "EXPEDITE_ORDER");
		}
		if (orders.getOrderType().getOrderTypeId().equals(1004L)) {
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "CHANGE_ORDER");
		}
		if (orders.getOrderType().getOrderTypeId().equals(1001L) && null!=count && !count.equals(0L)) {
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "CHANGE_REQUEST");
		}
		if (orders.getOrderType().getOrderTypeId().equals(1006L)) { ///check for CR count 
			// always need to run the MAIN PROCESS FLOW TO TRIGGER ORDER APPROVAL
			orderMainBPMFlowRequest(orderId, "DECOMMISSION_ORDER");
		}
		logger.info("End method getOrdersMainWorkFlow", this);
	}
	
	private void orderMainBPMFlowRequest(Long orderId , String orderType) {
		logger.info("Starting methode orderMainBPMFlowRequest. for ORDER_ID::"+orderId+" AND ORDER TYPE::"+orderType,this); 
		OperationResponseBO operationBO = new OperationResponseBO();
		CAMMUNDA_SERVICE_URL =applicationConfig.getCamundaRestUrl();
		String relativeUrl = createRelativeUrl();
		logger.info("CAMMUNDA SERVICE URL : "+CAMMUNDA_SERVICE_URL, this);
		String requestUri = CAMMUNDA_SERVICE_URL.concat(relativeUrl);
		logger.info("requestUri="+requestUri, this);
		JSONObject jsonRequest = createJsonRequest(orderId, orderType);
		try {
			operationBO = processOperationService(requestUri, jsonRequest, orderId);
		} catch (CometDataException e) {
			logger.error("Issue on OPeration.orderId="+orderId,this);
		}
		if(null!=operationBO) {
			logger.info("MAIN FLOW Order Approval CREATED for orderId:="+orderId+" Status::"+operationBO.getStatus(), this);
			logger.info("MAIN FLOW Order Approval CREATED for orderId:="+orderId+" Message::"+operationBO.getMessage(), this);
		}
		
	}
	
	//OA Approval for ALL TYPE OF ORDER 
	public void processWorkFLowForOAApproval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException {
		logger.info("STARTING processWorkFLowForOAApproval :: OrderId="+ orderId , this);	
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1010 OA approval // NEW ,Change order				
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L)) {// order TYPE NEW
					logger.info("MIGRATION for OA Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OA Approval :: OrderType=" + bo.getOrderTypeId().toString(), this);
					// OA
					if (bo.getBusinessStepId() == 3001L) {
						if(oaApproval_1010(orderId,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for OA Approval failure :: OrderId=" + orderId+"oaApproval_1010", this);	
						}
					}
				}
				// OA TASK ID 1033   Expidite order type
				if (bo.getOrderTypeId().equals(1003L)) {// order TYPE Exidite
					logger.info("MIGRATION for OA Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OA Approval :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					// OA
					if (bo.getBusinessStepId() == 3171L) {
						if(oaApproval_1033(orderId,bo.getOrderTypeId(),bo)) {
							break ;
						}else {
							logger.info("MIGRATION for OA Approval failure :: OrderId=" + orderId+"oaApproval_1033", this);	
						}
					}
				}
				//OA TASK ID Cancel Order Type
				if (bo.getOrderTypeId().equals(1002L)) {// order TYPE cancel order
					logger.info("MIGRATION for OA Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OA Approval :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					// OA
					if (bo.getBusinessStepId() == 3179L) {
					if(oaApproval_1037(orderId,bo.getOrderTypeId(),bo)) {
						break ;
					}else {
						logger.info("MIGRATION for OA Approval failure :: OrderId=" + orderId+"oaApproval_1037", this);
					}
					}
				}
				
				//OA TASK ID Change Request Type
				if (bo.getOrderTypeId().equals(1001L) && !count.equals(0L)) {// order TYPE Change Request
					logger.info("MIGRATION for OA Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OA Approval :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					// OA
					if (bo.getBusinessStepId() == 3179L) {
						if(oaApproval_1028(orderId,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for OA Approval failure :: OrderId=" + orderId+"oaApproval_1028", this);	
						}
					}
				}
				
				
			}
		}
		logger.info("END processWorkFLowForOAApproval :: OrderId="+ orderId , this);	
	}
	
	private boolean oaApproval_1028(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
		logger.info("oaApproval_1028 ::OA Approval OrderId=" + orderId, this);
		Long taskId =1028L;
		Long statusId=1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1028L)) {
				
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END oaApproval_1028  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END oaApproval_1028  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END oaApproval_1028 not save :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OA APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END oaApproval_1037  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
	
	}

	private boolean oaApproval_1037(Long orderId , Long orderType, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
	logger.info("oaApproval_1037 ::OA Approval OrderId=" + orderId, this);
	Long taskId =1037L;
	Long statusId=1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1037L)) {
				
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END oaApproval_1037  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END oaApproval_1037  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END oaApproval_1037  not save:: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OA APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END oaApproval_1037  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
	
	}
	
	private boolean oaApproval_1033(Long orderId , Long orderType, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {

		logger.info("oaApproval_1033 ::OA Approval OrderId=" + orderId, this);
		Long taskId =1033L;
		Long statusId=1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
				if (orderUserBpmTask.getBpmTask().getTaskId().equals(1033L)) {
				
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END oaApproval_1033  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END oaApproval_1033  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END oaApproval_1033 not save :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OA APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END oaApproval_1033  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
	}
	
	private boolean oaApproval_1010(Long orderId , Long orderType, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {

		logger.info("oaApproval_1010 ::OA Approval OrderId=" + orderId, this);
		Long taskId =1010L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1010L)) {
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END oaApproval_1010  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END oaApproval_1010  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.error(" oaApproval_1010 process no save  :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OA APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END oaApproval_1010  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
	}
	
	//OM Approval for all order 
	public void processWorkFlowForOMApproval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException {
		logger.info("STARTING processWorkFlowForOMApproval :: OrderId="+ orderId , this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1011 OM approval // NEW ,Change order,change request				
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for OM Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OM Approval :: OrderType=" + bo.getOrderTypeId().toString(), this);
					// OA
					if (bo.getBusinessStepId() == 3002L) {
						if(omApproval_1011(orderId,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for OM Approval failure:: OrderId=" + orderId +"omApproval_1011", this);	
						}
					}
				}
				//TASK ID 1034 OM approval Expidite				
				if (bo.getOrderTypeId().equals(1003L) ) {
					logger.info("MIGRATION for OM Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OM Approval :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					// OA
					if (bo.getBusinessStepId() == 3120L) {
						if(omApproval_1034(orderId,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for OM Approval failure:: OrderId=" + orderId +"omApproval_1034", this);	
						}
					}
				}
				//TASK ID 1011 OM approval Decommision				
				if (bo.getOrderTypeId().equals(1006L) ) {
					logger.info("MIGRATION for OM Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for OM Approval :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					// OA
					if (bo.getBusinessStepId() == 3140L) {
						if(omApproval_1045(orderId,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for OM Approval failure:: OrderId=" + orderId +"omApproval_1045", this);	
						}
					}
				}
			}
		}
		logger.info("END processWorkFlowForOMApproval :: OrderId="+ orderId , this);
	}
	
	private boolean omApproval_1011(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
		logger.info("omApproval_1011 ::OM Approval OrderId=" + orderId, this);
		Long taskId =1011L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1011L)) {
				
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
						if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
							
							String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
							Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
									bpmTaskFieldDataBO);
							ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
									taskVariablesMap, String.class);
							if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
								logger.info("Successfully completed the task ID: " + bpmtaskId);
								logger.info("END omApproval_1011  :: OrderId=" + orderId, this);
								return  true;
							} else if (500 == response.getStatusCodeValue()
									|| 400 == response.getStatusCodeValue()) {
								logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
								logger.info("END omApproval_1011  :: OrderId=" + orderId, this);
								return false;
							}
						}else {
							logger.info("END omApproval_1011 is not save :: OrderId=" + orderId, this);
						}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OM APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END omApproval_1011  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
		
	}

	private boolean omApproval_1034(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
		logger.info("omApproval_1034 ::OM Approval OrderId=" + orderId, this);
		Long taskId =1034L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1034L)) {
				
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END omApproval_1034  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END omApproval_1034  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END omApproval_1034 no save :: OrderId=" + orderId, this);	
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OM APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END omApproval_1034  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
		
		
	}

	private boolean omApproval_1045(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
		logger.info("omApproval_1045 ::OM Approval OrderId=" + orderId, this);
		Long taskId =1045L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1045L)) {
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					bpmTaskFieldDataBO.setResponse("Approved");
					bpmTaskFieldDataBO.setComments(bo.getComments());
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END omApproval_1045  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END omApproval_1045  :: OrderId=" + orderId, this);
							return false;
						}
					}
					else {
						logger.info("END omApproval_1045 is not save :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON PROCESSING OM APPROVAL  :: OrderId=" + orderId, this);
					logger.info("END omApproval_1045  :: OrderId=" + orderId, this);
					return false;
				}
			}
		}
		return false;
		
	}

	private String createRelativeUrl() {
		logger.info("Starting methode relativeUrl.",this); 
		StringBuilder relativeUrl = null;
			relativeUrl = new StringBuilder(CometCommonConstant.FORWARD_SLASH);
			relativeUrl.append(CometCommonConstant.P_MAINBUSINESSPROCESS).append(CometCommonConstant.FORWARD_SLASH);
			relativeUrl.append(CometCommonConstant.START);
		logger.info("Exiting methode relativeUrl.",this);
		return relativeUrl.toString();
	}
	
	private JSONObject createJsonRequest(Long orderId,String orderType) {
		logger.info("Starting methode createJsonRequest.",this);
		try {
			JSONObject orderOperationValue = new JSONObject();
			orderOperationValue.put("value", orderType);
			orderOperationValue.put("type", "String");

			JSONObject orderIdValue = new JSONObject();
			orderIdValue.put("value", orderId.toString());
			orderIdValue.put("type", "Long");

			JSONObject orderValue = new JSONObject();
			orderValue.put("orderOperation", orderOperationValue);
			orderValue.put("orderId", orderIdValue);

			JSONObject variableValue = new JSONObject();
			variableValue.put("variables", orderValue);
			variableValue.put("businessKey", orderId.toString());
			return variableValue;
		}catch(Exception e) { 
			logger.debug("Create Json Request : " + e.getMessage(), e);
		}
		logger.info("Exiting methode createJsonRequest.",this);
		return null;
	}
	private OperationResponseBO processOperationService(String requestUri, JSONObject jsonRequest, Long orderId) throws CometDataException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method processSubmitService : ", this);
		OperationResponseBO operationresponseBO = new OperationResponseBO();
		try {
			URI uri = new URI(requestUri);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request =  new HttpEntity<String>(jsonRequest.toString(), headers);
			logger.info("jsonRequest::"+jsonRequest);
			logger.info("URL::"+uri, this);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, request, String.class);
			logger.info("Response code from BPM 1 : "+response.getBody());
			logger.info("Response code from BPM : "+response.getStatusCodeValue());

			operationresponseBO = createOperationBO(String.valueOf(response.getStatusCodeValue()),orderId);

		} catch (HttpStatusCodeException  e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + e.getRawStatusCode());
			logger.debug("URISyntaxException during URI generate for URL : " + e.getMessage());
			operationresponseBO = createOperationBO(String.valueOf(e.getRawStatusCode()),orderId);
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks: " + e.getMessage());
			operationresponseBO = createOperationBO("599",orderId);
		} catch (Exception e) {
			logger.debug("error : " + e.getMessage(), e);
			operationresponseBO = createOperationBO("599",orderId);
		}

		logger.info("Exiting methode processOperationService.",this);
		return operationresponseBO;
	}
	
	private OperationResponseBO createOperationBO(String errorCode,Long orderId) {
		OperationResponseBO operationresponseBO = new OperationResponseBO();
		String statusAndErrorCode = messageConfig.properties().getProperty("errors.and.success.operation.http.bpm.statuscodes");
		String message = messageConfig.properties().getProperty("errors.operation.http.bpm.message");
		
	    HashMap<String, String> hashMap = (HashMap<String, String>) Arrays.asList(statusAndErrorCode.split(",")).stream().map(s -> s.split(":")).collect(Collectors.toMap(e -> e[0], e -> e[1]));
			
		if(hashMap.containsKey(errorCode)) {
			operationresponseBO.setCode(errorCode);
			if(hashMap.get(errorCode).equalsIgnoreCase("SUCCESS")) {
				operationresponseBO.setMessage(hashMap.get(errorCode));
				operationresponseBO.setStatus("Success");
			}else {
				operationresponseBO.setMessage("("+hashMap.get(errorCode)+") ".concat(message.replaceAll("0", orderId.toString())));
				operationresponseBO.setStatus("Failed");
			}
		}else {
			operationresponseBO.setCode(hashMap.get(errorCode));
			operationresponseBO.setMessage("(Comet_BPM000) ".concat(message.replaceAll("0", orderId.toString())));
			operationresponseBO.setStatus("Failed");
		}
		return operationresponseBO;
	}

	private Map<String, Object> prepareProcessVariablesForTaskCompletion(BpmTaskFieldDataBO bpmTaskFieldDataBO) throws CometException {
		if (null == bpmTaskFieldDataBO) {
			throw new CometException("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- Invalid task field data");
		}
		
		logger.info("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- Start");
		
		Map<String, Object> dataMap = null;
		Map<String, Object> inputMap = new HashMap<String, Object>();
		Map<String, Object> variablesMap = new HashMap<String, Object>();
		
		if (null != bpmTaskFieldDataBO.getComments()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getComments());
			dataMap.put("type", "String");
			inputMap.put("comments", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketNum()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTicketNum());
			dataMap.put("type", "String");
			inputMap.put("ticketNum", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketCreateDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTicketCreateDate());
			dataMap.put("type", "String");
			inputMap.put("ticketCreateDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuRescheduleDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuRescheduleDateTime());
			dataMap.put("type", "String");
			inputMap.put("ttuRescheduleDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getReasonForReschedule()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getReasonForReschedule());
			dataMap.put("type", "String");
			inputMap.put("reasonForReschedule", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getResponse()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getResponse());
			dataMap.put("type", "String");
			inputMap.put("response", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getCompletedDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getCompletedDate());
			dataMap.put("type", "String");
			inputMap.put("completedDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getApnIWOSbuildConfirmation()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getApnIWOSbuildConfirmation());
			dataMap.put("type", "String");
			inputMap.put("apnIWOSbuildConfirmation", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getIsPreFlightTestOccurred()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getIsPreFlightTestOccurred());
			dataMap.put("type", "String");
			inputMap.put("isPreFlightTestOccurred", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingResult()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getPreFlightTestingResult());
			dataMap.put("type", "String");
			inputMap.put("preFlightTestingResult", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getPreFlightTestingDateTime());
			dataMap.put("type", "String");
			inputMap.put("preFlightTestingDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getIsTTURequired()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getIsTTURequired());
			dataMap.put("type", "String");
			inputMap.put("isTTURequired", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuScheduleDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuScheduleDateTime());
			dataMap.put("type", "String");
			inputMap.put("ttuScheduleDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder());
			dataMap.put("type", "String");
			inputMap.put("ttuIsPerformedForTheOrder", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuResult()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuResult());
			dataMap.put("type", "String");
			inputMap.put("ttuResult", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber());
			dataMap.put("type", "String");
			inputMap.put("securityEngrIwosTicketNumber", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate());
			dataMap.put("type", "String");
			inputMap.put("proposedExpediteBuildCompletionDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate());
			dataMap.put("type", "String");
			inputMap.put("finalExpediteBuildCompletionDate", dataMap);
		}
		
		variablesMap.put("variables", inputMap);
		
		logger.info("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- End");
		return variablesMap;
	}

	
	//3007L IWOS NETWORK CREATION Approval for All Order
	public void processWorkFlowForIWOS_Network_Creation_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException {
		logger.info("STARTING processWorkFlowForIWOS_Network_Creation_Approval :: OrderId="+ orderId , this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for IWOS network creation  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for IWOS network creation :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3007L) {
						if(iwosApproval_1016(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
						logger.info("MIGRATION for IWOS network creation  Approval  failure :: OrderId=" + orderId, this);		
						}
						
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowForIWOS_Network_Creation_Approval :: OrderId="+ orderId , this);
	}

	private boolean iwosApproval_1016(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
		logger.info("Starting iwosApproval_1016 ::IWOS Network creation Approval OrderId=" + orderId, this);
		Long taskId =1016L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1016L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepExecutedOn().toString()) {
					bpmTaskFieldDataBO.setTicketCreateDate(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
					}else {
						logger.error("IWOS Network creation Approval date is null for  OrderId=" + orderId, this);	
					}if(null!=bo.getBusinessStepValue()) {
						bpmTaskFieldDataBO.setTicketNum(bo.getBusinessStepValue());
					}else {
						logger.error("IWOS Network creation Approval Ticket Num is null for  OrderId=" + orderId, this);
					}
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("IWOS Network creation Approval Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END iwosApproval_1016  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON iwos Network Creation Approval_1016  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END iwosApproval_1016 save failure :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON iwos Network Creation Approval_1016:: OrderId=" + orderId, this);
					logger.info("END ON iwos Network Creation Approval_1016  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End iwosApproval_1016 ::IWOS Network creation Approval OrderId=" + orderId, this);
		return false;
	}
	
	//ITOS creation NEW as of now , need to revist for CR /CO
	public void processWorkFlowForITOPS_Creation_Approval(Long orderId)throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException {
		logger.info("STARTING processWorkFlowForITOPS_Creation_Approval :: OrderId="+ orderId , this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L)) {
					logger.info("MIGRATION for ITOPS creation  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for IWOPS creation :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3005L) {
						if(itopsApproval_1021(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}
						else {
						logger.info("MIGRATION for ITOPS creation  Approval failure:: OrderId=" + orderId, this);	
						}
					}
				}
			}
		}
		
		logger.info("END processWorkFlowForITOPS_Creation_Approval :: OrderId="+ orderId , this);
	}

	private boolean itopsApproval_1021(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
		logger.info("Starting itopsApproval_1021 ::ITOPS creation Approval OrderId=" + orderId, this);
		Long taskId =1021L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1021L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepExecutedOn().toString()) {
						
					bpmTaskFieldDataBO.setCompletedDate(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
					}else {
						logger.error("ITOPS  creation Approval date is null for  OrderId=" + orderId, this);	
					}
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("ITOPS  creation Approval Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END itopsApproval_1021  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON iwos Network Creation Approval_1016  :: OrderId=" + orderId, this);
							return false;
						}
					} else {
						logger.info("END itopsApproval_1021 not save :: OrderId=" + orderId, this);	
					}
				
				} catch (CometException e) {
					logger.info("ISSUE ON itopsApproval_1021 :: OrderId=" + orderId, this);
					logger.info("END itopsApproval_1021  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("Starting itopsApproval_1021 ::ITOPS creation Approval OrderId=" + orderId, this);
		return false;
	}

	
	//APN_HLR Creation Approval 
	public void processWorkFlowForAPN_HLR_Creation_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException{
		logger.info("Starting processWorkFlowForAPN_HLR_Creation_Approval :: OrderId="+ orderId , this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for APN_HLR_Creation  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for APN_HLR_Creation creation :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3142L) {
						if(apnHLRCreationApproval_1060(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for APN_HLR_Creation  Approval Failure :: OrderId=" + orderId, this);	
						}
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowForAPN_HLR_Creation_Approval :: OrderId="+ orderId , this);
		
	}

	private boolean apnHLRCreationApproval_1060(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {

		logger.info("Starting apnHLRCreationApproval_1060 ::APN HLR Creation Approval OrderId=" + orderId, this);
		Long taskId =1060L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1060L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepExecutedOn().toString()) {
					bpmTaskFieldDataBO.setTicketCreateDate(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
					}else {
						logger.error("apnHLRCreationApproval_1060 date is null for  OrderId=" + orderId, this);	
					}if(null!=bo.getBusinessStepValue()) {
						bpmTaskFieldDataBO.setTicketNum(bo.getBusinessStepValue());
					}else {
						logger.error("apnHLRCreationApproval_1060  Ticket Num is null for  OrderId=" + orderId, this);
					}
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("apnHLRCreationApproval_1060 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END apnHLRCreationApproval_1060   :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON apnHLRCreationApproval_1060   :: OrderId=" + orderId, this);
							return false;
						}	
					}else {
						logger.info("END apnHLRCreationApproval_1060 not save  :: OrderId=" + orderId, this);
					}
					
					
				} catch (CometException e) {
					logger.info("ISSUE ON apnHLRCreationApproval_1060 :: OrderId=" + orderId, this);
					logger.info("END ON apnHLRCreationApproval_1060   :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End apnHLRCreationApproval_1060 ::APN HLR Creation Approval OrderId=" + orderId, this);
		return false;
	
	}

	
	//NI order update creation Approval
	
	
	public void processWorkFlowForNI_order_update_Creation_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException {
		logger.info("Starting processWorkFlowForNI_order_update_Creation_Approval ::NI Order Update creation Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for NI ORDER  Update creation  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for NI ORDER  Update creation :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3027L) {
						if(niOrderUpdateApproval_1019(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for NI ORDER  Update creation  Approval failure:: OrderId=" + orderId, this);	
						}
							
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowForNI_order_update_Creation_Approval ::NI Order Update creation Approval OrderId=" + orderId, this);
		
	}

	private boolean niOrderUpdateApproval_1019(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
	logger.info("Starting niOrderUpdateApproval_1019 ::niOrderUpdateApproval_1019 OrderId=" + orderId, this);
	Long taskId =1019L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1019L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepValue()) {
					bpmTaskFieldDataBO.setIsTTURequired(bo.getBusinessStepValue());
					}else {
						logger.error("niOrderUpdateApproval_1019 Business Step value  is null for  OrderId=" + orderId, this);	
					}
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("niOrderUpdateApproval_1019 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END niOrderUpdateApproval_1019  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON niOrderUpdateApproval_1019  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END niOrderUpdateApproval_1019  not saved:: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON niOrderUpdateApproval_1019 :: OrderId=" + orderId, this);
					logger.info("END ON niOrderUpdateApproval_1019  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End niOrderUpdateApproval_1019 ::niOrderUpdateApproval_1019 OrderId=" + orderId, this);
		return false;
	
	
	}

	
	//billing task creation approval
	public void processWorkFlowBilling_task_Creation_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException{
		logger.info("Starting processWorkFlowBilling_task_Creation_Approval ::Billing task creation Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for Billing task creation  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for  Billing task  creation :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3023L) {
						if(billingTaskApproval_1020(orderId ,bo.getOrderTypeId(),bo)){
							break;
						}else {
							logger.info("MIGRATION for Billing task creation  Approval failure:: OrderId=" + orderId, this);
						}
							
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowBilling_task_Creation_Approval ::Billing task creation Approval OrderId=" + orderId, this);
		
	}

	private boolean billingTaskApproval_1020(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
		logger.info("Starting billingTaskApproval_1020 ::billingTaskApproval_1020 OrderId=" + orderId, this);
		Long taskId =1020L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
				if (orderUserBpmTask.getBpmTask().getTaskId().equals(1020L)) {
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					try {
						BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
						if(null!=bo.getComments()) {
							bpmTaskFieldDataBO.setComments(bo.getComments());
						}else {
							logger.error("billingTaskApproval_1020 Ticket Comment is null for  OrderId=" + orderId, this);	
						}
						if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
							String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
							Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
									bpmTaskFieldDataBO);
							ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
									taskVariablesMap, String.class);
							if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
								logger.info("Successfully completed the task ID: " + bpmtaskId);
								logger.info("END billingTaskApproval_1020  :: OrderId=" + orderId, this);
								return  true;
							} else if (500 == response.getStatusCodeValue()
									|| 400 == response.getStatusCodeValue()) {
								logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
								logger.info("END ON billingTaskApproval_1020  :: OrderId=" + orderId, this);
								return false;
							}
						}else {
							logger.info("END billingTaskApproval_1020 not saved  :: OrderId=" + orderId, this);
						}
						
					} catch (CometException e) {
						logger.info("ISSUE ON billingTaskApproval_1020 :: OrderId=" + orderId, this);
						logger.info("END ON billingTaskApproval_1020  :: OrderId=" + orderId, this);
						return false;
					}
					
				}
			}
		
			logger.info("End billingTaskApproval_1020 ::billingTaskApproval_1020 OrderId=" + orderId, this);
			return false;
		}


	//ITOPS completion date approval 
	public void processWorkFlowIWOS_network_compeletion_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException{
		logger.info("Starting processWorkFlowIWOS_network_compeletion_Approval ::IWOS_network_compeletion Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for IWOS_network_compeletion  Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION for IWOS_network_compeletion :: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3027L) {
						if(itopsCompeletionApproval_1017(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for IWOS_network_compeletion  Approval failure:: OrderId=" + orderId, this);
						}
							
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowIWOS_network_compeletion_Approval ::IWOS_network_compeletion Approval OrderId=" + orderId, this);
		
	}

	private boolean itopsCompeletionApproval_1017(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
	logger.info("Starting itopsCompeletionApproval_1017 ::itopsCompeletionApproval_1017 OrderId=" + orderId, this);
	Long taskId =1017L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1017L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
			try {
				BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
				
				if(null!=bo.getComments()) {
					bpmTaskFieldDataBO.setComments(bo.getComments());
				}else {
					logger.error("itopsCompeletionApproval_1017 Ticket Comment is null for  OrderId=" + orderId, this);	
				}
				if(null!=bo.getBusinessStepExecutedOn()) {
					bpmTaskFieldDataBO.setCompletedDate(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
				}else {
					logger.error("itopsCompeletionApproval_1017 Ticket date is null for  OrderId=" + orderId, this);	
				}
				if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
					String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
					Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
							bpmTaskFieldDataBO);
					ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
							taskVariablesMap, String.class);
					if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
						logger.info("Successfully completed the task ID: " + bpmtaskId);
						logger.info("END itopsCompeletionApproval_1017  :: OrderId=" + orderId, this);
						return  true;
					} else if (500 == response.getStatusCodeValue()
							|| 400 == response.getStatusCodeValue()) {
						logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
						logger.info("END ON itopsCompeletionApproval_1017  :: OrderId=" + orderId, this);
						return false;
					}
				}else {
					logger.info("END itopsCompeletionApproval_1017  not saved:: OrderId=" + orderId, this);
				}
				
				} catch (CometException e) {
					logger.info("ISSUE ON itopsCompeletionApproval_1017 :: OrderId=" + orderId, this);
					logger.info("END ON itopsCompeletionApproval_1017  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End itopsCompeletionApproval_1017 ::itopsCompeletionApproval_1017 OrderId=" + orderId, this);
		return false;
	
	
	}

	
	

		
//APN_HLR_Completion
	public void processWorkFlowAPN_HLR_Completion_Approval(Long orderId)  throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException{
		logger.info("Starting processWorkFlowAPN_HLR_Completion_Approval ::processWorkFlowAPN_HLR_Completion_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//niOrderCompletionApproval_1015
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowAPN_HLR_Completion_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowAPN_HLR_Completion_Approval :: OrderType=" + bo.getOrderTypeId().toString(), this);
					if (bo.getBusinessStepId() == 3143L) {
						if(APN_HLRCompletionApproval_1015(orderId ,bo.getOrderTypeId(),bo)) {
							break;
							}
						else {
							logger.info("MIGRATION for processWorkFlowAPN_HLR_Completion_Approval failure:: OrderId=" + orderId, this);
						}
					}
					
				}
				
			}
		}
		logger.info("End processWorkFlowAPN_HLR_Completion_Approval ::processWorkFlowAPN_HLR_Completion_Approval OrderId=" + orderId, this);
		
	}
	
	private boolean APN_HLRCompletionApproval_1015(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
		logger.info("Starting APN_HLRCompletionApproval_1015 ::APN_HLRCompletionApproval_1015 OrderId=" + orderId, this);
		Long taskId =1015L;
		Long statusId =1001L;
		OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
		if (null!=orderUserBpmTask) {
				if (orderUserBpmTask.getBpmTask().getTaskId().equals(1015L)) {
					String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
					try {
						BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
						if(null!=bo.getBusinessStepValue()) {
						bpmTaskFieldDataBO.setResponse(bo.getBusinessStepValue());
						}else {
							logger.error("APN_HLRCompletionApproval_1015 Business Step value  is null for  OrderId=" + orderId, this);	
						}
						if(null!=bo.getComments()) {
							bpmTaskFieldDataBO.setComments(bo.getComments());
						}else {
							logger.error("APN_HLRCompletionApproval_1015 Ticket Comment is null for  OrderId=" + orderId, this);	
						}
						if(null!=bo.getBusinessStepExecutedOn()) {
							bpmTaskFieldDataBO.setCompletedDate(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
						}else {
							logger.error("APN_HLRCompletionApproval_1015 Ticket date is null for  OrderId=" + orderId, this);	
						}
						if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
							String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
							Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
									bpmTaskFieldDataBO);
							ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
									taskVariablesMap, String.class);
							if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
								logger.info("Successfully completed the task ID: " + bpmtaskId);
								logger.info("END APN_HLRCompletionApproval_1015  :: OrderId=" + orderId, this);
								return  true;
							} else if (500 == response.getStatusCodeValue()
									|| 400 == response.getStatusCodeValue()) {
								logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
								logger.info("END ON APN_HLRCompletionApproval_1015  :: OrderId=" + orderId, this);
								return false;
							}
						}else {
							logger.info("END APN_HLRCompletionApproval_1015 not saved :: OrderId=" + orderId, this);
						}
						
					} catch (CometException e) {
						logger.info("ISSUE ON APN_HLRCompletionApproval_1015 :: OrderId=" + orderId, this);
						logger.info("END ON APN_HLRCompletionApproval_1015  :: OrderId=" + orderId, this);
						return false;
					}
					
				}
			}
			logger.info("End APN_HLRCompletionApproval_1015 ::APN_HLRCompletionApproval_1015 OrderId=" + orderId, this);
			return false;
		
		
		}

	//TTU_Preflight_Testing_Approval
	public void processWorkFlowTTU_Preflight_Testing_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting processWorkFlowTTU_Preflight_Testing_Approval ::TTU_Preflight_Testing_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//TASK ID 1016 OA approval //New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for TTU_Preflight_Testing_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION TTU_Preflight_Testing_Approval:: OrderType=" + bo.getOrderTypeId().toString(), this);
					if (bo.getBusinessStepId() == 3025L) {
						if(TTU_Preflight_Testing_Approval_1022(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for TTU_Preflight_Testing_Approval failure:: OrderId=" + orderId, this);
						}
							
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Preflight_Testing_Approval ::TTU_Preflight_Testing_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Preflight_Testing_Approval_1022(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
	logger.info("Starting TTU_Preflight_Testing_Approval_1022 ::TTU_Preflight_Testing_Approval_1022 OrderId=" + orderId, this);
	Long taskId =1022L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1022L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepStatus()) {//yes or not
						bpmTaskFieldDataBO.setIsPreFlightTestOccurred(bo.getBusinessStepStatus());
						}else {
							logger.error("TTU_Preflight_Testing_Approval_1022 PreFlightTestOccurred  value  is null for  OrderId=" + orderId, this);	
						}
					if(null!=bo.getBusinessStepValue()) {//compelted 
					bpmTaskFieldDataBO.setPreFlightTestingResult(bo.getBusinessStepValue());
					}else {
						logger.error("TTU_Preflight_Testing_Approval_1022 PreFlightTestingResult  is null for  OrderId=" + orderId, this);	
					}
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("TTU_Preflight_Testing_Approval_1022 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(null!=bo.getBusinessStepExecutedOn()) {
						bpmTaskFieldDataBO.setPreFlightTestingDateTime(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
					}else {
						logger.error("TTU_Preflight_Testing_Approval_1022 Ticket PreFlightTestingDateTime is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END TTU_Preflight_Testing_Approval_1022  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON TTU_Preflight_Testing_Approval_1022  :: OrderId=" + orderId, this);
							return false;
						}	
					}else {
						logger.info("END TTU_Preflight_Testing_Approval_1022 not saved  :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Preflight_Testing_Approval_1022 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Preflight_Testing_Approval_1022  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End niOrderCompletionApproval_1015 ::niOrderCompletionApproval_1015 OrderId=" + orderId, this);
		return false;
	
	
	}

	//TTU Applicability 
	public void processWorkFlowTTU_Applicability_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException{
		logger.info("Starting processWorkFlowTTU_Applicability_Approval ::processWorkFlowTTU_Applicability_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowTTU_Applicability_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowTTU_Applicability_Approval:: OrderType=" + bo.getOrderTypeId().toString(), this);
					if (bo.getBusinessStepId() == 3026L) {
						if(TTU_Applicability_Approval_1023(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for processWorkFlowTTU_Applicability_Approval failure:: OrderId=" + orderId, this);
						}	
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Preflight_Testing_Approval ::TTU_Preflight_Testing_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Applicability_Approval_1023(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
	logger.info("Starting TTU_Applicability_Approval_1023 ::TTU_Applicability_Approval_1023 OrderId=" + orderId, this);
	Long taskId =1023L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1023L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepValue()) {//yes or no
						bpmTaskFieldDataBO.setIsTTURequired(bo.getBusinessStepValue());
						}else {
							logger.error("TTU_Applicability_Approval_1023 getBusinessStepStatus  value  is null for  OrderId=" + orderId, this);	
						}
					
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("TTU_Applicability_Approval_1023 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END TTU_Applicability_Approval_1023  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON TTU_Applicability_Approval_1023  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END TTU_Applicability_Approval_1023 not saved :: OrderId=" + orderId, this);
					}
					
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Applicability_Approval_1023 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Applicability_Approval_1023  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End niOrderCompletionApproval_1015 ::niOrderCompletionApproval_1015 OrderId=" + orderId, this);
		return false;
	
	
	}

	//TTU Schedule
	public void processWorkFlowTTU_Schedule_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException{
		logger.info("Starting processWorkFlowTTU_Schedule_Approval ::processWorkFlowTTU_Applicability_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowTTU_Applicability_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowTTU_Applicability_Approval:: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3032L) {
						if(TTU_Schedule_Approval_1024(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for processWorkFlowTTU_Applicability_Approval failure:: OrderId=" + orderId, this);
						}
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Schedule_Approval ::processWorkFlowTTU_Schedule_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Schedule_Approval_1024(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
	logger.info("Starting TTU_Schedule_Approval_1024 ::TTU_Schedule_Approval_1024 OrderId=" + orderId, this);
	Long taskId =1024L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1024L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
			try {
				BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
				if(null!=bo.getBusinessStepExecutedOn()) {
					bpmTaskFieldDataBO.setTtuScheduleDateTime(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
				}else {
					logger.error("TTU_Schedule_Approval_1024 Ticket date is null for  OrderId=" + orderId, this);	
				}
				
				if(null!=bo.getComments()) {
					bpmTaskFieldDataBO.setComments(bo.getComments());
				}else {
					logger.error("TTU_Schedule_Approval_1024 Ticket Comment is null for  OrderId=" + orderId, this);	
				}
				
				if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
					String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
					Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
							bpmTaskFieldDataBO);
					ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
							taskVariablesMap, String.class);
					if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
						logger.info("Successfully completed the task ID: " + bpmtaskId);
						logger.info("END TTU_Schedule_Approval_1024  :: OrderId=" + orderId, this);
						return  true;
					} else if (500 == response.getStatusCodeValue()
							|| 400 == response.getStatusCodeValue()) {
						logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
						logger.info("END ON TTU_Schedule_Approval_1024  :: OrderId=" + orderId, this);
						return false;
					}	
				}else {
					logger.info("END TTU_Schedule_Approval_1024  not saved:: OrderId=" + orderId, this);
				}
				
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Schedule_Approval_1024 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Schedule_Approval_1024  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End TTU_Schedule_Approval_1024 ::TTU_Schedule_Approval_1024 OrderId=" + orderId, this);
		return false;
	
	
	}

	
	//TTU Perform status
	public void processWorkFlowTTU_Perform_Status_Approval(Long orderId)throws CometDataException, CometServiceException, RestClientException, URISyntaxException {
		logger.info("Starting processWorkFlowTTU_Perform_Status_Approval ::processWorkFlowTTU_Perform_Status_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowTTU_Perform_Status_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowTTU_Perform_Status_Approval:: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3028L) {
						if(TTU_Perform_Status_Approval_1025(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}else {
							logger.info("MIGRATION for processWorkFlowTTU_Perform_Status_Approval failure :: OrderId=" + orderId, this);
						}	
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Perform_Status_Approval ::processWorkFlowTTU_Perform_Status_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Perform_Status_Approval_1025(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
	logger.info("Starting TTU_Perform_Status_Approval_1025 ::TTU_Perform_Status_Approval_1025 OrderId=" + orderId, this);
	Long taskId =1025L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1025L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepValue()) {
						bpmTaskFieldDataBO.setTtuIsPerformedForTheOrder(bo.getBusinessStepValue());
					}else {
						logger.error("TTU_Perform_Status_Approval_1025 TtuIsPerformed is null for  OrderId=" + orderId, this);	
					}
					
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("TTU_Perform_Status_Approval_1025 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END TTU_Perform_Status_Approval_1025  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON TTU_Perform_Status_Approval_1025  :: OrderId=" + orderId, this);
							return false;
						}	
					}else {
						logger.info("END TTU_Perform_Status_Approval_1025 not saved :: OrderId=" + orderId, this);
					}
					
					
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Perform_Status_Approval_1025 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Perform_Status_Approval_1025  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End TTU_Perform_Status_Approval_1025 ::TTU_Perform_Status_Approval_1025 OrderId=" + orderId, this);
		return false;
	
	
	}

	
	//TTU Result
	public void processWorkFlowTTU_Result_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException{
		logger.info("Starting processWorkFlowTTU_Result_Approval ::processWorkFlowTTU_Result_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowTTU_Result_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowTTU_Result_Approval:: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3029L) {
						if(TTU_Result_Approval_1026(orderId ,bo.getOrderTypeId(),bo)) {
							break;
							}else {
								logger.info("MIGRATION for processWorkFlowTTU_Result_Approval failure:: OrderId=" + orderId, this);	
							}	
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Result_Approval ::processWorkFlowTTU_Result_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Result_Approval_1026(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException {
	logger.info("Starting TTU_Result_Approval_1026 ::TTU_Result_Approval_1026 OrderId=" + orderId, this);
	Long taskId =1026L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1026L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepValue()) {
						bpmTaskFieldDataBO.setTtuIsPerformedForTheOrder(bo.getBusinessStepValue());
					}else {
						logger.error("TTU_Result_Approval_1026 TtuIsPerformed is null for  OrderId=" + orderId, this);	
					}
					
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("TTU_Result_Approval_1026 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END TTU_Result_Approval_1026  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON TTU_Result_Approval_1026  :: OrderId=" + orderId, this);
							return false;
						}	
					}else {
						logger.info("END TTU_Result_Approval_1026 not saved :: OrderId=" + orderId, this);
					}
					
					
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Result_Approval_1026 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Result_Approval_1026  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End TTU_Result_Approval_1026 ::TTU_Result_Approval_1026 OrderId=" + orderId, this);
		return false;
	
	
	}

	
	//TTU_Reschedule
	public void processWorkFlowTTU_Reschedule_Approval(Long orderId) throws CometDataException, CometServiceException, RestClientException, URISyntaxException, ParseException{
		logger.info("Starting processWorkFlowTTU_Reschedule_Approval ::processWorkFlowTTU_Reschedule_Approval OrderId=" + orderId, this);
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		Long count = orderEventRepository.getEventCount(orderId);
		BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(orderId);
		if(bpmBusinessOrderStepBO != null){
			logger.debug("[OrderID : " + (orderId == null ? "" : orderId)
					+ " ] BPMBusinessOrderStepBO is set :: " ,this);
			//New , Change order , Change request 
			for (BPMBusinessOrderStepBO bo : bpmBusinessOrderStepBO) {
				//New , Change order , Change request 
				if (bo.getOrderTypeId().equals(1001L) || bo.getOrderTypeId().equals(1004L) || !count.equals(0L)) {
					logger.info("MIGRATION for processWorkFlowTTU_Reschedule_Approval :: OrderId=" + orderId, this);
					logger.info("MIGRATION processWorkFlowTTU_Reschedule_Approval:: OrderType=" + OrderTypeEnum.getEnum(bo.getOrderTypeId().toString()), this);
					if (bo.getBusinessStepId() == 3141L) {
						if(TTU_Reschedule_Approval_1027(orderId ,bo.getOrderTypeId(),bo)) {
							break;
						}	else {
							logger.info("MIGRATION for processWorkFlowTTU_Reschedule_Approval failure:: OrderId=" + orderId, this);
						}
					}
					
				}
				
			}
		}
		logger.info("Ending processWorkFlowTTU_Result_Approval ::processWorkFlowTTU_Result_Approval OrderId=" + orderId, this);
		
	}

	private boolean TTU_Reschedule_Approval_1027(Long orderId, Long orderTypeId, BPMBusinessOrderStepBO bo) throws RestClientException, URISyntaxException, ParseException {
	logger.info("Starting TTU_Reschedule_Approval_1027 ::TTU_Reschedule_Approval_1027 OrderId=" + orderId, this);
	Long taskId =1027L;
	Long statusId =1001L;
	OrderUserBpmTasks orderUserBpmTask = orderUserBpmTasksRepository.findByOrdersOrderIdAndBpmTaskTaskIdAndTaskStatusTaskStatusId(orderId,taskId,statusId);
	if (null!=orderUserBpmTask) {
			if (orderUserBpmTask.getBpmTask().getTaskId().equals(1027L)) {
				String bpmtaskId = orderUserBpmTask.getBpmTaskId().toString();// OA task
				try {
					BpmTaskFieldDataBO bpmTaskFieldDataBO = new BpmTaskFieldDataBO();
					if(null!=bo.getBusinessStepExecutedOn()) {
						bpmTaskFieldDataBO.setTtuRescheduleDateTime(stringToDateFormat(bo.getBusinessStepExecutedOn().toString()));
					}else {
						logger.error("TTU_Reschedule_Approval_1027 TtuRescheduleDateTime is null for  OrderId=" + orderId, this);	
					}
					
					if(null!=bo.getComments()) {
						bpmTaskFieldDataBO.setComments(bo.getComments());
					}else {
						logger.error("TTU_Reschedule_Approval_1027 Ticket Comment is null for  OrderId=" + orderId, this);	
					}
					if(saveTask(bpmtaskId, bpmTaskFieldDataBO)) {
						String requestUri = BPM_BASE_URL + TASK + "/" + bpmtaskId + "/complete";
						Map<String, Object> taskVariablesMap = prepareProcessVariablesForTaskCompletion(
								bpmTaskFieldDataBO);
						ResponseEntity<String> response = restTemplate.postForEntity(requestUri,
								taskVariablesMap, String.class);
						if (204 == response.getStatusCodeValue() || 200 == response.getStatusCodeValue()) {
							logger.info("Successfully completed the task ID: " + bpmtaskId);
							logger.info("END TTU_Reschedule_Approval_1027  :: OrderId=" + orderId, this);
							return  true;
						} else if (500 == response.getStatusCodeValue()
								|| 400 == response.getStatusCodeValue()) {
							logger.info("Completing the task ID: " + bpmtaskId + " was not successful");
							logger.info("END ON TTU_Reschedule_Approval_1027  :: OrderId=" + orderId, this);
							return false;
						}
					}else {
						logger.info("END TTU_Reschedule_Approval_1027 not saved :: OrderId=" + orderId, this);
					}
					
					
				} catch (CometException e) {
					logger.info("ISSUE ON TTU_Reschedule_Approval_1027 :: OrderId=" + orderId, this);
					logger.info("END ON TTU_Reschedule_Approval_1027  :: OrderId=" + orderId, this);
					return false;
				}
				
			}
		}
		logger.info("End TTU_Reschedule_Approval_1027 ::TTU_Reschedule_Approval_1027 OrderId=" + orderId, this);
		return false;
	
	
	}
	
	public Boolean saveTask(String taskId, BpmTaskFieldDataBO bpmTaskFieldDataBO) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || null == bpmTaskFieldDataBO) {
			logger.debug("Invalid info for saving a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::saveTask Task ID: " + taskId);
		
		//String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/localVariables";
		String requestUri="https://comet-mcs-prod.it.att.com/cometBpm-0.0.1-SNAPSHOT/engine/engine/task"+"/"+taskId+"/localVariables"; 
		Boolean isSaveSuccess = false;
		
		try{ 
			URI uri = new URI(requestUri);
			Map<String, Object> taskVariablesMap = this.prepareLocalVariablesForTask(bpmTaskFieldDataBO);
			
			ResponseEntity<String> response = restTemplate.postForEntity(uri, taskVariablesMap, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.info("Successfully saved the task ID: " + taskId);
				isSaveSuccess = true;
			} else if (500 == response.getStatusCodeValue()
						|| 400 == response.getStatusCodeValue()) {
				logger.info("Saving the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while saving the task ID [" + taskId + "]");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return isSaveSuccess;				
	}
	
	private Map<String, Object> prepareLocalVariablesForTask(BpmTaskFieldDataBO bpmTaskFieldDataBO) throws CometException {
		if (null == bpmTaskFieldDataBO) {
			throw new CometException("TaskServiceImpl::prepareLocalVariablesForTask -- Invalid task field data");
		}
		
		logger.info("TaskServiceImpl::prepareLocalVariablesForTask -- Start");
		
		Map<String, Object> dataMap = new HashMap<String, Object>();
		Map<String, Object> valueMap = new HashMap<String, Object>();
		Map<String, Object> inputMap = new HashMap<String, Object>();
		Map<String, Object> variablesMap = new HashMap<String, Object>();
		
		if (null != bpmTaskFieldDataBO.getComments()) {
			String comments = "'" + bpmTaskFieldDataBO.getComments() + "'";
			dataMap.put("comments", comments);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketNum()) {
			String ticketNum = "'" + bpmTaskFieldDataBO.getTicketNum() + "'";
			dataMap.put("ticketNum", ticketNum);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketCreateDate()) {
			String ticketCreateDate = "'" + bpmTaskFieldDataBO.getTicketCreateDate() + "'";
			dataMap.put("ticketCreateDate", ticketCreateDate);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuRescheduleDateTime()) {
			String ttuRescheduleDateTime = "'" + bpmTaskFieldDataBO.getTtuRescheduleDateTime() + "'";
			dataMap.put("ttuRescheduleDateTime", ttuRescheduleDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getReasonForReschedule()) {
			String reasonForReschedule = "'" + bpmTaskFieldDataBO.getReasonForReschedule() + "'";
			dataMap.put("reasonForReschedule", reasonForReschedule);
		}
		
		if (null != bpmTaskFieldDataBO.getResponse()) {
			String response = "'" + bpmTaskFieldDataBO.getResponse() + "'";
			dataMap.put("response", response);
		}
		
		if (null != bpmTaskFieldDataBO.getCompletedDate()) {
			String completedDate = "'" + bpmTaskFieldDataBO.getCompletedDate() + "'";
			dataMap.put("completedDate", completedDate);
		}
		
		if (null != bpmTaskFieldDataBO.getApnIWOSbuildConfirmation()) {
			String apnIWOSbuildConfirmation = "'" + bpmTaskFieldDataBO.getApnIWOSbuildConfirmation() + "'";
			dataMap.put("apnIWOSbuildConfirmation", apnIWOSbuildConfirmation);
		}
		
		if (null != bpmTaskFieldDataBO.getIsPreFlightTestOccurred()) {
			String isPreFlightTestOccurred = "'" + bpmTaskFieldDataBO.getIsPreFlightTestOccurred() + "'";
			dataMap.put("isPreFlightTestOccurred", isPreFlightTestOccurred);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingResult()) {
			String preFlightTestingResult = "'" + bpmTaskFieldDataBO.getPreFlightTestingResult() + "'";
			dataMap.put("preFlightTestingResult", preFlightTestingResult);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingDateTime()) {
			String preFlightTestingDateTime = "'" + bpmTaskFieldDataBO.getPreFlightTestingDateTime() + "'";
			dataMap.put("preFlightTestingDateTime", preFlightTestingDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getIsTTURequired()) {
			String isTTURequired = "'" + bpmTaskFieldDataBO.getIsTTURequired() + "'";
			dataMap.put("isTTURequired", isTTURequired);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuScheduleDateTime()) {
			String ttuScheduleDateTime = "'" + bpmTaskFieldDataBO.getTtuScheduleDateTime() + "'";
			dataMap.put("ttuScheduleDateTime", ttuScheduleDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder()) {
			String ttuIsPerformedForTheOrder = "'" + bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder() + "'";
			dataMap.put("ttuIsPerformedForTheOrder", ttuIsPerformedForTheOrder);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuResult()) {
			String ttuResult = "'" + bpmTaskFieldDataBO.getTtuResult() + "'";
			dataMap.put("ttuResult", ttuResult);
		}
		
		if (null != bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber()) {
			String securityEngrIwosTicketNumber = "'" + bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber() + "'";
			dataMap.put("securityEngrIwosTicketNumber", securityEngrIwosTicketNumber);
		}
		
		if (null != bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate()) {
			String proposedExpediteBuildCompletionDate = "'" + bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate() + "'";
			dataMap.put("proposedExpediteBuildCompletionDate", proposedExpediteBuildCompletionDate);
		}
		
		if (null != bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate()) {
			String finalExpediteBuildCompletionDate = "'" + bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate() + "'";
			dataMap.put("finalExpediteBuildCompletionDate", finalExpediteBuildCompletionDate);
		}
		
		valueMap.put("value", dataMap);
		valueMap.put("type", "String");
		inputMap.put(OrderConstants.BPM_TASK_LOCAL_VARIABLES_NAME, valueMap);
		variablesMap.put("modifications", inputMap);
		
		logger.info("TaskServiceImpl::prepareLocalVariablesForTask -- End");
		return variablesMap;
	}
	
	 public  String stringToDateFormat(String inputDate) throws ParseException {
	    	//change  yyyy-MM-dd'T'HH:mm:ss.SSSZ format
	    	SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			SimpleDateFormat outFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			
			Date inDate = inputFormat.parse(inputDate);
			String outDate = outFormatter.format(inDate);
			return outDate ;
	    }

}
