package com.att.comet.dao.hibernate.bean;

import java.sql.Blob;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for SubAccount. Mapped to SUB_ACCOUNT table in the database.
 */
@Entity
@Table(name = "SUB_ACCOUNT")
public class SubAccount implements java.io.Serializable {

	private static final long serialVersionUID = -4230284471524264780L;
	private String bcid;
	private Country countryByMccCountryId;
	private String accountType;
	private City cityByClCityId;
	private City cityByBlCityId;
	private Country countryByClCountryId;
	private City cityByHlCityId;
	private State stateByMccStateId;
	private Country countryByBlCountryId;
	private State stateByBlStateId;
	private State stateByClStateId;
	private Country countryByHlCountryId;
	private State stateByHlStateId;
	private MasterAccount masterAccount;
	private City cityByMccCityId;
	private String subAccountName;
	private String federalTaxId;
	private Character tsp;
	private Character feeWaiverApproved;
	private byte[] waiverAttachment;
	private String waiverNotes;
	private String companyName;
	private String companyOwner;
	private String businessDescription;
	private String clStreetAddress;
	private String clZipCode;
	private String blStreetAddress;
	private String blZipCode;
	private String hlStreetAddress;
	private String hlZipCode;
	private String mainCustContact;
	private String mccStreetAddress;
	private String mccZipCode;
	private Long mccDeskphone;
	private Long mccCellphone;
	private String mccEmail;
	private String createdBy;
	private Date createdOn;
	private String updatedBy;
	private Date updatedOn;
	private Character active;
	private String waiverAttachmentFilename;
	private Set<Vpn> vpns = new HashSet<Vpn>(0);
	private Set<Orders> orderses = new HashSet<Orders>(0);
	private Character derivedClFromHq;
	private Character derivedBlFromHq;
	private Character derivedBlFromCl;
	private Character derivedCciFromHq;
	private String mccDeskphoneExtension;

	/**
	 * Getter method for bcid. BCID mapped to BCID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "BCID", unique = true, nullable = false, length=50)
	public String getBcid() {
		return this.bcid;
	}

	/**
	 * @param bcid
	 *            to bcid set.
	 */
	public void setBcid(String bcid) {
		this.bcid = bcid;
	}

	/**
	 * Getter method for countryByMccCountryId.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MCC_COUNTRY_ID", nullable = false)
	public Country getCountryByMccCountryId() {
		return this.countryByMccCountryId;
	}

	/**
	 * @param countryByMccCountryId
	 *            to countryByMccCountryId set.
	 */
	public void setCountryByMccCountryId(Country countryByMccCountryId) {
		this.countryByMccCountryId = countryByMccCountryId;
	}

	/**
	 * Getter method for accountType. ACCOUNT_TYPE mapped to ACCOUNT_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "ACCOUNT_TYPE", nullable = false)
	public String getAccountType() {
		return this.accountType;
	}

	/**
	 * @param accountType
	 *            to accountType set.
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * Getter method for cityByClCityId.
	 * 
	 * @return City
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CL_CITY_ID")
	public City getCityByClCityId() {
		return this.cityByClCityId;
	}

	/**
	 * @param cityByClCityId
	 *            to cityByClCityId set.
	 */
	public void setCityByClCityId(City cityByClCityId) {
		this.cityByClCityId = cityByClCityId;
	}

	/**
	 * Getter method for cityByBlCityId.
	 * 
	 * @return City
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BL_CITY_ID")
	public City getCityByBlCityId() {
		return this.cityByBlCityId;
	}

	/**
	 * @param cityByBlCityId
	 *            to cityByBlCityId set.
	 */
	public void setCityByBlCityId(City cityByBlCityId) {
		this.cityByBlCityId = cityByBlCityId;
	}

	/**
	 * Getter method for countryByClCountryId.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CL_COUNTRY_ID")
	public Country getCountryByClCountryId() {
		return this.countryByClCountryId;
	}

	/**
	 * @param countryByClCountryId
	 *            to countryByClCountryId set.
	 */
	public void setCountryByClCountryId(Country countryByClCountryId) {
		this.countryByClCountryId = countryByClCountryId;
	}

	/**
	 * Getter method for cityByHlCityId.
	 * 
	 * @return City
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HL_CITY_ID", nullable = false)
	public City getCityByHlCityId() {
		return this.cityByHlCityId;
	}

	/**
	 * @param cityByHlCityId
	 *            to cityByHlCityId set.
	 */
	public void setCityByHlCityId(City cityByHlCityId) {
		this.cityByHlCityId = cityByHlCityId;
	}

	/**
	 * Getter method for stateByMccStateId.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MCC_STATE_ID", nullable = false)
	public State getStateByMccStateId() {
		return this.stateByMccStateId;
	}

	/**
	 * @param stateByMccStateId
	 *            to stateByMccStateId set.
	 */
	public void setStateByMccStateId(State stateByMccStateId) {
		this.stateByMccStateId = stateByMccStateId;
	}

	/**
	 * Getter method for countryByBlCountryId.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BL_COUNTRY_ID")
	public Country getCountryByBlCountryId() {
		return this.countryByBlCountryId;
	}

	/**
	 * @param countryByBlCountryId
	 *            to countryByBlCountryId set.
	 */
	public void setCountryByBlCountryId(Country countryByBlCountryId) {
		this.countryByBlCountryId = countryByBlCountryId;
	}

	/**
	 * Getter method for stateByBlStateId.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BL_STATE_ID")
	public State getStateByBlStateId() {
		return this.stateByBlStateId;
	}

	/**
	 * @param stateByBlStateId
	 *            to stateByBlStateId set.
	 */
	public void setStateByBlStateId(State stateByBlStateId) {
		this.stateByBlStateId = stateByBlStateId;
	}

	/**
	 * Getter method for stateByClStateId.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CL_STATE_ID")
	public State getStateByClStateId() {
		return this.stateByClStateId;
	}

	/**
	 * @param stateByClStateId
	 *            to stateByClStateId set.
	 */
	public void setStateByClStateId(State stateByClStateId) {
		this.stateByClStateId = stateByClStateId;
	}

	/**
	 * Getter method for countryByHlCountryId.
	 * 
	 * @return Country
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HL_COUNTRY_ID", nullable = false)
	public Country getCountryByHlCountryId() {
		return this.countryByHlCountryId;
	}

	/**
	 * @param countryByHlCountryId
	 *            to countryByHlCountryId set.
	 */
	public void setCountryByHlCountryId(Country countryByHlCountryId) {
		this.countryByHlCountryId = countryByHlCountryId;
	}

	/**
	 * Getter method for stateByHlStateId.
	 * 
	 * @return State
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "HL_STATE_ID", nullable = false)
	public State getStateByHlStateId() {
		return this.stateByHlStateId;
	}

	/**
	 * @param stateByHlStateId
	 *            to stateByHlStateId set.
	 */
	public void setStateByHlStateId(State stateByHlStateId) {
		this.stateByHlStateId = stateByHlStateId;
	}

	/**
	 * Getter method for masterAccount.
	 * 
	 * @return MasterAccount
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UBCID", nullable = false)
	public MasterAccount getMasterAccount() {
		return this.masterAccount;
	}

	/**
	 * @param masterAccount
	 *            to masterAccount set.
	 */
	public void setMasterAccount(MasterAccount masterAccount) {
		this.masterAccount = masterAccount;
	}

	/**
	 * Getter method for cityByMccCityId.
	 * 
	 * @return City
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MCC_CITY_ID", nullable = false)
	public City getCityByMccCityId() {
		return this.cityByMccCityId;
	}

	/**
	 * @param cityByMccCityId
	 *            to cityByMccCityId set.
	 */
	public void setCityByMccCityId(City cityByMccCityId) {
		this.cityByMccCityId = cityByMccCityId;
	}

	/**
	 * Getter method for subAccountName. SUB_ACCOUNT_NAME mapped to
	 * SUB_ACCOUNT_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SUB_ACCOUNT_NAME", nullable = false, length = 100)
	public String getSubAccountName() {
		return this.subAccountName;
	}

	/**
	 * @param subAccountName
	 *            to subAccountName set.
	 */
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}

	/**
	 * Getter method for federalTaxId. FEDERAL_TAX_ID mapped to FEDERAL_TAX_ID
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "FEDERAL_TAX_ID", length = 100)
	public String getFederalTaxId() {
		return this.federalTaxId;
	}

	/**
	 * @param federalTaxId
	 *            to federalTaxId set.
	 */
	public void setFederalTaxId(String federalTaxId) {
		this.federalTaxId = federalTaxId;
	}

	/**
	 * Getter method for tsp. TSP mapped to TSP in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "TSP", length = 100)
	public Character getTsp() {
		return this.tsp;
	}

	/**
	 * @param tsp
	 *            to tsp set.
	 */
	public void setTsp(Character tsp) {
		this.tsp = tsp;
	}

	/**
	 * Getter method for feeWaiverApproved. FEE_WAIVER_APPROVED mapped to
	 * FEE_WAIVER_APPROVED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "FEE_WAIVER_APPROVED", length = 100)
	public Character getFeeWaiverApproved() {
		return this.feeWaiverApproved;
	}

	/**
	 * @param feeWaiverApproved
	 *            to feeWaiverApproved set.
	 */
	public void setFeeWaiverApproved(Character feeWaiverApproved) {
		this.feeWaiverApproved = feeWaiverApproved;
	}

	/**
	 * Getter method for waiverAttachment. WAIVER_ATTACHMENT mapped to
	 * WAIVER_ATTACHMENT in the database table.
	 * 
	 * @return Blob
	 */
	@Column(name = "WAIVER_ATTACHMENT")
	public byte[] getWaiverAttachment() {
		return this.waiverAttachment;
	}

	/**
	 * @param waiverAttachment
	 *            to waiverAttachment set.
	 */
	public void setWaiverAttachment(byte[] waiverAttachment) {
		this.waiverAttachment = waiverAttachment;
	}

	/**
	 * Getter method for waiverNotes. WAIVER_NOTES mapped to WAIVER_NOTES in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_NOTES", length = 2000)
	public String getWaiverNotes() {
		return this.waiverNotes;
	}

	/**
	 * @param waiverNotes
	 *            to waiverNotes
	 */
	public void setWaiverNotes(String waiverNotes) {
		this.waiverNotes = waiverNotes;
	}

	/**
	 * Getter method for companyName. COMPANY_NAME mapped to COMPANY_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "COMPANY_NAME", length = 100)
	public String getCompanyName() {
		return this.companyName;
	}

	/**
	 * @param companyName
	 *            to companyName
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Getter method for companyOwner. COMPANY_OWNER mapped to COMPANY_OWNER in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "COMPANY_OWNER", length = 100)
	public String getCompanyOwner() {
		return this.companyOwner;
	}

	/**
	 * @param companyOwner
	 *            to companyOwner
	 */
	public void setCompanyOwner(String companyOwner) {
		this.companyOwner = companyOwner;
	}

	/**
	 * Getter method for businessDescription. BUSINESS_DESCRIPTION mapped to
	 * BUSINESS_DESCRIPTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_DESCRIPTION", length = 3500)
	public String getBusinessDescription() {
		return this.businessDescription;
	}

	/**
	 * @param businessDescription
	 *            to businessDescription set.
	 */
	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	/**
	 * Getter method for clStreetAddress. CL_STREET_ADDRESS mapped to
	 * CL_STREET_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CL_STREET_ADDRESS", length = 2000)
	public String getClStreetAddress() {
		return this.clStreetAddress;
	}

	/**
	 * @param clStreetAddress
	 *            to clStreetAddress set.
	 */
	public void setClStreetAddress(String clStreetAddress) {
		this.clStreetAddress = clStreetAddress;
	}

	/**
	 * Getter method for clZipCode. CL_ZIP_CODE mapped to CL_ZIP_CODE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "CL_ZIP_CODE", length = 10)
	public String getClZipCode() {
		return this.clZipCode;
	}

	/**
	 * @param clZipCode
	 *            to clZipCode set.
	 */
	public void setClZipCode(String clZipCode) {
		this.clZipCode = clZipCode;
	}

	/**
	 * Getter method for blStreetAddress. BL_STREET_ADDRESS mapped to
	 * BL_STREET_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BL_STREET_ADDRESS", length = 2000)
	public String getBlStreetAddress() {
		return this.blStreetAddress;
	}

	/**
	 * @param blStreetAddress
	 *            to blStreetAddress set.
	 */
	public void setBlStreetAddress(String blStreetAddress) {
		this.blStreetAddress = blStreetAddress;
	}

	/**
	 * Getter method for blZipCode. BL_ZIP_CODE mapped to BL_ZIP_CODE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "BL_ZIP_CODE", length = 10)
	public String getBlZipCode() {
		return this.blZipCode;
	}

	/**
	 * @param blZipCode
	 *            to blZipCode set.
	 */
	public void setBlZipCode(String blZipCode) {
		this.blZipCode = blZipCode;
	}

	/**
	 * Getter method for hlStreetAddress. HL_STREET_ADDRESS mapped to
	 * HL_STREET_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "HL_STREET_ADDRESS", length = 2000, nullable = false)
	public String getHlStreetAddress() {
		return this.hlStreetAddress;
	}

	/**
	 * @param hlStreetAddress
	 *            to hlStreetAddress set.
	 */
	public void setHlStreetAddress(String hlStreetAddress) {
		this.hlStreetAddress = hlStreetAddress;
	}

	/**
	 * Getter method for hlZipCode. HL_ZIP_CODE mapped to HL_ZIP_CODE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "HL_ZIP_CODE", length = 10, nullable = false)
	public String getHlZipCode() {
		return this.hlZipCode;
	}

	/**
	 * @param hlZipCode
	 *            to hlZipCode set.
	 */
	public void setHlZipCode(String hlZipCode) {
		this.hlZipCode = hlZipCode;
	}

	/**
	 * Getter method for mainCustContact. MAIN_CUST_CONTACT mapped to
	 * MAIN_CUST_CONTACT in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MAIN_CUST_CONTACT", length = 100, nullable = false)
	public String getMainCustContact() {
		return this.mainCustContact;
	}

	/**
	 * @param mainCustContact
	 *            to mainCustContact set.
	 */
	public void setMainCustContact(String mainCustContact) {
		this.mainCustContact = mainCustContact;
	}

	/**
	 * Getter method for mccStreetAddress. MCC_STREET_ADDRESS mapped to
	 * MCC_STREET_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MCC_STREET_ADDRESS", length = 2000, nullable = false)
	public String getMccStreetAddress() {
		return this.mccStreetAddress;
	}

	/**
	 * @param mccStreetAddress
	 *            to mccStreetAddress set.
	 */
	public void setMccStreetAddress(String mccStreetAddress) {
		this.mccStreetAddress = mccStreetAddress;
	}

	/**
	 * Getter method for mccZipCode. MCC_ZIP_CODE mapped to MCC_ZIP_CODE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "MCC_ZIP_CODE", length = 100, nullable = false)
	public String getMccZipCode() {
		return this.mccZipCode;
	}

	/**
	 * @param mccZipCode
	 *            to mccZipCode set.
	 */
	public void setMccZipCode(String mccZipCode) {
		this.mccZipCode = mccZipCode;
	}

	/**
	 * Getter method for mccDeskphone. MCC_DESKPHONE mapped to MCC_DESKPHONE in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "MCC_DESKPHONE", precision = 10, scale = 0, nullable = false)
	public Long getMccDeskphone() {
		return this.mccDeskphone;
	}

	/**
	 * @param mccDeskphone
	 *            to mccDeskphone set.
	 */
	public void setMccDeskphone(Long mccDeskphone) {
		this.mccDeskphone = mccDeskphone;
	}

	/**
	 * Getter method for mccDeskphoneExtension. MCC_DESKPHONE_EXTENSION mapped
	 * to MCC_DESKPHONE_EXTENSION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MCC_DESKPHONE_EXTENSION", length = 6)
	public String getMccDeskphoneExtension() {
		return mccDeskphoneExtension;
	}

	/**
	 * @param mccDeskphoneExtension
	 *            to mccDeskphoneExtension set.
	 */
	public void setMccDeskphoneExtension(String mccDeskphoneExtension) {
		this.mccDeskphoneExtension = mccDeskphoneExtension;
	}

	/**
	 * Getter method for mccCellphone. MCC_CELLPHONE mapped to MCC_CELLPHONE in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "MCC_CELLPHONE", precision = 10, scale = 0)
	public Long getMccCellphone() {
		return this.mccCellphone;
	}

	/**
	 * @param mccCellphone
	 *            to mccCellphone set.
	 */
	public void setMccCellphone(Long mccCellphone) {
		this.mccCellphone = mccCellphone;
	}

	/**
	 * Getter method for mccEmail. MCC_EMAIL mapped to MCC_EMAIL in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "MCC_EMAIL", length = 100, nullable = false)
	public String getMccEmail() {
		return this.mccEmail;
	}

	/**
	 * @param mccEmail
	 *            to mccEmail set.
	 */
	public void setMccEmail(String mccEmail) {
		this.mccEmail = mccEmail;
	}

	/**
	 * Getter method for createdBy. CREATED_BY mapped to CREATED_BY in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "CREATED_BY", length = 100)
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 *            to createdBy set.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON")
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn
	 *            to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedBy. UPDATED_BY mapped to UPDATED_BY in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "UPDATED_BY", length = 100)
	public String getUpdatedBy() {
		return this.updatedBy;
	}

	/**
	 * @param updatedBy
	 *            to updatedBy set.
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the
	 * database table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn
	 *            to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for active. ACTIVE mapped to ACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ACTIVE", nullable = false, length = 1)
	public Character getActive() {
		return this.active;
	}

	/**
	 * @param active
	 *            to active set.
	 */
	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for waiverAttachmentFilename. WAIVER_ATTACHMENT_FILENAME
	 * mapped to WAIVER_ATTACHMENT_FILENAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "WAIVER_ATTACHMENT_FILENAME", length = 100)
	public String getWaiverAttachmentFilename() {
		return this.waiverAttachmentFilename;
	}

	/**
	 * @param waiverAttachmentFilename
	 *            to waiverAttachmentFilename set.
	 */
	public void setWaiverAttachmentFilename(String waiverAttachmentFilename) {
		this.waiverAttachmentFilename = waiverAttachmentFilename;
	}

	/**
	 * Getter method for vpns.
	 * 
	 * @return Set<Vpn>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "subAccount")
	public Set<Vpn> getVpns() {
		return this.vpns;
	}

	/**
	 * @param vpns
	 *            to vpns set.
	 */
	public void setVpns(Set<Vpn> vpns) {
		this.vpns = vpns;
	}

	/**
	 * Getter method for orderses.
	 * 
	 * @return Set<Orders>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "subAccount")
	public Set<Orders> getOrderses() {
		return this.orderses;
	}

	/**
	 * @param orderses
	 *            to orderses set.
	 */
	public void setOrderses(Set<Orders> orderses) {
		this.orderses = orderses;
	}

	/**
	 * Getter method for derivedClFromHq. DERIVED_CL_FROM_HQ mapped to
	 * DERIVED_CL_FROM_HQ in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "DERIVED_CL_FROM_HQ", length = 1)
	public Character getDerivedClFromHq() {
		return derivedClFromHq;
	}

	/**
	 * @param derivedClFromHq
	 *            to derivedClFromHq set.
	 */
	public void setDerivedClFromHq(Character derivedClFromHq) {
		this.derivedClFromHq = derivedClFromHq;
	}

	/**
	 * Getter method for derivedBlFromHq. DERIVED_BL_FROM_HQ mapped to
	 * DERIVED_BL_FROM_HQ in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "DERIVED_BL_FROM_HQ", length = 1)
	public Character getDerivedBlFromHq() {
		return derivedBlFromHq;
	}

	/**
	 * @param derivedBlFromHq
	 *            to derivedBlFromHq
	 */
	public void setDerivedBlFromHq(Character derivedBlFromHq) {
		this.derivedBlFromHq = derivedBlFromHq;
	}

	/**
	 * Getter method for derivedBlFromCl. DERIVED_BL_FROM_CL mapped to
	 * DERIVED_BL_FROM_CL in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "DERIVED_BL_FROM_CL", length = 1)
	public Character getDerivedBlFromCl() {
		return derivedBlFromCl;
	}

	/**
	 * @param derivedBlFromCl
	 *            to derivedBlFromCl set.
	 */
	public void setDerivedBlFromCl(Character derivedBlFromCl) {
		this.derivedBlFromCl = derivedBlFromCl;
	}

	/**
	 * @return the derivedCciFromHq
	 */
	@Column(name = "DERIVED_CCI_FROM_HQ", length = 1)
	public Character getDerivedCciFromHq() {
		return derivedCciFromHq;
	}

	/**
	 * @param derivedCciFromHq the derivedCciFromHq to set
	 */
	public void setDerivedCciFromHq(Character derivedCciFromHq) {
		this.derivedCciFromHq = derivedCciFromHq;
	}
}