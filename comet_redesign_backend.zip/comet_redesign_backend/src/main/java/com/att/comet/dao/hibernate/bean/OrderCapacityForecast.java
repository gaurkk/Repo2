package com.att.comet.dao.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for OrderCapacityForecast. Mapped to ORDER_CAPACITY_FORECAST
 * table in the database.
 */
@Entity
@Table(name = "ORDER_CAPACITY_FORECAST")
public class OrderCapacityForecast implements java.io.Serializable {

	private static final long serialVersionUID = 7019228530107022179L;

	private OrderCapacityForecastId id;
	private OrderAccount orderAccount;
	private String subscriberDevices;
	private String pkPercentOfDevices;
	private String speedPerSubscriber;
	private String pkPercentPerPdp;
	private String pkConcurrentTotalPdp;
	private String pkConcurrentPdpNdc;
	private String pkWanBwTotalNdc;
	private String pkPdpCtxActvPerSec;
	private String totalSmsWakeupsMonth;
	private String totalSmsWakeupsSec;

	/**
	 * Getter method for id.
	 * 
	 * @return OrderCapacityForecastId
	 */
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "year", column = @Column(name = "YEAR", nullable = false, precision = 4, scale = 0)) })
	public OrderCapacityForecastId getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            to id set.
	 */
	public void setId(OrderCapacityForecastId id) {
		this.id = id;
	}

	/**
	 * Getter method for orderAccount.
	 * 
	 * @return OrderAccount
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public OrderAccount getOrderAccount() {
		return this.orderAccount;
	}

	/**
	 * @param orderAccount
	 *            to orderAccount set.
	 */
	public void setOrderAccount(OrderAccount orderAccount) {
		this.orderAccount = orderAccount;
	}

	/**
	 * Getter method for subscriberDevices. SUBSCRIBER_DEVICES mapped to
	 * SUBSCRIBER_DEVICES in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SUBSCRIBER_DEVICES", length = 200)
	public String getSubscriberDevices() {
		return this.subscriberDevices;
	}

	/**
	 * @param subscriberDevices
	 *            to subscriberDevices set.
	 */
	public void setSubscriberDevices(String subscriberDevices) {
		this.subscriberDevices = subscriberDevices;
	}

	/**
	 * Getter method for pkPercentOfDevices. PK_PERCENT_OF_DEVICES mapped to
	 * PK_PERCENT_OF_DEVICES in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_PERCENT_OF_DEVICES", length = 200)
	public String getPkPercentOfDevices() {
		return this.pkPercentOfDevices;
	}

	/**
	 * @param pkPercentOfDevices
	 *            to pkPercentOfDevices set.
	 */
	public void setPkPercentOfDevices(String pkPercentOfDevices) {
		this.pkPercentOfDevices = pkPercentOfDevices;
	}

	/**
	 * Getter method for speedPerSubscriber. SPEED_PER_SUBSCRIBER mapped to
	 * SPEED_PER_SUBSCRIBER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SPEED_PER_SUBSCRIBER", length = 200)
	public String getSpeedPerSubscriber() {
		return this.speedPerSubscriber;
	}

	/**
	 * @param speedPerSubscriber
	 *            to speedPerSubscriber set.
	 */
	public void setSpeedPerSubscriber(String speedPerSubscriber) {
		this.speedPerSubscriber = speedPerSubscriber;
	}

	/**
	 * Getter method for pkPercentPerPdp. PK_PERCENT_PER_PDP mapped to
	 * PK_PERCENT_PER_PDP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_PERCENT_PER_PDP", length = 200)
	public String getPkPercentPerPdp() {
		return this.pkPercentPerPdp;
	}

	/**
	 * @param pkPercentPerPdp
	 *            to pkPercentPerPdp set.
	 */
	public void setPkPercentPerPdp(String pkPercentPerPdp) {
		this.pkPercentPerPdp = pkPercentPerPdp;
	}

	/**
	 * Getter method for pkConcurrentTotalPdp. PK_CONCURRENT_TOTAL_PDP mapped to
	 * PK_CONCURRENT_TOTAL_PDP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_CONCURRENT_TOTAL_PDP", length = 200)
	public String getPkConcurrentTotalPdp() {
		return this.pkConcurrentTotalPdp;
	}

	/**
	 * @param pkConcurrentTotalPdp
	 *            to pkConcurrentTotalPdp set.
	 */
	public void setPkConcurrentTotalPdp(String pkConcurrentTotalPdp) {
		this.pkConcurrentTotalPdp = pkConcurrentTotalPdp;
	}

	/**
	 * Getter method for pkConcurrentPdpNdc. PK_CONCURRENT_PDP_NDC mapped to
	 * PK_CONCURRENT_PDP_NDC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_CONCURRENT_PDP_NDC", length = 200)
	public String getPkConcurrentPdpNdc() {
		return this.pkConcurrentPdpNdc;
	}

	/**
	 * @param pkConcurrentPdpNdc
	 *            to pkConcurrentPdpNdc set.
	 */
	public void setPkConcurrentPdpNdc(String pkConcurrentPdpNdc) {
		this.pkConcurrentPdpNdc = pkConcurrentPdpNdc;
	}

	/**
	 * Getter method for pkWanBwTotalNdc. PK_WAN_BW_TOTAL_NDC mapped to
	 * PK_WAN_BW_TOTAL_NDC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_WAN_BW_TOTAL_NDC", length = 200)
	public String getPkWanBwTotalNdc() {
		return this.pkWanBwTotalNdc;
	}

	/**
	 * @param pkWanBwTotalNdc
	 *            to pkWanBwTotalNdc set.
	 */
	public void setPkWanBwTotalNdc(String pkWanBwTotalNdc) {
		this.pkWanBwTotalNdc = pkWanBwTotalNdc;
	}

	/**
	 * Getter method for pkPdpCtxActvPerSec. PK_PDP_CTX_ACTV_PER_SEC mapped to
	 * PK_PDP_CTX_ACTV_PER_SEC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PK_PDP_CTX_ACTV_PER_SEC", length = 200)
	public String getPkPdpCtxActvPerSec() {
		return this.pkPdpCtxActvPerSec;
	}

	/**
	 * @param pkPdpCtxActvPerSec
	 *            to pkPdpCtxActvPerSec set.
	 */
	public void setPkPdpCtxActvPerSec(String pkPdpCtxActvPerSec) {
		this.pkPdpCtxActvPerSec = pkPdpCtxActvPerSec;
	}

	/**
	 * Getter method for totalSmsWakeupsMonth. TOTAL_SMS_WAKEUPS_MONTH mapped to
	 * TOTAL_SMS_WAKEUPS_MONTH in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "TOTAL_SMS_WAKEUPS_MONTH", length = 200)
	public String getTotalSmsWakeupsMonth() {
		return this.totalSmsWakeupsMonth;
	}

	/**
	 * @param totalSmsWakeupsMonth
	 *            to totalSmsWakeupsMonth set.
	 */
	public void setTotalSmsWakeupsMonth(String totalSmsWakeupsMonth) {
		this.totalSmsWakeupsMonth = totalSmsWakeupsMonth;
	}

	/**
	 * Getter method for totalSmsWakeupsSec. TOTAL_SMS_WAKEUPS_SEC mapped to
	 * TOTAL_SMS_WAKEUPS_SEC in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "TOTAL_SMS_WAKEUPS_SEC", length = 200)
	public String getTotalSmsWakeupsSec() {
		return this.totalSmsWakeupsSec;
	}

	/**
	 * @param totalSmsWakeupsSec
	 *            to totalSmsWakeupsSec set.
	 */
	public void setTotalSmsWakeupsSec(String totalSmsWakeupsSec) {
		this.totalSmsWakeupsSec = totalSmsWakeupsSec;
	}
}