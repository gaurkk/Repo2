package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.OrderUserTracker;

@Repository
public interface OrderUserTrackerRepository extends JpaRepository<OrderUserTracker, Long> {

	@Modifying
	@Query(value = "insert into ORDER_USER_TRACKER (ORDER_ID,ATTUID,ROLE_ID,TRACK_ID,IP_ADDRESS,BROWSER,ACTION,TAB_NAME,HTTP_METHOD,STATUS_CODE,CONTENT_TYPE) "
			+ "VALUES(:orderId, :attUid, :roleId, :trackId, :ipAddress, :browser, :action, :tabName,:httpMethod,  :httpStatusCode, :contentType)", nativeQuery = true)
	void insertOrderUserTracker(Long orderId, String attUid, Long roleId, String trackId,String ipAddress,
			String browser,String action,String tabName,String httpMethod,String httpStatusCode,String contentType);
}
