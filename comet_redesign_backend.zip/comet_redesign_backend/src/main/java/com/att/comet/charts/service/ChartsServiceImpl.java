package com.att.comet.charts.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.charts.dao.ChartsDAOImpl;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.criteria.SearchCriteria;

@Service
public class ChartsServiceImpl implements ChartsService {

	private static final Logger logger = LoggerFactory.getLogger(ChartsServiceImpl.class);

	@Autowired
	ChartsDAOImpl chartsDAO;

	public ResultBO getDataUsingCriteria(SearchCriteria searchCriterias)
			throws CometServiceException, CometDataException {
		logger.info("Starting method getDataUsingCriteria : ", this);
		ResultBO resultBO = null;

		try {
			resultBO = chartsDAO.getDataUsingCriteria(searchCriterias);
		} catch (CometDataException exception) {
			/// logger.error(exception.getStackTrace());
			logger.error("Data Exception in getting all Charts data", exception);
			throw exception;
		} catch (CometServiceException exception) {
			/// logger.error(exception.getStackTrace());
			logger.error("Service Exception in getting all Charts data", exception);
			throw exception;
		} catch (Exception exception) {
			/// logger.error(exception.getStackTrace());
			logger.error("Exception in getting all Charts data");
			throw new CometServiceException("Error", exception);
		}
		logger.info("Exiting method getDataUsingCriteria : ", this);
		return resultBO;
	}

	@Override
	public List<BackhaulTypeBO> getBHType() throws CometServiceException, CometDataException {
		logger.info("Starting method getBHType : ", this);

		List<BackhaulTypeBO> lstBackHaulTypeBO = null;
		lstBackHaulTypeBO = chartsDAO.getBHType();

		logger.info("Exiting method getBHType : ", this);
		return lstBackHaulTypeBO;
	}

}
