package com.att.comet.apn;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataCenterDetails implements Serializable{
	private static final long serialVersionUID = 6497170419024011921L;
	boolean isDataCenterHasActive ;
	boolean isDataCenterHasPassive;
	boolean isDataCenterActiveOnly;
	boolean isDataCenterPassiveOnly;
	boolean isDataCenterActivePassive;
	boolean activeDataCenterMoreThanOne;
	boolean allMpls = false;
	boolean isMpls = false;
	boolean isIVPN = false;
	boolean isInternet = false;
	boolean isOtherThanInternet = false;
	boolean isMixedBH = false; //MPLS and IVPN
	boolean isM2m = false;
}
