package com.att.comet.common.modal;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class OrderUserTrackerBO extends CometGenericBO {
	private static final long serialVersionUID = -7285157504322401214L;

	private long orderId;
	private String attuid;
	private Long roleId;
	private String trackId;
	private String action;
	private String tabName;
	private String ipAddr;
	private String browser;
	private String httpMethod;
	private String httpStatusCode;
	private String contentType;
	private Date accessOn;
}
