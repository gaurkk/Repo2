package com.att.comet.manage.modal;

import java.io.Serializable;

public class MessageBO implements Serializable{
	
	private static final long serialVersionUID = -6664073654265907009L;
	private int recordNumber;
	private String message;
	private String messageType;
	private String  messageCode;
	/**
	 * @return the recordNumber
	 */
	public int getRecordNumber() {
		return recordNumber;
	}
	/**
	 * @param recordNumber the recordNumber to set
	 */
	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
	/**
	 * @return the errorMessage
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the errorType
	 */
	public String getMessageType() {
		return messageType;
	}
	/**
	 * @param errorType the errorType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	/**
	 * @return the errorCode
	 */
	public String getMessageCode() {
		return messageCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
}