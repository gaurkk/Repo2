package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for Resources. Mapped to RESOURCES table in the database.
 */
@Entity
@Table(name = "RESOURCES")
public class Resources implements Serializable {

	private static final long serialVersionUID = 8157187909852147757L;

	private long resourceId;
	private String resourceName;

	/**
	 * Getter method for resourceId. RESOURCE_ID mapped to RESOURCE_ID in the
	 * database table.
	 * 
	 * @return long
	 */
	@Id
	@Column(name = "RESOURCE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public long getResourceId() {
		return this.resourceId;
	}

	/**
	 * @param resourceId
	 *            to resourceId set.
	 */
	public void setResourceId(long resourceId) {
		this.resourceId = resourceId;
	}

	/**
	 * Getter method for resourceName. RESOURCE_NAME mapped to RESOURCE_NAME in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "RESOURCE_NAME", nullable = false, length = 100)
	public String getResourceName() {
		return this.resourceName;
	}

	/**
	 * @param resourceName
	 *            to resourceName set.
	 */
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
}