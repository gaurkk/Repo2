package com.att.comet.common.modal;

public enum BpmStatusEnum {
	TRIGGERRED		(1001L, "TRIGGERRED"),
	COMPLETED		(1002L, "COMPLETED"),
	NOT_EXECUTED	(1003L, "NOT EXECUTED"); 

	private final Long bpmStatusId;
	private final String bpmStatusName;

	public Long getBpmStatusId() {
		return bpmStatusId;
	}

	public String getBpmStatusName() {
		return bpmStatusName;
	}

	public static BpmStatusEnum getById(Long id) {
		BpmStatusEnum bpmStatusEnum = null;
		
		for (BpmStatusEnum statusEnum : BpmStatusEnum.values()) {
			if (statusEnum.getBpmStatusId().equals(id)) {
				bpmStatusEnum = statusEnum;
				break;
			}
		}
		
		return bpmStatusEnum;
	}

	private BpmStatusEnum(Long bpmStatusId, String bpmStatusName) {
		this.bpmStatusId = bpmStatusId;
		this.bpmStatusName = bpmStatusName;
	}
}
