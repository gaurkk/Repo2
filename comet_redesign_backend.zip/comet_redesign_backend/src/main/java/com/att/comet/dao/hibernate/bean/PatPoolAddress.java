package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for PatPoolAddress. Mapped to PAT_POOL_ADDRESS table in the
 * database.
 */
@Entity
@Table(name = "PAT_POOL_ADDRESS")
public class PatPoolAddress implements java.io.Serializable {

	private static final long serialVersionUID = -4556448863971341447L;
	private long patPoolAddressId;
	private DataCenter dataCenter;
	private Apn apn;
	private String ipAddress;
	private Byte seq;

	/**
	 * No-argument constructor of the class.
	 */
	public PatPoolAddress() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param patPoolAddressId
	 * @param dataCenter
	 * @param apn
	 */
	public PatPoolAddress(long patPoolAddressId, DataCenter dataCenter, Apn apn) {
		this.patPoolAddressId = patPoolAddressId;
		this.dataCenter = dataCenter;
		this.apn = apn;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param patPoolAddressId
	 * @param dataCenter
	 * @param apn
	 * @param ipAddress
	 * @param seq
	 */
	public PatPoolAddress(long patPoolAddressId, DataCenter dataCenter,
			Apn apn, String ipAddress, Byte seq) {
		this.patPoolAddressId = patPoolAddressId;
		this.dataCenter = dataCenter;
		this.apn = apn;
		this.ipAddress = ipAddress;
		this.seq = seq;
	}

	/**
	 * Getter method for patPoolAddressId. PAT_POOL_ADDRESS_ID mapped to
	 * PAT_POOL_ADDRESS_ID in the database table. The sequence of the generation
	 * of the pat pool id is done using the sequence SEQ_PAT_POOL_ADDRESS_ID.
	 * 
	 * @return long
	 */
	@Id
	@Column(name = "PAT_POOL_ADDRESS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_PAT_POOL_ADDRESS_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_PAT_POOL_ADDRESS_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PAT_POOL_ADDRESS_ID")
	public long getPatPoolAddressId() {
		return this.patPoolAddressId;
	}

	/**
	 * @param patPoolAddressId
	 *            to patPoolAddressId set.
	 */
	public void setPatPoolAddressId(long patPoolAddressId) {
		this.patPoolAddressId = patPoolAddressId;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 *            to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for ipAddress.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS", length = 100)
	public String getIpAddress() {
		return this.ipAddress;
	}

	/**
	 * @param ipAddress
	 *            to ipAddress set.
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Getter method for seq. SEQ mapped to SEQ in the database table.
	 * 
	 * @return Byte
	 */
	@Column(name = "SEQ", precision = 2, scale = 0)
	public Byte getSeq() {
		return this.seq;
	}

	/**
	 * @param seq
	 *            to seq set.
	 */
	public void setSeq(Byte seq) {
		this.seq = seq;
	}

}
