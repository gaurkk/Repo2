package com.att.comet.criteria.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.exception.SQLGrammarException;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.charts.modal.ChartNameEnum;
import com.att.comet.charts.modal.OrderProgressColumnsEnum;
import com.att.comet.charts.result.OrderProgressPieChartBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.dao.ChartsSqlConstants;
import com.att.comet.dao.ScalarConstants;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.restriction.Restriction;

@Component
public class PieChartCriteriaRenderer extends CriteriaRenderer {
	private static final Logger logger = LoggerFactory.getLogger(PieChartCriteriaRenderer.class);
	private static final String ORDER_PROGRESS_COLUMN_NAME_KEY = "name";
	private static final String ORDER_PROGRESS_COLUMN_TYPE_KEY = "type";

	@PersistenceContext
	EntityManager em;

	@Override
	public ResultBO createExecuteQuery(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQuery : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();

		if (criteria.getRestrictions().size() > 0) {
			// Get Base query
			if (criteria.getBaseQuery().equals("BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION")) {
				return createQueryforDCConsumptionChart(criteria);
			} else {
				sql.append(ChartsSqlConstants.BASE_QUERY_FOR_PIECHART);
			}
			if (CommonUtils.isNullEmpty(sql.toString()))
				return null;
			for (Restriction res : criteria.getRestrictions()) {
				if (CommonUtils.isNotNullEmpty(res.toSqlString())) {
					String temp = "";
					int count = 0;
					String arrTemp[] = sql.toString().split("UNION ALL");
					for (String add : arrTemp) {
						temp = temp + add + res.toSqlString();
						if (count < arrTemp.length - 1)
							temp = temp + " UNION ALL ";
						count++;
					}
					sql.delete(0, sql.length());
					sql.append(temp);
				}
			}
			sql = createQueryFromOtherInfo(criteria, sql);

			if (criteria.getRestrictions().size() > 0) {
				sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
			}
			result = executeQuery(sql.toString(), criteria);
		}
		logger.info("Exiting method createExecuteQuery : ", this);
		return result;
	}

	/**
	 * Add other criteria to main query (user id, role id)
	 * 
	 * @param criteria
	 * @param sql
	 * @return StringBuilder
	 */
	private StringBuilder createQueryFromOtherInfo(SearchCriteria criteria, StringBuilder sql) {
		logger.info("Starting method createQueryFromOtherInfo : ", this);
		StringBuilder sqlQuery = new StringBuilder(sql);
		if (criteria.getOther() != null) {
			OtherDetails other = criteria.getOther();
			if (CommonUtils.isNotNullEmpty(other.getUserId())) {
				String temp = "";
				int count = 0;
				String arrTemp[] = sqlQuery.toString().split("UNION ALL");
				for (String add : arrTemp) {
					temp = temp + add + " and oci.attuid = '" + other.getUserId() + "' ";
					if (count < arrTemp.length - 1)
						temp = temp + " UNION ALL ";
					count++;
				}
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(temp);
			}
			if (CommonUtils.isNotNullEmpty(other.getRoleId())) {
				String temp = "";
				int count = 0;
				String arrTemp[] = sqlQuery.toString().split("UNION ALL");
				String role = "";
				switch (other.getRoleId().intValue()) {
				case 1001:
					role = "1003,1023";
					break;
				case 1002:
					role = "1004";
					break;
				case 1003:
					role = "1005";
					break;
				case 1004:
					role = "1007";
					break;
				case 1005:
					role = "1006";
					break;
				case 1006:
					role = "";
					break;
				case 1007:
					role = "0";
					break;
				case 1008:
					role = "1024";
					break;
				default:
					role = "1003,1023";
					break;
				}
				if (CommonUtils.isNotNullEmpty(role)) {
					for (String add : arrTemp) {
						temp = temp + add + " and oci.order_contact_type_id in (" + role + ") ";
						if (count < arrTemp.length - 1)
							temp = temp + " UNION ALL ";
						count++;
					}
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(temp);
				}
			}
		}
		logger.info("Exiting method createQueryFromOtherInfo : ", this);
		return sqlQuery;
	}

	/**
	 * Execute query for Pie Chart
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeQuery : ", this);
		ResultBO objBO = null;

		try {

			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.STATUS, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.COUNT, IntegerType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.COLOR, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			objBO = new ResultBO();
			if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.ALL_ORDERS_PROGRESS.toString())) {
				objBO.getOtherBO().setTitle("All Orders Progress Summary");
			} else if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.MY_ORDERS_PROGRESS.toString())) {
				objBO.getOtherBO().setTitle("My Orders Progress Summary");
			}
			OrderProgressPieChartBO pieChartBO = new OrderProgressPieChartBO();

			List<Map<String, String>> colMapList = new ArrayList<Map<String, String>>();
			for (OrderProgressColumnsEnum columnEnum : OrderProgressColumnsEnum.values()) {
				HashMap<String, String> colMap = new HashMap<String, String>();
				colMap.put(ORDER_PROGRESS_COLUMN_NAME_KEY, columnEnum.getColumnName());
				colMap.put(ORDER_PROGRESS_COLUMN_TYPE_KEY, columnEnum.getColumnType());
				colMapList.add(colMap);
			}
			pieChartBO.setLstColumns(colMapList);

			List<List<String>> rowList = new ArrayList<List<String>>();
			list.stream().forEach(mapsData -> {
				List<String> row = new ArrayList<>();

				mapsData.entrySet().forEach(mapData -> {
					row.add(mapData.getValue().toString());
				});
				rowList.add(row);
			});

			pieChartBO.setLstRows(rowList);
			objBO.setLstResult(pieChartBO);
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeQuery : ", this);
		return objBO;
	}

	/**
	 * Execute query for Pie Chart DC consumption
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQueryForDCConsumption(String sql, SearchCriteria criteria,
			Map<Long, String> mapActiveDataCenter) {
		logger.info("Starting method executeQueryForDCConsumption : ", this);
		ResultBO objBO = null;
		try {

			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.COUNT, IntegerType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.DATA_CENTER_NAME, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			objBO = new ResultBO();
			objBO.getOtherBO().setTitle("APNs by Data Center");
			OrderProgressPieChartBO pieChartBO = new OrderProgressPieChartBO();

			List<Map<String, String>> colMapList = new ArrayList<Map<String, String>>();
			for (OrderProgressColumnsEnum columnEnum : OrderProgressColumnsEnum.values()) {
				HashMap<String, String> colMap = new HashMap<String, String>();
				colMap.put(ORDER_PROGRESS_COLUMN_NAME_KEY, columnEnum.getColumnName());
				colMap.put(ORDER_PROGRESS_COLUMN_TYPE_KEY, columnEnum.getColumnType());
				colMapList.add(colMap);
			}
			pieChartBO.setLstColumns(colMapList);

			List<List<String>> rowList = new ArrayList<List<String>>();
			list.stream().forEach(mapsData -> {
				List<String> row = new ArrayList<>();
				mapsData.entrySet().forEach(mapData -> {
					row.add(mapData.getValue().toString());
				});
				rowList.add(row);
			});

			pieChartBO.setLstRows(rowList);
			objBO.setLstResult(pieChartBO);
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeQueryForDCConsumption : ", this);
		return objBO;
	}

	private Map<Long, String> getDataCenterList() {
		logger.info("Starting method getDataCenterList : ", this);
		Map<Long, String> mapActiveDCId = new HashMap<Long, String>();
		Query query = (Query) em.createQuery("from DataCenter where dummy='N' ");
		@SuppressWarnings("unchecked")
		List<DataCenter> lstDataCenter = query.getResultList();

		for (DataCenter dataCenter : lstDataCenter) {
			mapActiveDCId.put(dataCenter.getDataCenterId(), dataCenter.getDataCenterName());
		}
		logger.info("Exiting method getDataCenterList : ", this);
		return mapActiveDCId;
	}

	/**
	 * Create query for DC Consumption
	 * 
	 * @param criteria
	 * @return
	 */
	private ResultBO createQueryforDCConsumptionChart(SearchCriteria criteria) {
		logger.info("Starting method createQueryforDCConsumptionChart : ", this);

		ResultBO result = null;
		int counter = 0;

		Map<Long, String> mapActiveDataCenter = getDataCenterList();
		String baseQuery = ChartsSqlConstants.BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION;

		StringBuilder sql = new StringBuilder();

		for (Map.Entry<Long, String> activeDC : mapActiveDataCenter.entrySet()) {
			if (counter > 0) {
				sql.append(" UNION ALL ");
			}
			sql.append(
					baseQuery.replace("?", activeDC.getKey().toString()).replace("@@", activeDC.getValue().toString()));
			counter++;
		}

		if (CommonUtils.isNullEmpty(sql.toString())) {
			return null;
		}

		StringBuilder restrictions = new StringBuilder(" ");
		for (Restriction res : criteria.getRestrictions()) {
			if (CommonUtils.isNotNullEmpty(res.toSqlString())) {
				restrictions.append(res.toSqlString());
			}
		}
		/// TODO : remove below append as its added as workaround
		restrictions.append(" ) ");
		sql = replaceAllString(sql, "@RESTRICTION", restrictions.toString());

		sql = createQueryFromOtherInfo(criteria, sql);

		// Final sorting check
		if (criteria.getRestrictions().size() > 0) {
			sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
		}

		result = executeQueryForDCConsumption(sql.toString(), criteria, mapActiveDataCenter);

		logger.info("Exiting method createQueryforDCConsumptionChart : ", this);
		return result;

	}

	/**
	 * Utility method to replace the string from StringBuilder.
	 * 
	 * @param sql
	 * @param toReplace
	 * @param replacement
	 * @return Stringbuilder
	 */
	private StringBuilder replaceAllString(StringBuilder sql, String toReplace, String replacement) {
		int index = -1;
		while ((index = sql.lastIndexOf(toReplace)) != -1) {
			sql.replace(index, index + toReplace.length(), replacement);
		}
		return sql;
	}

}
