package com.att.comet.common.constant;

/**
 * Contains all possible Order Status types available in a Comet Order.
 */
public enum TypeOrderStatus {

	NEW(1000L, "New"), IN_PROGRESS(1001L, "In Progress"), SUBMITTED(1002L,
			"Submitted"), CANCELLED(1003L, "Cancelled"), PENDING_FOR_OA_APPROVAL(
			1004L, "Pending for OA Approval"), PENDING_FOR_OM_APPROVAL(1005L,
			"Pending for OM Approval"), REJECTED_BY_OA(1006L, "Rejected by OA"), REJECTED_BY_OM(
			1007L, "Rejected by OM"), IN_PRODUCTION(1009L, "In Production"), CANCEL_IN_PROGRESS(
			1010L, "Cancel – In Progress"),

	PENDING_FOR_OSD_APPROVAL(1011L, "Pending for OSD Approval"), REJECTED_BY_OSD(
			1012L, "Rejected by OSD"),

	DECOMMISSION_COMPLETE(1023L, "Decommissioned"), IWOS_SUSPENDED(1045L,
			"IWOS Suspended"), IMPLEMENTATION_IN_PROGRESS(1046L,
			"Implementation in Progress"), IMPLEMENTATION_COMPLETED(1047L,
			"Implementation Completed"), CHANGE_ORDER_IN_PROGRESS(1063L,
			"Change Order in Progress"), OVERRIDDEN_BY_CHANGE_ORDER(1064L,
			"Overridden by Change Order"), DECOMMISSION_IN_PROGRESS(1065L,
			"Decommission in Progress"), OVERRIDDEN_BY_DECOMMISSION(1066L,
			"Overridden by Decommission"),

	// Dedicated APN Inventory Status values
	APN_INVENTORY_IWOS_COMPLETED(1053L, "APN INVENTORY IWOS COMPLETED"), APN_INVENTORY_IWOS_NOT_COMPLETED(
			1054L, "APN_INVENTORY IWOS NOT COMPLETED"), APN_INVENTORY_IWOS_CONFIRMATION_COMPLETED(
			1055L, "APN INVENTORY IWOS CONFIRMATION COMPLETED"), APN_INVENTORY_IWOS_CONFIRMATION_REJECTED(
			1056L, "APN INVENTORY IWOS CONFIRMATION REJECTED"), NI_APN_INVENTORY_PREFLIGHT_TEST_OCCURED(
			1057L, "NI APN INVENTORY PREFLIGHT TEST OCCURED"), NI_APN_INVENTORY_PREFLIGHT_TEST_NOT_OCCURED(
			1058L, "NI APN INVENTORY PREFLIGHT TEST NOT OCCURED"), APN_INVENTORY_BUILD_IWOS_COMPLETED(
			1059L, "APN INVENTORY BUILD IWOS COMPLETED"), APN_INVENTORY_BUILD_IWOS_NOT_COMPLETED(
			1060L, "APN INVENTORY BUILD IWOS NOT COMPLETED"),ON_HOLD(1067L,"On-hold"),
			
	

	DAPN_REQUESTED(2001L, "Requested"), DAPN_NEW(2002L, "New"), DAPN_IN_PROGRESS(
			2003L, "In Progress"), DAPN_AVAILABLE(2004L, "AVAILABLE"), DAPN_BUILD_IN_PROGRESS(
			2005L, "APN Build in Progress"),DAPN_RELEASED(1068L,"D-APN Released");

	/**
	 * property id
	 */
	private final Long id;

	/**
	 * property name
	 */
	private final String name;

	/**
	 * Getter method for id.
	 * 
	 * @return long
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Getter method for name
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * The method is used to get the status based on the id.
	 * 
	 * @param id
	 * @return TypeOrderStatus, if id is not null otherwise null.
	 */
	public static TypeOrderStatus getStatus(Long id) {
		if (id != null) {
			for (TypeOrderStatus orderStatus : TypeOrderStatus.values()) {
				if (orderStatus.getId().longValue() == id.longValue()) {
					return orderStatus;
				}
			}
		}
		return null;
	}

	/**
	 * Argument Constructor
	 * 
	 * @param id
	 * @param name
	 */
	private TypeOrderStatus(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}