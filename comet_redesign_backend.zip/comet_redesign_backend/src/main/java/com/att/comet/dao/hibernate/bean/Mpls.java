package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Mpls. Mapped to MPLS table in the database.
 */
@Entity
@Table(name = "MPLS")
public class Mpls implements Serializable {

	private static final long serialVersionUID = 36623698519134827L;

	private Long backhaulId;
	private Vpn vpn;
	private Backhaul backhaul;
	private String protocol;
	private Byte numStaticRoute;
	private String remark;
	private String exportMap;
	private Short numRoutesAccepted;
	private Short maxNumBgpRoutes;
	private String mplsCir;
	private String routeDistinguisher;

	/**
	 * Getter method for backhaulId. BACKHAUL_ID mapped to BACKHAUL_ID in the
	 * database table.
	 * 
	 * @return
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "backhaul"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "BACKHAUL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	/**
	 * Getter method for vpn.
	 * 
	 * @return Vpn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "VPN_ID")
	public Vpn getVpn() {
		return this.vpn;
	}

	/**
	 * @param vpn
	 *            to vpn set.
	 */
	public void setVpn(Vpn vpn) {
		this.vpn = vpn;
	}

	/**
	 * Getter method for backhaul.
	 * 
	 * @return Backhaul
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Backhaul getBackhaul() {
		return this.backhaul;
	}

	/**
	 * @param backhaul
	 *            to backhaul
	 */
	public void setBackhaul(Backhaul backhaul) {
		this.backhaul = backhaul;
	}

	/**
	 * Getter method for protocol. PROTOCOL mapped to PROTOCOL in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "PROTOCOL", length = 100)
	public String getProtocol() {
		return this.protocol;
	}

	/**
	 * @param protocol
	 *            to protocol set.
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * Getter method for numStaticRoute. NUM_STATIC_ROUTE mapped to
	 * NUM_STATIC_ROUTE in the database table.
	 * 
	 * @return Byte
	 */
	@Column(name = "NUM_STATIC_ROUTE", precision = 2, scale = 0)
	public Byte getNumStaticRoute() {
		return this.numStaticRoute;
	}

	/**
	 * @param numStaticRoute
	 *            to numStaticRoute set.
	 */
	public void setNumStaticRoute(Byte numStaticRoute) {
		this.numStaticRoute = numStaticRoute;
	}

	
	/**
	 * Getter method for remark. REMARK mapped to REMARK in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "REMARK", length = 3500)
	public String getRemark() {
		return this.remark;
	}

	/**
	 * @param remark
	 *            to remark set.
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * Getter method for numRoutesAccepted. NUM_ROUTES_ACCEPTED mapped to
	 * NUM_ROUTES_ACCEPTED in the database table.
	 * 
	 * @return Short
	 */
	@Column(name = "NUM_ROUTES_ACCEPTED", precision = 3, scale = 0)
	public Short getNumRoutesAccepted() {
		return this.numRoutesAccepted;
	}

	/**
	 * @param numRoutesAccepted
	 *            to numRoutesAccepted set
	 */
	public void setNumRoutesAccepted(Short numRoutesAccepted) {
		this.numRoutesAccepted = numRoutesAccepted;
	}

	/**
	 * Getter method for maxNumBgpRoutes. MAX_NUM_BGP_ROUTES mapped to
	 * MAX_NUM_BGP_ROUTES in the database table.
	 * 
	 * @return Short
	 */
	@Column(name = "MAX_NUM_BGP_ROUTES", precision = 3, scale = 0)
	public Short getMaxNumBgpRoutes() {
		return this.maxNumBgpRoutes;
	}

	/**
	 * @param maxNumBgpRoutes
	 *            to maxNumBgpRoutes set.
	 */
	public void setMaxNumBgpRoutes(Short maxNumBgpRoutes) {
		this.maxNumBgpRoutes = maxNumBgpRoutes;
	}

	/**
	 * Getter method for mplsCir. MPLS_CIR mapped to MPLS_CIR in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "MPLS_CIR", length = 100)
	public String getMplsCir() {
		return mplsCir;
	}

	/**
	 * @param mplsCir
	 *            to mplsCir set.
	 */
	public void setMplsCir(String mplsCir) {
		this.mplsCir = mplsCir;
	}

	/**
	 * Getter method for routeDistinguisher. ROUTE_DISTINGUISHER mapped to
	 * ROUTE_DISTINGUISHER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ROUTE_DISTINGUISHER", length = 100)
	public String getRouteDistinguisher() {
		return routeDistinguisher;
	}

	/**
	 * @param routeDistinguisher
	 *            to routeDistinguisher set.
	 */
	public void setRouteDistinguisher(String routeDistinguisher) {
		this.routeDistinguisher = routeDistinguisher;
	}
    
	/**
	 * Getter method for exportMap. EXPORT_MAP mapped to
	 * EXPORT_MAP in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXPORT_MAP", length = 100)
	public String getExportMap() {
		return exportMap;
	}
	/**
	 * @param exportMap
	 *            to exportMap set.
	 */
	public void setExportMap(String exportMap) {
		this.exportMap = exportMap;
	}
}