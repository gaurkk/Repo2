package com.att.comet.charts.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.charts.delegate.ChartsDelegate;
import com.att.comet.charts.modal.ChartsRequestBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.charts.service.ChartsService;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.order.controller.OrderController;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ChartsController {

	Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	CometResponse<ResultBO> cometResponse;

	@Autowired
	CometResponse<List<BackhaulTypeBO>> cometResponseBhType;

	@Autowired
	ChartsDelegate chartsDelegate;

	@Autowired
	ChartsService chartsService;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@PostMapping(value = "/charts", headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get all charts data", notes = "Fetches all the charts data")
	public CometResponse<ResultBO> postChartsRequest(@RequestBody ChartsRequestBO requestBO) throws CometDataException {
		logger.info("[Attuid : " + (requestBO.getUserInfo().getAttuid() == null ? "" : requestBO.getUserInfo().getAttuid()) + "] "+ "Starting method postChartsRequest : ", this);
		ResultBO resultBO = null;

		try {
			resultBO = chartsDelegate.parseRequestJson(requestBO);
			cometResponse.setMethodReturnValue(resultBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}

		if (cometResponse.getStatusCode().equals(CometResponse.Status.BUSINESS_ERROR.getCode())
				&& cometResponse.getStatus().equals(CometResponse.Status.BUSINESS_ERROR)) {
			logger.error("postChartsRequest :: requestBO is having null value::", this);
			throw new CometDataException("INVALID REQUEST FOR CHART");
		}
		logger.info("[Attuid : " + (requestBO.getUserInfo().getAttuid() == null ? "" : requestBO.getUserInfo().getAttuid()) + "] "+ "Exiting method postChartsRequest : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/charts/bhType", headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get all Backhaul Types", notes = "Fetches all Backhaul Types")
	public CometResponse<List<BackhaulTypeBO>> getBHType() throws CometServiceException, CometDataException {
		logger.info("Starting method getBHType : ", this);
		List<BackhaulTypeBO> lstBackHaulTypeBO = null;

		try {
			lstBackHaulTypeBO = chartsService.getBHType();
			cometResponseBhType.setMethodReturnValue(lstBackHaulTypeBO);
			cometResponseBhType.setStatusCode(Status.SUCCESS.getCode());
			cometResponseBhType.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponseBhType.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponseBhType.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}

		if (cometResponseBhType.getStatusCode().equals(CometResponse.Status.SYSTEM_ERROR.getCode())
				&& cometResponseBhType.getStatus().equals(CometResponse.Status.SYSTEM_ERROR)) {
			logger.error("getBHType ::RECORD NOT FOUND::", this);
			throw new CometDataException("RECORD NOT FOUND");
		}
		logger.info("Exiting method getBHType : ", this);
		return cometResponseBhType;
	}
}
