package com.att.comet.apn;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EnterpriseDnsServerBO implements Serializable {

	private static final long serialVersionUID = -5279813337388983814L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long enterpriseServerId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String orderId;
	private Long dataCenterId;
	private String primaryEntServerIp;
	private String secondaryEntServerIp;
	private String dnsServerNotes;
	private String apnProtocol;
	private String dataCenterName;
}
