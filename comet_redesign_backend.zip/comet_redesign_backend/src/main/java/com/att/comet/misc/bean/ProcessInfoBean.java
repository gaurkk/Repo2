package com.att.comet.misc.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProcessInfoBean {
	
	private ProcessInfoDefault processInfoDefault;
	private ChangeProcessInfo changeProcessInfo;
	private CancelProcessInfo cancelProcessInfo;
	private ExpediteProcessInfo expediteProcessInfo;
	private  DAPNProcessInfo  dAPNProcessInfo;
	private DecommisionProcessInfo decommisionProcessInfo;
	
}
