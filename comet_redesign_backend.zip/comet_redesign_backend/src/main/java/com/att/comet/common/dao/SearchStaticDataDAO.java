package com.att.comet.common.dao;

import java.util.List;

import com.att.comet.dao.hibernate.bean.AccountClass;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.BackhaulType;
import com.att.comet.dao.hibernate.bean.DapnStatus;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.OrderStatus;

public interface SearchStaticDataDAO extends GenericCometDAO {

	public List<AccountClass> findAccountClassList();

	public AdminCategory findAccTypeListByCategoryId(Long adminCategoryId);

	public List<BackhaulType> findBackhaulTypeList();

	public List<OrderStatus> findOrderStatusList();

	public List<DapnStatus> findDapnStatusList();

	public AdminCategory findApnSizeListByCategoryId(Long adminCategoryId);

	public List<DataCenter> findDataCenterList();

	public List<String> findCompanyList();

	public List<String> findBatchIdList();
	
	public List<String> findTunnelTypeList();

}
