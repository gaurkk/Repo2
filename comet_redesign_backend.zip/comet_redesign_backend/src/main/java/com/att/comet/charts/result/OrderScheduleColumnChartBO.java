package com.att.comet.charts.result;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderScheduleColumnChartBO extends ColumnChartDisplayBO {

	private static final long serialVersionUID = -3820250475656618003L;

	public List<Map<String, String>> lstColumns = new ArrayList<Map<String, String>>();

	public List<List<String>> lstRows = new ArrayList<List<String>>();

	public List<Map<String, String>> getLstColumns() {
		return lstColumns;
	}

	public void setLstColumns(List<Map<String, String>> lstColumns) {
		this.lstColumns = lstColumns;
	}

	public List<List<String>> getLstRows() {
		return lstRows;
	}

	public void setLstRows(List<List<String>> lstRows) {
		this.lstRows = lstRows;
	}

}
