package com.att.comet.common.modal;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class OrderUserTrackerLogBO extends CometGenericBO {
	private static final long serialVersionUID = 1895464054613699546L;

	private long trackLogId;
	private long orderId;
	private String attuid;
	private long roleId;
	private String action;
	private String tabName;
	private Date accessOn;
	private String ipAddress;
	private String browser;
}
