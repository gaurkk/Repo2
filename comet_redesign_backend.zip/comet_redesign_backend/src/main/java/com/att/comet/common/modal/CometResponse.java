package com.att.comet.common.modal;

import org.springframework.stereotype.Component;

import com.att.comet.common.exception.ErrorResponse;
import com.fasterxml.jackson.annotation.JsonInclude;

@Component
public class CometResponse<T> {

	public static final String PARAM_COMET_RESPONSE = "CometResponse";
	/**
	 * A pass-through object for methods to return their "originally intended"
	 * response (because we are requiring them to return a Comet Response now)
	 */
	private T mMethodReturnValue = null;
	private Integer statusCode;
	private Status status;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String message;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ErrorResponse errorResponse;

	public enum Status {

		UNSET(999, "Will be calculated based on errors"), SUCCESS(600, "Success"), SYSTEM_ERROR(601, "System Error"),
		USER_INPUT(602, "User Input Error"), BUSINESS_ERROR(603, "Business Error"), ACCOUNT_DELETION_ERROR(604, "Account can not be deleted as order(s) are associated with this account.");

		private int code;

		private String name;

		private Status(int code, String name) {
			this.code = code;
			this.name = name;
		}

		public Integer getCode() {
			return code;
		}

		public String getName() {
			return this.name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String toString() {
			return "Status: " + this.name + "(" + this.code + ")";
		}

	};

	public T getMethodReturnValue() {
		return mMethodReturnValue;
	}

	public void setMethodReturnValue(T mMethodReturnValue) {
		this.mMethodReturnValue = mMethodReturnValue;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status success) {
		this.status = success;
	}
	
	public ErrorResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
	
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CometResponse [mMethodReturnValue=" + mMethodReturnValue + ", statusCode=" + statusCode + ", status="
				+ status + ", message=" + message + ", errorResponse=" + errorResponse + "]";
	}

	
}
