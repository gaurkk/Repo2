package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.AdminCategory;

@Repository
public interface AdminConfigRepository extends JpaRepository<AdminCategory,Long> {
	@Query("from AdminCategory Where adminCategoryId = :adminCategoryId")
	AdminCategory getAdminCategoryId(Long adminCategoryId);
}
