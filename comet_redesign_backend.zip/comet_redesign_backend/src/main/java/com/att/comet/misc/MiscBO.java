package com.att.comet.misc;


import java.util.List;

import com.att.comet.misc.bean.AccaRequestInfoBean;
import com.att.comet.misc.bean.AmpRequestInfoBean;
import com.att.comet.misc.bean.MiscOverViewInfo;
import com.att.comet.misc.bean.OtherInfoBean;
import com.att.comet.misc.bean.ProcessInfoBean;
import com.att.comet.misc.bean.RecoveryInfoBean;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MiscBO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;
	private RecoveryInfoBean recoveryInfo ;
	private OtherInfoBean otherInfo;
	private ProcessInfoBean processInfo;
	private List<String> exceptionReasonsList;
	private boolean exceptionDiv;
	private boolean iswhiteListShow;
	private boolean isIwosShow;
	private MiscOverViewInfo miscOverViewInfo;
	private AmpRequestInfoBean ampRequestInfo =  new AmpRequestInfoBean();
	private AccaRequestInfoBean accaRequestInfo = new AccaRequestInfoBean();
}
