package com.att.comet.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.dao.hibernate.bean.OrderAccount;

public interface OrderAccountRepository extends JpaRepository<OrderAccount,Long>{

}
