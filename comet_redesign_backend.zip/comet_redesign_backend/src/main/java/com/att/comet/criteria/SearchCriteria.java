package com.att.comet.criteria;

import java.io.Serializable;
import java.util.List;

import com.att.comet.restriction.Restriction;


public interface SearchCriteria extends Cloneable, Serializable{
	/**
	 * 
	 * @param restriction
	 */
	public void add(Restriction restriction);

	/**
	 * 
	 * @return
	 * @throws CloneNotSupportedException
	 */
	public SearchCriteria clone() throws CloneNotSupportedException;

	/**
	 * 
	 * @return
	 */
	public List<Restriction> getRestrictions();

	/**
	 * 
	 * @return
	 */
	public OutputFormat getFormat();

	/**
	 * 
	 * @param format
	 */
	public void setFormat(OutputFormat format);

	/**
	 * 
	 * @param other
	 */
	public void addOtherDetails(OtherDetails other);

	/**
	 * 
	 * @return
	 */
	public OtherDetails getOther();

	/**
	 * 
	 * @param baseQuery
	 */
	public void setBaseQuery(String baseQuery);

	/**
	 * 
	 * @return
	 */
	public String getBaseQuery();

	/**
	 * 
	 * @param chartName
	 */
	public void setChartName(String chartName);

	/**
	 * 
	 * @return
	 */
	public String getChartName();


}
