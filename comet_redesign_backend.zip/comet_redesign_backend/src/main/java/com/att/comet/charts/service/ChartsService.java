package com.att.comet.charts.service;

import java.util.List;

import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.criteria.SearchCriteria;

public interface ChartsService extends GenericCometService {

	/**
	 * Returns different charts data
	 * 
	 * @param SearchCriteria
	 * @return ResultBO
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public ResultBO getDataUsingCriteria(SearchCriteria searchCriterias)
			throws CometServiceException, CometDataException;

	/**
	 * Fetches all the types of backhaul in COMET
	 * 
	 * @return List<BackhaulTypeBO>
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<BackhaulTypeBO> getBHType() throws CometServiceException, CometDataException;
}
