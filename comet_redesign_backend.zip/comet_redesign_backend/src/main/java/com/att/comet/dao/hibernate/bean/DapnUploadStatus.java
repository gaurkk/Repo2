package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "dapn_upload_status")
public class DapnUploadStatus implements Serializable {

	private static final long serialVersionUID = 182441279919484392L;

	private Long lineNo;
	private String dapnId;
	private String status;
	private String errorCode;
	private Date logDate;
	private String batchId;
	private Long id;
	private String pdpName;
	private String errorField;
	private String actionField;

	@GenericGenerator(name = "generator", strategy = "sequence-identity", parameters = @Parameter(name = "sequence", value = "SEQ_DAPN_UPLOAD_STATUS"))
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GeneratedValue(generator = "generator")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "LINE_NO", nullable = false, length = 4)
	public Long getLineNo() {
		return lineNo;
	}

	public void setLineNo(Long lineNo) {
		this.lineNo = lineNo;
	}

	@Column(name = "DAPN_ID", nullable = true, length = 10)
	public String getDapnId() {
		return dapnId;
	}

	public void setDapnId(String dapnId) {
		this.dapnId = dapnId;
	}

	@Column(name = "STATUS", nullable = false, length = 10)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ERROR_CODE", nullable = false, length = 100)
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@Column(name = "LOG_DATE")
	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	@Column(name = "BATCH_ID", nullable = false, length = 20)
	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	@Column(name = "PDP_NAME", nullable = true, length = 20)
	public String getPdpName() {
		return pdpName;
	}

	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	@Column(name = "ERROR_FIELD", nullable = true, length = 100)
	public String getErrorField() {
		return errorField;
	}

	public void setErrorField(String errorField) {
		this.errorField = errorField;
	}

	@Column(name = "ACTION", nullable = true, length = 10)
	public String getActionField() {
		return actionField;
	}

	public void setActionField(String actionField) {
		this.actionField = actionField;
	}

}
