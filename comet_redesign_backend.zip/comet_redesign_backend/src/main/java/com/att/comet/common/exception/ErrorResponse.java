package com.att.comet.common.exception;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
/**
 * POJO class to provide exception message
 * @author pd6080
 *
 */
@XmlRootElement(name = "error")
public class ErrorResponse {

	public ErrorResponse(String statusCode,String status, String errorCode,Date timestamp,String message, List<String> details) {
		super();
		this.statusCode = statusCode;
		this.status = status;
		this.errorCode = errorCode;	
		this.timestamp = timestamp;
		this.message = message;
		this.details = details;
		
		
	}
		String errorCode;
		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		private String message;
		private List<String> details;
		private Date timestamp;
		private String statusCode;
		private String status;
		
		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public List<String> getDetails() {
			return details;
		}

		public void setDetails(List<String> details) {
			this.details = details;
		}

		public Date getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(Date timestamp) {
			this.timestamp = timestamp;
		}

		public String getStatusCode() {
			return statusCode;
		}

		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		
	}