package com.att.comet.manage.modal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class ImsiMsisdnCSVLineBO extends LineBO{
	private static final long serialVersionUID = 1L;
	private String dataCenterName;
	private String actionField;
	private String Imsi;
	private String Msisdn;
	private int recordNumber;

}
