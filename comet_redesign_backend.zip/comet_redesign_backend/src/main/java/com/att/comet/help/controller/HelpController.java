package com.att.comet.help.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.charts.modal.UserInfoBO;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.help.modal.HelpContentBO;
import com.att.comet.help.service.HelpService;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.user.modal.RoleEnum;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class HelpController {
	
	private static final Logger logger = LoggerFactory.getLogger(HelpController.class);

	@Autowired
	UserHelper userHelper;
	
	@Autowired
	HelpService helpService;
	
	private final String ERROR_STRING = "User not allowed to perform this operation";
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/help/contents", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets all help contents", notes = "Return all the help content IDs and values")
	public CometResponse<Map<Long, String>> getHelpContents(Authentication authentication) {
		logger.debug("HelpController::getAllContentIds Getting all help contents");
		
		CometResponse<Map<Long, String>> cometResponse = new CometResponse<Map<Long, String>>();
		Map<Long, String> contentsMap = null;
		
		try {
			contentsMap = helpService.prepareHelpContents();
			
			if (null == contentsMap) {
				logger.debug("No help contents are available in COMET DB");
			}
			cometResponse.setMethodReturnValue(contentsMap);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(contentsMap);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/help/{contentId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets help details for given id", notes = "Return the help info for given contentId")
	public CometResponse<HelpContentBO> getHelpById(@PathVariable("contentId") Long contentId, Authentication authentication) {
		logger.info("Starting method getHelpById : ", this);
		
		CometResponse<HelpContentBO> cometResponse = new CometResponse<HelpContentBO>();
		HelpContentBO helpContentBO = null;
		
		try {
			helpContentBO = helpService.getHelpForId(contentId);
			
			if (null == helpContentBO) {
				logger.debug("No help information found for contentId : " + contentId);
			}
			cometResponse.setMethodReturnValue(helpContentBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(helpContentBO);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method getHelpById : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "/help/update", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE }, 
					produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Updates help details for given id", notes = "Updates the help info for given contentId")
	public CometResponse<Boolean> updateHelp(@RequestParam(value = "contentId", required = true) Long contentId,
											@RequestParam(value = "content", required = false) String content,
											@RequestParam(value = "file", required = false) MultipartFile file,
											@RequestParam(value = "isAttachFileUpdated", required = false, defaultValue = "true") boolean isAttachFileUpdated,
											Authentication authentication) 
											throws CometException {
		logger.info("Starting method updateHelp : ", this);
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<Boolean> cometResponse = new CometResponse<Boolean>();
		Boolean isSuccessfulUpdate = false;
		
		try {
			if (userInfoBO.getRoleId() != RoleEnum.COMET_ADMIN.getRoleId()) {
				throw new CometException(ERROR_STRING);
			}
			
			HelpContentBO helpContentBO = new HelpContentBO();
			helpContentBO.setContentId(contentId);
			helpContentBO.setContent(content);
			helpContentBO.setUpdatedBy(userInfoBO.getAttuid());
			
			if (null != file) {
				helpContentBO.setAttachmentName(file.getOriginalFilename());
			} 
			
			isSuccessfulUpdate = helpService.updateHelp(helpContentBO, file, isAttachFileUpdated);
			
			if (null == isSuccessfulUpdate) {
				throw new CometException("Something wrong happened during help update; please retry again");
			}
			cometResponse.setMethodReturnValue(isSuccessfulUpdate);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(false);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method updateHelp : ", this);
		return cometResponse;
	}

}
