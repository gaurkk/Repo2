package com.att.comet.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class UnAuthorizedUserException extends RuntimeException {

	private static final long serialVersionUID = 4611652614561409259L;

	public UnAuthorizedUserException(String message) {
		super(message);
	}

}