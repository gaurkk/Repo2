package com.att.comet.account.modal;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper=true)
public class OrderCapacityForecastBO extends CometGenericBO {

	private static final long serialVersionUID = -2028733408947964334L;
	private Long orderId;
	private Short year;
	private String subscribedDevicesOnATTInfrastructure;
	private String peakPercentOfDevicesWithConcurrentActivePDPCtxForcast;
	private String speedPerMonthPerSubscriber;
	private String peakPercentDevicesWithConcurrentActivePDPCtxCalculated;
	private String peakConcurrentActivePDPCtxTotal;
	private String peakConcurrentActivePDPCtxPerNDC;
	private String peakWANBandwidthTotalAllNDC;
	private String peakPDPCtxActivationsPerSecondsNDC;
	private String totalSMSWakeupsPerMonth;
	private String totalSMSWakeupsPerSecondPeak;
}
