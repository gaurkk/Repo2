package com.att.comet.charts.result;

import java.io.Serializable;

public interface DisplayResultBO extends Serializable {
	// Marker interface to show fetched result

}
