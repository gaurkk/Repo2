package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class StaticYesOrNoBO extends CometGenericBO{

	private static final long serialVersionUID = -5631773724968527348L;
	private int staticYesorNoId;
	private String staticYesorNoName;
}
