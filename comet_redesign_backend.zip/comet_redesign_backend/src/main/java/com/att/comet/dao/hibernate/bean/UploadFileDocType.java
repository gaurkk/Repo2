package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "UPLOAD_FILE_DOC_TYPE")
public class UploadFileDocType {

	@Id
	@Column(name="UPLOAD_FILE_TYPE_DOC_ID",unique = true, nullable = false)
	private String uploadFileTypeId;
	
	@Column(name = "UPLOAD_FILE_TYPE_NAME", length = 100)
	private String uploadFileTypeName;
	
}
