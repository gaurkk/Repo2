package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class of APN_CUSTOMER_RADIUS. Mapped with APN_CUSTOMER_RADIUS
 * table of database.
 */
@Entity
@Table(name = "APN_CUSTOMER_RADIUS")
public class ApnCustomerRadius implements Serializable {

	private static final long serialVersionUID = 6526255383667773526L;

	private Long apnCustomerRadiusId;
	private ApnRadius apnRadius;
	private String customerRadIpAddress;
	private String customerRadName;
	private String customerRadSharedSecret;

	/**
	 * Getter method for apnCustomerRadiusId. APN_CUSTOMER_RADIUS_ID mapped to
	 * APN_CUSTOMER_RADIUS_ID in the database.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "APN_CUSTOMER_RADIUS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_APN_CUSTOMER_RADIUS_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_APN_CUSTOMER_RADIUS_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_APN_CUSTOMER_RADIUS_ID")
	public Long getApnCustomerRadiusId() {
		return this.apnCustomerRadiusId;
	}

	/**
	 * @param apnCustomerRadiusId
	 *            to apnCustomerRadiusId set.
	 */
	public void setApnCustomerRadiusId(Long apnCustomerRadiusId) {
		this.apnCustomerRadiusId = apnCustomerRadiusId;
	}

	/**
	 * Getter method for ApnRadius.
	 * 
	 * @return ApnRadius
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns( {
			@JoinColumn(name = "ORDER_ID", referencedColumnName = "ORDER_ID", nullable = false),
			@JoinColumn(name = "DATA_CENTER_ID", referencedColumnName = "DATA_CENTER_ID", nullable = false) })
	public ApnRadius getApnRadius() {
		return this.apnRadius;
	}

	/**
	 * @param apnRadius
	 *            to apnRadius set.
	 */
	public void setApnRadius(ApnRadius apnRadius) {
		this.apnRadius = apnRadius;
	}

	/**
	 * Getter method for customerRadIpAddress CUSTOMER_RAD_IP_ADDRESS mapped to
	 * CUSTOMER_RAD_IP_ADDRESS in database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUSTOMER_RAD_IP_ADDRESS", length = 100)
	public String getCustomerRadIpAddress() {
		return this.customerRadIpAddress;
	}

	/**
	 * @param customerRadIpAddress
	 *            to customerRadIpAddress set.
	 */
	public void setCustomerRadIpAddress(String customerRadIpAddress) {
		this.customerRadIpAddress = customerRadIpAddress;
	}

	/**
	 * Getter method for customerRadName. CUSTOMER_RAD_NAME mapped to
	 * CUSTOMER_RAD_NAME in database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUSTOMER_RAD_NAME", length = 100)
	public String getCustomerRadName() {
		return this.customerRadName;
	}

	/**
	 * @param customerRadName
	 *            to customerRadName set.
	 */
	public void setCustomerRadName(String customerRadName) {
		this.customerRadName = customerRadName;
	}

	
	/**
	 * Getter method for customerRadSharedSecret. CUSTOMER_RAD_SHARED_SECRET
	 * mapped to CUSTOMER_RAD_SHARED_SECRET in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUSTOMER_RAD_SHARED_SECRET", length = 100)
	public String getCustomerRadSharedSecret() {
		return this.customerRadSharedSecret;
	}

	/**
	 * @param customerRadSharedSecret
	 *            to customerRadSharedSecret set.
	 */
	public void setCustomerRadSharedSecret(String customerRadSharedSecret) {
		this.customerRadSharedSecret = customerRadSharedSecret;
	}
}