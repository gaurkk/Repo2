package com.att.comet.apn;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This BO holds Orders PDP ID's Info
 * @author pd6080
 *
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class PdpIdInfoBO implements Serializable ,  Comparable<PdpIdInfoBO>{

	private static final long serialVersionUID = 6497170419024011921L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long pdpId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long autoPdpId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long userPdpId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character basicPdpId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String autoPdpName;
	
		public int compareTo(PdpIdInfoBO pdpIdInfo) {
		int retrunVal = -1;
		if(this.autoPdpId != null && pdpIdInfo.autoPdpId!= null ) {
			retrunVal = this.autoPdpId.compareTo(pdpIdInfo.autoPdpId);
		}
		return retrunVal;
	}
}