package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for SolutionSummary. Mapped to SOLUTION_SUMMARY table in the
 * database.
 */
@Entity
@Table(name = "SOLUTION_SUMMARY")
public class SolutionSummary implements Serializable {

	private static final long serialVersionUID = 7736272716456269722L;

	private Long ssId;
	private Orders orders;
	private Role role;
	private Character isOsd;
	private Users createdBy;
	private Date createdOn;
	private Users updatedBy;
	private Date updatedOn;
	private String comments;
	private Character isMigrationNotes;

	/**
	 * Getter method for ssId. SS_ID mapped to SS_ID in the database table. The
	 * sequence used to generate the ssId is SEQ_SOLUTION_SUMMARY_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "SS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_SOLUTION_SUMMARY_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_SOLUTION_SUMMARY_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SOLUTION_SUMMARY_ID")
	public Long getSsId() {
		return ssId;
	}

	/**
	 * @param ssId to ssId set.
	 */
	public void setSsId(Long ssId) {
		this.ssId = ssId;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for role.
	 * 
	 * @return Role
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false)
	public Role getRole() {
		return role;
	}

	/**
	 * @param role to role set.
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * Getter method for isOsd. IS_OSD mapped to IS_OSD in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "IS_OSD", length = 1)
	public Character getIsOsd() {
		return isOsd;
	}

	/**
	 * @param isOsd to isOsd set.
	 */
	public void setIsOsd(Character isOsd) {
		this.isOsd = isOsd;
	}

	/**
	 * Getter method for createdBy.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATED_BY", nullable = false)
	public Users getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy to createdBy set.
	 */
	public void setCreatedBy(Users createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedBy.
	 * 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UPDATED_BY", nullable = false)
	public Users getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy to updatedBy set.
	 */
	public void setUpdatedBy(Users updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the isMigrationNotes
	 */
	@Column(name = "IS_MIGRATION_NOTES", length = 1)
	public Character getIsMigrationNotes() {
		return isMigrationNotes;
	}

	/**
	 * @param isMigrationNotes the isMigrationNotes to set
	 */
	public void setIsMigrationNotes(Character isMigrationNotes) {
		this.isMigrationNotes = isMigrationNotes;
	}

}