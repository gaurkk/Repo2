package com.att.comet.manage.modal;

import java.util.Comparator;

import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class DapnUploadStatusBO implements Comparator<DapnUploadStatusBO>{
	String dapnId;
	String pdpName;
	String message;
	String messageType;
	Long lineNo;
	
	@Override
	public int compare(DapnUploadStatusBO o1, DapnUploadStatusBO o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
