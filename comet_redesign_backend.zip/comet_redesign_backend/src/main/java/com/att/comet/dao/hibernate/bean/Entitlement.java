package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for Entitlement. Mapped to ENTITLEMENT table in the
 * database.
 */
@Entity
@Table(name = "ENTITLEMENT")
public class Entitlement implements Serializable {

	private static final long serialVersionUID = 8652902782623375342L;

	private EntitlementId id;
	private Resources resources;
	private Role role;
	private Character required;
	private Character editable;

	/**
	 * Getter method for id.
	 * 
	 * @return EntitlementId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "resourceId", column = @Column(name = "RESOURCE_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "roleId", column = @Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)) })
	public EntitlementId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(EntitlementId id) {
		this.id = id;
	}

	/**
	 * Getter method for resources.
	 * 
	 * @return Resources
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RESOURCE_ID", nullable = false, insertable = false, updatable = false)
	public Resources getResources() {
		return this.resources;
	}

	/**
	 * @param resources to resources set.
	 */
	public void setResources(Resources resources) {
		this.resources = resources;
	}

	/**
	 * Getter method for role.
	 * 
	 * @return Role
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false, insertable = false, updatable = false)
	public Role getRole() {
		return this.role;
	}

	/**
	 * @param role to role set.
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * Getter method for required. REQUIRED mapped to REQUIRED in the database
	 * table.
	 * 
	 * @return Character
	 */
	@Column(name = "REQUIRED", length = 1)
	public Character getRequired() {
		return this.required;
	}

	/**
	 * @param required to required set.
	 */
	public void setRequired(Character required) {
		this.required = required;
	}

	/**
	 * Getter method for editable. EDITABLE mapped to EDITABLE in the database
	 * table.
	 * 
	 * @return Character
	 */
	@Column(name = "EDITABLE", length = 1)
	public Character getEditable() {
		return editable;
	}

	/**
	 * @param editable to editable set.
	 */
	public void setEditable(Character editable) {
		this.editable = editable;
	}

}