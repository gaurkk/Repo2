package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderWorkStepId.
 */
@Embeddable
public class BpmOrderWorkStepId implements Serializable {

	private static final long serialVersionUID = 5908778317485394867L;

	private Long workStepId;
	private Long orderId;
	private Long orderTypeId;

	/**
	 * Getter method workStepId. WORK_STEP_ID mapped to WORK_STEP_ID in the database
	 * table.
	 * 
	 * @return Long.
	 */
	@Column(name = "WORK_STEP_ID", nullable = false, precision = 22, scale = 0)
	public Long getWorkStepId() {
		return this.workStepId;
	}

	/**
	 * @param workStepId to workStepId set.
	 */
	public void setWorkStepId(Long workStepId) {
		this.workStepId = workStepId;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long.
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderWorkStepId))
			return false;
		BpmOrderWorkStepId castOther = (BpmOrderWorkStepId) other;

		return ((this.getWorkStepId() == castOther.getWorkStepId()) || (this.getWorkStepId() != null
				&& castOther.getWorkStepId() != null && this.getWorkStepId().equals(castOther.getWorkStepId())))
				&& (this.getOrderId() == castOther.getOrderId())
				&& (this.getOrderTypeId() == castOther.getOrderTypeId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (getWorkStepId() == null ? 0 : this.getWorkStepId().hashCode());
		result = 37 * result + (int) this.getOrderId().intValue();
		result = 37 * result + (int) this.getOrderTypeId().intValue();
		return result;
	}
}