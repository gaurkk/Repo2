package com.att.comet.criteria;

import java.io.Serializable;

public class OtherDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6442077722746666754L;
	private String userId;
	private Long roleId;
	private int pageNumber;
	private int maxCount;

	public OtherDetails() {
		userId = "";
		roleId = 0l;
		pageNumber = 1;
		maxCount = 1000;
	}

	public OtherDetails(String userId, Long roleId, int pageNumber, int maxCount) {
		this.userId = userId;
		this.roleId = roleId;
		this.pageNumber = pageNumber;
		this.maxCount = maxCount;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the pageNumber
	 */
	public int getPageNumber() {
		return pageNumber;
	}

	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	/**
	 * @return the maxCount
	 */
	public int getMaxCount() {
		return maxCount;
	}

	/**
	 * @param maxCount the maxCount to set
	 */
	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

}
