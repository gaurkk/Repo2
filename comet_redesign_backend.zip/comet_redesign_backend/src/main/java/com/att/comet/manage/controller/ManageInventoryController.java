package com.att.comet.manage.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.manage.modal.InventoryBO;
import com.att.comet.manage.modal.InventoryTemplateBO;
import com.att.comet.manage.modal.ManageInvetoryDownloadBO;
import com.att.comet.manage.modal.ParseResultBO;
import com.att.comet.manage.service.ManageService;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.user.exception.UserException;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ManageInventoryController {

	Logger logger = LoggerFactory.getLogger(ManageInventoryController.class);

	@Autowired
	ManageService manageService;

	@Autowired
	UserHelper userHelper;
	
	@Secured({"ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@GetMapping(value = "manage/inventoryInfo/{dataCenterId}/{templateName}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get Available & Assigned inventory info", notes = "Get Available & Assigned inventory info")
	public CometResponse<List<InventoryBO>> getInventoryInfo(@PathVariable Long dataCenterId , @PathVariable String templateName)
			throws RecordNotFoundException, UserException, UnsupportedEncodingException {
		logger.info("[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] "
				+ "Starting method getInventoryInfo :", this);
		CometResponse<List<InventoryBO>> cometResponse = new CometResponse<List<InventoryBO>>();
		List<InventoryBO> inventoryBOList = null;
		try {
			inventoryBOList = manageService.getInventoryInfo(dataCenterId,templateName);

			if (!CollectionUtils.isEmpty(inventoryBOList)) {
				cometResponse.setMethodReturnValue(inventoryBOList);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] "
				+ "Exiting method getInventoryInfo :", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/manage/inventory/{inventory}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Download template file ", notes = "Download template file")
	public ResponseEntity<ByteArrayResource> downloadManageInventoryTemplate(@PathVariable String inventory)
			throws CometDataException {
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Starting method downloadManageInventoryTemplate.");
		ManageInvetoryDownloadBO manageInvetoryDownloadBO = null;
		try {
			manageInvetoryDownloadBO = manageService.downloadManageInventoryTemplate(inventory);
			if (null != manageInvetoryDownloadBO) {
				String fileType = manageInvetoryDownloadBO.getTemplateContentType();
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(fileType))
						.header(HttpHeaders.CONTENT_DISPOSITION,
								"attachment; filename=\"" + manageInvetoryDownloadBO.getTemplateFileName() + "\"")
						.body(new ByteArrayResource(manageInvetoryDownloadBO.getTemplateAttachment()));
			}
		} catch (IOException e) {
			logger.error("[Inventory : " + (inventory == null ? "" : inventory) + "] "
					+ "IOException Getting Download Inventory Template File " + e);
		}
		logger.info("[Inventory : " + (inventory == null ? "" : inventory) + "] "
				+ "Exiting method downloadManageInventoryTemplate.");
		return null;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/manage/getInventoryNameList", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find all inventory names", notes = "Returns all distinct inventory names")
	public CometResponse<List<StaticDataBO>> getInventoryNameList() throws CometDataException {
		logger.info("Starting method getInventoryNameList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> inventoryClass = new ArrayList<StaticDataBO>();
		List<InventoryTemplateBO> inventoryTemplateBOList = manageService.getInventoryNameList();
		if (!CollectionUtils.isEmpty(inventoryTemplateBOList)) {
			List<KeyValueBO> keyValueList = inventoryTemplateBOList.stream()
					.map(bo -> new KeyValueBO(bo.getTemplateName(), bo.getTemplateName()))
					.collect(Collectors.toList());
			inventoryClass.add(new StaticDataBO(CometCommonConstant.INVENTORY_TEMPLATE_NAME, keyValueList));
		}
		cometResponse.setMethodReturnValue(inventoryClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getInventoryNameList : ", this);
		return cometResponse;
	}
	
	@Secured({"ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "manage/uploadManageInventory",consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE },headers = "X-API-VERSION=1")
	@ApiOperation(value = "Upload Manage Inventory Template", notes = "Upload Manage Inventory Template")
	public CometResponse<ParseResultBO> uploadManageInventory(@RequestParam("file") MultipartFile file, @RequestParam("isActivated") String isActivated, Authentication authentication)throws CometDataException, IOException  {
		logger.info("Starting method uploadManageInventory :", this);
		CometResponse<ParseResultBO> cometResponse = new CometResponse<ParseResultBO>();
		logger.info(
				"User::" + userHelper.getUserInfo(authentication).getAttuid() + ":",this);
		ParseResultBO resultBO = manageService.uploadManageInventory(file,isActivated,userHelper.getUserInfo(authentication).getAttuid());
		if(null!=resultBO && null==resultBO.getInvalidFileMesage()) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(resultBO);
		}else if(null!=resultBO.getInvalidFileMesage()) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			cometResponse.setMethodReturnValue(resultBO);
		}else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method uploadManageInventory :", this);
		return cometResponse;
	}

}
