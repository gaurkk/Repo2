package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import lombok.Data;

/**
 * Persistent class for Orders. Mapped to ORDERS table in the database.
 */
@Entity
@Table(name = "ORDERS")
@Data
public class Orders implements Serializable {

	private static final long serialVersionUID = 1776647983510711028L;
	@Id
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ORDER_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_ORDER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ORDER_ID")
	private Long orderId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CREATED_BY")
	private Users createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CIPN")
	private InternalProductAccount internalProductAccount;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_STATUS_ID", nullable = false)
	private OrderStatus orderStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "UPDATED_BY", nullable = false)
	private Users updatedBy;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "BCID")
	private SubAccount subAccount;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_TYPE_ID", nullable = false)
	private OrderType orderType;

	@Column(name = "NUM_DATA_CENTERS", precision = 2, scale = 0)
	private Long numDataCenters;

	@Column(name = "APN_SELECTION", length = 20)
	private String apnSelection;

	@Column(name = "BACKHAUL_SELECTION", length = 20)
	private String backhaulSelection;

	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "SUBMITTED_ON")
	private Date submittedOn;

	@Column(name = "UPDATED_ON")
	private Date updatedOn;

	@Column(name = "DERIVED_FROM_ORDER", precision = 12, scale = 0)
	private Long derivedFromOrder;

	@Lob
	@Column(name = "RECOVERY_FLOW_CHART", length = 100)
	private byte[] recoveryFlowChart;

	@Column(name = "RECOVERY_FLOW_CHART_FILENAME", length = 100)
	private String recoveryFlowChartFilename;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<OrderStatusHistory> orderStatusHistories = new HashSet<OrderStatusHistory>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<OrderDataCenterBackhaul> orderDataCenterBackhauls = new HashSet<OrderDataCenterBackhaul>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<OrderDataCenter> orderDataCenters = new HashSet<OrderDataCenter>(0);

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	private Apn apn;

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	private OrderAccount orderAccount;

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	private OrderContact orderContact;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<Vpn> vpns = new HashSet<Vpn>(0);

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	private OrderExpedite orderExpedite;

	@Column(name = "EXPEDITE", length = 1)
	private Character expedite;

	@Column(name = "EXCEPTIONAL", length = 1)
	private Character exceptional;

	@Column(name = "BASE_ORDER", length = 1)
	private Character baseOrder;

	@Column(name = "BASE_ORDER_NOTES", length = 3500)
	private String baseOrderNotes;

	@Column(name = "COMMENTS", length = 3500)
	private String comments;

	@Column(name = "CHANGE_REQUEST", length = 1)
	private Character changeRequest;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_INITIATOR")
	private Users orderInitiator;

	@Column(name = "CUS_PREF_DC_COMMENTS", length = 3500)
	private String customerPrefDCComments;

	@Column(name = "LTE_SWEEP", length = 100)
	private String lteSweep;

	@Column(name = "CANCEL_ORDER", length = 1)
	private Character cancelRequest;

	@Column(name = "CR_FLAG", length = 1)
	private Character crFlag;

	@Lob
	@Column(name = "IP_SEC_LETTER", length = 100)
	private byte[] ipSecLetterAttachment;

	@Column(name = "IP_SEC_LETTER_FILENAME", length = 100)
	private String ipSecLetterAttachmentName;

	@Column(name = "DATE_IN_PRODUCTION")
	private Date dateInProduction;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<OrderUserTrackerLog> orderUserTrackerLogs = new HashSet<OrderUserTrackerLog>(0);

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "orders")
	private Set<OrderFlagsDetails> orderFlagsDetails = new HashSet<OrderFlagsDetails>(0);

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "orders")
	private InfraGiInformation infraGiInformation;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orders")
	private Set<ExternalInterfaceDetails> extIntDetails = new HashSet<ExternalInterfaceDetails>(0);

	@Column(name = "FIRSTNET_EPC", length = 1)
	private Character firstNetEpc;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmTask")
	private List<OrderUserBpmTasks> orderUserBpmTasksList = new ArrayList<>();
	
	@Column(name = "SHOW_CRD")
	private String showCrd;

}