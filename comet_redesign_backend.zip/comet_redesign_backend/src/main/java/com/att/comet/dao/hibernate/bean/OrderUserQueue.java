package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
//import java.util.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_USER_QUEUE")
public class OrderUserQueue implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4185719562718579718L;

	private long queueId;
	private long orderId;
	private String attuid;
	private long priorityNbr;
	private String histryFlg;
	private String accName;
	private String apnName;
	private String orderType;
	private String orderStatus;
	private String orderLockedby;
	private String lockReqBy;
	private Timestamp userStartTime;
	private Timestamp userEndTime;
	private String currentlyWorking;

	public OrderUserQueue() {

	}

	@Id
	@Column(name = "QUEUE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_USER_QUEUE", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_USER_QUEUE") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_USER_QUEUE")
	public long getQueueId() {
		return queueId;
	}

	public void setQueueId(long queueId) {
		this.queueId = queueId;
	}

	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "ATTUID", nullable = false, length = 6)
	public String getAttuid() {
		return attuid;
	}

	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	@Column(name = "PRIORITY_NBR")
	public long getPriorityNbr() {
		return priorityNbr;
	}

	public void setPriorityNbr(long priorityNbr) {
		this.priorityNbr = priorityNbr;
	}

	@Column(name = "HISTORY_FLAG", nullable = false, length = 2)
	public String getHistryFlg() {
		return histryFlg;
	}

	public void setHistryFlg(String histryFlg) {
		this.histryFlg = histryFlg;
	}

	@Column(name = "ACC_NAME")
	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}

	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	@Column(name = "ORDER_TYPE")
	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Column(name = "ORDER_STATUS")
	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Column(name = "ORDER_LOCKED_BY")
	public String getOrderLockedby() {
		return orderLockedby;
	}

	public void setOrderLockedby(String orderLockedby) {
		this.orderLockedby = orderLockedby;
	}

	@Column(name = "LOCK_REQUESTED_BY")
	public String getLockReqBy() {
		return lockReqBy;
	}

	public void setLockReqBy(String lockReqBy) {
		this.lockReqBy = lockReqBy;
	}

	@Column(name = "USER_START_TIME")
	public Timestamp getUserStartTime() {
		return userStartTime;
	}

	public void setUserStartTime(Timestamp userStartTime) {
		this.userStartTime = userStartTime;
	}

	@Column(name = "USER_END_TIME")
	public Timestamp getUserEndTime() {
		return userEndTime;
	}

	public void setUserEndTime(Timestamp userEndTime) {
		this.userEndTime = userEndTime;
	}

	@Column(name = "CURRENTLY_WORKING", length = 2)
	public String getCurrentlyWorking() {
		return currentlyWorking;
	}

	public void setCurrentlyWorking(String currentlyWorking) {
		this.currentlyWorking = currentlyWorking;
	}

}
