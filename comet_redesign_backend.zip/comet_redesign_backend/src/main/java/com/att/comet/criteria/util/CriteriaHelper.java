/**
 * 
 */
package com.att.comet.criteria.util;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.charts.dao.ChartsDAOImpl;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.SearchCriteriaImpl;
import com.att.comet.criteria.TaskRole;
import com.att.comet.criteria.TaskStatus;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.order.OrderAPNStatusRestriction;
import com.att.comet.restriction.order.OrderActivePassiveRestriction;
import com.att.comet.restriction.order.OrderBHTypeRestriction;
import com.att.comet.restriction.order.OrderDataCenterRestriction;
import com.att.comet.restriction.order.OrderDateRestriction;
import com.att.comet.restriction.order.OrderGeoRestriction;
import com.att.comet.restriction.order.OrderInProductionYearRestriction;
import com.att.comet.restriction.order.OrderMarketSegmentRestriction;
import com.att.comet.restriction.order.OrderProgressNoRestriction;
import com.att.comet.restriction.order.OrderRoleAssignRestriction;
import com.att.comet.restriction.order.OrderScheduleRestriction;
import com.att.comet.restriction.order.OrderStatusRestriction;
import com.att.comet.restriction.order.OrderTTUIWOSAttuIdRestriction;
import com.att.comet.restriction.order.OrderTTUIWOSDateRestriction;
import com.att.comet.restriction.order.OrderTypeRestriction;
import com.att.comet.restriction.task.TaskApnNameRestriction;
import com.att.comet.restriction.task.TaskDateRestriction;
import com.att.comet.restriction.task.TaskExpediteRestriction;
import com.att.comet.restriction.task.TaskNameRestriction;
import com.att.comet.restriction.task.TaskNoRestriction;
import com.att.comet.restriction.task.TaskOpenReminderRestriction;
import com.att.comet.restriction.task.TaskOrderApnIdRestriction;
import com.att.comet.restriction.task.TaskOwnerRestriction;
import com.att.comet.restriction.task.TaskRoleRestriction;
import com.att.comet.restriction.task.TaskStatusCriteria;
import com.att.comet.restriction.task.TaskStatusRestriction;

@Service
public class CriteriaHelper {
	@Autowired
	static SearchCriteria criteria;

	@Autowired
	private List<CriteriaRenderer> listRenderers;

	private static final Logger logger = LoggerFactory.getLogger(ChartsDAOImpl.class);

	@Transactional
	public ResultBO getOutput(SearchCriteria criteria) throws Exception {
		logger.info("Starting method getOutput : ", this);

		if (criteria.getRestrictions().size() == 0) {
			throw new Exception("No Criteria Found");
		}
		CriteriaRenderer renderer = null;
		switch (criteria.getFormat()) {
		case GRID:
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		case PIE_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof PieChartCriteriaRenderer).findFirst().get();
			break;
		case BAR_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof BarChartCriteriaRenderer).findFirst().get();
			break;
		case STACKED_COLUMN_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof StackedColumnChartCriteriaRenderer)
					.findFirst().get();
			break;
		case COLUMN_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof ColumnChartCriteriaRenderer).findFirst()
					.get();
			break;
		case LINE_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof LineChartCriteriaRenderer).findFirst().get();
			break;
		default:
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		}
		ResultBO result = renderer.getOutput(criteria);
		logger.info("Exiting method getOutput : ", this);
		return result;
	}

	/**
	 * Get the object of Search Criteria
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria() throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl() : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format) : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format and other
	 * details
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format, OtherDetails other) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format, other) : criteria.clone());
	}

	/**
	 * Add Market segment as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction marketSegment(String propertyValue) {
		return new OrderMarketSegmentRestriction(propertyValue);
	}

	/**
	 * Add Order Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction orderType(Long propertyValue) {
		return new OrderTypeRestriction(propertyValue);
	}

	/**
	 * Add Month\Year restriction to result
	 * 
	 * @param month
	 * @param year
	 * @return Restriction
	 */
	public static Restriction date(String month, String year) {
		return new OrderDateRestriction(month, year);
	}

	/**
	 * Get Initial data to result
	 * 
	 * @return Restriction
	 */
	public static Restriction initalData() {
		return new OrderProgressNoRestriction();
	}
	
	/**
	 * Get Task Initial data to result
	 * 
	 * @return Restriction
	 */
	public static Restriction taskInitalData() {
		return new TaskNoRestriction();
	}

	/**
	 * Add role restriction to result
	 * 
	 * @param role
	 * @return Restriction
	 */
	public static Restriction orderAssignment(Long role) {
		return new OrderRoleAssignRestriction(role);
	}

	/**
	 * Add schedule restriction to result
	 * 
	 * @param schedule
	 * @return Restriction
	 */
	public static Restriction schedule(String schedule) {
		return new OrderScheduleRestriction(schedule);
	}

	/**
	 * Add In production order Year restriction to result
	 * 
	 * @param year
	 * @return Restriction
	 */
	public static Restriction inProductionYear(String year) {
		return new OrderInProductionYearRestriction(year);
	}

	/**
	 * Add Task owner restriction to result
	 * 
	 * @param owner
	 * @return Restriction
	 */
	public Restriction taskOwner(String owner) {
		return new TaskOwnerRestriction(owner);
	}

	/**
	 * Add Task status restriction to result
	 * 
	 * @param statuses
	 * @return Restriction
	 */
	public Restriction taskStatuses(List<TaskStatus> statuses) {
		return new TaskStatusRestriction(statuses);
	}

	/**
	 * Add Open Reminder restriction to result
	 * 
	 * @param flag
	 * @return Restriction
	 */
	public Restriction taskOpenReminder(boolean flag) {
		return new TaskOpenReminderRestriction(flag);
	}

	/**
	 * Add task creation date restriction to result
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return Restriction
	 * @throws CometDataException
	 */
	public Restriction taskCreationDate(String fromDate, String toDate) {/// throws CometDataException {
		return new TaskDateRestriction(fromDate, toDate);
	}

	/**
	 * Add Order id restriction to result
	 * 
	 * @param orderId
	 * @return Restriction
	 */
	public Restriction taskOrderId(Long orderId) {
		return new TaskOrderApnIdRestriction(orderId);
	}

	/**
	 * Add APN id restriction to result
	 * 
	 * @param apnId
	 * @return Restriction
	 */
	public static Restriction taskApnId(Long apnId) {
		return new TaskOrderApnIdRestriction(apnId);
	}

	/**
	 * Add Order\APN id restriction to result
	 * 
	 * @param orderApnId
	 * @return Restriction
	 */
	public static Restriction taskOrderApnId(Long orderApnId) {
		return new TaskOrderApnIdRestriction(orderApnId);
	}

	/**
	 * Add User role restriction to result
	 * 
	 * @param role
	 * @return Restriction
	 */
	public Restriction taskRole(TaskRole role) {
		return new TaskRoleRestriction(role);
	}

	/**
	 * Add task name restriction to result
	 * 
	 * @param name
	 * @return Restriction
	 */
	public Restriction taskId(Long id) {
		return new TaskNameRestriction(id);
	}

	/**
	 * Add expedite restriction to result
	 * 
	 * @param expedite
	 * @return Restriction
	 */
	public Restriction taskExpedite(boolean expedite) {
		return new TaskExpediteRestriction(expedite);
	}

	/**
	 * Add Order Status as a restriction to result
	 * 
	 * @param orderStatus
	 * @return Restriction
	 */
	public static Restriction orderStatus(String orderStatus) {
		return new OrderStatusRestriction(orderStatus);
	}

	/**
	 * Add Order date as a restriction to result
	 * 
	 * @param orderStatus
	 * @return Restriction
	 */
	public static Restriction orderTTUIWOSDate(String date) {
		return new OrderTTUIWOSDateRestriction(date);
	}

	/**
	 * Add Order TTU and IWOS AttuId as a restriction to result
	 * 
	 * @param orderStatus
	 * @return Restriction
	 */
	public static Restriction orderTTUIWOSAttuId(String selectedAttuId, String loginAttuId) {
		return new OrderTTUIWOSAttuIdRestriction(selectedAttuId, loginAttuId);
	}

	/**
	 * Add Apn Status as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction apnStatus(String propertyValue) {
		return new OrderAPNStatusRestriction(propertyValue);
	}

	/**
	 * Add Active Passive DC as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction activePassive(String propertyValue) {
		return new OrderActivePassiveRestriction(propertyValue);
	}

	/**
	 * Add Backhaul Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction bhType(String propertyValue) {
		return new OrderBHTypeRestriction(propertyValue);
	}

	/**
	 * Add Geo as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction geo(String propertyValue) {
		return new OrderGeoRestriction(propertyValue);
	}

	/**
	 * Add selected data center as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction dataCenter(String propertyValue) {
		return new OrderDataCenterRestriction(propertyValue);
	}
	
	public Restriction taskStatus(String status) {
		return new TaskStatusCriteria(status);
	}
	
	/**
	 * Add APN Name restriction to result
	 * 
	 * @param apnId
	 * @return Restriction
	 */
	public Restriction taskApnName(String apnId) {
		return new TaskApnNameRestriction(apnId);
	}
	
	public String escapeCharacterForSql(String str){ 
		  String finalSql = null; 
		  if (str != null && str.length() > 0) { 
		    str = str.replace("'", "''"); 
		    str = str.replace("&", "'||'&'||'"); 
		    finalSql = str; 
		  } 
		return finalSql; 
		 
		}
}
