package com.att.comet.apn;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApnSectionBasicInfo {

	private String sectionName ;
	private String apnName;
	private Long orderId;
	private Character migratedOrder = 'N';
	private Character managedAvpn= 'N';
	private Character ipbr = 'N';//PMIP 	
	private Character firstNet = 'N';
	private Character ccsmx= 'N';//CCS-MX Router
	private Character overRideCcsMx= 'N';//Override CCSMX
	private Character overRidePdp= 'N';	
	private Character msp= 'N';
	private Character mspEntAndMms= 'N';
	private Character turboAppSupport = 'N';	
	private Character overRide= 'N';
	private Character noFirewall= 'N';
	private String whitelistBlacklist;	
	private String provisioningMethod;
	private Character pacl = 'N';
	private Character PaclEnabled;
	private List<PdpIdInfoBO> pdpIdInfoBOList;
	private DataCenterDetails dataCenterDetails;	

}
