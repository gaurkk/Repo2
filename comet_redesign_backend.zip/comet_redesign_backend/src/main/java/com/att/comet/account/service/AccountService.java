package com.att.comet.account.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.web.multipart.MultipartFile;

import com.att.comet.account.modal.AccountBO;
import com.att.comet.account.modal.AccountFileDetailBO;
import com.att.comet.account.modal.AccountInfoBO;
import com.att.comet.account.modal.AccountSearchCriteriaBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.service.GenericCometService;

public interface AccountService extends GenericCometService {

	/**
	 * This service is used to get class 1 customers/account from comet database.
	 * AccountBO will be returned as per the criteria defined in
	 * AccountSearchCriteriaBO object.
	 * 
	 * @param criteria
	 * @return List<AccountBO>
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<AccountBO> getExternalAccounts(AccountSearchCriteriaBO criteria)
			throws CometServiceException, CometDataException;

	/**
	 * This service is used to get class 2/class 3 customers/account from comet
	 * database. AccountBO will be returned as per the criteria defined in
	 * AccountSearchCriteriaBO object.
	 * 
	 * @param AccountSearchCriteriaBO
	 * @return List<AccountBO>
	 * @throws CometServiceException
	 * @throws CometDataException
	 */
	public List<AccountBO> getInternalAccounts(AccountSearchCriteriaBO criteria)
			throws CometServiceException, CometDataException;

	public List<String> getMasterAccountNameList(String Criteria) throws CometServiceException, CometDataException;

	public List<String> getSubAccountNameList(String Criteria) throws CometServiceException, CometDataException;

	public List<String> getInternalInitiativeAccountNameList(String Criteria)
			throws CometServiceException, CometDataException;

	public List<String> getProductInitiativeAccountNameList(String Criteria)
			throws CometServiceException, CometDataException;

	public List<String> getApnNameList(String Criteria) throws CometServiceException, CometDataException;

	public AccountInfoBO getAccountInfo(String accountClassId, String accountId)
			throws CometServiceException, CometDataException;

	public AccountInfoBO updateAccountInfo(AccountInfoBO accountInfoBO) throws CometDataException, IOException;

	public boolean deleteAccount(String accountClassId, String accountId)
			throws CometServiceException, CometDataException;

	public AccountInfoBO createAccount(AccountInfoBO accountInfoBO)
			throws CometDataException, IOException, CometServiceException;

	/**
	 * Fetch File details fron DAO
	 * 
	 * @param accountClassId
	 * @param accountId
	 * @return
	 * @throws CometDataException
	 */
	public AccountFileDetailBO getFileDetails(String accountClassId, String accountId)
			throws CometDataException, SQLException;
	
	public String storeFile(MultipartFile file, String accountId, Long accClassId) throws CometDataException, IOException, CometServiceException, SerialException, SQLException;
	
	public List<MasterAccountBO> getExistingAccList() throws CometServiceException, CometDataException;
	
	public boolean delAccountAttachment(String accountClassId, String accountId)
			throws CometServiceException, CometDataException;

}
