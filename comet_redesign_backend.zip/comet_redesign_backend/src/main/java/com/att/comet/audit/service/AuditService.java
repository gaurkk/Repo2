package com.att.comet.audit.service;

import com.att.comet.account.modal.OrderAccountBO;
import com.att.comet.audit.modal.ApnAuditBO;
import com.att.comet.audit.modal.OrderAuditBO;
import com.att.comet.audit.modal.OrderContactAuditBO;
import com.att.comet.audit.modal.RecoveryFlowChartAuditBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulConfigBO;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.order.crd.modal.CrdBO;
import com.att.comet.order.modal.BillingDetailsBO;
import com.att.comet.order.modal.InternetVPNConfigBO;
import com.att.comet.order.modal.MplsConfigBO;
import com.att.comet.order.modal.OrderSummaryBO;

public interface AuditService extends GenericCometService {
	OrderAuditBO getOrderInitializationInfoAudit(Long orderId, Long eventId)	throws CometDataException, CometServiceException;
	
	ApnAuditBO getApnAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	OrderAccountBO getOrderAccountAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	OrderContactAuditBO getOrderContactAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	BackhaulConfigBO getBackhaulConfigAudit(Long orderId, Long eventId)	throws CometDataException, CometServiceException;
	
	InternetVPNConfigBO getInternetVPNConfigAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	MplsConfigBO getMplsConfigAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	CrdBO getCrdAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	OrderAccountBO getFeeWaiverDocAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	RecoveryFlowChartAuditBO getRecoveryFlowChartAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	OrderSummaryBO getOrderSummaryAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
	BillingDetailsBO getOrderBillingAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException;
	
}
