package com.att.comet.charts.result;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LineChartDisplayBO<T> implements DisplayResultBO {
	private static final long serialVersionUID = -3450964370100170712L;

	private List<T> lstLineChartBOs = new ArrayList<T>();

	public List<T> getLstLineChartBOs() {
		return lstLineChartBOs;
	}

	public void setLstLineChartBOs(List<T> lstLineChartBOs) {
		this.lstLineChartBOs = lstLineChartBOs;
	}

}
