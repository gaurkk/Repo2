package com.att.comet.common.service;

import java.util.List;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.order.modal.DataCenterBO;

public interface AdminConfigService extends GenericCometService {

	/**
	 * Returns the Announcement info based on Category Id specified in the argument.
	 * 
	 * @return announcementList @throws
	 */
	public List<AdminConfigBO> getWelcomeAnnouncement();

	/**
	 * Returns the Announcement info based on Category Id, CCSMX, DataCenter ID
	 * specified in the argument.
	 * 
	 * @return Admin Config Details Info @throws
	 */
	public List<AdminConfigBO> getAdminConfigInfoList(Long adminCategoryId, String ccsmx, String dataCenterId)
			throws CometDataException;

	/**
	 * Returns the AdminConfigBO list based on Admin-Category-Id specified in the
	 * argument.
	 * 
	 * @return AdminConfigBO list @throws
	 */
	public List<AdminConfigBO> getAdminConfigs(long adminCategoryId);

	/**
	 * Returns all Non Dummy DatCenterBO list
	 * 
	 * @return DatCenterBO list @throws
	 */
	List<DataCenterBO> getDataCenterNameList() throws CometDataException;
}
