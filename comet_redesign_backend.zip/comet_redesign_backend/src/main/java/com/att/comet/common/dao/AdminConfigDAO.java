package com.att.comet.common.dao;

import java.util.List;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.order.modal.DataCenterBO;

public interface AdminConfigDAO extends GenericCometDAO {

	/**
	 * Return Users object if user exists with specified attuid
	 * 
	 * @return CategoryId @throws
	 */
	public AdminCategory findByCategoryId(Long adminCategoryId);

	/**
	 * Return Admin Config Info List
	 * 
	 * @return CategoryId, ccsmx, dataCenter ID @throws
	 */
	public List<AdminConfigBO> getAdminConfigInfoList(Long adminCategoryId, String ccsmx, String dataCenterId)
			throws CometDataException;

	/**
	 * Return Users object if user exists with specified attuid
	 * 
	 * @return CategoryId @throws
	 */
	public AdminCategory findMarketSegmentByCategoryId(Long adminCategoryId);

	/**
	 * Return default value for the categoryId
	 * 
	 * @param adminCategoryId
	 * @return AdminConfigBO
	 */
	AdminConfigBO getDefaultAdminConfigInfo(Long adminCategoryId);

	/**
	 * Return default value for the categoryId with CCS-MX and Data Center category
	 * 
	 * @param adminCategoryId
	 * @return AdminConfigBO
	 */
	AdminConfigBO getDefaultAdminConfigInfo(Long adminCategoryId, String ccsmx, String dataCenterId);

	/**
	 * Return non dummy datacenter list
	 * 
	 * @param
	 * @return DataCenterBO
	 */
	List<DataCenterBO> getDataCenterNameList();

}
