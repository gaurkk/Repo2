package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class TaskInfoId implements Serializable {

	private static final long serialVersionUID = -830821926180813732L;

	@Column(name = "TASK_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long taskId;

	@Column(name = "TASK_DISPLAY_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long taskDisplayTypeId;
}
