package com.att.comet.misc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.apn.controller.OrderApnController;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.misc.MiscBO;
import com.att.comet.misc.UploadFileBO;
import com.att.comet.order.filedoc.service.FileUploadDownloadService;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.order.modal.FileDownloadBO;
import com.att.comet.order.modal.OrderUploadFileDetailsBO;
import com.att.comet.order.service.OrderService;

import io.swagger.annotations.ApiOperation;


@RestController
@CrossOrigin("*")
public class OrderMiscController {
	private static final Logger logger = LoggerFactory.getLogger(OrderApnController.class);

	@Autowired
	OrderService orderService;
	@Autowired
	FileUploadDownloadService fileUploadDownloadService;
	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;
	@Autowired
	UserHelper userHelper;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getMiscInfo/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find MISC Details for unique Order Id   ", notes = "Return MISC Tab details for specific order id")
	public CometResponse<MiscBO> getMiscDetailsByOrderId(@PathVariable Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Starting method getMiscDetailsByOrderId : ",
				this);
		CometResponse<MiscBO> cometResponse = new CometResponse<MiscBO>();
		MiscBO miscBo = null;
		try {
			miscBo = orderService.getMiscDetails(orderId);
			if (null != miscBo) {
				cometResponse.setMethodReturnValue(miscBo);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException | CometServiceException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Exiting method getMiscDetailsByOrderId : ",
				this);
		return cometResponse;

	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN"})
	@PutMapping(value = "order/updateOrderMiscDCInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Saving Misc DC Info", notes = "Misc DC INFO")
	public CometResponse<MiscBO> updateOrderMiscDCInfo(@RequestBody MiscBO miscBO, Authentication authentication)
			throws CometDataException, CometServiceException {
		logger.info("[OrderId : " + (miscBO.getOrderId() == null ? "" : miscBO.getOrderId())
				+ "] Starting method updateMiscTabByOrderId :", this);
		boolean updateStatus = false;
		CometResponse<MiscBO> cometResponse = new CometResponse<MiscBO>();
		if (null != miscBO) {
			if (null != miscBO.getRecoveryInfo().getDataCenterInfoList()) {
				updateStatus = orderService.updateMiscDCAndOtherInfo(miscBO, miscBO.getOrderId(), authentication);
				logger.info("[OrderId : " + (miscBO.getOrderId() == null ? "" : miscBO.getOrderId())
						+ "] Misc data center details save :" + updateStatus, this);
			}
			if (updateStatus) {
				logger.info(
						"User::" + userHelper.getUserInfo(authentication).getAttuid() + "[:: OrderId : "
								+ (miscBO.getOrderId() == null ? "" : miscBO.getOrderId()) + "] Update ing MISC info :",
						this);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		}
		logger.info("[OrderId : " + (miscBO.getOrderId() == null ? "" : miscBO.getOrderId())
				+ "] Existing method updateMiscTabByOrderId  :", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/uploadNetworkDoc", consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE },headers = "X-API-VERSION=1")
	@ApiOperation(value = "Misc Network doc upload", notes = "Misc Network doc upload")
	public CometResponse<UploadFileBO> uploadNetworkDoc(@RequestParam("file") MultipartFile file,
			@RequestParam("orderId") String orderId, @RequestParam("uploadTypeId") String uploadTypeId)
			throws CometDataException, IOException {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Starting method uploadNetworkDoc  for Upload ID:"+uploadTypeId, this);
		CometResponse<UploadFileBO> cometResponse = new CometResponse<UploadFileBO>();
		UploadFileBO uploadFileBO = fileUploadDownloadService.storeFile(file, Long.parseLong(orderId), uploadTypeId);
		if (null != uploadFileBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(uploadFileBO);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Existing method uploadNetworkDoc for Upload ID :"+uploadTypeId,
				this);
		return cometResponse;
	}
	
	@Secured({"ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN","ROLE_ORDER_SUBMITTERS"})
	@PostMapping(value = "order/uploadIpSecDoc",consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE },headers = "X-API-VERSION=1")
	@ApiOperation(value = "Misc IpSec doc upload", notes = "Misc IpSec doc upload")
	public CometResponse<UploadFileBO> uploadIpSecDoc(@RequestParam("file") MultipartFile file,
			@RequestParam("orderId") String orderId, @RequestParam("uploadTypeId") String uploadTypeId)
			throws CometDataException, IOException {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Starting method uploadIpSecDoc :", this);
		CometResponse<UploadFileBO> cometResponse = new CometResponse<UploadFileBO>();
		UploadFileBO uploadFileBO = fileUploadDownloadService.storeFile(file, Long.parseLong(orderId), uploadTypeId);
		if (null != uploadFileBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(uploadFileBO);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Existing method uploadIpSecDoc  :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@PostMapping(value = "order/downloadNetworkFile", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Download network file ", notes = "Download network file")
	public ResponseEntity<Resource> downloadNetworkFile(@RequestBody FileDownloadBO fileDownloadBO,
			HttpServletRequest request) throws CometDataException {
		logger.info("[OrderId : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId())
				+ "] Starting method downloadNetworkFile :", this);
		// Load file as Resource
		OrderUploadFileDetailsBO orderUploadFileDetailsBO;
		try {
			orderUploadFileDetailsBO = fileUploadDownloadService
					.getFileDetails(Long.parseLong(fileDownloadBO.getOrderId()), fileDownloadBO.getUploadTypeId());
			if (null != orderUploadFileDetailsBO) {
				String fileType = orderUploadFileDetailsBO.getUploadContentType();
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(fileType))
						.header(HttpHeaders.CONTENT_DISPOSITION,
								"attachment; filename=\"" + orderUploadFileDetailsBO.getUploadFileName() + "\"")
						.body(new ByteArrayResource(orderUploadFileDetailsBO.getUploadAttachment()));
			}
		} catch (NumberFormatException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "NumberFormatException Getting Download file " + e);
		} catch (CometDataException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "CometDataException Getting Download file " + e);
			throw new CometDataException("Error", "Getting OrderComments Info failed", e);
		} catch (IOException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "IOException Getting Download file " + e);
		}
		logger.info("[OrderId : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId())
				+ "] Exiting method downloadNetworkFile :", this);
		return null;

	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@PostMapping(value = "order/downloadIpLetterFile", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Download ipletter file ", notes = "Download ipletter file")
	public ResponseEntity<Resource> downloadIpLetterFile(@RequestBody FileDownloadBO fileDownloadBO,
			HttpServletRequest request) throws CometDataException {
		logger.info("[OrderId : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId())
				+ "] Starting method downloadIpLetterFile :", this);
		// Load file as Resource
		OrderUploadFileDetailsBO orderUploadFileDetailsBO;
		try {
			orderUploadFileDetailsBO = fileUploadDownloadService
					.getFileDetails(Long.parseLong(fileDownloadBO.getOrderId()), fileDownloadBO.getUploadTypeId());
			if (null != orderUploadFileDetailsBO) {
				String fileType = orderUploadFileDetailsBO.getUploadContentType();
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(fileType))
						.header(HttpHeaders.CONTENT_DISPOSITION,
								"attachment; filename=\"" + orderUploadFileDetailsBO.getUploadFileName() + "\"")
						.body(new ByteArrayResource(orderUploadFileDetailsBO.getUploadAttachment()));
			}
		} catch (NumberFormatException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "NumberFormatException Getting Download file " + e);
		} catch (CometDataException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "CometDataException Getting Download file " + e);
			throw new CometDataException("Error", "CometDataException Getting Download file", e);
		} catch (IOException e) {
			logger.error("[OrderID : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId()) + "] "
					+ "IOException Getting Download file " + e);
		}
		logger.info("[OrderId : " + (fileDownloadBO.getOrderId() == null ? "" : fileDownloadBO.getOrderId())
				+ "] Exiting method downloadIpLetterFile :", this);
		return null;
	}
	
	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "order/delDocument/{orderId}/{uploadTypeId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Uploaded Document ", notes = "Delete Uploaded Document ")
	public CometResponse<UploadFileBO> delDocument(@PathVariable Long orderId,@PathVariable String uploadTypeId) throws CometDataException {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Starting method delDocument :", this);
		CometResponse<UploadFileBO> cometResponse = new CometResponse<UploadFileBO>();
		boolean flag;
		try {
			flag = fileUploadDownloadService.deleteFile(orderId, uploadTypeId);
			if (flag) {
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException | IOException e) {
			logger.error("[OrderID : " + (orderId == null ? "" : orderId) + "] "
					+ "CometDataException Getting Download file " + e);
			throw new CometDataException("Error", "CometDataException Getting deleting file", e);
		}
		
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] Existing method delDocument  :", this);
		return cometResponse;
		
	}
	
}
