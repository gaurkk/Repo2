package com.att.comet.manage.modal;

public class InOutCSVLineBO extends LineBO{
	private static final long serialVersionUID = 8074190171311444611L;
	private String dataCenterName;
	private String insidePat;
	private String outsidePat;
	private int recordNumber;
	/**
	 * @return the dataCenterName
	 */
	public String getDataCenterName() {
		return dataCenterName;
	}
	/**
	 * @param dataCenterName the dataCenterName to set
	 */
	public void setDataCenterName(String dataCenterName) {
		this.dataCenterName = dataCenterName;
	}
	/**
	 * @return the insidePat
	 */
	public String getInsidePat() {
		return insidePat;
	}
	/**
	 * @param insidePat the insidePat to set
	 */
	public void setInsidePat(String insidePat) {
		this.insidePat = insidePat;
	}
	/**
	 * @return the outsidePat
	 */
	public String getOutsidePat() {
		return outsidePat;
	}
	/**
	 * @param outsidePat the outsidePat to set
	 */
	public void setOutsidePat(String outsidePat) {
		this.outsidePat = outsidePat;
	}
	/**
	 * @return the recordNumber
	 */
	public int getRecordNumber() {
		return recordNumber;
	}
	/**
	 * @param recordNumber the recordNumber to set
	 */
	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
}

