package com.att.comet.common.controller;

import static com.att.comet.security.constant.SecurityStaticConstants.CSP_ATT_UID;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.exception.UnAuthorizedUserException;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.common.service.AdminConfigServiceImpl;
import com.att.comet.order.modal.DataCenterBO;
import com.att.comet.security.util.SecCookieUtil;
import com.att.comet.user.exception.UserException;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class AdminConfigController {

	Logger logger = LoggerFactory.getLogger(AdminConfigController.class);

	@Autowired
	AdminConfigServiceImpl adminConfigService;

	@Autowired
	SecCookieUtil cookieUtil;

	@Autowired
	CometResponse<List<AdminConfigBO>> cometResponse;

	@GetMapping(value = "/welcomeAnnouncement", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Welocome Page Announcement", notes = "Return all the Announcement")
	public CometResponse<List<AdminConfigBO>> getAdminConfigWelcomeAnnouncement(
			@RequestHeader("attESSec") String attESSec, @RequestHeader("attESHr") String attESHr)
			throws RecordNotFoundException, UserException, UnsupportedEncodingException {
		logger.info("Starting method getAdminConfigWelcomeAnnouncement : ", this);
		HashMap<String, String> map = cookieUtil.decodeCookie(attESHr, attESSec);
		if (StringUtils.isNotBlank(map.get(CSP_ATT_UID))) {
			cometResponse.setMethodReturnValue(adminConfigService.getWelcomeAnnouncement());
		} else {
			throw new UnAuthorizedUserException("Unauthorized user");
		}
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getAdminConfigWelcomeAnnouncement : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/admin/configInfo/{adminCategoryId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Admin Config Info List", notes = "Return all the Admin Config list based on Admin Category ID")
	public CometResponse<List<AdminConfigBO>> getAdminConfigInfo(@PathVariable Long adminCategoryId)
			throws RecordNotFoundException, UserException {
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] "
				+ "Starting method getAdminConfigInfo :", this);
		CometResponse<List<AdminConfigBO>> cometResponse = new CometResponse<List<AdminConfigBO>>();
		List<AdminConfigBO> adminConfigBOList = null;
		try {
			adminConfigBOList = adminConfigService.getAdminConfigInfoList(adminCategoryId, null, null);

			if (!CollectionUtils.isEmpty(adminConfigBOList)) {
				cometResponse.setMethodReturnValue(adminConfigBOList);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] "
				+ "Exiting method getAdminConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/admin/configInfo/{adminCategoryId}/{ccsmx}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Admin Config Info List", notes = "Return all the Admin Config list based on Admin Category ID and CCSMX")
	public CometResponse<List<AdminConfigBO>> getAdminConfigInfo(@PathVariable Long adminCategoryId,
			@PathVariable String ccsmx) throws RecordNotFoundException, UserException {
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[Ccsmx : "
				+ (ccsmx == null ? "" : ccsmx) + "] " + "Starting method getAdminConfigInfo :", this);
		CometResponse<List<AdminConfigBO>> cometResponse = new CometResponse<List<AdminConfigBO>>();
		List<AdminConfigBO> adminConfigBOList = null;
		try {
			adminConfigBOList = adminConfigService.getAdminConfigInfoList(adminCategoryId, ccsmx, null);
			if (!CollectionUtils.isEmpty(adminConfigBOList)) {
				cometResponse.setMethodReturnValue(adminConfigBOList);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[Ccsmx : "
				+ (ccsmx == null ? "" : ccsmx) + "] " + "Exiting method getAdminConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/admin/configInfo/{adminCategoryId}/{ccsmx}/{dataCenterId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Admin Config Info List", notes = "Return all the Admin Config list based on Admin Category ID, CCSMX and Data Center ID")
	public CometResponse<List<AdminConfigBO>> getAdminConfigInfo(@PathVariable Long adminCategoryId,
			@PathVariable String ccsmx, @PathVariable String dataCenterId)
			throws RecordNotFoundException, UserException {
		logger.info(
				"[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[Ccsmx : "
						+ (ccsmx == null ? "" : ccsmx) + "] " + "[DataCenterId : "
						+ (dataCenterId == null ? "" : dataCenterId) + "] " + "Starting method getAdminConfigInfo :",
				this);
		CometResponse<List<AdminConfigBO>> cometResponse = new CometResponse<List<AdminConfigBO>>();
		List<AdminConfigBO> adminConfigBOList = null;
		try {
			adminConfigBOList = adminConfigService.getAdminConfigInfoList(adminCategoryId, ccsmx, dataCenterId);
			if (!CollectionUtils.isEmpty(adminConfigBOList)) {
				cometResponse.setMethodReturnValue(adminConfigBOList);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info(
				"[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[Ccsmx : "
						+ (ccsmx == null ? "" : ccsmx) + "] " + "[DataCenterId : "
						+ (dataCenterId == null ? "" : dataCenterId) + "] " + "Exiting method getAdminConfigInfo :",
				this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/marketSegmentList", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Market Segment List", notes = "Return all the MarketSegmentList")
	public CometResponse<List<AdminConfigBO>> getAdminConfigMarketSegmentList()
			throws RecordNotFoundException, UserException {
		logger.info("Starting method getAdminConfigMarketSegmentList : ", this);
		cometResponse = adminConfigService.getMarketSegmentList();
		logger.info("Exiting method getAdminConfigMarketSegmentList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/admin/getdataCenterNameList", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find All Non Dummy Data Center Names", notes = "Returns all the Non Dummy Data Center Names")
	public CometResponse<List<StaticDataBO>> getDataCenterNameList() throws CometDataException {
		logger.info("Starting method getDataCenterNameList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> dcClass = new ArrayList<StaticDataBO>();
		List<DataCenterBO> dataCenterNameList = adminConfigService.getDataCenterNameList();
		if (!CollectionUtils.isEmpty(dataCenterNameList)) {
			List<KeyValueBO> keyValueList = dataCenterNameList.stream()
					.map(bo -> new KeyValueBO(bo.getDataCenterId().toString(), bo.getDataCenterName()))
					.collect(Collectors.toList());
			dcClass.add(new StaticDataBO(CometCommonConstant.DATACENTER_NAME, keyValueList));
		}
		cometResponse.setMethodReturnValue(dcClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getDataCenterNameList : ", this);
		return cometResponse;
	}
}
