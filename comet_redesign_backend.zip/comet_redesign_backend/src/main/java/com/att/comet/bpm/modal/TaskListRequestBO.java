package com.att.comet.bpm.modal;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TaskListRequestBO {
	List<TaskVariable> taskVariables = null;
	private String processInstanceBusinessKey;
	private String taskAssignee;
	private String taskName;
	private String taskDescription;
	private Boolean assigned = null;
	private Boolean unassigned = null;
	private Boolean finished = null;
	private String startedAfter;
	private String startedBefore;
	List<Sorting> sorting = new ArrayList<Sorting>();

	public TaskListRequestBO() {
		Sorting sort = new Sorting("startTime", "desc");
		sorting.add(sort);
	}

	public List<TaskVariable> getTaskVariables() {
		return taskVariables;
	}

	public void setTaskVariables(List<TaskVariable> taskVariables) {
		this.taskVariables = taskVariables;
	}

	public String getProcessInstanceBusinessKey() {
		return processInstanceBusinessKey;
	}

	public void setProcessInstanceBusinessKey(String processInstanceBusinessKey) {
		this.processInstanceBusinessKey = processInstanceBusinessKey;
	}

	public String getTaskAssignee() {
		return taskAssignee;
	}

	public void setTaskAssignee(String taskAssignee) {
		this.taskAssignee = taskAssignee;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public Boolean getAssigned() {
		return assigned;
	}

	public void setAssigned(Boolean assigned) {
		this.assigned = assigned;
	}

	public Boolean getUnassigned() {
		return unassigned;
	}

	public void setUnassigned(Boolean unassigned) {
		this.unassigned = unassigned;
	}

	public Boolean getFinished() {
		return finished;
	}

	public void setFinished(Boolean finished) {
		this.finished = finished;
	}

	public String getStartedAfter() {
		return startedAfter;
	}

	public void setStartedAfter(String startedAfter) {
		this.startedAfter = startedAfter;
	}

	public String getStartedBefore() {
		return startedBefore;
	}

	public void setStartedBefore(String startedBefore) {
		this.startedBefore = startedBefore;
	}

	public List<Sorting> getSorting() {
		return sorting;
	}

	public void setSorting(List<Sorting> sorting) {
		this.sorting = sorting;
	}

	public void addTaskVeriable(String criteria, String value) {
		if (taskVariables == null) {
			taskVariables = new ArrayList<TaskVariable>();
		}
		TaskVariable variable = null;
		switch (criteria) {
		case "ROLE":
			variable = new TaskVariable("roleName", value, "eq");
			taskVariables.add(variable);
			break;
		case "EXPEDITE":
			variable = new TaskVariable("expedite", value, "eq");
			taskVariables.add(variable);
			break;
		case "OPEN_REMINDERS":
			variable = new TaskVariable("openReminder", value, "eq");
			taskVariables.add(variable);
			break;
		default:
			break;
		}
	}
}

class TaskVariable {
	private String name;
	private String value;
	private String operator;

	public TaskVariable(String name, String value, String operator) {
		this.name = name;
		this.value = value;
		this.operator = operator;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}
}

class Sorting {
	private String sortBy;
	private String sortOrder;

	public Sorting(String sortBy, String sortOrder) {
		this.sortBy = sortBy;
		this.sortOrder = sortOrder;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
}