package com.att.comet.charts.dao;

import java.util.List;

import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.dao.GenericCometDAO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.criteria.SearchCriteria;

public interface ChartsDAO extends GenericCometDAO {

	public ResultBO getDataUsingCriteria(SearchCriteria searchCriterias)
			throws CometServiceException, CometDataException, Exception;

	public List<BackhaulTypeBO> getBHType() throws CometServiceException, CometDataException;
}