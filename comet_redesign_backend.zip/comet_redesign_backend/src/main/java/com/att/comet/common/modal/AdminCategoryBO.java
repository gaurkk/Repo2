package com.att.comet.common.modal;

import java.util.ArrayList;
import java.util.List;

import com.att.comet.manage.modal.MessageBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
public class AdminCategoryBO {

	private Long categoryId;

	private String categoryName;

	private String categoryValueType;

	List<AdminConfigBO> adminConfigInfoList = new ArrayList<AdminConfigBO>();

}
