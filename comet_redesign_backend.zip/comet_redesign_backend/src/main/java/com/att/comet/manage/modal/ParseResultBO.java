package com.att.comet.manage.modal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ParseResultBO implements Serializable{
	private static final long serialVersionUID = 1260873951375855098L;
	private List<LineBO> lines = new ArrayList<LineBO>();
	private List<MessageBO> messages = new ArrayList<MessageBO>();
	private List<DapnUploadStatusBO> dapnploadStatus = new ArrayList<DapnUploadStatusBO>();
	private Object invalidFileMesage;
	
	

}