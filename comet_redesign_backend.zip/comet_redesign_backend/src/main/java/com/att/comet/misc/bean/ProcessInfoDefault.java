package com.att.comet.misc.bean;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProcessInfoDefault {

	private String headerValue;
	
	Map<String,List<ProcessInfoBeanDetails>> oAMapList;

}
