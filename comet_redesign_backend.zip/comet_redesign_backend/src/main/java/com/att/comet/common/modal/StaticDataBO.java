package com.att.comet.common.modal;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Component
@Getter
@Setter
@ToString
@NoArgsConstructor
public class StaticDataBO {
	
	public StaticDataBO(String staticDataName, List<KeyValueBO> data) {
		this.staticDataName = staticDataName;
		if(data != null)
			this.data = data;
	}
	private String staticDataName;
	private List<KeyValueBO> data = new ArrayList<KeyValueBO>();
}
