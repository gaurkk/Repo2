package com.att.comet.charts.delegate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.charts.modal.ChartNameEnum;
import com.att.comet.charts.modal.ChartsRequestBO;
import com.att.comet.charts.modal.RestrictionBO;
import com.att.comet.charts.modal.RestrictionEnum;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.charts.service.ChartsServiceImpl;
import com.att.comet.charts.util.ChartsConstant;
import com.att.comet.common.constant.BaseQueryNameConstant;
import com.att.comet.common.exception.ErrorCodeConstant;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.util.CriteriaHelper;

@Component
public class ChartsDelegate {

	private static final Logger logger = LoggerFactory.getLogger(ChartsServiceImpl.class);

	@Autowired
	ChartsServiceImpl chartsService;

	@Autowired
	CriteriaHelper criteriaHelper;

	public ResultBO parseRequestJson(ChartsRequestBO chartsRequestBo) {
		logger.info("[ChartsRequestBo : "+(chartsRequestBo == null ? "": chartsRequestBo.getUserInfo().getAttuid()==null ? "":chartsRequestBo.getUserInfo().getRoleId()==null)+"] Starting method parseRequestJson : ", this);

		ResultBO resultBO = null;

		try {
			SearchCriteria searchCriterias = null;
			String userAttUid = chartsRequestBo.getUserInfo().getAttuid();
			Long userRoleId = chartsRequestBo.getUserInfo().getRoleId();

			String marketSegment = "";
			String orderType = "0";
			String month = "";
			String year = "";
			String apnStatus = "";
			String activePassive = "";
			String bhType = "";
			String geo = "";

			if (chartsRequestBo.getRestrictions() != null) {
				for (RestrictionBO restriction : chartsRequestBo.getRestrictions()) {
					String key = RestrictionEnum.valueOf(restriction.getKey()).toString();
					String value = restriction.getValue();

					if (key.equals(RestrictionEnum.ORDER_MARKET_SEGMENT_RESTRICTION.name())) {
						marketSegment = value;
					}
					if (key.equals(RestrictionEnum.ORDER_TYPE_RESTRICTION.name())) {
						orderType = value;
					}
					if (key.equals(RestrictionEnum.ORDER_DATE_RESTRICTION.name())) {
						if (value != null && value.length() > 0) {
							if (value.length() == 7) {
								month = value.substring(0, 3).toUpperCase();
								year = value.substring(3);
							} else if (value.length() == 3) {
								month = value.toUpperCase();
							} else if (value.length() == 4) {
								year = value;
							}
						}
					}
					if (key.equals(RestrictionEnum.ORDER_ACTIVE_PASSIVE_RESTRICTION.name())) {
						activePassive = value;
					}
					if (key.equals(RestrictionEnum.ORDER_APN_STATUS_RESTRICTION.name())) {
						apnStatus = value;
					}
					if (key.equals(RestrictionEnum.ORDER_BH_TYPE_RESTRICTION.name())) {
						bhType = value;
					}
					if (key.equals(RestrictionEnum.ORDER_GEO_RESTRICTION.name())) {
						geo = value;
					}
				}
			} else {
				logger.error("RESTRICTION_REQUEST_NOT_PROPER::" + ErrorCodeConstant.RESTRICTION_REQUEST_NOT_PROPER,
						this);
			}
			if (chartsRequestBo.getChartName() == null) {
				logger.error("CHART NAME IS NOT PROPER::" + ErrorCodeConstant.CHART_NAME_IS_NOT_PROPER, this);
				return resultBO;
			}

			if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.ALL_ORDERS_PROGRESS.toString())) {

				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				searchCriterias.add(CriteriaHelper.marketSegment(marketSegment));
				searchCriterias.add(CriteriaHelper.orderType(Long.parseLong(orderType)));
				searchCriterias.add(CriteriaHelper.date(month, year));
				searchCriterias.setFormat(OutputFormat.PIE_CHART);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_PIECHART);
				searchCriterias.setChartName(ChartNameEnum.ALL_ORDERS_PROGRESS.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.MY_ORDERS_PROGRESS.toString())) {

				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				searchCriterias.add(CriteriaHelper.marketSegment(marketSegment));
				searchCriterias.add(CriteriaHelper.orderType(Long.parseLong(orderType)));
				searchCriterias.add(CriteriaHelper.date(month, year));
				searchCriterias.addOtherDetails(new OtherDetails(userAttUid, userRoleId, 0, 0));
				searchCriterias.setFormat(OutputFormat.PIE_CHART);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_PIECHART);
				searchCriterias.setChartName(ChartNameEnum.MY_ORDERS_PROGRESS.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.APNS_BY_DATA_CENTER.toString())) {

				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());

				if (apnStatus.equals("1001")) {
					apnStatus = "In Progress";
				} else if (apnStatus.equals("1002")) {
					apnStatus = "In Production";
				}

				searchCriterias.add(CriteriaHelper.apnStatus(apnStatus));

				searchCriterias.add(CriteriaHelper.activePassive(activePassive));
				searchCriterias.add(CriteriaHelper.bhType(bhType));
				searchCriterias.add(CriteriaHelper.geo(geo));
				searchCriterias.setFormat(OutputFormat.PIE_CHART);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION);
				searchCriterias.setChartName(ChartNameEnum.APNS_BY_DATA_CENTER.toString());

			} else if (chartsRequestBo.getChartName() != null && chartsRequestBo.getChartName()
					.equalsIgnoreCase(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.setFormat(OutputFormat.BAR_CHART);
				searchCriterias.add(CriteriaHelper.orderAssignment(1023L));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_BARCHART);
				searchCriterias.setChartName(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.setFormat(OutputFormat.BAR_CHART);
				searchCriterias.add(CriteriaHelper.orderAssignment(1007L));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_BARCHART);
				searchCriterias.setChartName(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.TTU_SCHEDULED.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.setFormat(OutputFormat.STACKED_COLUMN_CHART);
				searchCriterias.add(CriteriaHelper.schedule(ChartsConstant.SCHEDULE_TTU));
				searchCriterias.addOtherDetails(new OtherDetails(userAttUid, userRoleId, 0, 0));
				searchCriterias.setBaseQuery("BASE_QUERY_FOR_STACKEDCOLUMNCHART");
				searchCriterias.setChartName(ChartNameEnum.TTU_SCHEDULED.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.IWOS_EXPECTED.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				searchCriterias.setFormat(OutputFormat.STACKED_COLUMN_CHART);
				searchCriterias.add(CriteriaHelper.schedule(ChartsConstant.SCHEDULE_IWOS));
				searchCriterias.addOtherDetails(new OtherDetails(userAttUid, userRoleId, 0, 0));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_STACKEDCOLUMNCHART);
				searchCriterias.setChartName(ChartNameEnum.IWOS_EXPECTED.toString());

			}

			resultBO = chartsService.getDataUsingCriteria(searchCriterias);
		} catch (Exception e) {
			e.printStackTrace();
//			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
//			cometResponse.setStatus(Status.BUSINESS_ERROR);
//			return cometResponse;
		}

		logger.info("[ChartsRequestBo : "+(chartsRequestBo == null ? "": chartsRequestBo.getUserInfo().getAttuid()== null ? "":chartsRequestBo.getUserInfo().getRoleId()== null)+"] Exiting method parseRequestJson : ", this);
		return resultBO;
	}

}