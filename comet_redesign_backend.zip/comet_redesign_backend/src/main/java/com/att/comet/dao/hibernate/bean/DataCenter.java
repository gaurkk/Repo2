package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for DataCenter. mapped with DATA_CENTER table in the
 * database.
 */
@Entity
@Table(name = "DATA_CENTER")
public class DataCenter implements Serializable {

	private static final long serialVersionUID = 2278361266449169599L;

	private Long dataCenterId;
	private String dataCenterName;
	private Character dummy;
	private String firstNet;
	private String zoneName;
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dataCenterId == null) ? 0 : dataCenterId.hashCode());
		result = prime * result
				+ ((dataCenterName == null) ? 0 : dataCenterName.hashCode());
		result = prime * result
				+ ((dedicatedApns == null) ? 0 : dedicatedApns.hashCode());
		result = prime * result + ((dummy == null) ? 0 : dummy.hashCode());
		result = prime * result
				+ ((firstNet == null) ? 0 : firstNet.hashCode());
		result = prime * result
				+ ((zoneName == null) ? 0 : zoneName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DataCenter other = (DataCenter) obj;
		if (dataCenterId == null) {
			if (other.dataCenterId != null)
				return false;
		} else if (!dataCenterId.equals(other.dataCenterId))
			return false;
		if (dataCenterName == null) {
			if (other.dataCenterName != null)
				return false;
		} else if (!dataCenterName.equals(other.dataCenterName))
			return false;
		if (dedicatedApns == null) {
			if (other.dedicatedApns != null)
				return false;
		} else if (!dedicatedApns.equals(other.dedicatedApns))
			return false;
		if (dummy == null) {
			if (other.dummy != null)
				return false;
		} else if (!dummy.equals(other.dummy))
			return false;
		if (firstNet == null) {
			if (other.firstNet != null)
				return false;
		} else if (!firstNet.equals(other.firstNet))
			return false;
		if (zoneName == null) {
			if (other.zoneName != null)
				return false;
		} else if (!zoneName.equals(other.zoneName))
			return false;
		return true;
	}

	private Set<DapnInventory> dedicatedApns = new HashSet<DapnInventory>(0);
	/**
	 * Getter method for dataCenterId. DATA_CENTER_ID mapped to DATA_CENTER_ID
	 * in the database table.The sequence is used to generate the ids.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "DATA_CENTER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_DATA_CENTER_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_DATA_CENTER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_DATA_CENTER_ID")
	public Long getDataCenterId() {
		return this.dataCenterId;
	}

	/**
	 * @param dataCenterId
	 *            to dataCenterId set.
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	/**
	 * Getter method for dataCenterName. DATA_CENTER_NAME mapped to
	 * DATA_CENTER_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DATA_CENTER_NAME", nullable = false, length = 20)
	public String getDataCenterName() {
		return this.dataCenterName;
	}

	/**
	 * Getter method for zonename. ZONE_NAME mapped to
	 * ZONE_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name= "ZONE_NAME", length = 100)
	public String getZoneName() {
		return zoneName;
	}

	/**
	 * @param zoneName
	 *            to zoneName set.
	 */
		public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}

	/**
	 * @param dataCenterName
	 *            to dataCenterName set.
	 */
	public void setDataCenterName(String dataCenterName) {
		this.dataCenterName = dataCenterName;
	}

	/**
	 * Getter method for dummy. DUMMY mapped to DUMMY in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "DUMMY", nullable = false, length = 1)
	public Character getDummy() {
		return this.dummy;
	}

	/**
	 * @param dummy
	 *            to dummy set.
	 */
	public void setDummy(Character dummy) {
		this.dummy = dummy;
	}
	
	

	@Column(name = "FIRST_NET", length = 1)
	public String getFirstNet() {
		return firstNet;
	}

	public void setFirstNet(String firstNet) {
		this.firstNet = firstNet;
	}

	/**
	 * Getter method for dedicatedApns.
	 * 
	 * @return Set<DedicatedApn>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dataCenter")
	public Set<DapnInventory> getDedicatedApns() {
		return this.dedicatedApns;
	}

	/**
	 * @param dedicatedApns
	 *            to dedicatedApns set.
	 */
	public void setDedicatedApns(Set<DapnInventory> dedicatedApns) {
		this.dedicatedApns = dedicatedApns;
	}
}