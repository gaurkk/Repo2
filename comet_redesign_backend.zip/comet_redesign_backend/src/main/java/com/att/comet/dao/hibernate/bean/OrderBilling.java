package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_BILLING")
public class OrderBilling implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1376520646590386948L;
	private Long orderId;
	private Date billingCompletion;
	private String companyBillingAddress;
	private String ctnSim;
	private Orders orders;

	public OrderBilling() {

	}

	/**
	 * Getter method for the OrderId ORDER_ID mapped to ORDER_ID column if the table
	 * in database.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the billingCompletion
	 */
	@Column(name = "BILLING_DATE_COMPLETE", nullable = true)
	public Date getBillingCompletion() {
		return billingCompletion;
	}

	/**
	 * @param billingCompletion the billingCompletion to set
	 */
	public void setBillingCompletion(Date billingCompletion) {
		this.billingCompletion = billingCompletion;
	}

	/**
	 * @return the companyBillingAddress
	 */
	@Column(name = "COMPANY_BILLING_ADDRESS", length = 200)
	public String getCompanyBillingAddress() {
		return companyBillingAddress;
	}

	/**
	 * @param companyBillingAddress the companyBillingAddress to set
	 */
	public void setCompanyBillingAddress(String companyBillingAddress) {
		this.companyBillingAddress = companyBillingAddress;
	}

	/**
	 * @return the ctnSim
	 */
	@Column(name = "CTN_SIM", length = 20)
	public String getCtnSim() {
		return ctnSim;
	}

	/**
	 * @param ctnSim the ctnSim to set
	 */
	public void setCtnSim(String ctnSim) {
		this.ctnSim = ctnSim;
	}
	
	/**
	 * @return the orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return orders;
	}

	/**
	 * @param orders the orders to set
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
}
