package com.att.comet.common.constant;

/**
 * Contains all possible Back-haul types available in a Comet Order. The class
 * defines static constants to be used in the classes to avoid hard coding of
 * the back-haul types.
 */
public class TypeBackhaul {

	/**
	 * Back-haul type - ALL
	 */
	 public static final Long ALL = 1001L; 

	/**
	 * Back-haul type - Internet VPN
	 */
	public static final Long IVPN = 1002L;

	/**
	 * Back-haul type - MPLS
	 */
	public static final Long MPLS = 1004L;

	/**
	 * Back-haul type - INTERNET
	 */
	public static final Long INTERNET = 1005L;

	/**
	 * Back-haul type - M2M
	 */
	public static final Long M2M = 1006L;

}
