package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for OrderContactType. Mapped to ORDER_CONTACT_TYPE table in
 * the database.
 */
@Entity
@Table(name = "ORDER_CONTACT_TYPE")
public class OrderContactType implements java.io.Serializable {

	private static final long serialVersionUID = -5222200081512413491L;

	private Long orderContactTypeId;
	private String orderContactTypeName;	

	/**
	 * No-argument constructor of the class.
	 */
	public OrderContactType() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderContactTypeId
	 * @param orderContactTypeName
	 */
	public OrderContactType(long orderContactTypeId, String orderContactTypeName) {
		this.orderContactTypeId = orderContactTypeId;
		this.orderContactTypeName = orderContactTypeName;
	}

	/**
	 * Getter method for orderContactTypeId. ORDER_CONTACT_TYPE_ID mapped to
	 * ORDER_CONTACT_TYPE_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_CONTACT_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderContactTypeId() {
		return this.orderContactTypeId;
	}

	/**
	 * @param orderContactTypeId
	 *            to orderContactTypeId set.
	 */
	public void setOrderContactTypeId(Long orderContactTypeId) {
		this.orderContactTypeId = orderContactTypeId;
	}

	/**
	 * Getter method for orderContactTypeName. ORDER_CONTACT_TYPE_NAME mapped to
	 * ORDER_CONTACT_TYPE_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ORDER_CONTACT_TYPE_NAME", nullable = false, length = 100)
	public String getOrderContactTypeName() {
		return this.orderContactTypeName;
	}

	/**
	 * @param orderContactTypeName
	 *            to orderContactTypeName set.
	 */
	public void setOrderContactTypeName(String orderContactTypeName) {
		this.orderContactTypeName = orderContactTypeName;
	}
}