package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class MasterAccountBO extends CometGenericBO{
	private static final long serialVersionUID = 812233523137136775L;
	private Long accountClass;
	private String masterAccountName;
	private String ubcid;
	private SubAccountBO subAccount;
}
