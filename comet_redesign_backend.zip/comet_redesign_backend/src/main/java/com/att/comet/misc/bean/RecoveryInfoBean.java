package com.att.comet.misc.bean;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
/**
 * RecoveryInfoBean to handles the data of Recovery Information.
 */

@Setter
@Getter
@ToString
public class RecoveryInfoBean {

	private String build;
	private String apnName;
	private String pdpName;
	
	private List<DataCenterInfoBean> dataCenterInfoList = new ArrayList<DataCenterInfoBean>();
	private String postSalesContactName;
	private String postSalesContactPhone;
	private String postSalesContactEmail;
	private String postSalesContactExtension;
	private String lteSweep;	
	private String recoveryFlowChartFileName;
	private String ipSecLetterAttachmentName;
	
	
	
}
