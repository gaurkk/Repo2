package com.att.comet.misc.bean;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * DataCenterInfoBean for handling the data center info.
 */
@Getter
@Setter
@ToString
public class DataCenterInfoBean {

	private String ndc;
	private String dataCenter;
	private String activeRouter;
	private String activeInterface;
	private String primaryDcRouter;

}
