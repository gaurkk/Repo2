package com.att.comet.common.constant;

public enum OrderFlagsEnum {
	
	PcrfChange(1001L, "PcrfChange"), PcrfNone(1002L, "PcrfNone"), SkipAmp(
			1003L, "SkipAmp"), AmpApplied(1004L, "AmpApplied"), AccaApplied(
			1005L, "AccaApplied");
	
	/**
	 * 
	 * property variable id
	 */
	private final Long id;
	
	/**
	 * property variable name
	 */
	private final String name;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	
	/**
	 * The method is used to get the name of the type of the order.
	 * @param id
	 * @return Order Flag , if the id is not null otherwise null.
	 */
	public static OrderFlagsEnum getName(Long id) {
		if(id != null) {
			for(OrderFlagsEnum orderFlags : OrderFlagsEnum.values()) {
				if (orderFlags.getId().longValue() == id.longValue()) {
					return orderFlags;
				}
			}
		}
		return null;
	}
	
	/**
	 * Argument Constructor.
	 * @param id
	 * @param name
	 */
	private OrderFlagsEnum(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}
