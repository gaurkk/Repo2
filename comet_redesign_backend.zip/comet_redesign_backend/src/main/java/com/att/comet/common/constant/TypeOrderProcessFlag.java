package com.att.comet.common.constant;

public class TypeOrderProcessFlag {

	/**
	 * CHANGE_REQUEST_IN_PROGRESS
	 */
	public static final Character CHANGE_REQUEST_IN_PROGRESS = 'I';

	/**
	 * CHANGE_REQUEST_COMPLETED
	 */
	public static final Character CHANGE_REQUEST_COMPLETED = 'F';

	/**
	 * CHANGE_REQUEST_CANCELLED
	 */
	public static final Character CHANGE_REQUEST_CANCELLED = 'C';
	
	/**
	 * CANCEL_ORDER_INITIATED
	 */
	public static final Character CANCEL_ORDER_INITIATED = 'I';
	
	/**
	 * CANCEL_ORDER_CANCELLED 
	 */
	public static final Character CANCEL_ORDER_CANCELLED = 'C';
	
	/**
	 * CANCEL_ORDER_COMPLETED 
	 */
	public static final Character CANCEL_ORDER_COMPLETED = 'F';
	
	public static final Character SUBMIT = 'S';
}
