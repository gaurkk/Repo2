package com.att.comet.apn;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UeIpDataCenterBo {
	private String dataCenterId;
	private String orderId;
	private String ueIp1;
	private String ueIp2;
}

