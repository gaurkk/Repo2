package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ImsiMsisdnDataCenterId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Long dataCenterId;
	private String imsiMsisdn;

	public ImsiMsisdnDataCenterId() {
		super();
	}

	public ImsiMsisdnDataCenterId(Long dataCenterId, String imsiMsisdn) {
		super();
		this.dataCenterId = dataCenterId;
		this.imsiMsisdn = imsiMsisdn;
	}

	/**
	 * @return the dataCenterId
	 */
	@Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return dataCenterId;
	}

	/**
	 * @param dataCenterId the dataCenterId to set
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	/**
	 * @return the insideOutside
	 */
	@Column(name = "IMSI_MSISDN", nullable = false, length = 100)
	public String getImsiMsisdn() {
		return imsiMsisdn;
	}

	/**
	 * @param imsiMsisdn the imsiMsisdn to set
	 */
	public void setImsiMsisdn(String imsiMsisdn) {
		this.imsiMsisdn = imsiMsisdn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataCenterId == null) ? 0 : dataCenterId.hashCode());
		result = prime * result + ((imsiMsisdn == null) ? 0 : imsiMsisdn.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ImsiMsisdnDataCenterId other = (ImsiMsisdnDataCenterId) obj;
		if (dataCenterId == null) {
			if (other.dataCenterId != null)
				return false;
		} else if (!dataCenterId.equals(other.dataCenterId))
			return false;
		if (imsiMsisdn == null) {
			if (other.imsiMsisdn != null)
				return false;
		} else if (!imsiMsisdn.equals(other.imsiMsisdn))
			return false;
		return true;
	}

}
