package com.att.comet.account.dao;

import static com.att.comet.dao.StaticDataConstant.*;

/**
 * Static Account Constants
 */
public class AccountConstant {

	/**
	 * CIPN_NAME_
	 */
	public static final String CIPN_NAME_ = "select max(cipn) from " + "InternalProductAccount";

	/**
	 * GET_EXTERNAL_ACCOUNT_SEARCH_QUERY
	 */
	public static final String GET_EXTERNAL_ACCOUNT_SEARCH_QUERY = "SELECT DISTINCT ma.ubcid, "
			+ "ma.master_account_name, " + "sa.bcid, " + "sa.sub_account_name, " + "sa.account_type, "
			+ "sa.company_owner, " + "sa.created_by, " + "to_char(sa.created_on, 'MM/DD/YYYY') AS created_on, "
			+ "ma.account_class_id, " + "s.state_name, " + "c.city_name, " + "sa.hl_street_address, "
			+ "sa.hl_zip_code " + "FROM master_account ma, " + "sub_account sa, " + "account_class ac, " + "state s, "
			+ "city c ";

	/**
	 * GET_EXTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED
	 */
	public static final String GET_EXTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED = "SELECT DISTINCT ma.ubcid, "
			+ "ma.master_account_name, " + "sa.bcid, " + "sa.sub_account_name, " + "sa.account_type, "
			+ "sa.company_owner, " + "sa.created_by, " + "to_char(sa.created_on, 'MM/DD/YYYY') AS created_on, "
			+ "ma.account_class_id, " + " s.state_name," + " c.city_name," + " sa.hl_street_address,"
			+ " sa.hl_zip_code " + "FROM master_account ma, " + "sub_account sa, " + "account_class ac, state s,"
			+ " city c,dedicated_apn dap ";

	/**
	 * GET_EXTERNAL_ACCOUNT_SEARCH_WHERE_QUERY
	 */
	public static final String GET_EXTERNAL_ACCOUNT_SEARCH_WHERE_QUERY = " WHERE ma.ubcid = sa.ubcid "
			+ "AND ac.account_class_id    = ma.account_class_id " + "AND ac.account_class_id    = " + ACCOUNT_CLASS_1
			+ " " + "AND sa.active = 'Y' " + "AND c.city_id=sa.hl_city_id " + "And s.state_id = sa.hl_state_id ";

	/**
	 * GET_INTERNAL_ACCOUNT_SEARCH_QUERY
	 */
	public static final String GET_INTERNAL_ACCOUNT_SEARCH_QUERY = "SELECT DISTINCT ipa.cipn, "
			+ "ipa.internal_product_account_name, " + "ac.account_class_name, " + "ipa.created_by, "
			+ "to_char(ipa.created_on, 'MM/DD/YYYY'), " + "ipa.account_class_id "
			+ "FROM internal_product_account ipa, " + "sub_account sa, " + "account_class ac ";

	/**
	 * GET_INTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED
	 */
	public static final String GET_INTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED = "SELECT DISTINCT ipa.cipn, "
			+ "ipa.internal_product_account_name, " + "ac.account_class_name, " + "ipa.created_by, "
			+ "to_char(ipa.created_on, 'MM/DD/YYYY'), " + "ipa.account_class_id "
			+ "FROM internal_product_account ipa, " + "sub_account sa, " + "account_class ac, " + "dedicated_apn dap ";

	/**
	 * GET_INTERNAL_ACCOUNT_SEARCH_WHERE_QUERY
	 */
	public static final String GET_INTERNAL_ACCOUNT_SEARCH_WHERE_QUERY = "WHERE ipa.account_class_id            = ac.account_class_id "
			+ "AND ipa.active                        = 'Y' ";

	/**
	 * GET_MASTER_ACCOUNTS_QUERY
	 */
	public static final String GET_MASTER_ACCOUNTS_QUERY = "SELECT ubcid, master_account_name FROM master_account";

	/**
	 * GET_COMPANY_NAME
	 */
	public static final String GET_COMPANY_NAME = "select distinct company_name from sub_account order by lower(company_name)";

	/**
	 * CHECK_DELETION_OF_INTERNAL_PRODUCT_INITIATIVE_ACCOUNT
	 */
	public static final String CHECK_DELETION_OF_INTERNAL_PRODUCT_INITIATIVE_ACCOUNT = "SELECT count(*) FROM vpn WHERE cipn = :cipn UNION SELECT count(*) FROM pdp_package WHERE cipn = :cipn UNION SELECT count(*) FROM orders WHERE cipn = :cipn";

	/**
	 * CHECK_DELETION_OF_SUB_ACCOUNT
	 */
	public static final String CHECK_DELETION_OF_SUB_ACCOUNT = "SELECT count(*) as vpn_count FROM vpn WHERE bcid = :bcid UNION SELECT count(*) as pdp_count FROM pdp_package WHERE bcid = :bcid UNION SELECT count(*) as order_count FROM orders WHERE bcid = :bcid";

	/**
	 * CHECK_DELETION_OF_MASTER_ACCOUNT
	 */
	public static final String CHECK_DELETION_OF_MASTER_ACCOUNT = "SELECT count(*) FROM SUB_ACCOUNT s, MASTER_ACCOUNT m WHERE m.ubcid = :ubcid AND s.ubcid = m.ubcid";

	/**
	 * GET_MASTER_ACCOUNT_NAME_LIST
	 */
	public static final String GET_MASTER_ACCOUNT_NAME_LIST = "GET_MASTER_ACCOUNT_NAME_LIST";

	/**
	 * GET_SUB_ACCOUNT_NAME_LIST
	 */
	public static final String GET_SUB_ACCOUNT_NAME_LIST = "GET_SUB_ACCOUNT_NAME_LIST";

	/**
	 * GET_INTERNAL_PRODUCT_ACCOUNT_NAME_LIST
	 */
	public static final String GET_INTERNAL_PRODUCT_ACCOUNT_NAME_LIST = "GET_INTERNAL_PRODUCT_ACCOUNT_NAME_LIST";
	
	/**
	 * CLASS1
	 */
	public final static String CLASS1 = "1001";

	/**
	 * CLASS2
	 */
	public final static String CLASS2 = "1002";

	/**
	 * CLASS3
	 */
	public final static String CLASS3 = "1003";
	
	/**
	 * DATE_FORMAT
	 */
	public final static String DATE_FORMAT = "MM/dd/yyyy";
	
	/**
	 * ACCOUNT_CAT_NEW
	 */
	public final static String ACCOUNT_CAT_NEW = "new";

	/**
	 * ACCOUNT_CAT_SUB
	 */
	public final static String ACCOUNT_CAT_SUB = "existing";
	
	public final static String UPDATE_MASTER = "updateExisting";
	
	/**
	 * SUCCESS MESSAGE
	 */
	public final static String SUCCESS_MSG = "FILE UPLOADED SUCCESSFULLY";
}
