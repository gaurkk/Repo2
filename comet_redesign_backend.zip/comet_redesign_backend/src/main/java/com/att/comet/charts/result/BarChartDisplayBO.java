package com.att.comet.charts.result;

public class BarChartDisplayBO implements DisplayResultBO {
	private static final long serialVersionUID = 4054239138397753673L;

	
}
