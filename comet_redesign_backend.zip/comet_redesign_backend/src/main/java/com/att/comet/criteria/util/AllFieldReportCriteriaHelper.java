package com.att.comet.criteria.util;

import org.springframework.stereotype.Component;

import com.att.comet.common.constant.SearchColumnForAllReport;
import com.att.comet.common.constant.SearchFilterForReport;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.SearchCriteriaImpl;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericBooleanRestriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericDateRestriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericIPRangeRestriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericNoRestriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericNumberRestriction;
import com.att.comet.restriction.allfieldreport.AllFieldGenericStringRestriction;

@Component
public class AllFieldReportCriteriaHelper {
	private SearchCriteria criteria;

	/**
	 * Get the object of Search Criteria
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria() throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl() : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format) : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format and other
	 * details
	 * 
	 * @return SearchCriteria
	 */
	public SearchCriteria getCriteria(OutputFormat format, OtherDetails other) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format, other) : criteria.clone());
	}

	/**
	 * Get Initial data to result
	 * 
	 * @return Restriction
	 */
	public Restriction initalData() {
		return new AllFieldGenericNoRestriction();
	}

	/**
	 * Add boolean as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction booleanRestriction(SearchFilterForReport filter, SearchColumnForAllReport column,
			Boolean propertyValue) {
		return new AllFieldGenericBooleanRestriction(column, filter, propertyValue);
	}

	/**
	 * Add String as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction stringRestriction(SearchFilterForReport filter, SearchColumnForAllReport column,
			String propertyValue) {
		return new AllFieldGenericStringRestriction(column, filter, propertyValue);
	}

	/**
	 * Add Number as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction numberRestriction(SearchFilterForReport filter, SearchColumnForAllReport column,
			String propertyValue) {
		return new AllFieldGenericNumberRestriction(column, filter, propertyValue);
	}

	/**
	 * Add Date as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction dateRestriction(SearchColumnForAllReport column, String fromDate, String toDate) {
		return new AllFieldGenericDateRestriction(column, fromDate, toDate);
	}

	/**
	 * Add IP Range as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public Restriction ipRangeRestriction(SearchFilterForReport filter, SearchColumnForAllReport column,
			String propertyValue) {
		return new AllFieldGenericIPRangeRestriction(column, filter, propertyValue);
	}
}
