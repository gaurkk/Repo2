package com.att.comet.audit.helper;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.apn.EnterpriseTargetIpRangeBO;
import com.att.comet.apn.PdpIdInfoBO;
import com.att.comet.apn.helper.ApnHelper;
import com.att.comet.audit.modal.OrderAuditBO;
import com.att.comet.audit.modal.RowData;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.BackhaulConfigBO;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.crd.modal.ConnectivityMatrixBO;
import com.att.comet.order.crd.modal.CrdBO;
import com.att.comet.order.crd.modal.CrdDataCenterBO;
import com.att.comet.order.modal.BackhaulBO;
import com.att.comet.order.modal.BillingDetailsBO;
import com.att.comet.order.modal.DedicatedApnBO;
import com.att.comet.order.modal.OrderDataCenterBO;
import com.att.comet.order.modal.OrderSummaryBO;

import oracle.sql.TIMESTAMP;

@Component
public class OrderAuditHelper {
	
	@Autowired
	ApnHelper apnHelper;

	/**
	 * Returns the Init Order Config Audit info
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return OrderAuditBO
	 * @throws SQLException
	 */
	public OrderAuditBO getInitOrderConfigAuditInfo(StoredProcedureQuery spQuery) throws SQLException {
		OrderAuditBO orderBO = null;
		
		List<RowData> orderResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> orderDataCenterResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		List<RowData> orderDataCenterBackhaulResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(5));
		List<RowData> orderLocation = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(6));

		// Set Order Values
		Object columnValue = null;
		if (orderResults != null && !orderResults.isEmpty()) {
			orderBO = new OrderAuditBO();
			for (RowData orderRow : orderResults) {
				columnValue = orderRow.getColumnValue("order_id");
				if (columnValue != null) {
					orderBO.setOrderId(((BigDecimal) columnValue).longValue());
				}
				
				columnValue = orderRow.getColumnValue("order_status_id");
				if (columnValue != null) {
					orderBO.setOrderStatus(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRow.getColumnValue("num_data_centers");
				if (columnValue != null) {
					orderBO.setNumDataCenters(((BigDecimal) columnValue).longValue());
				}
				columnValue = orderRow.getColumnValue("bcid");
				if (columnValue != null) {
					orderBO.setBcid((String) columnValue);
				}
				columnValue = orderRow.getColumnValue("cipn");
				if (columnValue != null) {
					orderBO.setCipn((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("apn_selection");
				if (columnValue != null) {
					orderBO.setApnSelection((String) columnValue);
				}
				columnValue = orderRow.getColumnValue("backhaul_selection");
				if (columnValue != null) {
					orderBO.setBackHaulSelection((String) columnValue);
				}
				columnValue = orderRow.getColumnValue("created_by");
				if (columnValue != null) {
					orderBO.setCreatedBy((String) columnValue);
				}
				columnValue = orderRow.getColumnValue("created_on");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					orderBO.setCreatedOn(oraTimestamp.timestampValue());
				}
				columnValue = orderRow.getColumnValue("updated_by");
				if (columnValue != null) {
					orderBO.setUpdatedBy((String) columnValue);
				}
				columnValue = orderRow.getColumnValue("updated_on");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					orderBO.setUpdatedOn(oraTimestamp.timestampValue());
				}
				columnValue = orderRow.getColumnValue("submitted_on");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					orderBO.setSubmittedOn(oraTimestamp.timestampValue());
				}

				columnValue = orderRow.getColumnValue("order_type_id");
				if (columnValue != null) {
					orderBO.setOrderType(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRow.getColumnValue("derived_from_order");
				if (columnValue != null) {
					orderBO.setDerivedFromOrder(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRow.getColumnValue("expedite");
				if (columnValue != null) {
					orderBO.setExpediteAction((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("recovery_flow_chart");
				if (columnValue != null) {
					orderBO.setRecoveryFlowChart(((Blob) columnValue).getBinaryStream());
				}

				columnValue = orderRow.getColumnValue("recovery_flow_chart_filename");
				if (columnValue != null) {
					orderBO.setRecoveryFlowChartName((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("exceptional");
				if (columnValue != null) {
					orderBO.setExceptional(((String) columnValue).toCharArray()[0]);
				}

				columnValue = orderRow.getColumnValue("base_order");
				if (columnValue != null) {
					orderBO.setBaseOrder(((String) columnValue).toCharArray()[0]);
				}

				columnValue = orderRow.getColumnValue("date_in_production");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					orderBO.setDateInProduction(oraTimestamp.timestampValue());
				}

				columnValue = orderRow.getColumnValue("base_order_notes");
				if (columnValue != null) {
					orderBO.setBaseOrderNotes((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("comments");
				if (columnValue != null) {
					orderBO.setComments((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("change_request");
				if (columnValue != null) {
					orderBO.setChangeRequest(((String) columnValue).toCharArray()[0]);
				}

				// Starts -- BUC ID 2.2.09
				columnValue = orderRow.getColumnValue("cus_pref_dc_comments");
				if (columnValue != null) {
					orderBO.setCustomerPrefDCComments((String) columnValue);
				}
				// Ends -- BUC ID 2.2.09

			}

			Set<OrderDataCenterBO> orderDataCenters = null;
			OrderDataCenterBO orderDataCenterBO = null;

			Long dataCenterId = null;
			if (orderDataCenterResults != null && !orderDataCenterResults.isEmpty()) {
				orderDataCenters = new TreeSet<OrderDataCenterBO>();
				
				for (RowData rowData : orderDataCenterResults) {
					orderDataCenterBO = new OrderDataCenterBO();

					columnValue = rowData.getColumnValue("order_id");
					if (columnValue != null) {
						orderDataCenterBO.setOrderId(((BigDecimal) columnValue).longValue());
					}

					columnValue = rowData.getColumnValue("data_center_id");
					if (columnValue != null) {
						dataCenterId = ((BigDecimal) columnValue).longValue();
						orderDataCenterBO.setDataCenterId(dataCenterId);
					}

					columnValue = rowData.getColumnValue("num_new_backhauls");
					if (columnValue != null) {
						orderDataCenterBO.setNumNewBackhauls(((BigDecimal) columnValue).longValue());
					}

					columnValue = rowData.getColumnValue("active");
					if (columnValue != null) {
						orderDataCenterBO.setActive(((String) columnValue).charAt(0));
					}

					columnValue = rowData.getColumnValue("data_center_type");
					if (columnValue != null) {
						orderDataCenterBO.setDataCenterType(((String) columnValue).charAt(0));
					}

					columnValue = rowData.getColumnValue("pr_dc_router_failover_config");
					if (columnValue != null) {
						orderDataCenterBO.setPrimaryDcRouterFailoverConfig((String) columnValue);
					}

					columnValue = rowData.getColumnValue("active_router");
					if (columnValue != null) {
						orderDataCenterBO.setActiveRouter((String) columnValue);
					}

					columnValue = rowData.getColumnValue("active_interface");
					if (columnValue != null) {
						orderDataCenterBO.setActiveInterface((String) columnValue);
					}

					columnValue = rowData.getColumnValue("dc_sort_order");
					if (columnValue != null) {
						orderDataCenterBO.setDcSortOrder(((BigDecimal) columnValue).intValue());
					}
					columnValue = rowData.getColumnValue("snapactive");
					if (columnValue != null) {
						orderDataCenterBO.setSnapActive(((String) columnValue).charAt(0));
					}else{
						columnValue = rowData.getColumnValue("active");
						if (columnValue != null) {
							orderDataCenterBO.setSnapActive(((String) columnValue).charAt(0));
						}
					}

					if (orderDataCenterBackhaulResults != null && !orderDataCenterBackhaulResults.isEmpty()) {
						Set<BackhaulBO> backhauls = getDataCenterBackhauls(orderDataCenterBackhaulResults, dataCenterId);
						if (backhauls != null && !backhauls.isEmpty()) {
							orderDataCenterBO.setBackhauls(backhauls);
						}
					}
					orderDataCenters.add(orderDataCenterBO);
				}
				orderBO.setOrderDataCenters(orderDataCenters);
			}

			if (orderLocation != null && !orderLocation.isEmpty()) {
				StringBuilder location = new StringBuilder();

				for (RowData rowData : orderLocation) {

					columnValue = (String) rowData.getColumnValue("street_address");
					if (columnValue != null) {
						location.append(columnValue);
						location.append("   ");
					}

					columnValue = (String) rowData.getColumnValue("city_name");
					if (columnValue != null) {
						location.append(columnValue);
						location.append("   ");
					}

					columnValue = (String) rowData.getColumnValue("state_name");
					if (columnValue != null) {
						location.append(columnValue);
						location.append("   ");
					}

					columnValue = (String) rowData.getColumnValue("zip_code");
					if (columnValue != null) {
						location.append(columnValue);
						location.append("   ");
					}
				}
				orderBO.setHeadQuarterLocation(location.toString().trim());
			}
		}
		return orderBO;
	}
	
	/**
	 * Returns the Data Center Back-hauls info.
	 * 
	 * @param pOrderDCBHList
	 * @param dataCenterId
	 * @return Set<BackhaulBO>
	 */
	private Set<BackhaulBO> getDataCenterBackhauls(List<RowData> pOrderDCBHList, Long dataCenterId) {

		Set<BackhaulBO> backhauls = new TreeSet<BackhaulBO>();
		Object columnValue = null;
		Long backhaulId = null;
		Long backhaulTypeId = null;
		String backhaulSelection = null;
		String backhaulTypeName = null;
		String backhaulDisplayId = null;
		String createdBy = null;

		for (RowData rowData : pOrderDCBHList) {
			columnValue = rowData.getColumnValue("data_center_id");
			if (columnValue != null) {
				Long dcId = ((BigDecimal) columnValue).longValue();
				if (dcId.equals(dataCenterId)) {
					columnValue = rowData.getColumnValue("backhaul_id");
					if (columnValue != null) {
						backhaulId = ((BigDecimal) columnValue).longValue();
					}

					columnValue = rowData.getColumnValue("backhaul_display_id");
					if (columnValue != null) {
						backhaulDisplayId = ((String) columnValue);
					}

					columnValue = rowData.getColumnValue("created_by");
					if (columnValue != null) {
						createdBy = ((String) columnValue);
					}

					columnValue = rowData.getColumnValue("backhaul_type_id");
					if (columnValue != null) {
						backhaulTypeId = ((BigDecimal) columnValue).longValue();
					}

					columnValue = rowData.getColumnValue("backhaul_selection");
					if (columnValue != null) {
						backhaulSelection = (String) columnValue;
					}

					columnValue = rowData.getColumnValue("backhaul_type_name");
					if (columnValue != null) {
						backhaulTypeName = (String) columnValue;
					}

					BackhaulBO backhaulBO = new BackhaulBO();
					backhaulBO.setBackhaulId(backhaulId);
					backhaulBO.setBackhaulTypeId(backhaulTypeId);
					backhaulBO.setBackhaulSelection(backhaulSelection);
					backhaulBO.setDataCenterId(dcId);
					backhaulBO.setBackhaulTypeName(backhaulTypeName);
					backhaulBO.setBackhaulDisplayId(backhaulDisplayId);
					backhaulBO.setCreatedBy(createdBy);
					backhauls.add(backhaulBO);
				}
			}
		}
		return backhauls;
	}

	/**
	 * Returns the BackHaul Config auidt info.
	 * 
	 * @param orderId
	 * @param backhaulConfigResults
	 * @return BackhaulConfigBO
	 * @throws SQLException
	 */
	public BackhaulConfigBO getBackhaulConfigAuditInfo(Long orderId, List<RowData> backhaulConfigResults) throws SQLException {
		BackhaulConfigBO backhaulConfigBO = null;
		Object columnValue = null;
		if (backhaulConfigResults != null) {
			for (RowData orderRow : backhaulConfigResults) {
				backhaulConfigBO = new BackhaulConfigBO();

				columnValue = orderRow.getColumnValue("order_id");
				if (columnValue != null) {
					backhaulConfigBO.setOrderId(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRow.getColumnValue("excp_request_approver");
				if (columnValue != null) {
					backhaulConfigBO.setExcpRequestApprover((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("excp_approver_date");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					backhaulConfigBO.setExcpApproverDate(oraTimestamp.timestampValue());
				}

				columnValue = orderRow.getColumnValue("excp_approval_number");
				if (columnValue != null) {
					backhaulConfigBO.setExcpApprovalNumber((String) columnValue);
				}

				columnValue = orderRow.getColumnValue("notes");
				if (columnValue != null) {
					backhaulConfigBO.setNotes((String) columnValue);
				}
				
				columnValue = orderRow.getColumnValue("MSP_IWOS");
				if (columnValue != null) {
					backhaulConfigBO.setNotes((String) columnValue);
				}
				
				columnValue = orderRow.getColumnValue("MSP_WHITEBLACK_LIST");
				if (columnValue != null) {
					backhaulConfigBO.setNotes((String) columnValue);
				}
				
				columnValue = orderRow.getColumnValue("IWOS");
				if (columnValue != null) {
					backhaulConfigBO.setNotes((String) columnValue);
				}
				
				columnValue = orderRow.getColumnValue("WHITELIST_OF_BLACKLIST");
				if (columnValue != null) {
					backhaulConfigBO.setNotes((String) columnValue);
				}

			}
		}
		return backhaulConfigBO;
	}

	/**
	 * Returns the CRD Audit Info data.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return CrdBO
	 * @throws SQLException
	 */
	public CrdBO getCrdAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		List<RowData> crdResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> crdDCResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		List<RowData> connMatrixResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(5));
		CrdBO crdBO = null;
		Object columnValue = null;
		Long crdId = null;

		if (crdResults != null) {
			crdBO = new CrdBO();
			RowData crdRowData = crdResults.get(0);

			columnValue = crdRowData.getColumnValue("CRD_ID");
			if (columnValue != null) {
				crdId = ((BigDecimal) columnValue).longValue();
				crdBO.setCrdId(crdId);
			}

			columnValue = crdRowData.getColumnValue("ORDER_ID");
			if (columnValue != null) {
				crdBO.setOrderId(((BigDecimal) columnValue).longValue());
			}

			columnValue = crdRowData.getColumnValue("APN_ID");
			if (columnValue != null) {
				crdBO.setApnId((String) columnValue);
			}

			columnValue = crdRowData.getColumnValue("REQUEST_TYPE");
			if (columnValue != null) {
				crdBO.setRequestType((String) columnValue);
			}

			columnValue = crdRowData.getColumnValue("INSTRUCTIONS");
			if (columnValue != null) {
				crdBO.setInstructions((String) columnValue);
			}

			columnValue = crdRowData.getColumnValue("SELF_IMPACT_ASSESSMENT");
			if (columnValue != null) {
				crdBO.setSelfImpactAssessment((String) columnValue);
			}

			columnValue = crdRowData.getColumnValue("IMPACT_DETAILS");
			if (columnValue != null) {
				crdBO.setImpactDetails((String) columnValue);
			}

			columnValue = crdRowData.getColumnValue("BUSINESS_PURPOSE");
			if (columnValue != null) {
				crdBO.setBusinessPurpose((String) columnValue);
			}

			if (crdDCResults != null && !crdDCResults.isEmpty()) {
				List<CrdDataCenterBO> crdDCBOs = new ArrayList<CrdDataCenterBO>();
				crdBO.setCrdDataCenter(crdDCBOs);
				for (RowData crdDCRowData : crdDCResults) {
					CrdDataCenterBO crdDataCenterBO = new CrdDataCenterBO();
					crdDCBOs.add(crdDataCenterBO);
					Long dataCenterId = null;

					columnValue = crdDCRowData.getColumnValue("DATA_CENTER_ID");
					if (columnValue != null) {
						dataCenterId = ((BigDecimal) columnValue).longValue();
						crdDataCenterBO.setDataCenterId(dataCenterId);
					}

					columnValue = crdDCRowData.getColumnValue("DATA_CENTER_NAME");
					if (columnValue != null) {
						crdDataCenterBO.setDataCenterName((String) columnValue);
					}

					columnValue = crdDCRowData.getColumnValue("CRD_ID");
					if (columnValue != null) {
						crdDataCenterBO.setCrdId(((BigDecimal) columnValue).longValue());
					}

					columnValue = crdDCRowData.getColumnValue("STRICT_TCP_ENFC_ENABLED");
					if (columnValue != null) {
						crdDataCenterBO.setStrictTcpEnfcEnabled(((String) columnValue).charAt(0));
					}

					columnValue = crdDCRowData.getColumnValue("TESTING_REQUIRED");
					if (columnValue != null) {
						crdDataCenterBO.setTestingRequired(((String) columnValue).charAt(0));
					}

					columnValue = crdDCRowData.getColumnValue("IMPLEMENT_DATE");
					if (columnValue != null) {
						TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
						crdDataCenterBO.setImplementDate(oraTimestamp.timestampValue());
					}

					columnValue = crdDCRowData.getColumnValue("EXPIRATION_DATE");
					if (columnValue != null) {
						TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
						crdDataCenterBO.setExpirationDate(oraTimestamp.timestampValue());
					}

					TreeSet<ConnectivityMatrixBO> matrixBOs = new TreeSet<ConnectivityMatrixBO>();
					crdDataCenterBO.setConnectivityMatrix(matrixBOs);
					for (Long index = 1L; index <= 11; index++) {
						ConnectivityMatrixBO matrixBO = new ConnectivityMatrixBO();
						matrixBOs.add(matrixBO);
						matrixBO.setCrdId(crdId);
						matrixBO.setDataCenterId(dataCenterId);
						matrixBO.setScenario(index);

						if (connMatrixResults != null && !connMatrixResults.isEmpty()) {
							for (RowData connMatrixRowData : connMatrixResults) {
								Long matrixDcId = ((BigDecimal) connMatrixRowData.getColumnValue("DATA_CENTER_ID")).longValue();
								Long matrixScenarioId = ((BigDecimal) connMatrixRowData.getColumnValue("SCENARIO")).longValue();
								if (matrixDcId.equals(dataCenterId) && matrixScenarioId.equals(index)) {
									columnValue = connMatrixRowData.getColumnValue("SOURCE_IP_ADDRESS");
									if (columnValue != null) {
										matrixBO.setSourceIpAddress((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("DIRECTION_INDICATOR");
									if (columnValue != null) {
										matrixBO.setDirectionIndicator((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("DESTINATION_IP_ADDRESS");
									if (columnValue != null) {
										matrixBO.setDestinationIpAddress((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("DESTINATION_DATA_CENTER");
									if (columnValue != null) {
										matrixBO.setDestinationDataCenter((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("SERVICE_PROTOCOL");
									if (columnValue != null) {
										matrixBO.setServiceProtocol((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("CUSTOMER_VLAN_ID");
									if (columnValue != null) {
										matrixBO.setCustomerVlanId((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("AUTO_VLAN_ID");
									if (columnValue != null) {
										matrixBO.setAutoVlanId((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("COMPLETE_REQUEST_COMMNETS");
									if (columnValue != null) {
										matrixBO.setCompleteRequestComments((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("DESTINATION_IP_ADDRESS_DNS");
									if (columnValue != null) {
										matrixBO.setDestinationIpAddressDns((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("ATT_MOBILITY_VPN_ROUTERS");
									if (columnValue != null) {
										matrixBO.setAttMobilityvpnRouter((String) columnValue);
									}

									columnValue = connMatrixRowData.getColumnValue("DNS");
									if (columnValue != null) {
										matrixBO.setDns((String) columnValue);
									}
								}
							}
						}
					}
				}
			}
		}
		return crdBO;
	}

	/**
	 * Returns the Order Summary Info.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @param session
	 * @return OrderSummaryBO
	 * @throws SQLException
	 */
	public OrderSummaryBO getOrderSummaryAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException, CometDataException {

		List<RowData> orderResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> apnResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		List<RowData> orderDCResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(5));
		List<RowData> entIpResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(6));
		List<RowData> orderDCBHResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(7));
		List<RowData> orderAccountResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(8));
		List<RowData> pdpIdInfoResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(9));

		Object columnValue = null;
		OrderSummaryBO summeryBO = null;
		TreeSet<OrderDataCenterBO> dataCenterBOs = null;
		OrderDataCenterBO dataCenterBO = null;

		if (orderResults != null && !orderResults.isEmpty()) {
			RowData orderRowData = orderResults.get(0);
			summeryBO = new OrderSummaryBO();
			summeryBO.setOrderId(orderId);
			columnValue = orderRowData.getColumnValue("APN_SELECTION");
			if (columnValue != null) {
				summeryBO.setApnSelection((String) columnValue);
			}

			columnValue = orderRowData.getColumnValue("BCID");
			if (columnValue != null) {
				summeryBO.setBcid((String) columnValue);
				summeryBO.setAccountClassId(1001L);

				columnValue = orderRowData.getColumnValue("MAIN_CUST_CONTACT");
				if (columnValue != null) {
					summeryBO.setMainCustContact((String) columnValue);
				}

				columnValue = orderRowData.getColumnValue("MCC_CELLPHONE");
				if (columnValue != null) {
					summeryBO.setMccCellphone(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRowData.getColumnValue("MCC_DESKPHONE");
				if (columnValue != null) {
					summeryBO.setMccDeskphone(((BigDecimal) columnValue).longValue());
				}

				columnValue = orderRowData.getColumnValue("MCC_EMAIL");
				if (columnValue != null) {
					summeryBO.setMccEmail((String) columnValue);
				}

				columnValue = orderRowData.getColumnValue("UBCID");
				if (columnValue != null) {
					summeryBO.setUbcid((String) columnValue.toString());
				}

				columnValue = orderRowData.getColumnValue("SUB_ACCOUNT_NAME");
				if (columnValue != null) {
					summeryBO.setSubAccountName((String) columnValue);
				}

				columnValue = orderRowData.getColumnValue("MASTER_ACCOUNT_NAME");
				if (columnValue != null) {
					summeryBO.setMasterAccountName((String) columnValue);
				}
			}

			columnValue = orderRowData.getColumnValue("CIPN");
			if (columnValue != null) {
				summeryBO.setCipn((String) columnValue);

				columnValue = orderRowData.getColumnValue("INTERNAL_PRODUCT_ACCOUNT_NAME");
				if (columnValue != null) {
					summeryBO.setIpAccountName((String) columnValue);
				}

				columnValue = orderRowData.getColumnValue("ACCOUNT_CLASS_ID");
				if (columnValue != null) {
					summeryBO.setAccountClassId(((BigDecimal) columnValue).longValue());
				}
			}

			if (apnResults != null && !apnResults.isEmpty()) {
				RowData apnRowData = apnResults.get(0);

				columnValue = apnRowData.getColumnValue("ADDRESS_TYPE");
				if (columnValue != null) {
					summeryBO.setAddressType((String) columnValue);
				}

				columnValue = apnRowData.getColumnValue("APN_NAME");
				if (columnValue != null) {
					summeryBO.setApnName((String) columnValue);
				}

				columnValue = apnRowData.getColumnValue("IP_ADDRESS_SOURCE");
				if (columnValue != null) {
					summeryBO.setIpAddressSource((String) columnValue);
				}

				// PdpIdInfo

				if (pdpIdInfoResults != null && pdpIdInfoResults.size() > 0) {
					List<PdpIdInfoBO> pdpIdInfoBOs = new ArrayList<PdpIdInfoBO>();
					for (RowData pdpIdInfoRow : pdpIdInfoResults) {
						PdpIdInfoBO pdpIdInfoBO = new PdpIdInfoBO();
						Long ipOrderId = ((BigDecimal) pdpIdInfoRow.getColumnValue("ORDER_ID")).longValue();
						if (orderId.equals(ipOrderId)) {
							pdpIdInfoBO.setOrderId(ipOrderId);
							columnValue = pdpIdInfoRow.getColumnValue("auto_pdp_id");
							if (columnValue != null) {
								pdpIdInfoBO.setAutoPdpId(((BigDecimal) columnValue).longValue());
							}
							
							columnValue = pdpIdInfoRow.getColumnValue("user_pdp_id");
							if (columnValue != null) {
								pdpIdInfoBO.setUserPdpId(((BigDecimal) columnValue).longValue());
							}
							
							columnValue = pdpIdInfoRow.getColumnValue("basic_pdp_id");
							if (columnValue != null) {
								pdpIdInfoBO.setBasicPdpId(((String) columnValue).charAt(0));
							}
							
							columnValue = pdpIdInfoRow.getColumnValue("auto_pdp_name");
							if (columnValue != null) {
								pdpIdInfoBO.setAutoPdpName(((String) columnValue));
							}

							pdpIdInfoBOs.add(pdpIdInfoBO);
						}

					}
					summeryBO.setPdpNameList(pdpIdInfoBOs);
				}

				columnValue = apnRowData.getColumnValue("MOBILE_TERMINATION_ENABLED");
				if (columnValue != null) {
					summeryBO.setMobileTerminationEnabled(((String) columnValue).charAt(0));
				}

				columnValue = apnRowData.getColumnValue("MOBILE_TO_MOBILE_ENABLED");
				if (columnValue != null) {
					summeryBO.setMobileToMobileEnabled(((String) columnValue).charAt(0));
				}

				columnValue = apnRowData.getColumnValue("TOTAL_MOBILE_POOL_SIZE");
				if (columnValue != null) {
					summeryBO.setTotalMobilePoolSize(((BigDecimal) columnValue).longValue());
				}

				if (entIpResults != null && !entIpResults.isEmpty()) {
					List<EnterpriseTargetIpRangeBO> ipRangeBOs = new ArrayList<EnterpriseTargetIpRangeBO>();
					summeryBO.setEntTargetIpRanges(ipRangeBOs);
					for (RowData entIpRowData : entIpResults) {
						EnterpriseTargetIpRangeBO ipRangeBO = new EnterpriseTargetIpRangeBO();
						ipRangeBOs.add(ipRangeBO);
						ipRangeBO.setOrderId(orderId);
						columnValue = entIpRowData.getColumnValue("ENT_TARGET_IP_RANGE");
						if (columnValue != null) {
							ipRangeBO.setEntTargetIpRange((String) columnValue);
						}
					}
				}
			}

			DedicatedApnBO dedicatedApnBO = apnHelper.getDedicatedApnByOrder(orderId);
			if (dedicatedApnBO != null) {
				summeryBO.setAddressType(dedicatedApnBO.getAddressType());
				summeryBO.setApnName(dedicatedApnBO.getApnName());
				summeryBO.setIpAddressSource(dedicatedApnBO.getIpAddressSource());
				summeryBO.setPdpName(dedicatedApnBO.getPdpName());
				summeryBO.setMobileTerminationEnabled(dedicatedApnBO.getMobileTerminationEnabled());
				summeryBO.setMobileToMobileEnabled(dedicatedApnBO.getMobileToMobileEnabled());
				summeryBO.setTotalMobilePoolSize(dedicatedApnBO.getTotalMobilePoolSize());
			}

			if (orderDCResults != null && !orderDCResults.isEmpty()) {
				dataCenterBOs = new TreeSet<OrderDataCenterBO>();
				summeryBO.setDataCenters(dataCenterBOs);

				for (RowData orderDCRowData : orderDCResults) {
					dataCenterBO = new OrderDataCenterBO();
					dataCenterBOs.add(dataCenterBO);
					dataCenterBO.setOrderId(orderId);

					Long dataCenterId = null;

					columnValue = orderDCRowData.getColumnValue("DATA_CENTER_ID");
					if (columnValue != null) {
						dataCenterId = ((BigDecimal) columnValue).longValue();
						dataCenterBO.setDataCenterId(dataCenterId);
					}

					columnValue = orderDCRowData.getColumnValue("DATA_CENTER_NAME");
					if (columnValue != null) {
						dataCenterBO.setDataCenterName((String) columnValue);
					}

					columnValue = orderDCRowData.getColumnValue("NUM_NEW_BACKHAULS");
					if (columnValue != null) {
						dataCenterBO.setNumNewBackhauls(((BigDecimal) columnValue).longValue());
					}

					columnValue = orderDCRowData.getColumnValue("ACTIVE");
					if (columnValue != null) {
						dataCenterBO.setActive(((String) columnValue).charAt(0));
					}

					columnValue = orderDCRowData.getColumnValue("PR_DC_ROUTER_FAILOVER_CONFIG");
					if (columnValue != null) {
						dataCenterBO.setPrimaryDcRouterFailoverConfig((String) columnValue);
					}

					columnValue = orderDCRowData.getColumnValue("ACTIVE_ROUTER");
					if (columnValue != null) {
						dataCenterBO.setActiveRouter((String) columnValue);
					}

					columnValue = orderDCRowData.getColumnValue("ACTIVE_INTERFACE");
					if (columnValue != null) {
						dataCenterBO.setActiveInterface((String) columnValue);
					}

					columnValue = orderDCRowData.getColumnValue("DATA_CENTER_TYPE");
					if (columnValue != null) {
						dataCenterBO.setDataCenterType(((String) columnValue).charAt(0));
					}

					columnValue = orderDCRowData.getColumnValue("DC_SORT_ORDER");
					if (columnValue != null) {
						dataCenterBO.setDcSortOrder(((BigDecimal) columnValue).intValue());
					}
					
					if (orderDCBHResults != null && !orderDCBHResults.isEmpty()) {
						Set<BackhaulBO> backhaulBOs = null;
						for (RowData orderDCBHRowData : orderDCBHResults) {

							Long orderBackhaulDataCenterId = null;
							columnValue = orderDCBHRowData.getColumnValue("DATA_CENTER_ID");
							if (columnValue != null) {
								orderBackhaulDataCenterId = ((BigDecimal) columnValue).longValue();
							}

							if (orderBackhaulDataCenterId.equals(dataCenterId)) {
								if (backhaulBOs == null) {
									backhaulBOs = new TreeSet<BackhaulBO>();
									dataCenterBO.setBackhauls(backhaulBOs);
								}

								BackhaulBO backhaulBO = new BackhaulBO();
								backhaulBO.setDataCenterId(dataCenterId);
								backhaulBOs.add(backhaulBO);

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_ID");
								if (columnValue != null) {
									backhaulBO.setBackhaulId(((BigDecimal) columnValue).longValue());
								}

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_SELECTION");
								if (columnValue != null) {
									backhaulBO.setBackhaulSelection((String) columnValue);
								}

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_TYPE_NAME");
								if (columnValue != null) {
									backhaulBO.setBackhaulTypeName((String) columnValue);
								}

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_TYPE_ID");
								if (columnValue != null) {
									backhaulBO.setBackhaulTypeId(((BigDecimal) columnValue).longValue());
								}

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_DISPLAY_ID");
								if (columnValue != null) {
									backhaulBO.setBackhaulDisplayId((String) columnValue);
								}

								columnValue = orderDCBHRowData.getColumnValue("BACKHAUL_DISPLAY_ID");
								if (columnValue != null) {
									backhaulBO.setBackhaulDisplayId((String) columnValue);
								}

								columnValue = orderDCBHRowData.getColumnValue("CREATED_BY");
								if (columnValue != null) {
									backhaulBO.setCreatedBy((String) columnValue);
								}

								columnValue = orderDCBHRowData.getColumnValue("CREATED_ON");
								if (columnValue != null) {
									TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
									backhaulBO.setCreatedOn(oraTimestamp.timestampValue());
								}
							}
						}
					}
				}
			}

			if (orderAccountResults != null && !orderAccountResults.isEmpty()) {
				RowData orderAccountRowData = orderAccountResults.get(0);
				if (orderAccountRowData != null) {
					columnValue = orderAccountRowData.getColumnValue("FAN_ID");
					if (columnValue != null) {
						summeryBO.setFanId((String) columnValue);
					}
				}
			}
		}
		return summeryBO;
	}

	public BillingDetailsBO getOrderBillingAuditInfo(Long orderId, List<RowData> orderBillingConfigResults) throws SQLException {
		BillingDetailsBO billingDetailsBO = null;
		Object columnValue = null;
		if (orderBillingConfigResults != null) {
			for (RowData orderRow : orderBillingConfigResults) {
				billingDetailsBO = new BillingDetailsBO();				
				columnValue = orderRow.getColumnValue("dateBillingComplete");
				if (columnValue != null) {
					TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
					billingDetailsBO.setDateBillingComplete(oraTimestamp.timestampValue());
				}				
				columnValue = orderRow.getColumnValue("companyBillingAddress");
				if (columnValue != null) {
					billingDetailsBO.setCompanyBillingAddress((String) columnValue);				
				}

				columnValue = orderRow.getColumnValue("ctnSim");
				if (columnValue != null) {
					billingDetailsBO.setCtnSim((String) columnValue);
				}				
			}
		}
		return billingDetailsBO;
	}

}
