package com.att.comet.apn;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper=true)
public class PersistentIpBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 2265368660833522816L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String ipAddress;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String username;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String password;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long persistentIpId;

}
