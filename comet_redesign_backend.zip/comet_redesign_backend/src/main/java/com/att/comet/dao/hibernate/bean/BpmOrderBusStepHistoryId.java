package com.att.comet.dao.hibernate.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderBusStepHistoryId.
 */
@Embeddable
public class BpmOrderBusStepHistoryId implements java.io.Serializable {

	private static final long serialVersionUID = 8296872669236494307L;

	private Long orderId;
	private Long businessStepId;
	private Long orderTypeId;
	private String businessStepStatus;
	private String businessStepValue;
	private Date businessStepExecutedOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;

	/**
	 * No-argument constructor of the class.
	 */
	public BpmOrderBusStepHistoryId() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderId
	 * @param businessStepId
	 * @param businessStepStatus
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderBusStepHistoryId(Long orderId, Long businessStepId, String businessStepStatus, Date createdOn,
			Date updatedOn) {
		this.orderId = orderId;
		this.businessStepId = businessStepId;
		this.businessStepStatus = businessStepStatus;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param orderId
	 * @param businessStepId
	 * @param orderTypeId
	 * @param businessStepStatus
	 * @param businessStepValue
	 * @param businessStepExecutedOn
	 * @param comments
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderBusStepHistoryId(Long orderId, Long businessStepId, Long orderTypeId, String businessStepStatus,
			String businessStepValue, Date businessStepExecutedOn, String comments, Date createdOn, Date updatedOn) {
		this.orderId = orderId;
		this.businessStepId = businessStepId;
		this.orderTypeId = orderTypeId;
		this.businessStepStatus = businessStepStatus;
		this.businessStepValue = businessStepValue;
		this.businessStepExecutedOn = businessStepExecutedOn;
		this.comments = comments;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return orderId
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for businessStepId. BUSINESS_STEP_ID mapped to BUSINESS_STEP_ID
	 * in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BUSINESS_STEP_ID", nullable = false, precision = 12, scale = 0)
	public Long getBusinessStepId() {
		return this.businessStepId;
	}

	/**
	 * @param businessStepId to businessStepId set.
	 */
	public void setBusinessStepId(Long businessStepId) {
		this.businessStepId = businessStepId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/**
	 * Getter method for businessStepStatus. BUSINESS_STEP_STATUS mapped to
	 * BUSINESS_STEP_STATUS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_STEP_STATUS", nullable = false, length = 100)
	public String getBusinessStepStatus() {
		return this.businessStepStatus;
	}

	/**
	 * @param businessStepStatus to businessStepStatus set.
	 */
	public void setBusinessStepStatus(String businessStepStatus) {
		this.businessStepStatus = businessStepStatus;
	}

	/**
	 * Getter method for businessStepValue. BUSINESS_STEP_VALUE mapped to
	 * BUSINESS_STEP_VALUE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_STEP_VALUE", length = 500)
	public String getBusinessStepValue() {
		return this.businessStepValue;
	}

	/**
	 * @param businessStepValue to businessStepValue set.
	 */
	public void setBusinessStepValue(String businessStepValue) {
		this.businessStepValue = businessStepValue;
	}

	/**
	 * Getter method for businessStepExecutedOn. BUSINESS_STEP_EXECUTED_ON mapped to
	 * BUSINESS_STEP_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "BUSINESS_STEP_EXECUTED_ON")
	public Date getBusinessStepExecutedOn() {
		return this.businessStepExecutedOn;
	}

	/**
	 * @param businessStepExecutedOn to businessStepExecutedOn set.
	 */
	public void setBusinessStepExecutedOn(Date businessStepExecutedOn) {
		this.businessStepExecutedOn = businessStepExecutedOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date.
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderBusStepHistoryId))
			return false;
		BpmOrderBusStepHistoryId castOther = (BpmOrderBusStepHistoryId) other;

		return (this.getOrderId() == castOther.getOrderId())
				&& (this.getBusinessStepId() == castOther.getBusinessStepId())
				&& ((this.getOrderTypeId() == castOther.getOrderTypeId())
						|| (this.getOrderTypeId() != null && castOther.getOrderTypeId() != null
								&& this.getOrderTypeId().equals(castOther.getOrderTypeId())))
				&& ((this.getBusinessStepStatus() == castOther.getBusinessStepStatus())
						|| (this.getBusinessStepStatus() != null && castOther.getBusinessStepStatus() != null
								&& this.getBusinessStepStatus().equals(castOther.getBusinessStepStatus())))
				&& ((this.getBusinessStepValue() == castOther.getBusinessStepValue())
						|| (this.getBusinessStepValue() != null && castOther.getBusinessStepValue() != null
								&& this.getBusinessStepValue().equals(castOther.getBusinessStepValue())))
				&& ((this.getBusinessStepExecutedOn() == castOther.getBusinessStepExecutedOn())
						|| (this.getBusinessStepExecutedOn() != null && castOther.getBusinessStepExecutedOn() != null
								&& this.getBusinessStepExecutedOn().equals(castOther.getBusinessStepExecutedOn())))
				&& ((this.getComments() == castOther.getComments()) || (this.getComments() != null
						&& castOther.getComments() != null && this.getComments().equals(castOther.getComments())))
				&& ((this.getCreatedOn() == castOther.getCreatedOn()) || (this.getCreatedOn() != null
						&& castOther.getCreatedOn() != null && this.getCreatedOn().equals(castOther.getCreatedOn())))
				&& ((this.getUpdatedOn() == castOther.getUpdatedOn()) || (this.getUpdatedOn() != null
						&& castOther.getUpdatedOn() != null && this.getUpdatedOn().equals(castOther.getUpdatedOn())));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getOrderId().intValue();
		result = 37 * result + (int) this.getBusinessStepId().intValue();
		result = 37 * result + (getOrderTypeId() == null ? 0 : this.getOrderTypeId().hashCode());
		result = 37 * result + (getBusinessStepStatus() == null ? 0 : this.getBusinessStepStatus().hashCode());
		result = 37 * result + (getBusinessStepValue() == null ? 0 : this.getBusinessStepValue().hashCode());
		result = 37 * result + (getBusinessStepExecutedOn() == null ? 0 : this.getBusinessStepExecutedOn().hashCode());
		result = 37 * result + (getComments() == null ? 0 : this.getComments().hashCode());
		result = 37 * result + (getCreatedOn() == null ? 0 : this.getCreatedOn().hashCode());
		result = 37 * result + (getUpdatedOn() == null ? 0 : this.getUpdatedOn().hashCode());
		return result;
	}

}
