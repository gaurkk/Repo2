package com.att.comet.misc.helper;

import static com.att.comet.order.dao.OrderSqlConstant.GET_AMP_REQ_INFO_BY_ORDER_QUERY1;
import static com.att.comet.order.dao.OrderSqlConstant.GET_AMP_REQ_INFO_BY_ORDER_QUERY2;
import static com.att.comet.order.dao.OrderSqlConstant.GET_ACCA_REQ_INFO1;
import static com.att.comet.order.dao.OrderSqlConstant.GET_ACCA_REQ_INFO2;


import java.util.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BPMBusinessOrderStepBO;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.common.util.Comparators;
import com.att.comet.dao.hibernate.bean.Apn;
import com.att.comet.dao.hibernate.bean.BackhaulConfig;
import com.att.comet.dao.hibernate.bean.BpmOrderBusinessStep;
import com.att.comet.dao.hibernate.bean.OrderDataCenter;
import com.att.comet.dao.hibernate.bean.OrderUploadFileDetails;
import com.att.comet.dao.hibernate.bean.Orders;
import com.att.comet.dao.hibernate.bean.PdpIdInfo;
import com.att.comet.misc.AccaRequestBO;
import com.att.comet.misc.AmpRequestBO;
import com.att.comet.misc.MiscBO;
import com.att.comet.misc.bean.AccaRequestInfoBean;
import com.att.comet.misc.bean.AmpRequestInfoBean;
import com.att.comet.misc.bean.CancelProcessInfo;
import com.att.comet.misc.bean.ChangeProcessInfo;
import com.att.comet.misc.bean.DAPNProcessInfo;
import com.att.comet.misc.bean.DataCenterInfoBean;
import com.att.comet.misc.bean.DecommisionProcessInfo;
import com.att.comet.misc.bean.ExpediteProcessInfo;
import com.att.comet.misc.bean.MiscOverViewInfo;
import com.att.comet.misc.bean.OtherInfoBean;
import com.att.comet.misc.bean.ProcessInfoBean;
import com.att.comet.misc.bean.ProcessInfoBeanDetails;
import com.att.comet.misc.bean.ProcessInfoDefault;
import com.att.comet.misc.bean.RecoveryInfoBean;
import com.att.comet.order.dao.OrderDAO;
import com.att.comet.order.filedoc.repository.OrderUploadFileDetailsRepository;
import com.att.comet.order.modal.DataCenterBO;
import com.att.comet.order.modal.OrderContactInfoBO;
import com.att.comet.order.modal.OrderContactTabBO;
import com.att.comet.order.repository.BackHaulConfgurationRespository;
import com.att.comet.order.repository.OrderDataCenterRepository;
import com.att.comet.order.repository.OrderRepository;
import com.att.comet.order.service.OrderService;
import com.att.comet.order.util.OrderUtil;

@Component
public class MiscHelper {
	private static final Logger logger = LoggerFactory.getLogger(MiscHelper.class);
	
	@Autowired
	OrderDAO orderDAO;	
	@Autowired
	OrderService orderService;
	@Autowired
	OrderUtil orderUtil;
	@PersistenceContext
	EntityManager em;
	
	@Autowired
	OrderDataCenterRepository orderDataCenterRepository;
	@Autowired
	BackHaulConfgurationRespository backHaulConfgurationRespository;
	@Autowired
	OrderUploadFileDetailsRepository orderUploadFileDetailsRepository;
	@Autowired
	OrderRepository orderRepository;


	
	/**
	 * 
	 * @param order
	 * @return
	 */

	public MiscBO setMISCInfo(Orders order) {
	logger.info("Starting methode setMISCInfo" , this);
	MiscBO miscBO = new MiscBO();
	if(null!=order) {
		MiscOverViewInfo miscOverViewInfo =new MiscOverViewInfo();
		RecoveryInfoBean recoveryInfoBean = new RecoveryInfoBean();	
		OtherInfoBean otherInfoBean = new OtherInfoBean();
		ProcessInfoBean processInfoBean  = new ProcessInfoBean();
		AmpRequestInfoBean ampRequestInfoBean =new AmpRequestInfoBean();
		AccaRequestInfoBean accaRequestInfoBean = new AccaRequestInfoBean();
		miscOverViewInfo = setMiscOverViewInfo(order,miscOverViewInfo);
		miscBO.setMiscOverViewInfo(miscOverViewInfo);
		recoveryInfoBean = setRecoveryMiscInfo(order,recoveryInfoBean);
		miscBO.setRecoveryInfo(recoveryInfoBean);
		otherInfoBean = setMiscOtherInfo(order,otherInfoBean,miscBO);
		List<String> exceptionList = orderUtil.setExceptionList(order);
		if(!CollectionUtils.isEmpty(exceptionList)) {
			miscBO.setExceptionReasonsList(exceptionList);
			miscBO.setExceptionDiv(true);
		}
		miscBO.setOtherInfo(otherInfoBean);
		processInfoBean = setProcessInfoDetails(order, processInfoBean,miscOverViewInfo);
		miscBO.setProcessInfo(processInfoBean);
		ampRequestInfoBean = setAmpRequestInfoInBO(order.getOrderId(),ampRequestInfoBean);
		miscBO.setAmpRequestInfo(ampRequestInfoBean);
		accaRequestInfoBean = setAccaRequestInfoInBO(order.getOrderId(),accaRequestInfoBean);
		miscBO.setAccaRequestInfo(accaRequestInfoBean);
	}else {
		logger.error("Request Object is not set", this);
	}
		
	logger.info("Exiting methode setMISCInfo ",this);
		return miscBO;
		
	}

	private MiscOverViewInfo setMiscOverViewInfo(Orders orders,MiscOverViewInfo miscOverViewInfo) {
		logger.info("Starting methode setMiscOverViewInfo" , this);	
		logger.debug("[OrderID : " + (orders.getOrderId() == null ? "" : orders.getOrderId()) + "] "+ "setMiscOverViewInfo ::" ,this);
		Long orderTypeId = orders.getOrderType().getOrderTypeId();
		Long orderStatusId = orders.getOrderStatus().getOrderStatusId();
		
		//orderType= 1002 submitted 
		//orderStatusId =1023 Decomsission 
		
		miscOverViewInfo.setOrderStatus(orderStatusId.toString());
		miscOverViewInfo.setOrderType(orderTypeId.toString());
		
		//Order status and order Type
		if(orderStatusId==1023L || orderStatusId==1065L || orderStatusId==1066L ||orderTypeId==1006L) {
			//show Decomission 
			miscOverViewInfo.setDecomissionOrder(true);
		}
		
		if(orderStatusId==1023L && orderTypeId>1002) {
			//hide default Process information table
			miscOverViewInfo.setHideDefaultProcessInfoTable(true);
		}
		//dedicatedApn true
		if(null!=orders.getApnSelection() && orders.getApnSelection().equalsIgnoreCase(CometCommonConstant.APN_DEDICATED)) {
			//set Dedicated APN
			miscOverViewInfo.setDedicatedApn(true);
		}
		
		//order expedite
		if(null!=orders.getExpedite() && orders.getExpedite()=='Y') {
			//set Expedite order
			miscOverViewInfo.setExpediteOrder(true);
		}
		//cancel order 
		if(null!=orders.getCancelRequest() &&(orders.getCancelRequest()=='I' || orders.getCancelRequest()=='F')) {
			//set Cancel order 
			miscOverViewInfo.setCancelOrder(true);
		}
		//change order 
		if(null!=orders.getChangeRequest() && (orders.getChangeRequest()=='I' || orders.getChangeRequest()=='F')) {
		//set Change order 	
			miscOverViewInfo.setChangeOrder(true);
		}
		logger.info("Existing methode setMiscOverViewInfo" , this);
		return miscOverViewInfo;
	}
	
	/**
	 * Set Recovery Misc details
	 * @param order
	 * @param recoveryInfoBean
	 * @return
	 */
	private RecoveryInfoBean setRecoveryMiscInfo(Orders order,RecoveryInfoBean recoveryInfoBean) {
		logger.info("[OrderId : "+(order.getOrderId() == null ? "": order.getOrderId())+"] Starting method setRecoveryMiscInfo : ");
		Long orderId = order.getOrderId();
		if(null!=order) {
			//APN and PDP name
			if(null!=order.getApn() && null!=order.getApn().getApnName()) {
				recoveryInfoBean.setApnName(order.getApn().getApnName());
			}
			
			StringBuilder pdpNames = new StringBuilder();
			if (null!=order.getApn() && !CollectionUtils.isEmpty(order.getApn().getPdpIdInfos())) {
			
				List<PdpIdInfo> pdpIdInfoList = order.getApn().getPdpIdInfos().stream().collect(Collectors.toList());
				String prefix = "";
				pdpNames.append("[");
				for (PdpIdInfo pdpIdInfo : pdpIdInfoList) {
					if(null!=pdpIdInfo.getAutoPdpName()) {
						if(pdpIdInfo.getAutoPdpName()!=null && !pdpIdInfo.getAutoPdpName().isEmpty()){
							pdpNames.append(prefix);
							prefix = ", ";
							pdpNames.append(pdpIdInfo.getAutoPdpName().toUpperCase());
						}
					}
				}
				pdpNames.append("]");
				recoveryInfoBean.setPdpName(pdpNames.toString());
			}
			//END APN and PDP name
			try {
				//DataCenterInfoBean dataCenterInfoBean =new DataCenterInfoBean();
				String dataCenterName = null;
				String dataCenterId = null;
				List<DataCenterBO>  dataCenterBO = orderDAO.getDataCenterInfo(orderId, "MISC", order);
				if(!CollectionUtils.isEmpty(dataCenterBO)) {
					for(DataCenterBO  dataCenterObj : dataCenterBO) {
						DataCenterInfoBean dataCenterInfoBean =new DataCenterInfoBean();
						if(null!=dataCenterObj) {
							if(dataCenterInfoBean.getDataCenter()==null) {
								
								dataCenterName = dataCenterObj.getDataCenterName();
								dataCenterId = String.valueOf(dataCenterObj.getDataCenterId());
								dataCenterInfoBean.setNdc(dataCenterName);//data center
								dataCenterInfoBean.setDataCenter(dataCenterId);//NDC
								if(null!=dataCenterObj.getActiveInterface()) {
									dataCenterInfoBean.setActiveInterface(dataCenterObj.getActiveInterface());
								}
								if(null!=dataCenterObj.getActiveRouter()) {
									dataCenterInfoBean.setActiveRouter(dataCenterObj.getActiveRouter());	
								}
								if(null!=dataCenterObj.getDcRounterFailOverConfig()) {
									dataCenterInfoBean.setPrimaryDcRouter(dataCenterObj.getDcRounterFailOverConfig());
								}
								recoveryInfoBean.getDataCenterInfoList().add(dataCenterInfoBean);
							}else
							if(!dataCenterInfoBean.getDataCenter().equalsIgnoreCase(String.valueOf(dataCenterObj.getDataCenterId()))) {
								dataCenterName = dataCenterObj.getDataCenterName();
								dataCenterId = String.valueOf(dataCenterObj.getDataCenterId());
								dataCenterInfoBean.setNdc(dataCenterName);//data center
								dataCenterInfoBean.setDataCenter(dataCenterId);//NDC
								if(null!=dataCenterObj.getActiveInterface()) {
									dataCenterInfoBean.setActiveInterface(dataCenterObj.getActiveInterface());
								}
								if(null!=dataCenterObj.getActiveRouter()) {
									dataCenterInfoBean.setActiveRouter(dataCenterObj.getActiveRouter());	
								}
								if(null!=dataCenterObj.getDcRounterFailOverConfig()) {
									dataCenterInfoBean.setPrimaryDcRouter(dataCenterObj.getDcRounterFailOverConfig());
								}
								recoveryInfoBean.getDataCenterInfoList().add(dataCenterInfoBean);
							}
						}
									
					}
				}			
			} catch (CometDataException e) {
				logger.error("order Id [" + orderId + "] :: Date center info is null", this);
				logger.error("[OrderID : " + (orderId == null ? "" : orderId)+ "] " + e.getStackTrace());
			}
			if(recoveryInfoBean.getDataCenterInfoList().size() > 1){
				recoveryInfoBean.setBuild("Geo Data Center Build");
			} else {
				recoveryInfoBean.setBuild("Single Data Center");
			}
			
			if (order != null && order.getLteSweep() != null) {
				recoveryInfoBean.setLteSweep(order.getLteSweep());
			}
			
			List<OrderUploadFileDetails> orderUploadFileDetailsList =  orderUploadFileDetailsRepository.findByOrderUploadId_orderId(orderId);
			if(!CollectionUtils.isEmpty(orderUploadFileDetailsList)) {
				for(OrderUploadFileDetails orderUploadFileDetails :orderUploadFileDetailsList) {
					if(null!=orderUploadFileDetails) {
						if(null!=orderUploadFileDetails.getOrderUploadId() && orderUploadFileDetails.getOrderUploadId().getUploadId().equals("1001")) {
							//Network diagram
							recoveryInfoBean.setRecoveryFlowChartFileName(orderUploadFileDetails.getUploadFileName());
						}
						//IP SEC letter 
						if(null!=orderUploadFileDetails.getOrderUploadId() && orderUploadFileDetails.getOrderUploadId().getUploadId().equals("1002")) {
							recoveryInfoBean.setIpSecLetterAttachmentName(orderUploadFileDetails.getUploadFileName());
						}
					}//end orderUploadFileDetails
				}
			}
			try {
				OrderContactTabBO orderContactTabObj = orderDAO.getOrderContactTabInfo(orderId);
				List<OrderContactInfoBO> orderContactInfoList= orderContactTabObj.getOcList();
				if(!CollectionUtils.isEmpty(orderContactInfoList)) {
					for (OrderContactInfoBO orderContactInfo : orderContactInfoList) {
						if(orderContactInfo.getOrderContactType()==1025) {
							recoveryInfoBean.setPostSalesContactName(orderContactInfo.getName());
							recoveryInfoBean.setPostSalesContactPhone(orderContactInfo.getPhone());
							recoveryInfoBean.setPostSalesContactEmail(orderContactInfo.getEmail());
							recoveryInfoBean.setPostSalesContactExtension(orderContactInfo.getExtention());
						}
					}
				}
			} catch (CometDataException e) {
				logger.error("order Id [" + orderId + "] :: Not able to fetch the Recovery Contract Info::", this);
				logger.error("[OrderID : " + (orderId == null ? "" : orderId)+ "] " + e.getStackTrace());
			}
		}
		logger.info("[OrderId : "+(order.getOrderId() == null ? "": order.getOrderId())+"] Exiting method setRecoveryMiscInfo : ");
		return recoveryInfoBean;
	}
	
	/**
	 * 
	 * @param order
	 * @param recoveryInfoBean
	 * @return
	 */
	private OtherInfoBean setMiscOtherInfo(Orders order ,OtherInfoBean otherInfoBean,MiscBO miscBO) {
		logger.info("[OrderId : "+(order.getOrderId() == null ? "": order.getOrderId())+"] Starting method setMiscOtherInfo : ");
	 if(null!=order) {
		try {
			BackhaulConfig backhaulConfig = orderDAO.getBackHaulConfig(order.getOrderId());
			if(null!=backhaulConfig) {
				if(backhaulConfig.getApnInProductionDate() != null)
					otherInfoBean.setApnInProductionDate(backhaulConfig.getApnInProductionDate());
				if(backhaulConfig.getExcpApproverDate() != null)
					otherInfoBean.setExceptionApprovalDate(backhaulConfig.getExcpApproverDate());
				if(backhaulConfig.getExcpApprovalNumber() != null)
					otherInfoBean.setExceptionApprovalNumber(backhaulConfig.getExcpApprovalNumber());
				if(backhaulConfig.getExcpRequestApprover() != null)
					otherInfoBean.setExceptionRequestApprover(backhaulConfig.getExcpRequestApprover());
				if(backhaulConfig.getNotes() != null)
					otherInfoBean.setNotes(backhaulConfig.getNotes());
				if(backhaulConfig.getIwosNotes() != null){
					otherInfoBean.setIwosNotes(backhaulConfig.getIwosNotes());
				}
				
				if (backhaulConfig.getWhiteListOfBlackList() != null) {
					otherInfoBean.setWhiteListOfBlackList(backhaulConfig.getWhiteListOfBlackList());
				}
				if(orderUtil.checkAndUpdateExceptionalOrder(order.getOrderId())) {
					miscBO.setExceptionDiv(true);
				}
				
			/*	if(null!= order && null!=order.getNumDataCenters() && order.getNumDataCenters() > 2) {
					miscBO.setExceptionDiv(true);
				}*/
				Apn apn = orderDAO.getApn(order.getOrderId());
				if (null!=apn && null!=apn.getWhitelistBlacklist()) {
					if(apn.getWhitelistBlacklist().equalsIgnoreCase("exception")) {
						miscBO.setIswhiteListShow(true);
						miscBO.setIwosShow(true);
						miscBO.setExceptionDiv(true);
					}
				}
				if (backhaulConfig.getiWOS() != null) {
					otherInfoBean.setIWOS(backhaulConfig.getiWOS());
				}
			}
			
		} catch (CometDataException e) {
			logger.error("order Id [" + order.getOrderId() + "] :: Backhaul Configuration  info is null", this);
			logger.error("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())+ "] " + e.getStackTrace());
		}
		
		try {
			List<OrderDataCenter> orderDateCenterList =  orderDAO.getDateCenterByOrderId(order.getOrderId());
		    if(!CollectionUtils.isEmpty(orderDateCenterList)) {
		    	for(OrderDataCenter orderDataCenter :orderDateCenterList) {
		    		Long numBackHauls =	orderDataCenter.getNumNewBackhauls();
		    		if(numBackHauls>0) {
		    			otherInfoBean.setNumBackHauls(numBackHauls);
		    		}
		    	}
		    }
		} catch (CometDataException e) {
			logger.error("order Id [" + order.getOrderId() + "] :: Date center List is null ::", this);
			logger.error("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())+ "] " + e.getStackTrace());
		}
		
	 }
	 logger.info("[OrderId : "+(order.getOrderId() == null ? "": order.getOrderId())+"] Exiting method setMiscOtherInfo : ");
		return otherInfoBean; 
	}
	
	/**
	 * 
	 * @param order
	 * @param processInfoBean
	 * @return
	 */
	private ProcessInfoBean setProcessInfoDetails(Orders order ,ProcessInfoBean processInfoBean,MiscOverViewInfo miscOverViewInfo ) {
		logger.info("Starting method setProcessInfo" , this);
		if(null!=order) {
			logger.info("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())
					+ "] " ,this);
			try {
				BPMBusinessOrderStepBO bpmBusinessOrderStepBO[]=orderService.getBusinessOrderStep(order.getOrderId());
				if(bpmBusinessOrderStepBO != null){
					logger.debug("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())
							+ " ] BPMBusinessOrderStepBO is set :: " ,this);
					processInfoBean = setAllProcessInfo(bpmBusinessOrderStepBO, processInfoBean,miscOverViewInfo);					
				}
				String baseNote = orderService.getBaseOrderNotes(order.getOrderId());
				logger.debug("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())
						+ " ] baseNote is set :: "+baseNote ,this);
				//baseNote.processInfoBean.setBaseOrderNotes(baseNote);	
			} catch (CometDataException | CometServiceException e) {
				logger.error("[OrderID : " + (order.getOrderId() == null ? "" : order.getOrderId())
						+ "] " + e.getStackTrace());
			}
		}
		
		logger.info("Existing method setProcessInfo" , this);
		return processInfoBean;
	}
	
	
	/**
	 * Populate BPM Business Order Step BO info.
	 * 
	 * @param businessStep
	 * @return BPMBusinessOrderStepBO
	 */
	public static BPMBusinessOrderStepBO populateBPMBusinessOrderStepBO(
			BpmOrderBusinessStep businessStep) {
		logger.info("[BusinessStep : "+(businessStep.getId() == null ? "": businessStep.getId())+"] Starting method populateBPMBusinessOrderStepBO : ");
		BPMBusinessOrderStepBO orderStepBO = new BPMBusinessOrderStepBO();
		orderStepBO.setBusinessStepExecutedOn(businessStep
				.getBusinessStepExecutedOn());
		if (businessStep.getId() != null) {
			orderStepBO.setOrderBusinessStepId(businessStep.getId()
					.getBusinessStepId());
			orderStepBO.setOrderId(businessStep.getId().getOrderId());
			orderStepBO.setOrderTypeId(businessStep.getId().getOrderTypeId());
		}
		orderStepBO.setBusinessStepStatus(businessStep.getBusinessStepStatus());
		orderStepBO.setBusinessStepValue(businessStep.getBusinessStepValue());
		orderStepBO.setComments(businessStep.getComments());
		orderStepBO.setCreatedOn(businessStep.getCreatedOn());
		orderStepBO.setAttuid(businessStep.getAttuid());
		if (businessStep.getOrderType() != null) {
			orderStepBO.setOrderTypeId(businessStep.getOrderType()
					.getOrderTypeId());
			orderStepBO.setOrderTypeName(businessStep.getOrderType()
					.getOrderTypeName());
		}
		orderStepBO.setUpdatedOn(businessStep.getUpdatedOn());
		if (businessStep.getBpmBusinessStep() != null) {
			orderStepBO.setBusinessStepId(businessStep.getBpmBusinessStep()
					.getBusinessStepId());
		}
		logger.info("[BusinessStep : "+(businessStep.getId() == null ? "": businessStep.getId())+"] Exiting method populateBPMBusinessOrderStepBO : ");
		return orderStepBO;
	}
	
	private ProcessInfoBean setAllProcessInfo(
			BPMBusinessOrderStepBO bpmBusinessOrderStepBO[], ProcessInfoBean processInfoBean,MiscOverViewInfo miscOverViewInfo) {
		logger.info("Starting method setAllProcessInfo" , this);
		
		if(!miscOverViewInfo.isHideDefaultProcessInfoTable()) {
			logger.debug("Default Table for Process Information display" , this);
			processInfoBean = setAllNoNCRProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
		}if(miscOverViewInfo.isCancelOrder()) {
			boolean isCancelDateStatus =false;
			for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
				if(bo.getOrderTypeId().longValue() == 3133L){
					if(null!=bo.getBusinessStepStatus()) {
						isCancelDateStatus =true;
					}
				}
			}
			if(isCancelDateStatus || miscOverViewInfo.isCancelOrder()) {
				//cancel order logic
				logger.debug("Display Cancel table  for Process Information display" , this);
				processInfoBean=setAllCancelProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
			}
		}
		if(miscOverViewInfo.isDedicatedApn()) {
			logger.debug("Display DAPN table  for Process Information display" , this);
			//DAPN order logic
			processInfoBean=setAllDAPNProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
		}
		if(miscOverViewInfo.isDecomissionOrder()) {
			logger.debug("Display Decomission table  for Process Information display" , this);
			//Decommission logic
			processInfoBean=setAllDecomission(bpmBusinessOrderStepBO, processInfoBean);
		}
		if(miscOverViewInfo.isExpediteOrder()) {
			boolean  expediteRequestAppTaskStatus =false;
			for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
				if(bo.getOrderTypeId().longValue() == 1003L){
					if(null!=bo.getBusinessStepStatus()) {
						expediteRequestAppTaskStatus =true;
						break;
					}
				}
			}
			//Expedite logic
			if(expediteRequestAppTaskStatus || miscOverViewInfo.isExpediteOrder()) {
				logger.debug("Display Expedite table  for Process Information display" , this);
				processInfoBean=setAllExpediteProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
			}
		}else {
			boolean  expediteRequestAppTaskStatus =false;
			for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
				if(bo.getOrderTypeId().longValue() == 1003L){
					if(null!=bo.getBusinessStepStatus()) {
						expediteRequestAppTaskStatus =true;
						break;
					}
				}
			}
			//Expedite logic
			if(expediteRequestAppTaskStatus) {
				logger.debug("Display Expedite table  for Process Information display" , this);
				processInfoBean=setAllExpediteProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
			}
		}
		if(miscOverViewInfo.isChangeOrder()) {
			boolean isChangeStatus =false;
			for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
				//3138L
				if(bo.getOrderTypeId().longValue() == 3138L){
					if(null!=bo.getBusinessStepStatus()) {
						isChangeStatus =true;
					}
				}
			}
			if(isChangeStatus || miscOverViewInfo.isChangeOrder()) {
				logger.debug("Display Change order table  for Process Information display" , this);
				//Change order 		
				processInfoBean=setAllChangeOrderProcessInfo(bpmBusinessOrderStepBO, processInfoBean);
			}
			
		}
		logger.info("Existing method setAllProcessInfo" , this);
		return processInfoBean;
	}

	/**
	 * setAllNoNCRProcessInfo for Non CR activity
	 * @param bpmBusinessOrderStepBO
	 * @param processInfoBean
	 * @return
	 */
	private ProcessInfoBean setAllNoNCRProcessInfo(BPMBusinessOrderStepBO bpmBusinessOrderStepBO[], ProcessInfoBean processInfoBean) {
		logger.info("Starting method setAllNoNCRProcessInfo" , this);		
					
						
		ProcessInfoDefault processInfoDefault = new ProcessInfoDefault();		
		HashMap<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>(); 			
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() != 1005L){
				List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				//OA
				if(bo.getBusinessStepId() == 3001L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3001L] " ,this);
					ProcessInfoBeanDetails oAProcessInfoBean = new ProcessInfoBeanDetails();
					oAProcessInfoBean.setSequenceNumber(0);
					oAProcessInfoBean.setActivityName("OA Approval Task");
					oAProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oAProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						oAProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oAProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oAProcessInfoBean);
					mapList.put("1",processInfoBeanList);  //OA_Approval_Process
				} 
				//oaProcessMap.put("OA Approval Task" ,oAProcessInfoBean);
				//OM
				if(bo.getBusinessStepId() == 3002L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3002L ] " ,this);
					ProcessInfoBeanDetails oMProcessInfoBean = new ProcessInfoBeanDetails();
					oMProcessInfoBean.setSequenceNumber(1);
					oMProcessInfoBean.setActivityName("OM Approval Task");
					oMProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oMProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						oMProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oMProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oMProcessInfoBean); 
					mapList.put("2",processInfoBeanList);  //OM_Approval_Process
					
				}
			//	omProcessMap.put("OM Approval Task" ,oMProcessInfoBean);
				/* OSD - BUC#1.1.009 */
				if(bo.getBusinessStepId() == 3144L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3144L] " ,this);
					ProcessInfoBeanDetails osdProcessInfoBean = new ProcessInfoBeanDetails();
					osdProcessInfoBean.setSequenceNumber(2);
					osdProcessInfoBean.setActivityName("OSD Approval Task");
					osdProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					osdProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null) {
						osdProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						osdProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(osdProcessInfoBean); 
					mapList.put("3",processInfoBeanList);  //OSD_Approval_Process
				}
				//APN HLR/HSS IWOS Process
				if(bo.getBusinessStepId() == 3142L || bo.getBusinessStepId() == 3143L || bo.getBusinessStepId() == 3003L || bo.getBusinessStepId()==3031L) {
					ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();	
					if(bo.getBusinessStepId() == 3003L || bo.getBusinessStepId() == 3142L){
							logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
									+ " busssniess Step:3003L  " ,this);
							if(null!=bo.getBusinessStepStatus()) {
								apnHLRIWOSProcessInfoBean.setSequenceNumber(3);
								apnHLRIWOSProcessInfoBean.setActivityName("APN	HLR/HSS IWOS Creation Task");
								apnHLRIWOSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
								apnHLRIWOSProcessInfoBean.setFlagNaN("1000001");
								if(null!=bo.getBusinessStepValue()) {
									apnHLRIWOSProcessInfoBean.setInformation("APN HLR/HSS IWOS Ticket"+"\n Number:"+bo.getBusinessStepValue()+"\n Comments:"+bo.getComments());
								}else {
									apnHLRIWOSProcessInfoBean.setInformation("Comments:"+bo.getComments());	
								}
									if(bo.getCreatedOn() != null){
										apnHLRIWOSProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
										apnHLRIWOSProcessInfoBean.setTaskOwer(bo.getAttuid());
									}
								List<ProcessInfoBeanDetails> list1_3003L= new ArrayList<ProcessInfoBeanDetails>();
									if(null!=mapList.get("4")) {
										list1_3003L=mapList.get("4");
										}
									list1_3003L.add(apnHLRIWOSProcessInfoBean);
									mapList.put("4",list1_3003L);  //APN_HLR/HSS_IWOS_Process
							}
							
						}//3003L
						if(bo.getBusinessStepId() == 3031L || bo.getBusinessStepId() ==3143L){
							logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
									+ " busssniess Step:3031L  " ,this);
							if(null!=bo.getBusinessStepStatus()) {
								apnHLRIWOSProcessInfoBean.setSequenceNumber(3);
								apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Completion Task");
								apnHLRIWOSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
								apnHLRIWOSProcessInfoBean.setFlagNaN("1000002");
								apnHLRIWOSProcessInfoBean.setInformation("Comments:"+bo.getComments());	
								if(bo.getCreatedOn() != null){
									apnHLRIWOSProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
									apnHLRIWOSProcessInfoBean.setTaskOwer(bo.getAttuid());
								}
								List<ProcessInfoBeanDetails> list2_3031L= new ArrayList<ProcessInfoBeanDetails>();
								if(null!=mapList.get("4")) {
									list2_3031L=mapList.get("4");
									}
								list2_3031L.add(apnHLRIWOSProcessInfoBean);
								mapList.put("4",list2_3031L);  //APN_HLR/HSS_IWOS_Process
							}
							
						}//3031L
						//if(bo.getBusinessStepId() == 3142L){} //3142L
						//if(bo.getBusinessStepId() == 3143L){}//3143L
					}
				
				// APN IT OPS TASK
				if (bo.getBusinessStepId() == 3005L) {
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3005L  ", this);
					ProcessInfoBeanDetails apnITOPSProcessInfoBean = new ProcessInfoBeanDetails();	
					apnITOPSProcessInfoBean.setSequenceNumber(4);
					apnITOPSProcessInfoBean.setActivityName("APN IT OPS Completion Task");
					apnITOPSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					apnITOPSProcessInfoBean.setInformation(bo.getComments());
					if (bo.getBusinessStepExecutedOn() != null) {
						apnITOPSProcessInfoBean
								.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
						apnITOPSProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(apnITOPSProcessInfoBean); 
					mapList.put("5",processInfoBeanList); //APN_IT_OPS_Process
				}
				
				//Billing submission Task 
				if(bo.getBusinessStepId() == 3023L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3023L ", this);
					ProcessInfoBeanDetails billingProcessInfoBean = new ProcessInfoBeanDetails();
					billingProcessInfoBean.setSequenceNumber(5);
					billingProcessInfoBean.setActivityName("Billing Request Submission Task");
					billingProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					billingProcessInfoBean.setInformation(bo.getComments());	
					if(bo.getCreatedOn() != null){
						billingProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						billingProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(billingProcessInfoBean); 
					mapList.put("6", processInfoBeanList);  //Process_Billing_Request
				} 
				
				
				//APN Build IWOS Create Task (Network IWOS Process) and //APN CCSPM Complete Task 
				if(bo.getBusinessStepId() == 3007L || bo.getBusinessStepId() == 3012L){
					ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();	
					if(bo.getBusinessStepId() == 3007L) {
						if(null!=bo.getBusinessStepStatus()) {
							apnBUILDIWOSInfoBean.setSequenceNumber(6);
							apnBUILDIWOSInfoBean.setActivityName("NetworkIWOS Creation Task");
							apnBUILDIWOSInfoBean.setFlagNaN("1000001");
							apnBUILDIWOSInfoBean.setItwosNoteDisplay("true");
							if(bo.getCreatedOn() != null){
								apnBUILDIWOSInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								apnBUILDIWOSInfoBean.setTaskOwer(bo.getAttuid());
							}
							apnBUILDIWOSInfoBean.setStatus(bo.getBusinessStepStatus());
							if(null!=bo.getBusinessStepValue() && null!=bo.getBusinessStepStatus() && null!=bo.getBusinessStepExecutedOn()) {
								apnBUILDIWOSInfoBean.setInformation("Network IWOS Ticket Number :"+"\n\tNumber:"+bo.getBusinessStepValue()+
										"Network Estimated Complete Date:"+bo.getBusinessStepExecutedOn().toString()+ "\n\tComments:"+bo.getComments()+"\n\tIWOS Notes:");
							}
							if(null!=bo.getBusinessStepValue() && null==bo.getBusinessStepExecutedOn()) {
								apnBUILDIWOSInfoBean.setInformation("Network IWOS Ticket Number :"+"\n\t Number:"+bo.getBusinessStepValue()+
										"Netork Estimated Complete Date:"+bo.getBusinessStepExecutedOn().toString()+ "\n\tComments:"+bo.getComments()+"\n\tIWOS Notes:");
							}
							List<ProcessInfoBeanDetails> list_3007L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("7")) {
								list_3007L=mapList.get("7");
							}
							list_3007L.add(apnBUILDIWOSInfoBean); 
							mapList.put("7", list_3007L);  //Network_IWOS_Process
						}
						
					}//3007L
					if(bo.getBusinessStepId() == 3012L) {
						if(null!=bo.getBusinessStepStatus()) {
							apnBUILDIWOSInfoBean.setSequenceNumber(6);
							apnBUILDIWOSInfoBean.setActivityName("Network IWOS Suspension/Completion TASK");
							apnBUILDIWOSInfoBean.setFlagNaN("1000002");
							if(bo.getCreatedOn() != null){
								apnBUILDIWOSInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								apnBUILDIWOSInfoBean.setTaskOwer(bo.getAttuid());
							}
							apnBUILDIWOSInfoBean.setStatus(bo.getBusinessStepStatus());
							apnBUILDIWOSInfoBean.setInformation("Comments:"+bo.getComments());
							List<ProcessInfoBeanDetails> list_3012= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("7")) {
								list_3012=mapList.get("7");
							}
							list_3012.add(apnBUILDIWOSInfoBean); 
							mapList.put("7", list_3012); //Network_IWOS_Process
						}
						
					}
					
				}//end of APN Build IWOS Create Task (Network IWOS Process) and //APN CCSPM Complete Task 
			
				//TTU Process
				if(bo.getBusinessStepId() == 3025L || bo.getBusinessStepId() == 3026L || bo.getBusinessStepId() == 3132L
						|| bo.getBusinessStepId() == 3028L || bo.getBusinessStepId() == 3029L || bo.getBusinessStepId() == 3141L) {
					ProcessInfoBeanDetails ttuProcessInfoBean = new ProcessInfoBeanDetails();
					//OS conform preflight test
					if (bo.getBusinessStepId() == 3025L) {
						String preflightStatus="";
						if (bo.getBusinessStepStatus() == null) {
							preflightStatus = "";
						} else {
							preflightStatus = bo.getBusinessStepStatus();
						}
						ttuProcessInfoBean.setSequenceNumber(7);
						ttuProcessInfoBean.setActivityName("Preflight Testing Task (OSD)");
						ttuProcessInfoBean.setStatus("\r Is Pre-Flight Test Occurred ?:\n\r"
								+ bo.getBusinessStepValue() + "\n Status:" + preflightStatus);
						ttuProcessInfoBean.setFlagNaN("1000001");
						if (bo.getCreatedOn() != null) {
							ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
							ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
						}
						ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
						List<ProcessInfoBeanDetails> list_3025L = new ArrayList<ProcessInfoBeanDetails>();
						if (null != mapList.get("8")) {
							list_3025L = mapList.get("8");
						}
						list_3025L.add(ttuProcessInfoBean);
						mapList.put("8", list_3025L); // TTU_Process

					}//3025L
					//OS Conform TTU Require 
					if(bo.getBusinessStepId() == 3026L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setSequenceNumber(7);
							ttuProcessInfoBean.setActivityName("TTU Applicability Task (OSD)");
							ttuProcessInfoBean.setFlagNaN("1000002");
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							List<ProcessInfoBeanDetails> list_3026L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3026L=mapList.get("8");
							}
							list_3026L.add(ttuProcessInfoBean);
							mapList.put("8", list_3026L);
						}
						
					}//3026L
					//Schedule TTU Task
					if(bo.getBusinessStepId() == 3132L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setSequenceNumber(7);
							ttuProcessInfoBean.setActivityName("Schedule TTU Task");
							ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000003");
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3132L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3132L=mapList.get("8");
							}
							list_3132L.add(ttuProcessInfoBean);
							mapList.put("8", list_3132L);
						}
						
					}//3132L
					//Perform TTU Task
					if(bo.getBusinessStepId() == 3028L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setSequenceNumber(7);
							ttuProcessInfoBean.setActivityName("Perform TTU Task");
							ttuProcessInfoBean.setFlagNaN("1000004");
							ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3028L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3028L=mapList.get("8");
							}
							list_3028L.add(ttuProcessInfoBean);
							mapList.put("8", list_3028L);
						}
						
					}//3028L
					//TTU Result Task
					if(bo.getBusinessStepId() == 3029L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setSequenceNumber(7);
							ttuProcessInfoBean.setActivityName("TTU Result Task");
							ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000005");
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3029L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3029L=mapList.get("8");
							}
							list_3029L.add(ttuProcessInfoBean);
							mapList.put("8", list_3029L);
						}
						
					}//3029L
					//Re Schedule TTU Task 
					if(bo.getBusinessStepId() == 3141L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setSequenceNumber(7);
							ttuProcessInfoBean.setActivityName("Re Schedule TTU Task");
							ttuProcessInfoBean.setInformation(bo.getComments()==null?"Comments:":"Comments:"+bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000006");
							if(bo.getBusinessStepExecutedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3141L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3141L=mapList.get("8");
							}
							list_3141L.add(ttuProcessInfoBean);
							mapList.put("8", list_3141L);
						}
						
					}//3141L
				}
			}
		}
		mapList = populateDefaultTable(mapList);
		if(!CollectionUtils.isEmpty(mapList)) {
			mapList = Comparators.sortByValue(mapList);
			processInfoDefault.setOAMapList(mapList);
			processInfoBean.setProcessInfoDefault(processInfoDefault);
		}else {
			logger.error("@@@@@@@@@@MISC TAB PROCESS INFO DEFAULT TABLE MAP IS EMPTY!!!!!!!", this);
		}
		logger.info("Existing method setAllNoNCRProcessInfo" , this);
		return processInfoBean;
	}
	
	private HashMap<String,List<ProcessInfoBeanDetails>> populateDefaultTable(HashMap<String,List<ProcessInfoBeanDetails>> mapList) {
		logger.info("Starting method populateDefaultTable" , this);
		if(null==mapList.get("1")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails oAProcessInfoBean=new ProcessInfoBeanDetails();
			oAProcessInfoBean.setSequenceNumber(0);
			oAProcessInfoBean.setActivityName("OA Approval Task");
			oAProcessInfoBean.setStatus("N/A");
			oAProcessInfoBean.setInformation("Comments:N/A");
			oAProcessInfoBean.setTimeStamp("N/A");
			oAProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oAProcessInfoBean);
			mapList.put("1",processInfoBeanList);  //OA_Approval_Process
			
		}
		if(null==mapList.get("2")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails oMProcessInfoBean=new ProcessInfoBeanDetails();
			oMProcessInfoBean.setSequenceNumber(1);
			oMProcessInfoBean.setActivityName("OM Approval Task");
			oMProcessInfoBean.setStatus("N/A");
			oMProcessInfoBean.setInformation("Comments:N/A");
			oMProcessInfoBean.setTimeStamp("N/A");
			oMProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oMProcessInfoBean);
			mapList.put("2",processInfoBeanList); //OM_Approval_Process
			
		}
		if(null==mapList.get("3")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails osdProcessInfoBean=new ProcessInfoBeanDetails();
			osdProcessInfoBean.setSequenceNumber(2);
			osdProcessInfoBean.setActivityName("OSD Approval Task");
			osdProcessInfoBean.setStatus("N/A");
			osdProcessInfoBean.setInformation("Comments:N/A");
			osdProcessInfoBean.setTimeStamp("N/A");
			osdProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(osdProcessInfoBean);
			mapList.put("3",processInfoBeanList);  //OSD_Approval_Process
			
		}
		if(null==mapList.get("5")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails apnITOPSProcessInfoBean=new ProcessInfoBeanDetails();
			apnITOPSProcessInfoBean.setSequenceNumber(3);
			apnITOPSProcessInfoBean.setActivityName("APN IT OPS Completion Task");
			apnITOPSProcessInfoBean.setStatus("N/A");
			apnITOPSProcessInfoBean.setInformation("Comments:N/A");
			apnITOPSProcessInfoBean.setTimeStamp("N/A");
			apnITOPSProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(apnITOPSProcessInfoBean);
			mapList.put("5",processInfoBeanList);   //APN_IT_OPS_Process
			
		}
		if(null==mapList.get("6")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails billingProcessInfoBean=new ProcessInfoBeanDetails();
			billingProcessInfoBean.setSequenceNumber(4);
			billingProcessInfoBean.setActivityName("Billing Request Submission Task");
			billingProcessInfoBean.setStatus("N/A");
			billingProcessInfoBean.setInformation("Comments:N/A");
			billingProcessInfoBean.setTimeStamp("N/A");
			billingProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(billingProcessInfoBean);
			mapList.put("6",processInfoBeanList);  //Process_Billing_Request
			
		}
		if(null==mapList.get("4")) {
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean1 = new ProcessInfoBeanDetails();
			apnHLRIWOSProcessInfoBean1.setSequenceNumber(5);
			apnHLRIWOSProcessInfoBean1.setActivityName("APN HLR/HSS IWOS Creation Task");
			apnHLRIWOSProcessInfoBean1.setStatus("N/A");
			apnHLRIWOSProcessInfoBean1.setInformation("APN HLR/HSS IWOS Ticket Number: NA Comments: NA");
			apnHLRIWOSProcessInfoBean1.setTimeStamp("N/A");
			apnHLRIWOSProcessInfoBean1.setTaskOwer("N/A");
			apnHLRIWOSProcessInfoBean1.setFlagNaN("1000001");
			list1.add(apnHLRIWOSProcessInfoBean1);
			mapList.put("4", list1);   //APN_HLR/HSS_IWOS_Process
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("4");
			ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean2 = new ProcessInfoBeanDetails();
			apnHLRIWOSProcessInfoBean2.setSequenceNumber(5);
			apnHLRIWOSProcessInfoBean2.setActivityName("APN HLR/HSS IWOS Completion Task");
			apnHLRIWOSProcessInfoBean2.setStatus("N/A");
			apnHLRIWOSProcessInfoBean2.setInformation("Comments:N/A");
			apnHLRIWOSProcessInfoBean2.setTimeStamp("N/A");
			apnHLRIWOSProcessInfoBean2.setTaskOwer("N/A");
			apnHLRIWOSProcessInfoBean2.setFlagNaN("1000002");
			list2.add(apnHLRIWOSProcessInfoBean2);
			
			mapList.put("4", list2);
		}
		if(null!=mapList.get("4")){
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			processInfoBeanList =mapList.get("4");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag2 =true;	
				}
			}
			if(!flag2) {
				List<ProcessInfoBeanDetails> list1= mapList.get("4");
				ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();
				apnHLRIWOSProcessInfoBean.setSequenceNumber(5);
				apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Completion Task");
				apnHLRIWOSProcessInfoBean.setStatus("N/A");
				apnHLRIWOSProcessInfoBean.setInformation("Comments:N/A");
				apnHLRIWOSProcessInfoBean.setTimeStamp("N/A");
				apnHLRIWOSProcessInfoBean.setTaskOwer("N/A");
				list1.add(apnHLRIWOSProcessInfoBean);
				mapList.put("4", list1);
			}if(!flag1) {
				List<ProcessInfoBeanDetails> list1= mapList.get("4");
				ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();
				apnHLRIWOSProcessInfoBean.setSequenceNumber(5);
				apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Creation Task");
				apnHLRIWOSProcessInfoBean.setStatus("N/A");
				apnHLRIWOSProcessInfoBean.setInformation("Comments:N/A");
				apnHLRIWOSProcessInfoBean.setTimeStamp("N/A");
				apnHLRIWOSProcessInfoBean.setTaskOwer("N/A");
				list1.add(apnHLRIWOSProcessInfoBean);
				mapList.put("4", list1);
			}
		}	
		
		if(null==mapList.get("7")) {   //Network_IWOS_Process
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails apnBUILDIWOSInfoBean1 = new ProcessInfoBeanDetails();
			apnBUILDIWOSInfoBean1.setSequenceNumber(6);
			apnBUILDIWOSInfoBean1.setActivityName("NetworkIWOS Creation Task");
			apnBUILDIWOSInfoBean1.setStatus("N/A");
			apnBUILDIWOSInfoBean1.setInformation("Network IWOS Ticket Number: NA Network Estimated Complete Date: NA Comments:NA");
			apnBUILDIWOSInfoBean1.setTimeStamp("N/A");
			apnBUILDIWOSInfoBean1.setTaskOwer("N/A");
			apnBUILDIWOSInfoBean1.setFlagNaN("1000001");
			list1.add(apnBUILDIWOSInfoBean1);
			mapList.put("7", list1);
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("7");
			ProcessInfoBeanDetails apnBUILDIWOSInfoBean2 = new ProcessInfoBeanDetails();
			apnBUILDIWOSInfoBean2.setSequenceNumber(6);
			apnBUILDIWOSInfoBean2.setActivityName("Network IWOS Suspension/Completion TASK");
			apnBUILDIWOSInfoBean2.setStatus("N/A");
			apnBUILDIWOSInfoBean2.setInformation("Comments:N/A");
			apnBUILDIWOSInfoBean2.setTimeStamp("N/A");
			apnBUILDIWOSInfoBean2.setTaskOwer("N/A");
			apnBUILDIWOSInfoBean2.setFlagNaN("1000002");
			list2.add(apnBUILDIWOSInfoBean2);
			
			mapList.put("7", list2);
		}
		
		if(null!=mapList.get("7")){
		List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			processInfoBeanList =mapList.get("7");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag2 =true;	
				}
			}
			if(!flag2) {
				ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				list1 = mapList.get("7");
				apnBUILDIWOSInfoBean.setSequenceNumber(6);
				apnBUILDIWOSInfoBean.setActivityName("Network IWOS Suspension/Completion TASK");
				apnBUILDIWOSInfoBean.setStatus("N/A");
				apnBUILDIWOSInfoBean.setInformation("Comments:N/A");
				apnBUILDIWOSInfoBean.setTimeStamp("N/A");
				apnBUILDIWOSInfoBean.setTaskOwer("N/A");
				list1.add(apnBUILDIWOSInfoBean);
				mapList.put("7", list1);
			}if(!flag1) {
				ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				list1 = mapList.get("7");
				apnBUILDIWOSInfoBean.setSequenceNumber(6);
				apnBUILDIWOSInfoBean.setActivityName("NetworkIWOS Creation Task");
				apnBUILDIWOSInfoBean.setStatus("N/A");
				apnBUILDIWOSInfoBean.setInformation("Comments:N/A");
				apnBUILDIWOSInfoBean.setTimeStamp("N/A");
				apnBUILDIWOSInfoBean.setTaskOwer("N/A");
				list1.add(apnBUILDIWOSInfoBean);
				mapList.put("7", list1);
			}
		}//TTU Process
		if(null==mapList.get("8")) {
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails ttuProcessInfoBean1 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean1.setSequenceNumber(7);
			ttuProcessInfoBean1.setActivityName("Preflight Testing Task (OSD)");
			ttuProcessInfoBean1.setStatus("Is Pre-Flight Test Occurred ? \n"+"\tNA \n\t"+"Status: NA");
			ttuProcessInfoBean1.setInformation("Comments:N/A");
			ttuProcessInfoBean1.setTimeStamp("N/A");
			ttuProcessInfoBean1.setTaskOwer("N/A");
			ttuProcessInfoBean1.setFlagNaN("1000001");
			list1.add(ttuProcessInfoBean1);
			mapList.put("8", list1);
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean2 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean2.setSequenceNumber(7);
			ttuProcessInfoBean2.setActivityName("TTU Applicability Task (OSD)");
			ttuProcessInfoBean2.setStatus("N/A");
			ttuProcessInfoBean2.setInformation("Comments:N/A");
			ttuProcessInfoBean2.setTimeStamp("N/A");
			ttuProcessInfoBean2.setTaskOwer("N/A");
			ttuProcessInfoBean2.setFlagNaN("1000002");
			list2.add(ttuProcessInfoBean2);
			mapList.put("8", list2);
			
			List<ProcessInfoBeanDetails> list3= new ArrayList<ProcessInfoBeanDetails>();
			list3= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean3 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean3.setSequenceNumber(7);
			ttuProcessInfoBean3.setActivityName("Schedule TTU Task");
			ttuProcessInfoBean3.setStatus("N/A");
			ttuProcessInfoBean3.setInformation("Comments:N/A");
			ttuProcessInfoBean3.setTimeStamp("N/A");
			ttuProcessInfoBean3.setTaskOwer("N/A");
			ttuProcessInfoBean3.setFlagNaN("1000003");
			list3.add(ttuProcessInfoBean3);
			mapList.put("8", list3);
			
			List<ProcessInfoBeanDetails> list4= new ArrayList<ProcessInfoBeanDetails>();
			list4= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean4 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean4.setSequenceNumber(7);
			ttuProcessInfoBean4.setActivityName("Perform TTU Task");
			ttuProcessInfoBean4.setStatus("N/A");
			ttuProcessInfoBean4.setInformation("Comments:N/A");
			ttuProcessInfoBean4.setTimeStamp("N/A");
			ttuProcessInfoBean4.setTaskOwer("N/A");
			ttuProcessInfoBean4.setFlagNaN("1000004");
			list4.add(ttuProcessInfoBean4);
			mapList.put("8", list4);
			
			List<ProcessInfoBeanDetails> list5= new ArrayList<ProcessInfoBeanDetails>();
			list5= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean5 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean5.setSequenceNumber(7);
			ttuProcessInfoBean5.setActivityName("TTU Result Task");
			ttuProcessInfoBean5.setStatus("N/A");
			ttuProcessInfoBean5.setInformation("Comments:N/A");
			ttuProcessInfoBean5.setTimeStamp("N/A");
			ttuProcessInfoBean5.setTaskOwer("N/A");
			ttuProcessInfoBean5.setFlagNaN("1000005");
			list5.add(ttuProcessInfoBean5);
			mapList.put("8", list5);
			
			List<ProcessInfoBeanDetails> list6= new ArrayList<ProcessInfoBeanDetails>();
			list6= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean6 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean6.setSequenceNumber(7);
			ttuProcessInfoBean6.setActivityName("Re Schedule TTU Task");
			ttuProcessInfoBean6.setStatus("N/A");
			ttuProcessInfoBean6.setInformation("Comments:N/A");
			ttuProcessInfoBean6.setTimeStamp("N/A");
			ttuProcessInfoBean6.setTaskOwer("N/A");
			ttuProcessInfoBean6.setFlagNaN("1000006");
			list6.add(ttuProcessInfoBean6);
			mapList.put("8", list6);	
			
		}
		if(null!=mapList.get("8")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			boolean flag3=false;
			boolean flag4=false;
			boolean flag5=false;
			boolean flag6=false;
			
			processInfoBeanList =mapList.get("8");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag2 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000003")) {
					flag3 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000004")) {
					flag4 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000005")) {
					flag5 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000006")) {
					flag6 =true;	
				}
			}
			if(!flag1) {
				List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
				list1 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean1 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean1.setSequenceNumber(7);
				ttuProcessInfoBean1.setActivityName("Preflight Testing Task (OSD)");
				ttuProcessInfoBean1.setStatus("Is Pre-Flight Test Occurred ? \n"+"\tNA \n\t"+"Status: NA");
				ttuProcessInfoBean1.setInformation("Comments:N/A");
				ttuProcessInfoBean1.setTimeStamp("N/A");
				ttuProcessInfoBean1.setTaskOwer("N/A");
				ttuProcessInfoBean1.setFlagNaN("1000001");
				list1.add(ttuProcessInfoBean1);
				mapList.put("8", list1);
			}
			if (!flag2) {
				List<ProcessInfoBeanDetails> list2 = new ArrayList<ProcessInfoBeanDetails>();
				list2 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean2 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean2.setSequenceNumber(7);
				ttuProcessInfoBean2.setActivityName("TTU Applicability Task (OSD)");
				ttuProcessInfoBean2.setStatus("N/A");
				ttuProcessInfoBean2.setInformation("Comments:N/A");
				ttuProcessInfoBean2.setTimeStamp("N/A");
				ttuProcessInfoBean2.setTaskOwer("N/A");
				ttuProcessInfoBean2.setFlagNaN("1000002");
				list2.add(ttuProcessInfoBean2);
				mapList.put("8", list2);
			}
			if (!flag3) {
				List<ProcessInfoBeanDetails> list3 = new ArrayList<ProcessInfoBeanDetails>();
				list3 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean3 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean3.setSequenceNumber(7);
				ttuProcessInfoBean3.setActivityName("Schedule TTU Task");
				ttuProcessInfoBean3.setStatus("N/A");
				ttuProcessInfoBean3.setInformation("Comments:N/A");
				ttuProcessInfoBean3.setTimeStamp("N/A");
				ttuProcessInfoBean3.setTaskOwer("N/A");
				ttuProcessInfoBean3.setFlagNaN("1000003");
				list3.add(ttuProcessInfoBean3);
				mapList.put("8", list3);
			}
			if (!flag4) {
				List<ProcessInfoBeanDetails> list4 = new ArrayList<ProcessInfoBeanDetails>();
				list4 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean4 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean4.setSequenceNumber(7);
				ttuProcessInfoBean4.setActivityName("Perform TTU Task");
				ttuProcessInfoBean4.setStatus("N/A");
				ttuProcessInfoBean4.setInformation("Comments:N/A");
				ttuProcessInfoBean4.setTimeStamp("N/A");
				ttuProcessInfoBean4.setTaskOwer("N/A");
				ttuProcessInfoBean4.setFlagNaN("1000004");
				list4.add(ttuProcessInfoBean4);
				mapList.put("8", list4);
			}
			if (!flag5) {
				List<ProcessInfoBeanDetails> list5 = new ArrayList<ProcessInfoBeanDetails>();
				list5 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean5 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean5.setSequenceNumber(7);
				ttuProcessInfoBean5.setActivityName("TTU Result Task");
				ttuProcessInfoBean5.setStatus("N/A");
				ttuProcessInfoBean5.setInformation("Comments:N/A");
				ttuProcessInfoBean5.setTimeStamp("N/A");
				ttuProcessInfoBean5.setTaskOwer("N/A");
				ttuProcessInfoBean5.setFlagNaN("1000005");
				list5.add(ttuProcessInfoBean5);
				mapList.put("8", list5);
			}
			if (!flag6) {
				List<ProcessInfoBeanDetails> list6 = new ArrayList<ProcessInfoBeanDetails>();
				list6 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean6 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean6.setSequenceNumber(7);
				ttuProcessInfoBean6.setActivityName("Re Schedule TTU Task");
				ttuProcessInfoBean6.setStatus("N/A");
				ttuProcessInfoBean6.setInformation("Comments:N/A");
				ttuProcessInfoBean6.setTimeStamp("N/A");
				ttuProcessInfoBean6.setTaskOwer("N/A");
				ttuProcessInfoBean6.setFlagNaN("1000006");
				list6.add(ttuProcessInfoBean6);
				mapList.put("8", list6);
			}
			Collections.sort(mapList.get("8"), new Comparator<ProcessInfoBeanDetails>() {

				@Override
				public int compare(ProcessInfoBeanDetails o1, ProcessInfoBeanDetails o2) {
					if (o1 != null && o2 != null && o1.getFlagNaN() != null && o2.getFlagNaN() != null) {
						return o1.getFlagNaN().compareTo(o2.getFlagNaN());
					}
					return 0;
				}

			});
		}
		logger.info("Exsiting method populateDefaultTable" , this);
		return mapList;
	}

	
	private ProcessInfoBeanDetails setTTUBeanInfoNA(String activityName , String commet ,ProcessInfoBeanDetails infoBean) {
		infoBean.setActivityName(activityName);
		infoBean.setInformation("commet");
		infoBean.setStatus("N/A");
		infoBean.setInformation("Comments:N/A");
		infoBean.setTimeStamp("N/A");
		infoBean.setTaskOwer("N/A");
		return infoBean; 
	}

	private ProcessInfoBean setAllExpediteProcessInfo(BPMBusinessOrderStepBO bpmBusinessOrderStepBO[], ProcessInfoBean processInfoBean) {
		logger.info("Starting method setAllExpediteProcessInfo" , this);
		ProcessInfoBeanDetails oAexpProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails oMexpProcessInfoBean = new ProcessInfoBeanDetails();	
		ProcessInfoBeanDetails proposeExpBuildProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails finalExpBuildProcessInfoBean = new ProcessInfoBeanDetails();
		ExpediteProcessInfo expediteProcessInfo = new ExpediteProcessInfo();	
		Map<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>();
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() != 1005L){
				 List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				if(bo.getBusinessStepId() == 3117L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3117L] " ,this);
					oAexpProcessInfoBean.setActivityName("OA Approval Task");
					oAexpProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oAexpProcessInfoBean.setInformation("Comments:"+bo.getComments());	
					if(bo.getCreatedOn() != null){
						oAexpProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						}
					oAexpProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(oAexpProcessInfoBean);
					mapList.put("1",processInfoBeanList); //OA_Approval_Process
				}
				if(bo.getBusinessStepId() == 3120L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3120L] " ,this);
					oMexpProcessInfoBean.setActivityName("OM Approval Task");
					oMexpProcessInfoBean.setInformation("Comments:"+bo.getComments());
					oMexpProcessInfoBean.setStatus(bo.getBusinessStepStatus());		
					if(bo.getCreatedOn() != null){
						oMexpProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oMexpProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oMexpProcessInfoBean);
					mapList.put("2",processInfoBeanList); //OM_Approval_Process
				}
				if(bo.getBusinessStepId() == 3038L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3107L] " ,this);
					proposeExpBuildProcessInfoBean.setFlagNaN("2000001");
					proposeExpBuildProcessInfoBean.setActivityName("OSD:Proposed Expedite Build Date Task");
					proposeExpBuildProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					proposeExpBuildProcessInfoBean.setInformation("Comments:"+bo.getComments()+"\n\tProposed Expedite Build"+"\n\tDate:"+bo.getBusinessStepExecutedOn());
					proposeExpBuildProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					proposeExpBuildProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(proposeExpBuildProcessInfoBean);
					mapList.put("3",processInfoBeanList); //Proposed_Expedite_Build_Process
				}
				if(bo.getBusinessStepId() == 3107L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3038L] " ,this);
					proposeExpBuildProcessInfoBean.setFlagNaN("2000002");
					finalExpBuildProcessInfoBean.setActivityName("NI: Final Expedite Build Date Task");
					finalExpBuildProcessInfoBean.setInformation("Comments:"+bo.getComments()+"\n\tFinal Expedite Build Date:"+bo.getBusinessStepExecutedOn());
					finalExpBuildProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					finalExpBuildProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					finalExpBuildProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(finalExpBuildProcessInfoBean);
					mapList.put("4",processInfoBeanList);  //NI: Final Expedite Build Date Task
				}
			}
			else
			if(bo.getOrderTypeId().longValue() == 1003L){
				 List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				if(bo.getBusinessStepId() == 3117L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3117L and Change Order Type 1003L] " ,this);
					oAexpProcessInfoBean.setFlagNaN("2000001");
					oAexpProcessInfoBean.setActivityName("OA Approval Task");
					oAexpProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oAexpProcessInfoBean.setInformation("Comments:"+bo.getComments());	
					if(bo.getCreatedOn() != null){
						oAexpProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						}
					oAexpProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(oAexpProcessInfoBean);
					mapList.put("1",processInfoBeanList); //OA_Approval_Process
				}
				
				if(bo.getBusinessStepId() == 3120L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3120L and Change Order Type 1003L] " ,this);
					oMexpProcessInfoBean.setFlagNaN("2000002");
					oMexpProcessInfoBean.setActivityName("OM Approval Task");
					oMexpProcessInfoBean.setInformation("Comments:"+bo.getComments());
					oMexpProcessInfoBean.setStatus(bo.getBusinessStepStatus());		
					if(bo.getCreatedOn() != null){
						oMexpProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oMexpProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oMexpProcessInfoBean);
					mapList.put("2",processInfoBeanList); //OM_Approval_Process
				}
				
				if(bo.getBusinessStepId() == 3038L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3107L and for Change Order Type 1003L] " ,this);
					proposeExpBuildProcessInfoBean.setFlagNaN("2000003");
					proposeExpBuildProcessInfoBean.setActivityName("OSD:Proposed Expedite Build Date Task");
					proposeExpBuildProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					proposeExpBuildProcessInfoBean.setInformation("Comments:"+bo.getComments()+"\n\tProposed Expedite Build"+"\n\tDate:"+CommonUtils.getStringTillSpace(bo.getBusinessStepValue()));
					proposeExpBuildProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					proposeExpBuildProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(proposeExpBuildProcessInfoBean);
					mapList.put("3",processInfoBeanList);  //Proposed_Expedite_Build_Process
				}
				
				if(bo.getBusinessStepId() == 3107L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3038L and for Change Order Type 1003L] " ,this);
					finalExpBuildProcessInfoBean.setFlagNaN("2000004");
					finalExpBuildProcessInfoBean.setActivityName("NI: Final Expedite Build Date Task");
					finalExpBuildProcessInfoBean.setInformation("Comments:"+bo.getComments()+"\n\tFinal Expedite Build Date:"+CommonUtils.getStringTillSpace(bo.getBusinessStepValue()));
					finalExpBuildProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					finalExpBuildProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					finalExpBuildProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(finalExpBuildProcessInfoBean);
					mapList.put("4",processInfoBeanList);//Final_Expedite_Build_Process
				}
			
			}
			
		}
		if(null!=mapList && !mapList.isEmpty()) {
			mapList=populateDefaultExpedite(oAexpProcessInfoBean,oMexpProcessInfoBean,proposeExpBuildProcessInfoBean,finalExpBuildProcessInfoBean,mapList);
			mapList=Comparators.sortByKeyForExpedite(mapList);
			expediteProcessInfo.setHeaderValue("Expedite Process Information");
			expediteProcessInfo.setOAMapList(mapList);
			processInfoBean.setExpediteProcessInfo(expediteProcessInfo);
		}else {
			logger.info("MaPlist is null for expedite setAllExpediteProcessInfo" , this);
		}
		
		logger.info("Existing method setAllExpediteProcessInfo" , this);
		return processInfoBean;
	}
	
	private Map<String,List<ProcessInfoBeanDetails>>  populateDefaultExpedite(
			ProcessInfoBeanDetails oAexpProcessInfoBean,
			ProcessInfoBeanDetails oMexpProcessInfoBean,
			ProcessInfoBeanDetails proposeExpBuildProcessInfoBean ,
			ProcessInfoBeanDetails finalExpBuildProcessInfoBean,
			Map<String,List<ProcessInfoBeanDetails>> mapList) {
		logger.info("Starting method populateDefaultExpedite" , this);
		if(null==mapList.get("1")) { //OA_Approval_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oAexpProcessInfoBean.setActivityName("OA Approval Task");
			oAexpProcessInfoBean.setStatus("N/A");
			oAexpProcessInfoBean.setInformation("Comments:N/A");
			oAexpProcessInfoBean.setTimeStamp("N/A");
			processInfoBeanList.add(oAexpProcessInfoBean);
			mapList.put("1",processInfoBeanList);
		}
		if(null==mapList.get("2"))  { //OM_Approval_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oMexpProcessInfoBean.setActivityName("OM Approval Task");
			oMexpProcessInfoBean.setStatus("N/A");
			oMexpProcessInfoBean.setInformation("Comments:N/A");
			oMexpProcessInfoBean.setTimeStamp("N/A");
			processInfoBeanList.add(oMexpProcessInfoBean);
			mapList.put("2",processInfoBeanList);
		}
		if(null==mapList.get("3")) { //Proposed_Expedite_Build_Process
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails proposeExpBuildProcessInfoBean1 = new ProcessInfoBeanDetails();
			proposeExpBuildProcessInfoBean1.setActivityName("OSD:Proposed Expedite Build Date Task");
			proposeExpBuildProcessInfoBean1.setStatus("N/A");
			proposeExpBuildProcessInfoBean1.setInformation("Comments:N/A");
			proposeExpBuildProcessInfoBean1.setTimeStamp("N/A");
			proposeExpBuildProcessInfoBean1.setTaskOwer("N/A");
			list1.add(proposeExpBuildProcessInfoBean1);
			mapList.put("3", list1);
		}
		if(null==mapList.get("4")) {
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails proposeExpBuildProcessInfoBean2 = new ProcessInfoBeanDetails();
			proposeExpBuildProcessInfoBean2.setActivityName("NI: Final Expedite Build Date Task");
			proposeExpBuildProcessInfoBean2.setStatus("N/A");
			proposeExpBuildProcessInfoBean2.setInformation("Comments:N/A");
			proposeExpBuildProcessInfoBean2.setTimeStamp("N/A");
			proposeExpBuildProcessInfoBean2.setTaskOwer("N/A");
			list2.add(proposeExpBuildProcessInfoBean2);
			mapList.put("4", list2);	
		}
			
		
		if(null!=mapList.get("3") || null!=mapList.get("4")) {

			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			processInfoBeanList =mapList.get("3");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("2000003")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("2000004")) {
					flag1 =true;	
				}
			}
			if(flag1 && !flag2) {
				ProcessInfoBeanDetails proposeExpBuildProcessInfo= new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				proposeExpBuildProcessInfo.setActivityName("NI: Final Expedite Build Date Task");
				proposeExpBuildProcessInfo.setStatus("N/A");
				proposeExpBuildProcessInfo.setInformation("Comments:N/A");
				proposeExpBuildProcessInfo.setTimeStamp("N/A");
				proposeExpBuildProcessInfo.setTaskOwer("N/A");
				list1.add(proposeExpBuildProcessInfo);
				mapList.put("4", list1);
			}if(!flag1 && flag2) {
				ProcessInfoBeanDetails proposeExpBuildProcessInfo = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				proposeExpBuildProcessInfo.setActivityName("OSD:Proposed Expedite Build Date Task");
				proposeExpBuildProcessInfo.setStatus("N/A");
				proposeExpBuildProcessInfo.setInformation("Comments:N/A");
				proposeExpBuildProcessInfo.setTimeStamp("N/A");
				proposeExpBuildProcessInfo.setTaskOwer("N/A");
				list1.add(proposeExpBuildProcessInfo);
				mapList.put("3", list1);
			}
		
		}
		logger.info("Existing method populateDefaultExpedite" , this);
		return mapList;
		
	}
	
	private ProcessInfoBean setAllCancelProcessInfo(BPMBusinessOrderStepBO[] bpmBusinessOrderStepBO,
			ProcessInfoBean processInfoBean) {
		logger.info("Starting method setAllCancelProcessInfo" , this);
		Map<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>(); 
		ProcessInfoBeanDetails oaCancelProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardCancelProcessInfoBean = new ProcessInfoBeanDetails();
		CancelProcessInfo cancelProcessInfo = new CancelProcessInfo();	
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() != 1005L){
				 List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				
				 if(bo.getBusinessStepId() == 3184L){
					 logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
								+ " busssniess Step:3184L " ,this);
					 oaCancelProcessInfoBean.setActivityName("OA Cancel Approval Task");
					 oaCancelProcessInfoBean.setInformation("Comments:"+bo.getComments());
						if(bo.getBusinessStepExecutedOn() != null){
							oaCancelProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
							oaCancelProcessInfoBean.setTaskOwer(bo.getAttuid());
						}
						oaCancelProcessInfoBean.setStatus(bo.getBusinessStepStatus());
						processInfoBeanList.add(oaCancelProcessInfoBean);
						mapList.put("1",processInfoBeanList);   //OA_Cancel_Approval_Task
					}
				 if(bo.getBusinessStepId() == 3133L){
					 logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
								+ " busssniess Step:3133L " ,this);
					 dboardCancelProcessInfoBean.setActivityName("Cancellation Dashboard Task");
					 dboardCancelProcessInfoBean.setInformation(bo.getComments());
						if(bo.getBusinessStepExecutedOn() != null){
							dboardCancelProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
							dboardCancelProcessInfoBean.setTaskOwer(bo.getAttuid());
						}
						dboardCancelProcessInfoBean.setStatus(bo.getBusinessStepStatus());
						processInfoBeanList.add(dboardCancelProcessInfoBean);
						mapList.put("2",processInfoBeanList); //Cancellation_Dashboard_Process
					}
					
			}
		}
		mapList = populateDefaultCancelTable(oaCancelProcessInfoBean, dboardCancelProcessInfoBean, mapList);
		if(!CollectionUtils.isEmpty(mapList)) {
			mapList = Comparators.sortByKeyForCancel(mapList);
			cancelProcessInfo.setHeaderValue("Cancel Process Information");
			cancelProcessInfo.setOAMapList(mapList);
			processInfoBean.setCancelProcessInfo(cancelProcessInfo);
		}else {
			logger.error("@@@@@@@@@@MISC TAB PROCESS INFO DEFAULT CANCEL REQUEST TABLE MAP IS EMPTY!!!!!!!", this);
		}
		
		logger.info("Existing method setAllCancelProcessInfo" , this);
		// TODO Auto-generated method stub
		return processInfoBean;
	}
	
	private ProcessInfoBean setAllDecomission(BPMBusinessOrderStepBO[] bpmBusinessOrderStepBO,
			ProcessInfoBean processInfoBean) {
		logger.info("Starting method setAllDecomission" , this);
		Map<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>(); 
		ProcessInfoBeanDetails decomissondasboardInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardAPNHLRProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardNIProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardMPLSProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardBillingProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails dboardConfirmationProcessInfoBean = new ProcessInfoBeanDetails();
		DecommisionProcessInfo decomissonProcessInfo = new DecommisionProcessInfo();	
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() != 1005L){
				 List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				if(bo.getBusinessStepId() == 3139L){
					decomissondasboardInfoBean.setActivityName("CCS PM :Decommissioning Dashboard Task");
					decomissondasboardInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						decomissondasboardInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						decomissondasboardInfoBean.setTaskOwer(bo.getAttuid());
					}
					decomissondasboardInfoBean.setStatus(bo.getBusinessStepStatus());
					processInfoBeanList.add(decomissondasboardInfoBean);
					mapList.put("1",processInfoBeanList); //Decommissioning_Dashboard
				}//3139L
				if(bo.getBusinessStepId() == 3090L){
					//CCS PM : APN HLR Decommission Task
					dboardAPNHLRProcessInfoBean.setActivityName("CCS PM : APN HLR Decommission Task");
					dboardAPNHLRProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					dboardAPNHLRProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						dboardAPNHLRProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						dboardAPNHLRProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(dboardAPNHLRProcessInfoBean);
					mapList.put("2",processInfoBeanList);	 //APN_HLR_Decommission_Task
				}//3090L
				if(bo.getBusinessStepId() == 3091L){
					dboardNIProcessInfoBean.setActivityName("NI :Network Decommission Task");
					dboardNIProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					dboardNIProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						dboardNIProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						dboardNIProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(dboardNIProcessInfoBean);
					mapList.put("3",processInfoBeanList);	//APN_Build_Decommission_Task
				}//3091L
				if(bo.getBusinessStepId() == 3092L){
					dboardMPLSProcessInfoBean.setActivityName("CCS PM :MPLS Backhaul Decommission Task");
					dboardMPLSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					dboardMPLSProcessInfoBean.setInformation("Commets:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						dboardMPLSProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						dboardMPLSProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(dboardMPLSProcessInfoBean);
					mapList.put("4",processInfoBeanList);	//MPLS_Backhaul_Decommission_Task
				}//3092L
				if(bo.getBusinessStepId() == 3094L){
					dboardBillingProcessInfoBean.setActivityName("OA :Decommission Task for Billing");
					dboardBillingProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					dboardBillingProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getBusinessStepExecutedOn() != null){
						dboardBillingProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
						dboardBillingProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(dboardBillingProcessInfoBean);
					mapList.put("5",processInfoBeanList);	//Decommission_Billing
				}//3094L
				
				if(bo.getBusinessStepId() == 3140L){
					dboardConfirmationProcessInfoBean.setActivityName("CCS PM :Decommission Confirmation Task");
					dboardConfirmationProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						dboardConfirmationProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						dboardConfirmationProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					dboardConfirmationProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					processInfoBeanList.add(dboardConfirmationProcessInfoBean);
					mapList.put("6",processInfoBeanList); //Decommission_Confirmation_Task
				}
			}//orderstatus check
		}//end of for loop
		
		mapList = populateDefautDecomissonTable(decomissondasboardInfoBean, dboardAPNHLRProcessInfoBean, dboardNIProcessInfoBean, dboardMPLSProcessInfoBean, dboardBillingProcessInfoBean,dboardConfirmationProcessInfoBean, mapList);
		
		if(!CollectionUtils.isEmpty(mapList)) {
			mapList = Comparators.sortByKeyForDecomission(mapList);
			decomissonProcessInfo.setHeaderValue("Decommission Information");
			decomissonProcessInfo.setOAMapList(mapList);
			processInfoBean.setDecommisionProcessInfo(decomissonProcessInfo);
		}else {
			logger.error("@@@@@@@@@@MISC TAB PROCESS INFO DEFAULT Decomssion REQUEST TABLE MAP IS EMPTY!!!!!!!", this);
		}
		logger.info("Existing method setAllDecomission" , this);
		return processInfoBean;
	}
	

	
	private ProcessInfoBean setAllDAPNProcessInfo(BPMBusinessOrderStepBO[] bpmBusinessOrderStepBO,
			ProcessInfoBean processInfoBean) {
		logger.info("Starting method setAllDAPNProcessInfo" , this);
		Map<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>();
		ProcessInfoBeanDetails oaDAPNProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails itopsDAPNProcessInfoBean = new ProcessInfoBeanDetails();
		ProcessInfoBeanDetails oaDAPNBillingProcessInfoBean = new ProcessInfoBeanDetails();
		DAPNProcessInfo dAPNProcessInfo = new DAPNProcessInfo();
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() != 1005L){
				 List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				if(bo.getBusinessStepId() == 3200L){
					oaDAPNProcessInfoBean.setActivityName("OA D-APN Build Review");
					oaDAPNProcessInfoBean.setInformation("Commets:"+bo.getComments());
					if(bo.getCreatedOn()!= null){
						oaDAPNProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oaDAPNProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					oaDAPNProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					processInfoBeanList.add(oaDAPNProcessInfoBean);
					mapList.put("1",processInfoBeanList); //OA_Approval
				}//3200L
				if(bo.getBusinessStepId() == 3206L){
					itopsDAPNProcessInfoBean.setActivityName("IT OPS D-APN Build Request");
					itopsDAPNProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					itopsDAPNProcessInfoBean.setInformation("Comments:"+bo.getComments());		
					itopsDAPNProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					itopsDAPNProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(oaDAPNProcessInfoBean);
					mapList.put("2",processInfoBeanList); //IT_OPS_Approval_Process
				}//3206L
				if(bo.getBusinessStepId() == 3209L){	
					oaDAPNBillingProcessInfoBean.setActivityName("OA D-APN Billing Request Submission");
					oaDAPNBillingProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
					oaDAPNBillingProcessInfoBean.setInformation("Comments:"+bo.getComments());		
					oaDAPNBillingProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oaDAPNBillingProcessInfoBean.setTaskOwer(bo.getAttuid());
					processInfoBeanList.add(oaDAPNBillingProcessInfoBean);
					mapList.put("3",processInfoBeanList);  //Process_Billing_Request
				}
			}
		}
		dAPNProcessInfo.setHeaderValue("");
		mapList = Comparators.sortByKeyForDapn(mapList);
		dAPNProcessInfo.setOAMapList(mapList);
		processInfoBean.setDAPNProcessInfo(dAPNProcessInfo);
		logger.info("Existing method setAllDAPNProcessInfo" , this);
		return processInfoBean;
	}

	private ProcessInfoBean setAllChangeOrderProcessInfo(BPMBusinessOrderStepBO[] bpmBusinessOrderStepBO,
			ProcessInfoBean processInfoBean) {
		ProcessInfoBeanDetails crDashBoardProcessInfoBean = new ProcessInfoBeanDetails();	
		ProcessInfoBeanDetails oACRProcessInfoBean = new ProcessInfoBeanDetails();	
		ProcessInfoBeanDetails oAProcessInfoBean = new ProcessInfoBeanDetails();	
		ProcessInfoBeanDetails oMProcessInfoBean = new ProcessInfoBeanDetails();		
		ProcessInfoBeanDetails osdProcessInfoBean = new ProcessInfoBeanDetails();		
		ProcessInfoBeanDetails crapnITOPSProcessInfoBean = new ProcessInfoBeanDetails();		
		ProcessInfoBeanDetails crbillingProcessInfoBean = new ProcessInfoBeanDetails();	
		ProcessInfoBeanDetails crCommentsForCR =new ProcessInfoBeanDetails();
		ChangeProcessInfo changeprocessInfoDefault = new ChangeProcessInfo();		
		
		HashMap<String,List<ProcessInfoBeanDetails>> mapList = new HashMap<String,List<ProcessInfoBeanDetails>>(); 	
		for(BPMBusinessOrderStepBO bo: bpmBusinessOrderStepBO){
			if(bo.getBusinessStepId() != null && bo.getOrderTypeId().longValue() == 1005L){
				List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
				if(bo.getBusinessStepId() == 3137L){
					crDashBoardProcessInfoBean.setActivityName("Change Request Dashboard Task");
					crDashBoardProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						crDashBoardProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						crDashBoardProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					crDashBoardProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					processInfoBeanList.add(crDashBoardProcessInfoBean);
					mapList.put("-1", processInfoBeanList); //Change_Request_Dashboard
				}
				if(bo.getBusinessStepId() == 3179L){
					oACRProcessInfoBean.setActivityName("OA CR Approval Task");
					oACRProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oACRProcessInfoBean.setInformation("Comments:"+bo.getComments());
					if(bo.getCreatedOn() != null){
						oACRProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oACRProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oACRProcessInfoBean);
					mapList.put("0", processInfoBeanList); //OA_CR_Approval_Process
				} 
				if(bo.getBusinessStepId() == 3001L){
					oAProcessInfoBean.setActivityName("OA Approval Task");
					oAProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oAProcessInfoBean.setInformation(bo.getComments());
					if(bo.getCreatedOn() != null){
						oAProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oAProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oAProcessInfoBean); 
					mapList.put("1", processInfoBeanList);  //OA_Approval_Process
				} 
				if(bo.getBusinessStepId() == 3002L){
					oMProcessInfoBean.setActivityName("OM Approval Task");
					oMProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					oMProcessInfoBean.setInformation(bo.getComments());
					if(bo.getCreatedOn() != null){
						oMProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						oMProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(oMProcessInfoBean);
					mapList.put("2", processInfoBeanList); //OM_Approval_Process
				} 
				if(bo.getBusinessStepId() == 3144L){
					osdProcessInfoBean.setFlagNaN("1000005");
					osdProcessInfoBean.setActivityName("OSD Approval Task");
					osdProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					osdProcessInfoBean.setInformation(bo.getComments());
					if(bo.getCreatedOn() != null) {
						osdProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						osdProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(osdProcessInfoBean);
					mapList.put("3", processInfoBeanList);  //OSD_Approval_Process
				} 
				//APN HLR IWOS Create Task change request 
				if(bo.getBusinessStepId() == 3142L || bo.getBusinessStepId() == 3143L || bo.getBusinessStepId() == 3003L || bo.getBusinessStepId()==3031L) {
					ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();	
					if(bo.getBusinessStepId() == 3003L || bo.getBusinessStepId() == 3142L){
							logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
									+ " busssniess Step:3003L  " ,this);
							if(null!=bo.getBusinessStepStatus()) {
								apnHLRIWOSProcessInfoBean.setActivityName("APN	HLR/HSS IWOS Creation Task");
								apnHLRIWOSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
								apnHLRIWOSProcessInfoBean.setFlagNaN("1000001");
								if(null!=bo.getBusinessStepValue()) {
									apnHLRIWOSProcessInfoBean.setInformation("APN HLR/HSS IWOS Ticket"+"\n Number:"+bo.getBusinessStepValue()+"\n Comments:"+bo.getComments());
								}else {
									apnHLRIWOSProcessInfoBean.setInformation("Comments:"+bo.getComments());	
								}
									if(bo.getCreatedOn() != null){
										apnHLRIWOSProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
										apnHLRIWOSProcessInfoBean.setTaskOwer(bo.getAttuid());
									}
								List<ProcessInfoBeanDetails> list1_3003L= new ArrayList<ProcessInfoBeanDetails>();
									if(null!=mapList.get("4")) {
										list1_3003L=mapList.get("4");
										}
									list1_3003L.add(apnHLRIWOSProcessInfoBean);
									mapList.put("4",list1_3003L);  //APN_HLR/HSS_IWOS_Process
							}
							
						}//3003L
						if(bo.getBusinessStepId() == 3031L || bo.getBusinessStepId() ==3143L){
							logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
									+ " busssniess Step:3031L  " ,this);
							if(null!=bo.getBusinessStepStatus()) {
								apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Completion Task");
								apnHLRIWOSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
								apnHLRIWOSProcessInfoBean.setFlagNaN("1000002");
								if(null!=bo.getBusinessStepValue()) {
									apnHLRIWOSProcessInfoBean.setInformation("APN HLR/HSS IWOS Ticket"+"\n Number:"+bo.getBusinessStepValue()+"\n Comments:"+bo.getComments());
								}else {
									apnHLRIWOSProcessInfoBean.setInformation("Comments:"+bo.getComments());	
								}
								if(bo.getCreatedOn() != null){
									apnHLRIWOSProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
									apnHLRIWOSProcessInfoBean.setTaskOwer(bo.getAttuid());
								}
								List<ProcessInfoBeanDetails> list2_3031L= new ArrayList<ProcessInfoBeanDetails>();
								if(null!=mapList.get("4")) {
									list2_3031L=mapList.get("4");
									}
								list2_3031L.add(apnHLRIWOSProcessInfoBean);
								mapList.put("4",list2_3031L);  //APN_HLR/HSS_IWOS_Process
							}
							
						}//3031L
						//if(bo.getBusinessStepId() == 3142L){} //3142L
						//if(bo.getBusinessStepId() == 3143L){}//3143L
					}
				//APN IT OPS TASK change request 
				if(bo.getBusinessStepId() == 3005L){
					crapnITOPSProcessInfoBean.setActivityName("APN IT OPS Completion Task");
					crapnITOPSProcessInfoBean.setFlagNaN("1000001");
					crapnITOPSProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					if(bo.getBusinessStepExecutedOn() != null){
						crapnITOPSProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
						crapnITOPSProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					crapnITOPSProcessInfoBean.setInformation("Commets:"+bo.getComments());
					processInfoBeanList.add(crapnITOPSProcessInfoBean);
					mapList.put("5", processInfoBeanList); //APN_IT_OPS_Process
					
				}
				//APN Build IWOS Create Task change request 
				if(bo.getBusinessStepId() == 3007L){
					ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();	
					if(null!=bo.getBusinessStepStatus()) {
						apnBUILDIWOSInfoBean.setActivityName("NetworkIWOS Creation Task");
						apnBUILDIWOSInfoBean.setFlagNaN("1000001");
						apnBUILDIWOSInfoBean.setItwosNoteDisplay("true");
						if(bo.getCreatedOn() != null){
							apnBUILDIWOSInfoBean.setTimeStamp(bo.getCreatedOn().toString());
							apnBUILDIWOSInfoBean.setTaskOwer(bo.getAttuid());
						}
						apnBUILDIWOSInfoBean.setStatus(bo.getBusinessStepStatus());
						if(null!=bo.getBusinessStepValue() && null!=bo.getBusinessStepStatus() && null!=bo.getBusinessStepExecutedOn()) {
							apnBUILDIWOSInfoBean.setInformation("Network IWOS Ticket Number :"+"\n\tNumber:"+bo.getBusinessStepValue()+
									"Network Estimated Complete Date:"+bo.getBusinessStepExecutedOn().toString()+ "\n\tComments:"+bo.getComments()+"\n\tIWOS Notes:");
						}
						if(null!=bo.getBusinessStepValue() && null==bo.getBusinessStepExecutedOn()) {
							apnBUILDIWOSInfoBean.setInformation("Network IWOS Ticket Number :"+"\n\t Number:"+bo.getBusinessStepValue()+
									"Netork Estimated Complete Date:"+bo.getBusinessStepExecutedOn().toString()+ "\n\tComments:"+bo.getComments()+"\n\tIWOS Notes:");
						}
						List<ProcessInfoBeanDetails> list_3007L= new ArrayList<ProcessInfoBeanDetails>();
						if(null!=mapList.get("6")) {
							list_3007L=mapList.get("6");
						}
						list_3007L.add(apnBUILDIWOSInfoBean); 
						mapList.put("6", list_3007L);  //Network_IWOS_Process
					}
				}
				//APN CCSPM Complete Task  change request  
				if(bo.getBusinessStepId() == 3012L){
					ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();	
					if(null!=bo.getBusinessStepStatus()) {
						apnBUILDIWOSInfoBean.setActivityName("Network IWOS Suspension/Completion TASK");
						apnBUILDIWOSInfoBean.setFlagNaN("1000002");
						if(bo.getCreatedOn() != null){
							apnBUILDIWOSInfoBean.setTimeStamp(bo.getCreatedOn().toString());
							apnBUILDIWOSInfoBean.setTaskOwer(bo.getAttuid());
						}
						apnBUILDIWOSInfoBean.setInformation("Comments:"+bo.getComments());
						List<ProcessInfoBeanDetails> list_3012= new ArrayList<ProcessInfoBeanDetails>();
						if(null!=mapList.get("6")) {
							list_3012=mapList.get("6");
						}
						list_3012.add(apnBUILDIWOSInfoBean); 
						mapList.put("6", list_3012);  //Network_IWOS_Process
					}
					
				}
				//Billing submission Task 
				if(bo.getBusinessStepId() == 3023L){
					logger.debug("[OrderID : " + (bo.getOrderId() == null ? "" : bo.getOrderId())
							+ " busssniess Step:3023L ", this);
					crbillingProcessInfoBean.setActivityName("Billing Request Submission Task");
					crbillingProcessInfoBean.setStatus(bo.getBusinessStepStatus());
					crbillingProcessInfoBean.setInformation(bo.getComments());	
					if(bo.getCreatedOn() != null){
						crbillingProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
						crbillingProcessInfoBean.setTaskOwer(bo.getAttuid());
					}
					processInfoBeanList.add(crbillingProcessInfoBean); 
					mapList.put("7", processInfoBeanList); //Process_Billing_Request
				} 
				
				//TTU Process for Change request
				if(bo.getBusinessStepId() == 3025L || bo.getBusinessStepId() == 3026L || bo.getBusinessStepId() == 3132L
						|| bo.getBusinessStepId() == 3028L || bo.getBusinessStepId() == 3029L || bo.getBusinessStepId() == 3141L) {
					ProcessInfoBeanDetails ttuProcessInfoBean = new ProcessInfoBeanDetails();
					//OS conform preflight test
					if(bo.getBusinessStepId() == 3025L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("Preflight Testing Task (OSD)");
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							ttuProcessInfoBean.setFlagNaN("1000001");
							if(bo.getBusinessStepExecutedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}					
							ttuProcessInfoBean.setInformation("\r Is Pre-Flight Test Occurred ?:\n\r"+bo.getBusinessStepValue()+
									"\r\nComments:"+bo.getComments());
							List<ProcessInfoBeanDetails> list_3025L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3025L=mapList.get("8");
							}
							list_3025L.add(ttuProcessInfoBean); 
							mapList.put("8", list_3025L);
						}
						
					}//3025L
					//OS Conform TTU Require 
					if(bo.getBusinessStepId() == 3026L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("TTU Applicability Task (OSD)");
							ttuProcessInfoBean.setFlagNaN("1000002");
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							ttuProcessInfoBean.setInformation("Comments:"+bo.getComments());
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							List<ProcessInfoBeanDetails> list_3026L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3026L=mapList.get("8");
							}
							list_3026L.add(ttuProcessInfoBean);
							mapList.put("8", list_3026L);
						}
						
					}//3026L
					//Schedule TTU Task
					if(bo.getBusinessStepId() == 3132L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("Schedule TTU Task");
							ttuProcessInfoBean.setInformation(bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000003");
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3132L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3132L=mapList.get("8");
							}
							list_3132L.add(ttuProcessInfoBean);
							mapList.put("8", list_3132L);
						}
						
					}//3132L
					//Perform TTU Task
					if(bo.getBusinessStepId() == 3028L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("Perform TTU Task");
							ttuProcessInfoBean.setFlagNaN("1000004");
							ttuProcessInfoBean.setInformation(bo.getComments());
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3028L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3028L=mapList.get("8");
							}
							list_3028L.add(ttuProcessInfoBean);
							mapList.put("8", list_3028L);
						}
						
					}//3028L
					//TTU Result Task
					if(bo.getBusinessStepId() == 3029L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("TTU Result Task");
							ttuProcessInfoBean.setInformation(bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000005");
							if(bo.getCreatedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getCreatedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3029L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3029L=mapList.get("8");
							}
							list_3029L.add(ttuProcessInfoBean);
							mapList.put("8", list_3029L);
						}
						
					}//3029L
					//Re Schedule TTU Task 
					if(bo.getBusinessStepId() == 3141L){
						if(null!=bo.getBusinessStepStatus()) {
							ttuProcessInfoBean.setActivityName("Re Schedule TTU Task");
							ttuProcessInfoBean.setInformation(bo.getComments());
							ttuProcessInfoBean.setFlagNaN("1000006");
							if(bo.getBusinessStepExecutedOn() != null){
								ttuProcessInfoBean.setTimeStamp(bo.getBusinessStepExecutedOn().toString());
								ttuProcessInfoBean.setTaskOwer(bo.getAttuid());
							}
							ttuProcessInfoBean.setStatus(bo.getBusinessStepStatus());
							List<ProcessInfoBeanDetails> list_3141L= new ArrayList<ProcessInfoBeanDetails>();
							if(null!=mapList.get("8")) {
								list_3141L=mapList.get("8");
							}
							list_3141L.add(ttuProcessInfoBean);
							mapList.put("8", list_3141L);
						}
						
					}//3141L
				}
				
				//change Request Completion 
				if(bo.getBusinessStepId() == 3138L){
					crCommentsForCR.setActivityName("Change Request Completion Task");
					crCommentsForCR.setInformation(bo.getComments());
					if(bo.getCreatedOn() != null){
						crCommentsForCR.setTimeStamp(bo.getCreatedOn().toString());
						crCommentsForCR.setTaskOwer(bo.getAttuid());
					}
					crCommentsForCR.setStatus(bo.getBusinessStepStatus());
					processInfoBeanList.add(crCommentsForCR);
					mapList.put("9", processInfoBeanList); //Change_Request_Completion
				}
			}	
		}
		mapList = populateDefaultCRTable(crDashBoardProcessInfoBean,oMProcessInfoBean,osdProcessInfoBean,oAProcessInfoBean,oACRProcessInfoBean,crapnITOPSProcessInfoBean,crbillingProcessInfoBean,mapList,crCommentsForCR);
		if(!CollectionUtils.isEmpty(mapList)) {
			mapList = Comparators.sortByKeyForChangeOrder(mapList);
			changeprocessInfoDefault.setHeaderValue("Change Request Process Information");
			changeprocessInfoDefault.setOAMapList(mapList);
			processInfoBean.setChangeProcessInfo(changeprocessInfoDefault);
		}else {
			logger.error("@@@@@@@@@@MISC TAB PROCESS INFO DEFAULT CHANGE REQUEST TABLE MAP IS EMPTY!!!!!!!", this);
		}
		logger.info("Existing method setAllNoNCRProcessInfo" , this);
		return processInfoBean;
	}

	private Map<String, List<ProcessInfoBeanDetails>> populateDefautDecomissonTable(
			ProcessInfoBeanDetails decomissondasboardInfoBean,	ProcessInfoBeanDetails dboardAPNHLRProcessInfoBean,
			ProcessInfoBeanDetails dboardNIProcessInfoBean,ProcessInfoBeanDetails dboardMPLSProcessInfoBean,
			ProcessInfoBeanDetails dboardBillingProcessInfoBean,ProcessInfoBeanDetails dboardConfirmationProcessInfoBean ,Map<String,List<ProcessInfoBeanDetails>> mapList){
		logger.info("Starting method populateDefautDecomissonTable" ,this);	
		if(null==mapList.get("1")) {  //Decommissioning_Dashboard
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			decomissondasboardInfoBean.setActivityName("CCS PM :Decommissioning Dashboard Task");
			decomissondasboardInfoBean.setStatus("N/A");
			decomissondasboardInfoBean.setInformation("Comments:N/A");
			decomissondasboardInfoBean.setTimeStamp("N/A");
			decomissondasboardInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(decomissondasboardInfoBean);
			//mapList.put("Change_Request_Dashboard",processInfoBeanList);
			mapList.put("1",processInfoBeanList);
		}
		if(null==mapList.get("2")) { //APN_HLR_Decommission_Task
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardAPNHLRProcessInfoBean.setActivityName("NI :Network Decommission Task");
			dboardAPNHLRProcessInfoBean.setStatus("N/A");
			dboardAPNHLRProcessInfoBean.setInformation("Comments:N/A");
			dboardAPNHLRProcessInfoBean.setTimeStamp("N/A");
			dboardAPNHLRProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardAPNHLRProcessInfoBean);
			mapList.put("2",processInfoBeanList);
		}
		//APN_Build_Decommission_Task
		if(null==mapList.get("3")) { //APN_HLR_Decommission_Task
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardAPNHLRProcessInfoBean.setActivityName("NI :Network Decommission Task");
			dboardAPNHLRProcessInfoBean.setStatus("N/A");
			dboardAPNHLRProcessInfoBean.setInformation("Comments:N/A");
			dboardAPNHLRProcessInfoBean.setTimeStamp("N/A");
			dboardAPNHLRProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardAPNHLRProcessInfoBean);
			mapList.put("3",processInfoBeanList);
		}
		if(null==mapList.get("4")) { //MPLS_Backhaul_Decommission_Task
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardMPLSProcessInfoBean.setActivityName("CCS PM :MPLS Backhaul Decommission Task");
			dboardMPLSProcessInfoBean.setStatus("N/A");
			dboardMPLSProcessInfoBean.setInformation("Comments:N/A");
			dboardMPLSProcessInfoBean.setTimeStamp("N/A");
			dboardMPLSProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardMPLSProcessInfoBean);
			mapList.put("4",processInfoBeanList);
		}
		if(null==mapList.get("5")) { //Decommission_Billing
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardBillingProcessInfoBean.setActivityName("OA :Decommission Task for Billing");
			dboardBillingProcessInfoBean.setStatus("N/A");
			dboardBillingProcessInfoBean.setInformation("Comments:N/A");
			dboardBillingProcessInfoBean.setTimeStamp("N/A");
			dboardBillingProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardBillingProcessInfoBean);
			mapList.put("5",processInfoBeanList);
		}
		if(null==mapList.get("6")) { //Decommission_Confirmation_Task
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardConfirmationProcessInfoBean.setActivityName("CCS PM :Decommission Confirmation Task");
			dboardConfirmationProcessInfoBean.setStatus("N/A");
			dboardConfirmationProcessInfoBean.setInformation("Comments:N/A");
			dboardConfirmationProcessInfoBean.setTimeStamp("N/A");
			dboardConfirmationProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardConfirmationProcessInfoBean);
			mapList.put("6",processInfoBeanList);
		}
		
		logger.info("Existing method populateDefautDecomissonTable" ,this);	
		return mapList;
	}
	private Map<String, List<ProcessInfoBeanDetails>> populateDefaultCancelTable(ProcessInfoBeanDetails oaCancelProcessInfoBean,
			ProcessInfoBeanDetails dboardCancelProcessInfoBean,Map<String,List<ProcessInfoBeanDetails>> mapList ){
		logger.info("Starting method populateDefaultCancelTable",this);
		if(null==mapList.get("1")) { //OA_Cancel_Approval_Task
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oaCancelProcessInfoBean.setActivityName("OA Cancel Approval Task");
			oaCancelProcessInfoBean.setStatus("N/A");
			oaCancelProcessInfoBean.setInformation("Comments:N/A");
			oaCancelProcessInfoBean.setTimeStamp("N/A");
			oaCancelProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oaCancelProcessInfoBean);
			//mapList.put("Change_Request_Dashboard",processInfoBeanList);
			mapList.put("1",processInfoBeanList);
		}
		if(null==mapList.get("2")) { //Cancellation_Dashboard_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			dboardCancelProcessInfoBean.setActivityName("Cancellation Dashboard Task");
			dboardCancelProcessInfoBean.setStatus("N/A");
			dboardCancelProcessInfoBean.setInformation("Comments:N/A");
			dboardCancelProcessInfoBean.setTimeStamp("N/A");
			dboardCancelProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(dboardCancelProcessInfoBean);
			mapList.put("2",processInfoBeanList);
		}
		logger.info("Exsiting method populateDefaultCancelTable");
		return mapList;
	}
	
	private HashMap<String, List<ProcessInfoBeanDetails>> populateDefaultCRTable(ProcessInfoBeanDetails crDashBoardProcessInfoBean,ProcessInfoBeanDetails oMProcessInfoBean,
			ProcessInfoBeanDetails osdProcessInfoBean, ProcessInfoBeanDetails oAProcessInfoBean,ProcessInfoBeanDetails oACRProcessInfoBean,
			ProcessInfoBeanDetails crapnITOPSProcessInfoBean, ProcessInfoBeanDetails crbillingProcessInfoBean,
			HashMap<String, List<ProcessInfoBeanDetails>> mapList,ProcessInfoBeanDetails crCommentsForCR) {
		logger.info("Starting method populateDefaultCRTable" , this);
		if(null==mapList.get("-1")) { //Change_Request_Dashboard
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			crDashBoardProcessInfoBean.setActivityName("Change Request Dashboard Task");
			crDashBoardProcessInfoBean.setStatus("N/A");
			crDashBoardProcessInfoBean.setInformation("Comments:N/A");
			crDashBoardProcessInfoBean.setTimeStamp("N/A");
			crDashBoardProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(crDashBoardProcessInfoBean);
			mapList.put("-1",processInfoBeanList);
		}
		if(null==mapList.get("0")) {  //OA CR Approval
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oACRProcessInfoBean.setActivityName("OA CR Approval Task");
			oACRProcessInfoBean.setStatus("N/A");
			oACRProcessInfoBean.setInformation("Comments:N/A");
			oACRProcessInfoBean.setTimeStamp("N/A");
			oACRProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oAProcessInfoBean);
			//mapList.put("Change_Request_Dashboard",processInfoBeanList);
			mapList.put("0",processInfoBeanList);
		}

		if(null==mapList.get("1")) { //OA_Approval_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oAProcessInfoBean.setActivityName("OA Approval Task");
			oAProcessInfoBean.setStatus("N/A");
			oAProcessInfoBean.setInformation("Comments:N/A");
			oAProcessInfoBean.setTimeStamp("N/A");
			oAProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oAProcessInfoBean);
			mapList.put("1",processInfoBeanList);
			
		}
		if(null==mapList.get("2")) { //OM_Approval_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			oMProcessInfoBean.setActivityName("OM Approval Task");
			oMProcessInfoBean.setStatus("N/A");
			oMProcessInfoBean.setInformation("Comments:N/A");
			oMProcessInfoBean.setTimeStamp("N/A");
			oMProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(oMProcessInfoBean);
			mapList.put("2",processInfoBeanList);
			
		}
		if(null==mapList.get("3")) { //OSD_Approval_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			osdProcessInfoBean.setActivityName("OSD Approval Task");
			osdProcessInfoBean.setStatus("N/A");
			osdProcessInfoBean.setInformation("Comments:N/A");
			osdProcessInfoBean.setTimeStamp("N/A");
			osdProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(osdProcessInfoBean);
			mapList.put("3",processInfoBeanList);
			
		}
		if(null==mapList.get("5")) { //APN_IT_OPS_Process
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			crapnITOPSProcessInfoBean.setActivityName("APN IT OPS Completion Task");
			crapnITOPSProcessInfoBean.setStatus("N/A");
			crapnITOPSProcessInfoBean.setInformation("Comments:N/A");
			crapnITOPSProcessInfoBean.setTimeStamp("N/A");
			crapnITOPSProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(crapnITOPSProcessInfoBean);
			mapList.put("5",processInfoBeanList);
			
		}
		if(null==mapList.get("7")) { //Process_Billing_Request
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			crbillingProcessInfoBean.setActivityName("Billing Request Submission Task");
			crbillingProcessInfoBean.setStatus("N/A");
			crbillingProcessInfoBean.setInformation("Comments:N/A");
			crbillingProcessInfoBean.setTimeStamp("N/A");
			crbillingProcessInfoBean.setTaskOwer("N/A");
			processInfoBeanList.add(crbillingProcessInfoBean);
			mapList.put("7",processInfoBeanList);
			
		}
		if(null==mapList.get("4")) { //APN_HLR/HSS_IWOS_Process
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean1 = new ProcessInfoBeanDetails();
			apnHLRIWOSProcessInfoBean1.setActivityName("APN HLR/HSS IWOS Creation Task");
			apnHLRIWOSProcessInfoBean1.setStatus("N/A");
			apnHLRIWOSProcessInfoBean1.setInformation("Comments:N/A");
			apnHLRIWOSProcessInfoBean1.setTimeStamp("N/A");
			apnHLRIWOSProcessInfoBean1.setTaskOwer("N/A");
			apnHLRIWOSProcessInfoBean1.setFlagNaN("1000001");
			list1.add(apnHLRIWOSProcessInfoBean1);
			mapList.put("4", list1);
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("4");
			ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean2 = new ProcessInfoBeanDetails();
			apnHLRIWOSProcessInfoBean2.setActivityName("APN HLR/HSS IWOS Completion Task");
			apnHLRIWOSProcessInfoBean2.setStatus("N/A");
			apnHLRIWOSProcessInfoBean2.setInformation("Comments:N/A");
			apnHLRIWOSProcessInfoBean2.setTimeStamp("N/A");
			apnHLRIWOSProcessInfoBean2.setTaskOwer("N/A");
			apnHLRIWOSProcessInfoBean1.setFlagNaN("1000002");
			list2.add(apnHLRIWOSProcessInfoBean2);
			
			mapList.put("4", list2);
		}
		if(null!=mapList.get("4")){
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			processInfoBeanList =mapList.get("4");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag1 =true;	
				}
			}
			if(!flag2) {
				ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= mapList.get("4");
				apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Completion Task");
				apnHLRIWOSProcessInfoBean.setStatus("N/A");
				apnHLRIWOSProcessInfoBean.setInformation("Comments:N/A");
				apnHLRIWOSProcessInfoBean.setTimeStamp("N/A");
				apnHLRIWOSProcessInfoBean.setTaskOwer("N/A");
				list1.add(apnHLRIWOSProcessInfoBean);
				mapList.put("4", list1);
			}if(!flag1) {
				ProcessInfoBeanDetails apnHLRIWOSProcessInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= mapList.get("4");
				apnHLRIWOSProcessInfoBean.setActivityName("APN HLR/HSS IWOS Creation Task");
				apnHLRIWOSProcessInfoBean.setStatus("N/A");
				apnHLRIWOSProcessInfoBean.setInformation("Comments:N/A");
				apnHLRIWOSProcessInfoBean.setTimeStamp("N/A");
				apnHLRIWOSProcessInfoBean.setTaskOwer("N/A");
				list1.add(apnHLRIWOSProcessInfoBean);
				mapList.put("4", list1);
			}
		}	
		
		if(null==mapList.get("6")) { //Network_IWOS_Process
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails apnBUILDIWOSInfoBean1 = new ProcessInfoBeanDetails();
			apnBUILDIWOSInfoBean1.setActivityName("NetworkIWOS Creation Task");
			apnBUILDIWOSInfoBean1.setStatus("N/A");
			apnBUILDIWOSInfoBean1.setInformation("Comments:N/A");
			apnBUILDIWOSInfoBean1.setTimeStamp("N/A");
			apnBUILDIWOSInfoBean1.setTaskOwer("N/A");
			apnBUILDIWOSInfoBean1.setFlagNaN("1000001");
			list1.add(apnBUILDIWOSInfoBean1);
			mapList.put("6", list1);
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("6");
			ProcessInfoBeanDetails apnBUILDIWOSInfoBean2 = new ProcessInfoBeanDetails();
			apnBUILDIWOSInfoBean2.setActivityName("Network IWOS Suspension/Completion TASK");
			apnBUILDIWOSInfoBean2.setStatus("N/A");
			apnBUILDIWOSInfoBean2.setInformation("Comments:N/A");
			apnBUILDIWOSInfoBean2.setTimeStamp("N/A");
			apnBUILDIWOSInfoBean2.setTaskOwer("N/A");
			apnBUILDIWOSInfoBean1.setFlagNaN("1000002");
			list2.add(apnBUILDIWOSInfoBean2);
			
			mapList.put("6", list2);
		}
		
		if(null!=mapList.get("6")){
		List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			processInfoBeanList =mapList.get("6");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag1 =true;	
				}
			}
			if(!flag2) {
				ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				list1 = mapList.get("6");
				apnBUILDIWOSInfoBean.setActivityName("Network IWOS Suspension/Completion TASK");
				apnBUILDIWOSInfoBean.setStatus("N/A");
				apnBUILDIWOSInfoBean.setInformation("Comments:N/A");
				apnBUILDIWOSInfoBean.setTimeStamp("N/A");
				apnBUILDIWOSInfoBean.setTaskOwer("N/A");
				list1.add(apnBUILDIWOSInfoBean);
				mapList.put("6", list1);
			}if(!flag1) {
				ProcessInfoBeanDetails apnBUILDIWOSInfoBean = new ProcessInfoBeanDetails();
				List<ProcessInfoBeanDetails> list1= new ArrayList<ProcessInfoBeanDetails>();
				list1 = mapList.get("6");
				apnBUILDIWOSInfoBean.setActivityName("NetworkIWOS Creation Task");
				apnBUILDIWOSInfoBean.setStatus("N/A");
				apnBUILDIWOSInfoBean.setInformation("Comments:N/A");
				apnBUILDIWOSInfoBean.setTimeStamp("N/A");
				apnBUILDIWOSInfoBean.setTaskOwer("N/A");
				list1.add(apnBUILDIWOSInfoBean);
				mapList.put("6", list1);
			}
		}//TTU Process
		if(null==mapList.get("8")) {//TTU_Process
			List<ProcessInfoBeanDetails> list1  = new ArrayList<ProcessInfoBeanDetails>();
			ProcessInfoBeanDetails ttuProcessInfoBean1 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean1.setActivityName("Preflight Testing Task (OSD)");
			ttuProcessInfoBean1.setStatus("Is Pre-Flight Test Occurred ? \n"+"\tNA \n\t"+"Status: NA");
			ttuProcessInfoBean1.setInformation("Comments:N/A");
			ttuProcessInfoBean1.setTimeStamp("N/A");
			ttuProcessInfoBean1.setTaskOwer("N/A");
			ttuProcessInfoBean1.setFlagNaN("1000001");
			list1.add(ttuProcessInfoBean1);
			mapList.put("8", list1);
			
			List<ProcessInfoBeanDetails> list2= new ArrayList<ProcessInfoBeanDetails>();
			list2= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean2 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean2.setActivityName("TTU Applicability Task (OSD)");
			ttuProcessInfoBean2.setStatus("N/A");
			ttuProcessInfoBean2.setInformation("Comments:N/A");
			ttuProcessInfoBean2.setTimeStamp("N/A");
			ttuProcessInfoBean2.setTaskOwer("N/A");
			ttuProcessInfoBean2.setFlagNaN("1000002");
			list2.add(ttuProcessInfoBean2);
			mapList.put("8", list2);
			
			List<ProcessInfoBeanDetails> list3= new ArrayList<ProcessInfoBeanDetails>();
			list3= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean3 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean3.setActivityName("Schedule TTU Task");
			ttuProcessInfoBean3.setStatus("N/A");
			ttuProcessInfoBean3.setInformation("Comments:N/A");
			ttuProcessInfoBean3.setTimeStamp("N/A");
			ttuProcessInfoBean3.setTaskOwer("N/A");
			ttuProcessInfoBean3.setFlagNaN("1000003");
			list3.add(ttuProcessInfoBean3);
			mapList.put("8", list3);
			
			List<ProcessInfoBeanDetails> list4= new ArrayList<ProcessInfoBeanDetails>();
			list4= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean4 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean4.setActivityName("Perform TTU Task");
			ttuProcessInfoBean4.setStatus("N/A");
			ttuProcessInfoBean4.setInformation("Comments:N/A");
			ttuProcessInfoBean4.setTimeStamp("N/A");
			ttuProcessInfoBean4.setTaskOwer("N/A");
			ttuProcessInfoBean4.setFlagNaN("1000004");
			list4.add(ttuProcessInfoBean4);
			mapList.put("8", list4);
			
			List<ProcessInfoBeanDetails> list5= new ArrayList<ProcessInfoBeanDetails>();
			list5= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean5 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean5.setActivityName("TTU Result Task");
			ttuProcessInfoBean5.setStatus("N/A");
			ttuProcessInfoBean5.setInformation("Comments:N/A");
			ttuProcessInfoBean5.setTimeStamp("N/A");
			ttuProcessInfoBean5.setTaskOwer("N/A");
			ttuProcessInfoBean5.setFlagNaN("1000005");
			list5.add(ttuProcessInfoBean5);
			mapList.put("8", list5);
			
			List<ProcessInfoBeanDetails> list6= new ArrayList<ProcessInfoBeanDetails>();
			list6= mapList.get("8");
			ProcessInfoBeanDetails ttuProcessInfoBean6 = new ProcessInfoBeanDetails();
			ttuProcessInfoBean6.setActivityName("Re Schedule TTU Task");
			ttuProcessInfoBean6.setStatus("N/A");
			ttuProcessInfoBean6.setInformation("Comments:N/A");
			ttuProcessInfoBean6.setTimeStamp("N/A");
			ttuProcessInfoBean6.setTaskOwer("N/A");
			ttuProcessInfoBean6.setFlagNaN("1000006");
			list6.add(ttuProcessInfoBean6);
			mapList.put("8", list6);	
			
		}
		if(null!=mapList.get("8")) {
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			boolean flag1=false;
			boolean flag2=false;
			boolean flag3=false;
			boolean flag4=false;
			boolean flag5=false;
			boolean flag6=false;
			
			processInfoBeanList =mapList.get("8");
			for(ProcessInfoBeanDetails infoData: processInfoBeanList) {
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000001")) {
					flag1 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000002")) {
					flag2 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000003")) {
					flag3 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000004")) {
					flag4 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000005")) {
					flag5 =true;	
				}
				if(null!=infoData.getFlagNaN() && infoData.getFlagNaN().equalsIgnoreCase("1000006")) {
					flag6 =true;	
				}
			}
			if (!flag1) {
				List<ProcessInfoBeanDetails> list1 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean1 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean1.setActivityName("Preflight Testing Task (OSD)");
				ttuProcessInfoBean1.setStatus("Is Pre-Flight Test Occurred ? \n" + "\tNA \n\t" + "Status: NA");
				ttuProcessInfoBean1.setInformation("Comments:N/A");
				ttuProcessInfoBean1.setTimeStamp("N/A");
				ttuProcessInfoBean1.setTaskOwer("N/A");
				ttuProcessInfoBean1.setFlagNaN("1000001");
				list1.add(ttuProcessInfoBean1);
				mapList.put("8", list1);
			}
			if (!flag2) {
				List<ProcessInfoBeanDetails> list2 = new ArrayList<ProcessInfoBeanDetails>();
				list2 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean2 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean2.setActivityName("TTU Applicability Task (OSD)");
				ttuProcessInfoBean2.setStatus("N/A");
				ttuProcessInfoBean2.setInformation("Comments:N/A");
				ttuProcessInfoBean2.setTimeStamp("N/A");
				ttuProcessInfoBean2.setTaskOwer("N/A");
				ttuProcessInfoBean2.setFlagNaN("1000002");
				list2.add(ttuProcessInfoBean2);
				mapList.put("8", list2);
			}
			if (!flag3) {
				List<ProcessInfoBeanDetails> list3 = new ArrayList<ProcessInfoBeanDetails>();
				list3 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean3 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean3.setActivityName("Schedule TTU Task");
				ttuProcessInfoBean3.setStatus("N/A");
				ttuProcessInfoBean3.setInformation("Comments:N/A");
				ttuProcessInfoBean3.setTimeStamp("N/A");
				ttuProcessInfoBean3.setTaskOwer("N/A");
				ttuProcessInfoBean3.setFlagNaN("1000003");
				list3.add(ttuProcessInfoBean3);
				mapList.put("8", list3);
			}
			if (!flag4) {
				List<ProcessInfoBeanDetails> list4 = new ArrayList<ProcessInfoBeanDetails>();
				list4 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean4 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean4.setActivityName("Perform TTU Task");
				ttuProcessInfoBean4.setStatus("N/A");
				ttuProcessInfoBean4.setInformation("Comments:N/A");
				ttuProcessInfoBean4.setTimeStamp("N/A");
				ttuProcessInfoBean4.setTaskOwer("N/A");
				ttuProcessInfoBean4.setFlagNaN("1000004");
				list4.add(ttuProcessInfoBean4);
				mapList.put("8", list4);
			}
			if (!flag5) {
				List<ProcessInfoBeanDetails> list5 = new ArrayList<ProcessInfoBeanDetails>();
				list5 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean5 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean5.setActivityName("TTU Result Task");
				ttuProcessInfoBean5.setStatus("N/A");
				ttuProcessInfoBean5.setInformation("Comments:N/A");
				ttuProcessInfoBean5.setTimeStamp("N/A");
				ttuProcessInfoBean5.setTaskOwer("N/A");
				ttuProcessInfoBean5.setFlagNaN("1000005");
				list5.add(ttuProcessInfoBean5);
				mapList.put("8", list5);
			}
			/////////Flag 2//////////////// 
			if (!flag6) {
				List<ProcessInfoBeanDetails> list6 = new ArrayList<ProcessInfoBeanDetails>();
				list6 = mapList.get("8");
				ProcessInfoBeanDetails ttuProcessInfoBean6 = new ProcessInfoBeanDetails();
				ttuProcessInfoBean6.setActivityName("Re Schedule TTU Task");
				ttuProcessInfoBean6.setStatus("N/A");
				ttuProcessInfoBean6.setInformation("Comments:N/A");
				ttuProcessInfoBean6.setTimeStamp("N/A");
				ttuProcessInfoBean6.setTaskOwer("N/A");
				ttuProcessInfoBean6.setFlagNaN("1000006");
				list6.add(ttuProcessInfoBean6);
				mapList.put("8", list6);
			}
			/////////End Flag 6////////////////
		}
		if(null==mapList.get("9")) { //Change_Request_Completion
			List<ProcessInfoBeanDetails> processInfoBeanList  = new ArrayList<ProcessInfoBeanDetails>();
			crCommentsForCR.setActivityName("Change Request Completion Task");
			crCommentsForCR.setStatus("N/A");
			crCommentsForCR.setInformation("Comments:N/A");
			crCommentsForCR.setTimeStamp("N/A");
			crCommentsForCR.setTaskOwer("N/A");
			processInfoBeanList.add(crCommentsForCR);
			mapList.put("9",processInfoBeanList);
		}
		logger.info("Exsiting method populateDefaultCRTable" , this);
		return mapList;
		
	}
	
	
	private AmpRequestInfoBean setAmpRequestInfoInBO(Long orderId,AmpRequestInfoBean ampRequestInfoBean) {
		logger.debug("Starting method setAmpRequestInfoInBO()");
		HashMap<String,List<AmpRequestBO>> ampHashMap =null;
		try {
			ampHashMap =setMiscAmpRequestInfo(orderId) ;
			} catch (CometDataException e) {
				logger.error("[OrderID : " + (orderId == null ? "" : orderId)+ "] " + e.getStackTrace());
			}
		if(null!=ampHashMap) {
			ampRequestInfoBean =getAmpRequestFormBean(ampHashMap);
		}
		logger.debug("Exsiting method setAmpRequestInfoInBO()");
		return ampRequestInfoBean;
	}
	
	private AmpRequestInfoBean getAmpRequestFormBean(HashMap<String,List<AmpRequestBO>> ampHashMap) {
		logger.debug("Starting method getAmpRequestFormBean()");	
		AmpRequestInfoBean ampRequestInfoBean = new AmpRequestInfoBean();
		ampRequestInfoBean.setAmpHashMap(ampHashMap);		
		logger.debug("end method getAmpRequestFormBean()");
		return ampRequestInfoBean;
	}
	
	public HashMap<String,List<AmpRequestBO>> setMiscAmpRequestInfo(Long orderId)throws CometDataException {
		logger.info("[OrderID : "+(orderId == null ? "" : orderId)+"] "+"Starting method setMiscAmpRequestInfo");
		AmpRequestBO ampRequestBO = null;
		HashMap<String,List<AmpRequestBO>> mapList = new HashMap<String,List<AmpRequestBO>>();
		try {
			if (null != orderId) {
				StringBuilder query = getAmpRequestQuery(orderId);
				Query sqlQuery = em.createNativeQuery(query.toString());
				@SuppressWarnings("unchecked")
				List<Object> result  = sqlQuery.getResultList();

				Object[] results = null;
				if (result != null && result.size() > 0) {
					Iterator<Object> itr = result.iterator();
					while (itr.hasNext()) {
						ampRequestBO = new AmpRequestBO();
						results = (Object[]) itr.next();
						if (null != results[0]) {
							ampRequestBO.setRequestId((String) results[0]);
						}
						if (null != results[1]) {
							if (results[1].equals("IN_PROGRESS")) {
								results[1] = "IN PROGRESS";
							} else if (results[1].equals("SYNC_FETCHED")) {
								results[1] = "SYNC FETCHED";
							} else if (results[1].equals("SYNC_READY")) {
								results[1] = "SYNC READY";
							}
							if (results[1].equals("IN_APPROVAL")) {
								results[1] = "IN APPROVAL";
							}
							ampRequestBO.setActivityDetails((String) results[1]);
						}
						if (null != results[2]) {
							ampRequestBO.setActivitySubDateTime((Date) results[2]);
						}

						if (results[1].equals("CANCELLED")
								|| results[1].equals("REJECTED")) {
							ampRequestBO.setComments((String) results[3]);
						}
						List<AmpRequestBO> ampList = null;;
						if(mapList.containsKey(ampRequestBO.getRequestId())) {
							ampList= mapList.get(ampRequestBO.getRequestId());
							if(!CollectionUtils.isEmpty(ampList)) {
								ampList.add(ampRequestBO);
							}
						}else {
							ampList = new ArrayList<AmpRequestBO>();
							ampList.add(ampRequestBO);
						}
						mapList.put(ampRequestBO.getRequestId(),ampList);						
					}
				}
			}
		}catch (Exception exception) {
			exception.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + exception.getStackTrace());
			logger.error("[OrderID : " + (orderId== null ? "" : orderId)
					+ "] " + "Exception in getOrderAmpRequest" + exception);
			throw new CometDataException("Error",
					"Get Order Amp Request failed", exception);
		}	
		logger.info("[OrderID : "+(orderId == null ? "" : orderId)+"] "+"Exsiting method setMiscAmpRequestInfo");
		return mapList;
		
	}
	
	private StringBuilder getAmpRequestQuery(Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Starting method getAmpRequestQuery : ", this);
		String sqlQuery1 = GET_AMP_REQ_INFO_BY_ORDER_QUERY1+orderId+" ";
		String sqlQuery2 = GET_AMP_REQ_INFO_BY_ORDER_QUERY2;
		StringBuilder query = new StringBuilder(sqlQuery1);
		query.append(sqlQuery2);
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Existing method getAmpRequestQuery : ", this);
				return query;
	}
	

	private AccaRequestInfoBean setAccaRequestInfoInBO(Long orderId,AccaRequestInfoBean accaRequestInfoBean) {
		logger.debug("Starting method setAccRequestInfoInBO()");
		HashMap<String,List<AccaRequestBO>> mapList =null;
		try {
			mapList =setMiscAccaRequestInfo(orderId) ;
			} catch (CometDataException e) {
				logger.error("[OrderID : "+(orderId == null ? "" : orderId)+"] "+"Exception on setMiscAccaRequestInfo");
			}
		if(null!=mapList) {
			accaRequestInfoBean =getAccaRequestFormBean(mapList);
		}
		logger.debug("Exsiting method setAccRequestInfoInBO()");
		return accaRequestInfoBean;
	}
	
	public HashMap<String,List<AccaRequestBO>> setMiscAccaRequestInfo(Long orderId)throws CometDataException {
		logger.info("[OrderID : "+(orderId == null ? "" : orderId)+"] "+"Starting method setMiscAccaRequestInfo");
		AccaRequestBO accaRequestBO = null;
		HashMap<String,List<AccaRequestBO>> mapList = new HashMap<String,List<AccaRequestBO>>();
		try {
			if (null != orderId) {
				StringBuilder query = getAccaRequestQuery(orderId);
				Query sqlQuery = em.createNativeQuery(query.toString());
				@SuppressWarnings("unchecked")
				List<Object> result  = sqlQuery.getResultList();
			
				Object[] results = null;
				if (result != null && result.size() > 0) {
					Iterator<Object> itr = result.iterator();
					while (itr.hasNext()) {
						accaRequestBO = new AccaRequestBO();
						results = (Object[]) itr.next();
						if (null != results[0]) {
							accaRequestBO.setRequestId((String) results[0]);
						}
						if (null != results[1]) {
							if (results[1].equals("IN_PROGRESS")) {
								results[1] = "IN PROGRESS";
							} else if (results[1].equals("SYNC_FETCHED")) {
								results[1] = "SYNC FETCHED";
							} else if (results[1].equals("SYNC_READY")) {
								results[1] = "SYNC READY";
							}
							if (results[1].equals("IN_APPROVAL")) {
								results[1] = "IN APPROVAL";
							}
							accaRequestBO.setActivityDetails((String) results[1]);
							}
						if (null != results[2]) {
							accaRequestBO.setActivitySubDateTime((Date) results[2]);
						}

						if (results[1].equals("CANCELLED")
								|| results[1].equals("REJECTED")) {
							accaRequestBO.setComments((String) results[3]);
						}
						List<AccaRequestBO> accaList = null;
						if(mapList.containsKey(accaRequestBO.getRequestId())) {
							accaList= mapList.get(accaRequestBO.getRequestId());
							if(!CollectionUtils.isEmpty(accaList)) {
								accaList.add(accaRequestBO);
							}
						}else {
							accaList = new ArrayList<AccaRequestBO>();
							accaList.add(accaRequestBO);
						}
						mapList.put(accaRequestBO.getRequestId(),accaList);						
					}
				}
			}
		}catch (Exception exception) {
			exception.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + exception.getStackTrace());
			logger.error("[OrderID : " + (orderId== null ? "" : orderId)
					+ "] " + "Exception in getOrderAccaRequest" + exception);
			throw new CometDataException("Error",
					"Get Order acca Request failed", exception);
		}	
		logger.info("[OrderID : "+(orderId == null ? "" : orderId)+"] "+"Exsiting method setMiscAccaRequestInfo");
		return mapList;
		
	}
	
	private AccaRequestInfoBean getAccaRequestFormBean(HashMap<String,List<AccaRequestBO>> accaRequestBOs) {
		logger.debug("Starting method getAccaRequestFormBean()");	
		AccaRequestInfoBean accaRequestInfoBean = new AccaRequestInfoBean();
		accaRequestInfoBean.setAccAHashMap(accaRequestBOs);	
		logger.debug("end method getAccaRequestFormBean()");
		return accaRequestInfoBean;
	}
	
	private StringBuilder getAccaRequestQuery(Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Starting method getAmpRequestQuery : ", this);
		String sqlQuery1 = GET_ACCA_REQ_INFO1+orderId+" ";
		String sqlQuery2 = GET_ACCA_REQ_INFO2;
		StringBuilder query = new StringBuilder(sqlQuery1);
		query.append(sqlQuery2);
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Existing method getAmpRequestQuery : ", this);
				return query;
	}
	
	public boolean saveMiscDataCenterDetails(DataCenterInfoBean dataCenterInfoBean ,Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Starting method saveMiscDataCenterDetails : ", this);
		if(null!=dataCenterInfoBean) {
			OrderDataCenter orderDataCenter = new OrderDataCenter();
			orderDataCenter = orderDataCenterRepository.findById_OrderIdAndId_DataCenterId(orderId,Long.parseLong(dataCenterInfoBean.getDataCenter()));
			if (null!=orderDataCenter) {
				if(null!=dataCenterInfoBean.getActiveInterface()) {
					orderDataCenter.setActiveInterface(dataCenterInfoBean.getActiveInterface());
				}else {
					orderDataCenter.setActiveInterface(null);
				}
				if(null!=dataCenterInfoBean.getActiveRouter()) {
					orderDataCenter.setActiveRouter(dataCenterInfoBean.getActiveRouter());
				}else {
					orderDataCenter.setActiveRouter(null);
				}
				if(null!=dataCenterInfoBean.getPrimaryDcRouter()) {
					orderDataCenter.setPrDcRouterFailoverConfig(dataCenterInfoBean.getPrimaryDcRouter());
				}
				else {
					orderDataCenter.setPrDcRouterFailoverConfig(null);
				}
				orderDataCenterRepository.save(orderDataCenter);
				return true;
			}else {
				logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Not able to Update Misc Data MISC record  : ", this);	
			}
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Existing method saveMiscDataCenterDetails : ", this);
		return false;
	}
	
	public boolean saveMiscOtherInfo(OtherInfoBean otherInfoBean ,Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Starting method saveMiscOtherInfo : ", this);
		boolean updateMiscOtherStatus =false;
		try {
			BackhaulConfig backhaulConfig = orderDAO.getBackHaulConfig(orderId);
		    if(null!=backhaulConfig) {
		    	if(null!=otherInfoBean) {
					if(null!=otherInfoBean.getApnInProductionDate()) {
						backhaulConfig.setApnInProductionDate(otherInfoBean.getApnInProductionDate());	
					}else {
						backhaulConfig.setApnInProductionDate(null);
					}
					if(null!=otherInfoBean.getExceptionApprovalDate()) {
						backhaulConfig.setExcpApproverDate(otherInfoBean.getExceptionApprovalDate());
					}else {
						backhaulConfig.setExcpApproverDate(null);
					}
					if(null!=otherInfoBean.getExceptionRequestApprover()) {
						backhaulConfig.setExcpRequestApprover(otherInfoBean.getExceptionRequestApprover());
					}else {
						backhaulConfig.setExcpRequestApprover(null);
					}
					if(null!=otherInfoBean.getExceptionApprovalNumber()) {
						backhaulConfig.setExcpApprovalNumber(otherInfoBean.getExceptionApprovalNumber());
					}else {
						backhaulConfig.setExcpApprovalNumber(null);
					}
					if(null!=otherInfoBean.getIWOS()) {
						backhaulConfig.setiWOS(otherInfoBean.getIWOS());
					}else {
						backhaulConfig.setiWOS(null);
					}
					if(null!=otherInfoBean.getIwosNotes()) {
						backhaulConfig.setIwosNotes(otherInfoBean.getIwosNotes());
					}else {
						backhaulConfig.setIwosNotes(null);
					}
					if(null!=otherInfoBean.getNotes()) {
						backhaulConfig.setNotes(otherInfoBean.getNotes());
					}else {
						backhaulConfig.setNotes(null);
					}
					if(null!=otherInfoBean.getWhiteListOfBlackList()) {
						backhaulConfig.setWhiteListOfBlackList(otherInfoBean.getWhiteListOfBlackList());
					}else {
						backhaulConfig.setWhiteListOfBlackList(null);
					}
					backHaulConfgurationRespository.save(backhaulConfig);
					updateMiscOtherStatus =true;
					return updateMiscOtherStatus;
				}
		    }else{
		    	logger.debug("order Id [" + orderId + "] :: Backhaul Configuration table inserted first time", this);
		    	BackhaulConfig backhaulConfig1 = new BackhaulConfig();
		    	Orders orders = orderRepository.findByOrderId(orderId);
		    	backhaulConfig1.setOrders(orders);
		    	backhaulConfig1.setApnInProductionDate(otherInfoBean.getApnInProductionDate());	
		    	backhaulConfig1.setExcpRequestApprover(otherInfoBean.getExceptionRequestApprover());
		    	backhaulConfig1.setExcpApprovalNumber(otherInfoBean.getExceptionApprovalNumber());
		    	backhaulConfig1.setIwosNotes(otherInfoBean.getIwosNotes());
		    	backhaulConfig1.setNotes(otherInfoBean.getNotes());
		    	backHaulConfgurationRespository.save(backhaulConfig1);
				updateMiscOtherStatus =true;
				return updateMiscOtherStatus;
		    }
			
		} catch (CometDataException e) {
			logger.error("order Id [" + orderId + "] :: Backhaul Configuration  info is null", this);
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)+ "] " + e.getStackTrace());
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Existing method saveMiscOtherInfo : ", this);
		return false;
	}
	
	public boolean saveLTESweepValue(RecoveryInfoBean recoveryInfoBean , Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Starting method saveLTESweepValue : ", this);
		Orders orders = orderDAO.findByOrderId(orderId);
		if(null!=orders) {
			if(null!=recoveryInfoBean.getLteSweep()) {
				orders.setLteSweep(recoveryInfoBean.getLteSweep());
			}
			orderRepository.save(orders);
			return true;
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+"Existing method saveLTESweepValue : ", this);
		return false;
	}	
	
}
