package com.att.comet;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.healthcheck.helper.HealthCheckHelper;
import com.att.comet.user.exception.UserException;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class HealthCheckController {
	Logger logger = LoggerFactory.getLogger(HealthCheckController.class);

	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;
	@Autowired
	HealthCheckHelper healthCheckHelper;
	
	@GetMapping(value ={ "/healthCheckStatus/{test}", "/healthCheckStatus" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Health Check Status", notes = "Health Check Status")
	public String getHealthCheckStatus(@PathVariable String test)
			throws RecordNotFoundException, UserException, UnsupportedEncodingException {
		logger.info("Starting method getHealthCheckStatus : ", this);
		String healthCheckStatus = null;
		if(test.equals("test")) {
			healthCheckStatus = Status.SUCCESS+"" ;
			}else {
			healthCheckStatus = Status.SYSTEM_ERROR+"" ;
		}
		logger.info("Exiting method getHealthCheckStatus : ", this);
		return healthCheckStatus;
	}
	
	@GetMapping(value ={ "/dataMigrationMainProcess", "/dataMigrationMainProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration Process", notes = "Data Migration Process")
	public void dataMigrationMainProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException {
		logger.info("Starting method Data Migration Process : ", this);
		//long orderList[] = new long[] {117132};
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.getOrdersMainWorkFlow(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method Data Migration Process : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationOAApprovalProcess", "/dataMigrationOAApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration  OA Approval Process", notes = "Data Migration OA Approval Process")
	public void dataMigrationOAApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationOAApprovalProcess Process : ", this);
		//long orderList[] = new long[] {117132};
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFLowForOAApproval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationOAApprovalProcess Process : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationOMApprovalProcess", "/dataMigrationOMApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration  OM Approval Process", notes = "Data Migration OM Approval Process")
	public void dataMigrationOMApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationOMApprovalProcess Process : ", this);
		//long orderList[] = new long[] {117132};
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowForOMApproval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationOMApprovalProcess Process : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationIWOS_Network_CreationApprovalProcess", "/dataMigrationIWOS_Network_CreationApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration  IWOS Approval Process", notes = "Data Migration IWOS Approval Process")
	public void dataMigrationIWOSApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationIWOS_Network_CreationApprovalProcess Process : ", this);
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowForIWOS_Network_Creation_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationIWOS_Network_CreationApprovalProcess Process : ", this);
		
	}

	
	@GetMapping(value ={ "/dataMigrationITOPS_CreationApprovalProcess", "/dataMigrationITOS_CredataMigrationITOPS_CreationApprovalProcessationApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration  ITOPS Approval Process", notes = "Data Migration ITOPS Approval Process")
	public void dataMigrationITOS_CreationApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationITOS_CreationApprovalProcess Process : ", this);
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowForITOPS_Creation_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationITOS_CreationApprovalProcess Process : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationAPN_HLR_CreationApprovalProcess", "/dataMigrationAPN_HLR_CreationApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration APN_HLR_Creation Approval Process", notes = "Data Migration APN_HLR_Creation Approval Process")
	public void dataMigrationAPN_HLR_CreationApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationAPN_HLR_CreationApprovalProcess Process : ", this);
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowForAPN_HLR_Creation_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationAPN_HLR_CreationApprovalProcess Process : ", this);
		
	}
	
	
	@GetMapping(value ={ "/dataMigrationNI_order_update_Creation_ApprovalProcess", "/dataMigrationNI_order_update_Creation_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration NI_order_update_Creation Approval Process", notes = "Data Migration NI_order_update_Creation Approval Process")
	public void dataMigrationNI_order_update_Creation_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationNI_order_update_Creation_ApprovalProcess Process : ", this);
		long orderList[] = new long[] {115903};
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowForNI_order_update_Creation_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationNI_order_update_Creation_ApprovalProcess Process : ", this);
		
	}

	
	@GetMapping(value ={ "/dataMigrationBilling_task_Creation_ApprovalProcess", "/dataMigrationBilling_task_Creation_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration NI_order_update_Creation Approval Process", notes = "Data Migration NI_order_update_Creation Approval Process")
	public void dataMigrationBilling_task_Creation_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationBilling_task_Creation_ApprovalProcess Process : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowBilling_task_Creation_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationBilling_task_Creation_ApprovalProcess Process : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationIWOS_network_compeletion_ApprovalProcess", "/dataMigrationIWOS_network_compeletion_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration IWOS_network_compeletion Approval Process", notes = "Data Migration IWOS_network_compeletion Approval Process")
	public void dataMigrationIWOS_network_compeletion_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method IWOS_network_compeletion_ApprovalProcess Process : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowIWOS_network_compeletion_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method IWOS_network_compeletion Process : ", this);
		
	}
	
		
	@GetMapping(value ={ "/dataMigrationAPN_HLR_Completion_ApprovalProcess", "/dataMigrationAPN_HLR_Completion_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration APN_HLR_Completion Approval Process", notes = "Data Migration APN_HLR_Completion Approval Process")
	public void dataMigrationAPN_HLR_Completion_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException,RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method APN_HLR_Completion Process : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowAPN_HLR_Completion_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationAPN_HLR_Completion_ApprovalProcesss : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationTTU_Preflight_Testing_ApprovalProcess", "/dataMigrationTTU_Preflight_Testing_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Preflight_Testing_ApprovalProcess  Approval Process", notes = "Data MigrationdataMigrationTTU_Preflight_Testing_ApprovalProcess")
	public void dataMigrationTTU_Preflight_Testing_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationTTU_Preflight_Testing_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Preflight_Testing_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Preflight_Testing_ApprovalProcess : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationTTU_Applicability_ApprovalProcess", "/dataMigrationTTU_Applicability_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Applicability_ApprovalProcess  Approval Process", notes = "Data dataMigrationTTU_Applicability_ApprovalProcess")
	public void dataMigrationTTU_Applicability_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationTTU_Applicability_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Applicability_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Applicability_ApprovalProcess : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationTTU_Schedule_ApprovalProcess", "/dataMigrationTTU_Schedule_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Schedule_ApprovalProcess", notes = "Data dataMigrationTTU_Schedule_ApprovalProcess")
	public void dataMigrationTTU_Schedule_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationTTU_Schedule_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Schedule_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Schedule_ApprovalProcess : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationTTU_Perform_Status_ApprovalProcess", "/dataMigrationTTU_Perform_Status_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Perform_Status_ApprovalProcess", notes = "Data dataMigrationTTU_Perform_Status_ApprovalProcess")
	public void dataMigrationTTU_Perform_Status_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationTTU_Perform_Status_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Perform_Status_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Perform_Status_ApprovalProcess : ", this);
		
	}
	
	@GetMapping(value ={ "/dataMigrationTTU_Result_ApprovalProcess", "/dataMigrationTTU_Result_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Result_ApprovalProcess", notes = "Data dataMigrationTTU_Result_ApprovalProcess")
	public void dataMigrationTTU_Result_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException {
		logger.info("Starting method dataMigrationTTU_Result_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Result_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Result_ApprovalProcess : ", this);
		
	}
	
	
	@GetMapping(value ={ "/dataMigrationTTU_Reschedule_ApprovalProcess", "/dataMigrationTTU_Reschedule_ApprovalProcess" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Data Migration dataMigrationTTU_Reschedule_ApprovalProcess", notes = "Data dataMigrationTTU_Reschedule_ApprovalProcess")
	public void dataMigrationTTU_Reschedule_ApprovalProcess()
			throws RecordNotFoundException, UserException, UnsupportedEncodingException, RestClientException, URISyntaxException, ParseException {
		logger.info("Starting method dataMigrationTTU_Reschedule_ApprovalProcess : ", this);
		List<Long> orderList = new ArrayList<Long>();
		for(Long orderId :orderList) {
			try {
				healthCheckHelper.processWorkFlowTTU_Reschedule_Approval(orderId);
			} catch (CometDataException e) {
				logger.debug("EXCEPTION Occured for ORDERID::"+orderId, e);
			} catch (CometServiceException e) {
				logger.debug("SERVICE EXCEPTION Occured for ORDERID::"+orderId, e);
			}	
		}
		logger.info("Exiting method dataMigrationTTU_Reschedule_ApprovalProcess : ", this);
		
	}
	///TTU
	/*new ,CO,CR,
	1022 OSD : TTU - Preflight Testing --bussiness step Id =3025l --done
	1023 OSD : TTU - Applicability - bussiness step Id-3026L--done
    1024 OSD : TTU - Schedule - bussiness step Id-3132L--done
    1025 OSD : TTU Perform Status- bussiness step Id-3028lL--done
    1026 OSD : TTU Result-- bussiness step Id-3029L--done
    1027 OSD : TTU - Reschedule-- bussiness step Id-3141L*/
}
