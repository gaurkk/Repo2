package com.att.comet.common.util;

import com.att.comet.common.bean.TabBean;
import com.att.comet.common.constant.TypeOrderForm;

/**
 * OrderTabFactory provides the tabs on the basis of the tab type.
 */
public class OrderTabFactory {

	public static TabBean getTab(TypeOrderForm tabType) {

		switch (tabType) {

		case ORDER_INITIATE:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Initiate");

		case ORDER_APN:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "APN");

		case ORDER_BH:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "BH");

		case ORDER_ACCOUNT:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Account");

		case ORDER_CONTACT:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Contact");
		
		case ORDER_FIREWALL:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Firewall");
			
		case ORDER_MPLS:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "MPLS");

		case ORDER_IVPN:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "I-VPN");

		case ORDER_CRD:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "CRD");
			
		case ORDER_BILLING:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Billing");	

		case ORDER_MISC:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Misc");

		case ORDER_SUMMARY:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Summary");

		case ORDER_DAPN:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Dedicated-APN");

		case ORDER_HISTORY:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "History");
		case ORDER_TASK:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(), "Task");	
		case ORDER_LOGS:
			return new TabBean(tabType.getId(), tabType.getTab()
					.getDisplayOrder(),"Logs");			
		default:
			return null;

		}
	}
}