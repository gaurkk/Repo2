package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for BackhaulConfig.Mapped with BACKHAUL_CONFIG table in the
 * database.
 */
@Entity
@Table(name = "BACKHAUL_CONFIG")
public class BackhaulConfig implements Serializable {

	private static final long serialVersionUID = -4497276051699128807L;

	private Long orderId;
	private Orders orders;
	private String excpRequestApprover;
	private Date excpApproverDate;
	private String excpApprovalNumber;
	private String notes;
	private String iwosNotes;
	private Date apnInProductionDate;
	private String whiteListOfBlackList;
	private String iWOS;

	/**
	 * Getter method for the orderId. ORDER_ID mapped to ORDER_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "orders"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for the orders.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for the excpRequestApprover. EXCP_REQUEST_APPROVER mapped to
	 * EXCP_REQUEST_APPROVER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXCP_REQUEST_APPROVER", length = 100)
	public String getExcpRequestApprover() {
		return this.excpRequestApprover;
	}

	/**
	 * @param excpRequestApprover to excpRequestApprover set.
	 */
	public void setExcpRequestApprover(String excpRequestApprover) {
		this.excpRequestApprover = excpRequestApprover;
	}

	/**
	 * Getter method for excpApproverDate. EXCP_APPROVER_DATE mapped to
	 * EXCP_APPROVER_DATE in the database.
	 * 
	 * @return Date
	 */
	@Column(name = "EXCP_APPROVER_DATE")
	public Date getExcpApproverDate() {
		return this.excpApproverDate;
	}

	/**
	 * @param excpApproverDate to excpApproverDate set.
	 */
	public void setExcpApproverDate(Date excpApproverDate) {
		this.excpApproverDate = excpApproverDate;
	}

	/**
	 * Getter method for excpApprovalNumber. EXCP_APPROVAL_NUMBER mapped to
	 * EXCP_APPROVAL_NUMBER in the database.
	 * 
	 * @return String
	 */
	@Column(name = "EXCP_APPROVAL_NUMBER", length = 100)
	public String getExcpApprovalNumber() {
		return this.excpApprovalNumber;
	}

	/**
	 * @param excpApprovalNumber to excpApprovalNumber set.
	 */
	public void setExcpApprovalNumber(String excpApprovalNumber) {
		this.excpApprovalNumber = excpApprovalNumber;
	}

	/**
	 * Getter method for notes. NOTES mapped to NOTES in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "NOTES")
	public String getNotes() {
		return notes;
	}

	/**
	 * @param notes to notes set.
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * @return the iwosNotes
	 */
	@Column(name = "IWOS_NOTES")
	public String getIwosNotes() {
		return iwosNotes;
	}

	/**
	 * @param iwosNotes the iwosNotes to set
	 */
	public void setIwosNotes(String iwosNotes) {
		this.iwosNotes = iwosNotes;
	}

	/**
	 * This will map apnInProductionDate to db APN_INPRODUCTION_DATE column
	 * 
	 * @return
	 */
	@Column(name = "APN_INPRODUCTION_DATE")
	public Date getApnInProductionDate() {
		return apnInProductionDate;
	}

	/**
	 * This is used to set APN in production date from orderMisc tab
	 * 
	 * @param apnInProductionDate
	 */
	public void setApnInProductionDate(Date apnInProductionDate) {
		this.apnInProductionDate = apnInProductionDate;
	}

	/**
	 * @return the whiteListOfBlackList
	 */
	@Column(name = "WHITELIST_OF_BLACKLIST")
	public String getWhiteListOfBlackList() {
		return whiteListOfBlackList;
	}

	/**
	 * @param whiteListOfBlackList the whiteListOfBlackList to set
	 */
	public void setWhiteListOfBlackList(String whiteListOfBlackList) {
		this.whiteListOfBlackList = whiteListOfBlackList;
	}

	/**
	 * @return the iWOS
	 */
	@Column(name = "IWOS")
	public String getiWOS() {
		return iWOS;
	}

	/**
	 * @param iWOS the iWOS to set
	 */
	public void setiWOS(String iWOS) {
		this.iWOS = iWOS;
	}
}