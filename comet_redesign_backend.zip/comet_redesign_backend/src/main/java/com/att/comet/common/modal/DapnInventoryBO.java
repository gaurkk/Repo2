package com.att.comet.common.modal;

import com.att.comet.manage.modal.InventoryBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = true)

public class DapnInventoryBO extends CometGenericBO implements InventoryBO {

	private static final long serialVersionUID = 9126460505095235433L;
	private String dapnId;
	private String apnType;
	private Long apnSize;
	private String apnName;
	private String pdpName;
	private Long udPDPId;
	private String mobileIP;
	private String dataCenter;
	private String pDNSAddress;
	private String sDNSAddress;
	private String dnsNotes;
	private String ampInfo;
	private String createdOn;
	private String createdBy;
	private String updatedOn;
	private String updatedBy;
	private Long dapnStatus;
	private String batchId;
	private Long pdpId;
	private String sourceOfIpAddress;
	private String dnsServerIp;
	private String bhiInstanceType;
	private Character mToM;
	private Character mT;
	private String id;
	private String pcrf;
	private String newDapn;
	private String assignAvailableFlag;
	private String dataCenterName;
	private String inventoryStatus;
	private Long orderId;
}
