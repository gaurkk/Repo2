package com.att.comet.dao;

/**
 * Holds constants for binding sql query.
 */
public class BindingConstants {
	/**
	 * Used in native sql for replacement of attuid with actual value.
	 */
	public final static String ATT_UID_BC = "attuid";

	/**
	 * Used in native sql for replacement of data center id with actual value.
	 */
	public final static String DATA_CENTER_ID_BC = "dataCenterId";

	/**
	 * Used in native sql for replacement of data center id with actual value.
	 */
	public final static String BACKHAUL_ID_BC = "backhaulId";

	/**
	 * Used in native sql for replacement of scenario with actual value.
	 */
	public final static String SCENARIO = "scenario";

	/**
	 * Used in native sql for replacement of backhaul type id with actual value.
	 */
	public final static String BACKHAUL_TYPE_ID_BC = "backhaulTypeId";

	/**
	 * Used in native sql for replacement of number of backhauls with actual value.
	 */
	public final static String NUM_BACKHAULS_BC = "numBackhauls";

	/**
	 * Used in native sql for replacement of roleId with actual value.
	 */
	public final static String ROLE_ID_BC = "roleId";

	/**
	 * Used in native sql for replacement of orderId with actual value.
	 */
	public final static String ORDER_ID_BC = "orderId";

	/**
	 * Used in native sql for replacement of orderProcess with actual value.
	 */
	public final static String ORDER_PROCESS = "orderProcess";

	/**
	 * Used in native sql for replacement of subProcess with actual value.
	 */
	public final static String SUB_PROCESS = "subProcess";

	/**
	 * Used in native sql for replacement of ssId with actual value.
	 */
	public final static String SOLUTION_SUMMARY_ID = "ssId";

	/**
	 * Used in native sql for replacement of eventName with actual value.
	 */
	public final static String EVENT_NAME_BC = "eventName";

	/**
	 * Used in native sql for replacement of processIds with actual value.
	 */
	public final static String PROCESS_IDS = "processIds";

	/**
	 * Used in native sql for replacement of crdId with actual value.
	 */
	public final static String CRD_ID_BC = "crdId";

	/**
	 * Used in native sql for replacement of orderStatusId with actual value.
	 */
	public final static String ORDER_STATUS_ID_BC = "orderStatusId";

	/**
	 * Used in native sql for replacement of apnId with actual value.
	 */
	public final static String APN_ID = "apnId";

	/**
	 * Used in native sql for replacement of masterAccountName with actual value.
	 */
	public final static String MASTER_ACCOUNT_NAME_BC = "masterAccountName";

	/**
	 * Used in native sql for replacement of masterAccountName with actual value.
	 */
	public final static String PDP_PACKAGE_NAME_BC = "pdpPackageName";

	/**
	 * Used in native sql for replacement of subAccountName with actual value.
	 */
	public final static String SUB_ACCOUNT_NAME_BC = "subAccountName";

	/**
	 * Used in native sql for replacement of ubcid with actual value.
	 */
	public final static String UBCID_BC = "ubcid";

	/**
	 * Used in native sql for replacement of bcid with actual value.
	 */
	public final static String BCID_BC = "bcid";

	/**
	 * Used in native sql for replacement of companyOwner with actual value.
	 */
	public final static String COMPANY_OWNER_BC = "companyOwner";

	/**
	 * Used in native sql for replacement of accountCreatedBy with actual value.
	 */
	public final static String ACCOUNT_CREATED_BY_BC = "accountCreatedBy";

	/**
	 * Used in native sql for replacement of CcreationDateFrom with actual value.
	 */
	public final static String CREATION_DATE_FROM_BC = "CreationDateFrom";

	/**
	 * Used in native sql for replacement of creationDateTo with actual value.
	 */
	public final static String CREATION_DATE_TO_BC = "creationDateTo";

	/**
	 * Used in native sql for replacement of federalTaXId with actual value.
	 */
	public final static String FEDERAL_TAX_ID_BC = "federalTaXId";

	/**
	 * Used in native sql for replacement of companyName with actual value.
	 */
	public final static String COMPANY_NAME_BC = "companyName";

	/**
	 * Used in native sql for replacement of accountType with actual value.
	 */
	public final static String ACCOUNT_TYPE_BC = "accountType";

	/**
	 * Used in native sql for replacement of accountClass with actual value.
	 */
	public final static String ACCOUNT_CLASS_BC = "accountClass";

	/**
	 * Used in native sql for replacement of cipn with actual value.
	 */
	public final static String CIPN_BC = "cipn";

	/**
	 * Used in native sql for replacement of internalProductAccountName with actual
	 * value.
	 */
	public final static String INTERNAL_PRODUCT_ACCOUNT_NAME_BC = "internalProductAccountName";

	/**
	 * Used in native sql for replacement of apn with actual value.
	 */
	public final static String APN_BC = "apn";

	/**
	 * Used in native sql for replacement of banID with actual value.
	 */
	public final static String BAN_ID_BC = "banID";

	/**
	 * Used in native sql for replacement of createdBy with actual value.
	 */
	public final static String CREATED_BY_BC = "createdBy";

	/**
	 * Used in native sql for replacement of FanID with actual value.
	 */
	public final static String FAN_ID_BC = "fanId";

	/**
	 * Used in native sql for replacement of OrderStatus with actual value.
	 */
	public final static String ORDER_STATUS_BC = "orderStatus";

	/**
	 * Used in native sql for replacement of OrderType with actual value.
	 */
	public final static String ORDER_TYPE_BC = "orderType";

	/**
	 * Used in native sql for replacement of pdpName with actual value.
	 */
	public final static String PDP_NAME_BC = "pdpName";

	/**
	 * Used in native sql for replacement of pdpName with actual value.
	 */
	public final static String LAST_ACTION_DATE_BC = "lastActionDate";

	/**
	 * Used in native sql for replacement of category id with actual value.
	 */
	public final static String CATEGORY_ID_BC = "categoryId";
	/**
	 * Used in native sql for replacement of DataCenterId with actual value.
	 */
	public final static String CATEGORY_VALUE_BC = "categoryValue";

	/**
	 * Used in native sql for replacement of lteEnabled with actual value.
	 */
	// public final static String LTE_ENABLED_BC = "lteEnabled";

	/**
	 * Used in native sql for replacement of apnName with actual value.
	 */
	public final static String APN_NAME_BC = "apnName";

	/**
	 * Used in native sql for replacement of vrfName with actual value.
	 */
	public final static String VRF_NAME_BC = "vrfName";

	/**
	 * Used in native sql for replacement of workStepId with actual value.
	 */
	public final static String WORK_STEP_ID = "workStepId";

	/**
	 * Used in native sql for replacement of businessStepId with actual value.
	 */
	public final static String BUSINESS_STEP_ID = "businessStepId";

	/**
	 * Used in native sql for replacement of startDate with actual value.
	 */
	public final static String START_DATE_BC = "startDate";

	/**
	 * Used in native sql for replacement of endDate with actual value.
	 */
	public final static String END_DATE_BC = "endDate";

	/**
	 * Used in native sql for replacement of apnSelection with actual value.
	 */
	public final static String APN_SELECTION_BC = "apnSelection";

	/**
	 * Used in native sql for duplication check in Admin Config
	 */
	public final static String ADMIN_CATEGORY_ID = "categoryID";
	/**
	 * Used in native sql for duplication check in Admin Config
	 */
	public final static String CATEGORY_VALUE = "value";
	/**
	 * Used in native sql for duplication check in Admin Config
	 */
	public final static String CATEGORY_DESCRIPTION = "description";
	/**
	 * Used in native sql for duplication check in Admin Config in edit
	 */
	public final static String ADMIN_CONFIG = "adminConfigId";

	/**
	 * Used in native sql for replacement of inventory Status Id with actual value.
	 */
	public final static String INVENTORY_STATUS_ID = "inventoryStatusId";

	/**
	 * Used in native sql for replacement of inventory Status Id with actual value.
	 */
	public final static String PDP_ID = "pdpId";
	/**
	 * Used in native sql for replacement of inventory Status Id with actual value.
	 */
	public final static String CUSTOMER_OWNED_DOMAIN_NAME = "customerOwnedDomainName";
	/**
	 * Used in native sql for replacement of inventory Status Id with actual value.
	 */
	public final static String MIGRATED_ORDER = "migratedOrder";
	/**
	 * Used in native sql for replacement of inventory Status Id with actual value.
	 */
	public final static String EXPEDITE = "expedite";

	/**
	 * Used in native sql for replacement of routerState with routerState.
	 */
	public final static String ROUTER_STATE = "routerState";
	/**
	 * Used in native sql for replacement of routerState with routerState.
	 */
	public final static String ROUTER_CITY = "routerCity";
	/**
	 * Used in native sql for replacement of npanxx with npanxx.
	 */
	public final static String NPA_NXX = "npanxx";
	/**
	 * Used in native sql for replacement of circuitId with circuitId.
	 */
	public final static String CIRCUIT_ID = "circuitId";
	/**
	 * Used in native sql for replacement of circuitId with circuitId.
	 */
	public final static String PORT_NUMBER = "portNumber";
	/**
	 * Used in native sql for replacement of routerCity with routerCity.
	 */
	public final static String ROUTER_CITY_OLD = "routerCityOld";
	/**
	 * Used in native sql for replacement of routerState with routerState.
	 */
	public final static String ROUTER_STATE_OLD = "routerStateOld";

	/**
	 * INSTAR_ORDER_ID.
	 */
	public final static String INSTAR_ORDER_ID = "instarOrderId";

	/**
	 * COMET_ORDER_ID
	 */
	public final static String COMET_ORDER_ID = "comet_order_id";

	/**
	 * INSTAR_VPN_STATUS
	 */
	public final static String INSTAR_VPN_STATUS = "instarVPNStatus";

	/**
	 * ORDER_DRIVEN_BY
	 */
	public final static String ORDER_DRIVEN_BY = "orderDrivenBy";

	/**
	 * INSTAR_VPN_ID
	 */
	public final static String INSTAR_VPN_ID = "instarVpnId";

	/**
	 * BACKHAUL_DISPLAY_ID
	 */
	public final static String BACKHAUL_DISPLAY_ID = "backhaul_display_id";

	/**
	 * BACKHAUL_DISPLAY_ID
	 */
	public final static String BACKHAUL_DISPL_ID = "backhaulDispId";
	/**
	 * BACKHAUL_ID
	 */
	public final static String BACKHAUL_ID = "backhaul_id";

	/**
	 * VPNID
	 */
	public final static String VPNID = "vpnId";

	/**
	 * ORDER_CONTACT_ID
	 */
	public final static String ORDER_CONTACT_ID = "ORDER_CONTACT_ID";

	/**
	 * ORDER_CONTACT_TYPE_ID
	 */
	public final static String ORDER_CONTACT_TYPE_ID = "ORDER_CONTACT_TYPE_ID";

	/**
	 * NAME
	 */
	public final static String NAME = "NAME";

	/**
	 * PHONE
	 */
	public final static String PHONE = "PHONE";

	/**
	 * EMAIL
	 */
	public final static String EMAIL = "EMAIL";

	/**
	 * DATA_CENTER_ID
	 */
	public final static String DATA_CENTER_ID = "data_center_id";

	/**
	 * Used in native sql for update att vpn end point
	 */
	public final static String SUB_VALUE = "subValue";

	/**
	 * CUST_PREF_DC BUC ID 2.2.09
	 */
	public final static String CUST_PREF_DC = "customerPrefDCComments";
	/**
	 * VLAN_GI
	 * 
	 */
	public final static String VLAN_GI = "vlanGi";

	/**
	 * TASK_NAME BUC ID 2.2.1
	 */
	public final static String TASK_NAME = "taskName";

	/**
	 * TASK_NAME BUC ID 2.2.1
	 */
	public final static String TASK_DISPLAY_NAME = "taskDisplayName";

	/**
	 * TASK_ORDER_ID BUC ID 2.2.1
	 */
	public final static String TASK_ORDER_ID = "orderId";

	/**
	 * ROLE_ID BUC ID 2.2.1
	 */
	public final static String ROLE_ID = "roleId";

	/**
	 * INVENTORY_ID BUC ID 2.2.1
	 */
	public final static String INVENTORY_ID = "inventoryId";

	/**
	 * ROLE_ID BUC ID 3.1.6
	 */
	public final static String ROLE_IDS = "roleIds";

	/**
	 * UADM_TO_DATE BUC ID 3.1.2
	 */
	public final static String UADM_TO_DATE = "toDate";

	/**
	 * UADM_FROM_DATE BUC ID 3.1.2
	 */
	public final static String UADM_FROM_DATE = "fromDate";

	/**
	 * UADM_FROM_DATE BUC ID 3.1.2
	 */
	public final static String APN_INPRODUCTION_DATE = "apnInProductionDate";

	/**
	 * OWNER.
	 */
	public final static String OWNER = "owner";

	/**
	 * CURRENT_USER_ATTUID
	 */
	public final static String CURRENT_USER_ATTUID = "currentAttuId";

	/**
	 * NEW_USER_ATTUID
	 */
	public final static String NEW_USER_ATTUID = "newAttuId";

	/**
	 * orderContactTypeId
	 */
	public final static String ORDER_CONTACT_TYPE = "orderContactTypeId";

	/**
	 * orderContactTypeId
	 */
	public final static String ORDER_ID_LIST = "orderIds";

	/**
	 * dataCenterList
	 */
	public final static String DATA_CENTER_LIST = "dataCenterList";

	/**
	 * dataCenterList
	 */
	public final static String INSIDE_OUTSIDE = "insideOutside";

	/**
	 * dataCenterList
	 */
	public final static String IMSI_MSISDN = "imsiMsisdn";

	/**
	 * dataCenterList
	 */
	public final static String DERIVED_ORDER = "derivedOrder";

	/**
	 * ATT_TUNNEL_INTERFACE_IP
	 */

	public static final String ATT_TUNNEL_ENDPOINT_IP = "attTunnelEndpointIp";
	/**
	 * CUST_TUNNEL_INTERFACE_IP
	 */
	public static final String CUST_TUNNEL_ENDPOINT_IP = "custTunnelEndpointIp";

	public static final String VRF_NAME = "vrfName";

	public final static String QUEUE_ORDER_ID = "orderId";

	public final static String QUEUE_HISTRY_FLAG = "histryFlg";

	public final static String ATTUID = "attuid";

	public final static String BACKHAUL_ORDER_ID = "orderId";

	public final static String DATACENTERID = "dataCenterId";

	public final static String CCS_MX = "ccsmx";

	public final static String IN_OUT = "inout";
}
