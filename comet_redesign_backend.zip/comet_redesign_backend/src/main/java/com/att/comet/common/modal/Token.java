package com.att.comet.common.modal;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;
@Component
public class Token extends UsernamePasswordAuthenticationToken {

	private static final long serialVersionUID = 4153429079598706215L;

	private String token;

	public Token() {
        super(null, null);
    }
	
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }

}
