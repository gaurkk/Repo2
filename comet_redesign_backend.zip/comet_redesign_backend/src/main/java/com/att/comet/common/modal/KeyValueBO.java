package com.att.comet.common.modal;

import org.springframework.stereotype.Component;

@Component
public class KeyValueBO {
	public KeyValueBO() {
	}
	public KeyValueBO(String key, String value) {
		super();
		this.key = key;
		this.value = value;
	}
	public String key;
	public String value;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
}

