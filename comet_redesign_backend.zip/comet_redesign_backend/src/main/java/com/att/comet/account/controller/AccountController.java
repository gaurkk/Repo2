package com.att.comet.account.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.sql.rowset.serial.SerialException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.account.modal.AccountFileDetailBO;
import com.att.comet.account.modal.AccountInfoBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.account.service.AccountService;
import com.att.comet.account.service.AccountServiceImpl;
import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.order.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class AccountController {

	Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	AccountServiceImpl masterAccountService;

	@Autowired
	OrderService orderService;

	@Autowired
	AccountService accountService;

	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = { "/searchMasterAccountList/{element}", "/searchMasterAccountList" }, produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Master Account Name", notes = "Return all the Master Account Name")
	public CometResponse<List<StaticDataBO>> getMasterAccountNameList(
			@PathVariable(required = false, value = "element") String searchCriteria) throws CometDataException {
		logger.info("[searchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Starting method getMasterAccountNameList : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();
		searchCriteria = CommonUtils.isNullEmpty(searchCriteria) ? "" : searchCriteria;
		List<String> masterAccountNameList = masterAccountService.getMasterAccountNameList(searchCriteria);
		if (masterAccountNameList != null && masterAccountNameList.size() > 0) {
			List<KeyValueBO> keyValueList = masterAccountNameList.stream().map(bo -> new KeyValueBO(bo, bo))
					.collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.MASTER_ACCOUNT_NAME, keyValueList));
		}
		cometResponse.setMethodReturnValue(accClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("[searchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Exiting method getMasterAccountNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = { "/searchSubAccountList/{element}", "/searchSubAccountList" }, produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Sub Account Name", notes = "Return all the Sub Account Name")
	public CometResponse<List<StaticDataBO>> getSubAccountNameList(
			@PathVariable(required = false, value = "element") String searchCriteria) throws CometDataException {
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Starting method getSubAccountNameList : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();
		searchCriteria = CommonUtils.isNullEmpty(searchCriteria) ? "" : searchCriteria;
		List<String> subAccountNameList = masterAccountService.getSubAccountNameList(searchCriteria);
		if (subAccountNameList != null && subAccountNameList.size() > 0) {
			List<KeyValueBO> keyValueList = subAccountNameList.stream().map(bo -> new KeyValueBO(bo, bo))
					.collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.SUB_ACCOUNT_NAME, keyValueList));
		}

		cometResponse.setMethodReturnValue(accClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Exiting method getSubAccountNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = { "/searchInternalInitiativeAccountList/{element}",
			"/searchInternalInitiativeAccountList" }, produces = {
					MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Internal Initiative Account Name", notes = "Return all the Internal Initiative Account Name")
	public CometResponse<List<StaticDataBO>> getInternalInitiativeAccountNameList(
			@PathVariable(required = false, value = "element") String searchCriteria) throws CometDataException {
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Starting method getInternalInitiativeAccountNameList : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();
		searchCriteria = CommonUtils.isNullEmpty(searchCriteria) ? "" : searchCriteria;
		List<String> internalInitiativeAccountNameList = masterAccountService
				.getInternalInitiativeAccountNameList(searchCriteria);
		if (internalInitiativeAccountNameList != null && internalInitiativeAccountNameList.size() > 0) {
			List<KeyValueBO> keyValueList = internalInitiativeAccountNameList.stream().map(bo -> new KeyValueBO(bo, bo))
					.collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.INTERNAL_INITIATIVE_ACCOUNT_NAME, keyValueList));
		}

		cometResponse.setMethodReturnValue(accClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Exiting method getInternalInitiativeAccountNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = { "/searchProductInitiativeAccountList/{element}",
			"/searchProductInitiativeAccountList" }, produces = {
					MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Product Initiative Account Name", notes = "Return all the Product Initiative Account Name")
	public CometResponse<List<StaticDataBO>> getProductInitiativeAccountNameList(
			@PathVariable(required = false, value = "element") String searchCriteria) throws CometDataException {
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Starting method getProductInitiativeAccountNameList : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();
		searchCriteria = CommonUtils.isNullEmpty(searchCriteria) ? "" : searchCriteria;
		List<String> productInitiativeAccountNameList = masterAccountService
				.getProductInitiativeAccountNameList(searchCriteria);
		if (productInitiativeAccountNameList != null && productInitiativeAccountNameList.size() > 0) {
			List<KeyValueBO> keyValueList = productInitiativeAccountNameList.stream().map(bo -> new KeyValueBO(bo, bo))
					.collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.PRODUCT_INITIATIVE_ACCOUNT_NAME, keyValueList));
		}

		cometResponse.setMethodReturnValue(accClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Exiting method getProductInitiativeAccountNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = { "/searchApnList/{element}", "/searchApnList" }, produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find APN Name", notes = "Return all the APN Name")
	public CometResponse<List<StaticDataBO>> getApnNameList(
			@PathVariable(required = false, value = "element") String searchCriteria) throws CometDataException {
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Starting method getApnNameList : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();
		searchCriteria = CommonUtils.isNullEmpty(searchCriteria) ? "" : searchCriteria;
		List<String> apnNameList = masterAccountService.getApnNameList(searchCriteria);
		if (apnNameList != null && apnNameList.size() > 0) {
			List<KeyValueBO> keyValueList = apnNameList.stream().map(bo -> new KeyValueBO(bo, bo))
					.collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.APN_NAME, keyValueList));
		}

		cometResponse.setMethodReturnValue(accClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("[SearchCriteria : " + (searchCriteria == null ? "" : searchCriteria)
				+ "] Exiting method getApnNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/account/{accountClassId}/{accountId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get Account Data", notes = "Get Account Info Details")
	public CometResponse<AccountInfoBO> getAccountInfo(@PathVariable String accountClassId,
			@PathVariable String accountId) throws CometDataException, CometServiceException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method getAccountInfo : ",
				this);
		CometResponse<AccountInfoBO> cometResponse = new CometResponse<AccountInfoBO>();
		AccountInfoBO accountInfoBO = null;
		accountInfoBO = accountService.getAccountInfo(accountClassId, accountId);
		if (null != accountInfoBO) {
			cometResponse.setMethodReturnValue(accountInfoBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method getAccountInfo : ",
				this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PutMapping(value = "/account/updateAccountInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update Account Data", notes = "Update Account Info Details")
	public CometResponse<AccountInfoBO> updateAccountInfo(@RequestBody AccountInfoBO accountInfoBO)
			throws CometDataException, IOException {
		logger.info("Starting method updateAccountInfo : ", this);
		CometResponse<AccountInfoBO> cometResponse = new CometResponse<AccountInfoBO>();
		try {
			if (accountInfoBO != null) {
				accountInfoBO = accountService.updateAccountInfo(accountInfoBO);
				if (null != accountInfoBO) {
					cometResponse.setMethodReturnValue(accountInfoBO);
					cometResponse.setStatusCode(Status.SUCCESS.getCode());
					cometResponse.setStatus(Status.SUCCESS);
				} else {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to update Account ");
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method updateAccountInfo : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "/account/{accountClassId}/{accountId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Account Data", notes = "Delete Account Info Details")
	public CometResponse<String> delAccountInfo(@PathVariable String accountClassId, @PathVariable String accountId)
			throws CometDataException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method delAccountInfo : ",
				this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		boolean isAccountDeleted = false;
		try {
			isAccountDeleted = accountService.deleteAccount(accountClassId, accountId);
			if (isAccountDeleted) {
				cometResponse.setMethodReturnValue("Account Deleted Successfully For Account Id : " + accountId);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setMethodReturnValue(Status.ACCOUNT_DELETION_ERROR.getName());
				cometResponse.setStatusCode(Status.ACCOUNT_DELETION_ERROR.getCode());
				cometResponse.setStatus(Status.ACCOUNT_DELETION_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method delAccountInfo : ",
				this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "/account/createAccount", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Create Account Data", notes = "Create Account Info Details")
	public CometResponse<AccountInfoBO> createAccount(@RequestBody AccountInfoBO accountInfoBO)
			throws CometDataException, IOException {
		logger.info("Starting method createAccount : ", this);
		CometResponse<AccountInfoBO> cometResponse = new CometResponse<AccountInfoBO>();
		try {
			if (accountInfoBO != null) {
				accountInfoBO = accountService.createAccount(accountInfoBO);
				if (null != accountInfoBO && null==accountInfoBO.getErrorMessage()) {
					cometResponse.setMethodReturnValue(accountInfoBO);
					cometResponse.setStatusCode(Status.SUCCESS.getCode());
					cometResponse.setStatus(Status.SUCCESS);
				}else if(null!=accountInfoBO.getErrorMessage()) {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
					cometResponse.setMessage(accountInfoBO.getErrorMessage());
				} else {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to create Account ");
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method createAccount : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/account/downloadAccountAttachement/{accountClassId}/{accountId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Download Account attachement ", notes = "Download Account attachement")
	public ResponseEntity<Resource> downloadAccountAttachement(@PathVariable String accountClassId,
			@PathVariable String accountId) throws CometDataException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] "
				+ "Starting method downloadAccountAttachement : ", this);
		// Load file as Resource
		AccountFileDetailBO accountFileDetailBO = null;
		try {
			accountFileDetailBO = accountService.getFileDetails(accountClassId, accountId);
			if (null != accountFileDetailBO) {
				String fileType = accountFileDetailBO.getUploadContentType();
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(fileType))
						.header(HttpHeaders.CONTENT_DISPOSITION,
								"attachment; filename=\"" + accountFileDetailBO.getUploadFileName() + "\"")
						.body(new ByteArrayResource(accountFileDetailBO.getUploadAttachment()));
			}
		} catch (SQLException e) {
			logger.error("[AccountID : " + (accountId == null ? "" : accountId) + "] "
					+ "SQLException Getting Download file " + e);
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] "
				+ "Exiting method downloadAccountAttachement : ", this);
		return null;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "account/uploadWaiverDoc", consumes = {
			MediaType.MULTIPART_FORM_DATA_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Account Waiver doc upload", notes = "Account Waiver doc upload")
	public CometResponse<String> uploadWaiverDoc(@RequestParam("file") MultipartFile file,
			@RequestParam("accountId") String accountId, @RequestParam("accClassId") Long accClassId)
			throws CometDataException, IOException, NumberFormatException, CometServiceException, SerialException,
			SQLException {
		logger.info("Starting method uploadWaiverDoc :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String uploadFile = accountService.storeFile(file, accountId, accClassId);
		if (null != uploadFile) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(uploadFile);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method uploadWaiverDoc  :", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "account/masteracc", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Existing Acc", notes = "Return all the Existing Acc")
	public CometResponse<List<StaticDataBO>> getExistingAccList() throws CometDataException, CometServiceException {
		logger.info("Starting method getExistingAccList : ", this);
		List<StaticDataBO> masterClass = new ArrayList<StaticDataBO>();
		List<MasterAccountBO> accNameList = accountService.getExistingAccList();
		if (!CollectionUtils.isEmpty(accNameList)) {
			List<KeyValueBO> keyValueList = accNameList.stream()
					.map(bo -> new KeyValueBO(bo.getUbcid(), bo.getMasterAccountName()))
					.collect(Collectors.toList());
			masterClass.add(new StaticDataBO(CometCommonConstant.MASTER_ACC_NAME, keyValueList));
		}
		cometResponse.setMethodReturnValue(masterClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getExistingAccList : ", this);
		return cometResponse;
	}
	
	@DeleteMapping(value = "/account/delAttachment/{accountClassId}/{accountId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Account Attachment", notes = "Delete Account Attachment Details")
	public CometResponse<String> delAccountAttachment(@PathVariable String accountClassId, @PathVariable String accountId)
			throws CometDataException, CometServiceException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method delAccountAttachment : ",
				this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		boolean isAttachmentDeleted = false;
		isAttachmentDeleted = accountService.delAccountAttachment(accountClassId, accountId);
		if (isAttachmentDeleted) {
			cometResponse.setMethodReturnValue(CometCommonConstant.ATTACHMENT_DELETE_SUCCESS + accountId);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}

		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method delAccountAttachment : ", this);
		return cometResponse;
	}
}
