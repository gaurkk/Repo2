package com.att.comet.charts.result;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BackhaulListGridDisplayBO extends GridDisplayBO {

	private static final long serialVersionUID = 7688462931680419624L;

	private Long backhaulId;
	private String backhaulType;
	private Long backhaulTypeId;
	private Long dataCenterId;
	private String dataCenterName;
	private String backhaulDisplayId;
	private String backhaulStatus;
	private String tunnelTypeVpnName;
	private String createdBy;
	private String createdOn;
	private String sharedApn;
	private String orderId;

}
