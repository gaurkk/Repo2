package com.att.comet.charts.result;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OrderApnListGridDisplayBO implements Serializable{

	private static final long serialVersionUID = 3562978710816606372L;

	private Long orderId;
	private String apnName;
	private String orderType;
	private String orderStatus;
	private String pdpId;
	private String pdpName;
	private String custOwnedDomainName;
	private String orderSubmitter;
}
