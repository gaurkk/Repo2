package com.att.comet.common.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.common.dao.SearchStaticDataDAOImpl;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.AccountClassBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.ApnSelection;
import com.att.comet.common.modal.ApnSelectionBO;
import com.att.comet.common.modal.BackhaulStatus;
import com.att.comet.common.modal.BackhaulStatusBO;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.modal.DapnStatusBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.OrderTypeEnum;
import com.att.comet.common.modal.OrderTypeBO;
import com.att.comet.common.modal.StaticYesOrNo;
import com.att.comet.common.modal.StaticYesOrNoBO;
import com.att.comet.dao.hibernate.bean.AccountClass;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.AdminConfig;
import com.att.comet.dao.hibernate.bean.BackhaulType;
import com.att.comet.dao.hibernate.bean.DapnStatus;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.OrderStatus;

@Service
public class SearchMenuStaticDataServiceImpl implements SearchStaticDataService {

	Logger logger = LoggerFactory.getLogger(SearchMenuStaticDataServiceImpl.class);

	@Autowired
	SearchStaticDataDAOImpl searchStaticDataDAOImpl;

	public List<AccountClassBO> getSearchAccountStaticDataList() {
		logger.info("Starting method getSearchAccountStaticDataList : ", this);
		List<AccountClass> accountClassList = searchStaticDataDAOImpl.findAccountClassList();
		List<AccountClassBO> searchDataList = new ArrayList<AccountClassBO>();
		AccountClassBO accountClassBO = null;
		for (AccountClass accountClass : accountClassList) {
			if(accountClass != null) {
				accountClassBO = new AccountClassBO();
				accountClassBO.setAccountClassId(accountClass.getAccountClassId());
				accountClassBO.setAccountClassName(accountClass.getAccountClassName());
				searchDataList.add(accountClassBO);
			}
		}
		logger.info("Exiting method getSearchAccountStaticDataList : ", this);
		return searchDataList;
	}

	public List<AdminConfigBO> getAccountTypeList() {
		logger.info("Starting method getAccountTypeList() : ", this);
		AdminCategory adminCategory = searchStaticDataDAOImpl.findAccTypeListByCategoryId((long) 1002);
		Set<AdminConfig> adminConfigSet = adminCategory.getAdminConfigs();
		List<AdminConfigBO> announcementList = null;
		List<AdminConfigBO> sortedAccountTypeList;
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigSet)) {
			announcementList = new ArrayList<AdminConfigBO>();
			for (AdminConfig adminCofig : adminConfigSet) {
				if(adminCofig != null && adminCofig.getAdminCategory().getAdminCategoryId() != null) {
					adminConfigBO = new AdminConfigBO();
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					announcementList.add(adminConfigBO);
				}
			}
		}else {
			throw new RecordNotFoundException("Data Not Found For Account Type");
		}
		logger.info("Exiting method getAccountTypeList() : ", this);
		sortedAccountTypeList = announcementList.stream().sorted(Comparator.comparing(AdminConfigBO::getDescription)).collect(Collectors.toList());
		return sortedAccountTypeList;
	}

	public List<BackhaulTypeBO> getBackhaulTypeList() {
		logger.debug("Starting method getBackhaulTypeList", this);	
		List<BackhaulType> backhaulTypeList = searchStaticDataDAOImpl.findBackhaulTypeList();
		List<BackhaulTypeBO> bhTypeList = new ArrayList<BackhaulTypeBO>();
		BackhaulTypeBO bhTypeBO = null;
		for (BackhaulType bhType : backhaulTypeList) {
			if(bhType != null) {
				bhTypeBO = new BackhaulTypeBO();
				bhTypeBO.setBackhaulTypeId(bhType.getBackhaulTypeId());
				bhTypeBO.setBackhaulTypeName(bhType.getBackhaulTypeName());
				bhTypeList.add(bhTypeBO);
			}
		}
		logger.debug("End method getBackhaulTypeList", this);
		return bhTypeList;
	}

	public List<OrderStatusBO> getOrderStatusList() {
		logger.debug("Starting method getOrderStatusList", this);	
		List<OrderStatus> orderStatusList = searchStaticDataDAOImpl.findOrderStatusList();
		List<OrderStatusBO> orderStatusBOList = new ArrayList<OrderStatusBO>();
		OrderStatusBO orderStatusBO = null;
		for (OrderStatus orderStatus : orderStatusList) {
			if(orderStatus != null) {
				orderStatusBO = new OrderStatusBO();
				orderStatusBO.setOrderstatusId(orderStatus.getOrderStatusId());
				orderStatusBO.setOrderStatusName(orderStatus.getOrderStatusName());
				orderStatusBO.setOrderStatusDescription(orderStatus.getOrderStatusDescription());
				orderStatusBOList.add(orderStatusBO);
			}
		}
		logger.debug("End method getOrderStatusList", this);
		return orderStatusBOList;
	}

	public List<DapnStatusBO> getDapnStatusList() {
		logger.debug("Starting method getDapnStatusList", this);	
		List<DapnStatus> dapnStatusList = searchStaticDataDAOImpl.findDapnStatusList();
		List<DapnStatusBO> dapnStatusBOList = new ArrayList<DapnStatusBO>();
		DapnStatusBO dapnStatusBO = null;
		for (DapnStatus dapnStatus : dapnStatusList) {
			if(dapnStatus != null) {
				dapnStatusBO = new DapnStatusBO();
				dapnStatusBO.setDapnStatusId(dapnStatus.getDapnStatusId());
				dapnStatusBO.setDapnStatus(dapnStatus.getDapnStatus());
				dapnStatusBOList.add(dapnStatusBO);
			}
		}
		logger.debug("End method getDapnStatusList", this);
		return dapnStatusBOList;
	}

	public List<AdminConfigBO> getApnSizeTypeList() {
		logger.debug("Starting method getApnSizeTypeList", this);
		AdminCategory adminCategory = searchStaticDataDAOImpl.findAccTypeListByCategoryId((long) 1039);
		Set<AdminConfig> adminConfigSet = adminCategory.getAdminConfigs();
		List<AdminConfigBO> apnSizeList = null;
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigSet)) {
			apnSizeList = new ArrayList<AdminConfigBO>();
			for (AdminConfig adminCofig : adminConfigSet) {
				if(adminCofig != null && adminCofig.getAdminCategory().getAdminCategoryId() != null) {
					adminConfigBO = new AdminConfigBO();
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					apnSizeList.add(adminConfigBO);
				}
			}
		}else {
			throw new RecordNotFoundException("Data Not Found For Apn Size");
		}		
		logger.debug("End method getApnSizeList", this);
		return apnSizeList;
	}

	public List<String> getCompanyNameList() {
		logger.debug("Starting method getCompanyNameList", this); 
		List<String> companyNameList = searchStaticDataDAOImpl.findCompanyList();
		if(null == companyNameList) {
			companyNameList = new ArrayList<String>();
		}
		logger.debug("End method getCompanyNameList", this); 
		return companyNameList;
	}

	public List<String> getBatchIdList() {
		logger.debug("Starting method getBatchIdList", this); 
		List<String> batchIdList = searchStaticDataDAOImpl.findBatchIdList();
		if(null == batchIdList) {
			batchIdList = new ArrayList<String>();
		}
		logger.debug("End method getBatchIdList", this); 
		return batchIdList;	
	}

	public List<BackhaulStatusBO> getBackhaulInstanceStatus(){
		logger.debug("Starting method getBackhaulInstanceStatus", this);
		List<BackhaulStatusBO> backhaulInstanceStatusList = new ArrayList<BackhaulStatusBO>();
		BackhaulStatusBO backhaulStatus = null;
		for (BackhaulStatus stat : BackhaulStatus.values()) {
			backhaulStatus = new BackhaulStatusBO();
			backhaulStatus.setBackhaulStatusId(stat.getBackhaulStatusId());
			backhaulStatus.setBackhaulStatusName(stat.getBackhaulStatusName()); 
			backhaulInstanceStatusList.add(backhaulStatus);
		}
		logger.debug("End method getBackhaulInstanceStatus", this);
		return backhaulInstanceStatusList;
	}

	public List<ApnSelectionBO> getApnSelection(){
		logger.debug("Starting method getApnSelection", this);
		List<ApnSelectionBO> apnSelectionList = new ArrayList<ApnSelectionBO>();
		ApnSelectionBO apnSelection = null;
		List<ApnSelectionBO> sortedApnSelection;
		for (ApnSelection stat : ApnSelection.values()) {
			apnSelection = new ApnSelectionBO();
			apnSelection.setApnSelectionId(stat.getApnSelectionId());
			apnSelection.setApnSelectionName(stat.getApnSelectionName()); 
			apnSelectionList.add(apnSelection);
		}
		sortedApnSelection = apnSelectionList.stream().sorted(Comparator.comparing(ApnSelectionBO::getApnSelectionId)).collect(Collectors.toList());
		logger.debug("End method getApnSelection", this);
		return sortedApnSelection;
	}

	public List<OrderTypeBO> getOrderType(){
		logger.debug("Starting method getOrderType", this);
		List<OrderTypeBO> orderTypeList = new ArrayList<OrderTypeBO>();
		OrderTypeBO orderType = null;
		List<OrderTypeBO> sortedOrderType;
		for (OrderTypeEnum stat : OrderTypeEnum.values()) {
			orderType = new OrderTypeBO();
			orderType.setOrderTypeId(stat.getOrderTypeId());
			orderType.setOrderTypeName(stat.getOrderTypeName()); 
			orderTypeList.add(orderType);
		}
		sortedOrderType = orderTypeList.stream().sorted(Comparator.comparing(OrderTypeBO::getOrderTypeId)).collect(Collectors.toList());
		logger.debug("End method getOrderType", this);
		return sortedOrderType;
	}

	public List<StaticYesOrNoBO> getStaticYesOrNo(){
		logger.debug("Starting method getStaticYesOrNo", this);
		List<StaticYesOrNoBO> staticYesNoList = new ArrayList<StaticYesOrNoBO>();
		StaticYesOrNoBO staticYesNo = null;
		for (StaticYesOrNo stat : StaticYesOrNo.values()) {
			staticYesNo = new StaticYesOrNoBO();
			staticYesNo.setStaticYesorNoId(stat.getId());
			staticYesNo.setStaticYesorNoName(stat.getYesOrNo()); 
			staticYesNoList.add(staticYesNo);
		}
		logger.debug("End method getStaticYesOrNo", this);
		return staticYesNoList;
	}

	public List<DataCenterBO> getDataCenterNameList() {
		logger.debug("Starting method getDataCenterNameList", this);	
		List<DataCenter> dataCenterList = searchStaticDataDAOImpl.findDataCenterList();
		List<DataCenterBO> dataCenterBOList = new ArrayList<DataCenterBO>();
		DataCenterBO dataCenterBO = null;
		for (DataCenter dataCenter : dataCenterList) {
			if(dataCenter != null) {
				dataCenterBO = new DataCenterBO();
				dataCenterBO.setDataCenterId(dataCenter.getDataCenterId());
				dataCenterBO.setDataCenterName(dataCenter.getDataCenterName());
				dataCenterBOList.add(dataCenterBO);
			}
		}
		logger.debug("End method getDataCenterNameList", this);
		return dataCenterBOList;
	}

	public List<String> getTunnelTypeList() {
		logger.debug("Starting method getTunnelTypeList", this); 
		List<String> tunnelTypeList = searchStaticDataDAOImpl.findTunnelTypeList();
		if(null == tunnelTypeList) {
			tunnelTypeList = new ArrayList<String>();
		}
		logger.debug("End method getTunnelTypeList", this); 
		return tunnelTypeList;
	}

}
