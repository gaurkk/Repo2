package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for EntTargetIpRange. Mapped to ENT_TARGET_IP_RANGE table in
 * the database.
 */
@Entity
@Table(name = "ENT_TARGET_IP_RANGE")
public class EntTargetIpRange implements java.io.Serializable {

	private static final long serialVersionUID = 1347987783036777598L;

	private Long entTargetIpRangeId;
	private Apn apn;
	private String entTargetIpRange;
	private String entTargetIpRangeType;
	private String apnProtocol;

	/**
	 * Getter method for entTargetIpRangeId. ENT_TARGET_IP_RANGE_ID mapped to
	 * ENT_TARGET_IP_RANGE_ID in the database table. The value of the id is
	 * generated using the sequence generator defined by
	 * SEQ_ENT_TARGET_IP_RANGE_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ENT_TARGET_IP_RANGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_ENT_TARGET_IP_RANGE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ENT_TARGET_IP_RANGE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ENT_TARGET_IP_RANGE_ID")
	public Long getEntTargetIpRangeId() {
		return entTargetIpRangeId;
	}

	/**
	 * @param entTargetIpRangeId
	 *            to entTargetIpRangeId set
	 */
	public void setEntTargetIpRangeId(Long entTargetIpRangeId) {
		this.entTargetIpRangeId = entTargetIpRangeId;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for entTargetIpRange. ENT_TARGET_IP_RANGE mapped to
	 * ENT_TARGET_IP_RANGE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ENT_TARGET_IP_RANGE", nullable = false, length = 100)
	public String getEntTargetIpRange() {
		return this.entTargetIpRange;
	}

	/**
	 * @param entTargetIpRange
	 *            to entTargetIpRange set.
	 */
	public void setEntTargetIpRange(String entTargetIpRange) {
		this.entTargetIpRange = entTargetIpRange;
	}

	/**
	 * @return the entTargetIpRangeType
	 */
	@Column(name = "ENT_TARGET_IP_RANGE_TYPE", nullable = false, length = 10)
	public String getEntTargetIpRangeType() {
		return entTargetIpRangeType;
	}

	/**
	 * @param entTargetIpRangeType the entTargetIpRangeType to set
	 */
	public void setEntTargetIpRangeType(String entTargetIpRangeType) {
		this.entTargetIpRangeType = entTargetIpRangeType;
	}
	
	
		@Column(name = "APN_PROTOCOL",  length = 100)
		public String getApnProtocol() {
			return apnProtocol;
		}
	
		public void setApnProtocol(String apnProtocol) {
			this.apnProtocol = apnProtocol;
		}
}