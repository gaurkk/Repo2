package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "INT_TARGET_IP_RANGE")
public class IntTargetIpRange implements java.io.Serializable {

	private static final long serialVersionUID = 7520596835743593282L;
	
	private Long intTargetIpRangeId;
	private Apn apn;
	private String intTargetIpRange;
	
	/**
	 * Getter method for intTargetIpRangeId. INT_TARGET_IP_RANGE_ID mapped to
	 * INT_TARGET_IP_RANGE_ID in the database table. The value of the id is
	 * generated using the sequence generator defined by
	 * SEQ_INT_TARGET_IP_RANGE_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "INT_TARGET_IP_RANGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_INT_TARGET_IP_RANGE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_INT_TARGET_IP_RANGE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_INT_TARGET_IP_RANGE_ID")
	public Long getIntTargetIpRangeId() {
		return intTargetIpRangeId;
	}

	/**
	 * @param intTargetIpRangeId
	 *            to intTargetIpRangeId set
	 */
	public void setIntTargetIpRangeId(Long intTargetIpRangeId) {
		this.intTargetIpRangeId = intTargetIpRangeId;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set.
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for intTargetIpRange. INT_TARGET_IP_RANGE mapped to
	 * INT_TARGET_IP_RANGE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INT_TARGET_IP_RANGE", nullable = false, length = 100)
	public String getIntTargetIpRange() {
		return this.intTargetIpRange;
	}

	/**
	 * @param intTargetIpRange
	 *            to intTargetIpRange set.
	 */
	public void setIntTargetIpRange(String intTargetIpRange) {
		this.intTargetIpRange = intTargetIpRange;
	}
}
