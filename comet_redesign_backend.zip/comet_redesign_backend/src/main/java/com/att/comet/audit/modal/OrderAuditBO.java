package com.att.comet.audit.modal;

import java.io.InputStream;
import java.util.Date;
import java.util.Set;

import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.order.modal.OrderDataCenterBO;
import com.att.comet.order.modal.OrderStatusHistoryBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class OrderAuditBO extends CometGenericBO {
	 private static final long serialVersionUID = 1564653969825597538L;

	private Long orderId;
	private Long numDataCenters;
	private String backHaulSelection;
	private String bcid;
	private String cipn;
	private Long roleId;
	private String updatedBy;
	private Set<OrderDataCenterBO> orderDataCenters;
	private String comments;
	private String expediteAction;
	private OrderStatusHistoryBO orderStatusHistory;
	private String createdBy;
	private Long orderType;
	private Character changeRequest;
	private Character crFlag;
	private int eventCount;
	private String ApnSelection;
	private Long orderStatus;
	private Character firstNetEpc;
	private String headQuarterLocation;
	private String exception = null;
	private Date createdOn;
	private Date updatedOn;
	private Date submittedOn;
	private Date dateInProduction;
	private String customerPrefDCComments;// BUC ID 2.2.09
	private String baseOrderNotes;
	private Character baseOrder;
	private Character exceptional;
	private String recoveryFlowChartName;
	private Long derivedFromOrder;
	private InputStream recoveryFlowChart;
}
