package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Persistent class for DedicatedApn. Mapped with DEDICATED_APN table in the
 * database.
 */
@Entity
@Table(name = "DEDICATED_APN")
public class DedicatedApn implements Serializable {

	private static final long serialVersionUID = -4541230736277862425L;
	private String apnId;
	private Orders orders;
	private String ipAddressSource;
	private String apnName;
	private InventoryStatus inventoryStatus;
	private String socFeatureCode;
	private String pdpName;
	private String addressType;
	private String staticAddressType;
	private Long uniqueIpAddressSize;
	private Long totalMobilePoolSize;
	private Character mobileToMobileEnabled;
	private Character mobileTerminationEnabled;
	private String priEntDnsServAdd;
	private String secEntDnsServAdd;
	private String amplifyingInformation;
	private String excpRequestApprover;
	private Date excpRequestDate;
	private String excpApprovalNumber;
	private String backhaulType;
	private String createdBy;
	private String updatedBy;
	private Date createdOn;
	private Date updatedOn;
	private DataCenter dataCenter;
	private Set<DedicatedMobilePoolAddress> dedicatedMobilePoolAddresses = new HashSet<DedicatedMobilePoolAddress>(0);
	private String dnsServerIp;
	private String domainName;
	private String dnsServerNotes;
	private Long pdpId;
	private String dapnId;
	private String workFlowUrl;

	/**
	 * Getter method for apnId. APN_ID mapped to APN_ID in the database table.
	 * 
	 * @return String
	 */
	@Id
	@GeneratedValue(generator = "triggerAssigned")
	@GenericGenerator(name = "triggerAssigned", strategy = "com.att.comet.dao.TriggerAssignedIdentityGenerator")
	@Column(name = "APN_ID", unique = true, nullable = false, length = 100)
	public String getApnId() {
		return this.apnId;
	}

	/**
	 * @param apnId to apnId set.
	 */
	public void setApnId(String apnId) {
		this.apnId = apnId;
	}

	/**
	 * Getter method for orders. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID")
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for ipAddressSource. IP_ADDRESS_SOURCE mapped to
	 * IP_ADDRESS_SOURCE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "IP_ADDRESS_SOURCE", length = 100)
	public String getIpAddressSource() {
		return this.ipAddressSource;
	}

	/**
	 * @param ipAddressSource to ipAddressSource set.
	 */
	public void setIpAddressSource(String ipAddressSource) {
		this.ipAddressSource = ipAddressSource;
	}

	/**
	 * Getter method for apnName. APN_NAME mapped to APN_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "APN_NAME", length = 100)
	public String getApnName() {
		return this.apnName;
	}

	/**
	 * @param apnName to apnName set.
	 */
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	/**
	 * Getter method for socFeatureCode. SOC_FEATURE_CODE mapped to SOC_FEATURE_CODE
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SOC_FEATURE_CODE", length = 12)
	public String getSocFeatureCode() {
		return this.socFeatureCode;
	}

	/**
	 * @param socFeatureCode to socFeatureCode set.
	 */
	public void setSocFeatureCode(String socFeatureCode) {
		this.socFeatureCode = socFeatureCode;
	}

	/**
	 * Getter method for pdpName. PDP_NAME mapped to PDP_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PDP_NAME", length = 100)
	public String getPdpName() {
		return this.pdpName;
	}

	/**
	 * @param pdpName to pdpName set.
	 */
	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	/**
	 * Getter method for addressType. ADDRESS_TYPE mapped to ADDRESS_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "ADDRESS_TYPE", length = 100)
	public String getAddressType() {
		return this.addressType;
	}

	/**
	 * @param addressType to addressType set.
	 */
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	/**
	 * Getter method for staticAddressType. STATIC_ADDRESS_TYPE mapped to
	 * STATIC_ADDRESS_TYPE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "STATIC_ADDRESS_TYPE", length = 100)
	public String getStaticAddressType() {
		return this.staticAddressType;
	}

	/**
	 * @param staticAddressType to staticAddressType set.
	 */
	public void setStaticAddressType(String staticAddressType) {
		this.staticAddressType = staticAddressType;
	}

	/**
	 * Getter method for uniqueIpAddressSize. UNIQUE_IP_ADDRESS_SIZE mapped to
	 * UNIQUE_IP_ADDRESS_SIZE in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "UNIQUE_IP_ADDRESS_SIZE", precision = 12, scale = 0)
	public Long getUniqueIpAddressSize() {
		return this.uniqueIpAddressSize;
	}

	/**
	 * @param uniqueIpAddressSize to uniqueIpAddressSize set.
	 */
	public void setUniqueIpAddressSize(Long uniqueIpAddressSize) {
		this.uniqueIpAddressSize = uniqueIpAddressSize;
	}

	/**
	 * Getter method for totalMobilePoolSize. TOTAL_MOBILE_POOL_SIZE mapped to
	 * TOTAL_MOBILE_POOL_SIZE in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "TOTAL_MOBILE_POOL_SIZE", precision = 12, scale = 0)
	public Long getTotalMobilePoolSize() {
		return this.totalMobilePoolSize;
	}

	/**
	 * @param totalMobilePoolSize to totalMobilePoolSize set.
	 */
	public void setTotalMobilePoolSize(Long totalMobilePoolSize) {
		this.totalMobilePoolSize = totalMobilePoolSize;
	}

	/**
	 * Getter method for mobileToMobileEnabled. MOBILE_TO_MOBILE_ENABLED mapped to
	 * MOBILE_TO_MOBILE_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "MOBILE_TO_MOBILE_ENABLED", length = 1)
	public Character getMobileToMobileEnabled() {
		return this.mobileToMobileEnabled;
	}

	/**
	 * @param mobileToMobileEnabled to mobileToMobileEnabled set.
	 */
	public void setMobileToMobileEnabled(Character mobileToMobileEnabled) {
		this.mobileToMobileEnabled = mobileToMobileEnabled;
	}

	/**
	 * Getter method for mobileTerminationEnabled. MOBILE_TERMINATION_ENABLED mapped
	 * to MOBILE_TERMINATION_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "MOBILE_TERMINATION_ENABLED", length = 1)
	public Character getMobileTerminationEnabled() {
		return this.mobileTerminationEnabled;
	}

	/**
	 * @param mobileTerminationEnabled to mobileTerminationEnabled set.
	 */
	public void setMobileTerminationEnabled(Character mobileTerminationEnabled) {
		this.mobileTerminationEnabled = mobileTerminationEnabled;
	}

	/**
	 * Getter method for priEntDnsServAdd. PRI_ENT_DNS_SERV_ADD mapped to
	 * PRI_ENT_DNS_SERV_ADD in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PRI_ENT_DNS_SERV_ADD", length = 100)
	public String getPriEntDnsServAdd() {
		return this.priEntDnsServAdd;
	}

	/**
	 * @param priEntDnsServAdd to priEntDnsServAdd set.
	 */
	public void setPriEntDnsServAdd(String priEntDnsServAdd) {
		this.priEntDnsServAdd = priEntDnsServAdd;
	}

	/**
	 * Getter method for secEntDnsServAdd. SEC_ENT_DNS_SERV_ADD mapped to
	 * SEC_ENT_DNS_SERV_ADD in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SEC_ENT_DNS_SERV_ADD", length = 100)
	public String getSecEntDnsServAdd() {
		return this.secEntDnsServAdd;
	}

	/**
	 * @param secEntDnsServAdd to secEntDnsServAdd set.
	 */
	public void setSecEntDnsServAdd(String secEntDnsServAdd) {
		this.secEntDnsServAdd = secEntDnsServAdd;
	}

	/**
	 * Getter method for amplifyingInformation. AMPLIFYING_INFORMATION mapped to
	 * AMPLIFYING_INFORMATION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "AMPLIFYING_INFORMATION", length = 3500)
	public String getAmplifyingInformation() {
		return this.amplifyingInformation;
	}

	/**
	 * @param amplifyingInformation to amplifyingInformation set.
	 */
	public void setAmplifyingInformation(String amplifyingInformation) {
		this.amplifyingInformation = amplifyingInformation;
	}

	/**
	 * Getter method for dedicatedMobilePoolAddresses.
	 * 
	 * @return Set<DedicatedMobilePoolAddress>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dedicatedApn")
	public Set<DedicatedMobilePoolAddress> getDedicatedMobilePoolAddresses() {
		return this.dedicatedMobilePoolAddresses;
	}

	/**
	 * @param dedicatedMobilePoolAddresses to dedicatedMobilePoolAddresses set.
	 */
	public void setDedicatedMobilePoolAddresses(Set<DedicatedMobilePoolAddress> dedicatedMobilePoolAddresses) {
		this.dedicatedMobilePoolAddresses = dedicatedMobilePoolAddresses;
	}

	/**
	 * Getter method for excpRequestApprover. EXCP_REQUEST_APPROVER mapped to
	 * EXCP_REQUEST_APPROVER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXCP_REQUEST_APPROVER", length = 100)
	public String getExcpRequestApprover() {
		return this.excpRequestApprover;
	}

	/**
	 * @param excpRequestApprover to excpRequestApprover set.
	 */
	public void setExcpRequestApprover(String excpRequestApprover) {
		this.excpRequestApprover = excpRequestApprover;
	}

	/**
	 * Getter method for excpRequestDate. EXCP_REQUEST_DATE mapped to
	 * EXCP_REQUEST_DATE in the database table.
	 * 
	 * @return Date.
	 */
	@Column(name = "EXCP_REQUEST_DATE")
	public Date getExcpRequestDate() {
		return this.excpRequestDate;
	}

	/**
	 * @param excpRequestDate to excpRequestDate set
	 */
	public void setExcpRequestDate(Date excpRequestDate) {
		this.excpRequestDate = excpRequestDate;
	}

	/**
	 * Getter method for excpApprovalNumber. EXCP_APPROVAL_NUMBER mapped to
	 * EXCP_APPROVAL_NUMBER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXCP_APPROVAL_NUMBER", length = 100)
	public String getExcpApprovalNumber() {
		return this.excpApprovalNumber;
	}

	/**
	 * @param excpApprovalNumber to excpApprovalNumber set.
	 */
	public void setExcpApprovalNumber(String excpApprovalNumber) {
		this.excpApprovalNumber = excpApprovalNumber;
	}

	/**
	 * Getter method for backhaulType. BACKHAUL_TYPE mapped to BACKHAUL_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "BACKHAUL_TYPE", length = 100)
	public String getBackhaulType() {
		return this.backhaulType;
	}

	/**
	 * @param backhaulType to backhaulType set.
	 */
	public void setBackhaulType(String backhaulType) {
		this.backhaulType = backhaulType;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for createdBy. CREATED_BY mapped to CREATED_BY in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "CREATED_BY", nullable = false, length = 6)
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy to createdBy set.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Getter method for updatedBy. UPDATED_BY mapped to UPDATED_BY in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "UPDATED_BY", nullable = false, length = 6)
	public String getUpdatedBy() {
		return this.updatedBy;
	}

	/**
	 * @param updatedBy to updatedBy set.
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Getter method for inventoryStatus.
	 * 
	 * @return InventoryStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "INVENTORY_STATUS_ID", nullable = false)
	public InventoryStatus getInventoryStatus() {
		return this.inventoryStatus;
	}

	/**
	 * @param inventoryStatus to inventoryStatus set.
	 */
	public void setInventoryStatus(InventoryStatus inventoryStatus) {
		this.inventoryStatus = inventoryStatus;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID")
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for dnsServerIp. DNS_SERVER_IP mapped to DNS_SERVER_IP in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "DNS_SERVER_IP")
	public String getDnsServerIp() {
		return dnsServerIp;
	}

	/**
	 * @param dnsServerIp to dnsServerIp set
	 */
	public void setDnsServerIp(String dnsServerIp) {
		this.dnsServerIp = dnsServerIp;
	}

	/**
	 * Getter method for domainName. DOMAIN_NAME mapped to DOMAIN_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "DOMAIN_NAME", length = 30)
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName to domainName set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * Getter method for dnsServerNotes. DNS_SERVER_NOTES mapped to DNS_SERVER_NOTES
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DNS_SERVER_NOTES", length = 3500)
	public String getDnsServerNotes() {
		return dnsServerNotes;
	}

	/**
	 * @param dnsServerNotes to dnsServerNotes set
	 */
	public void setDnsServerNotes(String dnsServerNotes) {
		this.dnsServerNotes = dnsServerNotes;
	}

	/**
	 * Getter method for pdpId. PDP_ID mapped to PDP_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "PDP_ID", length = 10)
	public Long getPdpId() {
		return pdpId;
	}

	/**
	 * @param pdpId to pdpId set.
	 */
	public void setPdpId(Long pdpId) {
		this.pdpId = pdpId;
	}

	/**
	 * Getter method for dapnId. DAPN_ID mapped to DAPN_ID in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DAPN_ID", length = 100)
	public String getDapnId() {
		return dapnId;
	}

	/**
	 * @param dapnId to dapnId set.
	 */
	public void setDapnId(String dapnId) {
		this.dapnId = dapnId;
	}

	/**
	 * Getter method for workFlowUrl. WORKFLOW_URL mapped to WORKFLOW_URL in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "WORKFLOW_URL", length = 200)
	public String getWorkFlowUrl() {
		return workFlowUrl;
	}

	/**
	 * @param workFlowUrl to workFlowUrl set.
	 */
	public void setWorkFlowUrl(String workFlowUrl) {
		this.workFlowUrl = workFlowUrl;
	}

}