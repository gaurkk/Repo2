package com.att.comet.account.modal;

import lombok.Data;

@Data
public class AccountFileDetailBO {

	private String uploadContentType;

	private byte[] uploadAttachment;

	private String uploadFileName;
}
