package com.att.comet.common.modal;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * POJO for CountryBO
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class CountryBO extends CometGenericBO{
	
	private static final long serialVersionUID = -1927830587584477920L;
	private Long countryId;
	private String countryName;
	private Character active;

}

