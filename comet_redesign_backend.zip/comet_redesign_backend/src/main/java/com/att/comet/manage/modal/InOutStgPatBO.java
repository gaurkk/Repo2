package com.att.comet.manage.modal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InOutStgPatBO implements InventoryBO{

	private static final long serialVersionUID = 2160964784533463162L;
	private Long orderId;
	private Long dataCenterId;
	private String dataCenterName;
	private String insideOutside;
	private String insidePat;
	private String outsidePat;
	private String inventoryStatus;	
}
