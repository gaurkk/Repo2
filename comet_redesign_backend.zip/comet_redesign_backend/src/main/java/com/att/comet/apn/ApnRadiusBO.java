package com.att.comet.apn;

import java.io.Serializable;
import java.util.Set;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class ApnRadiusBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 3844143639090975702L;
	private Long dataCenterId;
	private String dataCenterName;
	private Long custRadServer;
	private String rasClientIp;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	Long orderId;
	private Set<ApnCustomerRadiusBO> apnCustomerRadiuses;

}
