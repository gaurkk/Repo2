package com.att.comet.apn;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApnRequestBO {
	private String attId;
	 private String roleId;
	 private String orderId;
}
