package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.AdminConfig;

@Repository
public interface AdminConfigInfoRepository extends JpaRepository<AdminConfig, Long> {

	List<AdminConfig> findByAdminCategory_adminCategoryId(Long adminCategoryId);

	List<AdminConfig> findByAdminCategory_adminCategoryIdAndCategoryValueContains(Long adminCategoryId,
			String dataCenterId);

	List<AdminConfig> findByAdminCategory_adminCategoryIdAndDefaultValueOrderByAdminConfigIdDesc(Long adminCategoryId,
			Character defaultValue);

	List<AdminConfig> findByAdminCategory_adminCategoryIdIn(List<Long> categoryId);

	List<AdminConfig> findByAdminCategory_adminCategoryIdAndDefaultValueAndCategoryValueContainsOrderByAdminConfigIdDesc(
			Long adminCategoryId, Character defaultValue, String dataCenterId);
	
	long countByAdminCategory_adminCategoryIdAndCategoryValueContains(Long categoryId,String categoryValue);

	AdminConfig findByAdminCategory_adminCategoryIdAndAdminCategory_adminCategoryValueType(Long adminCategoryId, String adminCategoryValueType);
}
