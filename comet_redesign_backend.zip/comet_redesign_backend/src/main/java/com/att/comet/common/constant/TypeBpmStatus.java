package com.att.comet.common.constant;

public enum TypeBpmStatus {

	TRIGGERRED(1001L, "TRIGGERRED"), COMPLETED(1002L, "COMPLETED"), NOT_EXECUTED(1003L, "NOT EXECUTED"),
	REJECTED(1004L, "REJECTED"), SUSPENDED(1005L, "SUSPENDED");

	/**
	 * property id
	 */
	private final Long id;

	/**
	 * property name
	 */
	private final String name;

	/**
	 * Getter method for the id.
	 * 
	 * @return Long
	 */

	public Long getId() {
		return id;
	}

	/**
	 * Getter method for the name
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * A static method to get the name of the BPM Status based on the id of the
	 * status.
	 * 
	 * @param id
	 * @return TypeBpmStatus, if the value of id is not null , and null otherwise.
	 */
	public static TypeBpmStatus getName(Long id) {
		if (id != null) {
			for (TypeBpmStatus orderStatus : TypeBpmStatus.values()) {
				if (orderStatus.getId().longValue() == id.longValue()) {
					return orderStatus;
				}
			}
		}
		return null;
	}

	/**
	 * Defines the constructor.
	 * 
	 * @param id
	 * @param name
	 */
	private TypeBpmStatus(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}