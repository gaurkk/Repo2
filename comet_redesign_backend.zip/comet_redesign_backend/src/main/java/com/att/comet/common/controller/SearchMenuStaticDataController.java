package com.att.comet.common.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.AccountClassBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.ApnSelectionBO;
import com.att.comet.common.modal.BackhaulStatusBO;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.DapnStatusBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.OrderTypeBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.common.modal.StaticYesOrNoBO;
import com.att.comet.common.service.SearchMenuStaticDataServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class SearchMenuStaticDataController {

	Logger logger = LoggerFactory.getLogger(SearchMenuStaticDataController.class);

	@Autowired 
	SearchMenuStaticDataServiceImpl searchStaticDataServiceImpl;

	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/searchMenuStaticData", produces = {MediaType.APPLICATION_JSON_VALUE},headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Search Menu Tab Static Data",notes = "Return all static Data")
	public CometResponse<List<StaticDataBO>> getSearchMenuStaticData() throws CometDataException{
		logger.info("Starting method getSearchMenuStaticData : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();

		List<AccountClassBO> accountBOs = searchStaticDataServiceImpl.getSearchAccountStaticDataList();
		if(!CollectionUtils.isEmpty(accountBOs)) {
			List<KeyValueBO> keyValueList = accountBOs.stream().map(bo -> new KeyValueBO(bo.getAccountClassId().toString(), bo.getAccountClassName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.ACCOUNT_CLASS,keyValueList));
		}else {
			logger.error("AccountBOs is not set ", this);	
		}

		List<AdminConfigBO> adminConfigBOs = searchStaticDataServiceImpl.getAccountTypeList();
		if(!CollectionUtils.isEmpty(adminConfigBOs)  && adminConfigBOs.size() > 0) {
			List<KeyValueBO> keyValueList = adminConfigBOs.stream().map(bo -> new KeyValueBO(bo.getCategoryValue(), bo.getDescription())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.ACCOUNT_TYPE, keyValueList)); 
		}else {
			logger.error("adminConfigBOs is not set", this);
		}

		List<BackhaulTypeBO> backHaulTypeBOs = searchStaticDataServiceImpl.getBackhaulTypeList();
		if(!CollectionUtils.isEmpty(backHaulTypeBOs) && backHaulTypeBOs.size() > 0) {
			List<KeyValueBO> keyValueList = backHaulTypeBOs.stream().map(bo -> new KeyValueBO(bo.getBackhaulTypeId().toString(), bo.getBackhaulTypeName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.BACKHAUL_TYPE, keyValueList)); 
		}else {
			logger.error("backHaulTypeBOs is not set ", this);
		}

		List<OrderStatusBO> orderStatusBOs = searchStaticDataServiceImpl.getOrderStatusList(); 
		if(!CollectionUtils.isEmpty(orderStatusBOs)) { 
			List<KeyValueBO> keyValueList = orderStatusBOs.stream().map(bo -> new KeyValueBO(String.valueOf(bo.getOrderstatusId()), bo.getOrderStatusDescription())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.ORDER_STATUS, keyValueList)); 
		}
		else {
			logger.error("orderStatusBOs is not set ", this);
		}

		List<DapnStatusBO> dapnStatusBOs = searchStaticDataServiceImpl.getDapnStatusList();
		if(!CollectionUtils.isEmpty(dapnStatusBOs)) {
			List<KeyValueBO> keyValueList = dapnStatusBOs.stream().map(bo -> new KeyValueBO(bo.getDapnStatusId().toString(), bo.getDapnStatus())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.DAPN_STATUS, keyValueList)); 
		}
		else {
			logger.error("dapnStatusBOs is not set ", this);
		}


		List<AdminConfigBO> apnSizeadminConfigBOs = searchStaticDataServiceImpl.getApnSizeTypeList();
		if(!CollectionUtils.isEmpty(apnSizeadminConfigBOs) && apnSizeadminConfigBOs.size() > 0) {
			List<KeyValueBO> keyValueList = apnSizeadminConfigBOs.stream().map(bo -> new KeyValueBO(bo.getCategoryValue(), bo.getCategoryValue())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.APN_SIZE, keyValueList)); 
		}else {
			logger.error("apnSizeadminConfigBOs is not set ", this);	
		}

		List<String> subAccountBOs = searchStaticDataServiceImpl.getCompanyNameList();
		if(!CollectionUtils.isEmpty(subAccountBOs)) {
			List<KeyValueBO> keyValueList = subAccountBOs.stream().map(bo -> new KeyValueBO(bo, bo)).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.COMPANY_NAME, keyValueList)); 
		}else {
			logger.error("subAccountBOs is not set ", this);
		}

		List<String> dapnInventoryBOs = searchStaticDataServiceImpl.getBatchIdList();
		if(!CollectionUtils.isEmpty(dapnInventoryBOs)) {
			List<KeyValueBO> keyValueList = dapnInventoryBOs.stream().map(bo -> new KeyValueBO(bo, bo)).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.BATCH_ID, keyValueList)); 
		}else {
			logger.error("dapnInventoryBOs is not set ", this);
		}

		List<BackhaulStatusBO> backhaulStatusBOs = searchStaticDataServiceImpl.getBackhaulInstanceStatus();
		if(!CollectionUtils.isEmpty(backhaulStatusBOs) && backhaulStatusBOs.size() > 0) {
			List<KeyValueBO> keyValueList = backhaulStatusBOs.stream().map(bo -> new KeyValueBO(bo.getBackhaulStatusName(), bo.getBackhaulStatusName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.BACKHAULINSTANCE_STATUS, keyValueList)); 
		}else {
			logger.error("backhaulStatusBOs is not set ", this);
		}

		List<ApnSelectionBO> apnSelectionBOs = searchStaticDataServiceImpl.getApnSelection();
		if(!CollectionUtils.isEmpty(backhaulStatusBOs)  && apnSelectionBOs.size() > 0) {
			List<KeyValueBO> keyValueList = apnSelectionBOs.stream().map(bo -> new KeyValueBO(bo.getApnSelectionName(), bo.getApnSelectionName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.APN_SELECTION, keyValueList)); 
		}else {
			logger.error("apnSelectionBOs is not set ", this);
		}

		List<OrderTypeBO> orderTypeBOs = searchStaticDataServiceImpl.getOrderType();
		if(!CollectionUtils.isEmpty(backhaulStatusBOs)  && orderTypeBOs.size() > 0) {
			List<KeyValueBO> keyValueList = orderTypeBOs.stream().map(bo -> new KeyValueBO(String.valueOf(bo.getOrderTypeId()), bo.getOrderTypeName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.ORDER_TYPE, keyValueList)); 
		}
		else {
			logger.error("apnSelectionBOs is not set ", this);
		}

		List<DataCenterBO> dataCenterBOs = searchStaticDataServiceImpl.getDataCenterNameList();
		if(!CollectionUtils.isEmpty(dataCenterBOs)) {
			List<KeyValueBO> keyValueList = dataCenterBOs.stream().map(bo -> new KeyValueBO(String.valueOf(bo.getDataCenterId()), bo.getDataCenterName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.DATACENTER_NAME, keyValueList)); 
		}else {
			logger.error("dataCenterBOs is not set ", this);
		}

		List<StaticYesOrNoBO> staticYesorNoMigrateOrder = searchStaticDataServiceImpl.getStaticYesOrNo();
		if(!CollectionUtils.isEmpty(staticYesorNoMigrateOrder)) {
			List<KeyValueBO> keyValueList = staticYesorNoMigrateOrder.stream().map(bo -> new KeyValueBO(bo.getStaticYesorNoName(), bo.getStaticYesorNoName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.STATIC_YES_NO_MIGRATEORDER, keyValueList)); 
		}else {
			logger.error("staticYesorNoMigrateOrder is not set ", this);
		}

		List<StaticYesOrNoBO> staticYesorNoFirstNetOrder = searchStaticDataServiceImpl.getStaticYesOrNo();
		if(!CollectionUtils.isEmpty(staticYesorNoFirstNetOrder)) {
			List<KeyValueBO> keyValueList = staticYesorNoFirstNetOrder.stream().map(bo -> new KeyValueBO(bo.getStaticYesorNoName(), bo.getStaticYesorNoName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.STATICYES_NO_FIRSTNETORDER, keyValueList)); 
		}else {
			logger.error("staticYesorNoFirstNetOrder is not set ", this);
		}

		List<StaticYesOrNoBO> staticYesorNoOrderExpedite = searchStaticDataServiceImpl.getStaticYesOrNo();
		if(!CollectionUtils.isEmpty(staticYesorNoOrderExpedite)) {
			List<KeyValueBO> keyValueList = staticYesorNoOrderExpedite.stream().map(bo -> new KeyValueBO(bo.getStaticYesorNoName(), bo.getStaticYesorNoName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.STATICYES_NO_ORDEREXPEDITE, keyValueList)); 
		}else {
			logger.error("staticYesorNoOrderExpedite is not set ", this);
		}

		List<BackhaulTypeBO> backHaulTypeInstanceBOs = searchStaticDataServiceImpl.getBackhaulTypeList();
		if(!CollectionUtils.isEmpty(backHaulTypeInstanceBOs)) {
			List<KeyValueBO> keyValueList = backHaulTypeInstanceBOs.stream().map(bo -> new KeyValueBO(bo.getBackhaulTypeId().toString(), bo.getBackhaulTypeName())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.BACKHAUL_INSTANCE_TYPE, keyValueList)); 
		}else {
			logger.error("backHaulTypeInstanceBOs is not set ", this);
		}

		List<String> tunnelTypeBOs = searchStaticDataServiceImpl.getTunnelTypeList();
		if(!CollectionUtils.isEmpty(tunnelTypeBOs)) {
			List<KeyValueBO> keyValueList = tunnelTypeBOs.stream().map(bo -> new KeyValueBO(bo, bo)).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.TUNNEL_TYPE, keyValueList)); 
		}else {
			logger.error("tunnelTypeBOs is not set ", this);
		}


		if(!CollectionUtils.isEmpty(accClass)) {
			cometResponse.setMethodReturnValue(accClass);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		}else {
			logger.error("accClass is not set ", this);
			cometResponse.setMethodReturnValue(accClass);
			cometResponse.setStatusCode(Status.SYSTEM_ERROR.getCode());
			cometResponse.setStatus(Status.SYSTEM_ERROR);
		}
		logger.info("Exiting method getSearchMenuStaticData : ", this);
		return cometResponse;	
	} 


}
