package com.att.comet.eiis.modal;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode
@AllArgsConstructor
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public User() {
        super();
    }
	private String username;
	private String password;
	
}
