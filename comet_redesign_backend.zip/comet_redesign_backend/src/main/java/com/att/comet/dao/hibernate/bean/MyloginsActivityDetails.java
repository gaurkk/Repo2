package com.att.comet.dao.hibernate.bean;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "MYLOGINS_ACTIVITY_DETAILS")
@Data
public class MyloginsActivityDetails implements java.io.Serializable {

	private static final long serialVersionUID = 941645110548647643L;
	
	@Id
	@Column(name = "ACTIVITY_DETAILS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long activityDetailsId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACTIVITY_TYPE_ID", nullable = false)
	private MyloginsActivityType myloginsActivityType;
	
	@Column(name = "START_TIME")
	private Date startTime;
	
	@Column(name = "END_TIME")
	private Date endTime;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "DEV_REMARKS")
	private String devRemarks;
	
	@Column(name = "FILE_NAME")
	private String fileName;
	
}