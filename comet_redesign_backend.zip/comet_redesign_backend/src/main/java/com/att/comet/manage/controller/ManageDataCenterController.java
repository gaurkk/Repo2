package com.att.comet.manage.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.manage.service.ManageService;
import com.att.comet.order.controller.OrderBHController;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ManageDataCenterController {
	
	Logger logger = LoggerFactory.getLogger(OrderBHController.class);

	@Autowired
	ManageService manageService;
	
	@Secured({"ROLE_COMET_ADMIN"})
	@PostMapping(value = "manageDataCenter/saveDataCenter",consumes = {
			MediaType.APPLICATION_JSON_VALUE },headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add new Data Center", notes = "Add New Data Center")
	public CometResponse<String> saveDataCenter(@RequestBody DataCenterBO dataCenterBO)throws CometDataException, CometServiceException  {
		logger.info("Starting method addDataCenter :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String resultBO = manageService.saveDataCenter(dataCenterBO);
		if(null!=resultBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(resultBO);
		}else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method addDataCenter :", this);
		return cometResponse;
	}
	
	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "manageDataCenter/delDataCenter", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Data Center", notes = "Delete Data Center")
	public CometResponse<String> delDataCenter(@RequestBody DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		logger.info("Starting method delDataCenter :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String resultBO = manageService.delDataCenter(dataCenterBO);
		if(null!=resultBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(resultBO);
		}else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method delDataCenter :", this);
		return cometResponse;
	}
	
	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "manageDataCenter/updateDataCenter", produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Updated DataCenter Info", notes = "Update DataCenter Info")
	public CometResponse<String> updateDataCenter(@RequestBody DataCenterBO dataCenterBO) throws CometDataException, CometServiceException {
		logger.info("Start method updateDataCenter :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		if (dataCenterBO != null) {
			String resultBO = manageService.updateDataCenter(dataCenterBO);
			cometResponse.setMethodReturnValue(resultBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method updateDataCenter :", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/getDataCenterInfo/{dcId}",produces = {
			MediaType.APPLICATION_JSON_VALUE },headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get Data Center Info", notes = "Data Center Info")
	public CometResponse<DataCenterBO> getDataCenterInfo(@PathVariable Long dcId)throws CometDataException, CometServiceException  {
		logger.info("Starting method getDataCenterInfo :", this);
		CometResponse<DataCenterBO> cometResponse = new CometResponse<DataCenterBO>();
		DataCenterBO resultBO = manageService.getDataCenterInfo(dcId);
		if(null!=resultBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(resultBO);
		}else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method getDataCenterInfo :", this);
		return cometResponse;
	}

}
