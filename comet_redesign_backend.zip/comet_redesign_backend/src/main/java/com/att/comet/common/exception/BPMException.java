package com.att.comet.common.exception;

import java.util.List;

/**
 * Base exception class for BPM service layer.
 */

public class BPMException extends CometException {

	private static final long serialVersionUID = 9036263879592175565L;
	
	/**
	 * BPMException constructor with String argument.
	 * 
	 * @param errorCode
	 */
	public BPMException(String errorCode) {
		super(errorCode);
	}

	/**
	 * BPMException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 */
	public BPMException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * BPMException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public BPMException(String errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * BPMException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public BPMException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

	/**
	 * BPMException constructor with list of error messages.
	 * 
	 * @param errorList
	 */
	public BPMException(List<String> errorList) {
		super(errorList);
	}
}
