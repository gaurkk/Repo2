package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class UserTokensId implements Serializable {

	private static final long serialVersionUID = -7862836655042609325L;

	@Column(name = "ATTUID", unique = true, nullable = false, length = 6)
	private String attuid;

	@Column(name = "ROLE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long roleId;
}
