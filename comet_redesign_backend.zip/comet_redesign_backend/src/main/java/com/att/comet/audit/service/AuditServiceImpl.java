package com.att.comet.audit.service;

import java.sql.Blob;
import java.sql.ResultSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.comet.account.modal.OrderAccountBO;
import com.att.comet.audit.helper.ApnAuditHelper;
import com.att.comet.audit.helper.BackhaulAuditHelper;
import com.att.comet.audit.helper.OrderAccountAuditHelper;
import com.att.comet.audit.helper.OrderAuditHelper;
import com.att.comet.audit.helper.OrderContactAuditHelper;
import com.att.comet.audit.modal.ApnAuditBO;
import com.att.comet.audit.modal.OrderAuditBO;
import com.att.comet.audit.modal.OrderContactAuditBO;
import com.att.comet.audit.modal.RecoveryFlowChartAuditBO;
import com.att.comet.audit.modal.RowData;
import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulConfigBO;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.crd.modal.CrdBO;
import com.att.comet.order.modal.BillingDetailsBO;
import com.att.comet.order.modal.InternetVPNConfigBO;
import com.att.comet.order.modal.MplsConfigBO;
import com.att.comet.order.modal.OrderSummaryBO;

@Service
public class AuditServiceImpl implements AuditService {
	private static final Logger logger = LoggerFactory.getLogger(AuditServiceImpl.class);
	
	@Autowired
	OrderAuditHelper orderAuditHelper;
	
	@Autowired
	ApnAuditHelper apnAuditHelper;
	
	@Autowired
	OrderAccountAuditHelper orderAccountAuditHelper;
	
	@Autowired
	OrderContactAuditHelper orderContactAuditHelper;
	
	@Autowired
	BackhaulAuditHelper backhaulAuditHelper;
	
	@Autowired
	EntityManager em;
	
	@Transactional
	@Override
	public OrderAuditBO getOrderInitializationInfoAudit(Long orderId, Long eventId)
													throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getOrderInitializationInfoAudit");
			throw new CometServiceException("[getOrderInitializationInfoAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getOrderInitializationInfoAudit -- Start");
		OrderAuditBO orderAuditBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_INIT_ORDER_CONFIG_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(6, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(7, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute(); 
	
			String errorMessage = (String) spQuery.getOutputParameterValue(7);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}
	
			orderAuditBO = orderAuditHelper.getInitOrderConfigAuditInfo(spQuery);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] Exception in Getting Init Order Config audit info "
					+ e);
			throw new CometServiceException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getOrderInitializationInfoAudit -- End");
		return orderAuditBO;
	}
	
	@Transactional
	@Override
	public ApnAuditBO getApnAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getApnAudit");
			throw new CometServiceException("[getApnAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getApnAudit -- Start");
		ApnAuditBO apnAuditBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_APN_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(6, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(7, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(8, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(9, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(10, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(11, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(12, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(13, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(14, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute(); 
			
			String errorMessage = (String) spQuery.getOutputParameterValue(14);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			apnAuditBO = apnAuditHelper.getApnAuditInfo(orderId, spQuery);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] Exception in Getting Apn audit info" 
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getApnAudit -- End");
		return apnAuditBO;
	}
	
	@Transactional
	@Override
	public OrderAccountBO getOrderAccountAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getOrderAccountAudit");
			throw new CometServiceException("[getOrderAccountAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getOrderAccountAudit -- Start");
		OrderAccountBO orderAccountBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_ORDER_ACCOUNT_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(5);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			orderAccountBO = orderAccountAuditHelper.getOrderAccountAuditInfo(orderId, spQuery);						
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] Exception in Getting order account audit info" 
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getOrderAccountAudit -- End");
		return orderAccountBO;
	}
	
	@Transactional
	@Override
	public OrderContactAuditBO getOrderContactAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getOrderContactAudit");
			throw new CometServiceException("[getOrderContactAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getOrderContactAudit -- Start");
		OrderContactAuditBO orderContactBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_ORDER_CONTACT_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(5);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			orderContactBO = orderContactAuditHelper.getOrderContactAuditInfo(orderId, spQuery);			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting Order Contact Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getOrderContactAudit -- End");
		return orderContactBO;
	}
	
	@Transactional
	@Override
	public BackhaulConfigBO getBackhaulConfigAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getBackhaulConfigAudit");
			throw new CometServiceException("[getBackhaulConfigAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getBackhaulConfigAudit -- Start");
		BackhaulConfigBO backhaulConfigBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_BACKHAUL_CONFIG_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(4);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			List<RowData> backhaulConfigResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));

			backhaulConfigBO = orderAuditHelper.getBackhaulConfigAuditInfo(orderId, backhaulConfigResults);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting Backhaul Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getBackhaulConfigAudit -- End");
		return backhaulConfigBO;
	}
	
	@Transactional
	@Override
	public InternetVPNConfigBO getInternetVPNConfigAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getInternetVPNConfigAudit");
			throw new CometServiceException("[getInternetVPNConfigAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getInternetVPNConfigAudit -- Start");
		InternetVPNConfigBO internetVPNConfigBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_INTERNET_VPN_AUDIT_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(5);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			internetVPNConfigBO = backhaulAuditHelper.getInternetVpnAuditInfo(orderId, spQuery);
			if (internetVPNConfigBO != null) {
				internetVPNConfigBO.setOrderId(orderId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting I-VPN Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getInternetVPNConfigAudit -- End");
		return internetVPNConfigBO;
	}
	
	@Transactional
	@Override
	public MplsConfigBO getMplsConfigAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getMplsConfigAudit");
			throw new CometServiceException("[getMplsConfigAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getMplsConfigAudit -- Start");
		MplsConfigBO mplsConfigBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_MPLS_AUDIT_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(6, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(7, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(7);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			mplsConfigBO = backhaulAuditHelper.getMplsAuditInfo(orderId, spQuery);
			if (mplsConfigBO != null) {
				mplsConfigBO.setOrderId(orderId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting MPLS Config Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getMplsConfigAudit -- End");
		return mplsConfigBO;
	}
	
	@Transactional
	@Override
	public CrdBO getCrdAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getCrdAudit");
			throw new CometServiceException("[getCrdAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getCrdAudit -- Start");
		CrdBO crdBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_CRD_CONFIG_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(6, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(6);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			crdBO = orderAuditHelper.getCrdAuditInfo(orderId, spQuery);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting MPLS Config Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getCrdAudit -- End");
		return crdBO;
	}
	
	@Transactional
	@Override
	public OrderAccountBO getFeeWaiverDocAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getFeeWaiverDocAudit");
			throw new CometServiceException("[getFeeWaiverDocAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getFeeWaiverDocAudit -- Start");
		OrderAccountBO orderAccountBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_FEE_WAIVER_DOC_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(4);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			List<RowData> orderAccountResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
			if (orderAccountResults != null && !orderAccountResults.isEmpty()) {
				RowData orderAccount = orderAccountResults.get(0);
				Object columnValue = null;
				if (orderAccount != null) {
					orderAccountBO = new OrderAccountBO();
					orderAccountBO.setOrderId(orderId);

					columnValue = orderAccount.getColumnValue("WAIVER_ATTACHMENT_FILENAME");
					if (columnValue != null) {
						orderAccountBO.setWaiverAttachmentFilename((String) columnValue);
					}

					columnValue = orderAccount.getColumnValue("WAIVER_ATTACHMENT");
					if (columnValue != null) {
						Blob blob = (Blob) columnValue;
						orderAccountBO.setWaiverAttachment(blob.getBytes(1L,  (int)blob.length()));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting FeeWaiver Doc Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
				
		logger.debug("AuditServiceImpl::getFeeWaiverDocAudit -- End");
		return orderAccountBO;
	}
	
	@Transactional
	@Override
	public RecoveryFlowChartAuditBO getRecoveryFlowChartAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getRecoveryFlowChartAudit");
			throw new CometServiceException("[getRecoveryFlowChartAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getRecoveryFlowChartAudit -- Start");
		RecoveryFlowChartAuditBO recoveryFlowChartAuditBO = null;
	
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_RECOVERY_FLOW_CHART_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(4);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			List<RowData> orderResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
			if (orderResults != null && !orderResults.isEmpty()) {
				RowData order = orderResults.get(0);
				Object columnValue = null;
				if (order != null) {
					recoveryFlowChartAuditBO = new RecoveryFlowChartAuditBO();
					recoveryFlowChartAuditBO.setOrderId(orderId);

					columnValue = order.getColumnValue("RECOVERY_FLOW_CHART_FILENAME");
					if (columnValue != null) {
						recoveryFlowChartAuditBO.setRecoveryFlowChartName((String) columnValue);
					}

					columnValue = order.getColumnValue("RECOVERY_FLOW_CHART");
					if (columnValue != null) {
						Blob blob = (Blob) columnValue;
						recoveryFlowChartAuditBO.setRecoveryFlowChart(blob.getBytes(1L,  (int)blob.length()));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting Recovery FlowChart Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getRecoveryFlowChartAudit -- End");
		return recoveryFlowChartAuditBO;
	}
	
	@Transactional
	@Override
	public OrderSummaryBO getOrderSummaryAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getOrderSummaryAudit");
			throw new CometServiceException("[getOrderSummaryAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getOrderSummaryAudit -- Start");
		OrderSummaryBO orderSummaryBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_ORDER_SUMMARY_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(5, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(6, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(7, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(8, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(9, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(10, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(10);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}

			orderSummaryBO = orderAuditHelper.getOrderSummaryAuditInfo(orderId, spQuery);		
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting Order Summary Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getOrderSummaryAudit -- End");
		return orderSummaryBO;
	}

	@Transactional
	@Override
	public BillingDetailsBO getOrderBillingAudit(Long orderId, Long eventId) throws CometDataException, CometServiceException {
		if (CommonUtils.isNullEmpty(orderId) || CommonUtils.isNullEmpty(eventId)) {
			logger.info("Invalid request for getOrderBillingAudit");
			throw new CometServiceException("[getOrderBillingAudit] Neither orderId nor eventId can be null");
		}
		
		logger.debug("AuditServiceImpl::getOrderBillingAudit -- Start");
		BillingDetailsBO billingDetailsBO = null;
		
		try {
			StoredProcedureQuery spQuery = em.createStoredProcedureQuery(CometCommonConstant.GET_ORDER_BILLING_CONFIG_STORED_PROC);
			spQuery.registerStoredProcedureParameter(1, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
			spQuery.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);
			spQuery.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
			
			spQuery.setParameter(1, orderId);
			spQuery.setParameter(2, eventId);
			
			spQuery.execute();

			String errorMessage = (String) spQuery.getOutputParameterValue(4);
			if (CommonUtils.isValidString(errorMessage)) {
				throw new CometDataException("Error", errorMessage);
			}
			
			List<RowData> orderBillingConfigResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));

			billingDetailsBO = orderAuditHelper.getOrderBillingAuditInfo(orderId, orderBillingConfigResults);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[OrderID : " + (orderId == null ? "" : orderId)
					+ "] " + "Exception in Getting Billing Audit Info"
					+ e);
			throw new CometDataException("Error", e);
		}
		
		logger.debug("AuditServiceImpl::getOrderBillingAudit -- End");
		return billingDetailsBO;
	}
}
