package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for LdapDummy. Mapped to LDAPDUMMY table in the database.
 */
@Entity
@Table(name = "LDAPDUMMY")
public class LdapDummy implements Serializable {

	private static final long serialVersionUID = 4376436761226567786L;

	private String attuid;
	private String state;
	private String city;
	private String country;
	private String firstname;
	private String lastname;
	private String cellPhone;
	private Character active;
	private String deskPhone;
	private String email;
	private String streetAddress;
	private String zipCode;

	/**
	 * Getter method for attuid. ATTUID mapped to ATTUID in the database table.
	 * 
	 * @return String
	 */
	@Id
	@Column(name = "ATTUID", unique = true, nullable = false, length = 6)
	public String getAttuid() {
		return this.attuid;
	}

	/**
	 * @param attuid to attuid set.
	 */
	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}

	/**
	 * Getter method for state. STATE_NAME mapped to STATE_NAME in the database
	 * table.
	 * 
	 * @return
	 */
	@Column(name = "STATE_NAME", length = 100)
	public String getState() {
		return this.state;
	}

	/**
	 * @param state to state set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Getter method for city. CITY_NAME mapped to CITY_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CITY_NAME", length = 100)
	public String getCity() {
		return this.city;
	}

	/**
	 * @param city to city set.
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Getter method for country. COUNTRY_NAME mapped to COUNTRY_NAME in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "COUNTRY_NAME", length = 100)
	public String getCountry() {
		return this.country;
	}

	/**
	 * @param country to country set.
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Getter method for firstname. FIRSTNAME mapped to FIRSTNAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "FIRSTNAME", nullable = false, length = 20)
	public String getFirstname() {
		return this.firstname;
	}

	/**
	 * @param firstname to firstname set.
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * Getter method for lastname. LASTNAME mapped to LASTNAME in the database
	 * table.
	 * 
	 * @return
	 */
	@Column(name = "LASTNAME", nullable = false, length = 20)
	public String getLastname() {
		return this.lastname;
	}

	/**
	 * @param lastname to lastname set.
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * Getter method for cellPhone. CELL_PHONE mapped to CELL_PHONE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "CELL_PHONE", length = 10)
	public String getCellPhone() {
		return this.cellPhone;
	}

	/**
	 * @param cellPhone to cellPhone set.
	 */
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	/**
	 * Getter method for active. ACTIVE mapped to ACTIVE in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "ACTIVE", nullable = false, length = 1)
	public Character getActive() {
		return this.active;
	}

	/**
	 * @param active to active set.
	 */
	public void setActive(Character active) {
		this.active = active;
	}

	/**
	 * Getter method for deskPhone. DESK_PHONE mapped to DESK_PHONE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "DESK_PHONE", length = 100)
	public String getDeskPhone() {
		return this.deskPhone;
	}

	/**
	 * @param deskPhone to deskPhone set.
	 */
	public void setDeskPhone(String deskPhone) {
		this.deskPhone = deskPhone;
	}

	/**
	 * Getter method for email. EMAIL mapped to EMAIL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EMAIL", length = 100)
	public String getEmail() {
		return this.email;
	}

	/**
	 * @param email to email set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Getter method for streetAddress. STREET_ADDRESS mapped to STREET_ADDRESS in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "STREET_ADDRESS", length = 100)
	public String getStreetAddress() {
		return this.streetAddress;
	}

	/**
	 * @param streetAddress to streetAddress set.
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	/**
	 * Getter method for zipCode. ZIP_CODE mapped to ZIP_CODE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ZIP_CODE", length = 100)
	public String getZipCode() {
		return this.zipCode;
	}

	/**
	 * @param zipCode to zipCode set.
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

}