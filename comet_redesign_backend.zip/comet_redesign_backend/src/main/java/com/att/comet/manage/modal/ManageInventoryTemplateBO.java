package com.att.comet.manage.modal;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;
@Data
public class ManageInventoryTemplateBO implements Serializable{

	private static final long serialVersionUID = -8011690304832810757L;
	private String fileName;
	private String fileType;
	private String fileExt;
	private Map<Integer ,ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();
	private Map<String,Object> masterConfigMap = new HashMap<String,Object>();
}
