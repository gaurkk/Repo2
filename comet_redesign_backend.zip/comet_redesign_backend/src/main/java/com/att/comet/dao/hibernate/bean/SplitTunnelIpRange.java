package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for SplitTunnelIpRange. Mapped to SPLIT_TUNNEL_IP_RANGE
 * table in the database.
 */
@Entity
@Table(name = "SPLIT_TUNNEL_IP_RANGE")
public class SplitTunnelIpRange implements Serializable {

	private static final long serialVersionUID = 705635094984472981L;

	private Long splitTunnelIpRangeId;
	private Apn apn;
	private String splitTunnelIpRange;

	/**
	 * Getter method for splitTunnelIpRangeId. SPLIT_TUNNEL_IP_RANGE_ID mapped
	 * to SPLIT_TUNNEL_IP_RANGE_ID in the database table. The sequence used to
	 * generate the ssId is SEQ_SPLIT_TUNNEL_IP_RANGE_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "SPLIT_TUNNEL_IP_RANGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_SPLIT_TUNNEL_IP_RANGE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_SPLIT_TUNNEL_IP_RANGE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_SPLIT_TUNNEL_IP_RANGE_ID")
	public Long getSplitTunnelIpRangeId() {
		return splitTunnelIpRangeId;
	}

	/**
	 * @param splitTunnelIpRangeId
	 *            to splitTunnelIpRangeId set.
	 */
	public void setSplitTunnelIpRangeId(Long splitTunnelIpRangeId) {
		this.splitTunnelIpRangeId = splitTunnelIpRangeId;
	}

	/**
	 * Getter method for apn.
	 * 
	 * @return Apn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Apn getApn() {
		return this.apn;
	}

	/**
	 * @param apn
	 *            to apn set
	 */
	public void setApn(Apn apn) {
		this.apn = apn;
	}

	/**
	 * Getter method for splitTunnelIpRange. SPLIT_TUNNEL_IP_RANGE mapped to
	 * SPLIT_TUNNEL_IP_RANGE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SPLIT_TUNNEL_IP_RANGE", nullable = false, length = 100)
	public String getSplitTunnelIpRange() {
		return this.splitTunnelIpRange;
	}

	/**
	 * @param splitTunnelIpRange
	 *            to splitTunnelIpRange set.
	 */
	public void setSplitTunnelIpRange(String splitTunnelIpRange) {
		this.splitTunnelIpRange = splitTunnelIpRange;
	}
}