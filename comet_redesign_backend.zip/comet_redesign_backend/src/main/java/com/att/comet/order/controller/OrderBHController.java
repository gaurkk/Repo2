package com.att.comet.order.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.dao.hibernate.bean.Orders;
import com.att.comet.order.modal.AddBhInstanceBO;
import com.att.comet.order.modal.DataCenterBO;
import com.att.comet.order.modal.DelBhInstanceBO;
import com.att.comet.order.modal.InsideOutsideBaseInterfaceBO;
import com.att.comet.order.modal.OrderBHBO;
import com.att.comet.order.modal.ResetBhInstanceBO;
import com.att.comet.order.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderBHController {

	Logger logger = LoggerFactory.getLogger(OrderBHController.class);

	@Autowired
	OrderService orderServiceImpl;

	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;

	public static final String module = "BH";

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getdataCenterNameList/{isDummy}/{isFirstNet}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Data Center Name", notes = "Return all the Data Center Name")
	public CometResponse<List<StaticDataBO>> getDataCenterNameList(@PathVariable Character isDummy,
			@PathVariable String isFirstNet) throws CometDataException {
		logger.info("Starting method getDataCenterNameList : ", this);
		List<StaticDataBO> dcClass = new ArrayList<StaticDataBO>();
		List<DataCenterBO> dataCenterNameList = orderServiceImpl.getDataCenterNameList(isDummy, isFirstNet);
		if (!CollectionUtils.isEmpty(dataCenterNameList)) {
			List<KeyValueBO> keyValueList = dataCenterNameList.stream()
					.map(bo -> new KeyValueBO(bo.getDataCenterId().toString(), bo.getDataCenterName()))
					.collect(Collectors.toList());
			dcClass.add(new StaticDataBO(CometCommonConstant.DATACENTER_NAME, keyValueList));
		}
		cometResponse.setMethodReturnValue(dcClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getDataCenterNameList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getInOutInterfaceData/{dataCenterId}/{inOutBase}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find In Out Base Data", notes = "Get In Out Base Data")
	public CometResponse<InsideOutsideBaseInterfaceBO> getInOutInterfaceData(@PathVariable Long dataCenterId,@PathVariable String inOutBase)
			throws CometDataException {
		logger.info("[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] "+
				"[InOutBase : " + (inOutBase == null ? "" : inOutBase) + "] " +"Starting method getInOutInterfaceData :", this);
		CometResponse<InsideOutsideBaseInterfaceBO> cometResponse = new CometResponse<InsideOutsideBaseInterfaceBO>();
		InsideOutsideBaseInterfaceBO insideOutsideBaseInterfaceBO = null;
		try {
			insideOutsideBaseInterfaceBO = orderServiceImpl.getInOutBaseData(dataCenterId, inOutBase);
			if (insideOutsideBaseInterfaceBO == null) {
				logger.error("insideOutsideBaseInterfaceBO is EMPTY");
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
			cometResponse.setMethodReturnValue(insideOutsideBaseInterfaceBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] "+
				"[InOutBase : " + (inOutBase == null ? "" : inOutBase) + "] " +"Exiting method getInOutInterfaceData :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/order/getDCInOutInterfaceBase/{orderId}/{dataCenterId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Populate Data Center inside outside interface base using data center name", notes = "Get Data Center inside outside interface base values")
	public CometResponse<List<StaticDataBO>> getDCInOutInterfaceBase(@PathVariable Long orderId,
			@PathVariable Long dataCenterId) throws CometDataException {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+
				"[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] " +"Starting method getDCInOutInterfaceBase :", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> listData = new ArrayList<StaticDataBO>();
		try {

			List<String> populateInOutInterfaceBaseList = orderServiceImpl.getInOutInterfaceBaseList(orderId,
					dataCenterId);

			if (null != populateInOutInterfaceBaseList && populateInOutInterfaceBaseList.size() > 0) {
				List<KeyValueBO> keyValueList = populateInOutInterfaceBaseList.stream()
						.map(bo -> new KeyValueBO(bo, bo)).collect(Collectors.toList());
				listData.add(new StaticDataBO("IN_OUT_INTERFACE_BASE_LIST", keyValueList));
			}

			cometResponse.setMethodReturnValue(listData);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);

		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+
				"[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId) + "] " +"Exiting method getDCInOutInterfaceBase :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getBackhaulTypeList", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Backhaul Type List", notes = "Return all the Backhaul Type List")
	public CometResponse<List<StaticDataBO>> getBHTypeList() throws CometDataException {
		logger.info("Starting method getBHTypeList : ", this);
		List<StaticDataBO> dcClass = new ArrayList<StaticDataBO>();
		List<BackhaulTypeBO> backhaulTypeList = orderServiceImpl.getBackhaulTypeList();
		if (!CollectionUtils.isEmpty(backhaulTypeList)) {
			List<KeyValueBO> keyValueList = backhaulTypeList.stream()
					.map(bo -> new KeyValueBO(bo.getBackhaulTypeId().toString(), bo.getBackhaulTypeName()))
					.collect(Collectors.toList());
			dcClass.add(new StaticDataBO(CometCommonConstant.BACKHAUL_TYPE, keyValueList));
		}
		cometResponse.setMethodReturnValue(dcClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getBHTypeList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getBHTabInfo/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get BackHaul tab information", notes = "Get BackHaul tab information")
	public CometResponse<OrderBHBO> getOrderBHInfo(@PathVariable Long orderId) throws CometDataException {
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getOrderBHInfo :", this);
		CometResponse<OrderBHBO> cometResponse = new CometResponse<OrderBHBO>();
		OrderBHBO orderBackhaulBO = null;
		try {
			orderBackhaulBO = orderServiceImpl.getOrderBHTabInfo(orderId);
			if (null != orderBackhaulBO) {
				cometResponse.setMethodReturnValue(orderBackhaulBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				logger.error("orderBHBO is having null value for ORDER ID :: [" + orderId + "]", this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}

		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getOrderBHInfo :", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/addBhInstance", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add BH Instance", notes = "Return BH Instance")
	public CometResponse<AddBhInstanceBO> getAddBhInstance(@RequestBody AddBhInstanceBO addBhInstanceBO) {
		logger.info("[OrderID : " + (addBhInstanceBO.getOrderId() == null ? "" : addBhInstanceBO.getOrderId()) + "] "+ "Starting method getAddBhInstance :", this);
		CometResponse<AddBhInstanceBO> cometResponse = new CometResponse<AddBhInstanceBO>();
		AddBhInstanceBO bhBO = null;
		try {
			bhBO = orderServiceImpl.addBhInstance(addBhInstanceBO);
			if (null != bhBO) {
				cometResponse.setMethodReturnValue(bhBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (addBhInstanceBO.getOrderId() == null ? "" : addBhInstanceBO.getOrderId()) + "] "+ "Exiting method getAddBhInstance :", this);
		return cometResponse;

	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getDataCenterInfo/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get data center information list", notes = "Get DataCenter Information")
	public CometResponse<List<DataCenterBO>> getDataCenterInfo(@PathVariable Long orderId) throws CometDataException {
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getDataCenterInfo :", this);
		CometResponse<List<DataCenterBO>> cometResponse = new CometResponse<List<DataCenterBO>>();
		List<DataCenterBO> dataCenterBO = null;
		Orders order = null;
		try {
			dataCenterBO = orderServiceImpl.getDataCenterInfo(orderId,module,order);
			if (null != dataCenterBO) {
				cometResponse.setMethodReturnValue(dataCenterBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				logger.error("DataCenterBO is having null value for orderId :: [" + orderId + "]", this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getDataCenterInfo :", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "order/delBhInstance", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete BH Instance", notes = "Return BH Instance")
	public CometResponse<DelBhInstanceBO> deleteBackhaulInstance(@RequestBody DelBhInstanceBO delBhInstanceBO,
			@RequestParam(required = false) Boolean isIvpnMplsDelete, Authentication authentication) throws CometServiceException {
		logger.info("[OrderID : " + (delBhInstanceBO.getOrderId() == null ? "" : delBhInstanceBO.getOrderId()) + "] "
				+ "Starting method deleteBackhaulInstance :", this);
		CometResponse<DelBhInstanceBO> cometResponse = new CometResponse<DelBhInstanceBO>();
		DelBhInstanceBO bhBO = null;
		try {
			bhBO = orderServiceImpl.deleteBackhaulInstance(delBhInstanceBO, isIvpnMplsDelete, authentication);
			if (null != bhBO) {
				cometResponse.setMethodReturnValue(bhBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (delBhInstanceBO.getOrderId() == null ? "" : delBhInstanceBO.getOrderId()) + "] "
				+ "Exiting method deleteBackhaulInstance :", this);
		return cometResponse;

	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@PutMapping(value = "order/orderBHUpdate", produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Updated Backhaul Info", notes = "Update Backhaul Info")
	public CometResponse<OrderBHBO> updateOrderBH(@RequestBody OrderBHBO orderBackhaul, Authentication authentication) throws CometDataException, CometServiceException {
		logger.info("[OrderID : " + (orderBackhaul == null ? "" : orderBackhaul+""+ 
					authentication == null ? "" : authentication) + "] "+ "Starting method updateOrderBH :", this);
		CometResponse<OrderBHBO> cometResponse = new CometResponse<OrderBHBO>();
		if (orderBackhaul != null) {
			orderBackhaul = orderServiceImpl.updateOrderBackhaul(orderBackhaul, authentication);
			orderServiceImpl.deleteFirewallTuplesForChangeApnType(orderBackhaul.getOrderId(), true);  //Firewall Tuples deletion while changing in Apn Type //
			cometResponse.setMethodReturnValue(orderBackhaul);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			logger.error("No Data Found", this);
			throw new CometDataException("No Data Found to update Backhaul Tab");
		}
		
		logger.info("[OrderID : " + (orderBackhaul == null ? "" : orderBackhaul+""+ 
				authentication == null ? "" : authentication) + "] "+ "Exiting method updateOrderBH :", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/resetBhInstance", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Reset BH Instance", notes = "Return BH Instance")
	public CometResponse<ResetBhInstanceBO> resetBackhaulInstance(@RequestBody ResetBhInstanceBO resetBhInstanceBO) {
		logger.info("[OrderID : " + (resetBhInstanceBO == null ? "" : resetBhInstanceBO) + " ] "+ "Starting method resetBackhaulInstance :", this);
		CometResponse<ResetBhInstanceBO> cometResponse = new CometResponse<ResetBhInstanceBO>();
		ResetBhInstanceBO resetBhBO = null;
		try {
			resetBhBO = orderServiceImpl.resetBackhaulInstance(resetBhInstanceBO);
			if (null != resetBhBO) {
				cometResponse.setMethodReturnValue(resetBhBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (resetBhInstanceBO == null ? "" : resetBhInstanceBO) + " ] "+ "Exiting method resetBackhaulInstance :", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@GetMapping(value = "/order/backhaul/claimBackhaul/{orderId}/{backhaulDisplayId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get backhaul claim modification", notes = "Get  backhaul claim modification")
	public CometResponse<String> getClaimBackhaulModification(@PathVariable Long orderId,@PathVariable String backhaulDisplayId) throws CometDataException { 
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + " ] "
					+"[BackhaulDisplayId : " + (backhaulDisplayId == null ? "" : backhaulDisplayId) + " ] "+ "Starting method getClaimBackhaulModification :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();

		try {
			String claimBackhaul = orderServiceImpl.getClaimBackhaul(orderId,backhaulDisplayId);
			cometResponse.setMethodReturnValue(claimBackhaul);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + " ] "
				+"[BackhaulDisplayId : " + (backhaulDisplayId == null ? "" : backhaulDisplayId) + " ] "+ "Exiting method getClaimBackhaulModification :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/order/backhaul/checkClaimPossible/{orderId}/{backhaulDisplayId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get backhaul claim possible", notes = "Get backhaul claim possible")
	public CometResponse<Boolean> getCheckClaimPossible(@PathVariable Long orderId,@PathVariable String backhaulDisplayId) throws CometDataException { 
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + " ] "
				+"[BackhaulDisplayId : " + (backhaulDisplayId == null ? "" : backhaulDisplayId) + " ] "+ "Starting method getCheckClaimPossible :", this);
		CometResponse<Boolean> cometResponse = new CometResponse<Boolean>();

		try {
			boolean checkClaimPossible = orderServiceImpl.getCheckClaimPossible(orderId,backhaulDisplayId);
			cometResponse.setMethodReturnValue(checkClaimPossible);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);

		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + " ] "
				+"[BackhaulDisplayId : " + (backhaulDisplayId == null ? "" : backhaulDisplayId) + " ] "+ "Starting method getCheckClaimPossible :", this);
		return cometResponse;
	}
}
