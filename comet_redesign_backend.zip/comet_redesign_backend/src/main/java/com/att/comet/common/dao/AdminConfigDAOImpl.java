package com.att.comet.common.dao;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.StaticRoutingProtocol;
import com.att.comet.common.repository.AdminConfigInfoRepository;
import com.att.comet.common.repository.AdminConfigRepository;
import com.att.comet.common.repository.DataCenterNameRepository;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.AdminConfig;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.order.modal.DataCenterBO;

@Component
public class AdminConfigDAOImpl implements AdminConfigDAO {

	Logger logger = LoggerFactory.getLogger(AdminConfigDAOImpl.class);

	@Autowired
	AdminConfigInfoRepository adminConfigInfoRepository;

	@Autowired
	AdminConfigRepository adminConfigRepository;

	@Autowired
	DataCenterNameRepository dataCenterNameRepository;

	public AdminCategory findByCategoryId(Long adminCategoryId) {
		return adminConfigRepository.getAdminCategoryId(adminCategoryId);
	}

	public List<AdminConfigBO> getAdminConfigInfoList(Long adminCategoryId, String ccsmx, String dataCenterId) {
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[ccsmx : "
				+ (ccsmx == null ? "" : ccsmx) + "] " + "[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId)
				+ "] " + "Starting method getAdminConfigInfoList : ", this);
		List<AdminConfig> adminConfigList = null;
		AdminConfigBO adminConfigBO = null;
		List<AdminConfigBO> adminConfigInfoList = new ArrayList<AdminConfigBO>();
		if (adminCategoryId == 1038) {
			for (StaticRoutingProtocol stat : StaticRoutingProtocol.values()) {
				adminConfigBO = new AdminConfigBO();
				adminConfigBO.setCategoryId(stat.getId());
				adminConfigBO.setCategoryValue(stat.getYesOrNo());
				adminConfigInfoList.add(adminConfigBO);
			}
		} else {
			if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx) && StringUtils.isNotBlank(dataCenterId)) {
				adminConfigList = adminConfigInfoRepository
						.findByAdminCategory_adminCategoryIdAndCategoryValueContains(adminCategoryId, dataCenterId);
			} else {
				adminConfigList = adminConfigInfoRepository.findByAdminCategory_adminCategoryId(adminCategoryId);
			}

			if (!CollectionUtils.isEmpty(adminConfigList)) {
				for (AdminConfig adminCofig : adminConfigList) {
					adminConfigBO = new AdminConfigBO();
					if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx) && StringUtils.isBlank(dataCenterId)) {
						String categoryLastChar = adminCofig.getCategoryValue()
								.substring(adminCofig.getCategoryValue().length() - 1);
						if (ccsmx.trim().equalsIgnoreCase(categoryLastChar)) {
							String categoryValue = CommonUtils.replaceContent(adminCofig.getCategoryValue(),
									"@@$$@@" + ccsmx.toUpperCase().trim());
							adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
							adminConfigBO.setCategoryValue(categoryValue);
							adminConfigBO.setDescription(adminCofig.getDescription());
							adminConfigInfoList.add(adminConfigBO);
						}
					} else if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx)
							&& StringUtils.isNotBlank(dataCenterId)) {
						String categoryLastChar = adminCofig.getCategoryValue()
								.substring(adminCofig.getCategoryValue().length() - 1);
						if (ccsmx.trim().equalsIgnoreCase(categoryLastChar)) {
							String categoryValue = CommonUtils.replaceContent(adminCofig.getCategoryValue(),
									"@@$$@@" + dataCenterId.trim() + "@@$$@@" + ccsmx.toUpperCase().trim());
							adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
							adminConfigBO.setCategoryValue(categoryValue);
							adminConfigBO.setDescription(adminCofig.getDescription());
							adminConfigInfoList.add(adminConfigBO);
						}
					} else {
						adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
						adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
						adminConfigBO.setDescription(adminCofig.getDescription());
						adminConfigInfoList.add(adminConfigBO);
					}
				}

			} else {
				logger.info("" + "::Data Not Found For Admin Config Info List::", this);
				throw new RecordNotFoundException("Data Not Found For Admin Config Info List");
			}
		}
		if (adminConfigInfoList != null && !adminConfigInfoList.isEmpty()) {
			adminConfigInfoList = adminConfigInfoList.stream()
					.sorted(Comparator.comparing(AdminConfigBO::getCategoryValue)).collect(Collectors.toList());
		}
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] " + "[ccsmx : "
				+ (ccsmx == null ? "" : ccsmx) + "] " + "[DataCenterId : " + (dataCenterId == null ? "" : dataCenterId)
				+ "] " + "Exiting method getAdminConfigInfoList : ", this);
		return adminConfigInfoList;

	}

	public AdminCategory findMarketSegmentByCategoryId(Long adminCategoryId) {
		return adminConfigRepository.getAdminCategoryId(adminCategoryId);
	}

	@Override
	public AdminConfigBO getDefaultAdminConfigInfo(Long adminCategoryId) {
		return getDefaultAdminConfigInfo(adminCategoryId, null, null);
	}

	@Override
	public AdminConfigBO getDefaultAdminConfigInfo(Long adminCategoryId, String ccsmx, String dataCenterId) {
		logger.info("[AdminCategoryId : " + (adminCategoryId == null ? "" : adminCategoryId) + "] "
				+ "Starting method getDefaultAdminConfigInfo : ", this);
		List<AdminConfig> adminConfigList = null;
		if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx) && StringUtils.isNotBlank(dataCenterId)) {
			adminConfigList = adminConfigInfoRepository
					.findByAdminCategory_adminCategoryIdAndDefaultValueAndCategoryValueContainsOrderByAdminConfigIdDesc(
							adminCategoryId, 'Y', dataCenterId);
		} else {
			adminConfigList = adminConfigInfoRepository
					.findByAdminCategory_adminCategoryIdAndDefaultValueOrderByAdminConfigIdDesc(adminCategoryId, 'Y');
		}
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigList)) {
			for (AdminConfig adminCofig : adminConfigList) {
				adminConfigBO = new AdminConfigBO();
				if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx) && StringUtils.isBlank(dataCenterId)) {
					String categoryLastChar = adminCofig.getCategoryValue()
							.substring(adminCofig.getCategoryValue().length() - 1);
					if (ccsmx.trim().equalsIgnoreCase(categoryLastChar)) {
						String categoryValue = CommonUtils.replaceContent(adminCofig.getCategoryValue(),
								"@@$$@@" + ccsmx.toUpperCase().trim());
						adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
						adminConfigBO.setCategoryValue(categoryValue);
						adminConfigBO.setDescription(adminCofig.getDescription());
						break;
					}
				} else if (adminCategoryId != null && StringUtils.isNotBlank(ccsmx)
						&& StringUtils.isNotBlank(dataCenterId)) {
					String categoryLastChar = adminCofig.getCategoryValue()
							.substring(adminCofig.getCategoryValue().length() - 1);
					if (ccsmx.trim().equalsIgnoreCase(categoryLastChar)) {
						String categoryValue = CommonUtils.replaceContent(adminCofig.getCategoryValue(),
								"@@$$@@" + dataCenterId.trim() + "@@$$@@" + ccsmx.toUpperCase().trim());
						adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
						adminConfigBO.setCategoryValue(categoryValue);
						adminConfigBO.setDescription(adminCofig.getDescription());
						break;
					}
				} else {
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					break;
				}
			}
		} else {
			logger.debug("No data found in AdminConfig against AdminCategoryId : " + adminCategoryId, this);
		}
		logger.debug("Exiting method getDefaultAdminConfigInfo", this);
		return adminConfigBO;
	}

	@Override
	public List<DataCenterBO> getDataCenterNameList() {
		logger.info("Starting method getDataCenterNameList : ", this);
		List<DataCenter> dataCenterList = dataCenterNameRepository.findByDummy('N');
		List<DataCenterBO> dcTypeList = new ArrayList<DataCenterBO>();
		DataCenterBO dcTypeBO = null;
		for (DataCenter dcName : dataCenterList) {
			if (dcName != null) {
				dcTypeBO = new DataCenterBO();
				dcTypeBO.setDataCenterId(dcName.getDataCenterId());
				dcTypeBO.setDataCenterName(dcName.getDataCenterName());
				dcTypeList.add(dcTypeBO);
			}
		}
		logger.info("Exiting method getDataCenterNameList : ", this);
		return dcTypeList;
	}
}
