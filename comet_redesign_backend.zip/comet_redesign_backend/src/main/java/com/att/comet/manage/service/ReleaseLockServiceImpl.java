package com.att.comet.manage.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.OrderUserTrackerBO;
import com.att.comet.common.modal.OrderUserTrackerLogBO;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.OrderUserQueue;
import com.att.comet.manage.modal.ReleaseLockBO;
import com.att.comet.manage.modal.ReleaseLockResponseBO;
import com.att.comet.order.dao.OrderConstants;
import com.att.comet.order.helper.OrderHelper;
import com.att.comet.order.helper.OrderLockHelper;
import com.att.comet.order.modal.OrderUserQueueBO;
import com.att.comet.order.repository.OrderUserQueueRepository;

import eu.bitwalker.useragentutils.UserAgent;

@Service
public class ReleaseLockServiceImpl implements ReleaseLockService {
	private static final Logger logger = LoggerFactory.getLogger(ReleaseLockServiceImpl.class);
	
	@Autowired
	OrderUserQueueRepository orderUserQueueRepository;
	
	@Autowired
	OrderLockHelper orderLockHelper;
	
	@Autowired
	OrderHelper orderHelper;
	
	@Override
	@Transactional
	public ReleaseLockResponseBO getAllRequestLocks(String attuid) {
		logger.debug("ReleaseLockServiceImpl::ReleaseLockBO Getting all request lock orders");
		
		Timestamp currentTime = new Timestamp(new Date().getTime());
		
		List<OrderUserQueue> orderUserQueueList = orderUserQueueRepository
				.findByHistryFlgAndUserEndTimeGreaterThanOrderByUserEndTime(OrderConstants.GET_ORDR_USER_ACTIVE_FLAG, 
																			currentTime);
		List<OrderUserQueue> requestLockList = new ArrayList<OrderUserQueue>();
		
		for (OrderUserQueue orderUserQueue : orderUserQueueList) {
			if (null != orderUserQueue.getLockReqBy()) {
				requestLockList.add(orderUserQueue);
			}
		}
		
		List<OrderUserQueueBO> orderUserQueueBOList = this.populateReleaseLockBOs(requestLockList);
		
		ReleaseLockResponseBO releaseLockResponseBO = new ReleaseLockResponseBO();
		
		if (null != orderUserQueueBOList && !orderUserQueueBOList.isEmpty()) {
			// Prepare the Set of orderIds where Request Lock button should be displayed
			Set<Long> reqLockOrderIds = new HashSet<Long>();
			
			// Add the orderId into set if logged-in user != lockReqBy and if absent
			for (OrderUserQueueBO OrderUserQueue : orderUserQueueBOList) {
				if (!attuid.equalsIgnoreCase(OrderUserQueue.getLockReqBy())) {
					reqLockOrderIds.add(OrderUserQueue.getOrderId());
				}
			}
			
			// Remove the orderId from set if logged-in user == lockReqBy and if present
			for (OrderUserQueueBO OrderUserQueue : orderUserQueueBOList) {
				if (attuid.equalsIgnoreCase(OrderUserQueue.getLockReqBy())) {
					reqLockOrderIds.remove(OrderUserQueue.getOrderId());
				}
			}
			
			releaseLockResponseBO.setOrderUserQueues(orderUserQueueBOList);
			releaseLockResponseBO.setReqLockOrderIds(reqLockOrderIds);
		}
		
		return releaseLockResponseBO;
	}
	
	@Override
	@Transactional
	public List<OrderUserQueueBO> getRequestLocksByOrderId(long orderId) throws CometServiceException {
		logger.debug("ReleaseLockServiceImpl::getAllLocksByOrderId Getting locks by order ID: " + orderId);
		
		if(CommonUtils.isNullEmpty(orderId)) {
			logger.info("Order ID does not exist");
			throw new CometServiceException("Order ID does not exist");
		}
		
		Timestamp currentTime = new Timestamp(new Date().getTime());
		
		List<OrderUserQueue> orderUserQueueList = orderUserQueueRepository
			.findByOrderIdAndHistryFlgAndUserEndTimeGreaterThanOrderByUserEndTime(orderId, 
																				OrderConstants.GET_ORDR_USER_ACTIVE_FLAG, 
																				currentTime);
		
		List<OrderUserQueue> requestLockList = new ArrayList<OrderUserQueue>();
		
		for (OrderUserQueue orderUserQueue : orderUserQueueList) {
			if (null != orderUserQueue.getLockReqBy()) {
				requestLockList.add(orderUserQueue);
			}
		}
		List<OrderUserQueueBO> orderUserQueueBOList = this.populateReleaseLockBOs(requestLockList);
				
		return orderUserQueueBOList;
	}
			
	@Override
	@Transactional
	public Boolean releaseLock(ReleaseLockBO releaseLockBO, HttpServletRequest request) 
									throws CometServiceException {
		if (null == releaseLockBO || null == request) {
			logger.info("Invalid request");
			throw new CometServiceException("Invalid request");
		}
	
		OrderUserQueueBO orderUserQueueBO = releaseLockBO.getOrderUserQueue();
		long orderId = orderUserQueueBO.getOrderId();
		logger.debug("ReleaseLockServiceImpl::releaseLock Releasing lock for order ID: " + orderId);
		
		Boolean isReleaseSuccess = false;
		try {
			orderLockHelper.userOrderReleaseLock(orderUserQueueBO);
			isReleaseSuccess = true;
		} catch (Exception e) {
			throw new CometServiceException("Exception during releasing lock for order ID: " + orderId);
		} finally{
			try{
				OrderUserTrackerBO orderUserTrackerBO = releaseLockBO.getOrderUserTracker();

				orderUserTrackerBO.setAction("RELEASE_ORDER_LOCK");
				orderUserTrackerBO.setTabName("ADMIN_RELEASE");
				if (CommonUtils.isNullEmpty(orderUserTrackerBO.getContentType())) {
					orderUserTrackerBO.setContentType(null);
				}
				if (CommonUtils.isNullEmpty(orderUserTrackerBO.getHttpMethod())) {
					orderUserTrackerBO.setHttpMethod("PUT");
				}
				
				String ipAddr = Optional.ofNullable(request.getHeader("X-FORWARDED-FOR")).orElse(request.getRemoteAddr());
				if (ipAddr.equals("0:0:0:0:0:0:0:1")) {  // Check for rest clients like postman
					ipAddr = "127.0.0.1";
				}
				
				UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
				String browserName = "Unknown";
				String osName = "Unknown";
				if (null != userAgent) {
					if (null != userAgent.getBrowser()) {
						browserName = userAgent.getBrowser().getName(); 
					}
					
					if (null != userAgent.getOperatingSystem()) {
						osName = userAgent.getOperatingSystem().getName(); 
					}
				}
				String browserInfo = "OS : " + osName + ", Browser : " + browserName;
				
				orderUserTrackerBO.setIpAddr(ipAddr);
				orderUserTrackerBO.setBrowser(browserInfo);
				orderUserTrackerBO.setHttpStatusCode(null);
				orderUserTrackerBO.setTrackId(UUID.randomUUID().toString());
				orderUserTrackerBO.setAccessOn(new Date());

				orderHelper.registerOrderUserTracking(orderUserTrackerBO);
				OrderUserTrackerLogBO orderUserTrackerLogBO = orderHelper.populateOrderUserTrackerLogBO(orderUserTrackerBO);
				orderHelper.registerOrderUserTrackingLog(orderUserTrackerLogBO);
			} catch(Exception exception) {
					exception.printStackTrace();
					logger.error("[OrderID : " + orderId + "] "+ exception.getStackTrace());
					logger.error("[OrderID : " + orderId + "] "+"Order usertracker" + exception.getMessage());
					throw new CometServiceException("Order usertracker exception during releasing lock for order ID: " + orderId);
				}
			}

		return isReleaseSuccess;
	}
	
	private List<OrderUserQueueBO> populateReleaseLockBOs(List<OrderUserQueue> orderUserQueueList) {
		logger.info("ReleaseLockServiceImpl::populateReleaseLockBOs Start");
		
		if (null == orderUserQueueList || orderUserQueueList.isEmpty()) {
			return null;
		}
		
		List<OrderUserQueueBO> orderUserQueueBOList = new ArrayList<OrderUserQueueBO>();
		
		orderUserQueueList.forEach(orderUserQueue -> {
			OrderUserQueueBO orderUserQueueBO = orderLockHelper.populateOrderUserQueueBO(orderUserQueue);
			orderUserQueueBOList.add(orderUserQueueBO);
		});
		
		return orderUserQueueBOList;
	}
}
