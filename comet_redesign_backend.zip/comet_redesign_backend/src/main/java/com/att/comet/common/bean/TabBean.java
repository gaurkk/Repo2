package com.att.comet.common.bean;

import java.io.Serializable;

/**
 * TabBean class implements he interface Comparable. The class is used for
 * segregating different tabs of the COMET application.
 */
public class TabBean implements Comparable<TabBean>, Serializable {

	private static final long serialVersionUID = 1090913606489161112L;
	
	private Long id;
	private String name;
	private Integer displayOrder;
	boolean readOnlyFlag =false;

	/**
	 * Multiple argument of the constructor.
	 * 
	 * @param id
	 * @param displayOrder
	 */
	public TabBean(Long id, Integer displayOrder) {
		super();
		this.id = id;
		this.displayOrder = displayOrder;
	}

	/**
	 * Multiple argument constructor of the class.
	 * 
	 * @param id
	 * @param displayOrder
	 * @param name
	 * @param form
	 * @param openAction
	 * @param saveAction
	 */
	public TabBean(Long id, Integer displayOrder, String name) {
		super();
		this.id = id;
		this.displayOrder = displayOrder;
		this.name = name;		
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	


	/**
	 * @return the displayOrder
	 */
	public Integer getDisplayOrder() {
		return displayOrder;
	}

	/**
	 * @param displayOrder
	 *            the displayOrder to set
	 */
	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "{name: \"" + name + "\", id: \"" + id + "\"}";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TabBean other = (TabBean) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(TabBean o) {
		return displayOrder.compareTo(((TabBean) o).displayOrder);
	}
}
