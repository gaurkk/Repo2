package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.BpmOrderWorkStep;
import com.att.comet.dao.hibernate.bean.BpmOrderWorkStepId;

@Repository
public interface BpmOrderWorkStepRepository extends JpaRepository<BpmOrderWorkStep, BpmOrderWorkStepId> {
	
	BpmOrderWorkStep findByOrders_orderIdAndBpmWorkStep_workStepId_AndOrderType_orderTypeId(Long orderId, Long workStepId,Long orderTypeId);

}
