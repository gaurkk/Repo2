package com.att.comet.manage.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.AdminCategoryBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CityBO;
import com.att.comet.common.modal.CountryBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.StateBO;
import com.att.comet.dao.hibernate.bean.DapnInventory;
import com.att.comet.dao.hibernate.bean.DapnUploadStatus;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnInventory;
import com.att.comet.dao.hibernate.bean.InsideOutsideBaseInterface;
import com.att.comet.dao.hibernate.bean.InsideOutsideStgPatInterface;
import com.att.comet.manage.modal.AdminConfigParamBO;
import com.att.comet.manage.modal.InventoryTemplateBO;
import com.att.comet.manage.modal.LineBO;
import com.att.comet.manage.modal.MasterAdminCategoryBO;
import com.att.comet.manage.modal.ParseResultBO;

public interface ManageDAO {

	List<InsideOutsideStgPatInterface> getInsideOutsidePAT(Long dataCenterId);

	List<ImsiMsisdnInventory> getImsiMsisdn(Long dataCenterId);

	List<InsideOutsideBaseInterface> getInOutBaseInterface(Long dataCenterId);

	List<DapnInventory> getDapnInventory(Long dataCenterId);

	public List<InventoryTemplateBO> downloadManageInventoryTemplate(String inventory);

	List<InventoryTemplateBO> getInventoryNameList();

	public ParseResultBO saveInOutStgPATs(ParseResultBO parseResultBO);

	public ParseResultBO saveINOUTInterfaceFile(ParseResultBO parseResultBO, LineBO lineBo)
			throws CometDataException, CometServiceException;

	public ParseResultBO saveImsiMsisdnFile(ParseResultBO resultBO) throws CometDataException, CometServiceException;

	public ParseResultBO saveRDRTFile(ParseResultBO resultBO) throws CometDataException, CometServiceException;

	public ParseResultBO updateINOUTInterfaceFile(ParseResultBO resultBO, LineBO lineBo)
			throws CometDataException, CometServiceException;

	public ParseResultBO updateImsiMsisdnFile(ParseResultBO resultBO) throws CometDataException, CometServiceException;
	
	public void insertDapnRecords(List<LineBO> dapnBO, String attuId,	long  status) throws CometDataException, ParseException;
	
	public List<DapnUploadStatus> getDapnUploadResultMessage(String batchId);
	
	public String validateDapnRecords() throws CometDataException, SQLException;
	
	public List<CountryBO> getCountryList() throws CometDataException;

	public List<StateBO> getStateList(Long countryId) throws CometDataException;

	public List<CityBO> getCityList(Long stateId, String criteria) throws CometDataException;

	public String saveAndUpdateCountryName(CountryBO countryBO) throws CometDataException, CometServiceException;

	public String saveDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;

	List<MasterAdminCategoryBO> getCategoryInfo() throws CometDataException;
	
	public List<StateBO> getState() throws CometDataException;

	AdminCategoryBO getConfigInfo(AdminConfigParamBO adminConfigParamBO) throws CometDataException;

	public String delDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;

	public String deleteCountryName(Long countryId) throws CometDataException, CometServiceException;

	boolean addConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException;

	boolean updateConfigInfo(AdminConfigBO adminConfigBO) throws CometDataException;

	boolean deleteConfigInfo(Long configId) throws CometDataException;

	List<OrderStatusBO> getOrderStatusList() throws CometDataException;

	boolean updateOrderStatus(OrderStatusBO orderStatusBO) throws CometDataException;
	
	public String updateDataCenter(DataCenterBO dataCenterBO) throws CometDataException, CometServiceException;
	
	public String deleteStateName(Long stateId)throws CometDataException, CometServiceException;

	public String deleteCityName(Long cityId)throws CometDataException, CometServiceException;
	
	public List<CityBO> getCity(Long countryId, Long stateId)throws CometDataException, CometServiceException;
	
	public String saveAndUpdateStateName(StateBO stateBO) throws CometServiceException, CometDataException;
	
	public String saveAndUpdateCityName(CityBO cityBO) throws CometServiceException, CometDataException;
	
	public DataCenterBO getDataCenterInfo(Long dcId) throws CometServiceException, CometDataException;
	
	public StateBO getStateById(long stateId) throws CometDataException, CometServiceException;
	
	public CityBO getCityById(long cityId) throws CometDataException, CometServiceException;

}
