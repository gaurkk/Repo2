package com.att.comet.apn;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class PatPoolAddressBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 4753219048236469196L;

	private Long dataCenterId;

	private String dataCenterName;

	private String ipAddress;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;

	private Long seq;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long patPoolAddressId;

}
