package com.att.comet.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.City;
import com.att.comet.dao.hibernate.bean.State;

@Repository
public interface CityRepository extends JpaRepository<City,Long>{
	@Query("select distinct cityId, cityName from City where state.stateId = :stateId AND cityName LIKE %:criteria%")
	List<String> getCityNameList(Long stateId, String criteria);
	
	City findByStateStateIdAndCityName(Long stateId, String cityName);
	
	List<City> findByState_StateId(Long countryId);
	
	Optional<City> findByCityName(String cityName);
}
