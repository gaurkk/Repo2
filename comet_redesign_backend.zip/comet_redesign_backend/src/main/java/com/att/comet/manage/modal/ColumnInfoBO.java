package com.att.comet.manage.modal;
import java.io.Serializable;

import lombok.Data;
@Data
public class ColumnInfoBO implements Serializable{
	private static final long serialVersionUID = 1228643134940149708L;
	private String columnName;
	private String columnType;
	private boolean isMandatory;
}
