package com.att.comet.dao;

public class ChartsSqlConstants {

	/**
	 * Scalar constant for return column attuid. Used to get result of returned
	 * column by native sql.
	 */
	public static final String BASE_QUERY_FOR_BARCHART = "select nvl(oci.attuid,'Unassigned') as userid, count(o.order_id) as count from orders o, order_contact oc, order_contact_info oci, order_contact_type oct \r\n"
			+ "		where o.order_id = oc.order_id \r\n"
			+ "		and o.order_status_id in (1002,1004,1005,1006,1007,1011,1012,1013,1045,1046,1047,1048) \r\n"
			+ "		and o.order_type_id not in (1002,1006)\r\n"
			+ "		and oc.order_contact_id = oci.order_contact_id \r\n"
			+ "		and oci.order_contact_type_id = oct.order_contact_type_id";

	public static final String BASE_QUERY_FOR_PIECHART = "select 'Reviews and Approvals' AS status, count(distinct o.order_id) as count, 'color:#F79800' AS color from orders o, order_account oa, order_contact oc,  order_contact_info oci  \r\n"
			+ "			where o.order_id = oa.order_id (+) \r\n" + "			and o.order_id = oc.order_id (+) \r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id\r\n"
			+ "			and o.order_status_id in (1002,1004,1005,1006,1007,1011,1012) \r\n"
			+ "			and o.order_type_id not in (1002,1006)\r\n" + "			UNION ALL \r\n"
			+ "			select 'Implementation in Progress' AS status, count(distinct o.order_id) as count, 'color:#F8C061' AS color from orders o , order_account oa, order_contact oc,  order_contact_info oci \r\n"
			+ "			where o.order_id = oa.order_id (+) \r\n" + "			and o.order_id = oc.order_id (+) \r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id\r\n"
			+ "			and o.order_status_id in (1045,1046) \r\n"
			+ "			and o.order_type_id not in (1002,1006)\r\n" + "			UNION ALL \r\n"
			+ "			select 'On-hold' AS status, count(distinct o.order_id) as count, 'color:#F8E8C7' AS color from orders o , order_account oa, order_contact oc,  order_contact_info oci\r\n"
			+ "			where o.order_id = oa.order_id(+) \r\n" + "			and o.order_id = oc.order_id (+) \r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id\r\n"
			+ "			and o.order_status_id in (1067) \r\n" + "			and o.order_type_id not in (1002,1006)\r\n"
			+ "			UNION ALL \r\n"
			+ "			select 'Post Implementation Complete' AS status, count(distinct o.order_id) as count, 'color:#EDDE11' AS color from orders o , order_account oa, order_contact oc,  order_contact_info oci\r\n"
			+ "			where o.order_id = oa.order_id(+) \r\n" + "			and o.order_id = oc.order_id (+) \r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id\r\n"
			+ "			and o.order_status_id in (1013,1047,1048) \r\n"
			+ "			and o.order_type_id not in (1002,1006)";

	public static final String BASE_QUERY_FOR_PIECHART_OF_DC_CONSUMPTION = "select count (distinct apn_name) as count, '@@' AS data_center_name from (\r\n"
			+ "				select distinct o.order_id, (case when apn.apn_name is null then 'APN not created ' || o.order_id else apn.apn_name end) as apn_name\r\n"
			+ "				from orders o, order_data_center odc, apn apn, data_center dc, \r\n"
			+ "				order_data_center_backhaul odcb, backhaul b\r\n"
			+ "				where o.order_id = apn.order_id(+)\r\n"
			+ "				and   o.order_id = odc.order_id(+)\r\n"
			+ "				and   odc.order_id = apn.order_id\r\n"
			+ "				and   dc.data_center_id = odc.data_center_id\r\n"
			+ "				and   get_apn_status(o.order_id) in ('In Progress', 'In Production')\r\n"
			+ "				and o.order_id = odcb.order_id(+)\r\n"
			+ "			    and odcb.backhaul_id = b.backhaul_id(+)\r\n"
			+ "				and   odc.data_center_id in (?) \r\n" + "				@RESTRICTION ";

	public static final String BASE_QUERY_FOR_STACKEDCOLUMNCHART = "WITH next_days AS\r\n"
			+ "  (SELECT sysdate + level AS the_date FROM dual CONNECT BY level <= 10\r\n" + "  )\r\n"
			+ "SELECT TO_CHAR(THE_DATE,'Mon-dd') AS THE_DATE,\r\n"
			+ "  NVL(t.ALL_COUNT,0)              AS ALL_COUNT ,\r\n"
			+ "  NVL(t.user_count,0)             AS USER_COUNT\r\n" + "FROM next_days n\r\n" + "LEFT JOIN\r\n"
			+ "  (SELECT to_date(NVL(B.DT,A.DT), 'dd-mm-yyyy') AS DT,\r\n"
			+ "    B.ALL_COUNT                                 AS ALL_COUNT,\r\n"
			+ "    A.USER_COUNT                                AS user_count\r\n" + "  FROM\r\n"
			+ "    (SELECT DISTINCT TO_CHAR(obs.business_step_executed_on,'dd-mm-yyyy') DT ,\r\n"
			+ "      NULL AS All_count,\r\n"
			+ "      COUNT(DISTINCT o.order_id) over(partition BY oci.attuid,TO_CHAR(obs.business_step_executed_on,'dd-mm-yyyy')) user_count\r\n"
			+ "    FROM bpm_order_business_step obs,\r\n" + "      orders o,\r\n" + "      order_contact oc,\r\n"
			+ "      order_contact_info oci\r\n"
			+ "    WHERE obs.business_step_executed_on BETWEEN TRUNC(sysdate) + 1 AND TRUNC(sysdate) +11\r\n"
			+ "    @STEPID\r\n" + "    AND obs.attuid IN @USER\r\n" + "    AND obs.attuid          IS NOT NULL\r\n"
			+ "    AND obs.order_id         =o.order_id\r\n" + "    AND o.order_id           = oc.order_id\r\n"
			+ "    AND oc.order_contact_id  =oci.order_contact_id\r\n"
			+ "    AND o.order_status_id   IN (1002,1004,1005,1006,1007,1011,1012,1013,1045,1046,1047,1048)\r\n"
			+ "    AND o.order_type_id NOT IN (1002,1006)\r\n" + "    AND obs.attuid           = oci.attuid\r\n"
			+ "    ) A\r\n" + "  FULL OUTER JOIN\r\n"
			+ "    ( SELECT DISTINCT TO_CHAR(obs.business_step_executed_on,'dd-mm-yyyy') DT ,\r\n"
			+ "      COUNT(DISTINCT o.order_id) over(partition BY oci.attuid,TO_CHAR(obs.business_step_executed_on,'dd-mm-yyyy')) All_count,\r\n"
			+ "      NULL AS Total_Count\r\n" + "    FROM bpm_order_business_step obs,\r\n" + "      orders o,\r\n"
			+ "      order_contact oc,\r\n" + "      order_contact_info oci\r\n"
			+ "    WHERE obs.business_step_executed_on BETWEEN TRUNC(sysdate) + 1 AND TRUNC(sysdate) +11\r\n"
			+ "    @STEPID\r\n" + "    AND obs.attuid NOT IN @USER\r\n" + "    AND obs.attuid          IS NOT NULL\r\n"
			+ "    AND obs.order_id         =o.order_id\r\n" + "    AND o.order_id           = oc.order_id\r\n"
			+ "    AND oc.order_contact_id  =oci.order_contact_id\r\n"
			+ "    AND o.order_status_id   IN (1002,1004,1005,1006,1007,1011,1012,1013,1045,1046,1047,1048)\r\n"
			+ "    AND o.order_type_id NOT IN (1002,1006)\r\n" + "    AND obs.attuid           = oci.attuid\r\n"
			+ "    ) B\r\n" + "  ON a.dt                       =b.dt\r\n"
			+ "  ) t ON TO_CHAR(t.dt ,'Mon-dd')= TO_CHAR(n.THE_DATE,'Mon-dd')\r\n" + "ORDER BY n.THE_DATE";

	public static final String BASE_QUERY_FOR_GRID = "select  distinct o.order_id , nvl(sa.sub_account_name,ipa.internal_product_account_name) as sub_account_name ,\r\n"
			+ "			ap.apn_name,ot.order_type_name, os.order_status_name, \r\n"
			+ "			TO_char(o.created_on,'mm/dd/yyyy') AS created_on ,  \r\n"
			+ "			NVL((select case when (sysdate - (SLA_Working_Day(io.submitted_on,25383) - 6) > 0) then 2 ELSE 1 end  as iflag\r\n"
			+ "			from orders io   where io.order_id = o.order_id\r\n"
			+ "			and exists (       select 1 from bpm_order_work_step ows, bpm_order_business_step obs, \r\n"
			+ "			bpm_business_step bs where ows.order_id = o.order_id and   obs.order_id = o.order_id and ows.work_step_id = bs.work_step_id	\r\n"
			+ "			and bs.business_step_id = obs.business_step_id and lower(bs.business_step_name) like '%reminder%'	\r\n"
			+ "			and ows.bpm_status_id = 1001)),0) as flag\r\n"
			+ "			from orders o,sub_account sa , order_account oa, order_contact oc, order_contact_info oci, apn ap, order_type ot, \r\n"
			+ "			order_status os, bpm_order_business_step obs , internal_product_account ipa  \r\n"
			+ "			where o.order_status_id in (1002,1004,1005,1006,1007,1011,1012,1013,1045,1046,1047,1048,1067) \r\n"
			+ "			and o.order_type_id not in (1002,1006)\r\n"
			+ "			and o.bcid = sa.bcid (+) and o.cipn = ipa.cipn (+) \r\n"
			+ "			and o.order_id = oa.order_id (+)\r\n" + "			and o.order_id = ap.order_id (+)\r\n"
			+ "			and o.order_type_id = ot.order_type_id \r\n"
			+ "			and o.order_status_id = os.order_status_id \r\n"
			+ "			and o.order_id = oc.order_id (+) \r\n" + "			and o.order_id = obs.order_id (+)\r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id ";

	public static final String BASE_QUERY_FOR_DC_CONSUMPTION_GRID = "select  distinct o.order_id , nvl(sa.sub_account_name,ipa.internal_product_account_name) as sub_account_name ,\r\n"
			+ "			ap.apn_name,ot.order_type_name, os.order_status_name, \r\n"
			+ "			TO_char(o.created_on,'mm/dd/yyyy') AS created_on ,  open_reminders(o.order_id) as flag\r\n"
			+ "			from orders o,sub_account sa , order_account oa, order_contact oc, order_contact_info oci, apn ap, order_type ot, \r\n"
			+ "			order_status os, bpm_order_business_step obs , internal_product_account ipa ,order_data_center odc , data_center dc,\r\n"
			+ "      		order_data_center_backhaul odcb, backhaul b\r\n"
			+ "			where get_apn_status(o.order_id) in ('In Progress', 'In Production')\r\n"
			+ "			and o.bcid = sa.bcid (+) and o.cipn = ipa.cipn (+) \r\n"
			+ "			and o.order_id = oa.order_id (+)\r\n" + "			and o.order_id = ap.order_id (+)\r\n"
			+ "			and o.order_type_id = ot.order_type_id \r\n"
			+ "			and o.order_status_id = os.order_status_id \r\n"
			+ "			and o.order_id = oc.order_id (+) \r\n" + "			and o.order_id = obs.order_id (+)\r\n"
			+ "			and oc.order_contact_id  = oci.order_contact_id \r\n"
			+ "   			and o.order_id = odc.order_id(+)\r\n" + "			and odc.order_id = ap.order_id\r\n"
			+ "			and dc.data_center_id = odc.data_center_id\r\n"
			+ "		    and o.order_id = odcb.order_id(+)\r\n" + "		    and odcb.backhaul_id = b.backhaul_id(+)";
	
	public static final String BASE_QUERY_FOR_COLUMNCHART = "WITH allmonths AS \r\n" + 
			"			(select to_char(add_months(trunc(sysdate, 'yyyy'), level - 1), 'Mon') month\r\n" + 
			"      		from dual connect by level <= 12 ) \r\n" + 
			"			SELECT month, nvl(t.count,0) as count\r\n" + 
			"			FROM allmonths n \r\n" + 
			"			LEFT JOIN \r\n" + 
			"			(\r\n" + 
			"		      select to_char(trunc(o.date_in_production,'Mon'),'Mon') as sysmonth, count(o.order_id) as count from orders o \r\n" + 
			"		      where o.order_status_id in (1009,1063,1064,1065,1066) @YEAR group by to_char(trunc(o.date_in_production,'Mon'),'Mon')		     	\r\n" + 
			"		    ) t ON t.sysmonth = n.month \r\n" + 
			"		      order by to_date(month,'mon')";
	
	public static final String BASE_QUERY_FOR_LINECHART = "WITH allmonths AS \r\n" + 
			"			(select to_char(add_months(trunc(sysdate, 'yyyy'), level - 1), 'Mon') month\r\n" + 
			"			  from dual connect by level <= 12 ) \r\n" + 
			"				SELECT month, nvl(t.avg_ordersum_implecompl,0) AS avg_ordersum_implecompl, \r\n" + 
			"				nvl(t.avg_ordersum_ttupass,0) AS avg_ordersum_ttupass, \r\n" + 
			"				nvl(t.avg_osdappr_implecompl,0) AS avg_osdappr_implecompl\r\n" + 
			"				FROM allmonths n \r\n" + 
			"				LEFT JOIN \r\n" + 
			"				(SELECT A.DT AS DT, A.avg_ordersum_implecompl AS avg_ordersum_implecompl, \r\n" + 
			"				B.avg_ordersum_ttupass AS avg_ordersum_ttupass,\r\n" + 
			"				C.avg_osdappr_implecompl AS avg_osdappr_implecompl\r\n" + 
			"				FROM\r\n" + 
			"					(select to_char(trunc(o.updated_on,'mon'), 'Mon') as DT,\r\n" + 
			"					ROUND(sum(GET_WORKING_DAYS(trunc(o.submitted_on),trunc(ows.created_on)))/count(distinct o.order_id)) as avg_ordersum_implecompl, \r\n" + 
			"					null as avg_ordersum_ttupass, \r\n" + 
			"					null as avg_osdappr_implecompl\r\n" + 
			"					from orders o, bpm_order_work_step ows\r\n" + 
			"					where ows.work_step_id = 1020 and o.order_status_id in (1009,1063,1064,1065,1066) @YEAR \r\n" + 
			"					and o.order_id = ows.order_id (+)\r\n" + 
			"					group by to_char(trunc(o.updated_on,'mon'), 'Mon')) A\r\n" + 
			"					FULL OUTER JOIN\r\n" + 
			"					(select to_char(trunc(o.updated_on,'mon'), 'Mon') as DT, \r\n" + 
			"					null as avg_ordersum_implecompl, \r\n" + 
			"					ROUND(sum(GET_WORKING_DAYS(trunc(o.submitted_on),trunc(obs.created_on)))/count(distinct o.order_id)) as avg_ordersum_ttupass, \r\n" + 
			"					null as avg_osdappr_implecompl\r\n" + 
			"					from orders o, bpm_order_business_step obs\r\n" + 
			"					where obs.business_step_id = 3029 and obs.business_step_status = 'Passed' \r\n" + 
			"					and o.order_status_id in (1009,1063,1064,1065,1066) @YEAR \r\n" + 
			"					and o.order_id = obs.order_id (+)\r\n" + 
			"					group by to_char(trunc(o.updated_on,'mon'), 'Mon')) B ON a.dt=b.dt\r\n" + 
			"					FULL OUTER JOIN\r\n" + 
			"					(select to_char(trunc(o.updated_on,'mon'), 'Mon') as DT,\r\n" + 
			"					null as avg_ordersum_implecompl, \r\n" + 
			"					null as avg_ordersum_ttupass, \r\n" + 
			"					ROUND(sum(GET_WORKING_DAYS(trunc(osd.created_on),trunc(impl.created_on)))/count(distinct o.order_id)) as avg_osdappr_implecompl \r\n" + 
			"					from orders o, bpm_order_work_step osd, bpm_order_work_step impl\r\n" + 
			"					where osd.work_step_id = 1065 and osd.bpm_status_id = 1002 \r\n" + 
			"					and impl.work_step_id = 1020\r\n" + 
			"					and o.order_status_id in (1009,1063,1064,1065,1066) @YEAR \r\n" + 
			"					and o.order_id = osd.order_id (+)\r\n" + 
			"					and o.order_id = impl.order_id (+)\r\n" + 
			"					group by to_char(trunc(o.updated_on,'mon'), 'Mon')) C \r\n" + 
			"					ON b.dt=c.dt\r\n" + 
			"				  ) t ON t.DT = n.month \r\n" + 
			"				  order by to_date(month,'mon')";

}
