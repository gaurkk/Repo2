package com.att.comet.account.modal;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * POJO for account
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class AccountBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 1942226061718565165L;
	private String ubcid;
	private String masterAccountName;
	private String subAccountName;
	private String cipn;
	private String bcid;
	private String agreementAccountName;
	private String accountType;
	private String companyOwner;
	private String accountCreatedBy;
	private String accountCreatedOn;
	private String internalProductInitiativeName;
	private Long accountClassId;
	private String pdpPackageName;
	private String cityName;
	private String stateName;
	private String streetAddress;
	private String zipCode;
}
