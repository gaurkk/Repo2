package com.att.comet.charts.result;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * To be used for fetch the all fields report.
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper=true)
public class OrderAllFieldsReportDisplayBO extends GridDisplayBO {
	private static final long serialVersionUID = -5388559580245092876L;

	private Long orderId;
	private String orderType;
	private String orderStatus;
	private String referenceOrderId;
	private String expedite;
	private String express;
	private String accountClass;
	private String masterAccountName;
	private String subAccountName;
	private String feeWaiverAccount;
	private String feeWaiverOrder;
	private String feeWaiverApprovedMRC;
	private String tsp;
	private String migratedOrder;
	private String dedicatedAPN;
	private String apnName;
	private String apnStatus;
	private String pdpId;
	private String pdpName;
	private String managedAvpn;
	private String attRadius;
	private String mobileToMobile;
	private String mobileTerminated;
	private String mobileOriginate;
	private String eod;
	private String splitTunnelInternetAccess;
	private String mobileTerminatedSplitTunnel;
	private String sourceOfIpAddressing;
	private String mobilePoolType;
	private String addressingType;
	private String ipptCustommerHostedRadius;
	private String enterpriseTargetIpRange;
	private String mobilePoolAddress;
	private String fanId;
	private String banId;
	private String eodBlu;
	private String marketSegment;
	private String orderSubmitter;
	private String osd;
	private String orderApprover;
	private String orderManager;
	private String ccspm;
	private String networkImplementor;
	private String itOps;
	private String geoRedundant;
	private String activePassive;
	private String dataCenters;
	private String backhaulType;
	private String internetVpnEndpoint;
	private String tunnelType;
	private String routingProtocol;
	private String restrictiveRouting;
	private String cirSpeed;
	private String strictTcp;
	private String dateSubmitted;
	private String approvedByOrderApprover;
	private String approvedByOrderManager;
	private String approvedByOsd;
	private String hlrHssCompleteionDate;
	private String niIWOSCreationDate;
	private String apnBuildIwosCompeteDate;
	private String billingTaskId;
	private String billingCreationDate;
	private String billingCompleteDate;
	private String itOpsCompleteDate;
	private String dashBoardCompleteDate;
	private String ccspmOrderUpdateCompleteDate;
	private String niOrderUpdateComplete;
	private String ttuRequired;
	private String onHoldStatus;
	private Long daysOnHold;
	private String ttuScheduleDate;
	private String apnInProductionDate;
	private String inProductionDate;
	private String lteSweep;
	private String ipbrFlag;
	private String msp;
	private String mspEntAndMms;
	private String pcrf;
	private String splitAccessPAT;
	private String enterpriseTargetIpRangeRoute;
	private String intTargetIpRanges;
	private String geoOptimization;
	private String patPoolRange;
	private String ccipRadius;
	private Long ccsRouterBaseRd;
	private String vrfName;
	private String vlanGi;
	private String ocs;
	private String interfaceTunnelNum;
	private String cryptoVlanId;
	private Long vlanId;
	private String firstNet = "N";
	private String turboAppSupport = "N";
	private String dscpPreservation = "N";
	private String isAmp;
	private String ccsMx;
	private String firstNetEpc;
	private String crdRow4;
	private String accaHealthCheckEnable;
	private Long numberOfChangeRequests;
	
	private String vti;
	private String apnType;
	private String globalBlockList;
	
	
	
	
}
