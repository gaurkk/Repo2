package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "CUSTOM_FILTERS")
public class CustomFilters implements Serializable {

	private static final long serialVersionUID = -4174628040287857773L;

	@Id
	@Column(name = "CUST_FILTER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_CUST_FILTER_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_CUST_FILTER_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CUST_FILTER_ID")
	private Long custFilterId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FILTER_ID")
	private Filters filters;

	@Column(name = "COLUMN_NAME", nullable = false, length = 200)
	private String columnName;

	@Column(name = "FILTER_NAME", nullable = true, length = 200)
	private String filterName;

	@Column(name = "VALUE", nullable = true, length = 200)
	private String value;

	@Column(name = "FROM_DATE", nullable = true)
	private String fromDate;

	@Column(name = "TO_DATE", nullable = true)
	private String toDate;

	/**
	 * @return the custFilterId
	 */
	public Long getCustFilterId() {
		return custFilterId;
	}

	/**
	 * @param custFilterId the custFilterId to set
	 */
	public void setCustFilterId(Long custFilterId) {
		this.custFilterId = custFilterId;
	}

	/**
	 * @return the filters
	 */
	public Filters getFilters() {
		return filters;
	}

	/**
	 * @param filters the filters to set
	 */
	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * @param columnName the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the filterName
	 */
	public String getFilterName() {
		return filterName;
	}

	/**
	 * @param filterName the filterName to set
	 */
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
}
