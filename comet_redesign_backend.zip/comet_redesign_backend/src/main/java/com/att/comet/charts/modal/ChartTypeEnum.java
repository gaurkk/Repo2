package com.att.comet.charts.modal;

public enum ChartTypeEnum {
	
	GRID,
	PIE,
	BAR,
	STACKED_COLUMN,
	COLUMN,
	LINE;
}


