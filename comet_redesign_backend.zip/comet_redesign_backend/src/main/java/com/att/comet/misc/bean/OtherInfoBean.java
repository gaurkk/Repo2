package com.att.comet.misc.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class OtherInfoBean {

	private String exceptionRequestApprover;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "MM/dd/yyyy")
	private Date exceptionApprovalDate;
	private String exceptionApprovalNumber;
	private String notes;
	private Long numBackHauls;
	private String iwosNotes;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "MM/dd/yyyy")
	private Date apnInProductionDate;
	private String whiteListOfBlackList;
	private String iWOS;

}
