package com.att.comet.manage.modal;


import lombok.Data;

@Data
public class ManageInvetoryDownloadBO {

	private String templateContentType;

	private byte[] templateAttachment;

	private String templateFileName;
}
