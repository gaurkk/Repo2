package com.att.comet.common.service;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.stereotype.Service;

import com.att.comet.configuration.MessageConfigProperties;

@Service
public class MessageConfigService {

	private AnnotationConfigApplicationContext context = null;
	public ConfigurableEnvironment properties() {
		if(null==context) {
			context =  new AnnotationConfigApplicationContext();
			context.register(MessageConfigProperties.class);
			context.refresh();
		}
		return context.getEnvironment();	
	}
	
}
