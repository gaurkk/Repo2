package com.att.comet.common.constant;

public class CometCommonConstant {

	public static final String ACCOUNT_CLASS = "ACCOUNT_CLASS";
	public static final String ACCOUNT_TYPE = "ACCOUNT_TYPE";
	public static final String BACKHAUL_TYPE = "BACKHAUL_TYPE";
	public static final String ORDER_STATUS = "ORDER_STATUS";
	public static final String DAPN_STATUS = "DAPN_STATUS";
	public static final String APN_SIZE = "APN_SIZE";
	public static final String COMPANY_NAME = "COMPANY_NAME";
	public static final String BATCH_ID = "BATCH_ID";
	public static final String BACKHAULINSTANCE_STATUS = "BACKHAULINSTANCE_STATUS";
	public static final String APN_SELECTION = "APN_SELECTION";
	public static final String ORDER_TYPE = "ORDER_TYPE";
	public static final String DATACENTER_NAME = "DATACENTER_NAME";
	public static final String INVENTORY_TEMPLATE_NAME = "INVENTORY_TEMPLATE_NAME";
	public static final String STATICYES_NO_FIRSTNETORDER = "STATICYES_NO_FIRSTNETORDER";
	public static final String STATICYES_NO_ORDEREXPEDITE = "STATICYES_NO_ORDEREXPEDITE";
	public static final String BACKHAUL_INSTANCE_TYPE = "BACKHAUL_INSTANCE_TYPE";
	public static final String STATIC_YES_NO_MIGRATEORDER = "STATICYES_NO_MIGRATEORDER";
	public static final String TUNNEL_TYPE = "TUNNEL_TYPE";
	public static final String SEARCH_ORDER_ACCOUNT_NAME = "SEARCH_ORDER_ACCOUNT_NAME";
	public static final String COUNTRY = "COUNTRY";
	public static final String STATE = "STATE";
	public static final String CITY = "CITY";
	
	public static final String MASTER_ACCOUNT_NAME = "MASTER_ACCOUNT_NAME";
	public static final String SUB_ACCOUNT_NAME = "SUB_ACCOUNT_NAME";
	public static final String INTERNAL_INITIATIVE_ACCOUNT_NAME = "INTERNAL_INITIATIVE_ACCOUNT_NAME";
	public static final String PRODUCT_INITIATIVE_ACCOUNT_NAME = "PRODUCT_INITIATIVE_ACCOUNT_NAME";
	public static final String APN_NAME = "APN_NAME";
	
	public static final String ENTERPRISE_ACCOUNT="Enterprise Account";
	public static final String PRODUCT_ACCOUNT="Product Account";
	public static final String INTERNAL_ACCOUNT="Internal Account";
	public static final String EOD_TYPE_YES_NO="EOD_TYPE_YES_NO";
	
	///////////ORDER INITIATING FIRST time Status/////
	public static final String INITIATING_ORDER_STATUS_FIRST_TIME = "New";
	public static final String INITIATING_ORDER_TYPE_FIRST_TIME = "New";
	
	public static final String JNDINAME = "spring.datasource.jndi-name";
	
	/**
	 * APN_NEW
	 */
	public final static String APN_NEW = "New";

	/**
	 * APN_DEDICATED
	 */
	public final static String APN_DEDICATED = "Dedicated";
	/**
	 * STATIC
	 */
	public final static String STATIC = "Static";

	/**
	 * DYNAMIC
	 */
	public final static String DYNAMIC = "Dynamic";

	/**
	 * ACTIVE
	 */
	public final static String ACTIVE = "Active";

	/**
	 * PASSIVE
	 */
	public final static String PASSIVE = "Passive";
	
	/**
	 * SHARED
	 */
	public final static String SHARED = "Shared";

	/**
	 * UNIQUE
	 */
	public final static String UNIQUE = "Unique";

	/**
	 * ATT_HOSTED
	 */
	public final static String ATT_HOSTED = "ATT_HOSTED";

	/**
	 * IPPT
	 */
	public final static String IPPT = "IPPT";

	/**
	 * CUSTOMER_HOSTED
	 */
	public final static String CUSTOMER_HOSTED = "CUSTOMER_HOSTED";

	/**
	 * EXISTING
	 */
	public final static String EXISTING = "Existing";

	/**
	 * NEW_EXISTING
	 */
	public final static String NEW_EXISTING = "NewExisting";

	/**
	 * ATC
	 */
	public final static String ATC = "ATC";

	/**
	 * BTC
	 */
	public final static String BTC = "BTC";

	/**
	 * STC
	 */
	public final static String STC = "STC";

	/**
	 * VTC
	 */
	public final static String VTC = "VTC";

	/**
	 * CNC
	 */
	public final static String CNCR = "CNCR";

	/**
	 * VTC2
	 */
	public final static String VTC2 = "VTC2";
	
	/**
	 * STR_1
	 */
	public final static String STR_1 = "1";

	/**
	 * STR_2
	 */
	public final static String STR_2 = "2";

	/**
	 * STR_3
	 */
	public final static String STR_3 = "3";

	/**
	 * STR_4
	 */
	public final static String STR_4 = "4";

	/**
	 * STR_5
	 */
	public final static String STR_5 = "5";

	/**
	 * HELP_INITIATE_ID
	 */
	public final static String HELP_INITIATE_ID = "1001";

	/**
	 * STR_1001
	 */
	public final static String STR_1001 = "1001";

	/**
	 * STR_1002
	 */
	public final static String STR_1002 = "1002";

	/**
	 * STR_1003
	 */
	public final static String STR_1003 = "1003";

	/**
	 * STR_1004
	 */
	public final static String STR_1004 = "1004";

	/**
	 * STR_1005
	 */
	public final static String STR_1005 = "1005";

	/**
	 * STR_1006
	 */
	public final static String STR_1006 = "1006";

	/**
	 * STR_1007
	 */
	public final static String STR_1007 = "1007";

	/**
	 * STR_1008
	 */
	public final static String STR_1008 = "1008";

	/**
	 * STR_1009
	 */
	public final static String STR_1009 = "1009";

	/**
	 * STR_1010
	 */
	public final static String STR_1010 = "1010";

	/**
	 * STR_1011
	 */
	public final static String STR_1011 = "1011";

	/**
	 * STR_1012
	 */
	public final static String STR_1012 = "1012";
	
	/**
	 * EMPTY_STR
	 */
	public final static String EMPTY_STR = "";
	
	public static final String BACKHAUL_EXISTING = "Existing";
	
	public static final String BACKHAUL_NEW = "New";
	
	public static final Long BACKHAUL_TYPE_IVPN = 1002L;
	
	public static final String CHECK_CLAIM_POSSIBLE = "SELECT CHECK_CLAIM_POSSIBLE(:p_order_id,:p_backhaul_display_id) FROM DUAL";
	
	public static final String CLAIM_BACKHAUL = "comet_order_pkg.claim_backhaul";
		
	public static final String ORDER_ID = "p_order_id";
	
	public static final String DISPLAY_BACKHAUL_ID = "p_backhaul_display_id";
	
	public static final String MARKET_SEGMENT_OTHER = "Other";
	
	public static final String CHECK_AND_UPDATE_EXCEPTIONAL_ORDER_STORED_PROC = "comet_order_pkg.check_update_exceptional_order";
	
	public static final Long BACKHAUL_TYPE_MPLS = 1004L;
	
	public static final String UPDATE_IN_OUT_STG_PAT_MAPPING = "UPDATE_IN_OUT_STG_PAT_MAPPING";
	
    public static final String DELETE_BACKHAUL_STORED_PROC = "comet_order_pkg.delete_backhaul";
	
	public static final String UPDATE_DATA_CENTER_BACKHAUL_COUNT_STORED_PROC = "comet_order_pkg.update_order_dc_bh_count";
	
    public static final String REPORT_OUTPUT_FORMAT = "REPORT_OUTPUT_FORMAT";
	
	public static final String WELCOME_PCKG_JASPER_PATH = "WELCOME_PCKG_JASPER_PATH";
	
	public static final String ORDER_SUMMARY_JASPER_PATH = "ORDER_SUMMARY_JASPER_PATH";
	
	public static final String CHECK_DUPLICATE_DATA_CENTER = "select count(data_center_name) as count from data_center where data_center_name= :data_center_name";
	
	public static final String DATA_CENTER_NAME = "data_center_name";
	
	public static final String MASTER_ACC_NAME = "MASTER_ACC_NAME";
	
	public static final String VALIDATE_DAPN_RECORDS ="{call VALIDATE_DAPN_RECORDS(?)}";
	
	public static final String ATTACHMENT_DELETE_SUCCESS= "Attachment Deleted Successfully For Account Id :";
	
	public static final String IVPN_STATIC = "static";
	
	public static final String IVPN_BGP = "bgp";
	
	public static final String COPY_BH="copybh";
	
	public static final String ROLE_NAME="ROLE_NAME";
	
	public static final String TASK_NAME="TASK_NAME";
	
	public static final String TASK_TYPE="TASK_TYPE";
	
	public static final String ASSIGNED="ASSIGNED";
	
	public static final String UNCLAIMED="UNCLAIMED";
	
	public static final String RESERVED="RESERVED";
	
	public static final String IN_PROGRESS="IN_PROGRESS";
	
	public static final String COMPLETED="COMPLETED";
	
	public static final String OPEN="OPEN (Unclaimed/ Assigned)";
	
	public static final String CLAIMED="CLAIMED";
	
	public static final String CREATE_REQUEST="createrequest";
	
	public static final String STATUS_REQUEST="statusrequest";
	
	public static final String SKIP_REQUEST="skiprequest";
	
	public static final String LOGIN_REQUEST="login";
	
	public static final String DETAIL_REQUEST="detailrequest";
	
	public static final String CANCEL_REQUEST="cancelrequest";
	
	public static final String ACCA_CREATE_REQUEST="accacreaterequest";
	
	public static final String ACCA_STATUS_REQUEST="accastatusrequest";
	
	public static final String ACCA_DETAIL_REQUEST="accadetailrequest";
	
	public static final String FORWARD_SLASH="/";
	
	public static final String GET_AMP_CHANGE_FUNCTION="CHECK_AMP_FIELDS_CHANGE";
	
	public static final String CHECK_ACCA_ELIGIBILITY="CHECK_ACCA_ELIGIBILITY";
	
	public static final String ACCA_SHOW_ENABLE="SHOW_ENABLE";
	
	public static final String AUTO_ACTIVATE_VPN_STORED="COMET_ORDER_PKG.VPN_AUTO_ACTIVATION";
	
	public static final String SAVE_ORDER_AUDIT_STORED_PROC="COMET_AUDIT_PKG.AUDIT_ORDER";
	
	public static final String GET_ORDER_PROCESS_NEW="New";
	
	public static final String GET_ORDER_PROCESS_EXPEDITE = "Expedite";
	
	public static final String UPDATE_VPN_INFO = "UPDATE_VPN_INFO";
	
	public static final String MANAGE_SHARED_BACKHAUL = "COMET_ORDER_PKG.MANAGE_SHARED_BACKHAUL";
	
	public static final String ROLLBACK_ORDER_AUDIT = "COMET_AUDIT_PKG.ROLLBACK_ORDER_AUDIT";
	
	public static final String P_MAINBUSINESSPROCESS  = "P_MainBusinessProcess";
	
	public static final String P_DAPNRELEASE_ID  = "P_DAPNRELEASE_ID";
	
	public static final String P_DAPN_CANCELLATION_PROCESS  = "P_DAPN_CANCELLATION__PROCESS";
	
	public static final String START  = "start";
	
	public static final String GET_INIT_ORDER_CONFIG_STORED_PROC = "{call comet_audit_pkg.get_init_order_config_audit(?, ?, ?, ?, ?, ?, ?) }";
	
	public static final String GET_APN_STORED_PROC = "{call comet_audit_pkg.get_apn_config_audit(?,?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?,?) }";
	
	public static final String GET_ORDER_ACCOUNT_STORED_PROC = "{call comet_audit_pkg.get_order_account_config_audit(?, ?, ?, ?, ?) }";
	
	public static final String GET_ORDER_CONTACT_STORED_PROC = "{call comet_audit_pkg.get_order_contact_config_audit(?, ?, ?, ?, ? ) }";
	
	public static final String GET_BACKHAUL_CONFIG_STORED_PROC = "{call comet_audit_pkg.get_backhaul_config_audit(?, ?, ?, ?) }";
	
	public static final String GET_INTERNET_VPN_AUDIT_STORED_PROC = "{call comet_audit_pkg.get_internet_vpn_config_audit(?, ?, ?, ?, ?) }";
	
	public static final String GET_MPLS_AUDIT_STORED_PROC = "{call comet_audit_pkg.get_mpls_config_audit(?, ?, ?, ?, ?, ?, ?) }";
	
	public static final String GET_CRD_CONFIG_STORED_PROC = "{call comet_audit_pkg.get_crd_audit(?, ?, ?, ?, ?, ?) }";
	
	public static final String GET_FEE_WAIVER_DOC_STORED_PROC = "{call comet_audit_pkg.get_fee_waiver_doc_audit(?, ?, ?, ?) }";
	
	public static final String GET_RECOVERY_FLOW_CHART_STORED_PROC = "{call comet_audit_pkg.get_recovery_flow_chart_audit(?, ?, ?, ?) }";
	
	public static final String GET_ORDER_SUMMARY_STORED_PROC = "{call comet_audit_pkg.get_order_summary_audit(?, ?, ?, ?, ?, ?, ?, ?, ?,?) }";
	
	public static final String GET_ORDER_BILLING_CONFIG_STORED_PROC = "{call comet_audit_pkg.get_order_billing_audit(?, ?, ?, ?) }";
}
