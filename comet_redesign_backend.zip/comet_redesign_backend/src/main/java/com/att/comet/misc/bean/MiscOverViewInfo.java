package com.att.comet.misc.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MiscOverViewInfo {

	String orderType;
	String orderStatus;
	boolean isCancelOrder =false;
	boolean isChangeOrder =false ;
	boolean isExpediteOrder =false;
	boolean isDecomissionOrder=false;
	boolean isDedicatedApn=false;
	boolean hideDefaultProcessInfoTable=false;

}
