package com.att.comet.charts.result;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OrderListGridDisplayBO implements Serializable {

	private static final long serialVersionUID = 7498607057479349739L;

	private Long orderId;
	private String accountName;
	private String apnName;
	private String orderType;
	private String orderStatus;
	private String createdOn;
	private Integer flag;

}
