package com.att.comet.common.util;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.att.comet.misc.bean.ProcessInfoBeanDetails;
import com.att.comet.order.modal.OrderDataCenterBO;
import com.att.comet.order.modal.ValidationsBO;
import com.att.comet.order.modal.VlanGiBO;

/**
 * Comparators class gives the method for comparing two quantities.
 */
public class Comparators {

	public static Comparator<OrderDataCenterBO> dataCenterComparatorOnSortOrderFirst() {
		return new Comparator<OrderDataCenterBO>() {
			public int compare(OrderDataCenterBO dc1, OrderDataCenterBO dc2) {
				if (dc1.getDcSortOrder() != null && dc2.getDcSortOrder() != null) {
					return dc1.getDcSortOrder().compareTo(dc2.getDcSortOrder());
				}
				return (dc1.getDataCenterId().compareTo(dc2.getDataCenterId()));
			}
		};
	}
	
	public static Comparator<ValidationsBO> validationSortingBaseOnTabId() {
		return new Comparator<ValidationsBO>() {
			public int compare(ValidationsBO vb1, ValidationsBO vb2) {
				if (vb1.getIdForSortTabErrors() != null && vb2.getIdForSortTabErrors() != null) {
					return vb1.getIdForSortTabErrors().compareTo(vb2.getIdForSortTabErrors());
				}
				return (vb1.getIdForSortTabErrors().compareTo(vb2.getIdForSortTabErrors()));
			}
		};
	}
	public static Comparator<VlanGiBO> dataCenterComparatorOnSortOrderFirstVlan() {
		return new Comparator<VlanGiBO>() {
			public int compare(VlanGiBO dc1, VlanGiBO dc2) {
				if (dc1.getDcSortOrder() != null && dc2.getDcSortOrder() != null) {
					return dc1.getDcSortOrder().compareTo(dc2.getDcSortOrder());
				}
				return (dc1.getDataCenterId().compareTo(dc2.getDataCenterId()));
			}
		};
	}
	
	
	 // function to sort hashmap by values 
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByValue(HashMap<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order
    	
    	HashMap<String,String> processValueMap = new HashMap<String,String>();
    	processValueMap.put("1","OA_Approval_Process"); //OA_Approval_Process
    	processValueMap.put("2","OM_Approval_Process"); //OM_Approval_Process
    	processValueMap.put("3","OSD_Approval_Process"); //OSD_Approval_Process
    	processValueMap.put("4","APN_HLR/HSS_IWOS_Process"); //APN_HLR/HSS_IWOS_Process
    	processValueMap.put("5","APN_IT_OPS_Process"); //APN_IT_OPS_Process
    	processValueMap.put("7", "Network_IWOS_Process"); //Network_IWOS_Process
    	processValueMap.put("6", "Process_Billing_Request"); //Process_Billing_Request
    	processValueMap.put("8", "TTU_Process"); //TTU_Process
    	
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	//return (o1.getValue().listIterator().next().getSequenceNumber()).compareTo(o2.getValue().listIterator().next().getSequenceNumber()); 
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(processValueMap.get(aa.getKey()), aa.getValue());
            //temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    } 
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByKeyForCancel(Map<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order  ProcessInfoBeanDetails
    	
    	HashMap<String,String> processValueMap = new HashMap<String,String>();
    	processValueMap.put("1","OA_Cancel_Approval_Task"); //OA_Approval_Process
    	processValueMap.put("2","Cancellation_Dashboard_Process"); //OM_Approval_Process
    	
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(processValueMap.get(aa.getKey()), aa.getValue());
        } 
        return temp; 
    } 
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByKeyForDecomission(Map<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order
    	
    	HashMap<String,String> processValueMap = new HashMap<String,String>();
    	processValueMap.put("1","Decommissioning_Dashboard"); //Decommissioning_Dashboard
    	processValueMap.put("2","APN_HLR_Decommission_Task"); //APN_HLR_Decommission_Task
    	processValueMap.put("3","APN_Build_Decommission_Task"); //APN_Build_Decommission_Task
    	processValueMap.put("4","MPLS_Backhaul_Decommission_Task"); //MPLS_Backhaul_Decommission_Task
    	processValueMap.put("5","Decommission_Billing"); //Decommission_Billing
    	processValueMap.put("6","Decommission_Confirmation_Task"); //Decommission_Confirmation_Task
    	
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(processValueMap.get(aa.getKey()), aa.getValue());
        } 
        return temp; 
    }
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByKeyForDapn(Map<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order
    	
    	HashMap<String,String> processValueMap = new HashMap<String,String>();
    	processValueMap.put("1","OA_Approval"); //OA_Approval_Process
    	processValueMap.put("2","IT_OPS_Approval_Process"); //IT_OPS_Approval_Process
    	processValueMap.put("3","Process_Billing_Request"); //Process_Billing_Request
    	
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(processValueMap.get(aa.getKey()), aa.getValue());
        } 
        return temp; 
    }
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByKeyForExpedite(Map<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order
    	
    	HashMap<String,String> processValueMap = new HashMap<String,String>();
    	processValueMap.put("1","OA_Approval_Process"); //OA_Approval_Process
    	processValueMap.put("2","OM_Approval_Process"); //OM_Approval_Process
    	processValueMap.put("3","Proposed_Expedite_Build_Process"); //Proposed_Expedite_Build_Process
    	processValueMap.put("4","Final_Expedite_Build_Process"); //Final_Expedite_Build_Process
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(processValueMap.get(aa.getKey()), aa.getValue());
        } 
        return temp; 
    }
    public static HashMap<String, List<ProcessInfoBeanDetails>> sortByKeyForChangeOrder(HashMap<String, List<ProcessInfoBeanDetails>> hm) 
    { 
        //Sorting Order
    	HashMap<String,String> crSequenceMap = new HashMap<String,String>();
    	crSequenceMap.put("-1", "Change_Request_Dashboard"); //Change_Request_Dashboard
    	crSequenceMap.put("0", "OA_CR_Approval_Process"); //OA_CR_Approval_Process
    	crSequenceMap.put("1", "OA_Approval_Process"); //OA_Approval_Process
    	crSequenceMap.put("2", "OM_Approval_Process"); //OM_Approval_Process
    	crSequenceMap.put("3", "OSD_Approval_Process"); //OSD_Approval_Process
    	crSequenceMap.put("4", "APN_HLR/HSS_IWOS_Process"); //APN_HLR/HSS_IWOS_Process
    	crSequenceMap.put("5", "APN_IT_OPS_Process"); //APN_IT_OPS_Process
    	crSequenceMap.put("6", "Network_IWOS_Process"); //Network_IWOS_Process
    	crSequenceMap.put("7", "Process_Billing_Request"); //Process_Billing_Request
    	crSequenceMap.put("8", "TTU_Process"); //TTU_Process
    	crSequenceMap.put("9", "Change_Request_Completion"); //Change_Request_Completion
    	
    	// Create a list from elements of HashMap 
        List<Map.Entry<String, List<ProcessInfoBeanDetails>> > list = 
               new LinkedList<Map.Entry<String, List<ProcessInfoBeanDetails>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, List<ProcessInfoBeanDetails>> >() { 
            public int compare(Map.Entry<String, List<ProcessInfoBeanDetails>> o1,  
                               Map.Entry<String, List<ProcessInfoBeanDetails>> o2) 
            {
            	return (o1.getKey()).compareTo(o2.getKey());       
            	
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, List<ProcessInfoBeanDetails>> temp = new LinkedHashMap<String, List<ProcessInfoBeanDetails>>(); 
        for (Map.Entry<String, List<ProcessInfoBeanDetails>> aa : list) { 
        	temp.put(crSequenceMap.get(aa.getKey()), aa.getValue());
        } 
        return temp; 
    }
}
