package com.att.comet.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "camunda")
public class CamundaConfig {
	private String baseUrl;
	private String taskListUrl;
	public String getBaseUrl() {
		return baseUrl;
	}
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	public String getTaskListUrl() {
		return taskListUrl;
	}
	public void setTaskListUrl(String taskListUrl) {
		this.taskListUrl = taskListUrl;
	}
}
