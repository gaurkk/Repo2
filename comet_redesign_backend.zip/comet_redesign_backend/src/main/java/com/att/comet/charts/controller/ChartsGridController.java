package com.att.comet.charts.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.charts.modal.ChartsRequestBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.charts.service.ChartsGridServiceImpl;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ChartsGridController {
	private static final Logger logger = LoggerFactory.getLogger(ChartsGridController.class);

	@Autowired
	ChartsGridServiceImpl chartsGridService;

	@Autowired
	CometResponse<ResultBO> cometResponse;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@PostMapping(value = "/chartsGrid", produces = { MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "All order specific to chart selection", notes = "Return all the orders specific to chart selection")
	public CometResponse<ResultBO> postChartsGridData(@RequestBody ChartsRequestBO requestBO)
			throws CometDataException {
		logger.info("[Attuid : " + (requestBO.getUserInfo().getAttuid() == null ? "" : requestBO.getUserInfo().getAttuid()) + "] "+ "Starting method postChartsGridData : ", this);
		ResultBO resultBO = null;

		try {
			resultBO = chartsGridService.getGridDataUsingCriteria(requestBO);
			cometResponse.setMethodReturnValue(resultBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}

		if (cometResponse.getStatusCode().equals(CometResponse.Status.BUSINESS_ERROR.getCode())
				&& cometResponse.getStatus().equals(CometResponse.Status.BUSINESS_ERROR)) {
			logger.error("postChartsGridData :: requestBO is having null value::", this);
			throw new CometDataException("INVALID REQUEST FOR CHART");
		}
		logger.info("[Attuid : " + (requestBO.getUserInfo().getAttuid() == null ? "" : requestBO.getUserInfo().getAttuid()) + "] "+ "Starting method postChartsGridData : ", this);
		return cometResponse;
	}

}
