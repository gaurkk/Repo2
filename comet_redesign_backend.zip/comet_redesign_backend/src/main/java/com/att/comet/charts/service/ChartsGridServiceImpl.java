package com.att.comet.charts.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.comet.charts.modal.ChartNameEnum;
import com.att.comet.charts.modal.ChartsRequestBO;
import com.att.comet.charts.modal.RestrictionBO;
import com.att.comet.charts.modal.RestrictionEnum;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.charts.util.ChartsConstant;
import com.att.comet.common.constant.BaseQueryNameConstant;
import com.att.comet.common.exception.ErrorCodeConstant;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.util.CriteriaHelper;

@Service
public class ChartsGridServiceImpl implements ChartsGridService {
	private static final Logger logger = LoggerFactory.getLogger(ChartsGridServiceImpl.class);

	@Autowired
	CriteriaHelper criteriaHelper;

	public ResultBO getGridDataUsingCriteria(ChartsRequestBO chartsRequestBo) {
		logger.info("Starting method getGridDataUsingCriteria : ", this);
		ResultBO resultBO = null;

		try {
			SearchCriteria searchCriterias = null;
			String userAttUid = chartsRequestBo.getUserInfo().getAttuid();
			Long userRoleId = chartsRequestBo.getUserInfo().getRoleId();

			String marketSegment = "";
			String orderType = "0";
			String month = "";
			String year = "";
			String apnStatus = "";
			String activePassive = "";
			String bhType = "";
			String geo = "";

			String orderStatus = "";
			String dataCenter = "";
			String selectedAttuId = "";
			String date = "";

			if (chartsRequestBo.getRestrictions() != null && chartsRequestBo.getRestrictions().size() >= 0) {
				for (RestrictionBO restriction : chartsRequestBo.getRestrictions()) {
					String key = RestrictionEnum.valueOf(restriction.getKey()).toString();
					String value = restriction.getValue();

					if (key.equals(RestrictionEnum.ORDER_MARKET_SEGMENT_RESTRICTION.name())) {
						marketSegment = value;
					} else if (key.equals(RestrictionEnum.ORDER_TYPE_RESTRICTION.name())) {
						orderType = value;
					} else if (key.equals(RestrictionEnum.ORDER_DATE_RESTRICTION.name())) {
						if (value != null && value.length() > 0) {
							if (value.length() == 7) {
								month = value.substring(0, 3).toUpperCase();
								year = value.substring(3);
							} else if (value.length() == 3) {
								month = value.toUpperCase();
							} else if (value.length() == 4) {
								year = value;
							}
						}
					} else if (key.equals(RestrictionEnum.ORDER_ACTIVE_PASSIVE_RESTRICTION.name())) {
						activePassive = value;
					} else if (key.equals(RestrictionEnum.ORDER_APN_STATUS_RESTRICTION.name())) {
						apnStatus = value;
					} else if (key.equals(RestrictionEnum.ORDER_BH_TYPE_RESTRICTION.name())) {
						bhType = value;
					} else if (key.equals(RestrictionEnum.ORDER_GEO_RESTRICTION.name())) {
						geo = value;
					} else if (key.equals(RestrictionEnum.ORDER_STATUS_RESTRICTION.name())) {
						orderStatus = value;
					} else if (key.equals(RestrictionEnum.ORDER_DATA_CENTER_RESTRICTION.name())) {
						dataCenter = value;
					} else if (key.equals(RestrictionEnum.ORDER_SELECTED_ATTU_ID_RESTRICTION.name())) {
						selectedAttuId = value;
					} else if (key.equals(RestrictionEnum.ORDER_TTU_IWOS_DATE_RESTRICTION.name())) {
						date = value;
					} else if (key.equals(RestrictionEnum.ORDER_TTU_IWOS_ATTU_ID_RESTRICTION.name())) {
						selectedAttuId = value;
					}
				}
			} else {
				logger.error("RESTRICTION_REQUEST_NOT_PROPER::" + ErrorCodeConstant.RESTRICTION_REQUEST_NOT_PROPER,
						this);
			}
			if (chartsRequestBo.getChartName() == null) {
				logger.error("CHART NAME IS NOT PROPER::" + ErrorCodeConstant.CHART_NAME_IS_NOT_PROPER, this);
				return resultBO;
			}

			if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.ALL_ORDERS_PROGRESS.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				searchCriterias.add(CriteriaHelper.marketSegment(marketSegment));
				searchCriterias.add(CriteriaHelper.orderType(Long.parseLong(orderType)));
				searchCriterias.add(CriteriaHelper.date(month, year));
				if (CommonUtils.isNotNullEmpty(orderStatus)) {
					searchCriterias.add(CriteriaHelper.orderStatus(orderStatus));
				}
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.ALL_ORDERS_PROGRESS.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.MY_ORDERS_PROGRESS.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				searchCriterias.add(CriteriaHelper.marketSegment(marketSegment));
				searchCriterias.add(CriteriaHelper.orderType(Long.parseLong(orderType)));
				searchCriterias.add(CriteriaHelper.date(month, year));
				if (CommonUtils.isNotNullEmpty(orderStatus)) {
					searchCriterias.add(CriteriaHelper.orderStatus(orderStatus));
				}
				searchCriterias.addOtherDetails(new OtherDetails(userAttUid, userRoleId, 0, 0));
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.MY_ORDERS_PROGRESS.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.APNS_BY_DATA_CENTER.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());

				if (apnStatus.equals("1001")) {
					apnStatus = "In Progress";
				} else if (apnStatus.equals("1002")) {
					apnStatus = "In Production";
				}

				searchCriterias.add(CriteriaHelper.apnStatus(apnStatus));
				searchCriterias.add(CriteriaHelper.activePassive(activePassive));
				searchCriterias.add(CriteriaHelper.bhType(bhType));
				searchCriterias.add(CriteriaHelper.geo(geo));
				searchCriterias.add(CriteriaHelper.dataCenter(dataCenter));
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_DC_CONSUMPTION_GRID);
				searchCriterias.setChartName(ChartNameEnum.APNS_BY_DATA_CENTER.toString());

			} else if (chartsRequestBo.getChartName() != null && chartsRequestBo.getChartName()
					.equalsIgnoreCase(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				if (CommonUtils.isNotNullEmpty(selectedAttuId)) {
					searchCriterias.addOtherDetails(new OtherDetails(selectedAttuId, 0L, 0, 0));
				}
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.add(CriteriaHelper.orderAssignment(1023L));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				if (CommonUtils.isNotNullEmpty(selectedAttuId)) {
					searchCriterias.addOtherDetails(new OtherDetails(selectedAttuId, 0L, 0, 0));
				}
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.add(CriteriaHelper.orderAssignment(1007L));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.TTU_SCHEDULED.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				if (CommonUtils.isNotNullEmpty(selectedAttuId) || CommonUtils.isNotNullEmpty(date)) {
					if (selectedAttuId.equalsIgnoreCase("ALL_COUNT")) {
						searchCriterias.add(CriteriaHelper.orderTTUIWOSAttuId("Others", userAttUid));
					} else {
						searchCriterias.add(CriteriaHelper.orderTTUIWOSAttuId(selectedAttuId, userAttUid));
					}
					searchCriterias.add(CriteriaHelper.orderTTUIWOSDate(date));
				}
				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.add(CriteriaHelper.schedule(ChartsConstant.SCHEDULE_TTU));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.TTU_SCHEDULED.toString());

			} else if (chartsRequestBo.getChartName() != null
					&& chartsRequestBo.getChartName().equalsIgnoreCase(ChartNameEnum.IWOS_EXPECTED.toString())) {
				searchCriterias = criteriaHelper.getCriteria();
				searchCriterias.add(CriteriaHelper.initalData());
				if (CommonUtils.isNotNullEmpty(selectedAttuId)) {
					if (selectedAttuId.equalsIgnoreCase("ALL_COUNT")) {
						searchCriterias.add(CriteriaHelper.orderTTUIWOSAttuId("Others", userAttUid));
					} else {
						searchCriterias.add(CriteriaHelper.orderTTUIWOSAttuId(selectedAttuId, userAttUid));
					}
				}
				if (CommonUtils.isNotNullEmpty(date)) {
					searchCriterias.add(CriteriaHelper.orderTTUIWOSDate(date));
				}

				searchCriterias.setFormat(OutputFormat.GRID);
				searchCriterias.add(CriteriaHelper.schedule(ChartsConstant.SCHEDULE_IWOS));
				searchCriterias.setBaseQuery(BaseQueryNameConstant.BASE_QUERY_FOR_GRID);
				searchCriterias.setChartName(ChartNameEnum.IWOS_EXPECTED.toString());

			}

			resultBO = criteriaHelper.getOutput(searchCriterias);
		} catch (Exception e) {
//			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
//			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}

		logger.info("Exiting method getGridDataUsingCriteria : ", this);
		return resultBO;
	}

}
