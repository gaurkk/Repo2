package com.att.comet.dao.hibernate.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for BpmBusinessStep. Mapped with the BPM_BUSINESS_STEP in
 * the database.
 */
@Entity
@Table(name = "BPM_BUSINESS_STEP")
public class BpmBusinessStep implements java.io.Serializable {

	private static final long serialVersionUID = 4488829381906222662L;

	private Long businessStepId;
	private BpmWorkStep bpmWorkStep;
	private String businessStepName;
	private Set<BpmOrderBusinessStep> bpmOrderBusinessSteps = new HashSet<BpmOrderBusinessStep>(0);

	/**
	 * No argument constructor of the class.
	 */
	public BpmBusinessStep() {
	}

	/**
	 * Constructor with multiple arguments.
	 * 
	 * @param businessStepId
	 * @param bpmWorkStep
	 * @param businessStepName
	 */
	public BpmBusinessStep(Long businessStepId, BpmWorkStep bpmWorkStep, String businessStepName) {
		this.businessStepId = businessStepId;
		this.bpmWorkStep = bpmWorkStep;
		this.businessStepName = businessStepName;
	}

	/**
	 * Constructor with multiple arguments.
	 * 
	 * @param businessStepId
	 * @param bpmWorkStep
	 * @param businessStepName
	 * @param bpmOrderBusinessSteps
	 */
	public BpmBusinessStep(Long businessStepId, BpmWorkStep bpmWorkStep, String businessStepName,
			Set<BpmOrderBusinessStep> bpmOrderBusinessSteps) {
		this.businessStepId = businessStepId;
		this.bpmWorkStep = bpmWorkStep;
		this.businessStepName = businessStepName;
		this.bpmOrderBusinessSteps = bpmOrderBusinessSteps;
	}

	/**
	 * Getter method for businessStepId. BUSINESS_STEP_ID mapped to BUSINESS_STEP_ID
	 * in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "BUSINESS_STEP_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getBusinessStepId() {
		return this.businessStepId;
	}

	/**
	 * @param businessStepId to businessStepId set.
	 */
	public void setBusinessStepId(Long businessStepId) {
		this.businessStepId = businessStepId;
	}

	/**
	 * Getter method for bpmWorkStep
	 * 
	 * @return BpmWorkStep
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WORK_STEP_ID", nullable = false)
	public BpmWorkStep getBpmWorkStep() {
		return this.bpmWorkStep;
	}

	/**
	 * @param bpmWorkStep to bpmWorkStep set.
	 */
	public void setBpmWorkStep(BpmWorkStep bpmWorkStep) {
		this.bpmWorkStep = bpmWorkStep;
	}

	/**
	 * Getter method for businessStepName. BUSINESS_STEP_NAME mapped to
	 * BUSINESS_STEP_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_STEP_NAME", nullable = false, length = 100)
	public String getBusinessStepName() {
		return this.businessStepName;
	}

	/**
	 * @param businessStepName to businessStepName set.
	 */
	public void setBusinessStepName(String businessStepName) {
		this.businessStepName = businessStepName;
	}

	/**
	 * Getter method for bpmOrderBusinessSteps.
	 * 
	 * @return Set<BpmOrderBusinessStep>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bpmBusinessStep")
	public Set<BpmOrderBusinessStep> getBpmOrderBusinessSteps() {
		return this.bpmOrderBusinessSteps;
	}

	/**
	 * @param bpmOrderBusinessSteps to bpmOrderBusinessSteps set.
	 */
	public void setBpmOrderBusinessSteps(Set<BpmOrderBusinessStep> bpmOrderBusinessSteps) {
		this.bpmOrderBusinessSteps = bpmOrderBusinessSteps;
	}

}
