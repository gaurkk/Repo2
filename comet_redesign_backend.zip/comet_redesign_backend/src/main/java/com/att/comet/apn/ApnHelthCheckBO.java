package com.att.comet.apn;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApnHelthCheckBO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//private long apnHelthCheckId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;	
	
	private Character helthChkenable = 'Y';
	//private String helthChkCustdestnIp;
	
	private String helthChkType = "PING";
	
	private Long helthChkFrequency;
}
