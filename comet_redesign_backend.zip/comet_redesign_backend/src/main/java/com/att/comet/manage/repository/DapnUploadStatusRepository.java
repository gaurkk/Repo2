package com.att.comet.manage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.DapnUploadStatus;
import java.lang.String;

@Repository
public interface DapnUploadStatusRepository extends JpaRepository<DapnUploadStatus, String> {

	List<DapnUploadStatus> findByBatchId(String batchId);
	
	
}
