package com.att.comet.audit.modal;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class RecoveryFlowChartAuditBO extends CometGenericBO {
	private static final long serialVersionUID = 1062443952783581090L;

	private Long orderId;
	private String recoveryFlowChartName;
	private byte[] recoveryFlowChart;
}
