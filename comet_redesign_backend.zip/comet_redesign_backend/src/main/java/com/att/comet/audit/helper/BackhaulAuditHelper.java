package com.att.comet.audit.helper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;

import com.att.comet.audit.modal.RowData;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.modal.BgpBO;
import com.att.comet.order.modal.InternetVPNConfigBO;
import com.att.comet.order.modal.InternetVpnBO;
import com.att.comet.order.modal.MplsBO;
import com.att.comet.order.modal.MplsConfigBO;
import com.att.comet.order.modal.StaticRouteBO;
import com.att.comet.order.modal.VpnBO;

@Component
public class BackhaulAuditHelper {
	/**
	 * Returns the Internet VPN audit info.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return InternetVPNConfigBO
	 * @throws SQLException
	 */
	public InternetVPNConfigBO getInternetVpnAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		InternetVPNConfigBO internetVPNConfigBO = null;
		Set<InternetVpnBO> internetVpnBOs = null;
		InternetVpnBO vpnBO = null;

		List<RowData> ivpnResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> bgpResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));

		Long backhaulId = null;
		if (ivpnResults != null) {
			internetVPNConfigBO = new InternetVPNConfigBO();
			internetVpnBOs = new HashSet<InternetVpnBO>();
			internetVPNConfigBO.setInternetVpns(internetVpnBOs);
			Object columnValueInternetVpn = null;
			for (RowData ivpnRow : ivpnResults) {
				vpnBO = new InternetVpnBO();
				internetVpnBOs.add(vpnBO);
				columnValueInternetVpn = (BigDecimal) ivpnRow.getColumnValue("BACKHAUL_ID");
				if (columnValueInternetVpn != null) {
					vpnBO.setBackhaulId(((BigDecimal) columnValueInternetVpn).longValue());
					backhaulId = ((BigDecimal) columnValueInternetVpn).longValue();
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("backhaul_display_id");
				if (columnValueInternetVpn != null) {
					vpnBO.setBackhaulDisplayId((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("backhaul_selection");
				if (columnValueInternetVpn != null) {
					vpnBO.setBackhaulSelection((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("data_center_id");
				if (columnValueInternetVpn != null) {
					vpnBO.setDataCenter(((BigDecimal) columnValueInternetVpn).longValue());
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("vpn_gw_type");
				if (columnValueInternetVpn != null) {
					vpnBO.setVpnGwType((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("concentrator_public_ip");
				if (columnValueInternetVpn != null) {
					vpnBO.setConcentratorPublicIp((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("internet_vpn_endpoint");
				if (columnValueInternetVpn != null) {
					vpnBO.setInternetVpnEndpoint((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("tunnel_type");
				if (columnValueInternetVpn != null) {
					vpnBO.setTunnelType((String) columnValueInternetVpn);
				}

				/* Start BUC ID : 1.1.017 */
				columnValueInternetVpn = ivpnRow.getColumnValue("routing_protocol");
				if (columnValueInternetVpn != null) {
					vpnBO.setRoutProtocol((String) columnValueInternetVpn);
				}
				
				columnValueInternetVpn = ivpnRow.getColumnValue("pfs");
				if (columnValueInternetVpn != null) {
					vpnBO.setPfs((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("pre_shared_secret");
				if (columnValueInternetVpn != null) {
					vpnBO.setPreSharedSecret((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("sa_lifetime");
				if (columnValueInternetVpn != null) {
					vpnBO.setSaLifetime((String) columnValueInternetVpn);
				}

				columnValueInternetVpn = ivpnRow.getColumnValue("data_center_id");
				if (columnValueInternetVpn != null) {
					vpnBO.setDataCenter(((BigDecimal) columnValueInternetVpn).longValue());
				}

				if (bgpResults != null) {
					BgpBO bgpBO = populateBgpAuditInfo(backhaulId, bgpResults);
					vpnBO.setBgp(bgpBO);
				}
			}
		}
		return internetVPNConfigBO;
	}
	
	/**
	 * Returns the BGP information for audit.
	 * 
	 * @param backhaulId
	 * @param bgpRow
	 * @return BgpBO
	 */
	private BgpBO populateBgpAuditInfo(Long backhaulId, List<RowData> bgpRows) {
		BgpBO bgpBO = null;
		Object columnValueBgp = null;
		for (RowData bgpRow : bgpRows) {

			Long bgpBackhaulId = ((BigDecimal) bgpRow
					.getColumnValue("BACKHAUL_ID")).longValue();

			if (backhaulId.equals(bgpBackhaulId)) {
				bgpBO = new BgpBO();

				bgpBO.setBackhaulId(bgpBackhaulId);

				columnValueBgp = bgpRow.getColumnValue("att_asn");
				if (columnValueBgp != null) {
					bgpBO.setAttAsn((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("att_endpoint_ip");
				if (columnValueBgp != null) {
					bgpBO.setAttEndpointIp((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("att_notes");
				if (columnValueBgp != null) {
					bgpBO.setAttNotes((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("cust_asn");
				if (columnValueBgp != null) {
					bgpBO.setCustAsn(((BigDecimal) columnValueBgp).longValue());
				}

				columnValueBgp = bgpRow.getColumnValue("cust_bgp_peer_ip");
				if (columnValueBgp != null) {
					bgpBO.setCustBgpPeerIp((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("cust_notes");
				if (columnValueBgp != null) {
					bgpBO.setCustNotes((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("routing_policies");
				if (columnValueBgp != null) {
					bgpBO.setRoutingPolicies((String) columnValueBgp);
				}

				columnValueBgp = bgpRow.getColumnValue("general_notes");
				if (columnValueBgp != null) {
					bgpBO.setOtherNotes((String) columnValueBgp);
				}
				break;
			}
		}
		return bgpBO;
	}
	
	/**
	 * Returns the MPLS Config details for the audit info.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return MplsConfigBO
	 * @throws SQLException
	 */
	public MplsConfigBO getMplsAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		Set<MplsBO> mplsBOs = null;
		MplsBO mplsBO = null;
		MplsConfigBO mplsConfigBO = null;
		List<RowData> mplsResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> mplsBgpResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		List<RowData> mplsStaticRouteResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(5));
		List<RowData> vpnResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(6));

		Object columnValue = null;
		Long backhaulId = null;
		if (mplsResults != null && mplsResults.size() > 0) {
			mplsConfigBO = new MplsConfigBO();
			mplsBOs = new HashSet<MplsBO>();
			mplsConfigBO.setMplses(mplsBOs);
			for (RowData mplsRow : mplsResults) {
				mplsBO = new MplsBO();

				columnValue = mplsRow.getColumnValue("BACKHAUL_ID");
				if (columnValue != null) {
					backhaulId = ((BigDecimal) columnValue).longValue();
					mplsBO.setBackhaulId(backhaulId);
				}

				Long vpnId = null;
				columnValue = mplsRow.getColumnValue("vpn_id");
				if (columnValue != null) {
					vpnId = ((BigDecimal) columnValue).longValue();
				}

				columnValue = mplsRow.getColumnValue("backhaul_display_id");
				if (columnValue != null) {
					mplsBO.setBackhaulDisplayId((String) columnValue);
				}

				columnValue = mplsRow.getColumnValue("backhaul_selection");
				if (columnValue != null) {
					mplsBO.setBackhaulSelection((String) columnValue);
				}

				columnValue = mplsRow.getColumnValue("protocol");
				if (columnValue != null) {
					mplsBO.setProtocol((String) columnValue);
				}
				columnValue = mplsRow.getColumnValue("num_static_route");
				if (columnValue != null) {
					mplsBO.setNumStaticRoute(((BigDecimal) columnValue)
							.byteValue());
				}

				columnValue = mplsRow.getColumnValue("remark");
				if (columnValue != null) {
					mplsBO.setRemark((String) columnValue);
				}
				
				columnValue = mplsRow.getColumnValue("exportMap");
				if (columnValue != null) {
					mplsBO.setExportMap((String) columnValue);
				}

				columnValue = mplsRow.getColumnValue("NUM_ROUTES_ACCEPTED");
				if (columnValue != null) {
					mplsBO.setNumRoutesAccepted((String) columnValue);
				}

				columnValue = mplsRow.getColumnValue("MAX_NUM_BGP_ROUTES");
				if (columnValue != null) {
					mplsBO.setMaxNumBgpRoutes(((BigDecimal) columnValue).shortValue());
				}

				columnValue = mplsRow.getColumnValue("data_center_id");
				if (columnValue != null) {
					mplsBO.setDataCenter(((BigDecimal) columnValue).longValue());
				}
				
				// BUC 1.1.0015 Starts
				columnValue = mplsRow.getColumnValue("MPLS_CIR");
				if (columnValue != null) {
					mplsBO.setMplsCir(((String) columnValue));
				}

				columnValue = mplsRow.getColumnValue("ROUTE_DISTINGUISHER");
				if (columnValue != null) {
					mplsBO.setRouteDistinguisher(((String) columnValue));
				}
				// Ends

				columnValue = mplsRow.getColumnValue("OWNER");
				if (columnValue != null) {
					mplsBO.setOwner((Long) columnValue);
					if(orderId.equals(columnValue)){
						mplsBO.setEditable(true);
					}
				}
				
				if (mplsBgpResults != null) {
					BgpBO bgpBO = populateBgpAuditInfo(backhaulId, mplsBgpResults);
					mplsBO.setBgp(bgpBO);
				}

				if (mplsStaticRouteResults != null) {
					Set<StaticRouteBO> routeBOs = populateStatisRouteAuditInfo(backhaulId, mplsStaticRouteResults);
					mplsBO.setStaticRoutes(routeBOs);

				}

				if (vpnResults != null) {
					VpnBO vpnBO = this.populateVpnInfo(vpnId, vpnResults);
					mplsBO.setVpn(vpnBO);
				}
				
				mplsBOs.add(mplsBO);
			}
		}
		return mplsConfigBO;
	}

	/**
	 * Returns the Static route info for auidt.
	 * 
	 * @param backhaulId
	 * @param mplsStaticRouteResults
	 * @return Set<StaticRouteBO>
	 */
	private Set<StaticRouteBO> populateStatisRouteAuditInfo(Long backhaulId, List<RowData> mplsStaticRouteResults) {
		Set<StaticRouteBO> routeBOs = new HashSet<StaticRouteBO>();
		Object columnValueStaticRoutes = null;
		for (RowData staticRouteRow : mplsStaticRouteResults) {
			Long srBackhaulId = ((BigDecimal) staticRouteRow
					.getColumnValue("BACKHAUL_ID")).longValue();
			if (backhaulId.equals(srBackhaulId)) {
				StaticRouteBO staticRouteBO = new StaticRouteBO();
				if (routeBOs == null) {
					routeBOs = new HashSet<StaticRouteBO>();
				}
				routeBOs.add(staticRouteBO);
				staticRouteBO.setBackhaulId(srBackhaulId);

				columnValueStaticRoutes = staticRouteRow.getColumnValue("ip_address");
				if (columnValueStaticRoutes != null) {
					staticRouteBO.setIpAddress((String) columnValueStaticRoutes);
				}

				columnValueStaticRoutes = staticRouteRow.getColumnValue("mask");
				if (columnValueStaticRoutes != null) {
					staticRouteBO.setMask((String) columnValueStaticRoutes);
				}
			}
		}
		return routeBOs;
	}

	/**
	 * Returns the VPN Info details for audit.
	 * 
	 * @param vpnId
	 * @param vpnResults
	 * @return VpnBO
	 */
	private VpnBO populateVpnInfo(Long vpnId, List<RowData> vpnResults) {
		VpnBO vpnBO = null;
		Object columnValue = null;

		for (RowData rowData : vpnResults) {
			if (vpnId != null && vpnId.equals(rowData.getColumnValue("vpn_id"))) {
				vpnBO = new VpnBO();
				vpnBO.setVpnId(vpnId);

				columnValue = rowData.getColumnValue("created_by_order_id");
				if (columnValue != null) {
					vpnBO.setOrderId(((BigDecimal) columnValue).longValue());
				}

				columnValue = rowData.getColumnValue("bcid");
				if (columnValue != null) {
					vpnBO.setBcid((String) columnValue);
				}

				columnValue = rowData.getColumnValue("cipn");
				if (columnValue != null) {
					vpnBO.setCipn((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_name");
				if (columnValue != null) {
					vpnBO.setVpnName((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_cust_contact");
				if (columnValue != null) {
					vpnBO.setVpnCustContact((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_company_name");
				if (columnValue != null) {
					vpnBO.setVpnCompanyName((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_type");
				if (columnValue != null) {
					vpnBO.setVpnType((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_mcn");
				if (columnValue != null) {
					vpnBO.setVpnMcn((String) columnValue);
				}

				columnValue = rowData.getColumnValue("vpn_grc");
				if (columnValue != null) {
					vpnBO.setVpnGrc((String) columnValue);
				}

				columnValue = rowData.getColumnValue("status");
				if (columnValue != null) {
					vpnBO.setStatus((String) columnValue);
				}

				columnValue = rowData.getColumnValue("derived_from_vpn");
				if (columnValue != null) {
					vpnBO.setDerivedFromVpn(((BigDecimal) columnValue).longValue());
				}
				
				// INSTAR code starts here
				columnValue = rowData.getColumnValue("primary_rt");
				if (columnValue != null) {
					vpnBO.setPrimaryRT((String) columnValue);
				}
				columnValue = rowData.getColumnValue("icore_cust_id");
				if (columnValue != null) {
					vpnBO.setIcoreCustId(((BigDecimal) columnValue).longValue());
				}
				columnValue = rowData.getColumnValue("icore_cust_name");
				if (columnValue != null) {
					vpnBO.setIcoreCustName((String) columnValue);
				}

				columnValue = rowData.getColumnValue("instar_vpn_id");
				if (columnValue != null) {
					vpnBO.setInstarVPNId(((BigDecimal) columnValue).longValue());
				}

				columnValue = rowData.getColumnValue("instar_vpn_status");
				if (columnValue != null) {
					vpnBO.setInstarVPNStatus((String) columnValue);
				}

				columnValue = rowData.getColumnValue("order_driven_by");
				if (columnValue != null) {
					vpnBO.setOrderDrivenBy((String) columnValue);
				}
				// INSTAR code ends here
				break;
			}
		}
		return vpnBO;
	}

}
