package com.att.comet.dao.hibernate.bean;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderProcess. Mapped to BPM_ORDER_PROCESS in the
 * database table.
 */
@Entity
@Table(name = "BPM_ORDER_PROCESS")
public class BpmOrderProcess implements java.io.Serializable {

	private static final long serialVersionUID = 8081237181485693595L;

	private BpmOrderProcessId id;
	private BpmStatus bpmStatus;
	private OrderType orderType;
	private Orders orders;
	private BpmProcess bpmProcess;
	private Date processExecutedOn;
	private String userDecision;
	private Date userDecisionOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderProcessId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "processId", column = @Column(name = "PROCESS_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)) })
	public BpmOrderProcessId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderProcessId id) {
		this.id = id;
	}

	/**
	 * Getter method for bpmStatus. BPM_STATUS_ID mapped to BPM_STATUS_ID in the
	 * database table.
	 * 
	 * @return BpmStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BPM_STATUS_ID")
	public BpmStatus getBpmStatus() {
		return this.bpmStatus;
	}

	/**
	 * @param bpmStatus to bpmStatus set.
	 */
	public void setBpmStatus(BpmStatus bpmStatus) {
		this.bpmStatus = bpmStatus;
	}

	/**
	 * Getter method for orderType. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return OrderType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_TYPE_ID", nullable = false, insertable = false, updatable = false)
	public OrderType getOrderType() {
		return this.orderType;
	}

	/**
	 * @param orderType to orderType set.
	 */
	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for bpmProcess.
	 * 
	 * @return BpmProcess
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PROCESS_ID", nullable = false, insertable = false, updatable = false)
	public BpmProcess getBpmProcess() {
		return this.bpmProcess;
	}

	/**
	 * @param bpmProcess to bpmProcess set.
	 */
	public void setBpmProcess(BpmProcess bpmProcess) {
		this.bpmProcess = bpmProcess;
	}

	/**
	 * Getter method for processExecutedOn. PROCESS_EXECUTED_ON mapped to
	 * PROCESS_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "PROCESS_EXECUTED_ON")
	public Date getProcessExecutedOn() {
		return this.processExecutedOn;
	}

	/**
	 * @param processExecutedOn to processExecutedOn set.
	 */
	public void setProcessExecutedOn(Date processExecutedOn) {
		this.processExecutedOn = processExecutedOn;
	}

	/**
	 * Getter method for userDecision. USER_DECISION mapped to USER_DECISION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_DECISION", length = 100)
	public String getUserDecision() {
		return this.userDecision;
	}

	/**
	 * @param userDecision to userDecision set.
	 */
	public void setUserDecision(String userDecision) {
		this.userDecision = userDecision;
	}

	/**
	 * Getter method for userDecisionOn. USER_DECISION_ON mapped to USER_DECISION_ON
	 * in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "USER_DECISION_ON")
	public Date getUserDecisionOn() {
		return this.userDecisionOn;
	}

	/**
	 * @param userDecisionOn to userDecisionOn set.
	 */
	public void setUserDecisionOn(Date userDecisionOn) {
		this.userDecisionOn = userDecisionOn;
	}

	/**
	 * Getter method for comments COMMENTS mapped to COMMENTS in the database table.
	 * 
	 * @return String.
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
}
