package com.att.comet.manage.modal;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class InOutInterfaceCSVLineBO extends LineBO{

	private static final long serialVersionUID = 1L;
	private int recordNumber;
	private String actionField;
	private String dataCenter;
	private String insideBase;
	private String outsideBase;
	private String gwSgiContext;
	private String rdRt;
	
}
