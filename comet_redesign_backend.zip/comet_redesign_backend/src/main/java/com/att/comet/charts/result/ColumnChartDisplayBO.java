package com.att.comet.charts.result;

import java.util.ArrayList;
import java.util.List;

public class ColumnChartDisplayBO<T> implements DisplayResultBO {

	private static final long serialVersionUID = 2908326343044675480L;
	
	private List<T> lstChartBOs = new ArrayList<T>();

	public List<T> getLstChartBOs() {
		return lstChartBOs;
	}

	public void setLstChartBOs(List<T> lstChartBOs) {
		this.lstChartBOs = lstChartBOs;
	}

}
