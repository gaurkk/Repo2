package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for OrderCapacityForecastId.
 */
@Embeddable
public class OrderCapacityForecastId implements java.io.Serializable {

	private static final long serialVersionUID = 3027276389428233718L;

	private Long orderId;
	private Short year;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for year. YEAR mapped to YEAR in the database table.
	 * 
	 * @return Short
	 */
	@Column(name = "YEAR", nullable = false, precision = 4, scale = 0)
	public Short getYear() {
		return this.year;
	}

	/**
	 * @param year to year set.
	 */
	public void setYear(Short year) {
		this.year = year;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderCapacityForecastId other = (OrderCapacityForecastId) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}

}