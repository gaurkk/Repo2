package com.att.comet.manage.modal;

import java.io.Serializable;

public interface InventoryBO extends Serializable{

}
