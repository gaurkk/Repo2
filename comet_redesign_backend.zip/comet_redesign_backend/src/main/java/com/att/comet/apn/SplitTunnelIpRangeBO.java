package com.att.comet.apn;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper=true)
public class SplitTunnelIpRangeBO extends CometGenericBO {
	private static final long serialVersionUID = -5021789295925057794L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String splitTunnelIpRange;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long splitTunnelIpRangeId;
}

