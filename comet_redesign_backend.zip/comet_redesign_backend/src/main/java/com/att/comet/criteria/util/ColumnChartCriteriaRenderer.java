package com.att.comet.criteria.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.exception.SQLGrammarException;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.charts.result.ColumnChartDisplayBO;
import com.att.comet.charts.result.OrderInProdColumnChartBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.dao.ChartsSqlConstants;
import com.att.comet.dao.ScalarConstants;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.order.OrderInProductionYearRestriction;

@Component
public class ColumnChartCriteriaRenderer extends CriteriaRenderer{
	private static final Logger logger = LoggerFactory.getLogger(ColumnChartCriteriaRenderer.class);

	@PersistenceContext
	EntityManager em;
	
	@Override
	public ResultBO createExecuteQuery(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQuery : ", this);
		ResultBO result = null;
		StringBuilder sql= new StringBuilder();
		if(criteria.getRestrictions().size() > 0)
		{
			//Get Base query
			sql.append(ChartsSqlConstants.BASE_QUERY_FOR_COLUMNCHART);///TODO
			if(CommonUtils.isNullEmpty(sql.toString()))
				return null;
			for(Restriction res : criteria.getRestrictions())
			{
				if(CommonUtils.isNotNullEmpty(res.toSqlString()))
				{
					if(res instanceof OrderInProductionYearRestriction)
					{
					    while (sql.lastIndexOf("@YEAR") != -1) {
					    	sql.replace(sql.indexOf("@YEAR"), sql.indexOf("@YEAR") + 5 , res.toSqlString());
					    }
					}
				}	
			}
			if(criteria.getRestrictions().size() > 0)
			{
				sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
			}
			result = executeQuery(sql.toString(), criteria);
		}
		logger.info("Exiting method createExecuteQuery : ", this);
		return result;
	}
	
	/**
	 * Execute query for Bar Chart
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeQuery : ", this);
		ResultBO objBO = null;
		try {
			
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.MONTH, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.COUNT, IntegerType.INSTANCE);
			
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			Map<String, Object> resultMap = null;
			List<OrderInProdColumnChartBO> chartList = new ArrayList<OrderInProdColumnChartBO>();
			ColumnChartDisplayBO<OrderInProdColumnChartBO> chartDispBO = new ColumnChartDisplayBO<OrderInProdColumnChartBO>();
			Object columnObject = null;
			
			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					OrderInProdColumnChartBO barChartBO = new OrderInProdColumnChartBO();

					resultMap = itr.next();
					columnObject = resultMap.get(ScalarConstants.MONTH);
					if (null != columnObject) {
						barChartBO.setMonth((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.COUNT);
					if (null != columnObject) {
						barChartBO.setCount((Integer) columnObject);
					}
					chartList.add(barChartBO);
				}
				chartDispBO.setLstChartBOs(chartList);
				objBO.setLstResult(chartDispBO);
				objBO.getOtherBO().setTitle("In Production Order");
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeQuery : ", this);
		return objBO;
	}	
	
}
