package com.att.comet.instar.soapclient.vpn;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

import com.att.comet.common.util.CommonUtils;
import com.att.comet.instar.soapclient.vpn.constant.ClientRequestConstant;
import com.att.comet.order.modal.CustomerInfoBO;
import com.att.comet.order.modal.VPNInfoBO;
import com.att.comet.order.modal.VPNSearchCriteriaBO;
import com.att.comet.order.modal.VPNSearchResultBO;

/**
 * CLASS TO CALL INSTAR SEARCH VPN WEBSERVICE
 * @author pd6080
 *
 */
@Component
public class SearchVPNServiceCall {

	private static final Logger logger = LoggerFactory.getLogger(SearchVPNServiceCall.class);
	

	public List<VPNSearchResultBO> invokeSearchVPN(VPNSearchCriteriaBO vpnSearchCriteriaBO,String ICORE_HOST) throws IOException {
		logger.info("[VPN : " + (vpnSearchCriteriaBO.getVpnName() == null ? "" : vpnSearchCriteriaBO.getVpnName()) + "] " + "Starting method invokeSearchVPN : ",
				this);
		String url =ICORE_HOST;
		logger.info("ICORE HOST URL :::"+ICORE_HOST);
		String soapEnvelop =  ClientRequestConstant.vpnSearchSoapEnvRequestHeader;
		String vpnNameRequestParam = "<tns:VpnName>"+vpnSearchCriteriaBO.getVpnName()+"</tns:VpnName>\r\n";
		String vpnServiceRequestParam ="<tns:Service>AVPN</tns:Service>\r\n";
		String customerIdRequestParam =null;
		String customerNameRequestParam = null;
		String vpnSearchRequest = null;
		if(null!=vpnSearchCriteriaBO.getIcoreCustId() && !StringUtils.isEmpty(vpnSearchCriteriaBO.getIcoreCustId())) {
			customerIdRequestParam	 ="<tns:CustomerId>"+vpnSearchCriteriaBO.getIcoreCustId()+"</tns:CustomerId>\r\n";
		}
		if(null!=vpnSearchCriteriaBO.getIcoreCustName()&& !StringUtils.isEmpty(vpnSearchCriteriaBO.getIcoreCustName())) {
			customerNameRequestParam="<tns:CustomerName>"+vpnSearchCriteriaBO.getIcoreCustName()+"</tns:CustomerName>";
		}
		if(null!=vpnNameRequestParam && null!=customerIdRequestParam && null!=customerNameRequestParam) {
			StringBuilder request = new StringBuilder(soapEnvelop);
			request.append(soapEnvelop).append(ClientRequestConstant.vpnSearchHeaderBody1).append(vpnNameRequestParam).append(vpnServiceRequestParam)
			.append(customerIdRequestParam).append(customerNameRequestParam).append(ClientRequestConstant.vpnSearchHeaderBody2);
			 vpnSearchRequest = request.toString();
		}else {
			StringBuilder request = new StringBuilder(soapEnvelop);
			request.append(soapEnvelop).append(ClientRequestConstant.vpnSearchHeaderBody1).append(vpnNameRequestParam).append(vpnServiceRequestParam).append(ClientRequestConstant.vpnSearchHeaderBody2);;
			vpnSearchRequest = request.toString();
		}
		//CONSTRUCTING URL CONNECTION WITH INSTAR SOAP
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type","application/soap+xml; charset=utf-8");
		 
		 con.setDoOutput(true);
		 DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		 wr.writeBytes(vpnSearchRequest);
		 wr.flush();
		 wr.close();
		 String responseStatus = con.getResponseMessage();
		 logger.info("CONNECTION STATUS FROM INSTAR VPN ::[" +responseStatus+"]", this);
		 logger.info("RESPONSE STATUS FROM INSTAR VPN ::[" +responseStatus+"]"+"VPN NAME :"+vpnSearchCriteriaBO.getVpnName(), this);
		 BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		 String inputLine;
	     StringBuffer response = new StringBuffer();
		 while ((inputLine = in.readLine()) != null) {
			 response.append(inputLine);
			 }
		 in.close();
		 Document doc = SoapClientHelper.convertStringToDocument(response.toString());
		 
		 NodeList nList = doc.getElementsByTagName("ns2:VpnInfo");
		 List<VPNSearchResultBO> vpnSearchResultBOList = new ArrayList<VPNSearchResultBO>();
		 for (int temp = 0; temp < nList.getLength(); temp++) {
			 Node nNode = nList.item(temp);
			 VPNSearchResultBO vpnSearchResultBO = new VPNSearchResultBO();
			 VPNInfoBO vpnInfoBO = new VPNInfoBO();
			 CustomerInfoBO customerInfoBO = new CustomerInfoBO();
			 if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               logger.debug("\n VpnId :" +eElement.getElementsByTagName("ns2:VpnId").item(0).getTextContent(), this);
	               vpnInfoBO.setVpnId(Long.parseLong(eElement.getElementsByTagName("ns2:VpnId").item(0).getTextContent()));
	               logger.debug("\n VpnName :" +eElement.getElementsByTagName("ns2:VpnName").item(0), this);
	               vpnInfoBO.setVpnName(eElement.getElementsByTagName("ns2:VpnName").item(0).getTextContent());
	              
	               logger.debug("\n PrimaryRouteTarget :" +eElement.getElementsByTagName("ns2:PrimaryRouteTarget").item(0), this);
	               vpnInfoBO.setPrimaryRouteTarget(eElement.getElementsByTagName("ns2:PrimaryRouteTarget").item(0).getTextContent());
	               
	               logger.debug("\n MaxRoutes :" +eElement.getElementsByTagName("ns2:MaxRoutes").item(0), this);
	               vpnInfoBO.setMaxRoutes(Long.parseLong(eElement.getElementsByTagName("ns2:MaxRoutes").item(0).getTextContent()));
	              
	               logger.debug("\n EngineeredRoutes :" +eElement.getElementsByTagName("ns2:EngineeredRoutes").item(0), this);
	               vpnInfoBO.setEngineeredRoutes(Long.parseLong(eElement.getElementsByTagName("ns2:EngineeredRoutes").item(0).getTextContent()));
	            
	               for (int temp1 = 0; temp1 < eElement.getElementsByTagName("ns2:CustInfo").getLength(); temp1++) {
	            	   	  logger.debug("\n ICORECustId :" +eElement.getElementsByTagName("ns2:ICORECustId").item(0), this);
		            	  customerInfoBO.setiCoreCustId(Long.parseLong(eElement.getElementsByTagName("ns2:ICORECustId").item(0).getTextContent()));
		            	  logger.debug("\n ICORECustomerName :" +eElement.getElementsByTagName("ns2:ICORECustomerName").item(0), this);
		            	  customerInfoBO.setiCoreCustName(eElement.getElementsByTagName("ns2:ICORECustomerName").item(0).getTextContent());
	               }
			 }
			 vpnSearchResultBO.setVpnInfo(vpnInfoBO);
			 vpnSearchResultBO.setCustomerInfoBO(customerInfoBO);
			 vpnSearchResultBOList.add(vpnSearchResultBO);
		 }
		if(CollectionUtils.isEmpty(vpnSearchResultBOList)) {
			logger.info("No result from Icore Instar::", "result list is empty");
			logger.error("No result from Icore Instar::", "result list is empty");
		}
		 logger.info("[VPN : " + (vpnSearchCriteriaBO.getVpnName() == null ? "" : vpnSearchCriteriaBO.getVpnName()) + "] " + "Ending method invokeSearchVPN : ",
					this);
		return vpnSearchResultBOList;
	}
}
