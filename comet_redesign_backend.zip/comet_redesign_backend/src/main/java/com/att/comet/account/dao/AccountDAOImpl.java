package com.att.comet.account.dao;

import static com.att.comet.account.dao.AccountConstant.GET_EXTERNAL_ACCOUNT_SEARCH_QUERY;
import static com.att.comet.account.dao.AccountConstant.GET_EXTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED;
import static com.att.comet.account.dao.AccountConstant.GET_EXTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
import static com.att.comet.account.dao.AccountConstant.GET_INTERNAL_ACCOUNT_SEARCH_QUERY;
import static com.att.comet.account.dao.AccountConstant.GET_INTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED;
import static com.att.comet.account.dao.AccountConstant.GET_INTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
import static com.att.comet.dao.BindingConstants.ACCOUNT_CLASS_BC;
import static com.att.comet.dao.BindingConstants.ACCOUNT_CREATED_BY_BC;
import static com.att.comet.dao.BindingConstants.ACCOUNT_TYPE_BC;
import static com.att.comet.dao.BindingConstants.BCID_BC;
import static com.att.comet.dao.BindingConstants.CIPN_BC;
import static com.att.comet.dao.BindingConstants.COMPANY_NAME_BC;
import static com.att.comet.dao.BindingConstants.COMPANY_OWNER_BC;
import static com.att.comet.dao.BindingConstants.CREATION_DATE_FROM_BC;
import static com.att.comet.dao.BindingConstants.CREATION_DATE_TO_BC;
import static com.att.comet.dao.BindingConstants.FEDERAL_TAX_ID_BC;
import static com.att.comet.dao.BindingConstants.UBCID_BC;
import static com.att.comet.dao.ScalarConstants.ACCOUNT_CREATED_BY;
import static com.att.comet.dao.ScalarConstants.ACCOUNT_CREATED_ON;
import static com.att.comet.dao.ScalarConstants.ACCOUNT_CREATED_ON1;
import static com.att.comet.dao.ScalarConstants.ACCOUNT_TYPE;
import static com.att.comet.dao.ScalarConstants.APN_NAME_QUERY;
import static com.att.comet.dao.ScalarConstants.CIPN;
import static com.att.comet.dao.ScalarConstants.INTERNAL_PRODUCT_INITIATIVE_NAME;
import static com.att.comet.dao.ScalarConstants.PDP_ID_QUERY;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.account.helper.AccountHelper;
import com.att.comet.account.modal.AccountBO;
import com.att.comet.account.modal.AccountFileDetailBO;
import com.att.comet.account.modal.AccountInfoBO;
import com.att.comet.account.modal.AccountSearchCriteriaBO;
import com.att.comet.account.modal.InternalAccountBO;
import com.att.comet.account.modal.InternalProductAccountBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.account.modal.ProductAccountBO;
import com.att.comet.account.modal.SubAccountBO;
import com.att.comet.account.repository.ApnNameRepository;
import com.att.comet.account.repository.InternalInitiativeAccountRepository;
import com.att.comet.account.repository.InternalProductAccountRepository;
import com.att.comet.account.repository.MasterAccountRepository;
import com.att.comet.account.repository.ProductInitiativeAccountRepository;
import com.att.comet.account.repository.SubAccountRepositoryforSubAccount;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.dao.hibernate.bean.AccountClass;
import com.att.comet.dao.hibernate.bean.InternalProductAccount;
import com.att.comet.dao.hibernate.bean.MasterAccount;
import com.att.comet.dao.hibernate.bean.SubAccount;

@Component
public class AccountDAOImpl implements AccountDAO {
	private static final Logger logger = LoggerFactory.getLogger(AccountDAOImpl.class);

	@Autowired
	MasterAccountRepository masterAccountRepository;

	@Autowired
	SubAccountRepositoryforSubAccount subAccountRepository;

	@Autowired
	InternalInitiativeAccountRepository internalInitiativeAccountRepository;

	@Autowired
	ProductInitiativeAccountRepository productInitiativeAccountRepository;

	@Autowired
	ApnNameRepository apnNameRepository;

	@Autowired
	InternalProductAccountRepository internalProductAccountRepository;

	@PersistenceContext
	EntityManager em;

	@Autowired
	AccountHelper accountHelper;

	@SuppressWarnings("deprecation")
	@Override
	public List<AccountBO> getExternalAccounts(AccountSearchCriteriaBO criteria) throws CometDataException {
		logger.info("Stating method getExternalAccounts : ", this);
		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Started getting data for External Accounts");
		ArrayList<AccountBO> responseList = new ArrayList<AccountBO>();

		try {
			Map<String, Object> bindParamMap = new HashMap<String, Object>();
			String query = getExternalSearchQuery(criteria, bindParamMap);
			
			Query sqlQuery = em.createNativeQuery(query.toString());
			ServiceUtils.setQueryParameters(sqlQuery, bindParamMap);
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			// TODO - Convert below logic to Lambda
			Map<String, Object> resultMap = null;
			Object columnObject = null;
			Object columnObject1 = null;
			AccountBO response = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();
				while (itr.hasNext()) {
					response = new AccountBO();
					resultMap = itr.next();

					columnObject = resultMap.get("UBCID");
					if (null != columnObject) {
						response.setUbcid(columnObject.toString());
					} else {
						response.setUbcid(" ");
					}

					columnObject = resultMap.get("MASTER_ACCOUNT_NAME");
					if (null != columnObject) {
						response.setMasterAccountName((String) columnObject);
					} else {
						response.setMasterAccountName(" ");
					}

					columnObject = resultMap.get("BCID");
					if (null != columnObject) {
						response.setBcid(columnObject.toString());
					} else {
						response.setBcid(" ");
					}

					columnObject = resultMap.get("SUB_ACCOUNT_NAME");
					if (null != columnObject) {
						response.setSubAccountName((String) columnObject);
					} else {
						response.setSubAccountName(" ");
					}

					columnObject = resultMap.get("ACCOUNT_TYPE");
					if (null != columnObject) {
						response.setAccountType((String) columnObject);
					} else {
						response.setAccountType(" ");
					}

					columnObject = resultMap.get("COMPANY_OWNER");
					if (null != columnObject) {
						response.setCompanyOwner((String) columnObject);
					} else {
						response.setCompanyOwner(" ");
					}

					columnObject = resultMap.get("CREATED_BY");
					if (null != columnObject) {
						response.setAccountCreatedBy((String) columnObject);
					} else {
						response.setAccountCreatedBy(" ");
					}

					columnObject = resultMap.get("CREATED_ON");
					columnObject1 = resultMap.get("CREATED_ON1");
					if (null != columnObject) {
						response.setAccountCreatedOn((String) columnObject);
					} else if (null != columnObject1) {
						response.setAccountCreatedOn((String) columnObject1);
					} else {
						response.setAccountCreatedOn(" ");
					}

					columnObject = resultMap.get("ACCOUNT_CLASS_ID");
					if (null != columnObject) {
						response.setAccountClassId(((BigDecimal) columnObject).longValue());
					} else {
						response.setAccountClassId(null);
					}

					columnObject = resultMap.get("CITY_NAME");
					if (null != columnObject) {
						response.setCityName((String) columnObject);
					} else {
						response.setCityName("");
					}

					columnObject = resultMap.get("STATE_NAME");
					if (null != columnObject) {
						response.setStateName((String) columnObject);
					} else {
						response.setStateName("");
					}
					columnObject = resultMap.get("HL_STREET_ADDRESS");
					if (null != columnObject) {
						response.setStreetAddress((String) columnObject);
					} else {
						response.setStreetAddress("");
					}
					columnObject = resultMap.get("HL_ZIP_CODE");
					if (null != columnObject) {
						response.setZipCode((String) columnObject);
					} else {
						response.setZipCode("");
					}

					responseList.add(response);
					response = null;
				}
			}

		} catch (Exception exception) {
			logger.error(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + exception.getStackTrace());
			exception.printStackTrace();
			logger.error(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Exception in getting external accounts",
					exception);
			throw new CometDataException("DA001", exception);
		}
		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Finished getting data for External Accounts");
		logger.info("Exiting method getExternalAccounts : ", this);
		return responseList;
	}

	/**
	 * Create the search account query for Master account
	 * 
	 * @param criteria
	 * @param bindParamMap
	 * @return
	 */
	private String getExternalSearchQuery(AccountSearchCriteriaBO criteria, Map<String, Object> bindParamMap) {
		logger.info("Starting method getExternalSearchQuery : ", this);
		StringBuilder queryBuilder = new StringBuilder();
		String queryConstant = GET_EXTERNAL_ACCOUNT_SEARCH_QUERY;
		String queryClause = GET_EXTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
		boolean orderApnTableAdded = false;
		boolean orderDomainNameAdded = false;
		boolean orderPdpIdAdded = false;
		boolean orderPdpIdAddedPdpName = false;

		if (criteria.getApnName() != null) {
			orderApnTableAdded = true;
			orderPdpIdAdded = true;
			queryConstant = queryConstant + APN_NAME_QUERY;
		}

		if (criteria.getPdpName() != null) {
			orderPdpIdAdded = false;
			if (!orderApnTableAdded) {
				orderDomainNameAdded = true;
				queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
			} else {
				queryConstant = queryConstant + PDP_ID_QUERY;
			}
		}

		if (criteria.getPdpid() != null) {
			if (!orderDomainNameAdded && !orderApnTableAdded) {
				if (criteria.getApnName() != null) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				} else {
					orderPdpIdAddedPdpName = true;
					queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
				}
			} else {
				if (orderPdpIdAdded) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				}
			}
		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			if (!orderApnTableAdded && !orderDomainNameAdded && !orderPdpIdAddedPdpName)
				queryConstant = queryConstant + APN_NAME_QUERY;
		}

		queryConstant = queryConstant + queryClause;
		queryBuilder.append(queryConstant);
		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Creating query for MasterAccountName/SubAccountName search.");

		String singleQuote = "'";
		String accountName;

		/* Master Account Name */
		accountName = criteria.getMasterAccountName();
		if (CommonUtils.isValidString(accountName)) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "MasterAccountName " + criteria.getMasterAccountName());
			accountName = accountName.replace('*', '%');
			queryBuilder.append(" AND lower(ma.master_account_name) like " + singleQuote + accountName.toLowerCase()
					+ singleQuote + " ");
		}

		/* Sub Account Name */
		accountName = criteria.getSubAccountName();
		if (CommonUtils.isValidString(accountName)) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "SubAccountName :" + criteria.getSubAccountName());
			accountName = accountName.replace('*', '%');
			queryBuilder.append(" AND lower(sa.sub_account_name) like " + singleQuote + accountName.toLowerCase()
					+ singleQuote + " ");
		}

		if (criteria.getUbcid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "UBCID " + criteria.getUbcid());
			queryBuilder.append("AND ma.ubcid = :" + UBCID_BC + " ");
			bindParamMap.put(UBCID_BC, criteria.getUbcid());

		}
		if (criteria.getBcid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "BCID " + criteria.getBcid());
			queryBuilder.append("AND sa.bcid = :" + BCID_BC + " ");
			bindParamMap.put(BCID_BC, criteria.getBcid());
		}

		if (CommonUtils.isValidString(criteria.getCompanyOwner())) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Company Owner " + criteria.getCompanyOwner());
			queryBuilder.append("AND lower(sa.company_owner) = :" + COMPANY_OWNER_BC + " ");
			bindParamMap.put(COMPANY_OWNER_BC, criteria.getCompanyOwner().toLowerCase());
		}

		if (CommonUtils.isValidString(criteria.getAccountCreatedBy())) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created By " + criteria.getAccountCreatedBy());
			queryBuilder.append("AND lower(sa.created_by) = :" + ACCOUNT_CREATED_BY_BC + " ");
			bindParamMap.put(ACCOUNT_CREATED_BY_BC, criteria.getAccountCreatedBy().toLowerCase());
		}

		if (criteria.getCreationDateFrom() != null && criteria.getCreationDateTo() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created From = " + criteria.getCreationDateFrom());
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created To = " + criteria.getCreationDateTo());
			queryBuilder.append("AND sa.created_on > TO_DATE (:" + CREATION_DATE_FROM_BC
					+ ", 'MM/DD/YYYY')  and sa.created_on  < TO_DATE(:" + CREATION_DATE_TO_BC + ",'MM/DD/YYYY')");
			bindParamMap.put(CREATION_DATE_FROM_BC, criteria.getCreationDateFrom());
			bindParamMap.put(CREATION_DATE_TO_BC, criteria.getCreationDateTo());
		}

		if (criteria.getFederalTaXId() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Federal Tax Id = :" + criteria.getFederalTaXId());
			queryBuilder.append("AND sa.federal_tax_id = :" + FEDERAL_TAX_ID_BC + " ");
			bindParamMap.put(FEDERAL_TAX_ID_BC, criteria.getFederalTaXId());
		}

		if (CommonUtils.isValidString(criteria.getCompanyName())) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Company Name = :" + criteria.getCompanyName());
			queryBuilder.append("AND sa.company_name = :" + COMPANY_NAME_BC + " ");
			bindParamMap.put(COMPANY_NAME_BC, criteria.getCompanyName());
		}

		if (criteria.getAccountType() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Type = " + criteria.getAccountType());
			queryBuilder.append(" AND sa.account_type = :" + ACCOUNT_TYPE_BC + " ");
			bindParamMap.put(ACCOUNT_TYPE_BC, criteria.getAccountType());
		}

		if (criteria.getApnName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Apn Name Type = " + criteria.getApnName());
			String apnName = criteria.getApnName().toString();
			apnName = apnName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND lower(ap.apn_name) like " + singQuote + apnName.toLowerCase() + singQuote + " ");
			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
		}

		if (criteria.getPdpName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + " [PdpName = " + criteria.getPdpName() + "] ");
			String pdpName = criteria.getPdpName().toString();
			pdpName = pdpName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND ( lower(pdpinfo.auto_pdp_name) like " + singQuote + pdpName.toLowerCase()
					+ singQuote + " or lower(pdpinfo.user_pdp_name) like " + singQuote + pdpName.toLowerCase()
					+ singQuote + ")");

		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + criteria.getCustomerOwnedDomainName());
			String domainName = criteria.getCustomerOwnedDomainName().toString();
			domainName = domainName.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + domainName);
			String singQuote = "'";

			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(
					" AND lower(ap.domain_name) like " + singQuote + domainName.toLowerCase() + singQuote + " ");
		}

		if (criteria.getPdpid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + criteria.getPdpid());
			String pdpId = criteria.getPdpid().toString();
			pdpId = pdpId.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + pdpId);
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND ( pdpinfo.auto_pdp_id like " + singQuote + pdpId + singQuote
					+ " or pdpinfo.user_pdp_id like " + singQuote + pdpId + singQuote + ")");
			logger.info(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "queryBuilder: " + queryBuilder);

		}

		String searchForDedicatedAPN = "";
		searchForDedicatedAPN = getExternalSearchForDedicatedAPN(criteria);

		queryBuilder.append(searchForDedicatedAPN);

		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Search Master AccountBO final query [" + queryBuilder.toString() + "]");
		logger.info("Exiting method getExternalSearchQuery : ", this);
		return queryBuilder.toString();

	}

	/**
	 * Create the search account query for Dedicated APN
	 * 
	 * @param criteria
	 * @return
	 */
	private String getExternalSearchForDedicatedAPN(AccountSearchCriteriaBO criteria) {
		logger.info("Starting method getExternalSearchForDedicatedAPN : ", this);
		if (criteria.getApnName() == null && criteria.getPdpName() == null
				&& criteria.getCustomerOwnedDomainName() == null && criteria.getPdpid() == null) {
			return "";
		}

		StringBuilder queryBuilder = new StringBuilder();
		String queryConstant = GET_EXTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED;
		String queryClause = GET_EXTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
		boolean orderApnTableAdded = false;
		boolean orderDomainNameAdded = false;
		boolean orderPdpIdAdded = false;
		boolean orderPdpIdAddedPdpName = false;

		if (criteria.getApnName() != null) {
			orderApnTableAdded = true;
			orderPdpIdAdded = true;
			queryConstant = queryConstant + APN_NAME_QUERY;
		}

		if (criteria.getPdpName() != null) {
			orderPdpIdAdded = false;
			if (!orderApnTableAdded) {
				orderDomainNameAdded = true;
				queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
			} else {
				queryConstant = queryConstant + PDP_ID_QUERY;
			}
		}

		if (criteria.getPdpid() != null) {
			if (!orderDomainNameAdded && !orderApnTableAdded) {
				if (criteria.getApnName() != null) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				} else {
					orderPdpIdAddedPdpName = true;
					queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
				}
			} else {
				if (orderPdpIdAdded) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				}
			}
		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			if (!orderApnTableAdded && !orderDomainNameAdded && !orderPdpIdAddedPdpName)
				queryConstant = queryConstant + APN_NAME_QUERY;
		}

		queryConstant = queryConstant + queryClause;
		queryBuilder.append(queryConstant);
		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Creating query for MasterAccountName/SubAccountName search.");

		if (criteria.getApnName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Apn Name Type in Dedicated APN = " + criteria.getApnName());
			String apnName = criteria.getApnName().toString();
			apnName = apnName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND lower(dap.apn_name) like " + singQuote + apnName.toLowerCase() + singQuote + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
		}

		if (criteria.getPdpName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp Name in Dedicated APN = " + criteria.getPdpName());
			String pdpName = criteria.getPdpName().toString();
			pdpName = pdpName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND lower(dap.pdp_name) like " + singQuote + pdpName.toLowerCase() + singQuote + " ");

		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name in Dedicated APN = "
							+ criteria.getCustomerOwnedDomainName());
			String domainName = criteria.getCustomerOwnedDomainName().toString();
			domainName = domainName.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + domainName);
			String singQuote = "'";

			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(
					" AND lower(dap.domain_name) like " + singQuote + domainName.toLowerCase() + singQuote + " ");
		}

		if (criteria.getPdpid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id in Dedicated APN = " + criteria.getPdpid());
			String pdpId = criteria.getPdpid().toString();
			pdpId = pdpId.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + pdpId);
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.bcid            = sa.bcid" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND dap.pdp_id like " + singQuote + pdpId + singQuote + " ");
			logger.info(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "queryBuilder: " + queryBuilder);
		}

		logger.info("Exiting method getExternalSearchForDedicatedAPN : ", this);
		return " UNION " + queryBuilder.toString();
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<AccountBO> getInternalAccounts(AccountSearchCriteriaBO criteria) throws CometDataException {
		logger.info("Starting method getInternalAccounts : ", this);
		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Started getting data for Internal Accounts");
		ArrayList<AccountBO> responseList = new ArrayList<AccountBO>();
		try {

			Map<String, Object> bindParamMap = new HashMap<String, Object>();
			String query = getInternalSearchQuery(criteria, bindParamMap);

			Query sqlQuery = em.createNativeQuery(query.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			ServiceUtils.setQueryParameters(sqlQuery, bindParamMap);


			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();

			// TODO - Convert below logic to Lambda
			Map<String, Object> resultMap = null;
			Object columnObject = null;
			Object columnObject1 = null;
			AccountBO response = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();
				while (itr.hasNext()) {
					response = new AccountBO();
					resultMap = itr.next();

					columnObject = resultMap.get(CIPN);
					if (null != columnObject) {
						response.setCipn(columnObject.toString());
					} else {
						response.setCipn(" ");
					}

					columnObject = resultMap.get(INTERNAL_PRODUCT_INITIATIVE_NAME);
					if (null != columnObject) {
						response.setInternalProductInitiativeName(columnObject.toString());
					} else {
						response.setInternalProductInitiativeName(" ");
					}

					columnObject = resultMap.get(ACCOUNT_TYPE);
					if (null != columnObject) {
						response.setAccountType(columnObject.toString());
					} else {
						response.setAccountType(" ");
					}

					columnObject = resultMap.get(ACCOUNT_CREATED_BY);
					if (null != columnObject) {
						response.setAccountCreatedBy(columnObject.toString());
					} else {
						response.setAccountCreatedBy(" ");
					}

					columnObject = resultMap.get(ACCOUNT_CREATED_ON);
					columnObject1 = resultMap.get(ACCOUNT_CREATED_ON1);
					if (null != columnObject) {
						response.setAccountCreatedOn(columnObject.toString());
					} else if (null != columnObject1) {
						response.setAccountCreatedOn(columnObject1.toString());
					} else {
						response.setAccountCreatedOn(" ");
					}

					response.setAccountClassId(null);
					columnObject = resultMap.get("ACCOUNT_CLASS_ID");
					logger.info("[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "columnObject" + columnObject.toString());
					if (null != columnObject) {
						response.setAccountClassId(((BigDecimal) columnObject).longValue());
					}

					responseList.add(response);
					response = null;
				}
			}

		} catch (Exception exception) {
			logger.error(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + exception.getStackTrace());
			exception.printStackTrace();
			logger.error(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Exception in getting internal accounts",
					exception);
			throw new CometDataException("DA001", exception);
		}

		logger.debug(
				"[AccountID : "
						+ (criteria == null ? ""
								: criteria.getBcid() == null ? ""
										: criteria.getCipn() == null ? "" : criteria.getCipn())
						+ "] " + "Finished getting data for Internal Accounts");
		logger.info("Exiting method getInternalAccounts : ", this);
		return responseList;
	}

	/**
	 * Create the search query for Internal/Product criteria
	 * 
	 * @param criteria
	 * @return
	 */
	private String getInternalSearchQuery(AccountSearchCriteriaBO criteria, Map<String, Object> bindParamMap) {
		logger.info("Starting method getInternalSearchQuery : ", this);
		StringBuilder queryBuilder = new StringBuilder();

		String queryConstant = GET_INTERNAL_ACCOUNT_SEARCH_QUERY;
		String queryClause = GET_INTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
		boolean orderApnTableAdded = false;
		boolean orderApnJoinAdded = false;
		boolean orderDomainNameAdded = false;
		boolean orderPdpIdAdded = false;
		boolean orderPdpIdAddedPdpName = false;

		if (criteria.getApnName() != null) {
			orderApnTableAdded = true;
			orderPdpIdAdded = true;
			queryConstant = queryConstant + APN_NAME_QUERY;
		}

		if (criteria.getPdpName() != null) {
			orderPdpIdAdded = false;
			if (!orderApnTableAdded) {
				orderDomainNameAdded = true;
				queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
			} else {
				queryConstant = queryConstant + PDP_ID_QUERY;
			}
		}

		if (criteria.getPdpid() != null) {
			if (!orderDomainNameAdded && !orderApnTableAdded) {
				if (criteria.getApnName() != null) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				} else {
					orderPdpIdAddedPdpName = true;
					queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
				}
			} else {
				if (orderPdpIdAdded) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				}
			}
		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			if (!orderApnTableAdded && !orderDomainNameAdded && !orderPdpIdAddedPdpName)
				queryConstant = queryConstant + APN_NAME_QUERY;
		}

		queryConstant = queryConstant + queryClause;
		queryBuilder.append(queryConstant);

		if (criteria.getAccountClass() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountClass = " + criteria.getAccountClass());
			queryBuilder.append("AND ipa.account_class_id = :" + ACCOUNT_CLASS_BC + " ");
			bindParamMap.put(ACCOUNT_CLASS_BC, criteria.getAccountClass());
		}

		String internalProductAccountName = criteria.getInternalProductAccountName();
		String singleQuote = "'";

		if (CommonUtils.isValidString(internalProductAccountName)) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Internal Product Account Name = " + criteria.getInternalProductAccountName());

			internalProductAccountName = internalProductAccountName.replace('*', '%');

			queryBuilder.append(" AND lower(ipa.internal_product_account_name) like " + singleQuote
					+ internalProductAccountName.toLowerCase() + singleQuote + " ");

		}

		if (CommonUtils.isValidString(criteria.getCipn())) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "CIPN = " + criteria.getCipn());
			queryBuilder.append("AND ipa.cipn = :" + CIPN_BC + " ");
			bindParamMap.put(CIPN_BC, criteria.getCipn().toUpperCase());
		}

		if (criteria.getFederalTaXId() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Federal Tax Id = " + criteria.getFederalTaXId());
			queryBuilder.append("AND ipa.federal_tax_id = :" + FEDERAL_TAX_ID_BC + " ");
			bindParamMap.put(FEDERAL_TAX_ID_BC, criteria.getFederalTaXId());
		}

		if (CommonUtils.isValidString(criteria.getAccountCreatedBy())) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created By = " + criteria.getAccountCreatedBy());
			queryBuilder.append("AND lower(ipa.created_by) = :" + ACCOUNT_CREATED_BY_BC + " ");
			bindParamMap.put(ACCOUNT_CREATED_BY_BC, criteria.getAccountCreatedBy().toLowerCase());
		}

		if (criteria.getCreationDateFrom() != null && criteria.getCreationDateTo() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created From = " + criteria.getCreationDateFrom());
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "AccountBO Created To = " + criteria.getCreationDateTo());
			queryBuilder.append("AND ipa.created_on > TO_DATE (:" + CREATION_DATE_FROM_BC
					+ ", 'MM/DD/YYYY')  and sa.created_on  < TO_DATE(:" + CREATION_DATE_TO_BC + ",'MM/DD/YYYY')");
			bindParamMap.put(CREATION_DATE_FROM_BC, criteria.getCreationDateFrom());
			bindParamMap.put(CREATION_DATE_TO_BC, criteria.getCreationDateTo());
		}

		if (criteria.getApnName() != null) {
			orderApnJoinAdded = true;
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Apn Name Type = " + criteria.getApnName());
			String apnName = criteria.getApnName().toString();
			apnName = apnName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND lower(ap.apn_name) like " + singQuote + apnName.toLowerCase() + singQuote + " ");
			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
		}

		if (criteria.getPdpName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "PDP Name = " + criteria.getPdpName());
			String pdpName = criteria.getPdpName().toString();
			pdpName = pdpName.replace('*', '%');
			String singQuote = "'";

			if (!orderApnJoinAdded) {
				queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
				queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
				queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
				queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			}
			queryBuilder.append(" AND ( lower(pdpinfo.auto_pdp_name) like " + singQuote + pdpName.toLowerCase()
					+ singQuote + " or lower(pdpinfo.user_pdp_name) like " + singQuote + pdpName.toLowerCase()
					+ singQuote + ")");
		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + criteria.getCustomerOwnedDomainName());
			String domainName = criteria.getCustomerOwnedDomainName().toString();
			domainName = domainName.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + domainName);
			String singQuote = "'";

			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(
					" AND lower(ap.domain_name) like " + singQuote + domainName.toLowerCase() + singQuote + " ");
		}

		if (criteria.getPdpid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + criteria.getPdpid());
			String pdpId = criteria.getPdpid().toString();
			pdpId = pdpId.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + pdpId);
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND ( pdpinfo.auto_pdp_id like " + singQuote + pdpId + singQuote
					+ " or pdpinfo.user_pdp_id like " + singQuote + pdpId + singQuote + ")");
			logger.info(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "queryBuilder: " + queryBuilder);
		}

		String internalSearchForDedicatedAPN = "";
		internalSearchForDedicatedAPN = getInternalSearchForDedicatedAPN(criteria);
		queryBuilder.append(internalSearchForDedicatedAPN);

		logger.info("Exiting method getInternalSearchQuery : ", this);
		return queryBuilder.toString();
	}

	/**
	 * Create the search query for Internal/Product criteria For Dedicated APN
	 * 
	 * @param criteria
	 * @return
	 */
	private String getInternalSearchForDedicatedAPN(AccountSearchCriteriaBO criteria) {
		logger.info("Starting method getInternalSearchForDedicatedAPN : ", this);
		if (criteria.getApnName() == null && criteria.getPdpName() == null
				&& criteria.getCustomerOwnedDomainName() == null && criteria.getPdpid() == null) {
			return "";
		}

		StringBuilder queryBuilder = new StringBuilder();

		String queryConstant = GET_INTERNAL_ACCOUNT_SEARCH_QUERY_DEDICATED;
		String queryClause = GET_INTERNAL_ACCOUNT_SEARCH_WHERE_QUERY;
		boolean orderApnTableAdded = false;
		boolean orderApnJoinAdded = false;
		boolean orderDomainNameAdded = false;
		boolean orderPdpIdAdded = false;
		boolean orderPdpIdAddedPdpName = false;

		if (criteria.getApnName() != null) {
			orderApnTableAdded = true;
			orderPdpIdAdded = true;
			queryConstant = queryConstant + APN_NAME_QUERY;
		}

		if (criteria.getPdpName() != null) {
			orderPdpIdAdded = false;
			if (!orderApnTableAdded) {
				orderDomainNameAdded = true;
				queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
			} else {
				queryConstant = queryConstant + PDP_ID_QUERY;
			}
		}

		if (criteria.getPdpid() != null) {
			if (!orderDomainNameAdded && !orderApnTableAdded) {
				if (criteria.getApnName() != null) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				} else {
					orderPdpIdAddedPdpName = true;
					queryConstant = queryConstant + PDP_ID_QUERY + APN_NAME_QUERY;
				}
			} else {
				if (orderPdpIdAdded) {
					queryConstant = queryConstant + PDP_ID_QUERY;
				}
			}
		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			if (!orderApnTableAdded && !orderDomainNameAdded && !orderPdpIdAddedPdpName)
				queryConstant = queryConstant + APN_NAME_QUERY;
		}

		queryConstant = queryConstant + queryClause;
		queryBuilder.append(queryConstant);

		if (criteria.getApnName() != null) {
			orderApnJoinAdded = true;
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Apn Name Type for Dedicated APN = " + criteria.getApnName());
			String apnName = criteria.getApnName().toString();
			apnName = apnName.replace('*', '%');
			String singQuote = "'";

			queryBuilder.append(" AND lower(dap.apn_name) like " + singQuote + apnName.toLowerCase() + singQuote + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");

		}

		if (criteria.getPdpName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "PDP Name for Dedicated APN = " + criteria.getPdpName());
			String pdpName = criteria.getPdpName().toString();
			pdpName = pdpName.replace('*', '%');
			String singQuote = "'";

			if (!orderApnJoinAdded) {
				queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
				queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
				queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
				queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
				queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			}
			queryBuilder.append(" AND lower(dap.pdp_name) like " + singQuote + pdpName.toLowerCase() + singQuote + " ");

		}

		if (criteria.getCustomerOwnedDomainName() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name for Dedicated APN = "
							+ criteria.getCustomerOwnedDomainName());
			String domainName = criteria.getCustomerOwnedDomainName().toString();
			domainName = domainName.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Customer Owned Domain Name = " + domainName);
			String singQuote = "'";

			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(
					" AND lower(dap.domain_name) like " + singQuote + domainName.toLowerCase() + singQuote + " ");

		}

		if (criteria.getPdpid() != null) {
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id for Dedicated APN = " + criteria.getPdpid());
			String pdpId = criteria.getPdpid().toString();
			pdpId = pdpId.replace('*', '%');
			logger.debug(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "Pdp id = " + pdpId);
			String singQuote = "'";

			queryBuilder.append(" AND pdpinfo.order_id        = ap.order_id " + " ");
			queryBuilder.append(" AND ord.order_id = dap.order_id " + " ");
			queryBuilder.append(" AND ord.apn_selection = 'Dedicated' " + " ");
			queryBuilder.append(" AND ord.cipn            = ipa.cipn" + " ");
			queryBuilder.append(" AND ord.order_type_id = 1001" + " ");
			queryBuilder.append(" AND dap.pdp_id like " + singQuote + pdpId + singQuote + " ");
			logger.info(
					"[AccountID : "
							+ (criteria == null ? ""
									: criteria.getBcid() == null ? ""
											: criteria.getCipn() == null ? "" : criteria.getCipn())
							+ "] " + "queryBuilder: " + queryBuilder);

		}

		logger.info("Exiting method getInternalSearchForDedicatedAPN : ", this);
		return " UNION " + queryBuilder.toString();
	}

	public List<String> findMasterAccountNameList(String criteria) {
		return masterAccountRepository.getMasterAccountList(criteria);
	}

	public List<String> findSubAccountNameList(String criteria) {
		return subAccountRepository.getSubAccountList(criteria);
	}

	public List<String> findInternalInitiativeAccountNameList(String criteria) {
		return internalInitiativeAccountRepository.getInternalInitiativeAccountList(criteria);
	}

	public List<String> findProductInitiativeAccountNameList(String criteria) {
		return productInitiativeAccountRepository.getProductInitiativeAccountList(criteria);
	}

	public List<String> findApnNameList(String criteria) {
		return apnNameRepository.getApnNameList(criteria);
	}

	@Override
	public AccountInfoBO getAccountInfo(String accountClassId, String accountId)
			throws CometServiceException, CometDataException {
		logger.info("[AccountID :" + accountId + "]Method getAccountInfo: Start");
		SubAccountBO subAccountBO = null;
		InternalProductAccountBO internalProductAccountBO = null;
		MasterAccountBO masterAccountBO = null;
		try {
			if (accountClassId.equalsIgnoreCase(AccountConstant.CLASS1)) {
				subAccountBO = getSubAccount(accountId);
				if (subAccountBO != null) {
					masterAccountBO = getMasterAccount(subAccountBO.getUbcid());
					return getClass1AccountInfo(subAccountBO, masterAccountBO);
				}
			} else if (accountClassId.equalsIgnoreCase(AccountConstant.CLASS2)) {
				internalProductAccountBO = getInternalAndProductAccount(accountId);
				if (internalProductAccountBO != null) {
					return getClass2AndClass3AccountInfo(internalProductAccountBO, AccountConstant.CLASS2);
				}

			} else if (accountClassId.equalsIgnoreCase(AccountConstant.CLASS3)) {
				internalProductAccountBO = getInternalAndProductAccount(accountId);
				if (internalProductAccountBO != null) {
					return getClass2AndClass3AccountInfo(internalProductAccountBO, AccountConstant.CLASS3);
				}
			}
		} catch (CometDataException e) {
			logger.error("[AccountID : " + (accountId == null ? "" : accountId) + "] " + e.getStackTrace());
			throw new CometDataException(e.getErrorCode(), e.getMessage());
		}
		logger.info("[AccountID :" + accountId + "] " + "Method getAccountInfo: End");
		return null;
	}

	public SubAccountBO getSubAccount(String bcid) throws CometDataException {
		logger.info("[AccountID :" + bcid + "] " + "Method getSubAccount: Start");
		SubAccountBO subAccountBO = null;
		try {
			if (!StringUtils.isEmpty(bcid)) {
				Optional<SubAccount> subAccountOptional = subAccountRepository.findById(bcid.trim());
				if (subAccountOptional.isPresent()) {
					subAccountBO = AccountHelper.populateSubAccountBO(subAccountOptional.get());
				} else {
					logger.info("Account :" + bcid + " " + "does not exist.");
					throw new RecordNotFoundException("Account :" + bcid + " " + "does not exist.");
				}
			}
		} catch (SQLException exception) {
			logger.error("[AccountID : "
					+ (subAccountBO == null ? ""
							: subAccountBO.getUbcid() == null ? ""
									: subAccountBO.getBcid() == null ? "" : subAccountBO.getBcid())
					+ "] " + exception.getStackTrace());
			throw new CometDataException("Error", exception);
		}
		logger.info("[AccountID :" + bcid + "] " + "Method getSubAccount: End");
		return subAccountBO;
	}
	
	private SubAccountBO getBcidExistorNot(String bcid) throws CometDataException {
		logger.info("[AccountID :" + bcid + "] " + "Method getSubAccount: Start");
		SubAccountBO subAccountBO = null;
		try {
			if (!StringUtils.isEmpty(bcid)) {
				Optional<SubAccount> subAccountOptional = subAccountRepository.findById(bcid.trim());
				if (subAccountOptional.isPresent()) {
					subAccountBO = AccountHelper.populateSubAccountBO(subAccountOptional.get());
				}
			}
		} catch (SQLException exception) {
			logger.error("[AccountID : "
					+ (subAccountBO == null ? ""
							: subAccountBO.getUbcid() == null ? ""
									: subAccountBO.getBcid() == null ? "" : subAccountBO.getBcid())
					+ "] " + exception.getStackTrace());
		}
		logger.info("[AccountID :" + bcid + "] " + "Method getSubAccount: End");
		return subAccountBO;
	}

	public MasterAccountBO getMasterAccount(String ubcid) throws CometDataException {
		logger.info("[AccountID :" + ubcid + "] " + "Method getMasterAccount: Start");
		MasterAccountBO masterAccountBO = null;
		try {
			if (!StringUtils.isEmpty(ubcid)) {
				Optional<MasterAccount> mstrAccountOptional = masterAccountRepository.findById(ubcid.trim());
				if (mstrAccountOptional.isPresent()) {
					MasterAccount pMasterAccount = mstrAccountOptional.get();
					masterAccountBO = new MasterAccountBO();
					masterAccountBO.setUbcid(pMasterAccount.getUbcid());
					masterAccountBO.setMasterAccountName(pMasterAccount.getMasterAccountName());
				}
			}
		} catch (Exception exception) {
			logger.error("[AccountUbcID : "
					+ (masterAccountBO == null ? ""
							: masterAccountBO.getUbcid() == null ? "" : masterAccountBO.getUbcid())
					+ "] " + exception.getStackTrace());
			// new CometDataException("Error", exception);
		}
		logger.info("[AccountID :" + ubcid + "] " + "Method getMasterAccount: End");
		return masterAccountBO;
	}

	private AccountInfoBO getClass1AccountInfo(SubAccountBO subAccountBO, MasterAccountBO masterAccountBO) {
		if(null!=masterAccountBO) {
			logger.info("[AccountID :" + masterAccountBO.getUbcid() + "] " + "Method getClass1AccountInfo: Start");
		}else {
			logger.info("[AccountID :" + subAccountBO.getUbcid() + "] " + "Method getClass1AccountInfo: Start");
		}
		
		AccountInfoBO accountInfoBO = new AccountInfoBO();

		accountInfoBO.setAccountClass(AccountConstant.CLASS1);
		if (subAccountBO.getBcid() != null) {
			accountInfoBO.setBcid(subAccountBO.getBcid().toString());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getSubAccountName())) {
			accountInfoBO.setSubAccountName(subAccountBO.getSubAccountName());
		}

		if (subAccountBO.getFederalTaxId() != null) {
			accountInfoBO.setFedralTaxId(subAccountBO.getFederalTaxId().toString());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getWaiverNotes())) {
			accountInfoBO.setWaiverNotes(subAccountBO.getWaiverNotes());
		}

		if (subAccountBO.getWaiverAttachment() != null) {
			accountInfoBO.setWaiverAttachment(subAccountBO.getWaiverAttachment());
		}

		if (subAccountBO.getWaiverAttachmentFilename() != null) {
			accountInfoBO.setWaiverFileName(subAccountBO.getWaiverAttachmentFilename());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getCompanyName())) {
			accountInfoBO.setCompanyName(subAccountBO.getCompanyName());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getCompanyName())) {
			accountInfoBO.setCompanyName(subAccountBO.getCompanyName());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getCompanyOwner())) {
			accountInfoBO.setCompanyOwner(subAccountBO.getCompanyOwner());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getBusinessDescription())) {
			accountInfoBO.setBusinessDesc(subAccountBO.getBusinessDescription());
		}

		if (subAccountBO.getCompanyCountryCode() != null) {
			accountInfoBO.setCompanyCountry(subAccountBO.getCompanyCountryCode().toString());
		}

		if (subAccountBO.getCompanyState() != null) {
			accountInfoBO.setCompanyState(subAccountBO.getCompanyState().toString());
		}

		if (subAccountBO.getCompanyState() != null) {
			accountInfoBO.setCompanyState(subAccountBO.getCompanyState().toString());
		}

		if (subAccountBO.getCompanyCity() != null) {
			accountInfoBO.setCompanyCityHid(subAccountBO.getCompanyCity().toString());
		}

		if (subAccountBO.getCompanyZip() != null) {
			accountInfoBO.setCompanyZip(subAccountBO.getCompanyZip().toString());
		}

		if (subAccountBO.getCompanyStreetAddress() != null) {
			accountInfoBO.setCompanyStreetAddress(subAccountBO.getCompanyStreetAddress().toString());
		}

		if (subAccountBO.getBillingCountryCode() != null) {
			accountInfoBO.setBillingCountry(subAccountBO.getBillingCountryCode().toString());
		}

		if (subAccountBO.getBillingStreetAddress() != null) {
			accountInfoBO.setBillingStreetAddress(subAccountBO.getBillingStreetAddress().toString());
		}

		if (subAccountBO.getBillingState() != null) {
			accountInfoBO.setBillingState(subAccountBO.getBillingState().toString());
		}

		if (subAccountBO.getBillingCity() != null) {
			accountInfoBO.setBillingCityHid(subAccountBO.getBillingCity().toString());
		}

		if (subAccountBO.getBillingZip() != null) {
			accountInfoBO.setBillingZip(subAccountBO.getBillingZip().toString());
		}

		if (subAccountBO.getHqCountryCode() != null) {
			accountInfoBO.setHeadquarterCountry(subAccountBO.getHqCountryCode().toString());
		}

		if (subAccountBO.getHqStreetAddress() != null) {
			accountInfoBO.setHeadquarterStreetAddress(subAccountBO.getHqStreetAddress().toString());
		}

		if (subAccountBO.getHqState() != null) {
			accountInfoBO.setHeadquarterState(subAccountBO.getHqState().toString());
		}

		if (subAccountBO.getHqCity() != null) {
			accountInfoBO.setHeadquarterCityHid(subAccountBO.getHqCity().toString());
		}

		if (subAccountBO.getHqZip() != null) {
			accountInfoBO.setHeadquarterZip(subAccountBO.getHqZip().toString());
		}

		if (CommonUtils.isNotNullEmpty(subAccountBO.getCompanyMainContact())) {
			accountInfoBO.setCciContact(subAccountBO.getCompanyMainContact());
		}

		if (subAccountBO.getCompanyContactCountry() != null) {
			accountInfoBO.setCciCountry(subAccountBO.getCompanyContactCountry().toString());
		}

		if (subAccountBO.getCompanyContactState() != null) {
			accountInfoBO.setCciState(subAccountBO.getCompanyContactState().toString());
		}

		if (subAccountBO.getCompanyContactCity() != null) {
			accountInfoBO.setCciCity(subAccountBO.getCompanyContactCity().toString());
		}

		if (subAccountBO.getCompanyContactCity() != null) {
			accountInfoBO.setCciCityHid(subAccountBO.getCompanyContactCity().toString());
		}

		if (subAccountBO.getCompanyContactZip() != null) {
			accountInfoBO.setCciZip(subAccountBO.getCompanyContactZip().toString());
		}

		if (subAccountBO.getCompanyContactStreetAddress() != null) {
			accountInfoBO.setCciStreetAddress(subAccountBO.getCompanyContactStreetAddress().toString());
		}

		if (subAccountBO.getCompanyContactDeskPhone() != null) {
			accountInfoBO.setCciDeskPhone(subAccountBO.getCompanyContactDeskPhone().toString());
		}

		if (subAccountBO.getCompanyContactDeskPhoneExtension() != null) {
			accountInfoBO.setCciDeskPhoneExtension(subAccountBO.getCompanyContactDeskPhoneExtension());
		}

		if (subAccountBO.getCompanyContactCellPhone() != null) {
			accountInfoBO.setCciCellPhone(subAccountBO.getCompanyContactCellPhone().toString());
		}

		if (subAccountBO.getCompanyContactEmail() != null) {
			accountInfoBO.setCciEmailAddress(subAccountBO.getCompanyContactEmail().toString());
		}

		if (subAccountBO.getUbcid() != null) {
			accountInfoBO.setUbcid(subAccountBO.getUbcid().toString());
		}

		if (subAccountBO.getAccountType() != null) {
			accountInfoBO.setAccountType(subAccountBO.getAccountType().toString());
		}
		
		if (null!=masterAccountBO && CommonUtils.isNotNullEmpty(masterAccountBO.getMasterAccountName())) {
			accountInfoBO.setMasterAccountName(masterAccountBO.getMasterAccountName());
		}

		if (subAccountBO.getTsp() != null) {
			accountInfoBO.setIsTsp(subAccountBO.getTsp().toString());
		}

		if (subAccountBO.getFeeWaiverApproved() != null) {
			accountInfoBO.setIsFeeWaiver(subAccountBO.getFeeWaiverApproved().toString());
		}

		if (subAccountBO.getDerivedClFromHq().equals('Y')) {
			accountInfoBO.setCheck1("on");
		}

		if (subAccountBO.getDerivedBlFromHq().equals('Y')) {
			accountInfoBO.setCheck2("on");
		}

		if (subAccountBO.getDerivedBlFromCl().equals('Y')) {
			accountInfoBO.setCheck3("on");
		}

		if (subAccountBO.getDerivedCciFromHq().equals('Y')) {
			accountInfoBO.setCheck4("on");
		}

		if (subAccountBO.getCreatedBy() != null) {
			accountInfoBO.setCreatedBy(subAccountBO.getCreatedBy());
		}

		if (subAccountBO.getCreatedOn() != null) {
			accountInfoBO
					.setCreatedOn(CommonUtils.dateToString(subAccountBO.getCreatedOn(), AccountConstant.DATE_FORMAT));
		}

		if (subAccountBO.getUpdatedBy() != null) {
			accountInfoBO.setUpdatedBy(subAccountBO.getUpdatedBy());
		}

		if (subAccountBO.getUpdatedOn() != null) {
			accountInfoBO
					.setUpdatedOn(CommonUtils.dateToString(subAccountBO.getUpdatedOn(), AccountConstant.DATE_FORMAT));
		}
		if(null!=masterAccountBO) {
			logger.info("[AccountID :" + masterAccountBO.getUbcid() + "] " + "Method getClass1AccountInfo: End");
		}
		
		return accountInfoBO;
	}

	public InternalProductAccountBO getInternalAndProductAccount(String cipn) throws CometDataException {
		logger.info("[AccountID :" + cipn + "] " + "Method getInternalAccount: Start");
		InternalProductAccountBO internalAccountBO = null;
		if (!StringUtils.isEmpty(cipn)) {
			Optional<InternalProductAccount> pAccountOptional = internalProductAccountRepository.findById(cipn);
			if (pAccountOptional.isPresent()) {
				InternalProductAccount pAccount = pAccountOptional.get();
				internalAccountBO = new InternalProductAccountBO();
				internalAccountBO.setCipnName(pAccount.getCipn());
				internalAccountBO.setAccountClass(pAccount.getAccountClass().getAccountClassId());
				internalAccountBO.setInternalInitiativeName(pAccount.getInternalProductAccountName());
				internalAccountBO.setCreatedBy(pAccount.getCreatedBy());
				internalAccountBO.setCreatedOn(pAccount.getCreatedOn());
				internalAccountBO.setFederalTaxId(pAccount.getFederalTaxId());
				internalAccountBO.setFeeWaiverApproved(pAccount.getFeeWaiverApproved());
				internalAccountBO.setTsp(pAccount.getTsp());
				internalAccountBO.setUpdatedBy(pAccount.getUpdatedBy());
				internalAccountBO.setUpdatedOn(pAccount.getUpdatedOn());
				if (pAccount.getWaiverAttachment() != null) {
					//Blob attachment = pAccount.getWaiverAttachment();
					//internalAccountBO.setWaiverAttachment(attachment.getBytes(1, (int) attachment.length()));
					internalAccountBO.setWaiverAttachment(pAccount.getWaiverAttachment());
				}
				internalAccountBO.setWaiverAttachmentFilename(pAccount.getWaiverAttachmentFilename());
				internalAccountBO.setWaiverNotes(pAccount.getWaiverNotes());
			} else {
				logger.info("Account :" + cipn + " " + "does not exist.");
				throw new RecordNotFoundException("Account :" + cipn + " " + "does not exist.");
			}
		}
		logger.info("[AccountID :" + cipn + "] " + "Method getInternalAccount: End");
		return internalAccountBO;
	}

	private AccountInfoBO getClass2AndClass3AccountInfo(InternalProductAccountBO internalAccountBO, String Class) {
		logger.info("[AccountID :" + internalAccountBO.getCipnName() + "] " + "Method getClass2AccountInfo: Start");
		AccountInfoBO accountInfoBO = new AccountInfoBO();
		accountInfoBO.setAccountClass(Class);

		if (CommonUtils.isNotNullEmpty(internalAccountBO.getCipnName())) {
			accountInfoBO.setCipn(internalAccountBO.getCipnName());
		}

		if (CommonUtils.isNotNullEmpty(internalAccountBO.getInternalInitiativeName())) {
			if(accountInfoBO.getAccountClass() == "1002") {
				accountInfoBO.setInternalInitiativeAcName(internalAccountBO.getInternalInitiativeName());
			} else {
				accountInfoBO.setProductInitiativeAcName(internalAccountBO.getInternalInitiativeName());
			}
		}

		if (internalAccountBO.getFederalTaxId() != null) {
			accountInfoBO.setFedralTaxId(internalAccountBO.getFederalTaxId().toString());
		}

		if (internalAccountBO.getTsp() != null) {
			accountInfoBO.setIsTsp(internalAccountBO.getTsp().toString());
		}

		if (internalAccountBO.getFeeWaiverApproved() != null) {
			accountInfoBO.setIsFeeWaiver(internalAccountBO.getFeeWaiverApproved().toString());
		}

		if (CommonUtils.isNotNullEmpty(internalAccountBO.getWaiverNotes())) {
			accountInfoBO.setWaiverNotes(internalAccountBO.getWaiverNotes());
		}

		if (internalAccountBO.getWaiverAttachment() != null) {
			accountInfoBO.setWaiverAttachment(internalAccountBO.getWaiverAttachment());
		}

		if (internalAccountBO.getWaiverAttachmentFilename() != null) {
			accountInfoBO.setWaiverFileName(internalAccountBO.getWaiverAttachmentFilename());
		}

		if (CommonUtils.isNotNullEmpty(internalAccountBO.getWaiverNotes())) {
			accountInfoBO.setWaiverNotes(internalAccountBO.getWaiverNotes());
		}

		if (internalAccountBO.getCreatedBy() != null) {
			accountInfoBO.setCreatedBy(internalAccountBO.getCreatedBy());
		}

		if (internalAccountBO.getCreatedOn() != null) {
			accountInfoBO.setCreatedOn(
					CommonUtils.dateToString(internalAccountBO.getCreatedOn(), AccountConstant.DATE_FORMAT));
		}

		if (internalAccountBO.getUpdatedBy() != null) {
			accountInfoBO.setUpdatedBy(internalAccountBO.getUpdatedBy());
		}

		if (internalAccountBO.getUpdatedOn() != null) {
			accountInfoBO.setUpdatedOn(
					CommonUtils.dateToString(internalAccountBO.getUpdatedOn(), AccountConstant.DATE_FORMAT));
		}
		logger.info("[AccountID :" + internalAccountBO.getCipnName() + "] " + "Method getClass2AccountInfo: End");
		return accountInfoBO;
	}

	@Override
	public AccountInfoBO updateAccountInfo(AccountInfoBO accountInfoBO) throws CometDataException, IOException {
		logger.info("Method updateAccountInfo: Start");

		String accountCategory = accountInfoBO.getMasterAccountCatagoryList();
		String accountClass = accountInfoBO.getAccountClass();

		if (accountClass.equalsIgnoreCase(AccountConstant.CLASS1)) {
			logger.debug("Scenario: accountClass is Class1");

			if (accountCategory.equalsIgnoreCase(AccountConstant.ACCOUNT_CAT_NEW)) {
				logger.debug("Scenario: accountCategory is MasterAccount");

				updateMasterAccount(transformToMasterAccount(accountInfoBO));
				updateSubAccount(transformToSubAccount(accountInfoBO));

			} else if (accountCategory.equalsIgnoreCase(AccountConstant.ACCOUNT_CAT_SUB)) {
				logger.debug("Scenario: accountCategory is MasterAccount");

				updateSubAccount(transformToSubAccount(accountInfoBO));

			} else if (accountCategory.equalsIgnoreCase(AccountConstant.UPDATE_MASTER)) {
				logger.debug("Scenario: accountCategory is MasterAccount");
				updateSubAccount(transformToSubAccount(accountInfoBO));
				updateMasterAccount(transformToMasterAccount(accountInfoBO));

			} else {
				logger.error("Scenario : Unexpected accountCategory.");
			}

		} else if (accountClass.equals(AccountConstant.CLASS2)) {
			logger.debug("Scenario: accountClass is Class2");

			updateInternalAccount(transformToInternalAccount(accountInfoBO));

		} else if (accountClass.equals(AccountConstant.CLASS3)) {
			logger.debug("Scenario: accountClass is Class3");

			updateProductAccount(transformToProductAccount(accountInfoBO));

		} else {
			logger.error("Scenario : Unexpected accountClass.");
		}

		logger.info("Method updateAccountInfo: End");
		return accountInfoBO;
	}

	public MasterAccountBO updateMasterAccount(MasterAccountBO masterAccountBO) throws CometDataException {
		logger.info("[AccountID :" + masterAccountBO.getUbcid() + "] " + "Method updateMasterAccount: Start");
		try {
			if (!StringUtils.isEmpty(masterAccountBO.getUbcid())) {
				Optional<MasterAccount> mstrAccountOptional = masterAccountRepository
						.findById(masterAccountBO.getUbcid().trim());
				if (mstrAccountOptional.isPresent()) {
					MasterAccount pAccount = mstrAccountOptional.get();
					pAccount.setUbcid(masterAccountBO.getUbcid());
					pAccount.setMasterAccountName(masterAccountBO.getMasterAccountName());
					masterAccountRepository.save(pAccount);
				} else {
					MasterAccount pAccount = new MasterAccount();
					AccountClass pAccountClass = new AccountClass();
					pAccount.setUbcid(masterAccountBO.getUbcid());
					pAccount.setMasterAccountName(masterAccountBO.getMasterAccountName());
					if (masterAccountBO.getAccountClass() != null) {
						pAccountClass.setAccountClassId(masterAccountBO.getAccountClass());
					}
					pAccount.setAccountClass(pAccountClass);
					masterAccountRepository.save(pAccount);
				}
			}
		} catch (Exception exception) {
			logger.error("[AccountUbcID : "
					+ (masterAccountBO == null ? ""
							: masterAccountBO.getUbcid() == null ? "" : masterAccountBO.getUbcid())
					+ "] " + exception.getStackTrace());
			throw new CometDataException("Error", exception);
		}
		logger.info("[AccountID :" + masterAccountBO.getUbcid() + "] " + "Method updateMasterAccount: End");
		return masterAccountBO;
	}

	public SubAccountBO updateSubAccount(SubAccountBO subAccountBO) throws CometDataException {
		logger.info("[AccountID :" + subAccountBO.getUbcid() + "] " + "Method updateSubAccount: Start");
		byte[] waiverAttachment = null;
		try {
			if (!StringUtils.isEmpty(subAccountBO.getBcid())) {
				Optional<SubAccount> subAccountOptional = subAccountRepository.findById(subAccountBO.getBcid().trim());
				if (subAccountOptional.isPresent()) {
					SubAccount pSubAccount = subAccountOptional.get();
					waiverAttachment = pSubAccount.getWaiverAttachment();
					subAccountBO.setUpdatedOn(new Date());
					subAccountBO.setCreatedBy(pSubAccount.getCreatedBy());
					subAccountBO.setCreatedOn(pSubAccount.getCreatedOn());

					pSubAccount = accountHelper.populateSubAccount(subAccountBO, pSubAccount);

					// Case-1: If attachment is removed from UI, then remove blob.
					if (subAccountBO.getWaiverAttachmentFilename() == null) {
						pSubAccount.setWaiverAttachmentFilename(null);
						pSubAccount.setWaiverAttachment(null);
					}
					// Case-2: If attachment is not removed, then set the file name
					// from UI.
					else {
						pSubAccount.setWaiverAttachmentFilename(subAccountBO.getWaiverAttachmentFilename());
						// Case 2-A: If attachment is not sent from UI, update the
						// previous
						// one.
						if (subAccountBO.getWaiverAttachment() == null) {
							pSubAccount.setWaiverAttachment(waiverAttachment);
						}

						// Case 2-B: If attachment is sent form UI then use new one.
						else {
							//pSubAccount.setWaiverAttachment(
							//		Hibernate.getLobCreator(null).createBlob(subAccountBO.getWaiverAttachment()));
							pSubAccount.setWaiverAttachment(subAccountBO.getWaiverAttachment());
						}
					}
					subAccountRepository.save(pSubAccount);
				}
			}
		} catch (Exception exception) {
			logger.error("[AccountUbcID : "
					+ (subAccountBO == null ? "" : subAccountBO.getBcid() == null ? "" : subAccountBO.getBcid()) + "] "
					+ exception.getStackTrace());
			throw new CometDataException("Error", exception);
		}
		logger.info("[AccountID :" + subAccountBO.getUbcid() + "] " + "Method updateSubAccount: End");
		return subAccountBO;
	}

	public InternalAccountBO updateInternalAccount(InternalAccountBO internalAccountBO) throws CometDataException {
		logger.info("[AccountID : "
				+ (internalAccountBO == null ? ""
						: internalAccountBO.getCipnName() == null ? "" : internalAccountBO.getCipnName())
				+ "] " + "Updating updateInternalAccount started");
		try {
			if (!StringUtils.isEmpty(internalAccountBO.getCipnName())) {
				Optional<InternalProductAccount> intProdAccountOptional = internalProductAccountRepository
						.findById(internalAccountBO.getCipnName());
				if (intProdAccountOptional.isPresent()) {
					InternalProductAccount exAccount = intProdAccountOptional.get();
					exAccount.setInternalProductAccountName(internalAccountBO.getInternalInitiativeName().trim());
					
					exAccount.setFederalTaxId(internalAccountBO.getFederalTaxId());
					exAccount.setTsp(internalAccountBO.getTsp());
					exAccount.setFeeWaiverApproved(internalAccountBO.getFeeWaiverApproved());
					exAccount.setWaiverNotes(internalAccountBO.getWaiverNotes());
					if (exAccount.getWaiverAttachment() != null) {
						//exAccount.setWaiverAttachment(Hibernate.getLobCreator(null).createBlob(internalAccountBO.getWaiverAttachment()));
						exAccount.setWaiverAttachment(internalAccountBO.getWaiverAttachment());
					}
					exAccount.setWaiverAttachmentFilename(internalAccountBO.getWaiverAttachmentFilename());
					exAccount.setCreatedBy(internalAccountBO.getCreatedBy());
					exAccount.setCreatedOn(internalAccountBO.getCreatedOn());
					exAccount.setUpdatedBy(internalAccountBO.getUpdatedBy());
					exAccount.setUpdatedOn(internalAccountBO.getUpdatedOn());
					exAccount.setActive('Y');
					internalProductAccountRepository.save(exAccount);
				}
			}
		} catch (Exception exception) {
			logger.error("[AccountID : "
					+ (internalAccountBO == null ? ""
							: internalAccountBO.getCipnName() == null ? "" : internalAccountBO.getCipnName())
					+ "] " + exception.getStackTrace());
			exception.printStackTrace();
		}
		logger.info("[AccountID : "
				+ (internalAccountBO == null ? ""
						: internalAccountBO.getCipnName() == null ? "" : internalAccountBO.getCipnName())
				+ "] " + "Updating internal account finished");
		return internalAccountBO;
	}

	public ProductAccountBO updateProductAccount(ProductAccountBO productAccountBO) throws CometDataException {
		logger.info("[AccountID : "
				+ (productAccountBO == null ? ""
						: productAccountBO.getCipnName() == null ? "" : productAccountBO.getCipnName())
				+ "] " + "Updating product account started ");
		try {
			if (productAccountBO.getCipnName() == null) {
				throw new CometDataException("Cipn Name is null");
			}
			if (!StringUtils.isEmpty(productAccountBO.getCipnName())) {
				Optional<InternalProductAccount> intProdAccountOptional = internalProductAccountRepository
						.findById(productAccountBO.getCipnName());
				if (intProdAccountOptional.isPresent()) {
					InternalProductAccount exAccount = intProdAccountOptional.get();
					exAccount.setInternalProductAccountName(productAccountBO.getProductInitiativeName().trim());
					
					exAccount.setFederalTaxId(productAccountBO.getFederalTaxId());
					exAccount.setTsp(productAccountBO.getTsp());
					exAccount.setFeeWaiverApproved(productAccountBO.getFeeWaiverApproved());
					exAccount.setWaiverNotes(productAccountBO.getWaiverNotes());
					if (exAccount.getWaiverAttachment() != null) {
						//exAccount.setWaiverAttachment(Hibernate.getLobCreator(null).createBlob(productAccountBO.getWaiverAttachment()));
						exAccount.setWaiverAttachment(productAccountBO.getWaiverAttachment());
					}
					exAccount.setWaiverAttachmentFilename(productAccountBO.getWaiverAttachmentFilename());
					exAccount.setCreatedBy(productAccountBO.getCreatedBy());
					exAccount.setCreatedOn(productAccountBO.getCreatedOn());
					exAccount.setUpdatedBy(productAccountBO.getUpdatedBy());
					exAccount.setUpdatedOn(productAccountBO.getUpdatedOn());
					exAccount.setActive('Y');
					internalProductAccountRepository.save(exAccount);
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			logger.error("[AccountID : "
					+ (productAccountBO == null ? ""
							: productAccountBO.getCipnName() == null ? "" : productAccountBO.getCipnName())
					+ "] " + "Updating product account failed", exception);
			throw new CometDataException("DA001", exception);
		}
		logger.info("[AccountID : "
				+ (productAccountBO == null ? ""
						: productAccountBO.getCipnName() == null ? "" : productAccountBO.getCipnName())
				+ "] " + "Updating product account finished");
		return productAccountBO;
	}

	/**
	 * Transforms the account into Master Account.
	 * 
	 * @param form
	 * @return MasterAccountBO
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private MasterAccountBO transformToMasterAccount(AccountInfoBO accountInfoBO) {

		logger.debug("In transformToMasterAccount() method : Starting");

		MasterAccountBO masterAccountBO = new MasterAccountBO();
		masterAccountBO.setAccountClass(Long.parseLong(accountInfoBO.getAccountClass()));
		if (accountInfoBO.getMasterAccountNameNew() != null
				&& CommonUtils.isNotNullEmpty(accountInfoBO.getMasterAccountNameNew()))
			masterAccountBO.setMasterAccountName(accountInfoBO.getMasterAccountNameNew());
		else
			masterAccountBO.setMasterAccountName(accountInfoBO.getMasterAccountName());

		masterAccountBO.setUbcid(accountInfoBO.getUbcid());
		try {
			masterAccountBO.setSubAccount(transformToSubAccount(accountInfoBO));
		} catch (IOException e) {
			e.printStackTrace();
		}

		logger.debug("Tranformation of Form to Master Account Object Done : " + masterAccountBO);
		return masterAccountBO;
	}

	/**
	 * Transforms the account into Sub Account.
	 * 
	 * @param form
	 * @return SubAccountBO
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private SubAccountBO transformToSubAccount(AccountInfoBO accountInfoBO) throws IOException {

		logger.debug("In transformToSubAccount() method : Starting");

		SubAccountBO subAccountBO = new SubAccountBO();
		subAccountBO.setTsp(accountInfoBO.getIsTsp().charAt(0));

		char isFeeWaiver = accountInfoBO.getIsFeeWaiver().charAt(0);
		subAccountBO.setFeeWaiverApproved(isFeeWaiver);
		if (isFeeWaiver == 'Y') {
			subAccountBO.setWaiverNotes(accountInfoBO.getWaiverNotes());
		}

		subAccountBO.setFederalTaxId(accountInfoBO.getFedralTaxId());
		subAccountBO.setUbcid(accountInfoBO.getUbcid());
		subAccountBO.setAccountType(accountInfoBO.getAccountType());
		subAccountBO.setSubAccountName(accountInfoBO.getSubAccountName().trim());
		subAccountBO.setBcid(accountInfoBO.getBcid());
		subAccountBO.setCompanyName(accountInfoBO.getCompanyName().trim());
		subAccountBO.setCompanyOwner(accountInfoBO.getCompanyOwner().trim());
		subAccountBO.setBusinessDescription(accountInfoBO.getBusinessDesc().trim());
		if(null!=accountInfoBO.getMasterAccountName()) {
			subAccountBO.setMasterAccountName(accountInfoBO.getMasterAccountName().trim());
		}
	

		if (accountInfoBO.getCompanyCountry() != null && !accountInfoBO.getCompanyCountry().isEmpty()) {
			subAccountBO.setCompanyCountryCode(Long.parseLong(accountInfoBO.getCompanyCountry()));
		}
		if (accountInfoBO.getCompanyState() != null && !accountInfoBO.getCompanyState().isEmpty()) {
			subAccountBO.setCompanyState(Long.parseLong(accountInfoBO.getCompanyState()));
		}

		// Modified For BUC # 28
		if (accountInfoBO.getCompanyCityHid() != null && !accountInfoBO.getCompanyCityHid().isEmpty()) {
			subAccountBO.setCompanyCity(Long.parseLong(accountInfoBO.getCompanyCityHid()));
		}
		if (accountInfoBO.getCompanyStreetAddress() != null && !accountInfoBO.getCompanyStreetAddress().isEmpty()) {
			subAccountBO.setCompanyStreetAddress(accountInfoBO.getCompanyStreetAddress().trim());
		}
		if (accountInfoBO.getCompanyZip() != null && !accountInfoBO.getCompanyZip().isEmpty()) {
			subAccountBO.setCompanyZip(Long.parseLong(accountInfoBO.getCompanyZip()));
		}

		if (accountInfoBO.getBillingCountry() != null && !accountInfoBO.getBillingCountry().isEmpty()) {
			subAccountBO.setBillingCountryCode(Long.parseLong(accountInfoBO.getBillingCountry()));
		}
		if (accountInfoBO.getBillingState() != null && !accountInfoBO.getBillingState().isEmpty()) {
			subAccountBO.setBillingState(Long.parseLong(accountInfoBO.getBillingState()));
		}

		// Modified For BUC # 28
		if (accountInfoBO.getBillingCityHid() != null && !accountInfoBO.getBillingCityHid().isEmpty()) {
			subAccountBO.setBillingCity(Long.parseLong(accountInfoBO.getBillingCityHid()));
		}
		if (accountInfoBO.getBillingStreetAddress() != null && !accountInfoBO.getBillingStreetAddress().isEmpty()) {
			subAccountBO.setBillingStreetAddress(accountInfoBO.getBillingStreetAddress().trim());
		}
		if (accountInfoBO.getBillingZip() != null && !accountInfoBO.getBillingZip().isEmpty()) {
			subAccountBO.setBillingZip(Long.parseLong(accountInfoBO.getBillingZip()));
		}

		if (accountInfoBO.getHeadquarterCountry() != null && !accountInfoBO.getHeadquarterCountry().isEmpty()) {
			subAccountBO.setHqCountryCode(Long.parseLong(accountInfoBO.getHeadquarterCountry()));
		}
		if (accountInfoBO.getHeadquarterState() != null && !accountInfoBO.getHeadquarterState().isEmpty()) {
			subAccountBO.setHqState(Long.parseLong(accountInfoBO.getHeadquarterState()));
		}

		// Modified For BUC # 28
		if (accountInfoBO.getHeadquarterCityHid() != null && !accountInfoBO.getHeadquarterCityHid().isEmpty()) {
			subAccountBO.setHqCity(Long.parseLong(accountInfoBO.getHeadquarterCityHid()));
		}
		if (accountInfoBO.getHeadquarterZip() != null && !accountInfoBO.getHeadquarterZip().isEmpty()) {
			subAccountBO.setHqZip(Long.parseLong(accountInfoBO.getHeadquarterZip()));
		}
		if (accountInfoBO.getHeadquarterStreetAddress() != null
				&& !accountInfoBO.getHeadquarterStreetAddress().isEmpty()) {
			subAccountBO.setHqStreetAddress(accountInfoBO.getHeadquarterStreetAddress().trim());
		}
		if (accountInfoBO.getCciCountry() != null && !accountInfoBO.getCciCountry().isEmpty()) {
			subAccountBO.setCompanyContactCountry(Long.parseLong(accountInfoBO.getCciCountry()));
		}
		if (accountInfoBO.getCciState() != null && !accountInfoBO.getCciState().isEmpty()) {
			subAccountBO.setCompanyContactState(Long.parseLong(accountInfoBO.getCciState()));
		}

		// Modified For BUC # 28
		if (accountInfoBO.getCciCityHid() != null && !accountInfoBO.getCciCityHid().isEmpty()) {
			subAccountBO.setCompanyContactCity(Long.parseLong(accountInfoBO.getCciCityHid()));
		}
		if (accountInfoBO.getCciStreetAddress() != null && !accountInfoBO.getCciStreetAddress().isEmpty()) {
			subAccountBO.setCompanyContactStreetAddress(accountInfoBO.getCciStreetAddress().trim());
		}
		if (accountInfoBO.getCciZip() != null && !accountInfoBO.getCciZip().isEmpty()) {
			subAccountBO.setCompanyContactZip(Long.parseLong(accountInfoBO.getCciZip()));
		}
		if (accountInfoBO.getCciZip() != null && !accountInfoBO.getCciZip().isEmpty()) {
			subAccountBO.setCompanyMainContact(accountInfoBO.getCciContact().trim());
		}
		if (accountInfoBO.getCciZip() != null && !accountInfoBO.getCciZip().isEmpty()) {
			subAccountBO.setCompanyContactEmail(accountInfoBO.getCciEmailAddress().trim());
		}

		subAccountBO.setCompanyContactCellPhone(CommonUtils.getPhoneValue(accountInfoBO.getCciCellPhone()));
		subAccountBO.setCompanyContactDeskPhone(CommonUtils.getPhoneValue(accountInfoBO.getCciDeskPhone()));

		// For BUC # 28
		subAccountBO.setCompanyContactDeskPhoneExtension(
				CommonUtils.getPhoneValue(accountInfoBO.getCciDeskPhoneExtension()));

		subAccountBO.setCreatedBy(accountInfoBO.getCreatedBy());
		subAccountBO.setUpdatedBy(accountInfoBO.getUpdatedBy());

		Character check1 = null;
		if (accountInfoBO.getCheck1() != null) {
			check1 = accountInfoBO.getCheck1().equals("on") ? 'Y' : 'N';
			subAccountBO.setDerivedClFromHq(check1);
		} else {
			subAccountBO.setDerivedClFromHq('N');
		}

		Character check2 = null;
		if (accountInfoBO.getCheck2() != null) {
			check2 = accountInfoBO.getCheck2().equals("on") ? 'Y' : 'N';
			subAccountBO.setDerivedBlFromHq(check2);
		} else {
			subAccountBO.setDerivedBlFromHq('N');
		}

		Character check3 = null;
		if (accountInfoBO.getCheck3() != null) {
			check3 = accountInfoBO.getCheck3().equals("on") ? 'Y' : 'N';
			subAccountBO.setDerivedBlFromCl(check3);
		} else {
			subAccountBO.setDerivedBlFromCl('N');
		}

		Character check4 = null;
		if (accountInfoBO.getCheck4() != null) {
			check4 = accountInfoBO.getCheck4().equals("on") ? 'Y' : 'N';
			subAccountBO.setDerivedCciFromHq(check4);
		} else {
			subAccountBO.setDerivedCciFromHq('N');
		}

		logger.debug("Tranformation of Form to Sub Account Object Done : " + subAccountBO);
		return subAccountBO;
	}

	/**
	 * Transforms the account into Product Account.
	 * 
	 * @param form
	 * @return ProductAccountBO
	 * @throws CometServiceException
	 * @throws CometDataException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private ProductAccountBO transformToProductAccount(AccountInfoBO accountInfoBO) {

		logger.debug("Method AccountManager.transformToProductAccount(): Start");

		ProductAccountBO productAccountBO = new ProductAccountBO();
		productAccountBO.setAccountClass(Long.parseLong(accountInfoBO.getAccountClass()));
		productAccountBO.setTsp(accountInfoBO.getIsTsp().charAt(0));

		char isFeeWaiver = accountInfoBO.getIsFeeWaiver().charAt(0);
		productAccountBO.setFeeWaiverApproved(isFeeWaiver);
		if (isFeeWaiver == 'Y') {
			productAccountBO.setWaiverNotes(accountInfoBO.getWaiverNotes());
		}
		productAccountBO.setFederalTaxId(accountInfoBO.getFedralTaxId());
		productAccountBO.setProductInitiativeName(accountInfoBO.getProductInitiativeAcName().trim());
		productAccountBO.setCreatedBy(accountInfoBO.getUserName());
		productAccountBO.setUpdatedBy(accountInfoBO.getUserName());
		if (accountInfoBO.getCipn() != null) {
			productAccountBO.setCipnName(accountInfoBO.getCipn());
		}
		logger.debug("Product Account BO: " + productAccountBO);
		logger.debug("Method AccountManager.transformToProductAccount(): End");
		return productAccountBO;
	}

	/**
	 * Transforms the account into internal account.
	 * 
	 * @param form
	 * @return InternalAccountBO
	 * @throws CometServiceException
	 * @throws CometDataException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private InternalAccountBO transformToInternalAccount(AccountInfoBO accountInfoBO) throws IOException {

		logger.debug("Method AccountManager.transformToInternalAccount(): Start");

		InternalAccountBO internalAccountBO = new InternalAccountBO();
		internalAccountBO.setAccountClass(Long.parseLong(accountInfoBO.getAccountClass()));
		internalAccountBO.setTsp(accountInfoBO.getIsTsp().charAt(0));

		char isFeeWaiver = accountInfoBO.getIsFeeWaiver().charAt(0);
		internalAccountBO.setFeeWaiverApproved(isFeeWaiver);
		if (isFeeWaiver == 'Y') {
			internalAccountBO.setWaiverNotes(accountInfoBO.getWaiverNotes());
		}
		internalAccountBO.setFederalTaxId(accountInfoBO.getFedralTaxId());
		internalAccountBO.setInternalInitiativeName(accountInfoBO.getInternalInitiativeAcName().trim());
		internalAccountBO.setCreatedBy(accountInfoBO.getUserName());
		internalAccountBO.setUpdatedBy(accountInfoBO.getUserName());
		if (accountInfoBO.getCipn() != null) {
			internalAccountBO.setCipnName(accountInfoBO.getCipn());
		}

		logger.debug("Internal Account BO: " + internalAccountBO);
		logger.debug("Method AccountManager.transformToInternalAccount(): End");
		return internalAccountBO;
	}

	@Override
	public boolean deleteSubAccount(String bcid) throws CometServiceException, CometDataException {
		logger.info("[AccountID : " + (bcid == null ? "" : bcid) + "] " + "Starting method deleteSubAccount : ", this);
		boolean isDeleted = false;
		if (!StringUtils.isEmpty(bcid)) {
			Optional<SubAccount> subAccOptinal = subAccountRepository.findById(bcid);
			if (subAccOptinal.isPresent()) {
				SubAccount subAccount = subAccOptinal.get();
				String ubcid = subAccount.getMasterAccount().getUbcid();
				Query query = em.createNativeQuery(AccountConstant.CHECK_DELETION_OF_SUB_ACCOUNT);
				query.setParameter("bcid", bcid);
				@SuppressWarnings("unchecked")
				List<BigDecimal> queryResultList = query.getResultList();
				int value = 0;
				if (null != queryResultList && queryResultList.size() > 0) {
					for (BigDecimal result : queryResultList) {
						value = value + result.intValue();
					}
					if (value == 0) {
						Query deleteMstrAccQueryCheck = em
								.createNativeQuery(AccountConstant.CHECK_DELETION_OF_MASTER_ACCOUNT);
						deleteMstrAccQueryCheck.setParameter("ubcid", ubcid);
						@SuppressWarnings("unchecked")
						List<BigDecimal> mstrAccCounList = deleteMstrAccQueryCheck.getResultList();
						if (null != mstrAccCounList && mstrAccCounList.size() == 1
								&& mstrAccCounList.get(0).intValue() == 1) {
							subAccountRepository.deleteById(bcid);
							if (null != ubcid) {
								masterAccountRepository.deleteById(ubcid);
							}
							isDeleted = true;
						} else {
							subAccountRepository.deleteById(bcid);
							isDeleted = true;
						}
					}
				}
			} else {
				logger.error("[BCID : " + bcid + " ] does not exists in comet db");
				throw new CometDataException("Error: " + "BCID [ " + bcid + " ] does not exists in comet db");
			}
		}
		logger.info("[AccountID : " + (bcid == null ? "" : bcid) + "] " + "Exiting method deleteSubAccount : ", this);
		return isDeleted;
	}

	@Override
	public boolean deleteInternalProductAccount(String cipn) throws CometDataException {
		logger.info(
				"[AccountID : " + (cipn == null ? "" : cipn) + "] " + "Starting method deleteInternalProductAccount : ",
				this);
		boolean isDeleted = false;
		if (!StringUtils.isEmpty(cipn)) {
			Optional<InternalProductAccount> internalProductAccountOptioal = internalProductAccountRepository
					.findById(cipn);
			if (internalProductAccountOptioal.isPresent()) {
				Query checkInternalProdAccDeletion = em
						.createNativeQuery(AccountConstant.CHECK_DELETION_OF_INTERNAL_PRODUCT_INITIATIVE_ACCOUNT);
				checkInternalProdAccDeletion.setParameter("cipn", cipn);
				@SuppressWarnings("unchecked")
				List<BigDecimal> checkInternalProdAccDeletionList = checkInternalProdAccDeletion.getResultList();
				if (null != checkInternalProdAccDeletionList && checkInternalProdAccDeletionList.size() > 0) {
					int value = 0;
					for (BigDecimal result : checkInternalProdAccDeletionList) {
						value = value + result.intValue();
					}
					if (value == 0) {
						internalProductAccountRepository.deleteById(cipn);
						isDeleted = true;
					}
				}
			} else {
				logger.error("[CIPN : " + cipn + " ] does not exists in comet db");
				throw new CometDataException("Error : " + "[CIPN ID  : " + cipn + " ] does not exists in comet db");
			}
		}
		logger.info(
				"[AccountID : " + (cipn == null ? "" : cipn) + "] " + "Exiting method deleteInternalProductAccount : ",
				this);
		return isDeleted;
	}

	@Override
	@Transactional
	public AccountInfoBO createAccount(AccountInfoBO accountInfoBO)
			throws CometDataException, IOException, CometServiceException {
		logger.info("Method createAccount: Start");

		String masterAccountCategory = accountInfoBO.getMasterAccountCatagoryList();

		// Case-1: If master account is selected.
		if (accountInfoBO.getAccountClass().equals(AccountConstant.CLASS1)) {
			logger.info("in Customer  Associated");
			if (masterAccountCategory.equalsIgnoreCase(AccountConstant.ACCOUNT_CAT_NEW)) {
				createMasterAccount(accountInfoBO);
			}
			// Case-2: If sub account is selected.*/
			else if (masterAccountCategory.equalsIgnoreCase(AccountConstant.ACCOUNT_CAT_SUB)) {
				createSubAccount(accountInfoBO);
			} else {
				logger.error("Method createAccount() : Invalid Option ");
			}
		} else {
			// Case-3: If internal accountInfoBO is selected.
			if (accountInfoBO.getAccountClass().equals(AccountConstant.CLASS2)) {
				InternalAccountBO internalAccount = createInternalAccount(accountInfoBO);
				List<InternalProductAccount> ipa= internalProductAccountRepository.findByInternalProductAccountName(internalAccount.getInternalInitiativeName());
				if(ipa!=null && ipa.size()>0)
				{
					accountInfoBO.setCipn(ipa.get(ipa.size()-1).getCipn());
				}
			}
			// Case-4: If product account is selected.
			else if (accountInfoBO.getAccountClass().contains(AccountConstant.CLASS3)) {
				ProductAccountBO productAccount = createProductAccount(accountInfoBO);
				List<InternalProductAccount> ipa= internalProductAccountRepository.findByInternalProductAccountName(productAccount.getProductInitiativeName());
				if(ipa!=null && ipa.size()>0)
				{
					accountInfoBO.setCipn(ipa.get(ipa.size()-1).getCipn());
				}
			} else {
				logger.error("Method createAccount() : Invalid Option ");
			}
		}

		logger.info("Creating new account finished.");
		return accountInfoBO;
	}

	private MasterAccountBO createMasterAccount(AccountInfoBO accountInfoBO)
			throws CometServiceException, CometDataException, FileNotFoundException, IOException {
		logger.info("Method createMasterAccount: Start");
		SubAccountBO subAccount =transformToSubAccount(accountInfoBO);
		MasterAccountBO masterAccount = saveMasterAccount(transformToMasterAccount(accountInfoBO));
		SubAccountBO subAccountBO = saveSubAccount(transformToSubAccount(accountInfoBO));
		if(null!=masterAccount.getErrorMessage() && !masterAccount.getErrorMessage().isEmpty()) {
			accountInfoBO.setErrorMessage(masterAccount.getErrorMessage());	
			return masterAccount;
		}else {
			if(null!=subAccountBO.getErrorMessage() && !subAccountBO.getErrorMessage().isEmpty()) {
				accountInfoBO.setErrorMessage(subAccountBO.getErrorMessage() );	
				return masterAccount;
			}else {
				accountInfoBO.setErrorMessage(null);
				MasterAccount pMasterAccount = accountHelper.populateMasterAccount(transformToMasterAccount(accountInfoBO));
				masterAccountRepository.save(pMasterAccount);
				Date today = new Date();
				subAccount.setCreatedOn(today);
				subAccount.setUpdatedOn(null);
				subAccount.setUpdatedBy(null);
				SubAccount subAcc = accountHelper.populateSubAccount(subAccount, null);
				subAccountRepository.save(subAcc);
			}
			
		}
		
		
		logger.info("Method createMasterAccount: End");
		return masterAccount;
	}

	private SubAccountBO createSubAccount(AccountInfoBO accountInfoBO)
			throws CometServiceException, CometDataException, FileNotFoundException, IOException {
		logger.info("Method createSubAccount: Start");
		SubAccountBO subAccount = saveSubAccount(transformToSubAccount(accountInfoBO));
		logger.info("Method createSubAccount: End");
		return subAccount;
	}
	
	private MasterAccountBO saveMasterAccount(MasterAccountBO account) throws CometDataException {
		logger.info("Create new master account started " + account.getUbcid());
		try {
			// Validation
			if (account.getUbcid() == null) {
				logger.error("COMET_BE_001","UBCID not defined"+"  ");
				MasterAccountBO existingMAccountBOTemp = new MasterAccountBO();
				existingMAccountBOTemp.setErrorMessage("COMET_BE_001 :UBCID not defined");
				return existingMAccountBOTemp;
			}

			if (account.getMasterAccountName() == null || account.getMasterAccountName().trim().length() < 1) {
				logger.error("COMET_BE_002", "Master account " + "name can not be null or empty");
				MasterAccountBO existingMAccountBOTemp = new MasterAccountBO();
				existingMAccountBOTemp.setErrorMessage("COMET_BE_002::Master account " + "name can not be null or empty");
				return existingMAccountBOTemp;
			}

			MasterAccountBO existingMAccountBO = this.getMasterAccount(account.getUbcid());
			if (existingMAccountBO != null) {
				logger.error("COMET_BE_003",
						"Master Account Id [" + account.getUbcid() + "] already exist, please enter unique value.");
				MasterAccountBO existingMAccountBOTemp = new MasterAccountBO();
				existingMAccountBOTemp.setErrorMessage("COMET_BE_003 :: Master Account Id [" + account.getUbcid() + "] already exist, please enter unique value.");
				return existingMAccountBOTemp;
			}
			//MasterAccount pMasterAccount = accountHelper.populateMasterAccount(account);
			//masterAccountRepository.save(pMasterAccount);
			logger.debug(
					"[AccountUbcID : " + (account == null ? "" : account.getUbcid() == null ? "" : account.getUbcid())
							+ "] " + "Saved master account.");
		} catch (Exception exception) {
			exception.printStackTrace();
			logger.error(
					"[AccountUbcID : " + (account == null ? "" : account.getUbcid() == null ? "" : account.getUbcid())
							+ "] " + "Creating new master account failed",
					exception);
			//throw new CometDataException("DA001", exception);
		}
		logger.info("[AccountUbcID : " + (account == null ? "" : account.getUbcid() == null ? "" : account.getUbcid())
				+ "] " + "Creating new master account finished");
		return account;
	}

	private SubAccountBO saveSubAccount(SubAccountBO account) throws CometDataException, CometServiceException {
		logger.info("[AccountID : " + (account == null ? "" : account.getBcid() == null ? "" : account.getBcid()) + "] "
				+ "Create new sub account started " + account.getBcid());
		try {
			SubAccountBO subAcc = null;
			if (account.getUbcid() == null) {
				logger.error("COMET_BE_005", "Master account UBCID not defined"+"");
				account.setErrorMessage("COMET_BE_005 Master account UBCID not defined.");
				return account;
			}

			if (account.getBcid() == null) {
				logger.error("COMET_BE_006", "Sub account BCID not defined."+"");
				account.setErrorMessage("COMET_BE_006 Sub account BCID not defined.");
				return account;
			}

			if (account.getSubAccountName() == null || account.getSubAccountName().trim().length() < 1) {
				logger.error("COMET_BE_007", "Sub account name can not be null or empty"+"");
				account.setErrorMessage("COMET_BE_007 : Sub account name can not be null or empty");
				return account;
			}

			// Check existing BCID
			subAcc = this.getBcidExistorNot(account.getBcid());
			if (subAcc != null) {
			logger.error("COMET_BE_008",
						"Account Id[" + account.getBcid() + "] already exist.");
			subAcc.setErrorMessage("COMET_BE_008 Account Id[" + account.getBcid() + "] already exist.");
			return subAcc;
			}
			
		} catch (Exception exception) {
			logger.error("[AccountID : " + (account == null ? "" : account.getBcid() == null ? "" : account.getBcid())
					+ "] " + exception.getStackTrace());
			exception.printStackTrace();
			logger.error("[AccountID : " + (account == null ? "" : account.getBcid() == null ? "" : account.getBcid())
					+ "] " + "Create new sub account failed", exception);
			throw new CometDataException("DA001", exception);
		}
		logger.info("[AccountID : " + (account == null ? "" : account.getBcid() == null ? "" : account.getBcid()) + "] "
				+ "Create new sub account finished");
		return account;

	}

	private InternalAccountBO createInternalAccount(AccountInfoBO account)
			throws CometServiceException, CometDataException, FileNotFoundException, IOException {

		logger.debug("In createInternalAccount() method : Starting");

		InternalAccountBO internalAccountBO = new InternalAccountBO();
		internalAccountBO.setAccountClass(Long.parseLong(account.getAccountClass()));
		internalAccountBO.setTsp(account.getIsTsp().charAt(0));

		char isFeeWaiver = account.getIsFeeWaiver().charAt(0);
		internalAccountBO.setFeeWaiverApproved(isFeeWaiver);
		if (isFeeWaiver == 'Y') {
			internalAccountBO.setWaiverNotes(account.getWaiverNotes());
		}
		internalAccountBO.setFederalTaxId(account.getFedralTaxId());
		internalAccountBO.setInternalInitiativeName(account.getInternalInitiativeAcName());
		internalAccountBO.setCreatedBy(account.getCreatedBy());
		internalAccountBO.setUpdatedBy(account.getUserName());

		logger.debug("Internal Account Bean: " + internalAccountBO);

		InternalAccountBO internalAccount = saveInternalAccount(internalAccountBO);
		return internalAccount;
	}

	private InternalAccountBO saveInternalAccount(InternalAccountBO account) throws CometDataException {
		logger.info(
				"[AccountID : " + (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName())
						+ "] " + "Saving new internal account started");
		try {
			Date today = new Date();
			account.setCreatedOn(today);
			account.setUpdatedOn(null);
			account.setUpdatedBy(null);
			InternalProductAccount interninitproductMaster = accountHelper.populateInternalAccount(account);
			internalProductAccountRepository.save(interninitproductMaster);
			logger.debug("[AccountID : "
					+ (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName()) + "] "
					+ "Generated CIPN value [" + interninitproductMaster.getCipn() + "]");
			account.setCipnName(interninitproductMaster.getCipn());
		} catch (Exception exception) {
			logger.error("[AccountID : "
					+ (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName()) + "] "
					+ exception.getStackTrace());
			exception.printStackTrace();
			logger.error("[AccountID : "
					+ (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName()) + "] "
					+ "Saving new internal account failed", exception);
			throw new CometDataException("DA001", exception);
		}
		logger.info(
				"[AccountID : " + (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName())
						+ "] " + "Saving new internal account finished");
		return account;
	}

	private ProductAccountBO createProductAccount(AccountInfoBO account)
			throws CometServiceException, CometDataException, FileNotFoundException, IOException {
		logger.debug("In createProductAccount() method : Starting");

		ProductAccountBO productAccountBO = new ProductAccountBO();
		productAccountBO.setAccountClass(Long.parseLong(account.getAccountClass()));
		productAccountBO.setTsp(account.getIsTsp().charAt(0));

		char isFeeWaiver = account.getIsFeeWaiver().charAt(0);
		productAccountBO.setFeeWaiverApproved(isFeeWaiver);
		if (isFeeWaiver == 'Y') {
			productAccountBO.setWaiverNotes(account.getWaiverNotes());
		}
		productAccountBO.setFederalTaxId(account.getFedralTaxId());
		productAccountBO.setProductInitiativeName(account.getProductInitiativeAcName());
		productAccountBO.setCreatedBy(account.getCreatedBy());
		productAccountBO.setUpdatedBy(account.getUserName());

		logger.debug("Product Account Bean: " + productAccountBO);

		ProductAccountBO productAccount = saveProductAccount(productAccountBO);
		return productAccount;
	}

	private ProductAccountBO saveProductAccount(ProductAccountBO account) throws CometDataException {
		logger.info(
				"[AccountID : " + (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName())
						+ "] " + "Saving new product account started " + account.getProductInitiativeName());
		try {
			Date today = new Date();
			account.setCreatedOn(today);
			account.setUpdatedOn(null);
			account.setUpdatedBy(null);
			InternalProductAccount interninitproductMaster = accountHelper.populateProductAccount(account);
			internalProductAccountRepository.save(interninitproductMaster);
			account.setCipnName(interninitproductMaster.getCipn());
		} catch (Exception exception) {
			logger.error("[AccountID : "
					+ (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName()) + "] "
					+ exception.getStackTrace());
			exception.printStackTrace();
			logger.error("[AccountID : "
					+ (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName()) + "] "
					+ "Saving new product account failed", exception);
			throw new CometDataException("DA001", exception);
		}
		logger.info(
				"[AccountID : " + (account == null ? "" : account.getCipnName() == null ? "" : account.getCipnName())
						+ "] " + "Saving new product account finished");
		return account;
	}

	@Override
	public AccountFileDetailBO getFileDetails(String accountClassId, String accountId)
			throws CometDataException, SQLException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method getFileDetails : ",
				this);
		AccountFileDetailBO accountFileDetailBO = null;
		String fileExtensionType = null;
		if (accountClassId.equalsIgnoreCase(AccountConstant.CLASS1)) {
			Optional<SubAccount> subAccountOptional = subAccountRepository.findById(accountId);
			if (subAccountOptional.isPresent()) {
				SubAccount subAccount = subAccountOptional.get();
				if (null == subAccount.getWaiverAttachment()) {
					throw new CometDataException("No File To Download.");
				}
				accountFileDetailBO = new AccountFileDetailBO();
				accountFileDetailBO.setUploadFileName(subAccount.getWaiverAttachmentFilename());
				fileExtensionType = CommonUtils.getAttachmentExtension(subAccount.getWaiverAttachmentFilename());
				accountFileDetailBO.setUploadContentType(fileExtensionType);
				//byte[] attachment = subAccount.getWaiverAttachment();
				accountFileDetailBO.setUploadAttachment(subAccount.getWaiverAttachment());
			}
		} else if (accountClassId.equalsIgnoreCase(AccountConstant.CLASS2)
				|| accountClassId.equalsIgnoreCase(AccountConstant.CLASS3)) {
			Optional<InternalProductAccount> internalProductAccountOptional = internalProductAccountRepository
					.findById(accountId);
			if (internalProductAccountOptional.isPresent()) {
				InternalProductAccount internalProductAccount = internalProductAccountOptional.get();
				if (null == internalProductAccount.getWaiverAttachment()) {
					throw new CometDataException("No File To Download.");
				}
				accountFileDetailBO = new AccountFileDetailBO();
				accountFileDetailBO.setUploadFileName(internalProductAccount.getWaiverAttachmentFilename());
				fileExtensionType = CommonUtils.getAttachmentExtension(internalProductAccount.getWaiverAttachmentFilename());
				accountFileDetailBO.setUploadContentType(fileExtensionType);
				//Blob attachment = internalProductAccount.getWaiverAttachment();
				accountFileDetailBO.setUploadAttachment(internalProductAccount.getWaiverAttachment());
			}
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method getFileDetails : ",
				this);
		return accountFileDetailBO;
	}

	@Override
	public String storeFile(MultipartFile file, String accountId, Long accClassId)
			throws IOException, SerialException, SQLException, CometDataException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Storing File for account Started "
				+ accountId);
		SubAccount subAccount = null;
		InternalProductAccount internalProductAccount = null;
		String msg = null;
		if (accClassId.equals(1001L)) {
			Optional<SubAccount> subAccountOptional = subAccountRepository.findById(accountId);
			if (subAccountOptional.isPresent()) {
				subAccount = subAccountOptional.get();
				subAccount.setWaiverAttachmentFilename(file.getOriginalFilename());
				byte[] contents = file.getBytes();
				//Blob blob = new SerialBlob(contents);
				subAccount.setWaiverAttachment(contents);
				subAccountRepository.saveAndFlush(subAccount);
				msg = AccountConstant.SUCCESS_MSG;
			}
		} else if (accClassId.equals(1002L) || accClassId.equals(1003L)) {
			Optional<InternalProductAccount> internalProductAccountOptional = internalProductAccountRepository
					.findById(accountId);
			if (internalProductAccountOptional.isPresent()) {
				internalProductAccount = internalProductAccountOptional.get();
				internalProductAccount.setWaiverAttachmentFilename(file.getOriginalFilename());
				byte[] contents = file.getBytes();
				//Blob blob = new SerialBlob(contents);
				internalProductAccount.setWaiverAttachment(contents);
				internalProductAccountRepository.saveAndFlush(internalProductAccount);
				msg = AccountConstant.SUCCESS_MSG;
			}
		} else {
			logger.error("[ACCOUNTID : " + accountId + " ] does not exists in comet db");
			throw new CometDataException("Error : " + "[ACCOUNT ID  : " + accountId + " ] does not exists in comet db");
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Storing File for account Ended "
				+ accountId);
		return msg;
	}
	
	@Override
	public List<MasterAccountBO> getExistingAccList() {
		logger.info("Starting method getExistingAccList : ");
		List<MasterAccount> masterAccList = masterAccountRepository.findAll();
		List<MasterAccountBO> accBo = new ArrayList<MasterAccountBO>();
		MasterAccountBO accTypeBO = null;
		for (MasterAccount country : masterAccList) {
			if (country != null) {
				accTypeBO = new MasterAccountBO();
				accTypeBO.setUbcid(country.getUbcid());
				accTypeBO.setMasterAccountName(country.getMasterAccountName());
				accBo.add(accTypeBO);
			}
		}
		logger.info("Exiting method getExistingAccList : ");
		return accBo;
	}
	
	@Override
	public boolean delAccountAttachment(String accountClassId, String accountId) {
		logger.info("Starting method delAccountAttachment : ");
		boolean isAttachmentDeleted = false;
		SubAccount subAccount = null;
		InternalProductAccount internalProductAccount = null;
		if(accountClassId.equals("1001")){
			Optional<SubAccount> subAccountOptional = subAccountRepository.findById(accountId);
			subAccount = subAccountOptional.get();
		}else{
			Optional<InternalProductAccount> internalAccountOptional = internalProductAccountRepository.findById(accountId);
			internalProductAccount = internalAccountOptional.get();
		}
		
		if(subAccount != null){
			subAccount.setWaiverAttachmentFilename(null);
			subAccount.setWaiverAttachment(null);
			subAccountRepository.save(subAccount);
			isAttachmentDeleted = true;
		}
				
		if(internalProductAccount != null){
			internalProductAccount.setWaiverAttachmentFilename("");
			internalProductAccount.setWaiverAttachment(null);
			internalProductAccountRepository.saveAndFlush(internalProductAccount);
			isAttachmentDeleted = true;
		}
		logger.info("Exiting method delAccountAttachment : ");
		return isAttachmentDeleted;
		
	}	
}
