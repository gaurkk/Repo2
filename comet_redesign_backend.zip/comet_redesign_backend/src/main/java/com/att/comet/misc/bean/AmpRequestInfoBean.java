package com.att.comet.misc.bean;

import java.util.HashMap;
import java.util.List;

import com.att.comet.misc.AmpRequestBO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AmpRequestInfoBean {

private HashMap<String,List<AmpRequestBO>> ampHashMap = new HashMap<String,List<AmpRequestBO>>();
	
}
