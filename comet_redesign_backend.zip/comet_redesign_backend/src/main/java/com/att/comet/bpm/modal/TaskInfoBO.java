package com.att.comet.bpm.modal;

import java.util.HashMap;
import java.util.Map;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class TaskInfoBO extends CometGenericBO {
	private static final long serialVersionUID = 4598988696475726675L;

	private String id;
	private String processDefinitionId;
	private String processInstanceId;
	private String executionId;
	private String caseDefinitionId;
	private String caseInstanceId;
	private String caseExecutionId;
	private String activityInstanceId;
	private String name;
	private String description;
	private String deleteReason;
	private String owner;
	private String assignee;
	private String startTime;
	private String endTime;
	private float duration;
	private String taskDefinitionKey;
	private float priority;
	private String due;
	private String parentTaskId;
	private String followUp;
	private String tenantId = null;
	private String removalTime;
	private String rootProcessInstanceId;
	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}