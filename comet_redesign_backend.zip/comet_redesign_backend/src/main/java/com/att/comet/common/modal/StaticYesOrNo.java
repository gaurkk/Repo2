package com.att.comet.common.modal;

import org.apache.commons.lang3.StringUtils;

public enum StaticYesOrNo {
	YES(1, "Yes"),
	NO(2, "No");
	
	public int getId() {
		return staticId;
	}

	public String getYesOrNo() {
		return staticName;
	}

	private final int staticId;
	private final String staticName;

	public static StaticYesOrNo getEnum(String value) {
		StaticYesOrNo getStat = null;
		if (StringUtils.isNotBlank(value)) {
			for (StaticYesOrNo stat : StaticYesOrNo.values()) {
				if (stat.name().equalsIgnoreCase(value)) {
					getStat = stat;
					break;
				}
			}
		}
		return getStat;
	}

	private StaticYesOrNo(int staticId, String staticName) {
		this.staticId = staticId;
		this.staticName = staticName;
	}
}
