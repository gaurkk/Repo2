package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "EXT_INT_EVENT_STATUSES")
public class ExternalInterfaceEventStatuses implements Serializable {

	private static final long serialVersionUID = 5807384054914907394L;

	private Long id;
	private ExternalInterfaceDetails extInterfaceDetails;
	private String statusDesc;
	private Date statusTime;
	private String updatedBy;

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_EVENT_STATUSES_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_EVENT_STATUSES_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_EVENT_STATUSES_ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the extInterfaceDetails
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EXT_INTERFACE_ID", nullable = false)
	public ExternalInterfaceDetails getExtInterfaceDetails() {
		return extInterfaceDetails;
	}

	/**
	 * @param extInterfaceDetails the extInterfaceDetails to set
	 */
	public void setExtInterfaceDetails(ExternalInterfaceDetails extInterfaceDetails) {
		this.extInterfaceDetails = extInterfaceDetails;
	}

	/**
	 * @return the statusDesc
	 */
	@Column(name = "STATUS_DESC", length = 100)
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * @return the statusTime
	 */
	@Column(name = "STATUS_TIME")
	public Date getStatusTime() {
		return statusTime;
	}

	/**
	 * @param statusTime the statusTime to set
	 */
	public void setStatusTime(Date statusTime) {
		this.statusTime = statusTime;
	}

	/**
	 * @return the updatedBy
	 */
	@Column(name = "UPDATED_BY", length = 100)
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
