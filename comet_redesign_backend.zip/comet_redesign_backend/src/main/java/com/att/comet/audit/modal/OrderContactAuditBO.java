package com.att.comet.audit.modal;

import java.util.HashSet;
import java.util.Set;

import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.order.modal.OrderContactInfoBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class OrderContactAuditBO extends CometGenericBO {
	private static final long serialVersionUID = 914791779138559666L;

	private Long orderContactId; 
	private Long orderId;
	private Set<OrderContactInfoBO> contactInfoList = new HashSet<OrderContactInfoBO>();  
	private Long roleId;
	private String apnId;
	private String deploymentInstruction;	
}
