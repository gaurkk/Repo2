package com.att.comet.charts.result;

import java.util.ArrayList;
import java.util.List;

public class GridDisplayBO<T> implements DisplayResultBO {

	private static final long serialVersionUID = 540961127950281467L;

	private List<T> lstGridBOs = new ArrayList<T>();

	public List<T> getLstGridBOs() {
		return lstGridBOs;
	}

	public void setLstGridBOs(List<T> lstGridBOs) {
		this.lstGridBOs = lstGridBOs;
	}

}
