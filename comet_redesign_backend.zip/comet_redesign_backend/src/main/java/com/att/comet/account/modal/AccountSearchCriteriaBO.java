package com.att.comet.account.modal;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * POJO for AccountSearchCriteria
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class AccountSearchCriteriaBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = -3939334687440477926L;

	// Fields for master/sub account search
	private String masterAccountName;
	private String subAccountName;
	private String ubcid;
	private String bcid;
	private String companyOwner;
	private String companyName;
	private String accountType;

	// Fields for internal/product account search
	private String internalProductAccountName;
	private String accountClass;
	private String cipn;

	// Common fields for both account search
	private String federalTaXId;
	private String accountCreatedBy;
	private String creationDateFrom;
	private String creationDateTo;
	private String apnName;
	private String pdpName;
	private String customerOwnedDomainName;
	private String pdpid;
	private String cityName;
	private String stateName;
	private String streetAddress;
	private String zipCode;
}