package com.att.comet.charts.service;

import com.att.comet.charts.modal.ChartsRequestBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.service.GenericCometService;

public interface ChartsGridService extends GenericCometService {

	/**
	 * Return all the orders info specific to chart selection.
	 * 
	 * @param ChartsRequestBO 
	 * @return ResultBO 
	 * @throws
	 */
	public ResultBO getGridDataUsingCriteria(ChartsRequestBO chartsRequestBo);
}
