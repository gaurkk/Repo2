package com.att.comet.common.constant;

import com.att.comet.common.bean.TabBean;

public enum TypeOrderForm {
	ORDER_INITIATE(1001L, new TabBean(1001L, 1)),
	ORDER_DAPN(1002L, new TabBean(1002L, 2)),
	ORDER_APN(1003L, new TabBean(1003L, 3)),
	ORDER_BH(1004L, new TabBean(1004L, 6)),
	ORDER_ACCOUNT(1005L, new TabBean(1005L, 4)),
	ORDER_CONTACT(1006L, new TabBean(1006L, 5)),
	ORDER_FIREWALL(1020L, new TabBean(1020L, 7)),
	ORDER_MPLS(1008L, new TabBean(1008L, 8)),
	ORDER_IVPN(1010L, new TabBean(1010L, 10)),
	ORDER_CRD(1011L, new TabBean(1011L, 11)),
	ORDER_BILLING(1012L, new TabBean(1012L, 12)),
	ORDER_MISC(1013L, new TabBean(1013L, 13)),
	ORDER_SUMMARY(1014L, new TabBean(1014L, 14)),
	ORDER_HISTORY(1015L, new TabBean(1015L, 15)),
	ORDER_TASK(1017L, new TabBean(1017L, 17)),
	ORDER_LOGS(1018L, new TabBean(1018L, 18));
	

	private final Long id;
	private final TabBean tab;

	/**
	 * Returns the id.
	 * 
	 * @return Long
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Returns the tab.
	 * 
	 * @return TabBean
	 */
	public TabBean getTab() {
		return tab;
	}

	/**
	 * Returns the type order form.
	 * 
	 * @param id
	 * @return TypeOrderForm
	 */
	public static TypeOrderForm getTypeOrderForm(Long id) {
		if (id != null) {
			for (TypeOrderForm typeOrderForm : TypeOrderForm.values()) {
				if (typeOrderForm.getId().longValue() == id.longValue()) {
					return typeOrderForm;
				}
			}
		}
		return null;
	}

	/**
	 * Constructor.
	 * 
	 * @param id
	 * @param tab
	 */
	private TypeOrderForm(Long id, TabBean tab) {
		this.id = id;
		this.tab = tab;
	}
}