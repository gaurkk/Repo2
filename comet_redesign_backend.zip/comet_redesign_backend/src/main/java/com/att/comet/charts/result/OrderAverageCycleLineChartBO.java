package com.att.comet.charts.result;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OrderAverageCycleLineChartBO implements Serializable {

	private static final long serialVersionUID = 6350714159129705795L;

	private String month;
	private int avg_ordersum_implecompl;
	private int avg_ordersum_ttupass;
	private int avg_osdappr_ordersum;

}
