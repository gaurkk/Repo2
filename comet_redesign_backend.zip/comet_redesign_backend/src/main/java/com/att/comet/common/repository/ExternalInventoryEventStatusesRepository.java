package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.ExternalInterfaceEventStatuses;

@Repository 
public interface ExternalInventoryEventStatusesRepository extends JpaRepository<ExternalInterfaceEventStatuses, String>{

	List<ExternalInterfaceEventStatuses>  findByExtInterfaceDetails_ExtInterfaceIdStartsWithAndExtInterfaceDetails_RequestTypeAndExtInterfaceDetails_Orders_OrderIdOrderByExtInterfaceDetails_CreatedAtAscStatusTimeAsc(String extInterfaceId, String requestType, Long orderId);
}
