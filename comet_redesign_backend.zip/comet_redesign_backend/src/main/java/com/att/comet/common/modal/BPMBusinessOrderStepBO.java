package com.att.comet.common.modal;

import java.io.Serializable;
import java.util.Date;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class BPMBusinessOrderStepBO extends CometGenericBO implements Serializable{

	private static final long serialVersionUID = -7570055800952263297L;
	private Long orderId;
	private Long orderBusinessStepId;
	private String businessStepStatus;
	private String businessStepValue;
	private Date businessStepExecutedOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;
	private Long orderTypeId;
	private String orderTypeName;
	private Long businessStepId;
	private String attuid;
}
