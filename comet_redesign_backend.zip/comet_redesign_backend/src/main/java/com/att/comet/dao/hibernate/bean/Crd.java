package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for Crd. Mapped to CRD table in the database.
 */
@Entity
@Table(name = "CRD")
public class Crd implements Serializable {

	private static final long serialVersionUID = -7472423979588681185L;

	private Long crdId;
	private DedicatedApn dedicatedApn;
	private Orders orders;
	private String requestType;
	private String instructions;
	private String selfImpactAssessment;
	private String impactDetails;
	private String businessPurpose;
	private Set<CrdDataCenter> crdDataCenters = new HashSet<CrdDataCenter>(0);

	/**
	 * Getter method for crdId. CRD_ID mapped to CRD_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "CRD_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_CRD_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_CRD_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CRD_ID")
	public Long getCrdId() {
		return this.crdId;
	}

	/**
	 * @param crdId to crdId set.
	 */
	public void setCrdId(Long crdId) {
		this.crdId = crdId;
	}

	/**
	 * Getter method for dedicatedApn. APN_ID mapped to APN_ID in the database
	 * table.
	 * 
	 * @return DedicatedApn
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "APN_ID")
	public DedicatedApn getDedicatedApn() {
		return this.dedicatedApn;
	}

	/**
	 * @param dedicatedApn to dedicatedApn set.
	 */
	public void setDedicatedApn(DedicatedApn dedicatedApn) {
		this.dedicatedApn = dedicatedApn;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID")
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for requestType. REQUEST_TYPE mapped to REQUEST_TYPE in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "REQUEST_TYPE", length = 100)
	public String getRequestType() {
		return this.requestType;
	}

	/**
	 * @param requestType to requestType set.
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	/**
	 * Getter method for instructions. INSTRUCTIONS mapped to INSTRUCTIONS in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "INSTRUCTIONS", length = 3500)
	public String getInstructions() {
		return this.instructions;
	}

	/**
	 * @param instructions to instructions set.
	 */
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	/**
	 * Getter method for selfImpactAssessment. SELF_IMPACT_ASSESSMENT mapped to
	 * SELF_IMPACT_ASSESSMENT in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SELF_IMPACT_ASSESSMENT", length = 3500)
	public String getSelfImpactAssessment() {
		return this.selfImpactAssessment;
	}

	/**
	 * @param selfImpactAssessment to selfImpactAssessment set.
	 */
	public void setSelfImpactAssessment(String selfImpactAssessment) {
		this.selfImpactAssessment = selfImpactAssessment;
	}

	/**
	 * Getter method for impactDetails. IMPACT_DETAILS mapped to IMPACT_DETAILS in
	 * the database table.
	 * 
	 * @return String
	 */
	@Column(name = "IMPACT_DETAILS", length = 3500)
	public String getImpactDetails() {
		return this.impactDetails;
	}

	/**
	 * @param impactDetails to impactDetails set.
	 */
	public void setImpactDetails(String impactDetails) {
		this.impactDetails = impactDetails;
	}

	/**
	 * Getter method for businessPurpose. BUSINESS_PURPOSE mapped to
	 * BUSINESS_PURPOSE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_PURPOSE", length = 3500)
	public String getBusinessPurpose() {
		return this.businessPurpose;
	}

	/**
	 * @param businessPurpose to businessPurpose set.
	 */
	public void setBusinessPurpose(String businessPurpose) {
		this.businessPurpose = businessPurpose;
	}

	/**
	 * Getter method for crdDataCenters.
	 * 
	 * @return Set<CrdDataCenter>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "crd")
	public Set<CrdDataCenter> getCrdDataCenters() {
		return this.crdDataCenters;
	}

	/**
	 * @param crdDataCenters to crdDataCenters set.
	 */
	public void setCrdDataCenters(Set<CrdDataCenter> crdDataCenters) {
		this.crdDataCenters = crdDataCenters;
	}
	
}