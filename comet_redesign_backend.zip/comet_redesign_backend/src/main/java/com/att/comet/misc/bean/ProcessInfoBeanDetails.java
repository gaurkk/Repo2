package com.att.comet.misc.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProcessInfoBeanDetails {

	private String activityName;
	private String status;
	private String information;
	private String taskOwer;
	private String timeStamp;
	private String flagNaN;
	private String itwosNoteDisplay;
	private Integer sequenceNumber;
	
}
