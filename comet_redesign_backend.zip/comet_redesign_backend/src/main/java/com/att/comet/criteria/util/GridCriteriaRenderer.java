package com.att.comet.criteria.util;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.exception.SQLGrammarException;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.bpm.modal.TaskListRequestBO;
import com.att.comet.bpm.service.BPMService;
import com.att.comet.charts.result.BackhaulListGridDisplayBO;
import com.att.comet.charts.result.DApnListGridDisplayBO;
import com.att.comet.charts.result.DisplayResultBO;
import com.att.comet.charts.result.GridDisplayBO;
import com.att.comet.charts.result.OrderAllFieldsReportDisplayBO;
import com.att.comet.charts.result.OrderApnListGridDisplayBO;
import com.att.comet.charts.result.OrderListGridDisplayBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.charts.result.TaskListGridDisplayBO;
import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
//import com.att.comet.SearchTaskSchema.OrderSearchCriteria;
//import com.att.comet.SearchTaskSchema.SearchDataType;
//import com.att.comet.SearchTaskSchema.SearchReqType;
//import com.att.comet.SearchTaskSchema.SearchRequest;
//import com.att.comet.SearchTaskSchema.TaskCreationDate;
//import com.att.comet.SearchTaskSchema.TaskSearchCriteria;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.dao.ChartsSqlConstants;
import com.att.comet.dao.ScalarConstants;
import com.att.comet.dao.hibernate.bean.BpmTask;
import com.att.comet.dao.hibernate.bean.OrderUserBpmTasks;
import com.att.comet.order.dao.OrderSqlConstant;
import com.att.comet.order.helper.OrderTaskHelper;
import com.att.comet.order.helper.UserHelper;
//import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.modal.MobilePoolRangeBO;
import com.att.comet.order.task.repository.BpmTaskRepository;
import com.att.comet.order.task.repository.OrderUserBpmTasksRepository;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.allfieldreport.AllFieldReportRestriction;
import com.att.comet.restriction.backhaul.BackhaulRestriction;
import com.att.comet.restriction.dapn.DApnMobileIPRangeRestriction;
import com.att.comet.restriction.dapn.DApnRestriction;
import com.att.comet.restriction.order.OrderRestriction;
import com.att.comet.restriction.order.OrderScheduleRestriction;
import com.att.comet.restriction.task.TaskApnNameRestriction;
import com.att.comet.restriction.task.TaskDateRestriction;
import com.att.comet.restriction.task.TaskExpediteRestriction;
import com.att.comet.restriction.task.TaskNameRestriction;
import com.att.comet.restriction.task.TaskOpenReminderRestriction;
import com.att.comet.restriction.task.TaskOrderApnIdRestriction;
import com.att.comet.restriction.task.TaskOwnerRestriction;
import com.att.comet.restriction.task.TaskRestriction;
import com.att.comet.restriction.task.TaskRoleRestriction;
import com.att.comet.restriction.task.TaskStatusCriteria;
import com.att.comet.restriction.task.TaskStatusRestriction;

@Component
public class GridCriteriaRenderer extends CriteriaRenderer {
	private static final Logger logger = LoggerFactory.getLogger(GridCriteriaRenderer.class);
	private static final String APN_NOT_CREATED_STRING = "APN name not created";

	@PersistenceContext
	EntityManager em;

	@Autowired
	BPMService bpmService;
	
	@Autowired
	BpmTaskRepository bpmTaskRepository;
	
	@Autowired
	OrderUserBpmTasksRepository orderUserBpmTasksRepository;
	
	@Autowired
	OrderTaskHelper orderTaskHelper;
	
	@Autowired
	UserHelper userHelper;

	@Override
	public ResultBO createExecuteQuery(SearchCriteria criteria) throws CometServiceException, CometDataException, ParseException {
		logger.info("Starting method createExecuteQueryt : ", this);

		ResultBO result = null;
		if (criteria.getRestrictions().size() > 0) {
			if (criteria.getRestrictions().get(0) instanceof OrderRestriction) {
				result = createExecuteQueryForOrder(criteria);
			} else if (criteria.getRestrictions().get(0) instanceof TaskRestriction) {
				result = createExecuteQueryForTask(criteria);
			} else if (criteria.getRestrictions().get(0) instanceof BackhaulRestriction) {
				result = createExecuteQueryForBackhaul(criteria);
			} else if (criteria.getRestrictions().get(0) instanceof DApnRestriction) {
				result = createExecuteQueryForDApn(criteria);
			} else if (criteria.getRestrictions().get(0) instanceof AllFieldReportRestriction) {
				result = createExecuteQueryForAllFieldReport(criteria);
			}
		}
		logger.info("Exiting method createExecuteQueryt : ", this);
		return result;
	}

	private ResultBO createExecuteQueryForOrder(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQueryForOrder : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();

		// Get Base query
		if (criteria.getBaseQuery().equals("BASE_QUERY_FOR_DC_CONSUMPTION_GRID")) {
			sql.append(ChartsSqlConstants.BASE_QUERY_FOR_DC_CONSUMPTION_GRID);
		} else {
			sql.append(ChartsSqlConstants.BASE_QUERY_FOR_GRID);
		}
		if (CommonUtils.isNullEmpty(sql.toString()))
			return null;
		for (Restriction res : criteria.getRestrictions()) {
			if (CommonUtils.isNotNullEmpty(res.toSqlString())) {
				sql.append(res.toSqlString());
			/*	if (res instanceof OrderScheduleRestriction) {
					sql.append(
							" AND obs.business_step_executed_on BETWEEN trunc(sysdate) + 1  AND trunc(sysdate) +11 ");
				}*/
			}
		}
		sql = createQueryFromOtherInfo(criteria, sql);
		if (criteria.getRestrictions().size() > 0) {
			sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
		}
		// Pagination code
		OtherDetails other = criteria.getOther();
		String temp = "";
		temp = "select * from ( select tab.*, rownum r from ( " + sql.toString() + ") tab where rownum <= "
				+ ((other.getPageNumber() == 1 || other.getPageNumber() == 0)
						? 1 * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())
						: (other.getPageNumber() * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())))
				+ " )" + "where r > " + ((other.getPageNumber() == 1 || other.getPageNumber() == 0) ? 0
						: ((other.getPageNumber() - 1) * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())));
		sql.delete(0, sql.length());
		sql.append(temp);

		result = executeQuery(sql.toString(), criteria);
		logger.info("Exiting method createExecuteQueryForOrder : ", this);
		return result;
	}

	/**
	 * Add other criteria to main query (user id, role id)
	 * 
	 * @param criteria
	 * @param sql
	 * @return StringBuilder
	 */
	private StringBuilder createQueryFromOtherInfo(SearchCriteria criteria, StringBuilder sql) {
		logger.info("Starting method createQueryFromOtherInfo : ", this);
		StringBuilder sqlQuery = new StringBuilder(sql);
		if (criteria.getOther() != null) {
			OtherDetails other = criteria.getOther();
			if (CommonUtils.isNotNullEmpty(other.getUserId())) {
				if (!other.getUserId().equals("Unassigned")) {
					sqlQuery.append("and oci.attuid  = '" + other.getUserId() + "' ");
				} else if (other.getUserId().equals("Unassigned")) {
					sqlQuery.append(" and oci.attuid IS NULL ");
				}
			}
			if (CommonUtils.isNotNullEmpty(other.getRoleId())) {
				String role = "";
				switch (other.getRoleId().intValue()) {
				case 1001:
					role = "1003,1023";
					break;
				case 1002:
					role = "1004";
					break;
				case 1003:
					role = "1005";
					break;
				case 1004:
					role = "1007";
					break;
				case 1005:
					role = "1006";
					break;
				case 1006:
					role = "";
					break;
				case 1007:
					role = "0";
					break;
				case 1008:
					role = "1024";
					break;
				default:
					role = "1003,1023";
					break;
				}
				if (CommonUtils.isNotNullEmpty(role)) {
					sqlQuery.append(" and oci.order_contact_type_id in (" + role + ") ");
				}
			}
		}
		logger.info("Exiting method createQueryFromOtherInfo : ", this);
		return sqlQuery;
	}

	/**
	 * Execute query for Grid
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			// sqlQuery.unwrap(NativeQuery.class).setResultSetMapping(name)(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SUB_ACCOUNT_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.APN_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_TYPE_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_STATUS_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_CREATED_ON, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.FLAG, IntegerType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			List<OrderListGridDisplayBO> orderList = new ArrayList<OrderListGridDisplayBO>();
			GridDisplayBO<OrderListGridDisplayBO> grdDisplayBO = new GridDisplayBO<OrderListGridDisplayBO>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			Map<String, Set<Long>> mapOfAPNNameAndOrderIdList = new HashMap<String, Set<Long>>();
			Map<Long, OrderListGridDisplayBO> mapOfOrderIdAndGridBO = new HashMap<Long, OrderListGridDisplayBO>();
			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					OrderListGridDisplayBO gridDisplayBO = new OrderListGridDisplayBO();

					resultMap = itr.next();

					columnObject = resultMap.get(ScalarConstants.ORDER_ID);
					if (null != columnObject) {
						gridDisplayBO.setOrderId(((Long) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.SUB_ACCOUNT_NAME);
					if (null != columnObject) {
						gridDisplayBO.setAccountName(CommonUtils.formatContentForGrid((String) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.APN_NAME);

					if (null != columnObject && !columnObject.toString().trim().isEmpty()
							&& !columnObject.toString().equals("N/A")) {
						gridDisplayBO.setApnName(columnObject.toString());
					} else {
						gridDisplayBO.setApnName(APN_NOT_CREATED_STRING);
					}

					columnObject = resultMap.get(ScalarConstants.ORDER_TYPE_NAME);
					if (null != columnObject) {
						gridDisplayBO.setOrderType((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_STATUS_NAME);
					if (null != columnObject) {
						gridDisplayBO.setOrderStatus((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_CREATED_ON);
					if (null != columnObject) {
						gridDisplayBO.setCreatedOn((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.FLAG);
					if (null != columnObject) {
						gridDisplayBO.setFlag((Integer) columnObject);
					}

					if (!mapOfAPNNameAndOrderIdList.containsKey(gridDisplayBO.getApnName())) {
						mapOfAPNNameAndOrderIdList.put(gridDisplayBO.getApnName(), new TreeSet<Long>());
					}

					mapOfAPNNameAndOrderIdList.get(gridDisplayBO.getApnName()).add(gridDisplayBO.getOrderId());
					mapOfOrderIdAndGridBO.put(gridDisplayBO.getOrderId(), gridDisplayBO);
				}
				String apnName = null;
				Set<Long> orderIds = null;
				for (Map.Entry<String, Set<Long>> entry : mapOfAPNNameAndOrderIdList.entrySet()) {
					apnName = entry.getKey();
					orderIds = entry.getValue();
					for (Long orderId : orderIds) {
						orderList.add(mapOfOrderIdAndGridBO.get(orderId));
						if (!apnName.equalsIgnoreCase(APN_NOT_CREATED_STRING)) {
							break;
						}
					}
				}
				grdDisplayBO.setLstGridBOs(orderList);
				objBO.setLstResult(grdDisplayBO);
				objBO.getOtherBO().setTitle("Order List");
				objBO.getOtherBO().setCurrentPage(criteria.getOther().getPageNumber());
				objBO.getOtherBO().setTotalRecord(orderList.size());
				objBO.getOtherBO().setTotalPages((int) Math.ceil((float) orderList.size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Starting method executeQuery : ", this);
		return objBO;
	}


	private ResultBO createExecuteQueryForBackhaul(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQueryForBackhaul : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();
		// Get Base query
		sql.append(criteria.getBaseQuery());
		if (CommonUtils.isNullEmpty(sql.toString()))
			return null;
		for (Restriction res : criteria.getRestrictions()) {
			if (res instanceof BackhaulRestriction && CommonUtils.isNotNullEmpty(res.toSqlString())) {
				sql.append(res.toSqlString());
			}
		}
		if (criteria.getBaseQuery().equals(OrderSqlConstant.BASE_QUERY_FOR_SHARED_BACKHAUL_ORDERS_GRID)) {
			String sharedOrders = "";
			sharedOrders = "SELECT * from (" + sql.toString() + " ) a WHERE NOT EXISTS (SELECT 1 FROM orders i"
					+ " WHERE a.order_id   = i.derived_from_order  AND i.order_status_id NOT IN (1003, 1023,1064,1066))";
			sql.delete(0, sql.length());
			sql.append(sharedOrders);
		}
		// Pagination code
		OtherDetails other = criteria.getOther();
		String temp = "";
		temp = "select * from ( select tab.*, rownum r from ( " + sql.toString() + ") tab where rownum <= "
				+ ((other.getPageNumber() == 1 || other.getPageNumber() == 0)
						? 1 * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())
						: (other.getPageNumber() * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())))
				+ " )" + "where r > " + ((other.getPageNumber() == 1 || other.getPageNumber() == 0) ? 0
						: ((other.getPageNumber() - 1) * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())));
		sql.delete(0, sql.length());
		sql.append(temp);
		if (criteria.getBaseQuery().equals(OrderSqlConstant.BASE_QUERY_FOR_BACKHAUL_SEARCH_GRID)) {
			sql.append(" order by backhaul_display_id ");
			result = executeBackhaulSearchQuery(sql.toString(), criteria);
			removeDuplicateBackhaulEntries(result);
		} else if (criteria.getBaseQuery().equals(OrderSqlConstant.BASE_QUERY_FOR_SHARED_BACKHAUL_ORDERS_GRID)) {
			sql.append(" order by order_id ");
			result = executeSharedBackhaulOrdersSearchQuery(sql.toString(), criteria);
			
		}
		logger.info("Exiting method createExecuteQueryForBackhaul : ", this);
		return result;
	}

	private ResultBO createExecuteQueryForDApn(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQueryForDApn : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();
		Restriction mobIPRangeRes = null;
		// Get Base query
		sql.append(OrderSqlConstant.BASE_QUERY_FOR_SEARCH_DAPN_GRID);
		if (CommonUtils.isNullEmpty(sql.toString()))
			return null;
		for (Restriction res : criteria.getRestrictions()) {
			if (res instanceof DApnMobileIPRangeRestriction) {
				mobIPRangeRes = res;
				continue;
			}
			if (res instanceof DApnRestriction && CommonUtils.isNotNullEmpty(res.toSqlString())) {
				sql.append(res.toSqlString());
			}
		}

		// Pagination code
		OtherDetails other = criteria.getOther();
		String temp = "";
		temp = "select * from ( select tab.*, rownum r from ( " + sql.toString() + ") tab where rownum <= "
				+ ((other.getPageNumber() == 1 || other.getPageNumber() == 0)
						? 1 * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())
						: (other.getPageNumber() * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())))
				+ " )" + "where r > " + ((other.getPageNumber() == 1 || other.getPageNumber() == 0) ? 0
						: ((other.getPageNumber() - 1) * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())));
		sql.delete(0, sql.length());
		sql.append(temp);
		if (criteria.getBaseQuery().equals("BASE_QUERY_FOR_SEARCH_DAPN_GRID")) {
			sql.append(" order by DAPN_ID ");
			result = executeDApnSearchQuery(sql.toString(), criteria);
		}
		if (mobIPRangeRes != null
				&& CommonUtils.isNotNullEmpty(((DApnMobileIPRangeRestriction) mobIPRangeRes).toSqlString())) {
			applyMobileIPRangeRestiction(result, mobIPRangeRes);
		}
		logger.info("Exiting method createExecuteQueryForDApn : ", this);
		return result;
	}

	private void applyMobileIPRangeRestiction(ResultBO result, Restriction mobIPRangeRes) {
		/// if (result != null && result.getLstResult() != null &&
		/// result.getLstResult().size() > 0) {
		logger.info("Starting method applyMobileIPRangeRestiction : ", this);
		if (result != null && result.getLstResult() != null) {
			String[] values = ((DApnMobileIPRangeRestriction) mobIPRangeRes).toSqlString().trim().split("_");
			MobilePoolRangeBO fromRangeBO = new MobilePoolRangeBO();
			fromRangeBO.setIpAddress(values[0]);
			MobilePoolRangeBO toRangeBO = new MobilePoolRangeBO();
			toRangeBO.setIpAddress(values[1]);
			getMobilePoolRange(fromRangeBO);
			getMobilePoolRange(toRangeBO);

			// List<DisplayResultBO> finalResult = new ArrayList<DisplayResultBO>();
			// for (DisplayResultBO resultBO : result.getLstResult()) {
			// if (resultBO instanceof DApnListGridDisplayBO) {
			// DApnListGridDisplayBO gridDisplayBO = (DApnListGridDisplayBO) resultBO;
			// MobilePoolRangeBO resultRangeBO = new MobilePoolRangeBO();
			// resultRangeBO.setIpAddress(gridDisplayBO.getMobileIp());
			// getMobilePoolRange(resultRangeBO);
			// if (fromRangeBO.getRangeStart() <= resultRangeBO.getRangeStart() &&
			// toRangeBO.getRangeEnd() >= resultRangeBO.getRangeEnd()) {
			// finalResult.add(resultBO);
			// }
			// }
			// }
			/// result.setLstResult(finalResult);
			logger.info("Exiting method applyMobileIPRangeRestiction : ", this);
		}
	}

	private void getMobilePoolRange(MobilePoolRangeBO rangeBO) {
		logger.info("Starting method getMobilePoolRange : ", this);
		if (CommonUtils.isNotNullEmpty(rangeBO.getIpAddress())) {

			int subnet;
			double rangeStart;
			double rangeEnd;
			String[] ipAdd;

			String temp[] = rangeBO.getIpAddress().split("/");
			rangeBO.setIpAddress(temp[0]);
			rangeBO.setSubnet(Integer.parseInt(temp[1]));

			ipAdd = rangeBO.getIpAddress().split("\\.");
			subnet = rangeBO.getSubnet();

			rangeStart = 0;
			for (int octet = 0, power = 3; octet <= 3; octet++, power--) {

				rangeStart += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));

			}
			rangeEnd = (rangeStart + Math.pow(2, (32 - subnet))) - 1;

			rangeBO.setRangeStart(rangeStart);
			rangeBO.setRangeEnd(rangeEnd);
			logger.info("Exiting method getMobilePoolRange : ", this);
		}
	}

	@SuppressWarnings("deprecation")
	private ResultBO executeBackhaulSearchQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeBackhaulSearchQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_BACKHAUL_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_BACKHAUL_TYPE_NAME,
					StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_BACKHAUL_TYPE_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_DATA_CENTER_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_DATA_CENTER_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_BACKHAUL_DISPLAY_ID,
					StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.BACKHAUL_STATUS, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.TUNNELTYPE_VPNNAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.CREATED_BY, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_CREATED_ON, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SHARED_APN, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_ID, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			List<BackhaulListGridDisplayBO> backhaulList = new ArrayList<BackhaulListGridDisplayBO>();
			GridDisplayBO<BackhaulListGridDisplayBO> grdDisplayBO = new GridDisplayBO<BackhaulListGridDisplayBO>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					BackhaulListGridDisplayBO gridDisplayBO = new BackhaulListGridDisplayBO();

					resultMap = itr.next();

					columnObject = resultMap.get(ScalarConstants.SEARCH_BACKHAUL_ID);
					if (null != columnObject) {
						gridDisplayBO.setBackhaulId(((Long) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_BACKHAUL_TYPE_NAME);
					if (null != columnObject) {
						gridDisplayBO.setBackhaulType(((String) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_BACKHAUL_TYPE_ID);
					if (null != columnObject) {
						gridDisplayBO.setBackhaulTypeId(((Long) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_DATA_CENTER_ID);
					if (null != columnObject) {
						gridDisplayBO.setDataCenterId((Long) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_DATA_CENTER_NAME);
					if (null != columnObject) {
						gridDisplayBO.setDataCenterName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_BACKHAUL_DISPLAY_ID);
					if (null != columnObject) {
						gridDisplayBO.setBackhaulDisplayId((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.BACKHAUL_STATUS);
					if (null != columnObject) {
						gridDisplayBO.setBackhaulStatus((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.TUNNELTYPE_VPNNAME);
					if (null != columnObject) {
						gridDisplayBO.setTunnelTypeVpnName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.CREATED_BY);
					if (null != columnObject) {
						gridDisplayBO.setCreatedBy((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_CREATED_ON);
					if (null != columnObject) {
						gridDisplayBO.setCreatedOn((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SHARED_APN);
					if (null != columnObject) {
						gridDisplayBO.setSharedApn((String) columnObject);
					}

					columnObject = resultMap.get(ScalarConstants.ORDER_ID);
					if (null != columnObject) {
						gridDisplayBO.setOrderId((String) columnObject);
					}
					backhaulList.add(gridDisplayBO);
				}
				grdDisplayBO.setLstGridBOs(backhaulList);
				objBO.setLstResult(grdDisplayBO);
				objBO.getOtherBO().setTitle("Backhaul List");
				objBO.getOtherBO().setCurrentPage(criteria.getOther().getPageNumber());
				objBO.getOtherBO().setTotalRecord(backhaulList.size());
				objBO.getOtherBO().setTotalPages((int) Math.ceil((float) backhaulList.size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			logger.error(e.getMessage());
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeBackhaulSearchQuery : ", this);
		return objBO;
	}

	@SuppressWarnings("deprecation")
	private ResultBO executeSharedBackhaulOrdersSearchQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeSharedBackhaulOrdersSearchQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.APN_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_TYPE_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_STATUS_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.PDP_ID, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.PDP_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.DOMAIN_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_SUBMITTER, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			List<OrderApnListGridDisplayBO> orderApnList = new ArrayList<OrderApnListGridDisplayBO>();
			GridDisplayBO<OrderApnListGridDisplayBO> grdDisplayBO = new GridDisplayBO<OrderApnListGridDisplayBO>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					OrderApnListGridDisplayBO gridDisplayBO = new OrderApnListGridDisplayBO();

					resultMap = itr.next();

					columnObject = resultMap.get(ScalarConstants.ORDER_ID);
					if (null != columnObject) {
						gridDisplayBO.setOrderId(((Long) columnObject));
					}

					columnObject = resultMap.get(ScalarConstants.APN_NAME);
					if (null != columnObject) {
						gridDisplayBO.setApnName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_TYPE_NAME);
					if (null != columnObject) {
						gridDisplayBO.setOrderType((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_STATUS_NAME);
					if (null != columnObject) {
						gridDisplayBO.setOrderStatus((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.PDP_ID);
					if (null != columnObject) {
						gridDisplayBO.setPdpId((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.PDP_NAME);
					if (null != columnObject) {
						gridDisplayBO.setPdpName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.DOMAIN_NAME);
					if (null != columnObject) {
						gridDisplayBO.setCustOwnedDomainName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_SUBMITTER);
					if (null != columnObject) {
						gridDisplayBO.setOrderSubmitter((String) columnObject);
					}
					orderApnList.add(gridDisplayBO);
				}
				grdDisplayBO.setLstGridBOs(orderApnList);
				objBO.setLstResult(grdDisplayBO);
				objBO.getOtherBO().setTitle("Order Apn List");
				objBO.getOtherBO().setCurrentPage(criteria.getOther().getPageNumber());
				objBO.getOtherBO().setTotalRecord(orderApnList.size());
				objBO.getOtherBO().setTotalPages((int) Math.ceil((float) orderApnList.size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			logger.error(e.getMessage());
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeSharedBackhaulOrdersSearchQuery : ", this);
		return objBO;
	}

	@SuppressWarnings("deprecation")
	private ResultBO executeDApnSearchQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeDApnSearchQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.DAPN_ID, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.DAPN_STATUS, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.APN_TYPE, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.APN_SIZE, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.APN_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.PDP_NAME, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.PDP_ID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.UD_PDPID, LongType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.MOBILE_IP, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_DAPN_DATA_CENTER_NAME,
					StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.CREATED_BY, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.SEARCH_CREATED_ON, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.ORDER_ID, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.BATCH_ID, StringType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			List<DApnListGridDisplayBO> dapnList = new ArrayList<DApnListGridDisplayBO>();
			GridDisplayBO<DApnListGridDisplayBO> grdDisplayBO = new GridDisplayBO<DApnListGridDisplayBO>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					DApnListGridDisplayBO gridDisplayBO = new DApnListGridDisplayBO();

					resultMap = itr.next();

					columnObject = resultMap.get(ScalarConstants.DAPN_ID);
					if (null != columnObject) {
						gridDisplayBO.setDapnId(((String) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.DAPN_STATUS);
					if (null != columnObject) {
						gridDisplayBO.setDapnStatus(((String) columnObject));
					}
					columnObject = resultMap.get(ScalarConstants.APN_TYPE);
					if (null != columnObject) {
						gridDisplayBO.setApnType((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.APN_SIZE);
					if (null != columnObject) {
						gridDisplayBO.setApnSize((Long) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.APN_NAME);
					if (null != columnObject) {
						gridDisplayBO.setApnName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.PDP_NAME);
					if (null != columnObject) {
						gridDisplayBO.setPdpName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.PDP_ID);
					if (null != columnObject) {
						gridDisplayBO.setPdpId((Long) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.UD_PDPID);
					if (null != columnObject) {
						gridDisplayBO.setUdpdpId((Long) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.MOBILE_IP);
					if (null != columnObject) {
						gridDisplayBO.setMobileIp((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_DAPN_DATA_CENTER_NAME);
					if (null != columnObject) {
						gridDisplayBO.setDataCenter((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.CREATED_BY);
					if (null != columnObject) {
						gridDisplayBO.setCreatedBy((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.SEARCH_CREATED_ON);
					if (null != columnObject) {
						gridDisplayBO.setCreatedOn((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_ID);
					if (null != columnObject) {
						gridDisplayBO.setOrderId((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.BATCH_ID);
					if (null != columnObject) {
						gridDisplayBO.setBatchId((String) columnObject);
					}
					dapnList.add(gridDisplayBO);
				}

				grdDisplayBO.setLstGridBOs(dapnList);
				objBO.setLstResult(grdDisplayBO);
				objBO.getOtherBO().setTitle("DApn List");
				objBO.getOtherBO().setCurrentPage(criteria.getOther().getPageNumber());
				objBO.getOtherBO().setTotalRecord(dapnList.size());
				objBO.getOtherBO().setTotalPages((int) Math.ceil((float) dapnList.size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			logger.error(e.getMessage());
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeDApnSearchQuery : ", this);
		return objBO;
	}

	/**
	 * This method returns the base query
	 * 
	 * @param criteria
	 * @return base query
	 */
	private String getBaseQuery(SearchCriteria criteria) {
		return null;
		/// return session.getNamedQuery(criteria.getBaseQuery()).getQueryString() + "
		/// ";
	}

	private void removeDuplicateBackhaulEntries(ResultBO result) {
		logger.info("Starting method removeDuplicateBackhaulEntries : ", this);
		if (result != null && result.getLstResult() != null) {
			DisplayResultBO lstResult = result.getLstResult();
			if (lstResult instanceof GridDisplayBO) {
				@SuppressWarnings("unchecked")
				GridDisplayBO<BackhaulListGridDisplayBO> bGridDisplayBO = (GridDisplayBO<BackhaulListGridDisplayBO>) lstResult;
				List<BackhaulListGridDisplayBO> noDupResult = new ArrayList<BackhaulListGridDisplayBO>();
				int counter = 0;
				for (BackhaulListGridDisplayBO backhaulGridDisplayBO : bGridDisplayBO.getLstGridBOs()) {
					// If no element present in no duplicate list then directly add element
					if (noDupResult.size() == 0) {
						noDupResult.add(backhaulGridDisplayBO);
					} else {
						BackhaulListGridDisplayBO noDupRecord = (BackhaulListGridDisplayBO) noDupResult.get(counter);
						// If backhauls are same go for next conditions
						// else add backhaul directly to no duplicate list
						if (backhaulGridDisplayBO.getBackhaulDisplayId()
								.compareToIgnoreCase(noDupRecord.getBackhaulDisplayId()) == 0) {
							// In Production status Backhaul will get priority against In Progress
							// If both backhauls are In Production or In Progress, old backhaul will get
							// priority
							if (backhaulGridDisplayBO.getBackhaulStatus().equals("IN_PRODUCTION")
									&& noDupRecord.getBackhaulDisplayId().equals("IN_PROGRESS")) {
								noDupResult.add(counter, backhaulGridDisplayBO);
								counter++;
							} else if (backhaulGridDisplayBO.getBackhaulStatus().equals("IN_PROGRESS")
									&& noDupRecord.getBackhaulDisplayId().equals("IN_PRODUCTION")) {
								continue;
							} else if (backhaulGridDisplayBO.getBackhaulStatus().equals("IN_PRODUCTION")
									&& noDupRecord.getBackhaulDisplayId().equals("IN_PRODUCTION")) {
								if (backhaulGridDisplayBO.getBackhaulId() < noDupRecord.getBackhaulId()) {
									noDupResult.add(counter, backhaulGridDisplayBO);
									counter++;
								} else {
									continue;
								}
							} else if (backhaulGridDisplayBO.getBackhaulStatus().equals("IN_PROGRESS")
									&& noDupRecord.getBackhaulDisplayId().equals("IN_PROGRESS")) {
								if (backhaulGridDisplayBO.getBackhaulId() < noDupRecord.getBackhaulId()) {
									noDupResult.add(counter, backhaulGridDisplayBO);
									counter++;
								} else {
									continue;
								}
							}
						} else {
							noDupResult.add(backhaulGridDisplayBO);
							counter++;
						}
					}
				}
				bGridDisplayBO.setLstGridBOs(noDupResult);
				logger.info("Exiting method removeDuplicateBackhaulEntries : ", this);
				result.setLstResult(bGridDisplayBO);
			}
		}
	}

	private ResultBO createExecuteQueryForAllFieldReport(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQueryForAllFieldReport : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();

		// Get Base query
		sql.append(getBaseQuery(criteria));
		if (CommonUtils.isNullEmpty(sql.toString()))
			return null;
		boolean whereFlag = true;
		for (Restriction res : criteria.getRestrictions()) {
			String tempSQL = res.toSqlString();
			if (CommonUtils.isNotNullEmpty(tempSQL)) {
				if (whereFlag) {
					sql.append(" where ");
					whereFlag = false;
				} else {
					sql.append(" and ");
				}
				sql.append(tempSQL);
			}
		}
		if (criteria.getRestrictions().size() > 0) {
			sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
		}
		// Pagination code
		OtherDetails other = criteria.getOther();
		String temp = "";
		temp = "select * from ( select tab.*, rownum r from ( " + sql.toString() + ") tab where rownum <= "
				+ ((other.getPageNumber() == 1 || other.getPageNumber() == 0)
						? 1 * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())
						: (other.getPageNumber() * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())))
				+ " )" + "where r > " + ((other.getPageNumber() == 1 || other.getPageNumber() == 0) ? 0
						: ((other.getPageNumber() - 1) * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())));
		sql.delete(0, sql.length());
		sql.append(temp);

		result = executeAllFieldResultQuery(sql.toString(), criteria);
		logger.info("Exiting method createExecuteQueryForAllFieldReport : ", this);
		return result;
	}

	@SuppressWarnings("deprecation")
	private ResultBO executeAllFieldResultQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeAllFieldResultQuery : ", this);
		ResultBO objBO = null;
		try {
			OrderAllFieldsReportDisplayBO responseBO = null;
			Map<String, Object> bindingMap = new HashMap<String, Object>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			// Orders All field Report Query.
			@SuppressWarnings("rawtypes")
			SQLQuery sqlQuery = null;
			/// SQLQuery sqlQuery = session.createSQLQuery(sql);
			/// ServiceUtils.setQueryParameters(sqlQuery, bindingMap);

			sqlQuery.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> reportResult = sqlQuery.list();

			if (reportResult != null && reportResult.size() > 0) {

				objBO = new ResultBO();
				// reportBOs = new ArrayList<OrderAllFieldsReportBO>();
				Iterator<Map<String, Object>> iterator = reportResult.iterator();
				while (iterator.hasNext()) {

					responseBO = new OrderAllFieldsReportDisplayBO();
					resultMap = iterator.next();

					// Setter of Order ID
					columnObject = resultMap.get("ORDER_ID");
					if (columnObject != null) {
						responseBO.setOrderId(((BigDecimal) columnObject).longValue());
					}

					// Setter of Order Type
					columnObject = resultMap.get("ORDER_TYPE");
					if (columnObject != null) {
						responseBO.setOrderType((String) columnObject);
					}

					// Setter of Order Status
					columnObject = resultMap.get("ORDER_STATUS");
					if (columnObject != null) {
						responseBO.setOrderStatus((String) columnObject);
					}

					// Setter of Ref. Order ID
					columnObject = resultMap.get("REF_ORDER_ID");
					if (columnObject != null) {
						responseBO.setReferenceOrderId(((BigDecimal) columnObject).toString());
					}

					// Setter of Expedite
					columnObject = resultMap.get("EXPEDITE");
					if (columnObject != null) {
						responseBO.setExpedite((String) columnObject);
					}

					// Setter of Express
					columnObject = resultMap.get("EXPRESS");
					if (columnObject != null) {
						responseBO.setExpress(((Character) columnObject).toString());
					}

					// Setter of Account Class
					columnObject = resultMap.get("ACCOUNT_CLASS");
					if (columnObject != null) {
						responseBO.setAccountClass((String) columnObject);
					}

					// Setter of Master Account Name
					columnObject = resultMap.get("MASTER_ACCOUNT_NAME");
					if (columnObject != null) {
						responseBO.setMasterAccountName((String) columnObject);
					}

					// Setter of Sub Account Name
					columnObject = resultMap.get("ACCOUNT_NAME");
					if (columnObject != null) {
						responseBO.setSubAccountName((String) columnObject);
					}

					// Setter of Fee Waiver Account
					columnObject = resultMap.get("FEE_WAIVER_ACCOUNT");
					if (columnObject != null) {
						responseBO.setFeeWaiverAccount((String) columnObject);
					}

					// Setter of Fee Waiver Order
					columnObject = resultMap.get("FEE_WAIVER_ORDER");
					if (columnObject != null) {
						responseBO.setFeeWaiverOrder((String) columnObject);
					}

					// Setter of Fee Waiver Approved MRC
					columnObject = resultMap.get("FEE_WAIVER_APPROVED_MRC");
					if (columnObject != null) {
						responseBO.setFeeWaiverApprovedMRC((String) columnObject);
					}

					// Setter of TSP
					columnObject = resultMap.get("TSP");
					if (columnObject != null) {
						responseBO.setTsp((String) columnObject);
					}

					// Setter of APN Name
					columnObject = resultMap.get("APN_NAME");
					if (columnObject != null) {
						responseBO.setApnName((String) columnObject);
					}

					// Setter of APN Status
					columnObject = resultMap.get("APN_STATUS");
					if (columnObject != null) {
						responseBO.setApnStatus((String) columnObject);
					}

					// Setter of OCS
					columnObject = resultMap.get("OCS");
					if (columnObject != null) {
						responseBO.setOcs((String) columnObject);
					}

					// Setter of PDP ID
					columnObject = resultMap.get("PDP_ID");
					if (columnObject != null) {
						responseBO.setPdpId((String) columnObject);
					}

					// Setter of PDP Name
					columnObject = resultMap.get("PDP_NAME");
					if (columnObject != null) {
						responseBO.setPdpName((String) columnObject);
					}

					// Setter of Managed AVPN
					columnObject = resultMap.get("MANAGED_AVPN");
					if (columnObject != null) {
						responseBO.setManagedAvpn((String) columnObject);
					}

					// Setter of ATT Radius
					columnObject = resultMap.get("ATT_RADIUS");
					if (columnObject != null) {
						responseBO.setAttRadius((String) columnObject);
					}

					// Setter of ATT Radius
					columnObject = resultMap.get("MOBILE_TO_MOBILE");
					if (columnObject != null) {
						responseBO.setMobileToMobile((String) columnObject);
					}

					// Setter of MT
					columnObject = resultMap.get("MOBILE_TERMINATED");
					if (columnObject != null) {
						responseBO.setMobileTerminated((String) columnObject);
					}

					// Setter of MT
					columnObject = resultMap.get("MOBILE_ORIGINATE");
					if (columnObject != null) {
						responseBO.setMobileOriginate((String) columnObject);
					}

					// Setter of EOD
					columnObject = resultMap.get("EOD");
					if (columnObject != null) {
						responseBO.setEod((String) columnObject);
					}

					// Setter of Internet Access
					columnObject = resultMap.get("SPLIT_TUNNEL_INTERNET_ACCESS");
					if (columnObject != null) {
						responseBO.setSplitTunnelInternetAccess((String) columnObject);
					}

					// Setter of MT Enabled
					columnObject = resultMap.get("SPLIT_TUNNEL_MT_ACCESS");
					if (columnObject != null) {
						responseBO.setMobileTerminatedSplitTunnel((String) columnObject);
					}

					// Setter of Source Of IP Addressing
					columnObject = resultMap.get("IP_ADDRESS_SOURCE");
					if (columnObject != null) {
						responseBO.setSourceOfIpAddressing((String) columnObject);
					}

					// Setter of Mobile Pool Type
					columnObject = resultMap.get("MOBILE_POOL_TYPE");
					if (columnObject != null) {
						responseBO.setMobilePoolType((String) columnObject);
					}

					// Setter of Type of Addressing
					columnObject = resultMap.get("ADDRESS_TYPE");
					if (columnObject != null) {
						responseBO.setAddressingType((String) columnObject);
					}

					// Setter of IPPT/Customer Hosted Radius
					columnObject = resultMap.get("IPPT_CUST_RADIUS");
					if (columnObject != null) {
						responseBO.setIpptCustommerHostedRadius((String) columnObject);
					}

					// Setter of Enterprise Target IP Range
					columnObject = resultMap.get("ENT_TARGET_IP_RANGE");
					if (columnObject != null) {
						responseBO.setEnterpriseTargetIpRange((String) columnObject);
					}

					// Setter of Mobile Pool Address in Each DC
					columnObject = resultMap.get("MOBILE_POOL_ADDRESS");
					if (columnObject != null) {
						responseBO.setMobilePoolAddress((String) columnObject);
					}

					// Setter of FAN
					columnObject = resultMap.get("FAN_ID");
					if (columnObject != null) {
						responseBO.setFanId((String) columnObject);
					}

					// Setter of BAN
					columnObject = resultMap.get("BAN_ID");
					if (columnObject != null) {
						responseBO.setBanId((String) columnObject);
					}

					// Setter of EOD_BLU
					columnObject = resultMap.get("EOD_BLU");
					if (columnObject != null) {
						responseBO.setEodBlu((String) columnObject);
					}

					// Setter of Market Segment
					columnObject = resultMap.get("MARKET_SEGMENT");
					if (columnObject != null) {
						responseBO.setMarketSegment((String) columnObject);
					}

					// Setter of Order Submitter
					columnObject = resultMap.get("OS");
					if (columnObject != null) {
						responseBO.setOrderSubmitter((String) columnObject);
					}

					// Setter of OSD
					columnObject = resultMap.get("OSD");
					if (columnObject != null) {
						responseBO.setOsd((String) columnObject);
					}

					// Setter of OA
					columnObject = resultMap.get("OA");
					if (columnObject != null) {
						responseBO.setOrderApprover((String) columnObject);
					}

					// Setter of OM
					columnObject = resultMap.get("OM");
					if (columnObject != null) {
						responseBO.setOrderManager((String) columnObject);
					}

					// Setter of CCSPM
					columnObject = resultMap.get("CCSPM");
					if (columnObject != null) {
						responseBO.setCcspm((String) columnObject);
					}

					// Setter of Netwrok Implementor.
					columnObject = resultMap.get("NI");
					if (columnObject != null) {
						responseBO.setNetworkImplementor((String) columnObject);
					}

					// Setter of IT_OPS.
					columnObject = resultMap.get("ITOPS");
					if (columnObject != null) {
						responseBO.setItOps((String) columnObject);
					}

					// Setter of GEO.
					columnObject = resultMap.get("GEO");
					if (columnObject != null) {
						responseBO.setGeoRedundant(String.valueOf(((Character) columnObject)));
					}

					// Setter of Active /Passive.
					columnObject = resultMap.get("ACTIVE_PASSIVE");
					if (columnObject != null) {
						responseBO.setActivePassive((String) columnObject);
					}

					// Setter of Data Center.
					columnObject = resultMap.get("DATA_CENTERS");
					if (columnObject != null) {
						responseBO.setDataCenters((String) columnObject);
					}

					// Setter of Types of Back-hauls.
					columnObject = resultMap.get("BACKHAUL_TYPES");
					if (columnObject != null) {
						responseBO.setBackhaulType((String) columnObject);
					}

					// Setter of Tunnel Type.
					columnObject = resultMap.get("TUNNEL_TYPE");
					if (columnObject != null) {
						responseBO.setTunnelType((String) columnObject);
					}

					// Setter of VTI.
					columnObject = resultMap.get("VTI");
					if (columnObject != null) {
						responseBO.setVti((String) columnObject);
					}

					// Setter of Routing Protocol
					columnObject = resultMap.get("ROUTING_PROTOCOL");
					if (columnObject != null) {
						responseBO.setRoutingProtocol((String) columnObject);
					}

					// Setter of Restrictive Routing.
					columnObject = resultMap.get("RESTRICTIVE_ROUTING");
					if (columnObject != null) {
						responseBO.setRestrictiveRouting((String) columnObject);
					}

					// Setter of Circuit Speed.
					columnObject = resultMap.get("CIR_SPEED");
					if (columnObject != null) {
						responseBO.setCirSpeed((String) columnObject);
					}

					// Setter of Strict TCP.
					columnObject = resultMap.get("STRICT_TCP");
					if (columnObject != null) {
						responseBO.setStrictTcp((String) columnObject);
					}

					// Setter of Date Submitted.
					columnObject = resultMap.get("DATE_SUBMITTED");
					if (columnObject != null) {
						responseBO.setDateSubmitted((String) columnObject);
					}

					// Setter of Date OA Approved.
					columnObject = resultMap.get("DATE_OA_APPROVED");
					if (columnObject != null) {
						responseBO.setApprovedByOrderApprover((String) columnObject);
					}

					// Setter of Date OM Approved.
					columnObject = resultMap.get("DATE_OM_APPROVED");
					if (columnObject != null) {
						responseBO.setApprovedByOrderManager((String) columnObject);
					}

					// Setter of Date OSD Approved.
					columnObject = resultMap.get("DATE_OSD_APPROVED");
					if (columnObject != null) {
						responseBO.setApprovedByOsd((String) columnObject);
					}

					// Setter of Date HLR/HSS Complete.
					columnObject = resultMap.get("DATE_HLR_HSS_COMPLETE");
					if (columnObject != null) {
						responseBO.setHlrHssCompleteionDate((String) columnObject);
					}

					// Setter of Date NI IWOS Creation.
					columnObject = resultMap.get("DATE_NI_IWOS_CREATION");
					if (columnObject != null) {
						responseBO.setNiIWOSCreationDate((String) columnObject);
					}

					// Setter of Date APN Build IWOS COmplete.
					columnObject = resultMap.get("DATE_IWOS_COMPLETE");
					if (columnObject != null) {
						responseBO.setApnBuildIwosCompeteDate((String) columnObject);
					}

					// Setter of Date Billing Complete.
					columnObject = resultMap.get("DATE_BILLING_COMPLETE");
					if (columnObject != null) {
						responseBO.setBillingCompleteDate((String) columnObject);
					}

					// Setter of Date IT OPS Complete.
					columnObject = resultMap.get("DATE_ITOPS_COMPLETE");
					if (columnObject != null) {
						responseBO.setItOpsCompleteDate((String) columnObject);
					}

					// Setter of Date DashBoard Complete.
					columnObject = resultMap.get("DATE_DASHBOARD_COMPLETE");
					if (columnObject != null) {
						responseBO.setDashBoardCompleteDate((String) columnObject);
					}

					// Setter of Date CCS PM Order Update Complete.
					columnObject = resultMap.get("DATE_CCSPM_UPDATE_COMPLETE");
					if (columnObject != null) {
						responseBO.setCcspmOrderUpdateCompleteDate((String) columnObject);
					}

					// Setter of Date NI Order Update Complete.
					columnObject = resultMap.get("DATE_NI_ORDER_UPDATE_COMPLETE");
					if (columnObject != null) {
						responseBO.setNiOrderUpdateComplete((String) columnObject);
					}

					// Setter of TTU Required.
					columnObject = resultMap.get("TTU_REQUIRED");
					if (columnObject != null) {
						responseBO.setTtuRequired((String) columnObject);
					}

					// Setter of On Hold.
					columnObject = resultMap.get("ON_HOLD");
					if (columnObject != null) {
						responseBO.setOnHoldStatus(((Character) columnObject).toString());
					} else {
						responseBO.setOnHoldStatus("N");
					}

					// Setter of Days on hold.
					columnObject = resultMap.get("DAYS_ON_HOLD");
					if (columnObject != null) {
						responseBO.setDaysOnHold(((BigDecimal) columnObject).longValue());
					} else {
						responseBO.setDaysOnHold(0L);
					}

					// Setter of TTU Schedule.
					columnObject = resultMap.get("TTU_SCHEDULE_DATE");
					if (columnObject != null) {
						responseBO.setTtuScheduleDate((String) columnObject);
					}

					// Setter of APN Date In Production.
					columnObject = resultMap.get("DATE_APN_IN_PRODUCTION");
					if (columnObject != null) {
						responseBO.setApnInProductionDate((String) columnObject);
					}

					// Setter of Date In Production.
					columnObject = resultMap.get("DATE_IN_PRODUCTION");
					if (columnObject != null) {
						responseBO.setInProductionDate((String) columnObject);
					}

					// Setter of LTE Sweep.
					columnObject = resultMap.get("LTE_SWEEP");
					if (columnObject != null) {
						responseBO.setLteSweep((String) columnObject);
					}

					// Setter of IPBR.
					columnObject = resultMap.get("IPBR");
					if (columnObject != null) {
						responseBO.setIpbrFlag((String) columnObject);
					}
					// Setter of Order Status
					columnObject = resultMap.get("MSP");
					if (columnObject != null) {
						responseBO.setMsp((String) columnObject);

					}

					// Setter of MSP_ENTITLEMENT_AND_MMS
					columnObject = resultMap.get("MSP_ENTITLEMENT_AND_MMS");
					if (columnObject != null) {
						responseBO.setMspEntAndMms((String) columnObject);

					}

					// Setter of PCRF.
					columnObject = resultMap.get("PCRF");
					if (columnObject != null) {
						responseBO.setPcrf((String) columnObject);
					}

					// Setter of SPLIT ACCESS PAT.
					columnObject = resultMap.get("SPLIT_ACCESS_PAT");
					if (columnObject != null) {
						responseBO.setSplitAccessPAT((String) columnObject);
					}

					// Setter of INTERNET TARGET IP RANGES.
					columnObject = resultMap.get("INT_TARGET_IP_RANGE");
					if (columnObject != null) {
						responseBO.setIntTargetIpRanges((String) columnObject);
					}

					// Setter of ENT TARGET IP RANGE ROUTE.
					columnObject = resultMap.get("ENT_TARGET_IP_RANGE_ROUTE");
					if (columnObject != null) {
						responseBO.setEnterpriseTargetIpRangeRoute((String) columnObject);
					}

					// Setter of GEO OPTIMIZATION.
					columnObject = resultMap.get("GEO_OPTIMIZATION");
					if (columnObject != null) {
						responseBO.setGeoOptimization((String) columnObject);
					}

					// Setter of PAT POOL RANGE.
					columnObject = resultMap.get("PAT_POOL_RANGE");
					if (columnObject != null) {
						responseBO.setPatPoolRange((String) columnObject);
					}

					// Setter of CCIP_RADIUS.
					columnObject = resultMap.get("CCIP_RADIUS");
					if (columnObject != null) {
						responseBO.setCcipRadius((String) columnObject);
					}

					// Setter of MIGRATED ORDER.
					columnObject = resultMap.get("MIGRATED_ORDER");
					if (columnObject != null) {
						responseBO.setMigratedOrder((String) columnObject);
					}

					// Setter of INTERNET VPN ENDPOINT.
					columnObject = resultMap.get("INTERNET_VPN_ENDPOINT");
					if (columnObject != null) {
						responseBO.setInternetVpnEndpoint((String) columnObject);
					}

					// Setter of CCS ROUTER BASE RD.
					columnObject = resultMap.get("CCS_ROUTER_BASE_RD");
					if (columnObject != null) {
						responseBO.setCcsRouterBaseRd(((BigDecimal) columnObject).longValue());
					}

					// Setter of VRF NAME
					columnObject = resultMap.get("VRF_NAME");
					if (columnObject != null) {
						responseBO.setVrfName((String) columnObject);
					}

					// Setter of VLAN_GI
					columnObject = resultMap.get("VLAN_GI");
					if (columnObject != null) {
						responseBO.setVlanGi((String) columnObject);
					}

					// Setter of Interface Tunnel Num
					columnObject = resultMap.get("INTERFACE_TUNNEL_NUM");
					if (columnObject != null) {
						responseBO.setInterfaceTunnelNum(((String) columnObject));
					}

					// Setter of CRYPTO_VLAN_ID
					columnObject = resultMap.get("CRYPTO_VLAN_ID");
					if (columnObject != null) {
						responseBO.setCryptoVlanId((String) columnObject);
					}

					// Setter of APN_TYPE
					columnObject = resultMap.get("APN_TYPE");
					if (columnObject != null) {
						responseBO.setApnType((String) columnObject);
					}

					// Setter of FIRST NET
					columnObject = resultMap.get("FIRST_NET");
					if (columnObject != null) {
						responseBO.setFirstNet((String) columnObject);
					}

					// Setter of TURBO APPLICATION SUPPORT
					columnObject = resultMap.get("TURBO_APP_SUPPORT");
					if (columnObject != null) {
						responseBO.setTurboAppSupport((String) columnObject);
					}

					// Setter of DSCP PRESERVATION
					columnObject = resultMap.get("DSCP_PRESERVATION");
					if (columnObject != null) {
						responseBO.setDscpPreservation((String) columnObject);
					}

					// Setter of DSCP PRESERVATION
					columnObject = resultMap.get("ISAMP");
					if (columnObject != null) {
						responseBO.setIsAmp(Character.toString((Character) columnObject));
					}

					// Setter of CCS MX
					columnObject = resultMap.get("CCS_MX");
					if (columnObject != null) {
						responseBO.setCcsMx((String) columnObject);
					}
					// Req#6.2.01 sp3599
					columnObject = resultMap.get("FIRSTNET_EPC");
					if (columnObject != null) {
						responseBO.setFirstNetEpc((String) columnObject);
					}

					columnObject = resultMap.get("CRD_ROW_ENABLE");
					if (columnObject != null) {
						responseBO.setCrdRow4((String) columnObject);
					}
					// Setter of ACCA HEALTHCHECK
					columnObject = resultMap.get("ACCA_HEALTH_CHECK_ENABLE");
					if (columnObject != null) {
						responseBO.setAccaHealthCheckEnable((String) columnObject);
					}
					// setter for number_of_change_request

					columnObject = resultMap.get("NUMBER_OF_CHANGE_REQUESTS");
					if (columnObject != null) {
						responseBO.setNumberOfChangeRequests(((BigDecimal) columnObject).longValue());
					}

					/// objBO.getLstResult().add(responseBO);
				}
				if (criteria.getOther() != null && CommonUtils.isNotNullEmpty(criteria.getOther().getUserId())) {
					/// fetchAndUpdateBillingTaskBO(objBO, criteria.getOther().getUserId());
				}

				objBO.getOtherBO().setTitle("All Field Report List");
				/// objBO.getOtherBO().setCurrentpage(criteria.getOther().getPageNumber());
				/// objBO.getOtherBO().setTotalRecord(objBO.getLstResult().size());
				/// objBO.getOtherBO().setTotalpages((int) Math.ceil((float)
				/// objBO.getLstResult().size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			logger.error(e.getMessage());
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeAllFieldResultQuery : ", this);
		return objBO;
	}
	
	
	private ResultBO createExecuteQueryForTask(SearchCriteria criteria) throws ParseException {
		logger.info("Starting method createExecuteQueryForOrder : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();
		sql.append(criteria.getBaseQuery());
		TaskListRequestBO requestBO = new TaskListRequestBO();
		if (CommonUtils.isNullEmpty(sql.toString()))
			return null;
		boolean whereFlag = true;
		for (Restriction res : criteria.getRestrictions()) {
			String tempSQL = res.toSqlString();
			if (CommonUtils.isNotNullEmpty(tempSQL)) {
				if (whereFlag) {
					sql.append(" where ");
					if (res instanceof TaskOrderApnIdRestriction) {
						requestBO.setProcessInstanceBusinessKey(res.toSqlString());
						sql.append("order_id = "+requestBO.getProcessInstanceBusinessKey()+" ");
					}
					if (res instanceof TaskApnNameRestriction) {
						requestBO.setTaskAssignee(res.toSqlString());
						sql.append("apn_name = \'"+requestBO.getTaskAssignee()+ "\'");
					}
					if (res instanceof TaskOwnerRestriction) {
						requestBO.setTaskAssignee(res.toSqlString());
						sql.append("attuid = \'"+requestBO.getTaskAssignee()+ "\'");
					}
					if (res instanceof TaskNameRestriction) {
						requestBO.setTaskName(res.toSqlString());
						sql.append("task_id = "+requestBO.getTaskName()+" ");
					}
					if (res instanceof TaskExpediteRestriction) {
						if(res.toSqlString().equalsIgnoreCase("false")) {
							sql.append("expedite = 'N'");
						}else {
							sql.append("expedite = 'Y'");
						}
					}
					if (res instanceof TaskOpenReminderRestriction) {
						if(res.toSqlString().equalsIgnoreCase("N")) {
							sql.append("open_reminder = 'N'");
						}else {
							sql.append("open_reminder = 'Y'");
						}
					}
					if (res instanceof TaskRoleRestriction) {
						sql.append("role_id = "+res.toSqlString()+" ");
					}
					if (res instanceof TaskStatusCriteria) {
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.ASSIGNED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and attuid IS NOT NULL");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.UNCLAIMED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and attuid IS NULL");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.COMPLETED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and task_status_id = 1002");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.OPEN)) {
							sql.append("task_category_id = 1002");
							sql.append(" and task_status_id = 1001");
						}
					}
					if (res instanceof TaskDateRestriction) {
						String taskDate = res.toSqlString().toString();
						String[] dateList = taskDate.split(",");        
						String fromDate = dateList [0];
					    fromDate = dateFormatting(fromDate);
						String toDate =  dateList [1];
						toDate = dateFormatting(toDate);
						sql.append("(trunc(creation_date) BETWEEN to_date(\'"+fromDate+"\') and to_date(\'"+toDate+"\'))");
					}
					whereFlag = false;
				} else {
					sql.append(" and ");
					if (res instanceof TaskOwnerRestriction) {
						requestBO.setTaskAssignee(res.toSqlString());
						sql.append("attuid = \'"+requestBO.getTaskAssignee()+ "\'");
					}
					if (res instanceof TaskOrderApnIdRestriction) {
						requestBO.setProcessInstanceBusinessKey(res.toSqlString());
						sql.append("order_id = "+requestBO.getProcessInstanceBusinessKey()+" ");
					}
					if (res instanceof TaskApnNameRestriction) {
						requestBO.setTaskAssignee(res.toSqlString());
						sql.append("apn_name = \'"+requestBO.getTaskAssignee()+ "\'");
					}
					if (res instanceof TaskNameRestriction) {
						requestBO.setTaskName(res.toSqlString());
						sql.append("task_id = "+requestBO.getTaskName()+" ");
					}
					if (res instanceof TaskExpediteRestriction) {
						if(res.toSqlString().equalsIgnoreCase("false")) {
							sql.append("expedite = 'N'");
						}else {
							sql.append("expedite = 'Y'");
						}
					}
					if (res instanceof TaskOpenReminderRestriction) {
						if(res.toSqlString().equalsIgnoreCase("N")) {
							sql.append("open_reminder = 'N'");
						}else {
							sql.append("open_reminder = 'Y'");
						}
					}
					if (res instanceof TaskRoleRestriction) {
						sql.append("role_id = "+res.toSqlString()+" ");
					}
					if (res instanceof TaskStatusCriteria) {
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.ASSIGNED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and attuid IS NOT NULL");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.UNCLAIMED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and attuid IS NULL");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.COMPLETED)) {
							sql.append("task_category_id = 1002");
							sql.append(" and task_status_id = 1002");
						}
						if(res.toSqlString().equalsIgnoreCase(CometCommonConstant.OPEN)) {
							sql.append("task_category_id = 1002");
							sql.append(" and task_status_id = 1001");
						}
					}
					if (res instanceof TaskStatusRestriction) {
						sql.append("task_category_id = 1002");
						sql.append(" and attuid IS NOT NULL");
					}
					
					if (res instanceof TaskDateRestriction) {
						String taskDate = res.toSqlString().toString();
						String[] dateList = taskDate.split(",");        
						String fromDate = dateList [0];
					    fromDate = dateFormatting(fromDate);
						String toDate =  dateList [1];
						toDate = dateFormatting(toDate);
						sql.append("(trunc(creation_date) BETWEEN to_date(\'"+fromDate+"\') and to_date(\'"+toDate+"\'))");
					}	
				}
			}
		}
		
		// Pagination code
		OtherDetails other = criteria.getOther();
		String temp = "";
		temp = "select * from ( select tab.*, rownum r from ( " + sql.toString() + ") tab where rownum <= "
				+ ((other.getPageNumber() == 1 || other.getPageNumber() == 0)
						? 1 * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())
						: (other.getPageNumber() * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())))
				+ " )" + "where r > " + ((other.getPageNumber() == 1 || other.getPageNumber() == 0) ? 0
						: ((other.getPageNumber() - 1) * (other.getMaxCount() == 0 ? 1000 : other.getMaxCount())));
		sql.delete(0, sql.length());
		sql.append(temp);

		result = executeTaskSearchQuery(sql.toString(), criteria);
		logger.info("Exiting method createExecuteQueryForOrder : ", this);
		return result;
	}
	
	@SuppressWarnings("deprecation")
	private ResultBO executeTaskSearchQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeTaskSearchQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			List<TaskListGridDisplayBO> taskList = new ArrayList<TaskListGridDisplayBO>();
			GridDisplayBO<TaskListGridDisplayBO> grdDisplayBO = new GridDisplayBO<TaskListGridDisplayBO>();
			Map<String, Object> resultMap = null;
			Object columnObject = null;

			if (list != null && list.size() > 0) {
				Iterator<Map<String, Object>> itr = list.iterator();

				objBO = new ResultBO();

				while (itr.hasNext()) {
					TaskListGridDisplayBO gridDisplayBO = new TaskListGridDisplayBO();

					resultMap = itr.next();
					
					Long status = ((BigDecimal) resultMap.get(ScalarConstants.TASK_STATUS_ID)).longValue();
					if(resultMap.get(ScalarConstants.TASK_ATTUID) != null && status.toString().equalsIgnoreCase("1001")){
						columnObject = resultMap.get(ScalarConstants.TASK_TYPE);
						gridDisplayBO.setTaskType(CometCommonConstant.CLAIMED);
					}else if(resultMap.get(ScalarConstants.TASK_ATTUID) != null && status.toString().equalsIgnoreCase("1002")){
						columnObject = resultMap.get(ScalarConstants.TASK_TYPE);
						gridDisplayBO.setTaskType(CometCommonConstant.COMPLETED);
					}else {
						columnObject = resultMap.get(ScalarConstants.TASK_TYPE);
						gridDisplayBO.setTaskType(CometCommonConstant.UNCLAIMED);
					}
					columnObject = resultMap.get(ScalarConstants.ORDER_ID);
					if (null != columnObject) {
						gridDisplayBO.setOrderId(((BigDecimal) columnObject).longValue());
					}
					
					Long taskNameId = ((BigDecimal) resultMap.get(ScalarConstants.TASK_ID)).longValue();
					Optional<BpmTask> taskNameRepositoryOptional = bpmTaskRepository.findById(taskNameId);
					if(taskNameRepositoryOptional.isPresent()) {
						BpmTask bpmTaskName = taskNameRepositoryOptional.get();
						gridDisplayBO.setTaskName(bpmTaskName.getTaskName());
						gridDisplayBO.setTaskReference(bpmTaskName.getTaskReference());
					}else {
						gridDisplayBO.setTaskName("");
					}
					
					columnObject = resultMap.get(ScalarConstants.TASK_ATTUID);
					if (null != columnObject) {
						gridDisplayBO.setOwner((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.APN_NAME);
					if (null != columnObject) {
						gridDisplayBO.setApnName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.BPM_TASK_ID);
					if (null != columnObject) {
						gridDisplayBO.setTaskId((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.ACCOUNT_NAME);
					if (null != columnObject) {
						gridDisplayBO.setAccountName((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.TASK_SUBJECT);
					if (null != columnObject) {
						gridDisplayBO.setSubject((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.EXPEDITE);
					if (null != columnObject) {
						gridDisplayBO.setExpedite((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.OPEN_REMINDER);
					if (null != columnObject) {
						gridDisplayBO.setOpenReminder((String) columnObject);
					}
					columnObject = resultMap.get(ScalarConstants.CREATION_DATE);
					if (null != columnObject) {
						String createDate = (columnObject).toString();
						String crDate[] = createDate.split(":", 5);
						createDate = (crDate[0]+":"+crDate[1]);
						gridDisplayBO.setCreatedDate(createDate);
					}
					columnObject = resultMap.get(ScalarConstants.COMPLETION_DATE);
					if (null != columnObject) {
						String completeDate = (columnObject).toString();
						String clDate[] = completeDate.split(":", 5);
						completeDate = (clDate[0]+":"+clDate[1]);
						gridDisplayBO.setCompletionDate(completeDate);
					}
					Optional<OrderUserBpmTasks> orderUserBpmTaskRepositoryOptional = orderUserBpmTasksRepository.findById(gridDisplayBO.getTaskId());
					if(orderUserBpmTaskRepositoryOptional.isPresent()) {
						OrderUserBpmTasks orderUserBpmTask = orderUserBpmTaskRepositoryOptional.get();
						gridDisplayBO.setDashFlag(orderUserBpmTask.getDashboardFlag());
						gridDisplayBO.setTaskStatusId(orderUserBpmTask.getTaskStatus().getTaskStatusId());
					}
					boolean userOpenPermission = orderTaskHelper.isTaskCanOpenByUser(criteria.getOther().getRoleId(),criteria.getOther().getUserId(), gridDisplayBO.getTaskStatusId(), gridDisplayBO.getOwner(), gridDisplayBO.getTaskName());
					gridDisplayBO.setUserOpenPermission(userOpenPermission);
					taskList.add(gridDisplayBO);
				}
				grdDisplayBO.setLstGridBOs(taskList);
				objBO.setLstResult(grdDisplayBO);
				objBO.getOtherBO().setTitle("Order Task List");
				objBO.getOtherBO().setCurrentPage(criteria.getOther().getPageNumber());
				objBO.getOtherBO().setTotalRecord(taskList.size());
				objBO.getOtherBO().setTotalPages((int) Math.ceil((float) taskList.size() / 20));
			}
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			logger.error(e.getMessage());
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeTaskSearchQuery : ", this);
		return objBO;
	}
	
	public static String dateFormatting(String date) throws ParseException {
		try {
			SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
		    SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
		    Date dateParse = format1.parse(date);
		    return date = format2.format(dateParse).toString();
		} catch (ParseException e) {
			logger.error("GridCriteriaRenderer.dateFormatting: " + e.getMessage());
		}
		return null;
	}

	// private void fetchAndUpdateBillingTaskBO(ResultBO objBO, String userId)
	// throws CometServiceException, CometDataException,
	// ParseException {
	// //Search billing task
	// SearchCriteria criteria = new SearchCriteriaImpl();
	// criteria.add(new TaskNameRestriction("CCSPMBillingSubmitTask"));
	// criteria.setFormat(OutputFormat.GRID);
	// criteria.addOtherDetails(new OtherDetails(userId, null, 0, 1000));
	//
	// ResultBO taskSearchResult = createExecuteQueryForTask(criteria);
	// for (DisplayResultBO orderResult : objBO.getLstResult()) {
	// OrderAllFieldsReportDisplayBO displayBO = (OrderAllFieldsReportDisplayBO)
	// orderResult;
	// if (displayBO != null &&
	// CommonUtilsNew.isNotNullEmpty(displayBO.getOrderId())) {
	// for (DisplayResultBO taskResult : taskSearchResult.getLstResult()) {
	// TaskListGridDisplayBO taskDisplayBO = (TaskListGridDisplayBO) taskResult;
	// if (taskDisplayBO != null &&
	// CommonUtilsNew.isNotNullEmpty(taskDisplayBO.getOrderId())) {
	// if (displayBO.getOrderId().equals(taskDisplayBO.getOrderId())) {
	// displayBO.setBillingTaskId(Long.parseLong(taskDisplayBO.getTaskId().substring(9).trim()));
	// displayBO.setBillingCreationDate(CommonUtilsNew.isNullEmpty(taskDisplayBO.getCreatedDate().trim())
	// ? null
	// : new SimpleDateFormat("MM/dd/yyyy").format(
	// new SimpleDateFormat("yyyy-MM-dd
	// HH:mm").parse(taskDisplayBO.getCreatedDate().trim())).toString());
	// displayBO.setBillingCompleteDate(CommonUtilsNew.isNullEmpty(taskDisplayBO.getCompletionDate().trim())
	// ? null
	// : new SimpleDateFormat("MM/dd/yyyy").format(
	// new SimpleDateFormat("yyyy-MM-dd
	// HH:mm").parse(taskDisplayBO.getCompletionDate().trim())).toString());
	// break;
	// }
	// }
	// }
	// }
	// }
	// }
}
