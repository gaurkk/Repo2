/**
 * 
 */
package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author GB00476665
 *
 */
@Entity
@Table(name = "DAPN_INVENTORY_TEMPLATE")
public class DapnInventoryTemplate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1377655105997222737L;

	private Long columnNumberDapn;
	private String fieldNameDapn;
	private String fieldDatatypeDapn;

	public DapnInventoryTemplate() {
	}

	/**
	 * @return the columnNumberDapn
	 */
	@Id
	@Column(name = "COLUMN_NUMBER_DAPN", unique = true, nullable = false, precision = 5, scale = 0)
	public Long getColumnNumberDapn() {
		return columnNumberDapn;
	}

	/**
	 * @param columnNumberDapn the columnNumberDapn to set
	 */
	public void setColumnNumberDapn(Long columnNumberDapn) {
		this.columnNumberDapn = columnNumberDapn;
	}

	/**
	 * @return the fieldNameDapn
	 */
	@Column(name = "FIELD_NAME_DAPN", length = 100)
	public String getFieldNameDapn() {
		return fieldNameDapn;
	}

	/**
	 * @param fieldNameDapn the fieldNameDapn to set
	 */
	public void setFieldNameDapn(String fieldNameDapn) {
		this.fieldNameDapn = fieldNameDapn;
	}

	/**
	 * @return the fieldDatatypeDapn
	 */
	@Column(name = "FIELD_DATATYPE_DAPN", length = 100)
	public String getFieldDatatypeDapn() {
		return fieldDatatypeDapn;
	}

	/**
	 * @param fieldDatatypeDapn the fieldDatatypeDapn to set
	 */
	public void setFieldDatatypeDapn(String fieldDatatypeDapn) {
		this.fieldDatatypeDapn = fieldDatatypeDapn;
	}

}
