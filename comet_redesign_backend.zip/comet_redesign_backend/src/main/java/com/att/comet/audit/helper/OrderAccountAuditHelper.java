package com.att.comet.audit.helper;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;

import com.att.comet.account.modal.OrderAccountBO;
import com.att.comet.account.modal.OrderCapacityForecastBO;
import com.att.comet.audit.modal.RowData;
import com.att.comet.dao.ServiceUtils;

@Component
public class OrderAccountAuditHelper {
	/**
	 * Returns the Order Account Audit info details.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return OrderAccountBO
	 * @throws SQLException
	 */
	public OrderAccountBO getOrderAccountAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		OrderAccountBO orderAccountBO = null;
		List<OrderCapacityForecastBO> forecastBOs = null;

		List<RowData> orderAccountResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> capacityForecastResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		
		Object columnValue = null;
		if (orderAccountResults != null && orderAccountResults.size() > 0) {
			for (RowData accountRow : orderAccountResults) {
				orderAccountBO = new OrderAccountBO();
				Long accountOrderId = ((BigDecimal) accountRow.getColumnValue("ORDER_ID")).longValue();
				if (orderId.equals(accountOrderId)) {
					orderAccountBO.setOrderId(accountOrderId);

					columnValue = accountRow.getColumnValue("pdp_package_id");
					if (columnValue != null) {
						orderAccountBO.setPdpPackage(((BigDecimal) columnValue).longValue());
					}
					
					columnValue = accountRow.getColumnValue("pdp_description");
					if (columnValue != null) {
						orderAccountBO.setPdpDescription((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("agreement_account_name");
					if (columnValue != null) {
						orderAccountBO.setAgreementAccountName((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("agreement_account_no");
					if (columnValue != null) {
						orderAccountBO.setAgreementAccountNumber((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("eod_enabled");
					if (columnValue != null) {
						orderAccountBO.setEodEnabled(((String) columnValue).charAt(0));
					}
					
					columnValue = accountRow.getColumnValue("eod_with_fan");
					if (columnValue != null) {
						orderAccountBO.setEodWithFan(((String) columnValue).charAt(0));
					}
					
					columnValue = accountRow.getColumnValue("fan_id");
					if (columnValue != null) {
						orderAccountBO.setFanId((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("ban_id");
					if (columnValue != null) {
						orderAccountBO.setBanId(((String) columnValue));
					}
					
					columnValue = accountRow.getColumnValue("fee_waiver_approved");
					if (columnValue != null) {
						orderAccountBO.setFeeWaiverApproved(((String) columnValue).charAt(0));
					}
					
					columnValue = accountRow.getColumnValue("fee_waiver_approved_mrc");
					if (columnValue != null) {
						orderAccountBO.setFeeWaiverApprovedMRC(((String) columnValue).charAt(0));
					}
					
					columnValue = accountRow.getColumnValue("waiver_notes");
					if (columnValue != null) {
						orderAccountBO.setWaiverNotes((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("waiver_attachment");
					if (columnValue != null) {
						Blob blob = (Blob) columnValue;
						orderAccountBO.setWaiverAttachment(blob.getBytes(1L,  (int)blob.length()));
					}
					
					columnValue = accountRow.getColumnValue("waiver_attachment_filename");
					if (columnValue != null) {
						orderAccountBO.setWaiverAttachmentFilename((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("market_segment");
					if (columnValue != null) {
						orderAccountBO.setMarketSegment((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("cos");
					if (columnValue != null) {
						orderAccountBO.setCos((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("qos");
					if (columnValue != null) {
						orderAccountBO.setQos((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("server_software");
					if (columnValue != null) {
						orderAccountBO.setServerSoftware((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("middleware");
					if (columnValue != null) {
						orderAccountBO.setMiddleware((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("mobile_platform");
					if (columnValue != null) {
						orderAccountBO.setMobilePlatform((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("mobile_software");
					if (columnValue != null) {
						orderAccountBO.setMobileSoftware((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("current_year");
					if (columnValue != null) {
						orderAccountBO.setCurrentYear(((BigDecimal) columnValue).shortValue());
					}
					
					columnValue = accountRow.getColumnValue("pk_bw_rel_avg_bw");
					if (columnValue != null) {
						orderAccountBO.setPeakBandwidthRelToAverageBandwidth((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("pecent_bw_oh_vpn_tun_cust");
					if (columnValue != null) {
						orderAccountBO.setPercentBandwidthOverheadOfVPNTunnelToCustomer((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("no_sms_wakeups_per_devices");
					if (columnValue != null) {
						orderAccountBO.setNumberOfSMSWakeupsPerDevicePerMonth((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("no_pdp_ctx_actv_per_device");
					if (columnValue != null) {
						orderAccountBO.setNumberOfPDPCtxActivationPerDevicePerDay((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("avg_len_actv_pdp_ctx_session");
					if (columnValue != null) {
						orderAccountBO.setAverageLengthOfActivePDPCtxSession((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("no_of_ndc_support_traffic");
					if (columnValue != null) {
						orderAccountBO.setNumberOfNDCSupportingTraffic((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("internal_support_method");
					if (columnValue != null) {
						orderAccountBO.setInternalSupportMethod((String) columnValue);
					}

					columnValue = accountRow.getColumnValue("ism_name");
					if (columnValue != null) {
						orderAccountBO.setIsmName((String) columnValue);
					}

					columnValue = accountRow.getColumnValue("ism_phone");
					if (columnValue != null) {
						orderAccountBO.setIsmPhone((String) columnValue);
					}

					columnValue = accountRow.getColumnValue("ism_email");
					if (columnValue != null) {
						orderAccountBO.setIsmEmail((String) columnValue);
					}

					columnValue = accountRow.getColumnValue("market_segment_note");
					if (columnValue != null) {
						orderAccountBO.setMarketSegmentNote((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("use_category");
					if (columnValue != null) {
						orderAccountBO.setUseCategory((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("primary_backup_remote");
					if (columnValue != null) {
						orderAccountBO.setPrimaryBackupRemote((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("user_type");
					if (columnValue != null) {
						orderAccountBO.setUserType((String) columnValue);
					}
					
					columnValue = accountRow.getColumnValue("stationary_mobile");
					if (columnValue != null) {
						orderAccountBO.setStationaryMobile((String) columnValue);
					}
					
					if (capacityForecastResults != null	&& capacityForecastResults.size() > 0) {
						forecastBOs = new ArrayList<OrderCapacityForecastBO>();
						for (RowData forecastRow : capacityForecastResults) {
							OrderCapacityForecastBO bo = new OrderCapacityForecastBO();
							Long forecastOrderId = ((BigDecimal) forecastRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(forecastOrderId)) {
								bo.setOrderId(accountOrderId);

								columnValue = forecastRow.getColumnValue("year");
								if (columnValue != null) {
									bo.setYear(((BigDecimal) columnValue).shortValue());
								}

								columnValue = forecastRow.getColumnValue("subscriber_devices");
								if (columnValue != null) {
									bo.setSubscribedDevicesOnATTInfrastructure((String) columnValue);
								}
								
								columnValue = forecastRow.getColumnValue("pk_percent_of_devices");
								if (columnValue != null) {
									bo.setPeakPercentDevicesWithConcurrentActivePDPCtxCalculated(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("speed_per_subscriber");
								if (columnValue != null) {
									bo.setSpeedPerMonthPerSubscriber(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("pk_percent_per_pdp");
								if (columnValue != null) {
									bo.setPeakPercentOfDevicesWithConcurrentActivePDPCtxForcast(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("pk_concurrent_total_pdp");
								if (columnValue != null) {
									bo.setPeakConcurrentActivePDPCtxTotal(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("pk_concurrent_pdp_ndc");
								if (columnValue != null) {
									bo.setPeakConcurrentActivePDPCtxPerNDC(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("pk_wan_bw_total_ndc");
								if (columnValue != null) {
									bo.setPeakWANBandwidthTotalAllNDC(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("pk_pdp_ctx_actv_per_sec");
								if (columnValue != null) {
									bo.setPeakPDPCtxActivationsPerSecondsNDC(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("total_sms_wakeups_month");
								if (columnValue != null) {
									bo.setTotalSMSWakeupsPerMonth(((String) columnValue));
								}
								
								columnValue = forecastRow.getColumnValue("total_sms_wakeups_sec");
								if (columnValue != null) {
									bo.setTotalSMSWakeupsPerSecondPeak(((String) columnValue));
								}
								
								forecastBOs.add(bo);
							}
						}
						orderAccountBO.setOrderCapacityForecasts(forecastBOs);
					}
				}
			}
		}
		return orderAccountBO;
	}
}
