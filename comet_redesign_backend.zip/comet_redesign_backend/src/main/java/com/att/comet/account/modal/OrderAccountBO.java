package com.att.comet.account.modal;

import java.io.InputStream;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderAccountBO extends CometGenericBO {
	private static final long serialVersionUID = -6621240286811010010L;
	private Long orderId;
	private String pdpDescription;
	private String agreementAccountName;
	private String agreementAccountNumber;
	private Character eodEnabled;
	private Character eodWithFan;
	private String fanId;
	private String banId;
	private Character feeWaiverApproved;
	private Character feeWaiverApprovedMRC;
	private String waiverNotes;
	private byte[] waiverAttachment;
	private MultipartFile waiverAttachments;
	private String waiverAttachmentFilename;
	private String marketSegment;
	private String cos;
	private String qos;
	private String serverSoftware;
	private String middleware;
	private String mobilePlatform;
	private String mobileSoftware;
	private String peakBandwidthRelToAverageBandwidth;
	private String percentBandwidthOverheadOfVPNTunnelToCustomer;
	private String numberOfSMSWakeupsPerDevicePerMonth;
	private String numberOfPDPCtxActivationPerDevicePerDay;
	private String averageLengthOfActivePDPCtxSession;
	private String numberOfNDCSupportingTraffic;
	private String internalSupportMethod;	
	private Short currentYear;
	private List<OrderCapacityForecastBO> OrderCapacityForecasts;
	private String ismName;
	private String ismPhone;
	private String ismEmail;
	private String marketSegmentNote;
	private Long pdpPackage;
	private String isTunnelType;	
	private String eodBLU; //-- STARTS -- BR-2.2.005 -- HLD-2.2.5.02
	private String updatedBy;
	private Long roleId;
	private Long copyOrderFromOrderId;
	private String accountClass;
	private String masterAccountName;
	private String subAccountName;
	private String useCategory;
	private String primaryBackupRemote;
	private String userType;
	private String stationaryMobile;
}
