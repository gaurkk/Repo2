package com.att.comet.audit.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.account.modal.OrderAccountBO;
import com.att.comet.audit.modal.ApnAuditBO;
import com.att.comet.audit.modal.OrderAuditBO;
import com.att.comet.audit.modal.OrderContactAuditBO;
import com.att.comet.audit.modal.RecoveryFlowChartAuditBO;
import com.att.comet.audit.service.AuditService;
import com.att.comet.charts.modal.UserInfoBO;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.modal.BackhaulConfigBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.order.crd.modal.CrdBO;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.order.modal.BillingDetailsBO;
import com.att.comet.order.modal.InternetVPNConfigBO;
import com.att.comet.order.modal.MplsConfigBO;
import com.att.comet.order.modal.OrderSummaryBO;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class AuditController {
	private static final Logger logger = LoggerFactory.getLogger(AuditController.class);
	
	@Autowired
	UserHelper userHelper;
	
	@Autowired
	AuditService auditService;
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getInitiateInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the initiate tab info", notes = "Gets the initiate tab info for a CR")
	public CometResponse<OrderAuditBO> getAuditInitiateInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditInitiateInfo Getting Initiate info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<OrderAuditBO> response = new CometResponse<OrderAuditBO>();
		OrderAuditBO orderAuditBO = null;
		
		try {
			orderAuditBO = auditService.getOrderInitializationInfoAudit(orderId, eventId);
					
			if (null == orderAuditBO) {
				throw new CometException("No Initiate info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(orderAuditBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(orderAuditBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getApnInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the apn tab info", notes = "Gets the apn tab info for a CR")
	public CometResponse<ApnAuditBO> getAuditApnInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditApnInfo Getting Apn info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<ApnAuditBO> response = new CometResponse<ApnAuditBO>();
		ApnAuditBO apnAuditBO = null;
		
		try {
			apnAuditBO = auditService.getApnAudit(orderId, eventId);
					
			if (null == apnAuditBO) {
				throw new CometException("No Apn audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(apnAuditBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(apnAuditBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getAccountInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<OrderAccountBO> getAuditAccountInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditAccountInfo Getting Account info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<OrderAccountBO> response = new CometResponse<OrderAccountBO>();
		OrderAccountBO orderAccountBO = null;
		
		try {
			orderAccountBO = auditService.getOrderAccountAudit(orderId, eventId);
					
			if (null == orderAccountBO) {
				throw new CometException("No Account audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(orderAccountBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(orderAccountBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getContactInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<OrderContactAuditBO> getAuditContactInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditContactInfo Getting Contact info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<OrderContactAuditBO> response = new CometResponse<OrderContactAuditBO>();
		OrderContactAuditBO orderContactAuditBO = null;
		
		try {
			orderContactAuditBO = auditService.getOrderContactAudit(orderId, eventId);
					
			if (null == orderContactAuditBO) {
				throw new CometException("No Contact audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(orderContactAuditBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(orderContactAuditBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getBackhaulInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<BackhaulConfigBO> getAuditBackhaulInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditBackhaulInfo Getting Backhaul info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<BackhaulConfigBO> response = new CometResponse<BackhaulConfigBO>();
		BackhaulConfigBO backhaulConfigBO = null;
		
		try {
			backhaulConfigBO = auditService.getBackhaulConfigAudit(orderId, eventId);
					
			if (null == backhaulConfigBO) {
				throw new CometException("No Backhaul audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(backhaulConfigBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(backhaulConfigBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getIVPNInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<InternetVPNConfigBO> getAuditInternetVPNInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditInternetVPNInfo Getting IVPN info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<InternetVPNConfigBO> response = new CometResponse<InternetVPNConfigBO>();
		InternetVPNConfigBO internetVPNConfigBO = null;
		
		try {
			internetVPNConfigBO = auditService.getInternetVPNConfigAudit(orderId, eventId);
					
			if (null == internetVPNConfigBO) {
				throw new CometException("No IVPN audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(internetVPNConfigBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(internetVPNConfigBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getMplsInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<MplsConfigBO> getAuditMplsInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditMplsInfo Getting Mpls info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<MplsConfigBO> response = new CometResponse<MplsConfigBO>();
		MplsConfigBO mplsConfigBO = null;
		
		try {
			mplsConfigBO = auditService.getMplsConfigAudit(orderId, eventId);
					
			if (null == mplsConfigBO) {
				throw new CometException("No Mpls audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(mplsConfigBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(mplsConfigBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getCrdInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<CrdBO> getAuditCrdInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditCrdInfo Getting Crd info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<CrdBO> response = new CometResponse<CrdBO>();
		CrdBO crdBO = null;
		
		try {
			crdBO = auditService.getCrdAudit(orderId, eventId);
					
			if (null == crdBO) {
				throw new CometException("No Crd audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(crdBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(crdBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getFeeWaiverDocInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<OrderAccountBO> getAuditFeeWaiverDocInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditFeeWaiverDocInfo Getting FeeWaiverDoc info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<OrderAccountBO> response = new CometResponse<OrderAccountBO>();
		OrderAccountBO orderAccountBO = null;
		
		try {
			orderAccountBO = auditService.getFeeWaiverDocAudit(orderId, eventId);
					
			if (null == orderAccountBO) {
				throw new CometException("No FeeWaiverDoc audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(orderAccountBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(orderAccountBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getRecoveryFlowChartInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<RecoveryFlowChartAuditBO> getAuditRecoveryFlowChartInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditRecoveryFlowChartInfo Getting RecoveryFlowChart info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<RecoveryFlowChartAuditBO> response = new CometResponse<RecoveryFlowChartAuditBO>();
		RecoveryFlowChartAuditBO recoveryFlowChartAuditBO = null;
		
		try {
			recoveryFlowChartAuditBO = auditService.getRecoveryFlowChartAudit(orderId, eventId);
					
			if (null == recoveryFlowChartAuditBO) {
				throw new CometException("No RecoveryFlowChart audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(recoveryFlowChartAuditBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(recoveryFlowChartAuditBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getOrderSummaryInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<OrderSummaryBO> getAuditOrderSummaryInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditOrderSummaryInfo Getting OrderSummary info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<OrderSummaryBO> response = new CometResponse<OrderSummaryBO>();
		OrderSummaryBO orderSummaryBO = null;
		
		try {
			orderSummaryBO = auditService.getOrderSummaryAudit(orderId, eventId);
					
			if (null == orderSummaryBO) {
				throw new CometException("No OrderSummary audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(orderSummaryBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(orderSummaryBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/audit/{orderId}/{eventId}/getOrderBillingInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Gets the account tab info", notes = "Gets the account tab info for a CR")
	public CometResponse<BillingDetailsBO> getAuditOrderBillingInfo(@PathVariable("orderId") Long orderId,
														@PathVariable("eventId") Long eventId,
														Authentication authentication) 
																throws CometException {
		logger.debug("AuditController::getAuditOrderBillingInfo Getting Billing info for orderId [" + orderId 
						+ "] and eventId [" + eventId + "]");
		
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		CometResponse<BillingDetailsBO> response = new CometResponse<BillingDetailsBO>();
		BillingDetailsBO billingDetailsBO = null;
		
		try {
			billingDetailsBO = auditService.getOrderBillingAudit(orderId, eventId);
					
			if (null == billingDetailsBO) {
				throw new CometException("No Billing audit info found for orderId [" + orderId + "] and eventId [" + eventId + "]");
			}
			response.setMethodReturnValue(billingDetailsBO);
			response.setStatusCode(Status.SUCCESS.getCode());
			response.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			response.setMethodReturnValue(billingDetailsBO);
			response.setStatusCode(Status.BUSINESS_ERROR.getCode());
			response.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return response;
	}
}
