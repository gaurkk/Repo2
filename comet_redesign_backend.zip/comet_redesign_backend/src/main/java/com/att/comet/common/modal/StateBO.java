package com.att.comet.common.modal;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * POJO for StateBO
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class StateBO extends CometGenericBO implements Comparable<StateBO>{
	
	private static final long serialVersionUID = 7891055212552674666L;
	private Long stateId;
	private Long countryId;
	private String stateName; 
	private Character active;
	private String countryName; 
	@Override
	public int compareTo(StateBO stateBO) {		
		if (this.stateName != null && stateBO.stateName != null) {
			return this.stateName.compareTo(stateBO.stateName);
		}
		return -1;
	}

}
