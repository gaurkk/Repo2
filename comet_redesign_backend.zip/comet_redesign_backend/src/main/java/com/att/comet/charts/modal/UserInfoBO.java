package com.att.comet.charts.modal;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.att.comet.common.modal.CometGenericBO;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class UserInfoBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = -8415128317358612563L;

	private String attuid;
	private Long roleId;
}
