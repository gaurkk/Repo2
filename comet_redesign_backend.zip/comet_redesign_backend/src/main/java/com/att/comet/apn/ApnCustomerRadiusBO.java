package com.att.comet.apn;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper=true)
public class ApnCustomerRadiusBO extends CometGenericBO {

	private static final long serialVersionUID = 1823187944741324197L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long dataCenterId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long apnCustRadiusId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String customerRadIpAddress;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String customerRadName;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String customerRadSharedSecret;
}
