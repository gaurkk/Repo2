package com.att.comet.dao.hibernate.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for TaskData. Mapped to TASK_DATA table in the database.
 */
@Entity
@Table(name = "TASK_DATA")
public class TaskData implements java.io.Serializable {

	private static final long serialVersionUID = 5572583300951683499L;

	private Long taskDataId;
	private String header;
	private String subHeading;
	private String taskDesc;
	private String taskLinkURL;
	private String nameSpace;
	private String rootName;
	private String partName;
	private String taskName;
	private String taskDisplayName;
	private String sqlQuery;

	private Set<TaskDataFields> taskDataFields = new HashSet<TaskDataFields>(0);

	/**
	 * No-argument constructor for the class.
	 */
	public TaskData () {}
	
	public TaskData(Long taskDataId, Set<TaskDataFields> taskDataFields) {
		this.taskDataId = taskDataId;
		this.taskDataFields = taskDataFields;
	}

	@Id
	@Column(name = "TASK_DATA_ID", unique = true, nullable = false, precision = 22, scale = 0)
	public Long getTaskDataId() {
		return taskDataId;
	}

	public void setTaskDataId(Long taskDataId) {
		this.taskDataId = taskDataId;
	}

	@Column(name = "HEADER", nullable = false, length = 100)
	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	@Column(name = "SUB_HEADING", nullable = false, length = 200)
	public String getSubHeading() {
		return subHeading;
	}

	public void setSubHeading(String subHeading) {
		this.subHeading = subHeading;
	}

	@Column(name = "TASK_DESC", nullable = false, length = 500)
	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	@Column(name = "TASK_LINK_URL", nullable = true, length = 200)
	public String getTaskLinkURL() {
		return taskLinkURL;
	}

	public void setTaskLinkURL(String taskLinkURL) {
		this.taskLinkURL = taskLinkURL;
	}

	@Column(name = "NAME_SPACE", nullable = true, length = 100)
	public String getNameSpace() {
		return nameSpace;
	}

	public void setNameSpace(String nameSpace) {
		this.nameSpace = nameSpace;
	}

	@Column(name = "ROOT_NAME", nullable = true, length = 50)
	public String getRootName() {
		return rootName;
	}

	public void setRootName(String rootName) {
		this.rootName = rootName;
	}

	@Column(name = "PART_NAME", nullable = true, length = 50)
	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	@Column(name = "TASK_NAME", nullable = true, length = 50)
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Column(name = "TASK_DISPLAY_NAME", nullable = true, length = 100)
	public String getTaskDisplayName() {
		return taskDisplayName;
	}

	public void setTaskDisplayName(String taskDisplayName) {
		this.taskDisplayName = taskDisplayName;
	}
	
	@OneToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "TASK_DATA_ID", nullable = false)
	public Set<TaskDataFields> getTaskDataFields() {
		return taskDataFields;
	}

	public void setTaskDataFields(Set<TaskDataFields> taskDataFields) {
		this.taskDataFields = taskDataFields;
	}

	@Column(name = "SQL_QUERY", nullable = true, length = 200)
	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

}
