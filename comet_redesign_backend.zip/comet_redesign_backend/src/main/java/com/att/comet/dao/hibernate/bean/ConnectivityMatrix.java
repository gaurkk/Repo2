package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for ConnectivityMatrix. Mapped to CONNECTIVITY_MATRIX table
 * in the database.
 */
@Entity
@Table(name = "CONNECTIVITY_MATRIX")
public class ConnectivityMatrix implements Serializable {

	private static final long serialVersionUID = 8044468307974677310L;

	private ConnectivityMatrixId id;
	private CrdDataCenter crdDataCenter;
	private String sourceIpAddress;
	private String directionIndicator;
	private String destinationIpAddress;
	private String destinationDataCenter;
	private String serviceProtocol;
	private String customerVlanId;
	private String autoVlanId;
	private String completeRequestCommnets;
	private String destinationIpAddressDns;
	private String attMobilityVpnRouters;
	private String dns;

	/**
	 * Getter method for id.
	 * 
	 * @return ConnectivityMatrixId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "scenario", column = @Column(name = "SCENARIO", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "crdId", column = @Column(name = "CRD_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public ConnectivityMatrixId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(ConnectivityMatrixId id) {
		this.id = id;
	}

	/**
	 * Getter method for crdDataCenter.
	 * 
	 * @return CrdDataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CRD_ID", referencedColumnName = "CRD_ID", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "DATA_CENTER_ID", referencedColumnName = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false) })
	public CrdDataCenter getCrdDataCenter() {
		return this.crdDataCenter;
	}

	/**
	 * @param crdDataCenter to crdDataCenter set.
	 */
	public void setCrdDataCenter(CrdDataCenter crdDataCenter) {
		this.crdDataCenter = crdDataCenter;
	}

	/**
	 * Getter method for sourceIpAddress. SOURCE_IP_ADDRESS mapped to
	 * SOURCE_IP_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SOURCE_IP_ADDRESS", length = 100)
	public String getSourceIpAddress() {
		return this.sourceIpAddress;
	}

	/**
	 * @param sourceIpAddress to sourceIpAddress set.
	 */
	public void setSourceIpAddress(String sourceIpAddress) {
		this.sourceIpAddress = sourceIpAddress;
	}

	/**
	 * Getter method for directionIndicator. DIRECTION_INDICATOR mapped to
	 * DIRECTION_INDICATOR in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DIRECTION_INDICATOR", length = 100)
	public String getDirectionIndicator() {
		return this.directionIndicator;
	}

	/**
	 * @param directionIndicator to directionIndicator set.
	 */
	public void setDirectionIndicator(String directionIndicator) {
		this.directionIndicator = directionIndicator;
	}

	/**
	 * Getter method for destinationIpAddress. DESTINATION_IP_ADDRESS mapped to
	 * DESTINATION_IP_ADDRESS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DESTINATION_IP_ADDRESS", length = 500)
	public String getDestinationIpAddress() {
		return this.destinationIpAddress;
	}

	/**
	 * @param destinationIpAddress to destinationIpAddress set.
	 */
	public void setDestinationIpAddress(String destinationIpAddress) {
		this.destinationIpAddress = destinationIpAddress;
	}

	/**
	 * Getter method for destinationDataCenter. DESTINATION_DATA_CENTER mapped to
	 * DESTINATION_DATA_CENTER in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DESTINATION_DATA_CENTER", length = 100)
	public String getDestinationDataCenter() {
		return this.destinationDataCenter;
	}

	/**
	 * @param destinationDataCenter to destinationDataCenter set.
	 */
	public void setDestinationDataCenter(String destinationDataCenter) {
		this.destinationDataCenter = destinationDataCenter;
	}

	/**
	 * Getter method for serviceProtocol. SERVICE_PROTOCOL mapped to
	 * SERVICE_PROTOCOL in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "SERVICE_PROTOCOL", length = 100)
	public String getServiceProtocol() {
		return this.serviceProtocol;
	}

	/**
	 * @param serviceProtocol to serviceProtocol set.
	 */
	public void setServiceProtocol(String serviceProtocol) {
		this.serviceProtocol = serviceProtocol;
	}

	/**
	 * Getter method for customerVlanId. CUSTOMER_VLAN_ID mapped to CUSTOMER_VLAN_ID
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "CUSTOMER_VLAN_ID", length = 100)
	public String getCustomerVlanId() {
		return this.customerVlanId;
	}

	/**
	 * @param customerVlanId to customerVlanId set.
	 */
	public void setCustomerVlanId(String customerVlanId) {
		this.customerVlanId = customerVlanId;
	}

	/**
	 * Getter method for autoVlanId. AUTO_VLAN_ID mapped to AUTO_VLAN_ID in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "AUTO_VLAN_ID", length = 100)
	public String getAutoVlanId() {
		return this.autoVlanId;
	}

	/**
	 * @param autoVlanId to autoVlanId set.
	 */
	public void setAutoVlanId(String autoVlanId) {
		this.autoVlanId = autoVlanId;
	}

	/**
	 * Getter method for completeRequestCommnets. COMPLETE_REQUEST_COMMNETS mapped
	 * to COMPLETE_REQUEST_COMMNETS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "COMPLETE_REQUEST_COMMNETS", length = 3500)
	public String getCompleteRequestCommnets() {
		return this.completeRequestCommnets;
	}

	/**
	 * @param completeRequestCommnets to completeRequestCommnets set.
	 */
	public void setCompleteRequestCommnets(String completeRequestCommnets) {
		this.completeRequestCommnets = completeRequestCommnets;
	}

	/**
	 * Getter method for destinationIpAddressDns. DESTINATION_IP_ADDRESS_DNS mapped
	 * to DESTINATION_IP_ADDRESS_DNS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DESTINATION_IP_ADDRESS_DNS", length = 100)
	public String getDestinationIpAddressDns() {
		return this.destinationIpAddressDns;
	}

	/**
	 * @param destinationIpAddressDns to destinationIpAddressDns set.
	 */
	public void setDestinationIpAddressDns(String destinationIpAddressDns) {
		this.destinationIpAddressDns = destinationIpAddressDns;
	}

	/**
	 * Getter method for attMobilityVpnRouters. ATT_MOBILITY_VPN_ROUTERS mapped to
	 * ATT_MOBILITY_VPN_ROUTERS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ATT_MOBILITY_VPN_ROUTERS", length = 100)
	public String getAttMobilityVpnRouters() {
		return this.attMobilityVpnRouters;
	}

	/**
	 * @param attMobilityVpnRouters to attMobilityVpnRouters set.
	 */
	public void setAttMobilityVpnRouters(String attMobilityVpnRouters) {
		this.attMobilityVpnRouters = attMobilityVpnRouters;
	}

	/**
	 * Getter method for dns. DNS mapped to DNS in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "DNS", length = 100)
	public String getDns() {
		return this.dns;
	}

	/**
	 * @param dns to dns set.
	 */
	public void setDns(String dns) {
		this.dns = dns;
	}
}