package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.BpmProcess;

@Repository
public interface BpmProcessRespository extends JpaRepository<BpmProcess, Long> {

}
