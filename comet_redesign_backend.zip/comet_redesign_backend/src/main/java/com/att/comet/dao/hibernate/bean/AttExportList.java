package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ATT_EXPORT_LIST")
public class AttExportList implements java.io.Serializable {
	private static final long serialVersionUID = -739546651452262407L;
	
	private Long backhaulId;
	private String ExportIpAddress;
	private String ExportListType;
	private Long AttExportId;
	@ManyToOne
	@JoinColumn(name="BACKHAUL_ID", 
				insertable=false, updatable=false, 
				nullable=false)
	private Bgp bgp;
	
	/**
	 * Getter method for AttExportId 
	 * @return Long
	 */
	@Id
	@GenericGenerator(name = "SEQ_ATT_EXPORT_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_ATT_EXPORT_ID")})
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_ATT_EXPORT_ID")
	@Column(name = "ATT_EXPORT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getAttExportId() {
		return AttExportId;
	}
	public void setAttExportId(Long attExportId) {
		AttExportId = attExportId;
	}

	/**
	 * Getter method for the backhaulId.It is the unique value in the database ,
	 * having a maximum length of 12. BACKHAUL_ID mapped to BACKHAUL_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BACKHAUL_ID")
	public Long getBackhaulId() {
		return this.backhaulId;
	}

	/**
	 * @param backhaulId
	 *            to backhaulId set.
	 */
	public void setBackhaulId(Long backhaulId) {
		this.backhaulId = backhaulId;
	}

	
	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BACKHAUL_ID", nullable = false, insertable = false, updatable = false)
	public Bgp getBgp() {
		return this.bgp;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setBgp(Bgp bgp) {
		this.bgp = bgp;
	}
	
	@Column(name = "EXPORT_IP_ADDRESS")
	public String getExportIpAddress() {
		return ExportIpAddress;
	}
	
	public void setExportIpAddress(String exportIpAddress) {
		ExportIpAddress = exportIpAddress;
	}
	
	@Column(name = "EXPORT_LIST_TYPE")
	public String getExportListType() {
		return ExportListType;
	}
	
	public void setExportListType(String exportListType) {
		ExportListType = exportListType;
	}



}
