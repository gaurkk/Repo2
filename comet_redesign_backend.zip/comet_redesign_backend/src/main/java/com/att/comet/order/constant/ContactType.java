package com.att.comet.order.constant;

import com.att.comet.common.modal.BpmStatusEnum;

public enum ContactType {
	SALES_CONTACT(1001L, "Sales Contact"),
	PROV_PROJECT_MANGAER(1002L, "Prov Project Manager"),
	ORDER_SUBMITTER(1003L, "Order Submitter"),
	ORDER_APPROVER(1004L, "Order Approver"),
	ORDER_MANAGER(1005L, "Order Manager"),
	CCSPM(1006L, "CCSPM"),
	NETWORK_IMPLEMENTATION(1007L, "Network Implementation"),
	PROJECT_MANAGER(1008L, "Project Manager"),
	APP_SERVER_ADMIN(1009L, "Application Server Admin"),
	FIREWALL_ADMIN(1010L, "Firewall Administrator"),
	VPN_ADMIN(1011L, "VPN Administrator"),
	FRAME_ADMIN(1012L, "Frame Administrator"),
	BILLING_ADMIN(1013L, "Billing Administrator"),
	HELPDESK(1014L, "Helpdesk"),
	CUSTOMER_TECH_CONTACT(1015L, "Customer Technical Contact"),
	CUSTOMER_BUSINESS_CONTACT(1016L, "Customer Business Contact"),
	INITIATIVE_ORIGINATOR(1017L, "Initiative Originator"),
	CUSTOMER_CONTACT(1018L, "Customer Contact"),
	TECHNICAL_CONTACT(1019L, "Technical Contact"),
	BILLING_CONTACT(1020L, "Billing Contact"),
	ONSITE_CONTACT(1021L, "On Site Contact"),
	ALTERNATE_CONTACT(1022L, "Alternate Contact"),
	OSD(1023L, "OSD"),
	IT_OPS(1024L, "IT OPS"),
	POST_SALES_SE(1025L, "Post Sales SE");
	
	private Long contactId;
	private String contactName;
	
	public Long getContactId() {
		return contactId;
	}

	public String getContactname() {
		return contactName;
	}

	public static ContactType getById(Long id) {
		ContactType contactType = null;
		
		for (ContactType type : ContactType.values()) {
			if (type.getContactId().equals(id)) {
				contactType = type;
				break;
			}
		}
		
		return contactType;
	}

	private ContactType(Long contactId, String contactName) {
		this.contactId = contactId;
		this.contactName = contactName;
	}
}
