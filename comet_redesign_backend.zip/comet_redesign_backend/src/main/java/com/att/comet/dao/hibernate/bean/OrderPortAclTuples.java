package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ORDER_PORT_ACL_TUPLES")
public class OrderPortAclTuples implements Serializable {
	private static final long serialVersionUID = -1364259342726373183L;
	
	private Long paclId; 
	private Orders orders;
	private String internetIntranet;
	private String moMt;
	private String sourceIp;
	private String sourcePort;
	private String destinationIp;
	private String destinationPort;
	private String protocol;
	private String timeToLive;
	private String permission;
	private String preBuildApplication;
	
	/**
	 * Get Port ACL Id
	 * @return
	 */
	@Id
	@Column(name = "PACL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_PACL_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_PACL_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PACL_ID")
	public Long getPaclId() {
		return paclId;
	}
	
	/**
	 * Set Port ACL Id
	 * @param paclId
	 */
	public void setPaclId(Long paclId) {
		this.paclId = paclId;
	}
	
	/**
	 * Getter method for Orders object
	 * @return Orders
	 */	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return orders;
	}
	
	/**
	 * Set Order object
	 * @param order
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	/**
	 * Getter method for internetIntranet. InternetIntranet mapped to INTERNET_INTRANET in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INTERNET_INTRANET", length = 10, nullable = false)
	public String getInternetIntranet() {
		return internetIntranet;
	}
	
	/**
	 * Set internetIntranet
	 * @param internetIntranet
	 */
	public void setInternetIntranet(String internetIntranet) {
		this.internetIntranet = internetIntranet;
	}
	
	/**
	 * Getter method for moMt. MoMt mapped to MO_MT in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "MO_MT", length = 2, nullable = false)
	public String getMoMt() {
		return moMt;
	}
	
	/**
	 * Set moMt
	 * @param moMt
	 */
	public void setMoMt(String moMt) {
		this.moMt = moMt;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "SOURCE_IP", length = 100)
	public String getSourceIp() {
		return sourceIp;
	}
	
	/**
	 * Set sourceIp
	 * @param sourceIp
	 */
	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}
	
	/**
	 * Getter method for Source Port
	 * 
	 * @return String
	 */
	@Column(name = "SOURCE_PORT", length = 20)
	public String getSourcePort() {
		return sourcePort;
	}
	
	/**
	 * Set sourcePort
	 * @param sourcePort
	 */
	public void setSourcePort(String sourcePort) {
		this.sourcePort = sourcePort;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "DESTINATION_IP", length = 100)
	public String getDestinationIp() {
		return destinationIp;
	}
	
	/**
	 * Set destinationIp
	 * @param destinationIp
	 */
	public void setDestinationIp(String destinationIp) {
		this.destinationIp = destinationIp;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "DESTINATION_PORT", length = 20)
	public String getDestinationPort() {
		return destinationPort;
	}
	
	/**
	 * Set destinationPort
	 * @param destinationPort
	 */
	public void setDestinationPort(String destinationPort) {
		this.destinationPort = destinationPort;
	}
	
	/**
	 * Getter method for Protocol
	 * 
	 * @return String
	 */
	@Column(name = "PROTOCOL", length = 10)
	public String getProtocol() {
		return protocol;
	}
	
	/**
	 * Set Protocol
	 * @param protocol
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "TIME_TO_LIVE", length = 20)
	public String getTimeToLive() {
		return timeToLive;
	}
	
	/**
	 * Set time to live
	 * @param timeToLive
	 */
	public void setTimeToLive(String timeToLive) {
		this.timeToLive = timeToLive;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "PERMISSION", length = 5)
	public String getPermission() {
		return permission;
	}
	
	/**
	 * Set Permission
	 * @param permission
	 */
	public void setPermission(String permission) {
		this.permission = permission;
	}
	
	/**
	 * Getter method for SourceIp
	 * 
	 * @return String
	 */
	@Column(name = "PRE_BUILD_APPLICATION", length = 100)
	public String getPreBuildApplication() {
		return preBuildApplication;
	}
	
	/**
	 * Set Prebuild application
	 * @param preBuildApplication
	 */
	public void setPreBuildApplication(String preBuildApplication) {
		this.preBuildApplication = preBuildApplication;
	}
}
