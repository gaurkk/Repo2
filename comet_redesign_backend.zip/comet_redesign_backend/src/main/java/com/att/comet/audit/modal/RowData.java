package com.att.comet.audit.modal;

import java.util.List;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class RowData extends CometGenericBO {
	 private static final long serialVersionUID = -5872869100128269297L;
	 
	 private List<ColumnData> columnData;

	/**
	 * Returns the column value for specified column label.
	 * 
	 * @param columnLabel
	 * @return Object
	 */
	public Object getColumnValue(String columnLabel) {
		Object returnValue = null;
		if (columnData != null && !columnData.isEmpty() && columnLabel != null) {
			for (ColumnData cData : columnData) {
				if (cData.getColumnLabel() != null) {
					if (cData.getColumnLabel().equalsIgnoreCase(columnLabel)) {
						returnValue = cData.getColumnValue();
						break;
					}
				}
			}
		}

		return returnValue;
	}
}
