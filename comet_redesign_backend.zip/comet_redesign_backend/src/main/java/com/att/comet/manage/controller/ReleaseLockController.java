package com.att.comet.manage.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.charts.modal.UserInfoBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.manage.modal.ReleaseLockBO;
import com.att.comet.manage.modal.ReleaseLockResponseBO;
import com.att.comet.manage.service.ReleaseLockService;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.order.modal.OrderUserQueueBO;
import com.att.comet.user.exception.UserException;
import com.att.comet.user.modal.RoleEnum;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ReleaseLockController {
	private static final Logger logger = LoggerFactory.getLogger(ReleaseLockController.class);
	
	@Autowired
	UserHelper userHelper;
	
	@Autowired
	ReleaseLockService releaseLockService;
	
	private final String ERROR_STRING = "User not allowed to perform this operation";
	
	@Secured({"ROLE_COMET_ADMIN"})
	@GetMapping(value = "/orders/releaseLock", produces = {MediaType.APPLICATION_JSON_VALUE }, 
											headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find currently locked and request locks for all orders", 
					notes = "Get all the orders currently either locked or requested lock by all users")
	public CometResponse<ReleaseLockResponseBO> getAllLockedOrders(Authentication authentication) 
															throws CometDataException, CometException {
		logger.debug("ReleaseLockController::getAllLockedOrders Getting all request lock orders");

		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		if (!userInfoBO.getRoleId().equals(RoleEnum.COMET_ADMIN.getRoleId())) {
			throw new CometException(ERROR_STRING);
		}
		
		CometResponse<ReleaseLockResponseBO> cometResponse = new CometResponse<ReleaseLockResponseBO>();
		ReleaseLockResponseBO releaseLockResponse = null;
		
		try {
			releaseLockResponse = releaseLockService.getAllRequestLocks(userInfoBO.getAttuid());
			
			if(null == releaseLockResponse || 
					null == releaseLockResponse.getOrderUserQueues() || 
							releaseLockResponse.getOrderUserQueues().isEmpty()) {
				logger.info("No requested locks found");
			}
			cometResponse.setMethodReturnValue(releaseLockResponse);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(releaseLockResponse);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@GetMapping(value = "/orders/{orderId}/releaseLock", produces = {MediaType.APPLICATION_JSON_VALUE }, 
													headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find currently locked and request locks for specific order", 
					notes = "Return all the lock and requested locks for a given order")
	public CometResponse<List<OrderUserQueueBO>> getLocksByOrder(@PathVariable("orderId") long orderId, 
																	Authentication authentication) 
																	throws CometDataException, CometException {
		logger.debug("ReleaseLockController::getLocksByOrder Getting locks for order ID:" + orderId);

		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		if (!userInfoBO.getRoleId().equals(RoleEnum.COMET_ADMIN.getRoleId())) {
			throw new CometException(ERROR_STRING);
		}
		
		CometResponse<List<OrderUserQueueBO>> cometResponse = new CometResponse<List<OrderUserQueueBO>>();
		List<OrderUserQueueBO> orderUserQueueBOList = null;
		
		try {
			orderUserQueueBOList = releaseLockService.getRequestLocksByOrderId(orderId);
			
			if(null == orderUserQueueBOList) {
				logger.info("No requested locks found for order ID:" + orderId);
			}
			cometResponse.setMethodReturnValue(orderUserQueueBOList);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(orderUserQueueBOList);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "/orders/lock/release", produces = {MediaType.APPLICATION_JSON_VALUE }, 
													headers = "X-API-VERSION=1")
	@ApiOperation(value = "Releases lock request", notes = "Releases the lock or request lock of a given order")
	public CometResponse<Boolean> releaseOrderLock(@RequestBody ReleaseLockBO releaseLockBO, 
																Authentication authentication,
																HttpServletRequest request)
																throws UserException, CometException {
		logger.debug("ReleaseLockController::releaseOrderLock Releasing lock for oreder ID: " + 
								releaseLockBO.getOrderUserQueue().getOrderId() + " and user: " +
								releaseLockBO.getOrderUserQueue().getLockReqBy());

		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		if (!userInfoBO.getRoleId().equals(RoleEnum.COMET_ADMIN.getRoleId())) {
			throw new CometException(ERROR_STRING);
		}
		
		CometResponse<Boolean> cometResponse = new CometResponse<Boolean>();
		Boolean isReleaseSuccess = false;
		
		try {
			isReleaseSuccess = releaseLockService.releaseLock(releaseLockBO, request);
			
			if(null == isReleaseSuccess) {
				logger.info("Unsuccessful release lock");
			}
			cometResponse.setMethodReturnValue(isReleaseSuccess);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setMethodReturnValue(isReleaseSuccess);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		return cometResponse;
	}
}
