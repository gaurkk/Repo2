package com.att.comet.common.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.common.repository.AccountClassRepository;
import com.att.comet.common.repository.AdminConfigRepository;
import com.att.comet.common.repository.BackhaulTypeRepository;
import com.att.comet.common.repository.DapnRepository;
import com.att.comet.common.repository.DapnStatusRepository;
import com.att.comet.common.repository.DataCenterNameRepository;
import com.att.comet.common.repository.OrderStatusRepository;
import com.att.comet.common.repository.SubAccountRepository;
import com.att.comet.common.repository.TunnelTypeRepository;
import com.att.comet.dao.hibernate.bean.AccountClass;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.BackhaulType;
import com.att.comet.dao.hibernate.bean.DapnStatus;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.OrderStatus;

@Component
public class SearchStaticDataDAOImpl implements SearchStaticDataDAO {

	Logger logger = LoggerFactory.getLogger(SearchStaticDataDAOImpl.class);

	@Autowired
	AccountClassRepository accClassRepository;

	@Autowired
	AdminConfigRepository adminConfigRepository;

	@Autowired
	BackhaulTypeRepository backhaulTypeRepository;

	@Autowired
	OrderStatusRepository orderStatusRepository;

	@Autowired
	DapnStatusRepository dapnStatusRepository;

	@Autowired 
	DataCenterNameRepository dataCenterNameRepository;

	@Autowired
	SubAccountRepository subAccountRepository;

	@Autowired
	DapnRepository dapnRepository;

	@Autowired
	TunnelTypeRepository tunnelTypeRepository;

	public List<AccountClass> findAccountClassList() {
		return accClassRepository.getAccountClassList();
	}

	public AdminCategory findAccTypeListByCategoryId(Long adminCategoryId) {
		return adminConfigRepository.getAdminCategoryId(adminCategoryId);
	}

	public List<BackhaulType> findBackhaulTypeList() {
		return backhaulTypeRepository.getBackhaulTypeList();
	}

	public List<OrderStatus> findOrderStatusList() {
		return orderStatusRepository.getOrderStatusList();
	}

	public List<DapnStatus> findDapnStatusList() {
		return dapnStatusRepository.findByDapnStatusIdNotIn(1005L);
	}

	public AdminCategory findApnSizeListByCategoryId(Long adminCategoryId) {
		return adminConfigRepository.getAdminCategoryId(adminCategoryId);
	}

	public List<DataCenter> findDataCenterList() {
		return dataCenterNameRepository.getDataCenterNameList();
	}

	public List<String> findCompanyList() {
		return subAccountRepository.getCompanyNameList();
	}

	public List<String> findBatchIdList() {
		return dapnRepository.getBatchIdList();
	}

	public List<String> findTunnelTypeList() {
		return tunnelTypeRepository.getTunnelTypeList();
	}
}
