package com.att.comet.common.constant;

/**
 * Contains all possible Role types related to a Comet Order.
 */
public class TypeRole {

	/**
	 * ORDER_SUBMITTER
	 */
	public static final long ORDER_SUBMITTER = 1001L;

	/**
	 * ORDER_APPROVER
	 */
	public static final long ORDER_APPROVER = 1002L;

	/**
	 * ORDER_MANAGER
	 */
	public static final long ORDER_MANAGER = 1003L;

	/**
	 * NETWORK_IMPLEMENTATION
	 */
	public static final long NETWORK_IMPLEMENTATION = 1004L;

	/**
	 * CCS_PM
	 */
	public static final long CCS_PM = 1005L;

	/**
	 * COMET_ADMIN
	 */
	public static final long COMET_ADMIN = 1006L;

	/**
	 * GUEST
	 */
	public static final long GUEST = 1007L;

	/**
	 * IT_OPS
	 */
	public static final long IT_OPS = 1008L;

}
