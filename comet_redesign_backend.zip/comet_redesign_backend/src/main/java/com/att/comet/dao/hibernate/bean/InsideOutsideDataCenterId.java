package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class InsideOutsideDataCenterId implements java.io.Serializable {

	private static final long serialVersionUID = 1516727200858200529L;
	private Long dataCenterId;
	private String insideOutside;

	public InsideOutsideDataCenterId() {
		super();
	}

	public InsideOutsideDataCenterId(Long dataCenterId, String insideOutside) {
		super();
		this.dataCenterId = dataCenterId;
		this.insideOutside = insideOutside;
	}

	/**
	 * @return the dataCenterId
	 */
	@Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return dataCenterId;
	}

	/**
	 * @param dataCenterId the dataCenterId to set
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	/**
	 * @return the insideOutside
	 */
	@Column(name = "INSIDE_OUTSIDE", nullable = false, length = 100)
	public String getInsideOutside() {
		return insideOutside;
	}

	/**
	 * @param insideOutside the insideOutside to set
	 */
	public void setInsideOutside(String insideOutside) {
		this.insideOutside = insideOutside;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataCenterId == null) ? 0 : dataCenterId.hashCode());
		result = prime * result + ((insideOutside == null) ? 0 : insideOutside.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InsideOutsideDataCenterId other = (InsideOutsideDataCenterId) obj;
		if (dataCenterId == null) {
			if (other.dataCenterId != null)
				return false;
		} else if (!dataCenterId.equals(other.dataCenterId))
			return false;
		if (insideOutside == null) {
			if (other.insideOutside != null)
				return false;
		} else if (!insideOutside.equals(other.insideOutside))
			return false;
		return true;
	}
}
