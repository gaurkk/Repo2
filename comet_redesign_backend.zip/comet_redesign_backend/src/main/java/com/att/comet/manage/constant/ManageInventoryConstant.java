package com.att.comet.manage.constant;

public class ManageInventoryConstant {

	public static final String FAILED = "Failed";
	public static final String SUCCESS = "success";
	public static final String DAPN_FILE_HEADER_DOWNLOAD = "COMET-DAPN-INV-IMP-TEMP-VER1.0";
	public static final String PAT_FILE_HEADER_DOWNLOAD = "COMET-PAT-CHNL-IMP-TEMP-VER1.0";
	public static final String INOUT_INTERFACE_FILE_HEADER_DOWNLOAD = "COMET-INSIDE-OUTSIDE-INV-VER1.0";
	public static final String IMSI_MSISDN_FILE_HEADER_DOWNLOAD = "COMET-IMSI-MSISDN-INV-VER1.0";
	public static final String IMSI_MSISDN_TEMPLATE = "IMSI_MSISDN_Inventory.csv";
	public static final String IN_OUT_TEMPLATE = "INOUT_INTERFACE_Inventory.csv";
	public static final String INSIDE_OUTSIDE_PAT_TEMPLATE = "INSIDE_OUTSIDE_PAT_Inventory.csv";
	public static final String DAPN_TEMPLATE = "DAPN_Inventory.csv";
	public static final String EOR = "EOR";
	
	
}
