package com.att.comet.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import com.att.comet.audit.modal.ColumnData;
import com.att.comet.audit.modal.RowData;

/**
 * Service Utility Class
 */
public class ServiceUtils {

	/**
	 * Set the query parameters.
	 * 
	 * @param query
	 * @param bindParamMap
	 */
	@SuppressWarnings({ "rawtypes" })
	public static void setQueryParameters(Query query, Map<String, Object> bindParamMap) {
		Iterator<Map.Entry<String, Object>> iterator = bindParamMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<String, Object> entry = iterator.next();
			String key = entry.getKey();
			Object value = entry.getValue();

			if (value instanceof String) {
				query.setParameter(key, (String) value);
			} else if (value instanceof Long) {
				query.setParameter(key, (Long) value);
			} else if (value instanceof Integer) {
				query.setParameter(key, (Integer) value);
			} else if (value instanceof Character) {
				query.setParameter(key, (Character) value);
			} else if (value instanceof Collection) {
				query.setParameter(key, (Collection) value);
			} else if (value instanceof BigDecimal) {
				query.setParameter(key, (BigDecimal) value);
			}
		}
	}
	
	/**
	 * Gets the result set as List.
	 * 
	 * @param resultSet
	 * @return List<RowData>
	 * @throws SQLException
	 */
	public static List<RowData> getResultSetAsList(ResultSet resultSet) throws SQLException {
		List<RowData> returnList = null;
		if (resultSet != null) {
			returnList = new ArrayList<RowData>();
			while (resultSet.next()) {
				RowData rowData = new RowData();
				returnList.add(rowData);
				List<ColumnData> columnDataList = new ArrayList<ColumnData>();
				rowData.setColumnData(columnDataList);
				ResultSetMetaData metaData = resultSet.getMetaData();
				int numColumns = metaData.getColumnCount();
				for (int index = 1; index <= numColumns; index++) {
					ColumnData columnData = new ColumnData();
					String columnLabel = metaData.getColumnLabel(index);
					columnData.setColumnLabel(columnLabel);
					columnData.setColumnValue(resultSet.getObject(columnLabel));
					columnDataList.add(columnData);
				}
			}
		}
		return returnList;
	}
}