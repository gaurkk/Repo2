package com.att.comet.charts.result;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DApnListGridDisplayBO extends GridDisplayBO {

	private static final long serialVersionUID = 8937387762164960994L;

	private String dapnId;
	private String dapnStatus;
	private String apnType;
	private Long apnSize;
	private String apnName;
	private String pdpName;
	private Long pdpId;
	private Long udpdpId;
	private String mobileIp;
	private String dataCenter;
	private String createdBy;
	private String createdOn;
	private String orderId;
	private String batchId;

}
