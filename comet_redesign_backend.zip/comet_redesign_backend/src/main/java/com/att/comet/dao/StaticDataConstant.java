package com.att.comet.dao;

/**
 * Constants for static data in comet DB.
 */
public class StaticDataConstant {

	/**
	 * CLASS_1 account primary key.
	 */
	public static final Long ACCOUNT_CLASS_1 = 1001L;

	/**
	 * CLASS_2 account primary key.
	 */
	public static final Long ACCOUNT_CLASS_2 = 1002L;

	/**
	 * CLASS_3 account primary key.
	 */
	public static final Long ACCOUNT_CLASS_3 = 1003L;

	/**
	 * Saved order status primary key.
	 */
	public static final Long ORDER_STATUS_SAVED = 1001L;

	/**
	 * ORDER_STATUS_SUBMITTED primary key
	 */
	public static final Long ORDER_STATUS_SUBMITTED = 1002L;

	/**
	 * ORDER_STATUS_CANCELLED primary key
	 */
	public static final Long ORDER_STATUS_CANCELLED = 1003L;

	/**
	 * ORDER_STATUS_PENDING_FOR_OA_APPROVAL primary key
	 */
	public static final Long ORDER_STATUS_PENDING_FOR_OA_APPROVAL = 1004L;

	/**
	 * ORDER_STATUS_PENDING_FOR_OM_APPROVAL primary key
	 */
	public static final Long ORDER_STATUS_PENDING_FOR_OM_APPROVAL = 1005L;

	/**
	 * ORDER_STATUS_REJECTED_BY_OA primary key
	 */
	public static final Long ORDER_STATUS_REJECTED_BY_OA = 1006L;

	/**
	 * ORDER_STATUS_REJECTED_BY_OM primary key
	 */
	public static final Long ORDER_STATUS_REJECTED_BY_OM = 1007L;

	/**
	 * ORDER_STATUS_PENDING_FOR_PROVISIONING primary key
	 */
	public static final Long ORDER_STATUS_PENDING_FOR_PROVISIONING = 1008L;

	/**
	 * ORDER_STATUS_IN_PRODUCTION primary key
	 */
	public static final Long ORDER_STATUS_IN_PRODUCTION = 1009L;
	/**
	 * Order Status Cancel In Progress type primary key
	 */
	public static final Long ORDER_STATUS_CANCEL_IN_PROGRESS = 1010L;

	/**
	 * ORDER_STATUS_BACKHAUL_IWOS_CREATE_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_BACKHAUL_IWOS_CREATE_COMPLETED = 1011L;

	/**
	 * ORDER_STATUS_BACKHAUL_IWOS_CIRCUIT_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_BACKHAUL_IWOS_CIRCUIT_COMPLETED = 1012L;

	/**
	 * ORDER_STATUS_BACKHAUL_IWOS_STATUS_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_BACKHAUL_IWOS_STATUS_COMPLETED = 1013L;

	/**
	 * ORDER_STATUS_APPROVED_BY_OA primary key
	 */
	public static final Long ORDER_STATUS_APPROVED_BY_OA = 1016L;

	/**
	 * ORDER_STATUS_APPROVED_BY_OM primary key
	 */
	public static final Long ORDER_STATUS_APPROVED_BY_OM = 1017L;

	/**
	 * ORDER_STATUS_APN_BUILD_IWOS_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_APN_BUILD_IWOS_COMPLETED = 1018L;

	/**
	 * ORDER_STATUS_NI_APN_BUILD_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_NI_APN_BUILD_COMPLETED = 1019L;

	/**
	 * ORDER_STATUS_NI_CONFIRM_PREFLIGHT_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_NI_CONFIRM_PREFLIGHT_COMPLETED = 1020L;

	/**
	 * ORDER_STATUS_CCSPM_APN_IWOS_STATUS_COMPLETED primary key
	 */
	public static final Long ORDER_STATUS_CCSPM_APN_IWOS_STATUS_COMPLETED = 1021L;

	/**
	 * ORDER_STATUS_APN_BACKHAUL_IN_PROGRESS primary key
	 */
	public static final Long ORDER_STATUS_APN_BACKHAUL_IN_PROGRESS = 1049L;

	/**
	 * Order Status In Flight type primary key
	 */
	public static final Long ORDER_STATUS_IN_FLIGHT = 1022L;

	/**
	 * ORDER_STATUS_DECOMMISSION primary key
	 */
	public static final Long ORDER_STATUS_DECOMMISSION = 1023L;

	/**
	 * ORDER_STATUS_CHANGE_REQUEST primary key
	 */
	public static final Long ORDER_STATUS_CHANGE_REQUEST = 1024L;

	/**
	 * ORDER_STATUS_IWOS_REJECTED primary key
	 */
	public static final Long ORDER_STATUS_IWOS_REJECTED = 1045L;

	/**
	 * ORDER_STATUS_CCSPM_SUBMITTED_ORDER primary key
	 */
	public static final Long ORDER_STATUS_CCSPM_SUBMITTED_ORDER = 1050L;

	/**
	 * ORDER_STATUS_NI_SUBMITTED_ORDER primary key
	 */
	public static final Long ORDER_STATUS_NI_SUBMITTED_ORDER = 1051L;

	/**
	 * New order type primary key.
	 */
	public static final Long ORDER_TYPE_NEW = 1001L;

	/**
	 * CANCELLED order type primary key.
	 */
	public static final Long ORDER_TYPE_CANCELLED = 1002L;

	/**
	 * EXPEDITE order type primary key.
	 */
	public static final Long ORDER_TYPE_EXPEDITE = 1003L;

	/**
	 * CHANGE ORDER order type primary key.
	 */
	public static final Long ORDER_TYPE_CHANGE_ORDER = 1004L;

	/**
	 * CHANGE REQUEST order type primary key.
	 */
	public static final Long ORDER_TYPE_CHANGE_REQUEST = 1005L;

	/**
	 * DECOMMISSION order type primary key.
	 */
	public static final Long ORDER_TYPE_DECOMMISSION = 1006L;

	/**
	 * Mpls backhaul type primary key
	 */
	public static final Long BACKHAUL_TYPE_MPLS = 1004L;
	/**
	 * IVpn backhaul type primary key
	 */
	public static final Long BACKHAUL_TYPE_IVPN = 1002L;
	/**
	 * M2M backhaul type primary key
	 */
	public static final Long BACKHAUL_TYPE_M2M = 1006L;
	/**
	 * Internet backhaul type primary key
	 */
	public static final Long BACKHAUL_TYPE_INTERNET = 1005L;

	/**
	 * Order Contact type OA primary key
	 */
	public static final Long ORDER_CONTACT_TYPE_OA = 1004L;

	/**
	 * Order Contact type OS primary key
	 */
	public static final Long ORDER_CONTACT_TYPE_OS = 1003L;

	/**
	 * Order Contact Type IT Ops Primary Key
	 */
	public static final Long ORDER_CONTACT_TYPE_IT_OPS = 1024L;

	/**
	 * Dedicated Apn data center
	 */
	public static final Long DEDICATED_APN_DATA_CENTER = 1001L;

	/**
	 * Apn Addressing type Static
	 */
	public static final String ADDRESSING_TYPE_STATIC = "Static";

	/**
	 * Apn Addressing type Dynamic
	 */
	public static final String ADDRESSING_TYPE_DYNAMIC = "Dynamic";

	/**
	 * Apn Static Addressing type IPPT
	 */
	public static final String STATIC_ADDRESSING_TYPE_IPPT = "IPPT";

	/**
	 * Work Step id OS INCLUDED OA COMMENTS
	 */
	public static final Long WORK_STEP_OS_INCLUDED_OA = 3102L;

	/**
	 * Work Step id OS INCLUDED OM COMMENTS
	 */
	public static final Long WORK_STEP_OS_INCLUDED_OM = 3103L;

	/**
	 * Work Step id OS INCLUDED APN NI COMMENTS
	 */
	public static final Long WORK_STEP_OS_INCLUDED_APN_NI = 3104L;

	/**
	 * Work Step id OS INCLUDED BHI NI COMMENTS
	 */
	public static final Long WORK_STEP_OS_INCLUDED_BHI_NI = 3105L;

	/**
	 * Work Step id OS WORK_STEP_APN_REJECTED
	 */
	public static final Long WORK_STEP_APN_REJECTED = 3012L;

	/**
	 * Work Step id NI_ORDER_DATA_UPDATE
	 */
	public static final Long NI_ORDER_DATA_UPDATE = 3108L;

	/**
	 * Work Step id CCSPM_ORDER_DATA_UPDATE
	 */
	public static final Long CCSPM_ORDER_DATA_UPDATE = 3109L;

	/**
	 * Work Step id OS WORK_STEP_BHI_REJECTED
	 */
	public static final Long WORK_STEP_BHI_REJECTED = 3016L;

	/**
	 * Process Id for Expedite with CR EXPDEDITE_PROCESS
	 */
	public static final Long EXPDEDITE_PROCESS = 1018L;

	/**
	 * BUSINESS_STEP_STATUS_REJECTED
	 */
	public static final String BUSINESS_STEP_STATUS_REJECTED = "REJECTED";

	/**
	 * BUSINESS_STEP_STATUS_SUSPENDED
	 */
	public static final String BUSINESS_STEP_STATUS_SUSPENDED = "Suspended";

	/**
	 * BACKHAUL_IWOS_TICKET_STATUS_REJECTED
	 */
	public static final String BACKHAUL_IWOS_TICKET_STATUS_REJECTED = "BACKHAUL_IWOS_TICKET_STATUS_REJECTED";

	/**
	 * BACKHAUL_IWOS_TICKET_STATUS_SUSPENDED
	 */
	public static final String BACKHAUL_IWOS_TICKET_STATUS_SUSPENDED = "BACKHAUL_IWOS_TICKET_STATUS_SUSPENDED";

	public static final Long ORDER_CONTACT_TYPE_CCSPM = 1006L;
	public static final Long ORDER_CONTACT_TYPE_NI = 1007L;
	public static final Long ORDER_CONTACT_TYPE_OM = 1005L;
	public static final Long ORDER_CONTACT_TYPE_OSD = 1023L;
	public static final Long ORDER_CONTACT_TYPE_ADMIN = 1006L;
	
	public static final String INITIATE = "INITIATE";
}