package com.att.comet.common.exception;

/**
 * Error Constant
 * 
 * @author pd6080
 *
 */
public final class ErrorCodeConstant {

	public static final String FAILURE = "FAILURE";
	public static final String STATUS_CODE = "602";
	public static final String RESTRICTION_REQUEST_NOT_PROPER = "501";
	public static final String CHART_NAME_IS_NOT_PROPER = "502";

	/**
	 * No recent order found for the user
	 */
	public static final String NO_RECENT_ORDER_FOR_USER = "503";

	/**
	 * User NOT found
	 */
	public static final String COMET_USER_NTF = "USER_NTF_001";
	
	/**
	 * Role doest have User Info 
	 */
	public static final String COMET_ROLE_NTF = "ROLE_NTF_002";
	/**
	 * Entity not found
	 */
	public static final String COMET_ENTITY_NNF = "ENTITY_NTF_002";

	/**
	 * Record NOT found
	 */
	public static final String COMET_ANNOUNCEMENT_NTF = "RECORD_ANNC_NTF_001";

	/**
	 * INVALID REQUEST
	 */
	public static final String COMET_INVALID_REQUEST = "INVALID_REQUEST_001";
	
	/**
	 * Backhaul deletion status code
	 */
	public static final String BH_DELETE_STATUS_CODE = "504";
	
	/**
	 * Backhaul exception error code
	 */
	public static final String BACKHAUL_EXCEPTION = "BACKHAUL_EXCEPTION_001";
	
	public static final String FILE_NOT_UPLOAD = "FILE_NOT_UPLOAD_001";
	
	/** APN SAVE ERROR CODE */
	public static final String APN_NAME_EXIST ="APN001";
	
	public static final String PDP_NAME_GRT_ZERO ="APN002";
	
	public static final String APN_SAVE_ERROR ="APN003";
	
	public static final String APN_MOBILEPOOL_ERROR = "APN004";
	
	public static final String APN_ENTTARGET_RANGE_ERROR = "APN005";
	
	public static final String APN_TARGET_RANGE_ERROR = "APN006";
	
	public static final String APN_SPLIT_TUNNEL_RANGE_ERROR = "APN007";
	
	public static final String APN_ENTERPRISE_ADDRESS_ERROR = "APN008";
	
	public static final String APN_PDPIDINFO_ERROR = "APN009";
	
	public static final String APN_SAVE_HEALTH_CHECK_ERROR = "APN010";
	
	

}
