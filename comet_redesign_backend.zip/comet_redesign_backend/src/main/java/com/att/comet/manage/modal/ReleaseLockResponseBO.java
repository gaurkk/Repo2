package com.att.comet.manage.modal;

import java.util.List;
import java.util.Set;

import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.order.modal.OrderUserQueueBO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class ReleaseLockResponseBO extends CometGenericBO {
	private static final long serialVersionUID = 3299132413640474629L;
	
	List<OrderUserQueueBO> orderUserQueues; 
	Set<Long> reqLockOrderIds;
}
