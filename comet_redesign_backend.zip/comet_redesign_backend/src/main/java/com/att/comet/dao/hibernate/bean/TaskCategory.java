package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "TASK_CATEGORY")
@Data
public class TaskCategory implements Serializable{
	private static final long serialVersionUID = -5095132159088195487L;

	@Id
	@Column(name = "TASK_CATEGORY_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long taskCategoryId;
	
	@Column(name = "TASK_CATEGORY_DESC", nullable = true, length = 500)
	private String taskCategoryDesc;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "taskCategory")
	private List<OrderUserBpmTasks> orderUserBpmTasksList = new ArrayList<>();
	
}
