package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Persistent class for ExpediteInfo. mapped to ORDER_EXPEDITE_INFO table in the
 * database.
 */
@Entity
@Table(name = "ORDER_EXPEDITE_INFO")
public class ExpediteInfo implements Serializable {
	private static final long serialVersionUID = 7865027440033806025L;

	private Long orderId;
	private String requestedExpediteBuildDate;
	private String expediteReason;
	private String notes;
	private String expediteAction;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "ORDER_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId to orderId
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for requestedExpediteBuildDate. REQ_BUILD_COMPLETION_DATE
	 * mapped to REQ_BUILD_COMPLETION_DATE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "REQ_BUILD_COMPLETION_DATE")
	public String getRequestedExpediteBuildDate() {
		return requestedExpediteBuildDate;
	}

	/**
	 * @param requestedExpediteBuildDate to requestedExpediteBuildDate set.
	 */
	public void setRequestedExpediteBuildDate(String requestedExpediteBuildDate) {
		this.requestedExpediteBuildDate = requestedExpediteBuildDate;
	}

	/**
	 * Getter method for expediteReason. REASON_TO_EXPEDITE mapped to
	 * REASON_TO_EXPEDITE in the database table.
	 * 
	 * @return
	 */
	@Column(name = "REASON_TO_EXPEDITE")
	public String getExpediteReason() {
		return expediteReason;
	}

	/**
	 * @param expediteReason to expediteReason set.
	 */
	public void setExpediteReason(String expediteReason) {
		this.expediteReason = expediteReason;
	}

	/**
	 * Getter method for notes. EXPEDITE_NOTES mapped to EXPEDITE_NOTES in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXPEDITE_NOTES")
	public String getNotes() {
		return notes;
	}

	/**
	 * @param notes to notes set.
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * Getter method for expediteAction. EXPEDITE_ACTION mapped to EXPEDITE_ACTION
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EXPEDITE_ACTION")
	public String getExpediteAction() {
		return expediteAction;
	}

	/**
	 * @param expediteAction to String set.
	 */
	public void setExpediteAction(String expediteAction) {
		this.expediteAction = expediteAction;
	}

}
