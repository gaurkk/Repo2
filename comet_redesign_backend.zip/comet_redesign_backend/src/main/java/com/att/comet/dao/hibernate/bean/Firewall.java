package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "FIREWALL")
public class Firewall implements Serializable {
	private static final long serialVersionUID = -1364259342726373183L;
	
	private Long firewallId; 
	private Orders orders;
	private String optOutPacl;
	private String syncConfigForDcs;
	private String globalBlockList;
	private Set<OrderPaclTuples> orderPaclTuples = new HashSet<OrderPaclTuples>(0);
	
	/**
	 * Get Firewall Id
	 * @return
	 */
	@Id
	@Column(name = "FIREWALL_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_FIREWALL_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_FIREWALL_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_FIREWALL_ID")
	public Long getFirewallId() {
		return firewallId;
	}
	
	public void setFirewallId(Long firewallId) {
		this.firewallId = firewallId;
	}
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return orders;
	}
	
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	@Column(name = "OPT_OUT_PACL", length = 1)
	public String getOptOutPacl() {
		return optOutPacl;
	}

	public void setOptOutPacl(String optOutPacl) {
		this.optOutPacl = optOutPacl;
	}

	@Column(name = "SYNC_CONFIG_ALL_DC", length = 1)
	public String getSyncConfigForDcs() {
		return syncConfigForDcs;
	}

	public void setSyncConfigForDcs(String syncConfigForDcs) {
		this.syncConfigForDcs = syncConfigForDcs;
	}

	@Column(name = "GLOBAL_BLOCK_LIST", length = 4)
	public String getGlobalBlockList() {
		return globalBlockList;
	}

	public void setGlobalBlockList(String globalBlockList) {
		this.globalBlockList = globalBlockList;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "firewall")
	public Set<OrderPaclTuples> getOrderPaclTuples() {
		return this.orderPaclTuples;
	}

	public void setOrderPaclTuples(Set<OrderPaclTuples> orderPaclTuples) {
		this.orderPaclTuples = orderPaclTuples;
	}
}
