package com.att.comet.charts.util;

public class ChartsConstant {

	/**
	 * ALL_ORDER_CHART
	 */
	public static final String ALL_ORDER_CHART = "AllOrderChart";

	/**
	 * DC_ASSIGNMENT_CHART
	 */
	public static final String DC_ASSIGNMENT_CHART = "DcAssignmentChart";

	/**
	 * MY_ORDER_CHART
	 */
	public static final String MY_ORDER_CHART = "MyOrderChart";
	/**
	 * OSD_CHART
	 */
	public static final String OSD_CHART = "OSDChart";
	/**
	 * NI_CHART
	 */
	public static final String NI_CHART = "NIChart";
	/**
	 * TTU_CHART
	 */
	public static final String TTU_CHART = "TTUChart";
	/**
	 * IWOS_CHART
	 */
	public static final String IWOS_CHART = "IWOSChart";

	/**
	 * SCHEDULE_IWOS
	 */
	public static final String SCHEDULE_IWOS = "IWOS";

	/**
	 * SCHEDULE_TTU
	 */
	public static final String SCHEDULE_TTU = "TTU";

	/**
	 * GET_DEFAULT_VALUE_MAP
	 */
	public static final String GET_CHART_DROPDOWN_VALUE = "GET_CHART_DROPDOWN_VALUE";

}
