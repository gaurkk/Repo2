package com.att.comet.criteria.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.comet.criteria.SearchCriteria;
import com.att.comet.charts.result.ResultBO;

public abstract class CriteriaRenderer {
	private static final Logger logger = LoggerFactory.getLogger(CriteriaRenderer.class);

	/**
	 * Provide output depending on the criteria provided
	 * 
	 * @param criteria
	 * @return ResultBO
	 * @throws Exception
	 */
	public ResultBO getOutput(SearchCriteria criteria) throws Exception {
		logger.info("Starting method getOutput : ", this);
		ResultBO result = null;
		if (criteria != null && criteria.getRestrictions().size() > 0) {
			result = createExecuteQuery(criteria);
		}

		logger.info("Exiting method getOutput : ", this);
		return result;
	}

	/**
	 * Abstract method for creating and executing query
	 * 
	 * @param criteria
	 * @param session
	 * @return ResultBO
	 */
	public abstract ResultBO createExecuteQuery(SearchCriteria criteria) throws Exception;
}
