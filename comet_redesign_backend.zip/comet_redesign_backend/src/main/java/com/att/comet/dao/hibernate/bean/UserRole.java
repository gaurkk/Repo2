package com.att.comet.dao.hibernate.bean;


import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Persistent class for UserRole. Mapped to USER_ROLE table in the database.
 */
@Entity
@Table(name = "USER_ROLE", uniqueConstraints = @UniqueConstraint(columnNames = {
		"ATTUID", "ROLE_ID" }))
public class UserRole implements java.io.Serializable {

	private static final long serialVersionUID = 8731957748820137669L;
	
	private UserRoleId id;
	private Role role;
	private Users users;
	private char approved;
	private String itOpsDefault;

	/**
	 * No-argument constructor of the class.
	 */
	public UserRole() {
	}

	/**
	 * Multiple argument constructor of the class.
	 * @param id
	 * @param role
	 * @param users
	 */
	public UserRole(UserRoleId id, Role role, Users users) {
		this.id = id;
		this.role = role;
		this.users = users;
	}

	/**
	 * Getter method for id. 
	 * @return UserRoleId
	 */
	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "attuid", column = @Column(name = "ATTUID", nullable = false, length = 6)),
			@AttributeOverride(name = "roleId", column = @Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)) })
	public UserRoleId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(UserRoleId id) {
		this.id = id;
	}

	/**
	 * Getter method for role. 
	 * @return Role
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", nullable = false, insertable = false, updatable = false)
	public Role getRole() {
		return this.role;
	}

	/**
	 * @param role to role set.
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * Getter method for users. 
	 * @return Users
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ATTUID", nullable = false, insertable = false, updatable = false)
	public Users getUsers() {
		return this.users;
	}

	/**
	 * @param users to users set.
	 */
	public void setUsers(Users users) {
		this.users = users;
	}
	
	/**
	 * Getter method for approved. 
	 * @return char
	 */
	public char getApproved() {
		return approved;
	}

	/**
	 * @param approved to approved set.
	 */
	public void setApproved(char approved) {
		this.approved = approved;
	}

	/**
	 * Getter method for Getter method for approved..
	 * @return String
	 */
	@Column(name = "itopsdefault")
	public String getItOpsDefault() {
		return itOpsDefault;
	}

	/**
	 * @param itOpsDefault to itOpsDefault set.
	 */
	public void setItOpsDefault(String itOpsDefault) {
		this.itOpsDefault = itOpsDefault;
	}

}
