package com.att.comet.common.util;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CometValidationRegExp {

	private static Logger logger = LoggerFactory.getLogger(CometValidationRegExp.class);
	/**
	 * Method used to validate IP address range using regular expression. Here
	 * returns true if IP is between 1.0.0.0 to 255.255.255.255
	 * 
	 * @param iPaddress
	 * @return false if invalid data
	 */
	public static boolean validateIpAddress(String iPaddress) {
		final Pattern IP_PATTERN = Pattern
				.compile("^([0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}

	/**
	 * Method used to validate IP address range using regular expression. Here
	 * returns true if IP is between 1.0.0.0/00 to 255.255.255.255/99
	 * 
	 * @param iPaddress
	 * @return false if invalid data
	 */
	public static boolean validateDestinationIpAddress(String iPaddress) {
		final Pattern IP_PATTERN = Pattern
				.compile("^([0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}(\\/[0-9]{1,2})?$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}

	/**
	 * Method used to validate IP address range using regular expression. Here
	 * returns true if IP is between 1.0.0.0 to 255.255.255.255
	 * 
	 * @param iPaddress
	 * @return false if invalid data
	 */
	public static boolean validateIpAddressForEnterpriseIP(String iPaddress) {
		final Pattern IP_PATTERN = Pattern
				.compile("^([0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$");
		return IP_PATTERN.matcher(iPaddress).matches();
	}

	/**
	 * Method used to validate IP address subnet. Here returns true if subnet is
	 * only number & between 1 to 2
	 * 
	 * @param subNet
	 * @return false if invalid data
	 */
	public static boolean validateSubnet(String subNet) {
		final Pattern IP_SUBNET = Pattern.compile("^[0-9]{1,2}$");
		return IP_SUBNET.matcher(subNet).matches();
	}

	/**
	 * Method used to validate alphabets with space only.
	 * 
	 * @param name
	 * @return false if invalid data
	 */
	public static boolean aplhabetsWithSpace(String name) {
		final Pattern IP_SUBNET = Pattern.compile("^[a-zA-Z\\s]*$");
		return IP_SUBNET.matcher(name).matches();
	}

	/**
	 * Method used to validate alphabets with space,',' and & only.
	 * 
	 * @param name
	 * @return false if invalid data
	 */
	public static boolean aplhabetsWithSpecialCharacters(String name) {
		final Pattern VLAN = Pattern.compile("^[a-zA-Z0-9\\s,&]*$");
		logger.info("VLAN.matcher(name).matches("+VLAN.matcher(name).matches());
		return VLAN.matcher(name).matches();
	}

	/**
	 * Method used to validate alphNum with Special Chars except backslash'\'
	 * 
	 * @param name
	 * @return
	 */
	public static boolean containsValidSpecialCharacters(String name) {
		if (name == null || name.trim().isEmpty()) {
			return false;
		}
		final Pattern alphaNumWithSpecialChars = Pattern.compile("^[a-zA-Z0-9~`!@#$%^&*()_+={}|:;\"'<>,.?/\\[\\]-]*$");
		logger.info("alphaNumWithSpecialChars.matcher(name).find()::"+alphaNumWithSpecialChars.matcher(name).find());
		return alphaNumWithSpecialChars.matcher(name).find();
	}

	/**
	 * Method used to validate alphabets without space only.
	 * 
	 * @param string
	 * @return false if invalid data
	 */
	public static boolean alphaNumeric(String string) {
		final Pattern ALPHA_NUMERIC = Pattern.compile("^[a-zA-Z0-9]*$");
		return ALPHA_NUMERIC.matcher(string).matches();
	}

	/**
	 * Method used to validate alphabets with dot only.
	 * 
	 * @param anyStr
	 * @return false if invalid data
	 */
	public static boolean aplhaNumericWithDot(String anyStr) {
		final Pattern stringEntry = Pattern.compile("^[a-zA-Z0-9.]*$");
		return stringEntry.matcher(anyStr).matches();
	}
	
	/**
	 * Method used to validate alphabets with dot only.
	 * 
	 * @param anyStr
	 * @return false if invalid data
	 */
	public static boolean alphaNumericAccordingToPattern(String anyStr,String pattern) {
		final Pattern stringEntry = Pattern.compile("^[" + pattern +"]*$");
		return stringEntry.matcher(anyStr).matches();
	}

	/**
	 * Method used to validate Port Number, must have length 1 to 4
	 * 
	 * @param port
	 * @return false if invalid data
	 */
	public static boolean validatePortNumber(String port) {
		final Pattern IP_SUBNET = Pattern.compile("^[0-9]{1,4}$");
		return IP_SUBNET.matcher(port).matches();
	}

	/**
	 * Method used to validate the Numeric data.
	 * @param string
	 * @return boolean
	 */
	public static boolean invalidNumeric(String string) {
		final Pattern NUMERIC = Pattern.compile("[0-9]*$");
		boolean isValid = NUMERIC.matcher(string).matches(); 
		return !isValid;
	}	
	
	/**
	 * Method used to validate the Numeric data for subnet 1 to 32.
	 * @param string
	 * @return boolean
	 */
	public static boolean validSubnetRange(String string) {
		final Pattern NUMERIC = Pattern.compile("^[1-9]|[0-2][0-9]|3[0-2]$");
		boolean isValid = NUMERIC.matcher(string).matches(); 
		return isValid;
	}
	
	/**
	 * Method used to check the minimum length of the string.
	 * @param string
	 * @param pattern
	 * @param minLength
	 * @return boolean
	 */
	public static boolean checkMinLength(String string,String pattern,int minLength){
		final Pattern CHECK_LENGTH = Pattern.compile("(["+pattern+"]){"+minLength+",}$");
		boolean isValid = CHECK_LENGTH.matcher(string).matches();
		return !isValid;
	}
	
	/**
	 * Method used to check the alphaNumeric with space.
	 * @param string
	 * @return boolean
	 */
	public static boolean aplhaNumericWithSpace(String string) {
		final Pattern ALPHA_NUMERIC_SPACE = Pattern.compile("[a-zA-Z0-9\\s]*$");
		return ALPHA_NUMERIC_SPACE.matcher(string).matches();
	}
	
	/**
	 * Method used to check the max-length of the string.
	 * @param string
	 * @param pattern
	 * @param minLength
	 * @return boolean
	 */
	public static boolean checkMaxLength(String string,String pattern,int maxLength){
		final Pattern CHECK_LENGTH = Pattern.compile("(["+pattern+"]){0,"+maxLength+"}$");
		boolean isValid = CHECK_LENGTH.matcher(string).matches();
		return !isValid;
	}
	
	/**
	 * 
	 * @param email
	 * @return
	 */
	public static boolean isInValidEmail(String email){
		final Pattern EMAIL_STRING = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$");
		boolean isValid = EMAIL_STRING.matcher(email.trim()).matches();
		return  !isValid;
	}
	
/**
 * 
 * @param ipAddress
 * @param subnet
 * @return
 */
	public static boolean isSubnetValid(String ipAddress, int subnet) {
		logger.debug("Method OrderUtil.isSubnetValid(): Start");

		boolean valid = false;

		if (CommonUtils.isNotNullEmpty(ipAddress)) {

			String[] ipAdd = ipAddress.split("\\.");

			double sum = 0;
			double subnetSize = Math.pow(2, (32 - subnet));

			for (int octet = 0, power = 3; octet <= 3; octet++, power--) {

				sum += (Integer.parseInt(ipAdd[octet]) * Math.pow(256, power));

			}

			if (sum % subnetSize == 0) {
				valid = true;
			}
		}

		logger.debug("Method OrderUtil.isSubnetValid(): End");
		return valid;
	}
	
	/**
	 * This validation is for the primary rt long numeric range
	 * @param range
	 * @return
	 */
	public static boolean validatePrimaryRtRanges(String range) {
		final Pattern RANGE = Pattern.compile("(([0-9]+)|((([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])))");
		return RANGE.matcher(range).matches();
	}
	
	/**
	 * without dash
	 * @param name
	 * @return
	 */
	public static boolean specialCharacters(String name) {

		if (name == null || name.trim().isEmpty()) {
			return false;
		}
		final Pattern alphaNumWithSpecialChars = Pattern.compile("^[a-zA-Z0-9~`!@#$%^&*()_+={}|:;\"'<>,.?/\\[\\]]*$");
		return alphaNumWithSpecialChars.matcher(name).find();
	}
	
	/**
	 *  no backslash, with space
	 * @param name
	 * @return
	 */
	public static boolean containsValidSpecialCharactersWithSpace(String name) {
		if (name == null || name.trim().isEmpty()) {
			return false;
		}
		final Pattern alphaNumWithSpecialChars = Pattern.compile("^[a-zA-Z0-9\\s~`!@#$%^&*()_+={}|:;\"'<>,.?/\\[\\]-]*$");
		return alphaNumWithSpecialChars.matcher(name).find();
	}
	
	/**
	 * Method used to check the alphaNumeric with space.
	 * @param string
	 * @return boolean
	 */
	public static boolean aplhaNumericWithHyphen(String string) {
		final Pattern ALPHA_NUMERIC_SPACE = Pattern.compile("[a-zA-Z0-9-]*$");
		return !ALPHA_NUMERIC_SPACE.matcher(string).matches();
	}
	
	/**
	 * Method used to check the alphaNumeric with space.
	 * @param string
	 * @return boolean
	 */
	public static boolean aplhaNumericWithSpaceAndDot(String string) {
		final Pattern ALPHA_NUMERIC_SPACE = Pattern.compile("[a-zA-Z0-9-.\\s]*$");
		return !ALPHA_NUMERIC_SPACE.matcher(string).matches();
	}

}
