package com.att.comet;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.web.client.RestTemplate;

import com.att.comet.common.constant.CometCommonConstant;

@SpringBootApplication
public class CometServiceApplication {

	Logger log = LoggerFactory.getLogger(CometServiceApplication.class);
	public static void main(String[] args) {
	
		SpringApplication.run(CometServiceApplication.class, args);
	}
	 @Bean
	   public RestTemplate getRestTemplate() {
	      return new RestTemplate();
	   }
	
	@Bean
    public JndiDataSourceLookup getDSLookup() {
        return new JndiDataSourceLookup();
    }

    /**
     * Primary ds.
     *
     * @param env the env
     * @return the data source
     */
	
	  @Profile("dev")
	  @Bean
	  public DataSource getDevDS(@Autowired Environment env) {
		return getDSLookup().getDataSource(env.getProperty(CometCommonConstant.JNDINAME));
	  }
	 
	  @Profile("test")
	  @Bean
	  public DataSource getTestDS(@Autowired Environment env) {
		  return getDSLookup().getDataSource(env.getProperty(CometCommonConstant.JNDINAME));
	  }
	  
	  @Profile("stg")
	  @Bean
	  public DataSource getStgDS(@Autowired Environment env) { 
		  return  getDSLookup().getDataSource(env.getProperty(CometCommonConstant.JNDINAME));
	  }
	  
	  @Profile("uat")
	  @Bean
	  public DataSource getUatDS(@Autowired Environment env) { 
		  return  getDSLookup().getDataSource(env.getProperty(CometCommonConstant.JNDINAME));
	  }
	  
	  @Profile("prod")
	  @Bean
	  public DataSource getProdDS(@Autowired Environment env) { 
		  return  getDSLookup().getDataSource(env.getProperty(CometCommonConstant.JNDINAME));
	  }
}
