package com.att.comet.apn;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ApnHealthChkCustDestnIpBO implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long healthChkCustId;
	private String healthChkCustIpLbl;
	private String healthChkCustIpVal;
	// private DataCenter dataCenter;
	private Long dataCenterId;
	private String dataCenterName;

}
