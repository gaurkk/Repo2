package com.att.comet.configuration;

import static com.att.comet.security.constant.SecurityStaticConstants.*;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.att.comet.security.constant.SecurityConstants;
import com.att.comet.user.modal.RoleEnum;
import com.att.comet.user.modal.UserBO;
import com.att.comet.user.service.UserService;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

	@Autowired
	SecurityConstants secConstant;

	@Autowired
	UserService userService;

	public JWTAuthorizationFilter(AuthenticationManager authManager) {
		super(authManager);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		if (secConstant == null) {
			ServletContext servletContext = req.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils
					.getWebApplicationContext(servletContext);
			secConstant = webApplicationContext.getBean(SecurityConstants.class);
		}
		if (userService == null) {
			ServletContext servletContext = req.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils
					.getWebApplicationContext(servletContext);
			userService = webApplicationContext.getBean(UserService.class);
		}

		String header = req.getHeader(HEADER_STRING);

		if (header == null || !header.startsWith(TOKEN_PREFIX)) {
			chain.doFilter(req, res);
			return;
		}

		UsernamePasswordAuthenticationToken authentication = getAuthentication(req);

		SecurityContextHolder.getContext().setAuthentication(authentication);
		chain.doFilter(req, res);
	}

	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
		String token = request.getHeader(HEADER_STRING);
		if (token != null) {
			String attUid = JWT.require(Algorithm.HMAC512(secConstant.getSecret().getBytes())).build()
					.verify(token.replace(TOKEN_PREFIX, "")).getSubject();
			String firstName = JWT.require(Algorithm.HMAC512(secConstant.getSecret().getBytes())).build()
					.verify(token.replace(TOKEN_PREFIX, "")).getClaim("FirstName").asString();
			String lastName = JWT.require(Algorithm.HMAC512(secConstant.getSecret().getBytes())).build()
					.verify(token.replace(TOKEN_PREFIX, "")).getClaim("LastName").asString();
			Long roleId =  JWT.require(Algorithm.HMAC512(secConstant.getSecret().getBytes())).build()
					.verify(token.replace(TOKEN_PREFIX, "")).getClaim("RoleId").asLong();
			String env =  JWT.require(Algorithm.HMAC512(secConstant.getSecret().getBytes())).build()
					.verify(token.replace(TOKEN_PREFIX, "")).getClaim("Env").asString();
			if (StringUtils.isNotBlank(attUid) && StringUtils.isNotBlank(firstName)
					&& StringUtils.isNotBlank(lastName) && !Objects.isNull(roleId)) {
				if (userService.checkForExistingToken(attUid, roleId, env.toLowerCase(), token.substring(7))) {
					UserBO user = userService.getUser(attUid);
					if (user != null && StringUtils.isNotBlank(user.getAttuid()) && user.getRoleList() != null
							&& user.getRoleList().size() > 0) {
						if (StringUtils.isNotBlank(user.getFirstName()) && StringUtils.isNotBlank(user.getLastName())
								&& user.getFirstName().equalsIgnoreCase(firstName)
								&& user.getLastName().equalsIgnoreCase(lastName)) {
							String roles = user.getRoleList().stream()
									.filter(obj -> obj.getRoleId().equals(roleId)
											&& RoleEnum.getByRoleId(obj.getRoleId()) != null)
									.map(role -> "ROLE_" + RoleEnum.getByRoleId(role.getRoleId()).name())
									.collect(Collectors.joining(","));

							List<GrantedAuthority> grantedAuths = AuthorityUtils
									.commaSeparatedStringToAuthorityList(roles);
							return new UsernamePasswordAuthenticationToken(user.getAttuid(), null, grantedAuths);
						}
					}
				}
			}
			return null;
		}
		return null;
	}
}