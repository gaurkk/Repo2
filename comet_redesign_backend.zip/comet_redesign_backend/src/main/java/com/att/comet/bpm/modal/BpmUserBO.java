package com.att.comet.bpm.modal;

import lombok.Data;

@Data
public class BpmUserBO {
	private UserProfileBO profile;
	private UserCredentialsBO credentials;
}
