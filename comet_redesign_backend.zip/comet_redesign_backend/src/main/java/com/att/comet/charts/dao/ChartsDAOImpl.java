package com.att.comet.charts.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.util.CriteriaHelper;
import com.att.comet.dao.hibernate.bean.BackhaulType;

@Component
public class ChartsDAOImpl implements ChartsDAO {

	private static final Logger logger = LoggerFactory.getLogger(ChartsDAOImpl.class);

	@Autowired
	CriteriaHelper criteriaHelper;

	@PersistenceContext
	EntityManager em;

	public ResultBO getDataUsingCriteria(SearchCriteria searchCriteria)
			throws CometServiceException, CometDataException, Exception {
		logger.info("Starting method getDataUsingCriteria : ", this);

		ResultBO resultBO = null;
		resultBO = criteriaHelper.getOutput(searchCriteria);
		logger.info("Exiting method getDataUsingCriteria : ", this);
		return resultBO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BackhaulTypeBO> getBHType() throws CometServiceException, CometDataException {
		logger.info("Starting method getBHType : ", this);
		Query query = em.createQuery("from BackhaulType bh where bh.isActive='Y' ");
		List<BackhaulType> lstBackhaulType = query.getResultList();
		List<BackhaulTypeBO> lstBackhaulTypeBO = new ArrayList<BackhaulTypeBO>();
		BackhaulTypeBO backhaulTypeBO = null;

		if (lstBackhaulType != null && !lstBackhaulType.isEmpty()) {
			for (BackhaulType backhaulType : lstBackhaulType) {
				backhaulTypeBO = new BackhaulTypeBO();
				BeanUtils.copyProperties(backhaulType, backhaulTypeBO);
				lstBackhaulTypeBO.add(backhaulTypeBO);
			}
		}

		logger.info("Exiting method getBHType : ", this);
		return lstBackhaulTypeBO;
	}

}
