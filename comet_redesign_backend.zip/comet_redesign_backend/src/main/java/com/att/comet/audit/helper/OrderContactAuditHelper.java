package com.att.comet.audit.helper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;

import com.att.comet.audit.modal.OrderContactAuditBO;
import com.att.comet.audit.modal.RowData;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.modal.OrderContactInfoBO;

@Component
public class OrderContactAuditHelper {
	/**
	 * Returns Order Contact Audit Info.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return OrderContactAuditBO
	 * @throws SQLException
	 */
	public OrderContactAuditBO getOrderContactAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		OrderContactAuditBO orderContactConfigBO = null;
		Set<OrderContactInfoBO> contactInfoBOs = null;
		OrderContactInfoBO orderContactInfoBO = null;
		
		List<RowData> orderContactResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> orderContactInfoResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));

		if (orderContactResults != null) {
			orderContactConfigBO = new OrderContactAuditBO();
			contactInfoBOs = new HashSet<OrderContactInfoBO>();

			Object columnValueOrderContact = null;
			Object columnValueOrderContactInfo = null;
			for (RowData orderContactRow : orderContactResults) {

				columnValueOrderContact = orderContactRow.getColumnValue("order_contact_id");
				if (columnValueOrderContact != null) {
					orderContactConfigBO.setOrderContactId(((BigDecimal) columnValueOrderContact).longValue());
				}

				columnValueOrderContact = orderContactRow.getColumnValue("ORDER_ID");
				if (columnValueOrderContact != null) {
					orderContactConfigBO.setOrderId(((BigDecimal) columnValueOrderContact).longValue());
				}

				columnValueOrderContact = orderContactRow.getColumnValue("apn_id");
				if (columnValueOrderContact != null) {
					orderContactConfigBO.setApnId((String) columnValueOrderContact);
				}

				columnValueOrderContact = orderContactRow.getColumnValue("deployment_instruction");
				if (columnValueOrderContact != null) {
					orderContactConfigBO.setDeploymentInstruction((String) columnValueOrderContact);
				}
				
				if (orderContactInfoResults != null) {
					for (RowData orderContactInfoRow : orderContactInfoResults) {
						orderContactInfoBO = new OrderContactInfoBO();

					//	orderContactInfoBO.setOrderId(orderId);

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("order_contact_type_id");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setOrderContactType(((BigDecimal) columnValueOrderContactInfo).longValue());
						}

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("order_contact_id");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setOrderContactId(((BigDecimal) columnValueOrderContactInfo).longValue());
						}

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("email");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setEmail((String) columnValueOrderContactInfo);
						}

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("name");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setName((String) columnValueOrderContactInfo);
						}

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("phone");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setPhone((String) columnValueOrderContactInfo);
						}

						columnValueOrderContactInfo = orderContactInfoRow.getColumnValue("attuid");
						if (columnValueOrderContactInfo != null) {
							orderContactInfoBO.setAttuid((String) columnValueOrderContactInfo);
						}
						contactInfoBOs.add(orderContactInfoBO);
					}
				}
			}
			orderContactConfigBO.setContactInfoList(contactInfoBOs);
		}
		return orderContactConfigBO;
	}
}
