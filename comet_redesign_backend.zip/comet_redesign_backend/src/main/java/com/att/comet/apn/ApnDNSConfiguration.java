package com.att.comet.apn;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApnDNSConfiguration {
	private String sectionName ;
	
	private String dnsServerIp;
	
	private List<EnterpriseDnsServerBO> enterpriseDnsServerRanges;
	
	private String amplifyingInformation;
}
