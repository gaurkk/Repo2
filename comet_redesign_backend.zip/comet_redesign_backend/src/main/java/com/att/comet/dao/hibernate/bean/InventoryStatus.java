package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for InventoryStatus. Mapped to INVENTORY_STATUS table in the
 * database.
 */
@Entity
@Table(name = "INVENTORY_STATUS")
public class InventoryStatus implements Serializable {

	private static final long serialVersionUID = 3313160832423561981L;

	private Long inventoryStatusId;
	private String inventoryStatusName;
	private Set<DedicatedApn> dedicatedApns = new HashSet<DedicatedApn>(0);

	/**
	 * No-argument constructor of the class.
	 */
	public InventoryStatus() {
	}

	/**
	 * Getter method for inventoryStatusId. INVENTORY_STATUS_ID mapped to
	 * INVENTORY_STATUS_ID in the database table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "INVENTORY_STATUS_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getInventoryStatusId() {
		return this.inventoryStatusId;
	}

	/**
	 * @param inventoryStatusId to inventoryStatusId set.
	 */
	public void setInventoryStatusId(Long inventoryStatusId) {
		this.inventoryStatusId = inventoryStatusId;
	}

	/**
	 * Getter method for inventoryStatusName. INVENTORY_STATUS_NAME mapped to
	 * INVENTORY_STATUS_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "INVENTORY_STATUS_NAME", nullable = false, length = 100)
	public String getInventoryStatusName() {
		return this.inventoryStatusName;
	}

	/**
	 * @param inventoryStatusName to inventoryStatusName set.
	 */
	public void setInventoryStatusName(String inventoryStatusName) {
		this.inventoryStatusName = inventoryStatusName;
	}

	/**
	 * Getter method for dedicatedApns.
	 * 
	 * @return Set<DedicatedApn>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "inventoryStatus")
	public Set<DedicatedApn> getDedicatedApns() {
		return this.dedicatedApns;
	}

	/**
	 * @param dedicatedApns to dedicatedApns set.
	 */
	public void setDedicatedApns(Set<DedicatedApn> dedicatedApns) {
		this.dedicatedApns = dedicatedApns;
	}
}