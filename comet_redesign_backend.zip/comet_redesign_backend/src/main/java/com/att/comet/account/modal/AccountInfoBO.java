package com.att.comet.account.modal;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class AccountInfoBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String accountClass;
	private String isTsp = "N";
	private String isFeeWaiver = "N";
	private String fedralTaxId;
	private String waiverNotes;
	private String waiverFileName;
	private MultipartFile waiverAttachments;
	private byte[] waiverAttachment;
	private String userName;
	private String masterAccountName;
	private String ubcid;
	private String accountType;
	private String subAccountName;
	private String bcid;
	private String companyName;
	private String companyOwner;
	private String businessDesc;
	private String companyCountry;
	private String companyState;
	private String companyCity;
	private String companyStreetAddress;
	private String companyZip;
	private String billingCountry;
	private String billingState;
	private String billingCity;
	private String billingStreetAddress;
	private String billingZip;
	private String headquarterCountry;
	private String headquarterState;
	private String headquarterCity;
	private String headquarterStreetAddress;
	private String headquarterZip;
	private String cciContact;
	private String cciCountry;
	private String cciState;
	private String cciCity;
	private String cciZip;
	private String cciStreetAddress;
	private String cciDeskPhone;
	private String cciCellPhone;
	private String cciEmailAddress;
	private String cciDeskPhoneExtension;
	private String headquarterCityHid;
	private String billingCityHid;
	private String companyCityHid;
	private String cciCityHid;
	private String internalInitiativeAcName;
	private String productInitiativeAcName;
	private String cipn;
	private String check1;
	private String check2;
	private String check3;
	private String check4;
	private String masterAccountNameNew;
	private String masterAccountCatagoryList;
	private String ubcidNew;
	private String createdBy;
	private String createdOn;
	private String updatedBy;
	private String updatedOn;
	private String cciStateHidd;
	private String cciZipHidd;
	private String cciStreetAddHidd;
	private String cciCityHidd;
	private String errorMessage;

}
