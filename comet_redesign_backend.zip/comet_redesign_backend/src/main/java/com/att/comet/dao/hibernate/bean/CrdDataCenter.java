package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Persistent class for CrdDataCenter. Mapped with the CRD_DATA_CENTER table in
 * the database.
 */
@Entity
@Table(name = "CRD_DATA_CENTER")
public class CrdDataCenter implements Serializable {

	private static final long serialVersionUID = 2695486248648741976L;

	private CrdDataCenterId id;
	private Crd crd;
	private DataCenter dataCenter;
	private Character strictTcpEnfcEnabled;
	private Character testingRequired;
	private Date implementDate;
	private Date expirationDate;
	private Set<ConnectivityMatrix> connectivityMatrixes = new HashSet<ConnectivityMatrix>(0);

	/**
	 * Getter method for id.
	 * 
	 * @return CrdDataCenterId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "crdId", column = @Column(name = "CRD_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)) })
	public CrdDataCenterId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(CrdDataCenterId id) {
		this.id = id;
	}

	/**
	 * Getter method for crd.
	 * 
	 * @return Crd
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CRD_ID", nullable = false, insertable = false, updatable = false)
	public Crd getCrd() {
		return this.crd;
	}

	/**
	 * @param crd to crd set.
	 */
	public void setCrd(Crd crd) {
		this.crd = crd;
	}

	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * Getter method for strictTcpEnfcEnabled. STRICT_TCP_ENFC_ENABLED mapped to
	 * STRICT_TCP_ENFC_ENABLED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "STRICT_TCP_ENFC_ENABLED", length = 1)
	public Character getStrictTcpEnfcEnabled() {
		return this.strictTcpEnfcEnabled;
	}

	/**
	 * @param strictTcpEnfcEnabled to strictTcpEnfcEnabled set.
	 */
	public void setStrictTcpEnfcEnabled(Character strictTcpEnfcEnabled) {
		this.strictTcpEnfcEnabled = strictTcpEnfcEnabled;
	}

	/**
	 * Getter method for testingRequired. TESTING_REQUIRED mapped to
	 * TESTING_REQUIRED in the database table.
	 * 
	 * @return Character
	 */
	@Column(name = "TESTING_REQUIRED", length = 1)
	public Character getTestingRequired() {
		return this.testingRequired;
	}

	/**
	 * @param testingRequired to testingRequired set.
	 */
	public void setTestingRequired(Character testingRequired) {
		this.testingRequired = testingRequired;
	}

	/**
	 * Getter method for implementDate. IMPLEMENT_DATE mapped to IMPLEMENT_DATE in
	 * the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "IMPLEMENT_DATE")
	public Date getImplementDate() {
		return this.implementDate;
	}

	/**
	 * @param implementDate to implementDate set.
	 */
	public void setImplementDate(Date implementDate) {
		this.implementDate = implementDate;
	}

	/**
	 * Getter method for expirationDate. EXPIRATION_DATE mapped to EXPIRATION_DATE
	 * in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "EXPIRATION_DATE")
	public Date getExpirationDate() {
		return this.expirationDate;
	}

	/**
	 * @param expirationDate to expirationDate set.
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * Getter method for connectivityMatrixes.
	 * 
	 * @return Set<ConnectivityMatrix>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "crdDataCenter")
	public Set<ConnectivityMatrix> getConnectivityMatrixes() {
		return this.connectivityMatrixes;
	}

	/**
	 * @param connectivityMatrixes to connectivityMatrixes set.
	 */
	public void setConnectivityMatrixes(Set<ConnectivityMatrix> connectivityMatrixes) {
		this.connectivityMatrixes = connectivityMatrixes;
	}
}