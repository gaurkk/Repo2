package com.att.comet.common.constant;

public enum DapnInventoryStatus {

	AVAILABLE(1001L,"Available"),IN_ACTIVE(1002L,"In-Active"),RESERVED(1003L,"Reserved"),ASSIGNED(1004L,"Assigned"),HISTORY(1005l,"History");
	
	private final Long id;
	private final String name;
	
	/**
	 * constructor
	 * @param id
	 * @param name
	 */
	private DapnInventoryStatus(Long id, String name){
		this.id = id;
		this.name=name;
	}
	
	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	/**
	 * The method is used to get the status based upon the id of the status.
	 * 
	 * @param id
	 * @return DapnStatus, if parameter id is not null otherwise null.
	 */
	public static DapnInventoryStatus getStatus(Long id){
		for(DapnInventoryStatus dapnStatus: DapnInventoryStatus.values()){
			if(dapnStatus.getId().longValue()==id.longValue()){
				return dapnStatus;
			}
		}
		return null;
	}
	
}
