package com.att.comet.common.modal;

import org.apache.commons.lang3.StringUtils;

public enum StaticRoutingProtocol {
	BGP(new Long(1038), "BGP"),
	Static(new Long(1038), "Static");
	
	public Long getId() {
		return staticId;
	}

	public String getYesOrNo() {
		return staticName;
	}

	private final Long staticId;
	private final String staticName;

	public static StaticRoutingProtocol getEnum(String value) {
		StaticRoutingProtocol getStat = null;
		if (StringUtils.isNotBlank(value)) {
			for (StaticRoutingProtocol stat : StaticRoutingProtocol.values()) {
				if (stat.name().equalsIgnoreCase(value)) {
					getStat = stat;
					break;
				}
			}
		}
		return getStat;
	}

	private StaticRoutingProtocol(Long staticId, String staticName) {
		this.staticId = staticId;
		this.staticName = staticName;
	}
}