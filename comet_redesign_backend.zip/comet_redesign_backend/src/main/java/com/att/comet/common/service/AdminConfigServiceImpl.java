package com.att.comet.common.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.att.comet.common.dao.AdminConfigDAOImpl;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.RecordNotFoundException;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.dao.hibernate.bean.AdminCategory;
import com.att.comet.dao.hibernate.bean.AdminConfig;
import com.att.comet.order.modal.DataCenterBO;

@Service
public class AdminConfigServiceImpl implements AdminConfigService{

	Logger logger = LoggerFactory.getLogger(AdminConfigDAOImpl.class);

	private static final String GET_ANNOUNCEMENT = "getWelcomeAnnouncement";

	@Autowired
	AdminConfigDAOImpl adminConfigDAOImpl;

	@Autowired
	CometResponse<List<AdminConfigBO>> cometResponse;

	public List<AdminConfigBO> getWelcomeAnnouncement() {
		logger.info("Starting method getWelcomeAnnouncement : ", this);	
		AdminCategory adminCategory = adminConfigDAOImpl.findByCategoryId((long) 1053);
		Set<AdminConfig> adminConfigSet = adminCategory.getAdminConfigs();
		List<AdminConfigBO> announcementList = null;
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigSet)) {
			announcementList = new ArrayList<AdminConfigBO>();
			for (AdminConfig adminCofig : adminConfigSet) {
				if(adminCofig != null && adminCofig.getAdminCategory().getAdminCategoryId() != null) {
					adminConfigBO = new AdminConfigBO();
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					announcementList.add(adminConfigBO);
				}
			}
		}else {
			logger.info(GET_ANNOUNCEMENT + "::AdminConfig DAO is having NULL value::", this);
			throw new RecordNotFoundException("Data Not Found For Welcome Announcement");
		}

		logger.info("Exiting method getWelcomeAnnouncement : ", this);
		return announcementList;

	}

	public List<AdminConfigBO> getAdminConfigs(long adminCategoryId) {
		logger.info("Starting method getAdminConfigsByAdminCategoryId", this);
		AdminCategory adminCategory = adminConfigDAOImpl.findByCategoryId(adminCategoryId);
		Set<AdminConfig> adminConfigSet = adminCategory.getAdminConfigs();
		List<AdminConfigBO> adminConfigBOList = null;
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigSet)) {
			adminConfigBOList = new ArrayList<AdminConfigBO>();
			for (AdminConfig adminCofig : adminConfigSet) {
				if(adminCofig != null && adminCofig.getAdminCategory().getAdminCategoryId() != null) {
					adminConfigBO = new AdminConfigBO();
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					adminConfigBOList.add(adminConfigBO);
				}
			}
		}else {
			logger.debug("No data found in AdminConfig against AdminCategoryId : " + adminCategoryId, this);
			throw new RecordNotFoundException("Data Not Found For AdminCategoryId : " + adminCategoryId);
		}

		logger.debug("End method getAdminConfigsByAdminCategoryId", this);

		return adminConfigBOList;
	}

	@Override
	@Transactional
	public List<AdminConfigBO> getAdminConfigInfoList(Long adminCategoryId,String ccsmx,String dataCenterId) throws CometDataException {
		return adminConfigDAOImpl.getAdminConfigInfoList(adminCategoryId,ccsmx,dataCenterId);
	}

	public CometResponse<List<AdminConfigBO>> getMarketSegmentList() {
		logger.info("Starting method getMarketSegmentList : ", this);	
		AdminCategory adminCategory = adminConfigDAOImpl.findMarketSegmentByCategoryId((long) 1011);
		Set<AdminConfig> adminConfigSet = adminCategory.getAdminConfigs();
		List<AdminConfigBO> marketSegmentList = null;
		List<AdminConfigBO> sortedList;
		AdminConfigBO adminConfigBO = null;
		if (!CollectionUtils.isEmpty(adminConfigSet)) {
			marketSegmentList = new ArrayList<AdminConfigBO>();
			for (AdminConfig adminCofig : adminConfigSet) {
				if(adminCofig != null && adminCofig.getAdminCategory().getAdminCategoryId() != null) {
					adminConfigBO = new AdminConfigBO();
					adminConfigBO.setCategoryId(adminCofig.getAdminCategory().getAdminCategoryId());
					adminConfigBO.setCategoryValue(adminCofig.getCategoryValue());
					adminConfigBO.setDescription(adminCofig.getDescription());
					marketSegmentList.add(adminConfigBO);
				}
			}
			sortedList = marketSegmentList.stream().sorted(Comparator.comparing(AdminConfigBO::getCategoryValue)).collect(Collectors.toList());
			cometResponse.setMethodReturnValue(sortedList);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		}else {
			logger.info("AdminConfig DAO is having NULL value::", this);
			throw new RecordNotFoundException("Data Not Found For Market Segment List");
		}

		logger.info("Exiting method getMarketSegmentList : ", this);
		return cometResponse;

	}

	@Override
	@Transactional
	public List<DataCenterBO> getDataCenterNameList() throws CometDataException {
		return adminConfigDAOImpl.getDataCenterNameList();
	}
}
