package com.att.comet.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class IncorrectRequestOrHeaderInfoException extends RuntimeException
{
	private static final long serialVersionUID = 2711060466783447551L;

	public IncorrectRequestOrHeaderInfoException(String message) {
        super(message);
    }
}