package com.att.comet.manage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.InventoryTemplate;

@Repository
public interface ManageInventoryRepository extends JpaRepository<InventoryTemplate, Long> {

	List<InventoryTemplate> findDistinctByTemplateNameOrderByColumnNumberAsc(String templateName);
		
	@Query("select distinct templateName from InventoryTemplate")
	List<String> findDistinctTemplates();
}
