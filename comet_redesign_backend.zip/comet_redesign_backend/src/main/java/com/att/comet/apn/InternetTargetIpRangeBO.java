package com.att.comet.apn;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter 
@EqualsAndHashCode(callSuper=true)
public class InternetTargetIpRangeBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = 1667214780059072747L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long intTargetIpRangeId;
	private Long orderId;
	private String intTargetIpRange;

}
