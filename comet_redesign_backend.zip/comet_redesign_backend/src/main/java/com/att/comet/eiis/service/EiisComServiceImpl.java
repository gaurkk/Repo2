package com.att.comet.eiis.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.swing.JScrollBar;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.configuration.ApplicationConfig;
import com.att.comet.eiis.modal.AmpResponseBO;
import com.att.comet.eiis.modal.User;
import com.att.comet.eiis.modal.UserBean;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import springfox.documentation.spring.web.json.Json;

//@Service
@Component
public class EiisComServiceImpl implements EiisComService {
	private static final Logger logger = LoggerFactory.getLogger(EiisComServiceImpl.class);

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ApplicationConfig applicationConfig;

	private String EIIS_SERVICE_URL;

	@PostConstruct
	public void init() {
		EIIS_SERVICE_URL = applicationConfig.getEiisServiceUrl();
	}

	@Override
	@Transactional
	public AmpResponseBO create(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method create : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String createReqRelativeUrl = getRelativeUrl(CometCommonConstant.CREATE_REQUEST, orderId, null, attuid);
		logger.info("createReqRelativeUrl ="+createReqRelativeUrl, this );
		String requestUri = EIIS_SERVICE_URL.concat(createReqRelativeUrl);
		logger.info("requestUri ="+requestUri, this );

		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("Error on ampResponseBO for Create="+e.getMessage(), this );
			logger.error("Error on ampResponseBO for Create="+e.getMessage(), this );
		}

		logger.info("Exiting methode create.",this);
		return ampResponseBO; 
	}

	@Override
	@Transactional
	public AmpResponseBO cancel(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method cancel : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String cancelReqRelativeUrl = getRelativeUrl(CometCommonConstant.CANCEL_REQUEST, orderId, null, attuid);
		logger.info("cancelReqRelativeUrl="+cancelReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(cancelReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);

		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("Error on ampResponseBO for cancel="+e.getMessage(), this);
			logger.error("Error on ampResponseBO for cancel="+e.getMessage(), this);
		}

		logger.info("Exiting methode cancel.",this);
		return ampResponseBO; 
	}

	@Override
	@Transactional
	public AmpResponseBO status(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method status : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String statusReqRelativeUrl = getRelativeUrl(CometCommonConstant.STATUS_REQUEST, orderId, null, attuid);
		logger.info("statusReqRelativeUrl="+statusReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(statusReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);
		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("ERROR ON ampResponseBO for status="+e.getMessage(), this);
			logger.error("ERROR ON ampResponseBO for status="+e.getMessage(), this);
		}

		logger.info("Exiting methode status.",this);
		return ampResponseBO; 
	}
	
	@Override
	@Transactional
	public AmpResponseBO skip(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method skip : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String skipReqRelativeUrl = getRelativeUrl(CometCommonConstant.SKIP_REQUEST, orderId, null, attuid);
		logger.info("Skip ReqRelative Url="+skipReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(skipReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);
		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("ERROR ON ampResponseBO for skip="+e);
			logger.error("ERROR ON ampResponseBO for skip="+e);
		}

		logger.info("Exiting methode skip.",this);
		return ampResponseBO; 
	}
	
	@Override
	@Transactional
	public AmpResponseBO login(String userName, String password, String token) throws CometDataException,CometServiceException{
		logger.info("[UserName : " + (userName == null ? "" : userName) + "] "+ "Starting method login : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		UserBean userBean = new UserBean();
		User user = new User();
		user.setUsername(userName);
		user.setPassword(password);
		userBean.setUser(user);
		String loginReqRelativeUrl = relativeUrlForLogin(CometCommonConstant.LOGIN_REQUEST);
		logger.info("Login ReqRelative Url="+loginReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(loginReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);
		try {
			ampResponseBO = processLoginService(requestUri, token, userBean);
		}catch(Exception e) {
			logger.info("ERROR ON ampResponseBO for login="+e);
			logger.error("ERROR ON ampResponseBO for login="+e);
		}

		logger.info("Exiting methode login.",this);
		return ampResponseBO; 
	}
	
	@Override
	@Transactional
	public AmpResponseBO details(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method details : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String detailsReqRelativeUrl = getRelativeUrl(CometCommonConstant.DETAIL_REQUEST, orderId, null, attuid);
		logger.info("detailsReqRelativeUrl="+detailsReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(detailsReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);
		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("ERROR ON ampResponseBO for details="+e.getMessage(), this);
			logger.error("ERROR ON ampResponseBO for details="+e.getMessage(), this);
		}

		logger.info("Exiting methode details.",this);
		return ampResponseBO; 
	}

	@Override
	@Transactional
	public List<AmpResponseBO> createAccaRequest(Long orderId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method createAccaRequest : ", this);

		List<AmpResponseBO> ampResponseBO = new ArrayList<AmpResponseBO>();
		String detailsReqRelativeUrl = getRelativeUrl(CometCommonConstant.ACCA_CREATE_REQUEST, orderId, null, attuid);
		String requestUri = EIIS_SERVICE_URL.concat(detailsReqRelativeUrl);

		try {
			URI uri = new URI(requestUri);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("X-API-VERSION","1");
			headers.set("Authorization",token);   // or use headers.setBearerAuth("")
			HttpEntity<Object> requestHeaders = new HttpEntity<>(null, headers);

			ResponseEntity<AmpResponseBO[]> response = restTemplate.postForEntity(uri, requestHeaders, AmpResponseBO[].class);
			if (200 == response.getStatusCodeValue()) {
				ampResponseBO = Arrays.asList(response.getBody());
			}else {
				logger.info("REPOSNE IS NOT 200 , ACTUAL REPOSNE="+response.getStatusCodeValue(),this);	
				logger.error("REPOSNE IS NOT 200 , ACTUAL REPOSNE="+response.getStatusCodeValue(),this);	
			}

			logger.info("Return Create ACCA Response .",this);
			return ampResponseBO;
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for order id: " + orderId);
			throw e;
		} catch (Exception e) {
			logger.info("Error on ampResponseBO for createAccaRequest="+e.getMessage(), this );
			logger.error("Error on ampResponseBO for createAccaRequest="+e.getMessage(), this );
		}

		logger.info("Exiting methode createAccaRequest.",this);
		return null;
	}

	@Override
	@Transactional
	public AmpResponseBO accaStatus(Long orderId, String reqId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method accaStatus : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String detailsReqRelativeUrl = getRelativeUrl(CometCommonConstant.ACCA_STATUS_REQUEST, orderId, reqId, attuid);
		logger.info("detailsReqRelativeUrl="+detailsReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(detailsReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);
		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("ERROR ON AMP RESPONSE for accaStatus="+e.getMessage(), this);
			logger.error("ERROR ON AMP RESPONSE for accaStatus="+e.getMessage(), this);
		}

		logger.info("Exiting methode accaStatus.",this);
		return ampResponseBO; 	
	}

	@Override
	@Transactional
	public AmpResponseBO accaDetails(Long orderId, String reqId, String attuid, String token) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method accaDetails : ", this);
		AmpResponseBO ampResponseBO = new AmpResponseBO();
		String detailsReqRelativeUrl = getRelativeUrl(CometCommonConstant.ACCA_DETAIL_REQUEST, orderId, reqId, attuid);
		logger.info("detailsReqRelativeUrl="+detailsReqRelativeUrl, this);
		String requestUri = EIIS_SERVICE_URL.concat(detailsReqRelativeUrl);
		logger.info("requestUri="+requestUri, this);

		try {
			ampResponseBO = getEiisServiceResponse(requestUri, token, orderId);
		}catch(Exception e) {
			logger.info("ERROR ON AMP RESPONSE for accaDetails="+e.getMessage(), this);
			logger.error("ERROR ON AMP RESPONSE for accaDetails="+e.getMessage(), this);
		}

		logger.info("Exiting methode accaDetails.",this);
		return ampResponseBO; 	
	}

	private String getRelativeUrl(String requestType,Long orderId, String reqId, String attuid) throws CometServiceException{
		logger.info("Starting methode getRelativeUrl.",this);

		StringBuilder relativeUrl = new StringBuilder(CometCommonConstant.FORWARD_SLASH);
		relativeUrl.append(requestType).append(CometCommonConstant.FORWARD_SLASH);
		relativeUrl.append(orderId.toString()).append(CometCommonConstant.FORWARD_SLASH);
		if(null != reqId) {
			relativeUrl.append(reqId).append(CometCommonConstant.FORWARD_SLASH);
		}
		relativeUrl.append(attuid);

		logger.info("Exiting methode getRelativeUrl.",this);
		return relativeUrl.toString();
	}
	
	private String relativeUrlForLogin(String requestType) throws CometServiceException{
		logger.info("Starting methode relativeUrlForLogin.",this);

		StringBuilder relativeUrl = new StringBuilder(CometCommonConstant.FORWARD_SLASH);
		relativeUrl.append(requestType);

		logger.info("Exiting methode relativeUrlForLogin.",this);
		return relativeUrl.toString();
	}

	private AmpResponseBO getEiisServiceResponse(String requestUri, String token, Long orderId) throws CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getEiisServiceResponse : ", this);

		AmpResponseBO ampResponseBO = new AmpResponseBO();

		try {
			URI uri = new URI(requestUri);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("X-API-VERSION","1");
			headers.set("Authorization",token);   // or use headers.setBearerAuth("")
			HttpEntity<Object> requestHeaders = new HttpEntity<>(null, headers);

			ResponseEntity<AmpResponseBO> response = restTemplate.postForEntity(uri, requestHeaders, AmpResponseBO.class);
			HttpStatus statusCode = response.getStatusCode();

			if (200 == response.getStatusCodeValue()) {
				ampResponseBO = response.getBody();

				logger.info("Return response .",this);
				return ampResponseBO;
			}

		} catch (HttpStatusCodeException  e) { 
			logger.debug("URISyntaxException during URI generate for URL: " + e.getStatusCode().toString());
			ampResponseBO.setErrorCode(String.valueOf(e.getRawStatusCode()));
			ampResponseBO.setException("Failed");
			ampResponseBO.setHTTP_CODE(String.valueOf(e.getStatusCode().value()));
			if(null !=  e.getResponseBodyAsString() && !(e.getResponseBodyAsString().contains("<")) && null != new JsonParser().parse(e.getResponseBodyAsString()).getAsJsonObject().get("message")) {
				ampResponseBO.setMessage(new JsonParser().parse(e.getResponseBodyAsString()).getAsJsonObject().get("message").getAsString());
			}else {
				ampResponseBO.setMessage(e.getStatusCode().toString());
			}
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks: " + e.getMessage());
			ampResponseBO.setHTTP_CODE("500");
			ampResponseBO.setErrorCode("500");
			ampResponseBO.setMessage(e.getMostSpecificCause().toString());
			ampResponseBO.setException("Failed");
		} catch (Exception e) {
			logger.debug("error code ." + e.getMessage());
			ampResponseBO.setHTTP_CODE("500");
			ampResponseBO.setErrorCode("500");
			ampResponseBO.setMessage(e.getMessage());
			ampResponseBO.setException("Failed");
		}

		logger.info("Exiting methode getEiisServiceResponse.",this);
		return ampResponseBO;
	}
	
	private AmpResponseBO processLoginService(String requestUri, String token, UserBean userBean) throws CometServiceException{
		logger.info("Starting method processLoginService : ", this);
		AmpResponseBO ampResponseBO = new AmpResponseBO();
		try {
			URI uri = new URI(requestUri);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("X-API-VERSION","1");
			headers.set("Authorization",token);   // or use headers.setBearerAuth("")
			HttpEntity<Object> requestHeaders = new HttpEntity<>(userBean, headers);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, requestHeaders, String.class);
			if (200 == response.getStatusCodeValue()) {
				logger.info("Return response ."+response.getBody().toString());
				ampResponseBO.setHTTP_CODE("200");
				ampResponseBO.setRequestStatus("Success");
				ampResponseBO.setToken(response.getBody().toString());
				return ampResponseBO;
			}
		} catch (HttpStatusCodeException  e) { 
			logger.debug("URISyntaxException during URI generate for URL: " + e.getStatusCode().toString());
			ampResponseBO.setErrorCode(String.valueOf(e.getRawStatusCode()));
			ampResponseBO.setException("Failed");
			ampResponseBO.setHTTP_CODE(String.valueOf(e.getStatusCode().value()));
			if(null !=  e.getResponseBodyAsString() && !(e.getResponseBodyAsString().contains("<")) && null != new JsonParser().parse(e.getResponseBodyAsString()).getAsJsonObject().get("message")) {
				ampResponseBO.setMessage(new JsonParser().parse(e.getResponseBodyAsString()).getAsJsonObject().get("message").getAsString());
			}else {
				ampResponseBO.setMessage(e.getStatusCode().toString());
			}
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks: " + e.getMessage());
			ampResponseBO.setHTTP_CODE("500");
			ampResponseBO.setErrorCode("500");
			ampResponseBO.setMessage(e.getMostSpecificCause().toString());
			ampResponseBO.setException("Failed");
		} catch (Exception e) {
			logger.debug("error code ." + e.getMessage());
			ampResponseBO.setHTTP_CODE("500");
			ampResponseBO.setErrorCode("500");
			ampResponseBO.setMessage(e.getMessage());
			ampResponseBO.setException("Failed");
		}

		logger.info("Exiting methode getEiisServiceResponse.",this);
		return ampResponseBO;
	}
}
