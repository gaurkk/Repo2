package com.att.comet.dao.hibernate.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for BpmOrderProcessHistoryId.
 */
@Embeddable
public class BpmOrderProcessHistoryId implements java.io.Serializable {

	private static final long serialVersionUID = 2941310848182016675L;

	private Long processId;
	private Long orderId;
	private Long orderTypeId;
	private Long bpmStatusId;
	private Date processExecutedOn;
	private String userDecision;
	private Date userDecisionOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;

	/**
	 * No-argument constructor.
	 */
	public BpmOrderProcessHistoryId() {
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param processId
	 * @param orderId
	 * @param orderTypeId
	 * @param bpmStatusId
	 * @param processExecutedOn
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderProcessHistoryId(Long processId, Long orderId, Long orderTypeId, Long bpmStatusId,
			Date processExecutedOn, Date createdOn, Date updatedOn) {
		this.processId = processId;
		this.orderId = orderId;
		this.orderTypeId = orderTypeId;
		this.bpmStatusId = bpmStatusId;
		this.processExecutedOn = processExecutedOn;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Multiple argument constructor.
	 * 
	 * @param processId
	 * @param orderId
	 * @param orderTypeId
	 * @param bpmStatusId
	 * @param processExecutedOn
	 * @param userDecision
	 * @param userDecisionOn
	 * @param comments
	 * @param createdOn
	 * @param updatedOn
	 */
	public BpmOrderProcessHistoryId(Long processId, Long orderId, Long orderTypeId, Long bpmStatusId,
			Date processExecutedOn, String userDecision, Date userDecisionOn, String comments, Date createdOn,
			Date updatedOn) {
		this.processId = processId;
		this.orderId = orderId;
		this.orderTypeId = orderTypeId;
		this.bpmStatusId = bpmStatusId;
		this.processExecutedOn = processExecutedOn;
		this.userDecision = userDecision;
		this.userDecisionOn = userDecisionOn;
		this.comments = comments;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for processId PROCESS_ID mapped to PROCESS_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Column(name = "PROCESS_ID", nullable = false, precision = 12, scale = 0)
	public Long getProcessId() {
		return this.processId;
	}

	/**
	 * @param processId to processId set.
	 */
	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for orderTypeId. ORDER_TYPE_ID mapped to ORDER_TYPE_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderTypeId() {
		return this.orderTypeId;
	}

	/**
	 * @param orderTypeId to orderTypeId set.
	 */
	public void setOrderTypeId(Long orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	/**
	 * Getter method for bpmStatusId. BPM_STATUS_ID mapped to BPM_STATUS_ID in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "BPM_STATUS_ID", nullable = false, precision = 12, scale = 0)
	public Long getBpmStatusId() {
		return this.bpmStatusId;
	}

	/**
	 * @param bpmStatusId to bpmStatusId set.
	 */
	public void setBpmStatusId(Long bpmStatusId) {
		this.bpmStatusId = bpmStatusId;
	}

	/**
	 * Getter method for processExecutedOn. PROCESS_EXECUTED_ON mapped to
	 * PROCESS_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "PROCESS_EXECUTED_ON", nullable = false)
	public Date getProcessExecutedOn() {
		return this.processExecutedOn;
	}

	/**
	 * @param processExecutedOn to processExecutedOn set.
	 */
	public void setProcessExecutedOn(Date processExecutedOn) {
		this.processExecutedOn = processExecutedOn;
	}

	/**
	 * Getter method for userDecision. USER_DECISION mapped to USER_DECISION in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "USER_DECISION", length = 100)
	public String getUserDecision() {
		return this.userDecision;
	}

	/**
	 * @param userDecision to userDecision set.
	 */
	public void setUserDecision(String userDecision) {
		this.userDecision = userDecision;
	}

	/**
	 * Getter method for userDecisionOn. USER_DECISION_ON mapped to USER_DECISION_ON
	 * in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "USER_DECISION_ON")
	public Date getUserDecisionOn() {
		return this.userDecisionOn;
	}

	/**
	 * @param userDecisionOn to userDecisionOn set.
	 */
	public void setUserDecisionOn(Date userDecisionOn) {
		this.userDecisionOn = userDecisionOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof BpmOrderProcessHistoryId))
			return false;
		BpmOrderProcessHistoryId castOther = (BpmOrderProcessHistoryId) other;

		return (this.getProcessId() == castOther.getProcessId()) && (this.getOrderId() == castOther.getOrderId())
				&& (this.getOrderTypeId() == castOther.getOrderTypeId())
				&& (this.getBpmStatusId() == castOther.getBpmStatusId())
				&& ((this.getProcessExecutedOn() == castOther.getProcessExecutedOn())
						|| (this.getProcessExecutedOn() != null && castOther.getProcessExecutedOn() != null
								&& this.getProcessExecutedOn().equals(castOther.getProcessExecutedOn())))
				&& ((this.getUserDecision() == castOther.getUserDecision())
						|| (this.getUserDecision() != null && castOther.getUserDecision() != null
								&& this.getUserDecision().equals(castOther.getUserDecision())))
				&& ((this.getUserDecisionOn() == castOther.getUserDecisionOn())
						|| (this.getUserDecisionOn() != null && castOther.getUserDecisionOn() != null
								&& this.getUserDecisionOn().equals(castOther.getUserDecisionOn())))
				&& ((this.getComments() == castOther.getComments()) || (this.getComments() != null
						&& castOther.getComments() != null && this.getComments().equals(castOther.getComments())))
				&& ((this.getCreatedOn() == castOther.getCreatedOn()) || (this.getCreatedOn() != null
						&& castOther.getCreatedOn() != null && this.getCreatedOn().equals(castOther.getCreatedOn())))
				&& ((this.getUpdatedOn() == castOther.getUpdatedOn()) || (this.getUpdatedOn() != null
						&& castOther.getUpdatedOn() != null && this.getUpdatedOn().equals(castOther.getUpdatedOn())));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getProcessId().intValue();
		result = 37 * result + (int) this.getOrderId().intValue();
		result = 37 * result + (int) this.getOrderTypeId().intValue();
		result = 37 * result + (int) this.getBpmStatusId().intValue();
		result = 37 * result + (getProcessExecutedOn() == null ? 0 : this.getProcessExecutedOn().hashCode());
		result = 37 * result + (getUserDecision() == null ? 0 : this.getUserDecision().hashCode());
		result = 37 * result + (getUserDecisionOn() == null ? 0 : this.getUserDecisionOn().hashCode());
		result = 37 * result + (getComments() == null ? 0 : this.getComments().hashCode());
		result = 37 * result + (getCreatedOn() == null ? 0 : this.getCreatedOn().hashCode());
		result = 37 * result + (getUpdatedOn() == null ? 0 : this.getUpdatedOn().hashCode());
		return result;
	}

}
