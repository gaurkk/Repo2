package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name = "FIRSTNET_DATACENTERS") 
public class FirstnetDatacenters implements Serializable{ 
 
	/** 
	 * 
	 */ 
	private static final long serialVersionUID = -94092477985356810L; 
	private Long dataCenterId; 
	private String seconaryTertiary; 
 
	/** 
	 * Getter method for dataCenterId. DATA_CENTER_ID mapped to DATA_CENTER_ID 
	 * in the database table.The sequence is used to generate the ids. 
	 * 
	 * @return Long 
	 */ 
	@Id 
	@Column(name = "DATA_CENTER_ID", precision = 12, scale = 0) 
	public Long getDataCenterId() { 
		return dataCenterId; 
	} 
	/** 
	 * @param dataCenterId 
	 *            to dataCenterId set. 
	 */ 
	public void setDataCenterId(Long dataCenterId) { 
		this.dataCenterId = dataCenterId; 
	} 
	/** 
	 * Getter method for seconaryTertiary. DEFAULT_SECONDARY_TERTIARY mapped to DEFAULT_SECONDARY_TERTIARY 
	 * in the database table. 
	 * 
	 * @return Long 
	 */ 
	@Column(name = "DEFAULT_SECONDARY_TERTIARY", length = 30) 
	public String getSeconaryTertiary() { 
		return seconaryTertiary; 
	} 
	/** 
	 * @param seconaryTertiary 
	 *            to seconaryTertiary set. 
	 */ 
	public void setSeconaryTertiary(String seconaryTertiary) { 
		this.seconaryTertiary = seconaryTertiary; 
	} 
 
 
 
 
}