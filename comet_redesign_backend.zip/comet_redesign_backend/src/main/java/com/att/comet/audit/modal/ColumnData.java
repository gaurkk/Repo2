package com.att.comet.audit.modal;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class ColumnData extends CometGenericBO {	 
	private static final long serialVersionUID = -343147074395225829L;

	private String columnLabel;
	private Object columnValue;
}
