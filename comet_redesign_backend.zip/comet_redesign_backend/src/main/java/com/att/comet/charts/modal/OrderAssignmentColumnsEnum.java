package com.att.comet.charts.modal;

public enum OrderAssignmentColumnsEnum {
	USERID("USERID", "string"), 
	COUNT("COUNT", "number"), 
	STYLE("STYLE", "string");

	private OrderAssignmentColumnsEnum(String orderAssignmentColumnName, String orderAssignmentColumnType) {
		this.columnName = orderAssignmentColumnName;
		this.columnType = orderAssignmentColumnType;
	}

	private String columnName;
	private String columnType;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

}
