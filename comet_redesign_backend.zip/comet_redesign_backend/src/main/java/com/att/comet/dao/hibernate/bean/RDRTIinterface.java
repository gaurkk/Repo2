package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "RDRT_INTERFACE")
public class RDRTIinterface implements java.io.Serializable {
	private static final long serialVersionUID = 3538013363480413683L;

	private int id;
	private String dataCenter;
	private String gwSgiContext;
	private String insideOutsideBase;
	private String rdRt;

	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_RDRT_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_RDRT_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_RDRT_ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "DATA_CENTER", length = 20)
	public String getDataCenter() {
		return dataCenter;
	}

	public void setDataCenter(String dataCenter) {
		this.dataCenter = dataCenter;
	}

	@Column(name = "GW_SGI_CONTEXT", length = 100)
	public String getGwSgiContext() {
		return gwSgiContext;
	}

	public void setGwSgiContext(String gwSgiContext) {
		this.gwSgiContext = gwSgiContext;
	}

	@Column(name = "RDRT", length = 30)
	public String getRdRt() {
		return rdRt;
	}

	public void setRdRt(String rdRt) {
		this.rdRt = rdRt;
	}

	@Column(name = "INSIDE_OUTSIDE_BASE", length = 100)
	public String getInsideOutsideBase() {
		return insideOutsideBase;
	}

	public void setInsideOutsideBase(String insideOutsideBase) {
		this.insideOutsideBase = insideOutsideBase;
	}
}
