package com.att.comet.help.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.HelpContent;

@Repository
public interface HelpContentRepository extends JpaRepository<HelpContent, Long> {
	@Query("select contentId, contentValue from HelpContent")
	List<String> getContentIdsAndValues();
}
