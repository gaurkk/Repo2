package com.att.comet.apn;

import java.io.Serializable;
import java.util.List;

import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.order.modal.DedicatedMobilePoolAddressBO;
import com.att.comet.order.modal.OrderValidationsBO;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class ApnBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = -2046298976029646343L;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String addressType;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character overRide;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character overRidePdp;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String ccsVRFName;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String updatedBy;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Long roleId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insideOusideStgPat;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String interimUpdateValue;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character ccsmx;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Character overRideCcsMx;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<PdpIdInfoBO> pdpIdInfoBOList;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<PersistentIpBO> persistentIps;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ApnSectionBasicInfo apnSectionBasicInfo;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ApnDomainProtocolConf apnDomainProtocolConf;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ApnHealthCheckInfo apnHealthCheckInfo;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ApnDNSConfiguration apnDNSConfiguration;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ApnRadiusInfo apnRadiusInfo;
	
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Long orderId; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String apnName; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String provisioningMethod; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String ipAddressSource; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String amplifyingInformation; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character fwdRadReqAuthEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character fwdRadReqMsgEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character mobileTerminationEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
 
	private Character mobileToMobileEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character mobileOriginateEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character radAccServEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String socFeatureCode; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character splitTunnelIntEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character splitTunnelMTEnabled; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Long totalMobilePoolSize; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Long uniqueIPAddressSize; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String dnsServerIp; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String domainName; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character migratedOrder = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String mobilePoolType; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character managedAvpn; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character noFirewall; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character ipbr = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character msp ; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String whitelistBlacklist; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String pcrf; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character splitAccessPAT; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character geoOptimization; 
 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character ccipRadius; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character mspEntAndMms ; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character ocs = 'Y'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String apnProtocol; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character firstNet = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character turboAppSupport = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character dscpPreservation = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private Character interimUpdate = 'N'; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String authenticationType; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String hostedRadiusType; 
 
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private List<EnterpriseTargetIpRangeBO> entTargetIpRanges;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<DedicatedMobilePoolAddressBO> dedicatedMobilePoolAddresses;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<MobilePoolAddressBO> mobilePoolAddressesList;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorCode;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorMessage;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private OrderValidationsBO orderValidationBO; 
	
	private Character isParentMigrated = 'N';
	
	private Character isParentBaseOrder = 'N';

}
