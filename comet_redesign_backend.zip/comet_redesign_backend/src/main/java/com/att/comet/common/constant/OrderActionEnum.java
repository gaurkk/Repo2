package com.att.comet.common.constant;

public enum OrderActionEnum {

	NEW_ORDER_SUBMITTED(1001L, "Order Submit (OS) - New Order"),
	CHANGE_ORDER_SUBMITTED(1002L, "Order Submit (OS) - Change Order"),
	BASE_ORDER_SUBMITTED(1003L, "Order Submit (OS) - Base Order"),
	
	CHANGE_REQUEST_INITIATED(1004L, "Change Request (OS) - Initiated"),
	CHANGE_REQUEST_CANCELLED(1005L, "Change Request (OS) - Cancelled"),
	CHANGE_REQUEST_SUBMITTED(1006L, "Change Request (OS) - Submitted"),	
	CHANGE_REQUEST_SUBMITTED_WITH_EXPEDITE(1007L, "Change Request (OS) - Submitted (With Expedite)"),
	
	
	EXPEDITE_SUBMITTED(1008L, "Expedite (OS) - Submitted"),
	
	
	ON_HOLD_REQUESTED(1009L, "On-hold (OSD) Requested"),
	
	ON_HOLD_CANCELLED(1010L, "On-hold (OSD) Cancelled"),

	ON_HOLD_RESOLVED(1011L, "On-hold (OSD) Resolved"),
	
		
	CANCEL_ORDER_REQUESTED(1012L, "Cancel Order (OS) - Requested"),
	
	
	DAPN_ORDER_CREATED(1013L, "Order Create (OS) - DAPN Order"),	
	DAPN_BASE_ORDER_CREATED(1014L, "Order Create (OS) - DAPN Base Order"),
	
	
	DAPN_ORDER_SUBMITTED(1015L, "Order Submit (OS) - DAPN Order"),		
	DAPN_BASE_ORDER_SUBMITTED(1016L, "Order Submit (OS) - DAPN Base Order"),	
	
	DAPN_RELEASED_REQUEST_SUBMITTED(1017L, "DAPN Release (OS) - Requested"),
	DAPN_RELEASED_REQUEST_CANCELLED(1018L, "DAPN Release (OS) - Cancelled"),	
	
	
	DAPN_CANCEL_ORDER_SUBMITTED(1019L, "Cancel Order (OS) - Submitted"),	
	DAPN_CANCEL_ORDER_REQUESTED(1020L, "Cancel Order (OS) - Requested");	
	

	private final Long id;

	private final String actionName;

	public Long getId() {
		return id;
	}

	public String getActionName() {
		return actionName;
	}

	public static OrderActionEnum getAction(Long id) {
		if (id != null) {
			for (OrderActionEnum action : OrderActionEnum.values()) {
				if (action.getId().longValue() == id.longValue()) {
					return action;
				}
			}
		}
		return null;
	}

	private OrderActionEnum(Long id, String actionName) {
		this.id = id;
		this.actionName = actionName;
	}
}
