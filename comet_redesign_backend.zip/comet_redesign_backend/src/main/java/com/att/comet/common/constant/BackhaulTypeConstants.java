package com.att.comet.common.constant;

public class BackhaulTypeConstants {
	/**
	 * Backhaul type of INTERNET_VPN
	 */
	public final static Long BACKHAUL_TYPE_INTERNET_VPN = 1002L;

	/**
	 * Backhaul type of MPLS
	 */
	public final static Long BACKHAUL_TYPE_MPLS = 1004L;

	/**
	 * Backhaul type of INTERNET
	 */
	public final static Long BACKHAUL_TYPE_INTERNET = 1005L;

	/**
	 * Backhaul type of M2M
	 */
	public final static Long BACKHAUL_TYPE_M2M = 1006L;
}