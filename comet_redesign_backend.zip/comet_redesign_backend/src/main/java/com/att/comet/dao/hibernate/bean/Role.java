package com.att.comet.dao.hibernate.bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

/**
 * Persistent class for Role. Mapped to ROLE table in the database.
 */
@Entity
@Table(name = "ROLE")
@Data
public class Role implements java.io.Serializable {

	private static final long serialVersionUID = -245361110065540839L;

	@Id
	@Column(name = "ROLE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long roleId;
	
	@Column(name = "ROLE_NAME", nullable = false, length = 50)
	private String roleName;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "role")
	private Set<UserRole> userRoles = new HashSet<UserRole>(0);
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "role")
	private List<OrderUserBpmTasks> orderUserBpmTasksList = new ArrayList<OrderUserBpmTasks>();

}
