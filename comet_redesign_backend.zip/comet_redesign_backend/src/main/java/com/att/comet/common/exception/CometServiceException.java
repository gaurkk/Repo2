/**
 * 
 */
package com.att.comet.common.exception;

import java.util.List;

/**
 * Base exception class for COMET service layer.
 */
public class CometServiceException extends CometException {

	private static final long serialVersionUID = 9036263879592175565L;

	/**
	 * CometServiceException constructor with String argument.
	 * 
	 * @param errorCode
	 */
	public CometServiceException(String errorCode) {
		super(errorCode);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 */
	public CometServiceException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public CometServiceException(String errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * CometServiceException constructor with multiple argument.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public CometServiceException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

	/**
	 * CometServiceException constructor with list of error messages.
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	public CometServiceException(List<String> errorList) {
		super(errorList);
	}
}