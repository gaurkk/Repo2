package com.att.comet.common.modal;

import org.apache.commons.lang3.StringUtils;

public enum BackhaulStatus {
	IN_PROGRESS(2, "IN_PROGRESS"),
	IN_PRODUCTION(1, "IN_PRODUCTION"); 


	public int getBackhaulStatusId() {
		return backhaulStatusId;
	}

	public String getBackhaulStatusName() {
		return backhaulStatusName;
	}

	private final int backhaulStatusId;
	private final String backhaulStatusName;

	public static BackhaulStatus getEnum(String value) {
		BackhaulStatus getStat = null;
		if (StringUtils.isNotBlank(value)) {
			for (BackhaulStatus stat : BackhaulStatus.values()) {
				if (stat.name().equalsIgnoreCase(value)) {
					getStat = stat;
					break;
				}
			}
		}
		return getStat;
	}

	private BackhaulStatus(int backhaulStatusId, String backhaulStatusName) {
		this.backhaulStatusId = backhaulStatusId;
		this.backhaulStatusName = backhaulStatusName;
	}

}
