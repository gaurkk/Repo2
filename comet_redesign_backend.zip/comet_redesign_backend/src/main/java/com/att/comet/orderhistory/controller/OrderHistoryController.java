package com.att.comet.orderhistory.controller;

	import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.order.modal.OrderAPNHistoryBO;
import com.att.comet.order.modal.OrderAPNHistoryDetailsBO;
import com.att.comet.order.modal.OrderCommentsBO;
import com.att.comet.order.modal.OrderHistoryActivityBO;
import com.att.comet.order.service.OrderServiceImpl;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderHistoryController {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderHistoryController.class);

	@Autowired
	OrderServiceImpl orderService;
	
	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;
	
	@Autowired
	OrderHistoryActivityBO  orderHistoryActivityBO;

	@Autowired
	OrderAPNHistoryBO  orderAPNHistoryBO;
	

	@Autowired
	OrderAPNHistoryDetailsBO orderAPNHistoryDetailsBO;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/orderHistoryActivities/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find order header tab details long with history tab functionality  ", notes = "Return order history tab functionality")
	public CometResponse<OrderHistoryActivityBO> getOrderHistoryActivities(@PathVariable("orderId") Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getOrderHistoryActivities : ", this);
		CometResponse<OrderHistoryActivityBO> cometResponse = new CometResponse<OrderHistoryActivityBO>();
		try {
			List<OrderCommentsBO>  OrderCommentsBOList= orderService.getOrderHistoryDetails(orderId);
			if(!CollectionUtils.isEmpty(OrderCommentsBOList)) {
				orderHistoryActivityBO.setOrderCommentsBOList(OrderCommentsBOList);
				cometResponse.setMethodReturnValue(orderHistoryActivityBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}
			else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getOrderHistoryActivities : ", this);
		return cometResponse;
		
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/orderProcessComments/{orderId}/{orderProcess}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find and return order process Comments lists  ", notes = "Return order process Comments lists functionality")
	public CometResponse<OrderHistoryActivityBO> getOrderProcessComments(@PathVariable("orderId") Long orderId,@PathVariable("orderProcess") String orderProcess) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+
				"[orderProcess : " + (orderProcess == null ? "" : orderProcess) + "] "+"Starting method getOrderProcessComments : ", this);
		CometResponse<OrderHistoryActivityBO> cometResponse = new CometResponse<OrderHistoryActivityBO>();
		try {
			List<OrderCommentsBO>  OrderCommentsBOList= orderService.getOrderProcessCommetsDetails(orderId,orderProcess);
			if(!CollectionUtils.isEmpty(OrderCommentsBOList)) {
				orderHistoryActivityBO.setOrderCommentsBOList(OrderCommentsBOList);
				cometResponse.setMethodReturnValue(orderHistoryActivityBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}
			else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+
				"[orderProcess : " + (orderProcess == null ? "" : orderProcess) + "] "+"Exiting method getOrderProcessComments : ", this);
		return cometResponse;
		
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/orderApnProcessComments/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find and return order process Comments lists only for APN   ", notes = "Return order process Comments lists functionality only for APN")
	public CometResponse<OrderHistoryActivityBO> getOrderApnProcessComments(@PathVariable("orderId") Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getOrderApnProcessComments : ", this);
		CometResponse<OrderHistoryActivityBO> cometResponse = new CometResponse<OrderHistoryActivityBO>();
		try {
			List<OrderCommentsBO>  OrderCommentsBOList= orderService.getOrderProcessCommetsDetails(orderId);
			if(!CollectionUtils.isEmpty(OrderCommentsBOList)) {
				orderHistoryActivityBO.setOrderCommentsBOList(OrderCommentsBOList);
				cometResponse.setMethodReturnValue(orderHistoryActivityBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}
			else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getOrderApnProcessComments : ", this);
		return cometResponse;
		
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getOrderAPNActivity/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find and return order APN activity list ", notes = "Return order APN activity functionality")
	public CometResponse<OrderAPNHistoryDetailsBO> getOrderAPNActivity(@PathVariable("orderId") Long orderId) {
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getOrderAPNActivity : ", this);
		CometResponse<OrderAPNHistoryDetailsBO> cometResponse = new CometResponse<OrderAPNHistoryDetailsBO>();
		try {
			OrderAPNHistoryBO[]  orderAPNHistoryList= orderService.getOrderAPNActivityDetails(orderId);
			if(null!=orderAPNHistoryList) {
				orderAPNHistoryDetailsBO.setOrderAPNHistoryBO(orderAPNHistoryList);
				cometResponse.setMethodReturnValue(orderAPNHistoryDetailsBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}
			else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Exiting method getOrderAPNActivity : ", this);
		return cometResponse;
		
	}
}
