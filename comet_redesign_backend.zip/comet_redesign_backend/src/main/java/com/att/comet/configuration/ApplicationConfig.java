package com.att.comet.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@Data
public class ApplicationConfig {
	@Value("${camunda.rest-url}")
	private String camundaRestUrl;
	
	@Value("${camunda.base-url}")
	private String camundaBaseUrl;
	
	@Value("${camunda.task-list-path}")
	private String camundaTaskListPath;

	@Value("${camunda.group-id}")
	private String camundaGroupId;
	
	@Value("${camunda.user-pwd}")
	private String camundaUserPwd;
	
	@Value("${ldap.host}")
	private String ldapHost;
	
	@Value("${ldap.port}")
	private String ldapPort;
	
	@Value("${ldap.init-context}")
	private String ldapInitContext;
	
	@Value("${icore.host}")
	private String icoreHost;
	
	@Value("${eiis.service-url}")
	private String eiisServiceUrl;
	
	@Value("${gbl.show}")
	private String gblShowFlag;
	
	@Value("${copy.show}")
	private String copyShowFlag;

}
