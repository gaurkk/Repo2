package com.att.comet.apn;

import java.util.List;

import com.att.comet.order.modal.ImsiMsisdnBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ApnHealthCheckInfo {

	private String sectionName;

	private List<ImsiMsisdnBO> imsiMsisdnList;

	private List<ApnHealthChkCustDestnIpBO> apnHealthChkCustDestnIpBOlst;

	private Character helthChkenable = 'Y';
	// private String helthChkCustdestnIp;

	private String helthChkType = "PING";

	private Long helthChkFrequency;

}
