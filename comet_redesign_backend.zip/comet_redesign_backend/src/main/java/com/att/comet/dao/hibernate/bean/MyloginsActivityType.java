package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name = "MYLOGINS_ACTIVITY_TYPE")
@Data
public class MyloginsActivityType implements java.io.Serializable {

	private static final long serialVersionUID = -8191966955217871482L;
	
	@Id
	@Column(name = "ACTIVITY_TYPE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	private Long activityTypeId;
	
	@Column(name = "ACTIVITY_TYPE_NAME", nullable = false, length = 100)
	private String activityTypeName;
	
	@Column(name = "DESCRIPTION", nullable = false, length = 1)
	private String description;
	
	@Column(name = "REMARK", nullable = false, length = 1)
	private String remark;
	
	@Column(name = "IS_ACTIVE", nullable = false, length = 1)
	private String isActive;
}
