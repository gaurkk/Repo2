package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.SubAccount;

@Repository
public interface SubAccountRepository extends JpaRepository<SubAccount,Long> {
	@Query("select distinct companyName from SubAccount order by companyName")
	List<String> getCompanyNameList();
}
