package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for OrderEvent. Mapped to ORDER_EVENT table in the database.
 */
@Entity
@Table(name = "ORDER_EVENT")
public class OrderEvent implements Serializable {

	private static final long serialVersionUID = 8312381070308743959L;

	private Long eventId;
	private Long orderId;
	private String eventName;
	private String eventStatus;
	private String comments;
	private String eventBy;
	private Date eventOn;
	private String orderProcess;

	/**
	 * Getter method for eventId. EVENT_ID mapped to EVENT_ID in the database table.
	 * The ids are generated using the sequence SEQ_EVENT_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "EVENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_EVENT_ID", strategy = "sequence", parameters = {
			@Parameter(name = "sequence", value = "SEQ_EVENT_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_EVENT_ID")
	public Long getEventId() {
		return this.eventId;
	}

	/**
	 * @param eventId to eventId set.
	 */
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for eventName. EVENT_NAME mapped to EVENT_NAME in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "EVENT_NAME", nullable = false, length = 100)
	public String getEventName() {
		return this.eventName;
	}

	/**
	 * @param eventName to eventName set.
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * Getter method for eventStatus. EVENT_STATUS mapped to EVENT_STATUS in the
	 * database table.
	 * 
	 * @return String
	 */
	@Column(name = "EVENT_STATUS", length = 100)
	public String getEventStatus() {
		return this.eventStatus;
	}

	/**
	 * @param eventStatus to eventStatus set.
	 */
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for eventBy. EVENT_BY mapped to EVENT_BY in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "EVENT_BY", nullable = false, length = 6)
	public String getEventBy() {
		return this.eventBy;
	}

	/**
	 * @param eventBy to eventBy set.
	 */
	public void setEventBy(String eventBy) {
		this.eventBy = eventBy;
	}

	/**
	 * Getter method for eventOn. EVENT_ON mapped to EVENT_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "EVENT_ON", nullable = false)
	public Date getEventOn() {
		return this.eventOn;
	}

	/**
	 * @param eventOn to eventOn set.
	 */
	public void setEventOn(Date eventOn) {
		this.eventOn = eventOn;
	}

	@Column(name = "ORDER_PROCESS", length = 100)
	public String getOrderProcess() {
		return orderProcess;
	}

	public void setOrderProcess(String orderProcess) {
		this.orderProcess = orderProcess;
	}
	
	
	
}