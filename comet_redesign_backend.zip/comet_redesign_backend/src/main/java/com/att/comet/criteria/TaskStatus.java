package com.att.comet.criteria;

public enum TaskStatus {
	ASSIGNED, UNASSIGNED, FINISHED, RESERVED, IN_PROGRESS;
}
