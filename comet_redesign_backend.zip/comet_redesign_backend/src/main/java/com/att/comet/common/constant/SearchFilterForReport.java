package com.att.comet.common.constant;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public enum SearchFilterForReport {
	EQUALS("equals", "STRING,NUMBER,BOOLEAN,IPRANGE"),
	DOES_NOT_EQUAL("does not equal", "STRING,NUMBER"),
	IS_GREATER_THAN("is greater than", "NUMBER"),
	IS_GREATER_THAN_OR_EQUAL_TO("is greater than or equal to", "NUMBER"),
	IS_LESS_THAN("is less than", "NUMBER"),
	IS_LESS_THAN_OR_EQUAL_TO("is less than or equal to", "NUMBER"),
	BEGINS_WITH("begins with", "STRING,NUMBER"),
	DOES_NOT_BEGIN_WITH("does not begin with", "STRING,NUMBER"),
	ENDS_WITH("ends with", "STRING,NUMBER"),
	DOES_NOT_ENDS_WITH("does not ends with", "STRING,NUMBER"),
	CONTAINS("contains", "STRING,NUMBER"),
	DOES_NOT_CONTAINS("does not contains", "STRING,NUMBER");
	
	private final String displayName;
	private final String dataTypes;
	
	
	public String getDisplayName() {
		return displayName;
	}

	public String getDataTypes() {
		return dataTypes;
	}

	private SearchFilterForReport(String displayName, String dataTypes){
		this.displayName = displayName;
		this.dataTypes = dataTypes; 
	}
	
	public static SearchFilterForReport getEnum(String value) {
		SearchFilterForReport getFilter = null;
		if (StringUtils.isNotBlank(value)) {
			for (SearchFilterForReport filter : SearchFilterForReport.values()) {
				if (filter.name().equalsIgnoreCase(value)) {
					getFilter = filter;
					break;
				}
			}
		}
		return getFilter;
	}

	public static List<SearchFilterForReport> getDataTypeEnums(String dataType) {
		List<SearchFilterForReport> filterEnums = new ArrayList<SearchFilterForReport>();
		if (StringUtils.isNotEmpty(dataType)) {
			for (SearchFilterForReport filter : SearchFilterForReport.values()) {
				if (filter.getDataTypes().indexOf(dataType) > -1) {
					filterEnums.add(filter);
				}
			}
		}
		return filterEnums;
	}
}
