package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.att.comet.dao.hibernate.bean.BpmOrderProcess;
import com.att.comet.dao.hibernate.bean.BpmOrderProcessId;

@Repository
public interface BpmOrderProcessRespository extends JpaRepository<BpmOrderProcess, BpmOrderProcessId> {

}
