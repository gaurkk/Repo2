package com.att.comet.criteria;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.att.comet.restriction.Restriction;

@Component
public final class SearchCriteriaImpl implements SearchCriteria {

	private static final long serialVersionUID = 26381327383735524L;

	private List<Restriction> lstRest = new ArrayList<Restriction>();
	private OutputFormat format = OutputFormat.GRID;
	private String baseQuery;
	private String chartName;
	private OtherDetails other;

	public SearchCriteriaImpl() {
		other = new OtherDetails();
	}

	public SearchCriteriaImpl(OutputFormat format) {
		this.format = format;
		other = new OtherDetails();
	}

	public String getBaseQuery() {
		return baseQuery;
	}

	public void setBaseQuery(String baseQuery) {
		this.baseQuery = baseQuery;
	}

	public String getChartName() {
		return chartName;
	}

	public void setChartName(String chartName) {
		this.chartName = chartName;
	}

	public SearchCriteriaImpl(OutputFormat format, OtherDetails other) {
		this.format = format;
		this.other = other;
		other = new OtherDetails();
	}

	@Override
	public void add(Restriction restriction) {
		lstRest.add(restriction);
	}

	@Override
	public SearchCriteria clone() throws CloneNotSupportedException {
		return (SearchCriteriaImpl) super.clone();

	}

	/**
	 * Setter for Output Format
	 * 
	 * @param format
	 */
	public void setFormat(OutputFormat format) {
		this.format = format;
	}

	/**
	 * Getter for Output Format
	 * 
	 * @return
	 */
	public OutputFormat getFormat() {
		return format;
	}

	@Override
	public List<Restriction> getRestrictions() {
		return lstRest;
	}

	@Override
	public void addOtherDetails(OtherDetails other) {
		this.other = other;
	}

	@Override
	public OtherDetails getOther() {
		return other;
	}

}
