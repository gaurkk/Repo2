package com.att.comet.apn.helper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.att.comet.apn.ApnBO;
import com.att.comet.apn.ApnCustomerRadiusBO;
import com.att.comet.apn.ApnDNSConfiguration;
import com.att.comet.apn.ApnDomainProtocolConf;
import com.att.comet.apn.ApnHealthCheckInfo;
import com.att.comet.apn.ApnHealthChkCustDestnIpBO;
import com.att.comet.apn.ApnRadiusBO;
import com.att.comet.apn.ApnRadiusInfo;
import com.att.comet.apn.ApnSectionBasicInfo;
import com.att.comet.apn.EnterpriseDnsServerBO;
import com.att.comet.apn.EnterpriseTargetIpRangeBO;
import com.att.comet.apn.InternetTargetIpRangeBO;
import com.att.comet.apn.MobilePoolAddressBO;
import com.att.comet.apn.PatPoolAddressBO;
import com.att.comet.apn.PdpIdInfoBO;
import com.att.comet.apn.PersistentIpBO;
import com.att.comet.apn.SplitTunnelIpRangeBO;
import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.constant.TypeOrder;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.repository.AdminConfigInfoRepository;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.Apn;
import com.att.comet.dao.hibernate.bean.ApnCustomerRadius;
import com.att.comet.dao.hibernate.bean.ApnHealthCheck;
import com.att.comet.dao.hibernate.bean.ApnHealthChkCustDestnIp;
import com.att.comet.dao.hibernate.bean.ApnRadius;
import com.att.comet.dao.hibernate.bean.ApnRadiusId;
import com.att.comet.dao.hibernate.bean.DapnInventory;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.EntTargetIpRange;
import com.att.comet.dao.hibernate.bean.EnterpriseDnsServer;
import com.att.comet.dao.hibernate.bean.ImsiDataCenterDetails;
import com.att.comet.dao.hibernate.bean.ImsiDataCenterDetailsId;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnDataCenterId;
import com.att.comet.dao.hibernate.bean.ImsiMsisdnInventory;
import com.att.comet.dao.hibernate.bean.IntTargetIpRange;
import com.att.comet.dao.hibernate.bean.MobilePoolAddress;
import com.att.comet.dao.hibernate.bean.OrderDataCenter;
import com.att.comet.dao.hibernate.bean.Orders;
import com.att.comet.dao.hibernate.bean.PatPoolAddress;
import com.att.comet.dao.hibernate.bean.PdpIdInfo;
import com.att.comet.dao.hibernate.bean.PersistentIp;
import com.att.comet.dao.hibernate.bean.SplitTunnelIpRange;
import com.att.comet.order.dao.OrderDAO;
import com.att.comet.order.modal.DedicatedApnBO;
import com.att.comet.order.modal.DedicatedMobilePoolAddressBO;
import com.att.comet.order.modal.ImsiMsisdnBO;
import com.att.comet.order.repository.ApnRepository;
import com.att.comet.order.repository.DapnInventoryRepository;
import com.att.comet.order.repository.OrderDataCenterRepository;

@Component
public class ApnHelper {

	private static final Logger logger = LoggerFactory.getLogger(ApnHelper.class);

	@PersistenceContext
	EntityManager em;

	@Autowired
	OrderDAO orderDAO;
	
	@Autowired
	DapnInventoryRepository dapnInventoryRepository;

	@Autowired
	AdminConfigInfoRepository adminConfigInfoRepository;

	@Autowired
	OrderDataCenterRepository odcRepository;
	
	@Autowired
	ApnRepository apnRepository;
	
	public ApnBO populateApnInfo(Apn apn) {
		logger.info("[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method populateApnInfo : ",
				this);
		ApnBO apnBO = new ApnBO();
		ApnSectionBasicInfo apnSectionBasicInfo = new ApnSectionBasicInfo();
		ApnDomainProtocolConf apnDomainProtocolConf = new ApnDomainProtocolConf();
		ApnHealthCheckInfo apnHealthCheckInfo = new ApnHealthCheckInfo();
		ApnDNSConfiguration apnDNSConfiguration = new ApnDNSConfiguration();
		ApnRadiusInfo apnRadiusInfo = new ApnRadiusInfo();
		List<OrderDataCenter> odcList = odcRepository.findByOrders_OrderId(apn.getOrderId());
		//////////////// ApnSectionBasicInfo///////////////
		apnSectionBasicInfo = getApnSectionBasicInfo(apn);
		if (null != apnSectionBasicInfo) {
			apnBO.setApnSectionBasicInfo(apnSectionBasicInfo);
		}
		//////////////// End ApnSectionBasicInfo///////////////

		///////////////////// apnDomainProtocolConf//////////////
		apnDomainProtocolConf = getApnDomainProtocolConf(apn,odcList);
		if (null != apnDomainProtocolConf) {
			apnBO.setApnDomainProtocolConf(apnDomainProtocolConf);
		}
		//// END of apnDomainProtocolConf/////////////

		/////////// APN Health Check ///////////
		apnHealthCheckInfo = getApnHealthCheckInfo(apn);
		if (null != apnHealthCheckInfo) {
			apnBO.setApnHealthCheckInfo(apnHealthCheckInfo);
		}
		////// END APN Health Check ///////////////////////

		/////// APN DNS Configuration///////////////////
		apnDNSConfiguration = getApnDNSConfiguration(apn,odcList);
		if (null != apnDNSConfiguration) {
			apnBO.setApnDNSConfiguration(apnDNSConfiguration);
		}
		//////// END APN DNS Configuration///////////////////

		////////////// Fetch ApnRadiusInfo///////////
		apnRadiusInfo = getApnRadiusInfo(apn,odcList);
		if (null != apnRadiusInfo) {
			apnBO.setApnRadiusInfo(apnRadiusInfo);
		}
		/////////// END Fetch ApnRadiusInfo/////////
		apnBO.setCcsVRFName(apn.getCcsVRFName());
		apnBO.setInsideOusideStgPat(apn.getInsideOusideStgPat());
		
		// Fetch PersistentIps()
		if (!CollectionUtils.isEmpty(apn.getPersistentIps())) {
			List<PersistentIp> persistentIpList = apn.getPersistentIps().stream().collect(Collectors.toList());
			PersistentIpBO persistentIpBO = new PersistentIpBO();
			List<PersistentIpBO> persistentIpBOList = new ArrayList<PersistentIpBO>();
			for (PersistentIp persistentIp : persistentIpList) {
				persistentIpBO.setPersistentIpId(persistentIp.getPersistentIpId());
				persistentIpBO.setIpAddress(persistentIp.getIpAddress());
				persistentIp.getUsername();
				persistentIp.getPassword();
				persistentIpBOList.add(persistentIpBO);
			}
			apnBO.setPersistentIps(persistentIpBOList);
		} else {
			logger.error("EntTargetIpRanges is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch PersistentIps()
		logger.info("[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method populateApnInfo : ",
				this);
		return apnBO;

	}

	/**
	 * getApnSectionBasicInfo
	 * 
	 * @param apnBO
	 * @param orderId
	 * @return
	 */
	private ApnSectionBasicInfo getApnSectionBasicInfo(Apn apn) {
		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method getApnSectionBasicInfo : ",
				this);
		ApnSectionBasicInfo apnSectionBasicInfo = new ApnSectionBasicInfo();
		apnSectionBasicInfo.setSectionName("Apn Basic Info");
		apnSectionBasicInfo.setApnName(apn.getApnName());
		apnSectionBasicInfo.setOrderId(apn.getOrderId());
		apnSectionBasicInfo.setMigratedOrder(apn.getMigratedOrder());
		apnSectionBasicInfo.setIpbr(apn.getIpbrFlag());
		apnSectionBasicInfo.setFirstNet(apn.getOrders().getFirstNetEpc() == null ? 'N' : apn.getOrders().getFirstNetEpc());
		apnSectionBasicInfo.setCcsmx(apn.getCcsmx());
		apnSectionBasicInfo.setOverRideCcsMx(apn.getOverRideCcsMx());
		apnSectionBasicInfo.setManagedAvpn(apn.getManagedAvpn());
		apnSectionBasicInfo.setOverRide(apn.getOverRide());// overrideAPN
		apnSectionBasicInfo.setProvisioningMethod(apn.getProvisioningMethod());
		apnSectionBasicInfo.setMsp(apn.getMsp());
		apnSectionBasicInfo.setWhitelistBlacklist(apn.getWhitelistBlacklist());
		apnSectionBasicInfo.setTurboAppSupport(apn.getTurboAppSupport());
		apnSectionBasicInfo.setNoFirewall(apn.getNoFirewall());
		try {
			apnSectionBasicInfo.setDataCenterDetails(orderDAO.getApnValidDCAndBH(apn.getOrderId(), false));
		} catch (CometDataException e) {
			logger.debug(" Not able to fetch data center ::: OrderId ::" + apn.getOrderId() + "]:: " + this);

		}

		apnSectionBasicInfo.setMspEntAndMms(apn.getMspEntAndMms());
		// Fetch PdpIdInfos
		if (!CollectionUtils.isEmpty(apn.getPdpIdInfos())) {
			List<PdpIdInfo> pdpIdInfoList = apn.getPdpIdInfos().stream().collect(Collectors.toList());
			List<PdpIdInfoBO> pdpIdInfoBOList = new ArrayList<PdpIdInfoBO>();
			for (PdpIdInfo pdpIdInfo : pdpIdInfoList) {
				PdpIdInfoBO pdpIdInfoBO = new PdpIdInfoBO();
				pdpIdInfo.getApn();
				pdpIdInfoBO.setPdpId(pdpIdInfo.getPdpId());
				pdpIdInfoBO.setAutoPdpId(pdpIdInfo.getAutoPdpId());
				pdpIdInfoBO.setUserPdpId(pdpIdInfo.getUserPdpId());
				pdpIdInfoBO.setBasicPdpId(pdpIdInfo.getBasicPdpId());
				pdpIdInfoBO.setAutoPdpName(pdpIdInfo.getAutoPdpName());
				pdpIdInfoBOList.add(pdpIdInfoBO);
			}
			apnSectionBasicInfo.setPdpIdInfoBOList(pdpIdInfoBOList);
		} else {
			logger.error("PdpIdInfo is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch PdpIdInfos
		apnSectionBasicInfo.setOverRidePdp(apn.getOverRidePdp());

		//CCS-MX calculation based on APN and Backhaul selections
		if (apnSectionBasicInfo.getOverRideCcsMx() == null || apnSectionBasicInfo.getOverRideCcsMx().equals('N')) {
			if (null!=apn.getOrders().getFirstNetEpc() && apn.getOrders().getFirstNetEpc().equals('Y')) {
				apnSectionBasicInfo.setCcsmx('Y');
			} else {
				if ((apn.getOrders().getOrderType().getOrderTypeId().equals(TypeOrder.NEW.getId())
						&& apn.getOrders().getOrderStatus().getOrderStatusId() == 1001L)
						|| (apn.getOrders().getChangeRequest() != null
								&& apn.getOrders().getChangeRequest().equals('I'))) {
					if (apn.getIpAddressSource() != null
							&& (apn.getIpAddressSource().equalsIgnoreCase("PrivateWithPATPortAddressTranslation"))) {
						apnSectionBasicInfo.setCcsmx('N');
					} else if ((apnSectionBasicInfo.getDataCenterDetails().isM2m())
							|| (apnSectionBasicInfo.getIpbr() != null && apnSectionBasicInfo.getIpbr().equals('Y'))
							|| (apnSectionBasicInfo.getDataCenterDetails().isMpls()
									&& !apnSectionBasicInfo.getDataCenterDetails().isIVPN()
									&& !apnSectionBasicInfo.getDataCenterDetails().isInternet())
							|| ((!apnSectionBasicInfo.getDataCenterDetails().isMpls()
									&& apnSectionBasicInfo.getDataCenterDetails().isIVPN()
									&& !apnSectionBasicInfo.getDataCenterDetails().isInternet()))
							|| ((!apnSectionBasicInfo.getDataCenterDetails().isMpls()
									&& !apnSectionBasicInfo.getDataCenterDetails().isIVPN()
									&& apnSectionBasicInfo.getDataCenterDetails().isInternet())
									&& (apn.getIpAddressSource() != null && (apn.getIpAddressSource()
											.equalsIgnoreCase("PublicATTProvided")
											|| apn.getIpAddressSource().equalsIgnoreCase("PublicCustomerProvided"))))) {
						apnSectionBasicInfo.setCcsmx('Y');
					} else {
						apnSectionBasicInfo.setCcsmx('N');
					}
				}
			}
		}
		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method getApnSectionBasicInfo : ",
				this);
		return apnSectionBasicInfo;
	}

	/**
	 * getApnDomainProtocolConf
	 * 
	 * @param apnBO
	 * @param orderId
	 * @return
	 */
	private ApnDomainProtocolConf getApnDomainProtocolConf(Apn apn,List<OrderDataCenter> odcList) {
		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method getApnSectionBasicInfo : ",
				this);
		String staticAddressType;
		ApnDomainProtocolConf apnDomainProtocolConf = new ApnDomainProtocolConf();
		apnDomainProtocolConf.setSectionName("Apn Domain Protocol Configuration");
		if (StringUtils.isEmpty(apn.getSocFeatureCode()) || !("EXPS").equals(apn.getSocFeatureCode())) {
			apnDomainProtocolConf.setIsExpress('N');
		} else {
			apnDomainProtocolConf.setIsExpress('Y');
		}
		apnDomainProtocolConf.setSocFeatureCode(apn.getSocFeatureCode());
		apnDomainProtocolConf.setDomainName(apn.getDomainName());
		if (null != apn.getAddressType()) {
			if (apn.getAddressType().equals(CometCommonConstant.DYNAMIC)) {
				staticAddressType = CometCommonConstant.DYNAMIC;
			} else {
				staticAddressType = CometCommonConstant.STATIC;
			}
			apnDomainProtocolConf.setStaticAddressType(staticAddressType);
		}
		apnDomainProtocolConf.setPcrf(apn.getPcrf());
		apnDomainProtocolConf.setOcs(apn.getOcs());
		apnDomainProtocolConf.setApnProtocol(apn.getApnProtocol());
		apnDomainProtocolConf.setIpAddressSource(apn.getIpAddressSource());
		apnDomainProtocolConf.setUniqueIPAddressSize(apn.getUniqueIpAddressSize());
		apnDomainProtocolConf.setTotalMobilePoolSize(apn.getTotalMobilePoolSize());
		if (null != apn.getMobileToMobileEnabled()) {
			apnDomainProtocolConf.setMobileToMobileEnabled(apn.getMobileToMobileEnabled());
		}
		apnDomainProtocolConf.setMobileTerminationEnabled(apn.getMobileTerminationEnabled());
		apnDomainProtocolConf.setMobileOriginateEnabled(apn.getMobileOriginateEnabled());
		apnDomainProtocolConf.setGeoOptimization(apn.getGeoOptimization());
		apnDomainProtocolConf.setSplitAccessPAT(apn.getSplitAccessPAT());
		apnDomainProtocolConf.setMobilePoolType(apn.getMobilePoolType());
		apnDomainProtocolConf.setDscpPreservation(apn.getDscpPreservation());
		apnDomainProtocolConf.setSplitTunnelIntEnabled(apn.getSplitTunnelIntEnabled());
		apnDomainProtocolConf.setSplitTunnelMTEnabled(apn.getSplitTunnelMtEnabled());
		apnDomainProtocolConf.setCcipRadius(apn.getCcipRadius());
		apnDomainProtocolConf.setInsideOusideStgPat(apn.getInsideOusideStgPat());
		// Fetch EntTargetIpRanges()
		if (!CollectionUtils.isEmpty(apn.getEntTargetIpRanges())) {
			List<EntTargetIpRange> entTargetIpRangesList = apn.getEntTargetIpRanges().stream()
					.collect(Collectors.toList());
			List<EnterpriseTargetIpRangeBO> enterpriseTargetIpRangeBOList = new ArrayList<EnterpriseTargetIpRangeBO>();
			for (EntTargetIpRange entTargetIpRange : entTargetIpRangesList) {
				EnterpriseTargetIpRangeBO entTargetIpRangeBO = new EnterpriseTargetIpRangeBO();
				entTargetIpRangeBO.setEntTargetIpRangeId(entTargetIpRange.getEntTargetIpRangeId());
				entTargetIpRangeBO.setEntTargetIpRange(entTargetIpRange.getEntTargetIpRange());
				entTargetIpRangeBO.setEntTargetIpRangeType(null == entTargetIpRange.getEntTargetIpRangeType() ? "FIREWALL" : entTargetIpRange.getEntTargetIpRangeType());
				entTargetIpRangeBO.setApnProtocol(entTargetIpRange.getApnProtocol());
				enterpriseTargetIpRangeBOList.add(entTargetIpRangeBO);
			}
			apnDomainProtocolConf.setEntTargetIpRanges(enterpriseTargetIpRangeBOList);
		} else {
			logger.error("EntTargetIpRanges is null for ORDER_ID Initiated::[" + apn.getOrderId() + "]", this);
			List<EnterpriseTargetIpRangeBO> enterpriseTargetIpRangeBOList = new ArrayList<EnterpriseTargetIpRangeBO>();
			EnterpriseTargetIpRangeBO entTargetIpRangeBO = new EnterpriseTargetIpRangeBO();
			entTargetIpRangeBO.setEntTargetIpRangeId(null);
			entTargetIpRangeBO.setEntTargetIpRange(null);
			entTargetIpRangeBO.setEntTargetIpRangeType(null);
			entTargetIpRangeBO.setApnProtocol(null);
			enterpriseTargetIpRangeBOList.add(entTargetIpRangeBO);
			apnDomainProtocolConf.setEntTargetIpRanges(enterpriseTargetIpRangeBOList);
			logger.error("EntTargetIpRanges is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch EntTargetIpRanges()

		// Fetch MobilePoolAddresses
		if (!CollectionUtils.isEmpty(apn.getMobilePoolAddresses())) {
			List<MobilePoolAddress> mobilePoolAddressList = apn.getMobilePoolAddresses().stream()
					.collect(Collectors.toList());
			List<MobilePoolAddressBO> mobilePoolAddressBOList = new ArrayList<MobilePoolAddressBO>();
			for (MobilePoolAddress mobilePoolAddress : mobilePoolAddressList) {
				MobilePoolAddressBO mobilePoolAddressBO = new MobilePoolAddressBO();
				mobilePoolAddressBO.setMobilePoolAddressId(mobilePoolAddress.getMobilePoolAddressId());
				mobilePoolAddressBO.setDataCenterId(mobilePoolAddress.getDataCenter().getDataCenterId());
				mobilePoolAddressBO.setDataCenterName(mobilePoolAddress.getDataCenter().getDataCenterName());
				mobilePoolAddressBO.setIpAddress(mobilePoolAddress.getIpAddress());
				if (null != mobilePoolAddress.getSeq()) {
					mobilePoolAddressBO.setSeq(Long.valueOf(mobilePoolAddress.getSeq()));
				} else {
					logger.error(
							"MobilePoolAddresses get Sequence value is null for ORDER_ID ::[" + apn.getOrderId() + "]",
							this);
				}

				mobilePoolAddressBO.setIpAddressType(mobilePoolAddress.getIpAddressType());
				mobilePoolAddressBOList.add(mobilePoolAddressBO);
			}
			apnDomainProtocolConf.setMobilePoolAddresses(mobilePoolAddressBOList);
		} else {
			logger.error("MobilePoolAddresses is null for ORDER_ID Initiated::[" + apn.getOrderId() + "]", this);
			List<MobilePoolAddressBO> mobilePoolAddressBOList = new ArrayList<MobilePoolAddressBO>();
		    if(!CollectionUtils.isEmpty(odcList)) {
		    	odcList.stream().forEach(odc ->{
					MobilePoolAddressBO mobilePoolAddressBO = new MobilePoolAddressBO();
					mobilePoolAddressBO.setMobilePoolAddressId(null);
					mobilePoolAddressBO.setDataCenterId(odc.getId().getDataCenterId());
					mobilePoolAddressBO.setDataCenterName(odc.getDataCenter().getDataCenterName());
					mobilePoolAddressBO.setIpAddress(null);
					mobilePoolAddressBO.setSeq(null);
					mobilePoolAddressBO.setIpAddressType(null);
					mobilePoolAddressBOList.add(mobilePoolAddressBO);	
				});	
		    }else {
		    	logger.error("DATA Center list  is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);	
		    }
			apnDomainProtocolConf.setMobilePoolAddresses(mobilePoolAddressBOList);
			logger.error("MobilePoolAddresses is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch MobilePoolAddresses

		// Fetch IntTargetIpRanges
		if (!CollectionUtils.isEmpty(apn.getIntTargetIpRanges())) {
			List<IntTargetIpRange> intTargetIpRangesList = apn.getIntTargetIpRanges().stream()
					.collect(Collectors.toList());
			List<InternetTargetIpRangeBO> internetTargetIpRangeBOList = new ArrayList<InternetTargetIpRangeBO>();
			for (IntTargetIpRange intTargetIpRange : intTargetIpRangesList) {
				InternetTargetIpRangeBO intTargetIpRangeBO = new InternetTargetIpRangeBO();
				intTargetIpRangeBO.setIntTargetIpRangeId(intTargetIpRange.getIntTargetIpRangeId());
				intTargetIpRangeBO.setIntTargetIpRange(intTargetIpRange.getIntTargetIpRange());
				internetTargetIpRangeBOList.add(intTargetIpRangeBO);
			}
			apnDomainProtocolConf.setIntTargetIpRanges(internetTargetIpRangeBOList);
		} else {
			logger.error("IntTargetIpRanges is null for ORDER_ID Initiated ::[" + apn.getOrderId() + "]", this);
			List<InternetTargetIpRangeBO> internetTargetIpRangeBOList = new ArrayList<InternetTargetIpRangeBO>();
			InternetTargetIpRangeBO intTargetIpRangeBO = new InternetTargetIpRangeBO();
			intTargetIpRangeBO.setIntTargetIpRangeId(null);
			intTargetIpRangeBO.setIntTargetIpRange(null);
			internetTargetIpRangeBOList.add(intTargetIpRangeBO);
			apnDomainProtocolConf.setIntTargetIpRanges(internetTargetIpRangeBOList);
			logger.error("IntTargetIpRanges is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch IntTargetIpRanges

		// Fetch SplitTunnelIpRanges
		if (!CollectionUtils.isEmpty(apn.getSplitTunnelIpRanges())) {
			List<SplitTunnelIpRange> splitTunnelIpRangeList = apn.getSplitTunnelIpRanges().stream()
					.collect(Collectors.toList());
			List<SplitTunnelIpRangeBO> splitTunnelIpRangeBOList = new ArrayList<SplitTunnelIpRangeBO>();
			for (SplitTunnelIpRange splitTunnelIpRange : splitTunnelIpRangeList) {
				SplitTunnelIpRangeBO splitTunnelIpRangeBO = new SplitTunnelIpRangeBO();
				splitTunnelIpRange.getApn();
				splitTunnelIpRangeBO.setSplitTunnelIpRange(splitTunnelIpRange.getSplitTunnelIpRange());
				splitTunnelIpRangeBO.setSplitTunnelIpRangeId(splitTunnelIpRange.getSplitTunnelIpRangeId());
				splitTunnelIpRangeBOList.add(splitTunnelIpRangeBO);
			}
			apnDomainProtocolConf.setSplitTunnelIpRanges(splitTunnelIpRangeBOList);
		} else {
			logger.error("SplitTunnelIpRanges is null for ORDER_ID Initaited::[" + apn.getOrderId() + "]", this);
			List<SplitTunnelIpRangeBO> splitTunnelIpRangeBOList = new ArrayList<SplitTunnelIpRangeBO>();
			SplitTunnelIpRangeBO splitTunnelIpRangeBO = new SplitTunnelIpRangeBO();
			splitTunnelIpRangeBO.setSplitTunnelIpRange(null);
			splitTunnelIpRangeBO.setSplitTunnelIpRangeId(null);
			splitTunnelIpRangeBOList.add(splitTunnelIpRangeBO);
			apnDomainProtocolConf.setSplitTunnelIpRanges(splitTunnelIpRangeBOList);
			logger.error("SplitTunnelIpRanges is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch SplitTunnelIpRanges

		// Fetch PatPoolAddresses
		if (!CollectionUtils.isEmpty(apn.getPatPoolAddresses())) {
			List<PatPoolAddress> patPoolAddressList = apn.getPatPoolAddresses().stream().collect(Collectors.toList());
			List<PatPoolAddressBO> patPoolAddressBOList = new ArrayList<PatPoolAddressBO>();
			for (PatPoolAddress patPoolAddress : patPoolAddressList) {
				PatPoolAddressBO patPoolAddressBO = new PatPoolAddressBO();
				patPoolAddressBO.setPatPoolAddressId(patPoolAddress.getPatPoolAddressId());
				patPoolAddressBO.setDataCenterId(patPoolAddress.getDataCenter().getDataCenterId());
				patPoolAddressBO.setDataCenterName(patPoolAddress.getDataCenter().getDataCenterName());
				patPoolAddressBO.setIpAddress(patPoolAddress.getIpAddress());
				if (null != patPoolAddress.getSeq()) {
					patPoolAddressBO.setSeq(Long.valueOf(patPoolAddress.getSeq()));
				} else {
					logger.error(
							"PatPoolAddresses get Sequence value is null for ORDER_ID ::[" + apn.getOrderId() + "]",
							this);
				}
				patPoolAddress.getApn();
				patPoolAddressBOList.add(patPoolAddressBO);
			}
			apnDomainProtocolConf.setPatPoolAddresses(patPoolAddressBOList);
		} else {
			List<PatPoolAddressBO> patPoolAddressBOList = new ArrayList<PatPoolAddressBO>();
			if(!CollectionUtils.isEmpty(odcList)) {
				odcList.stream().forEach(odc ->{
					PatPoolAddressBO patPoolAddressBO = new PatPoolAddressBO();
					patPoolAddressBO.setPatPoolAddressId(null);
					patPoolAddressBO.setDataCenterId(odc.getId().getDataCenterId());
					patPoolAddressBO.setDataCenterName(odc.getDataCenter().getDataCenterName());
					patPoolAddressBO.setIpAddress(null);
					patPoolAddressBO.setSeq(null);
					patPoolAddressBOList.add(patPoolAddressBO);
				});
			}else {
				logger.error("DATA center is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);	
			}
			apnDomainProtocolConf.setPatPoolAddresses(patPoolAddressBOList);
			logger.error("PatPoolAddresses is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch PatPoolAddresses

		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method getApnSectionBasicInfo : ",
				this);
		return apnDomainProtocolConf;
	}

	/**
	 * getApnHealthCheckInfo
	 * 
	 * @param apnBO
	 * @param orderId
	 * @return
	 */
	private ApnHealthCheckInfo getApnHealthCheckInfo(Apn apn) {
		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method getApnHealthCheckInfo : ",
				this);
		ApnHealthCheckInfo apnHealthCheckInfo = new ApnHealthCheckInfo();
		apnHealthCheckInfo.setSectionName("APN Health Check Info");
		// Fetch ApnHealthCheck()
		if (null != apn.getApnHealthCheck()) {
			ApnHealthCheck apnHlthChk = apn.getApnHealthCheck();
			apnHealthCheckInfo.setHelthChkenable(apnHlthChk.getHelthChkenable());
			apnHealthCheckInfo.setHelthChkType(apnHlthChk.getHelthChkType());
			apnHealthCheckInfo.setHelthChkFrequency(apnHlthChk.getHelthChkFrequency());

		} else {
			logger.error("ApnHealthCheck is null for ORDER_ID Initaited::[" + apn.getOrderId() + "]", this);
			apnHealthCheckInfo.setHelthChkenable(null);
			apnHealthCheckInfo.setHelthChkType(null);
			apnHealthCheckInfo.setHelthChkFrequency(null);
			logger.error("ApnHealthCheck is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch ApnHealthCheck()
		// Fetch ApnHealthChkCustDestnIps
		if (!CollectionUtils.isEmpty(apn.getApnHealthChkCustDestnIps())) {
			List<ApnHealthChkCustDestnIp> apnHealthChkCustDestnIpList = apn.getApnHealthChkCustDestnIps().stream()
					.collect(Collectors.toList());
			List<ApnHealthChkCustDestnIpBO> apnHealthChkCustDestnIpBOlist = new ArrayList<ApnHealthChkCustDestnIpBO>();
			for (ApnHealthChkCustDestnIp apnHealthChkCustDestnIp : apnHealthChkCustDestnIpList) {
				ApnHealthChkCustDestnIpBO apnHealthChkCustDestnIpBO = new ApnHealthChkCustDestnIpBO();
				apnHealthChkCustDestnIp.getApn();
				apnHealthChkCustDestnIpBO.setHealthChkCustId(apnHealthChkCustDestnIp.getHealthChkCustId());
				apnHealthChkCustDestnIpBO.setHealthChkCustIpLbl(apnHealthChkCustDestnIp.getHealthChkCustIpLbl());
				apnHealthChkCustDestnIpBO.setHealthChkCustIpVal(apnHealthChkCustDestnIp.getHealthChkCustIpVal());
				apnHealthChkCustDestnIpBO.setDataCenterId(apnHealthChkCustDestnIp.getDataCenter().getDataCenterId());
				apnHealthChkCustDestnIpBO
						.setDataCenterName(apnHealthChkCustDestnIp.getDataCenter().getDataCenterName());
				apnHealthChkCustDestnIpBOlist.add(apnHealthChkCustDestnIpBO);
			}
			apnHealthCheckInfo.setApnHealthChkCustDestnIpBOlst(apnHealthChkCustDestnIpBOlist);
		} else {
			logger.info("ApnHealthChkCustDestnIps is null for ORDER_ID Initiated ::[" + apn.getOrderId() + "]", this);
			List<ApnHealthChkCustDestnIpBO> apnHealthChkCustDestnIpBOlist = new ArrayList<ApnHealthChkCustDestnIpBO>();
			ApnHealthChkCustDestnIpBO apnHealthChkCustDestnIpBO = new ApnHealthChkCustDestnIpBO();
			apnHealthChkCustDestnIpBO.setHealthChkCustId(null);
			apnHealthChkCustDestnIpBO.setHealthChkCustIpLbl(null);
			apnHealthChkCustDestnIpBO.setHealthChkCustIpVal(null);
			apnHealthChkCustDestnIpBO.setDataCenterId(null);
			apnHealthChkCustDestnIpBO.setDataCenterName(null);
			apnHealthChkCustDestnIpBOlist.add(apnHealthChkCustDestnIpBO);
			apnHealthCheckInfo.setApnHealthChkCustDestnIpBOlst(apnHealthChkCustDestnIpBOlist);
			logger.error("ApnHealthChkCustDestnIps is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch ApnHealthChkCustDestnIps
		// Fetch ImsiDcDetails
		if (!CollectionUtils.isEmpty(apn.getImsiDcDetails())) {
			List<ImsiDataCenterDetails> imsiDataCenterDetailsList = apn.getImsiDcDetails().stream()
					.collect(Collectors.toList());
			List<ImsiMsisdnBO> imsiMsisdnBoList = new ArrayList<ImsiMsisdnBO>();
			for (ImsiDataCenterDetails imsiDataCenterDetails : imsiDataCenterDetailsList) {
				ImsiMsisdnBO imsiMsisdnBo = new ImsiMsisdnBO();
				imsiMsisdnBo.setDataCenterId(String.valueOf(imsiDataCenterDetails.getDataCenterId()));
				String imsiMsisdn = imsiDataCenterDetails.getImsiMsisdn();
				String imsiMsisdn2 = imsiDataCenterDetails.getImsiMsisdn2();
				
				if (StringUtils.isNotBlank(imsiMsisdn) && imsiMsisdn.contains("-")) {
					imsiMsisdn = imsiMsisdn.replaceAll("-", "/");
				}
				
				if (StringUtils.isNotBlank(imsiMsisdn2) && imsiMsisdn2.contains("-")) {
					imsiMsisdn2 = imsiMsisdn2.replaceAll("-", "/");
				}
				
				imsiMsisdnBo.setImsiMsisdn(imsiMsisdn);
				imsiMsisdnBo.setImsiMsisdn2(imsiMsisdn2);
				imsiMsisdnBoList.add(imsiMsisdnBo);
			}
			apnHealthCheckInfo.setImsiMsisdnList(imsiMsisdnBoList);
		} else {
			logger.error("ImsiDcDetails is null for ORDER_ID Initiated::[" + apn.getOrderId() + "]", this);
			List<ImsiMsisdnBO> imsiMsisdnBoList = new ArrayList<ImsiMsisdnBO>();
			ImsiMsisdnBO imsiMsisdnBo = new ImsiMsisdnBO();
			imsiMsisdnBo.setDataCenterId(null);
			imsiMsisdnBo.setImsiMsisdn(null);
			imsiMsisdnBo.setImsiMsisdn2(null);
			imsiMsisdnBoList.add(imsiMsisdnBo);
			apnHealthCheckInfo.setImsiMsisdnList(imsiMsisdnBoList);
			logger.error("ImsiDcDetails is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch ImsiDcDetails
		logger.info("[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method getApnHealthCheckInfo : ",
				this);
		return apnHealthCheckInfo;
	}

	/**
	 * getApnDNSConfiguration
	 * 
	 * @param apnBO
	 * @param orderId
	 * @return
	 */
	private ApnDNSConfiguration getApnDNSConfiguration(Apn apn,List<OrderDataCenter> odcList) {
		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method getApnDNSConfiguration : ",
				this);
		ApnDNSConfiguration apnDNSConfiguration = new ApnDNSConfiguration();
		apnDNSConfiguration.setSectionName("APN DNS Info");
		apnDNSConfiguration.setDnsServerIp(apn.getDnsServerIp() == null ? null : apn.getDnsServerIp());
		apnDNSConfiguration.setAmplifyingInformation(apn.getAmplifyingInformation() == null? null : apn.getAmplifyingInformation());
		// Fetch EnterPriseDnsServerAddresses
		if (!CollectionUtils.isEmpty(apn.getEnterPriseDnsServerAddresses())) {
			List<EnterpriseDnsServer> enterpriseDnsServersList = apn.getEnterPriseDnsServerAddresses().stream()
					.collect(Collectors.toList());
			List<EnterpriseDnsServerBO> enterpriseDnsServerBOList = new ArrayList<EnterpriseDnsServerBO>();
			for (EnterpriseDnsServer enterpriseDnsServer : enterpriseDnsServersList) {
				EnterpriseDnsServerBO enterpriseDnsServerBO = new EnterpriseDnsServerBO();
				enterpriseDnsServerBO.setEnterpriseServerId(enterpriseDnsServer.getEnterpriseServerId());
				enterpriseDnsServerBO.setDataCenterId(enterpriseDnsServer.getDataCenter().getDataCenterId());
				enterpriseDnsServerBO.setDataCenterName(enterpriseDnsServer.getDataCenter().getDataCenterName());
				enterpriseDnsServerBO.setPrimaryEntServerIp(enterpriseDnsServer.getPrimaryEntServerIp());
				enterpriseDnsServerBO.setSecondaryEntServerIp(enterpriseDnsServer.getSecondaryEntServerIp());
				enterpriseDnsServerBO.setDnsServerNotes(enterpriseDnsServer.getDnsServerNotes());
				enterpriseDnsServerBO.setApnProtocol(enterpriseDnsServer.getApnProtocol());
				enterpriseDnsServer.getApn();
				enterpriseDnsServerBOList.add(enterpriseDnsServerBO);
			}
			apnDNSConfiguration.setEnterpriseDnsServerRanges(enterpriseDnsServerBOList);
		} else {
			logger.info("EnterPriseDnsServerAddresses is null for ORDER_ID Initiated ::[" + apn.getOrderId() + "]", this);
			List<EnterpriseDnsServerBO> enterpriseDnsServerBOList = new ArrayList<EnterpriseDnsServerBO>();
			if(!CollectionUtils.isEmpty(odcList)) {
				odcList.stream().forEach(odc ->{
					EnterpriseDnsServerBO enterpriseDnsServerBO = new EnterpriseDnsServerBO();
					enterpriseDnsServerBO.setEnterpriseServerId(null);
					enterpriseDnsServerBO.setDataCenterId(odc.getId().getDataCenterId());
					enterpriseDnsServerBO.setDataCenterName(odc.getDataCenter().getDataCenterName());
					enterpriseDnsServerBO.setPrimaryEntServerIp(null);
					enterpriseDnsServerBO.setSecondaryEntServerIp(null);
					enterpriseDnsServerBO.setDnsServerNotes(null);
					enterpriseDnsServerBO.setApnProtocol(null);
					enterpriseDnsServerBOList.add(enterpriseDnsServerBO);
				});
			}else {
				logger.error("DATA Center is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);	
			}
			apnDNSConfiguration.setEnterpriseDnsServerRanges(enterpriseDnsServerBOList);
			logger.error("EnterPriseDnsServerAddresses is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// END Fetch EnterPriseDnsServerAddresses

		logger.info(
				"[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method getApnDNSConfiguration : ",
				this);
		return apnDNSConfiguration;
	}

	/**
	 * getApnRadiusInfo
	 * 
	 * @param apnBO
	 * @param orderId
	 * @return
	 */
	private ApnRadiusInfo getApnRadiusInfo(Apn apn,List<OrderDataCenter> odcList) {
		logger.info("[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Starting method getApnRadiusInfo : ",
				this);
		ApnRadiusInfo apnRadiusInfo = new ApnRadiusInfo();
		apnRadiusInfo.setRadAccServEnabled(apn.getRadAccServEnabled() == null ? null:apn.getRadAccServEnabled());
		apnRadiusInfo.setFwdRadReqAuthEnabled(apn.getFwdRadReqAuthEnabled() == null ? null:apn.getFwdRadReqAuthEnabled());
		apnRadiusInfo.setFwdRadReqMsgEnabled(apn.getFwdRadReqMsgEnabled() == null ? null:apn.getFwdRadReqMsgEnabled());
		apnRadiusInfo.setAuthenticationType(apn.getAuthenticationType() ==null ? null :apn.getAuthenticationType());
		apnRadiusInfo.setHostedRadiusType(apn.getHostedRadiusType() == null ? null : apn.getHostedRadiusType());
		apnRadiusInfo.setInterimUpdate(apn.getInterimUpdate() ==null ?null :apn.getInterimUpdate());
		apnRadiusInfo.setInterimUpdateValue(apn.getInterimUpdateValue() == null ? null : apn.getInterimUpdateValue());
		
		// Fetch ApnRadiuses
		if (!CollectionUtils.isEmpty(apn.getApnRadiuses())) {
			List<ApnRadius> apnRadiusList = apn.getApnRadiuses().stream().collect(Collectors.toList());

			List<ApnRadiusBO> anRadiusBOList = new ArrayList<ApnRadiusBO>();

			List<ApnCustomerRadius> apnCustomerRadiusList;

			for (ApnRadius apnRadius : apnRadiusList) {
				List<ApnCustomerRadiusBO> apnCustomerRadiusBOList = new ArrayList<ApnCustomerRadiusBO>();
				ApnRadiusBO apnRadiusBO = new ApnRadiusBO();
				apnRadiusBO.setDataCenterId(apnRadius.getDataCenter().getDataCenterId());
				apnRadiusBO.setDataCenterName(apnRadius.getDataCenter().getDataCenterName());
				apnRadiusBO.setCustRadServer(apnRadius.getCustRadServer());
				apnRadiusBO.setRasClientIp(apnRadius.getRasClientIp());

				apnCustomerRadiusList = apnRadius.getApnCustomerRadiuses().stream().collect(Collectors.toList());
				if (!CollectionUtils.isEmpty(apnCustomerRadiusList)) {
					for (ApnCustomerRadius apnCustomerRadius : apnCustomerRadiusList) {
						ApnCustomerRadiusBO apnCustomerRadiusBO = new ApnCustomerRadiusBO();
						apnCustomerRadiusBO.setApnCustRadiusId(apnCustomerRadius.getApnCustomerRadiusId());
						// apnCustomerRadius.getApnRadius();
						apnCustomerRadiusBO.setCustomerRadIpAddress(apnCustomerRadius.getCustomerRadIpAddress());
						apnCustomerRadiusBO.setCustomerRadName(apnCustomerRadius.getCustomerRadName());
						apnCustomerRadiusBO.setCustomerRadSharedSecret(apnCustomerRadius.getCustomerRadSharedSecret());
						apnCustomerRadiusBOList.add(apnCustomerRadiusBO);
					}
				} else {
					logger.error("apnCustomerRadius is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
				}

				// Convert List to stream
				Set<ApnCustomerRadiusBO> apnCustomerRadiusBOSet = CommonUtils.convertListToSet(apnCustomerRadiusBOList);
				apnRadiusBO.setApnCustomerRadiuses(apnCustomerRadiusBOSet);
				anRadiusBOList.add(apnRadiusBO);
			}
			apnRadiusInfo.setApnRadiuses(anRadiusBOList);
		} else {
			logger.error("ApnRadiuses is null for ORDER_ID Initiated ::[" + apn.getOrderId() + "]", this);
			List<ApnRadiusBO> anRadiusBOList = new ArrayList<ApnRadiusBO>();
			List<ApnCustomerRadiusBO> apnCustomerRadiusBOList = new ArrayList<ApnCustomerRadiusBO>();
			if(!CollectionUtils.isEmpty(odcList)) {
				odcList.stream().forEach(odc ->{
					ApnRadiusBO apnRadiusBO = new ApnRadiusBO();
					apnRadiusBO.setDataCenterId(odc.getId().getDataCenterId());
					apnRadiusBO.setDataCenterName(odc.getDataCenter().getDataCenterName());
					apnRadiusBO.setCustRadServer(null);
					apnRadiusBO.setRasClientIp(null);
					
					ApnCustomerRadiusBO apnCustomerRadiusBO = new ApnCustomerRadiusBO();
					apnCustomerRadiusBO.setApnCustRadiusId(null);
					// apnCustomerRadius.getApnRadius();
					apnCustomerRadiusBO.setCustomerRadIpAddress(null);
					apnCustomerRadiusBO.setCustomerRadName(null);
					apnCustomerRadiusBO.setCustomerRadSharedSecret(null);
					apnCustomerRadiusBOList.add(apnCustomerRadiusBO);
					Set<ApnCustomerRadiusBO> apnCustomerRadiusBOSet = CommonUtils.convertListToSet(apnCustomerRadiusBOList);
					apnRadiusBO.setApnCustomerRadiuses(apnCustomerRadiusBOSet);
					anRadiusBOList.add(apnRadiusBO);
				
				});
			}
			apnRadiusInfo.setApnRadiuses(anRadiusBOList);
			logger.error("ApnRadiuses is null for ORDER_ID ::[" + apn.getOrderId() + "]", this);
		}
		// End Fetch ApnRadiuses
		logger.info("[OrderId : " + (apn == null ? "" : apn.getOrderId()) + "] Exiting method getApnRadiusInfo : ",
				this);
		return apnRadiusInfo;
	}

	public Apn populateApn(ApnBO apnBO) {
		logger.info("Starting method populateApn : ");
		Apn apn = new Apn();
		DataCenter dataCenter = new DataCenter();
		if(null != apnBO.getApnSectionBasicInfo()) {
			if (apnBO.getApnSectionBasicInfo().getOrderId() != null) {
				Orders orders = new Orders();
				orders.setOrderId(apnBO.getApnSectionBasicInfo().getOrderId());
				apn.setOrders(orders);
			}
			if (StringUtils.isNotBlank(apnBO.getApnSectionBasicInfo().getApnName())) {
				apn.setApnName(apnBO.getApnSectionBasicInfo().getApnName().toLowerCase());
			}
			if (StringUtils.isNotBlank(apnBO.getApnSectionBasicInfo().getProvisioningMethod())) {
				apn.setProvisioningMethod(apnBO.getApnSectionBasicInfo().getProvisioningMethod());
			}
			if (apnBO.getApnSectionBasicInfo().getMigratedOrder() != null) {
				apn.setMigratedOrder(apnBO.getApnSectionBasicInfo().getMigratedOrder());
			}
			if (apnBO.getApnSectionBasicInfo().getManagedAvpn() != null) {
				apn.setManagedAvpn(apnBO.getApnSectionBasicInfo().getManagedAvpn());
			}
			if (apnBO.getApnSectionBasicInfo().getIpbr() != null) {
				apn.setIpbrFlag(apnBO.getApnSectionBasicInfo().getIpbr());
			}
			if (apnBO.getApnSectionBasicInfo().getMsp() != null) {
				apn.setMsp(apnBO.getApnSectionBasicInfo().getMsp());
			}
			if (apnBO.getApnSectionBasicInfo().getMspEntAndMms() != null) {
				apn.setMspEntAndMms(apnBO.getApnSectionBasicInfo().getMspEntAndMms());
			}
			if (StringUtils.isNotBlank(apnBO.getApnSectionBasicInfo().getWhitelistBlacklist())) {
				apn.setWhitelistBlacklist(apnBO.getApnSectionBasicInfo().getWhitelistBlacklist());
			}
			if (apnBO.getApnSectionBasicInfo().getFirstNet() != null) {
				apn.setFirstNet(apnBO.getApnSectionBasicInfo().getFirstNet());
			}
			if (apnBO.getApnSectionBasicInfo().getCcsmx() != null) {
				apn.setCcsmx(apnBO.getApnSectionBasicInfo().getCcsmx());
			}
			if (apnBO.getApnSectionBasicInfo().getNoFirewall() != null) {
				apn.setNoFirewall(apnBO.getApnSectionBasicInfo().getNoFirewall());
			}
			if (apnBO.getApnSectionBasicInfo().getTurboAppSupport() != null) {
				apn.setTurboAppSupport(apnBO.getApnSectionBasicInfo().getTurboAppSupport());
			}
			if (apnBO.getApnSectionBasicInfo().getOverRideCcsMx() != null) {
				apn.setOverRideCcsMx(apnBO.getApnSectionBasicInfo().getOverRideCcsMx());
			}
			if (apnBO.getApnSectionBasicInfo().getOverRidePdp() != null) {
				apn.setOverRidePdp(apnBO.getApnSectionBasicInfo().getOverRidePdp());
			}
			if (apnBO.getApnSectionBasicInfo().getOverRide() != null) {
				apn.setOverRide(apnBO.getApnSectionBasicInfo().getOverRide());
			}
//			if (StringUtils.isNotBlank(apnBO.getApnSectionBasicInfo().getStaticAddressType())) {
//				apn.setAddressType(apnBO.getApnSectionBasicInfo().getStaticAddressType());
//			}
			if (apnBO.getApnSectionBasicInfo().getPacl() != null) {
				apn.setPacl(apnBO.getApnSectionBasicInfo().getPacl());
			}
			if (apnBO.getApnSectionBasicInfo().getPaclEnabled() != null) {
				apn.setPaclEnabled(apnBO.getApnSectionBasicInfo().getPaclEnabled());
			}
		}

		if(null != apnBO.getApnDomainProtocolConf()) {
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getMobilePoolType())) {
				apn.setMobilePoolType(apnBO.getApnDomainProtocolConf().getMobilePoolType());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getIpAddressSource())) {
				apn.setIpAddressSource(apnBO.getApnDomainProtocolConf().getIpAddressSource());
			}
			if (apnBO.getApnDomainProtocolConf().getMobileTerminationEnabled() != null) {
				apn.setMobileTerminationEnabled(apnBO.getApnDomainProtocolConf().getMobileTerminationEnabled());
			}
			if (apnBO.getApnDomainProtocolConf().getMobileToMobileEnabled() != null) {
				apn.setMobileToMobileEnabled(apnBO.getApnDomainProtocolConf().getMobileToMobileEnabled());
			}
			if (apnBO.getApnDomainProtocolConf().getMobileOriginateEnabled() != null) {
				apn.setMobileOriginateEnabled(apnBO.getApnDomainProtocolConf().getMobileOriginateEnabled());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getSocFeatureCode())) {
				apn.setSocFeatureCode(apnBO.getApnDomainProtocolConf().getSocFeatureCode());
			}
			if (apnBO.getApnDomainProtocolConf().getSplitTunnelIntEnabled() != null) {
				apn.setSplitTunnelIntEnabled(apnBO.getApnDomainProtocolConf().getSplitTunnelIntEnabled());
			}
			if (apnBO.getApnDomainProtocolConf().getSplitTunnelMTEnabled() != null) {
				apn.setSplitTunnelMtEnabled(apnBO.getApnDomainProtocolConf().getSplitTunnelMTEnabled());
			}
			if (apnBO.getApnDomainProtocolConf().getTotalMobilePoolSize() != null) {
				apn.setTotalMobilePoolSize(apnBO.getApnDomainProtocolConf().getTotalMobilePoolSize());
			}
			if (apnBO.getApnDomainProtocolConf().getUniqueIPAddressSize() != null) {
				apn.setUniqueIpAddressSize(apnBO.getApnDomainProtocolConf().getUniqueIPAddressSize());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getDomainName())) {
				apn.setDomainName(apnBO.getApnDomainProtocolConf().getDomainName());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getStaticAddressType())) {
				apn.setAddressType(apnBO.getApnDomainProtocolConf().getStaticAddressType());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getPcrf())) {
				apn.setPcrf(apnBO.getApnDomainProtocolConf().getPcrf());
			}
			if (apnBO.getApnDomainProtocolConf().getSplitAccessPAT() != null) {
				apn.setSplitAccessPAT(apnBO.getApnDomainProtocolConf().getSplitAccessPAT());
			}
			if (apnBO.getApnDomainProtocolConf().getGeoOptimization() != null) {
				apn.setGeoOptimization(apnBO.getApnDomainProtocolConf().getGeoOptimization());
			}
			if (apnBO.getApnDomainProtocolConf().getCcipRadius() != null) {
				apn.setCcipRadius(apnBO.getApnDomainProtocolConf().getCcipRadius());
			}
			if (apnBO.getApnDomainProtocolConf().getOcs() != null) {
				apn.setOcs(apnBO.getApnDomainProtocolConf().getOcs());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getApnProtocol())) {
				apn.setApnProtocol(apnBO.getApnDomainProtocolConf().getApnProtocol());
			}
			if (apnBO.getApnDomainProtocolConf().getDscpPreservation() != null) {
				apn.setDscpPreservation(apnBO.getApnDomainProtocolConf().getDscpPreservation());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getInsideOusideStgPat())) {
				apn.setInsideOusideStgPat(apnBO.getApnDomainProtocolConf().getInsideOusideStgPat());
			}
		}
		
		if(null != apnBO.getApnDNSConfiguration()) {
			if (StringUtils.isNotBlank(apnBO.getApnDNSConfiguration().getDnsServerIp())) {
				apn.setDnsServerIp(apnBO.getApnDNSConfiguration().getDnsServerIp());
			}
			if (StringUtils.isNotBlank(apnBO.getApnDNSConfiguration().getAmplifyingInformation())) {
				apn.setAmplifyingInformation(apnBO.getApnDNSConfiguration().getAmplifyingInformation());
			}
		}
		
		if(null != apnBO.getApnRadiusInfo()) {
			if (apnBO.getApnRadiusInfo().getRadAccServEnabled() != null) {
				apn.setRadAccServEnabled(apnBO.getApnRadiusInfo().getRadAccServEnabled());
			}
			if (apnBO.getApnRadiusInfo().getFwdRadReqAuthEnabled() != null) {
				apn.setFwdRadReqAuthEnabled(apnBO.getApnRadiusInfo().getFwdRadReqAuthEnabled());
			}
			if (apnBO.getApnRadiusInfo().getFwdRadReqMsgEnabled() != null) {
				apn.setFwdRadReqMsgEnabled(apnBO.getApnRadiusInfo().getFwdRadReqMsgEnabled());
			}
			if (apnBO.getApnRadiusInfo().getInterimUpdate() != null) {
				apn.setInterimUpdate(apnBO.getApnRadiusInfo().getInterimUpdate());
			}
			if (apnBO.getApnRadiusInfo().getInterimUpdateValue() != null) {
				apn.setInterimUpdateValue(apnBO.getApnRadiusInfo().getInterimUpdateValue());
			}
			if (StringUtils.isNotBlank(apnBO.getApnRadiusInfo().getAuthenticationType())) {
				apn.setAuthenticationType(apnBO.getApnRadiusInfo().getAuthenticationType());
			}
			if (StringUtils.isNotBlank(apnBO.getApnRadiusInfo().getHostedRadiusType())) {
				apn.setHostedRadiusType(apnBO.getApnRadiusInfo().getHostedRadiusType());
			}
		}
		
		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getMobilePoolAddresses())) {
			Set<MobilePoolAddressBO> mobilePoolAddressList = apnBO.getApnDomainProtocolConf().getMobilePoolAddresses()
					.stream().collect(Collectors.toSet());
			MobilePoolAddress mobilePoolAddress = new MobilePoolAddress();
			Set<MobilePoolAddress> mobilePoolAddressSet = new HashSet<MobilePoolAddress>();

			for (MobilePoolAddressBO mobilePoolAddressBO : mobilePoolAddressList) {
				mobilePoolAddress.setMobilePoolAddressId(mobilePoolAddressBO.getMobilePoolAddressId());
				dataCenter.setDataCenterId(mobilePoolAddressBO.getDataCenterId());
				mobilePoolAddress.setDataCenter(dataCenter);

				mobilePoolAddress.setIpAddress(mobilePoolAddressBO.getIpAddress());
				if (null != mobilePoolAddressBO.getSeq()) {
					mobilePoolAddress.setSeq(Byte.valueOf(mobilePoolAddressBO.getSeq().toString()));
				} else {
					logger.error("MobilePoolAddressesBO get Sequence value is null for ORDER_ID ::["
							+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
				}

				mobilePoolAddress.setIpAddressType(mobilePoolAddressBO.getIpAddressType());
				mobilePoolAddressSet.add(mobilePoolAddress);
			}
			apn.setMobilePoolAddresses(mobilePoolAddressSet);
		} else {
			logger.error(
					"MobilePoolAddresses is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}
		////////////////////////////////////////////////////////

		if (null != apnBO.getApnHealthCheckInfo()) {
			apnBO.getApnHealthCheckInfo().getSectionName();
			ApnHealthCheck apnHealthCheck = new ApnHealthCheck();
			apnHealthCheck.setHelthChkenable(apnBO.getApnHealthCheckInfo().getHelthChkenable());
			apnHealthCheck.setHelthChkFrequency(apnBO.getApnHealthCheckInfo().getHelthChkFrequency());
			apnHealthCheck.setHelthChkType(apnBO.getApnHealthCheckInfo().getHelthChkType());
			apnHealthCheck.setApn(apn);
			apn.setApnHealthCheck(apnHealthCheck);
		} else {
			logger.error("ApnHealthCheck is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnHealthCheckInfo().getApnHealthChkCustDestnIpBOlst())) {
			Set<ApnHealthChkCustDestnIpBO> apnHealthChkCustDestnIpList = apnBO.getApnHealthCheckInfo()
					.getApnHealthChkCustDestnIpBOlst().stream().collect(Collectors.toSet());
			ApnHealthChkCustDestnIp apnHealthChkCustDestnIp = new ApnHealthChkCustDestnIp();
			Set<ApnHealthChkCustDestnIp> ApnHealthChkCustDestnIpSet = new HashSet<ApnHealthChkCustDestnIp>();
			for (ApnHealthChkCustDestnIpBO apnHealthChkCustDestnIpBO : apnHealthChkCustDestnIpList) {
				// apnHealthChkCustDestnIp.setApn(); //todo
				apnHealthChkCustDestnIp.setHealthChkCustId(apnHealthChkCustDestnIpBO.getHealthChkCustId());
				apnHealthChkCustDestnIp.setHealthChkCustIpLbl(apnHealthChkCustDestnIpBO.getHealthChkCustIpLbl());
				apnHealthChkCustDestnIp.setHealthChkCustIpVal(apnHealthChkCustDestnIpBO.getHealthChkCustIpVal());
				dataCenter.setDataCenterId(apnHealthChkCustDestnIpBO.getDataCenterId());
				apnHealthChkCustDestnIp.setDataCenter(dataCenter);
				ApnHealthChkCustDestnIpSet.add(apnHealthChkCustDestnIp);
			}
			apn.setApnHealthChkCustDestnIps(ApnHealthChkCustDestnIpSet);
		} else {
			logger.error("ApnHealthChkCustDestnIps is null for ORDER_ID ::["
					+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getPdpIdInfoBOList())) {
			Set<PdpIdInfoBO> pdpIdInfoList = apnBO.getPdpIdInfoBOList().stream().collect(Collectors.toSet());
			PdpIdInfo pdpIdInfo = new PdpIdInfo();
			Set<PdpIdInfo> pdpIdInfoSet = new HashSet<PdpIdInfo>();
			for (PdpIdInfoBO pdpIdInfoBO : pdpIdInfoList) {
				// pdpIdInfo.setApn(apn); //todo
				pdpIdInfo.setPdpId(pdpIdInfoBO.getPdpId());
				pdpIdInfo.setAutoPdpId(pdpIdInfoBO.getAutoPdpId());
				pdpIdInfo.setUserPdpId(pdpIdInfoBO.getUserPdpId());
				pdpIdInfo.setBasicPdpId(pdpIdInfoBO.getBasicPdpId());
				pdpIdInfo.setAutoPdpName(pdpIdInfoBO.getAutoPdpName());
				pdpIdInfoSet.add(pdpIdInfo);
			}
			apn.setPdpIdInfos(pdpIdInfoSet);
		} else {
			logger.error("PdpIdInfoBO is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getIntTargetIpRanges())) {
			Set<InternetTargetIpRangeBO> intTargetIpRangesBOList = apnBO.getApnDomainProtocolConf()
					.getIntTargetIpRanges().stream().collect(Collectors.toSet());
			IntTargetIpRange intTargetIpRange = new IntTargetIpRange();
			Set<IntTargetIpRange> internetTargetIpRangeSet = new HashSet<IntTargetIpRange>();
			for (InternetTargetIpRangeBO intTargetIpRangeBO : intTargetIpRangesBOList) {
				// intTargetIpRange.setApn(apn); //todo
				intTargetIpRange.setIntTargetIpRangeId(intTargetIpRangeBO.getIntTargetIpRangeId());
				intTargetIpRange.setIntTargetIpRange(intTargetIpRangeBO.getIntTargetIpRange());
				internetTargetIpRangeSet.add(intTargetIpRange);
			}
			apn.setIntTargetIpRanges(internetTargetIpRangeSet);
		} else {
			logger.error("InternetTargetIpRangeBO is null for ORDER_ID ::["
					+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnHealthCheckInfo().getImsiMsisdnList())) {
			Set<ImsiMsisdnBO> imsiMsisdnBoList = apnBO.getApnHealthCheckInfo().getImsiMsisdnList().stream()
					.collect(Collectors.toSet());
			ImsiDataCenterDetails imsiDataCenterDetails = new ImsiDataCenterDetails();
			Set<ImsiDataCenterDetails> imsiMsisdnSet = new HashSet<ImsiDataCenterDetails>();
			for (ImsiMsisdnBO imsiMsisdnBo : imsiMsisdnBoList) {
				// imsiDataCenterDetails.setApn(apn); //todo
				if(null!=imsiMsisdnBo) {
					imsiDataCenterDetails.setDataCenterId(imsiMsisdnBo.getDataCenterId()==null?null:Long.valueOf(imsiMsisdnBo.getDataCenterId()));
					imsiDataCenterDetails.setImsiMsisdn(imsiMsisdnBo.getImsiMsisdn());
					imsiDataCenterDetails.setImsiMsisdn2(imsiMsisdnBo.getImsiMsisdn2());
					imsiMsisdnSet.add(imsiDataCenterDetails);	
				}
		    }
			apn.setImsiDcDetails(imsiMsisdnSet);
		} else {
			logger.error("ImsiDcDetails is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getEntTargetIpRanges())) {
			Set<EnterpriseTargetIpRangeBO> entTargetIpRangesList = apnBO.getApnDomainProtocolConf()
					.getEntTargetIpRanges().stream().collect(Collectors.toSet());
			EntTargetIpRange entTargetIpRange = new EntTargetIpRange();
			Set<EntTargetIpRange> enterpriseTargetIpRangeBOSet = new HashSet<EntTargetIpRange>();
			for (EnterpriseTargetIpRangeBO entTargetIpRangeBO : entTargetIpRangesList) {
				entTargetIpRange.setEntTargetIpRangeId(entTargetIpRangeBO.getEntTargetIpRangeId());
				entTargetIpRange.setEntTargetIpRange(entTargetIpRangeBO.getEntTargetIpRange());
				entTargetIpRange.setEntTargetIpRangeType(entTargetIpRangeBO.getEntTargetIpRangeType());
				entTargetIpRange.setApnProtocol(entTargetIpRangeBO.getApnProtocol());
				enterpriseTargetIpRangeBOSet.add(entTargetIpRange);
			}
			apn.setEntTargetIpRanges(enterpriseTargetIpRangeBOSet);
		} else {
			logger.error(
					"EntTargetIpRanges is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getPersistentIps())) {
			Set<PersistentIpBO> persistentIpBOList = apnBO.getPersistentIps().stream().collect(Collectors.toSet());
			PersistentIp persistentIp = new PersistentIp();
			Set<PersistentIp> persistentIpBOSet = new HashSet<PersistentIp>();
			for (PersistentIpBO persistentIpBO : persistentIpBOList) {
				// persistentIp.setApn(apn); //todo
				persistentIp.setPersistentIpId(persistentIpBO.getPersistentIpId());
				persistentIp.setIpAddress(persistentIpBO.getIpAddress());
				persistentIp.getUsername();
				persistentIpBOSet.add(persistentIp);
			}
			apn.setPersistentIps(persistentIpBOSet);
		} else {
			logger.error(
					"EntTargetIpRanges is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnRadiusInfo().getApnRadiuses())) {
			Set<ApnRadiusBO> apnRadiusList = apnBO.getApnRadiusInfo().getApnRadiuses().stream()
					.collect(Collectors.toSet());
			ApnRadius apnRadius = new ApnRadius();

			Set<ApnCustomerRadiusBO> apnCustomerRadiusBOList;
			ApnCustomerRadius apnCustomerRadius = new ApnCustomerRadius();
			Set<ApnCustomerRadius> apnCustomerRadiusBOSet = new HashSet<ApnCustomerRadius>();

			for (ApnRadiusBO apnRadiusBO : apnRadiusList) {
				// apnRadius.setDataCenterId(apnRadiusBO.getDataCenterId()); //todo
				apnRadius.setCustRadServer(apnRadiusBO.getCustRadServer());
				apnRadius.setRasClientIp(apnRadiusBO.getRasClientIp());
				if(null!=apnRadiusBO.getApnCustomerRadiuses()) {
					apnCustomerRadiusBOList = apnRadiusBO.getApnCustomerRadiuses().stream().collect(Collectors.toSet());	
					if (!CollectionUtils.isEmpty(apnCustomerRadiusBOList)) {
						for (ApnCustomerRadiusBO apnCustomerRadiusBO : apnCustomerRadiusBOList) {
							apnCustomerRadius.setApnCustomerRadiusId(apnCustomerRadiusBO.getApnCustRadiusId());
							apnCustomerRadius.setCustomerRadIpAddress(apnCustomerRadiusBO.getCustomerRadIpAddress());
							apnCustomerRadius.setCustomerRadName(apnCustomerRadiusBO.getCustomerRadName());
							apnCustomerRadius.setCustomerRadSharedSecret(apnCustomerRadiusBO.getCustomerRadSharedSecret());
							apnCustomerRadiusBOSet.add(apnCustomerRadius);
						}
					} else {
						logger.error("apnCustomerRadius is null for ORDER_ID ::["
								+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
					}
				}
				// Convert List to stream
//				List<ApnCustomerRadius> apnCustomerRadiusSet = CommonUtils.convertSetToList(apnCustomerRadiusBOList); 
//				apnRadius.setApnCustomerRadiuses(apnCustomerRadiusSet);
//				anRadiusBOList.add(apnRadius);   //todo
			}
			// apnBO.setApnRadiuses(anRadiusBOList); //todo
		} else {
			logger.error("ApnRadiuses is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getSplitTunnelIpRanges())) {
			Set<SplitTunnelIpRangeBO> splitTunnelIpRangeList = apnBO.getApnDomainProtocolConf().getSplitTunnelIpRanges()
					.stream().collect(Collectors.toSet());
			SplitTunnelIpRange splitTunnelIpRange = new SplitTunnelIpRange();
			Set<SplitTunnelIpRange> splitTunnelIpRangeBOSet = new HashSet<SplitTunnelIpRange>();
			for (SplitTunnelIpRangeBO splitTunnelIpRangeBO : splitTunnelIpRangeList) {
				// splitTunnelIpRange.setApn(); //todo
				splitTunnelIpRange
						.setSplitTunnelIpRange(StringUtils.isNotBlank(splitTunnelIpRangeBO.getSplitTunnelIpRange())
								? splitTunnelIpRangeBO.getSplitTunnelIpRange()
								: "/");
				splitTunnelIpRange.setSplitTunnelIpRangeId(splitTunnelIpRangeBO.getSplitTunnelIpRangeId());
				splitTunnelIpRangeBOSet.add(splitTunnelIpRange);
			}
			apn.setSplitTunnelIpRanges(splitTunnelIpRangeBOSet);
		} else {
			logger.error(
					"SplitTunnelIpRanges is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnDNSConfiguration().getEnterpriseDnsServerRanges())) {
			Set<EnterpriseDnsServerBO> enterpriseDnsServersList = apnBO.getApnDNSConfiguration()
					.getEnterpriseDnsServerRanges().stream().collect(Collectors.toSet());
			EnterpriseDnsServer enterpriseDnsServer = new EnterpriseDnsServer();
			Set<EnterpriseDnsServer> enterpriseDnsServerSet = new HashSet<EnterpriseDnsServer>();
			for (EnterpriseDnsServerBO enterpriseDnsServerBO : enterpriseDnsServersList) {
				enterpriseDnsServer.setEnterpriseServerId(enterpriseDnsServerBO.getEnterpriseServerId());
				// enterpriseDnsServer.setDataCenterId(enterpriseDnsServerBO.getDataCenterId());
				// //todo
				enterpriseDnsServer.setPrimaryEntServerIp(enterpriseDnsServerBO.getPrimaryEntServerIp());
				enterpriseDnsServer.setSecondaryEntServerIp(enterpriseDnsServerBO.getSecondaryEntServerIp());
				enterpriseDnsServer.setDnsServerNotes(enterpriseDnsServerBO.getDnsServerNotes());
				enterpriseDnsServer.setApnProtocol(enterpriseDnsServerBO.getApnProtocol());
				// enterpriseDnsServer.setApn(); //todo
				enterpriseDnsServerSet.add(enterpriseDnsServer);
			}
			apn.setEnterPriseDnsServerAddresses(enterpriseDnsServerSet);
		} else {
			logger.error("EnterPriseDnsServerAddresses is null for ORDER_ID ::["
					+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getPatPoolAddresses())) {
			Set<PatPoolAddressBO> patPoolAddressList = apnBO.getApnDomainProtocolConf().getPatPoolAddresses().stream()
					.collect(Collectors.toSet());
			PatPoolAddress patPoolAddress = new PatPoolAddress();
			Set<PatPoolAddress> patPoolAddressSet = new HashSet<PatPoolAddress>();
			for (PatPoolAddressBO patPoolAddressBO : patPoolAddressList) {
				if(null!=patPoolAddressBO) {
					if(null!=patPoolAddressBO.getPatPoolAddressId()) {
						patPoolAddress.setPatPoolAddressId(patPoolAddressBO.getPatPoolAddressId());
						// patPoolAddress.setDataCenterId(patPoolAddressBO.getDataCenterId()); //todo
						patPoolAddress.setIpAddress(patPoolAddressBO.getIpAddress()==null?null:patPoolAddressBO.getIpAddress());
						if (null != patPoolAddress.getSeq()) {
							patPoolAddressBO.setSeq(Long.valueOf(patPoolAddress.getSeq()));
						} else {
							logger.error("PatPoolAddresses get Sequence value is null for ORDER_ID ::["
									+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
						}
						// patPoolAddress.getApn(); //todo
						patPoolAddressSet.add(patPoolAddress);
					}
				}
				logger.error("patPoolAddressBO IS NULL ORDER_ID ::["
						+ apnBO.getApnSectionBasicInfo().getOrderId() + "]");
			}
			apn.setPatPoolAddresses(patPoolAddressSet);
		} else {
			logger.error(
					"PatPoolAddresses is null for ORDER_ID ::[" + apnBO.getApnSectionBasicInfo().getOrderId() + "]");
		}

		//////////////////////////////////////////////////////////
		return apn;
	}

	public Apn populateApnForUpdate(ApnBO apnBO, Apn apn) {
		logger.info("Starting method populateApn : ");

		if(null != apnBO.getApnSectionBasicInfo()) {
			apn.setApnName(apnBO.getApnSectionBasicInfo().getApnName().toLowerCase());
			apn.setProvisioningMethod(apnBO.getApnSectionBasicInfo().getProvisioningMethod());
			apn.setMigratedOrder(apnBO.getApnSectionBasicInfo().getMigratedOrder());
			apn.setManagedAvpn(apnBO.getApnSectionBasicInfo().getManagedAvpn());
			apn.setIpbrFlag(apnBO.getApnSectionBasicInfo().getIpbr());
			apn.setMsp(apnBO.getApnSectionBasicInfo().getMsp());
			apn.setMspEntAndMms(apnBO.getApnSectionBasicInfo().getMspEntAndMms());
			apn.setWhitelistBlacklist(apnBO.getApnSectionBasicInfo().getWhitelistBlacklist());
			apn.setFirstNet(apnBO.getApnSectionBasicInfo().getFirstNet());
			apn.setTurboAppSupport(apnBO.getApnSectionBasicInfo().getTurboAppSupport());
			apn.setCcsmx(apnBO.getApnSectionBasicInfo().getCcsmx());
			apn.setNoFirewall(apnBO.getApnSectionBasicInfo().getNoFirewall());
			apn.setOverRideCcsMx(apnBO.getApnSectionBasicInfo().getOverRideCcsMx());
			apn.setOverRidePdp(apnBO.getApnSectionBasicInfo().getOverRidePdp());
			apn.setOverRide(apnBO.getApnSectionBasicInfo().getOverRide());
			apn.setPacl(apnBO.getApnSectionBasicInfo().getPacl());
			apn.setPaclEnabled(apnBO.getApnSectionBasicInfo().getPaclEnabled());
		}
		if(null != apnBO.getApnDNSConfiguration()) {
			apn.setAmplifyingInformation(apnBO.getApnDNSConfiguration().getAmplifyingInformation());
			apn.setDnsServerIp(apnBO.getApnDNSConfiguration().getDnsServerIp());
		}
		if(null != apnBO.getApnDomainProtocolConf()) {
			apn.setMobilePoolType(apnBO.getApnDomainProtocolConf().getMobilePoolType());
			apn.setInsideOusideStgPat(apnBO.getApnDomainProtocolConf().getInsideOusideStgPat());
			apn.setDscpPreservation(apnBO.getApnDomainProtocolConf().getDscpPreservation());
			apn.setSplitTunnelIntEnabled(apnBO.getApnDomainProtocolConf().getSplitTunnelIntEnabled());
			apn.setSplitTunnelMtEnabled(apnBO.getApnDomainProtocolConf().getSplitTunnelMTEnabled());
			apn.setSplitAccessPAT(apnBO.getApnDomainProtocolConf().getSplitAccessPAT());
			apn.setCcipRadius(apnBO.getApnDomainProtocolConf().getCcipRadius());
			apn.setMobileTerminationEnabled(apnBO.getApnDomainProtocolConf().getMobileTerminationEnabled());
			apn.setMobileToMobileEnabled(apnBO.getApnDomainProtocolConf().getMobileToMobileEnabled());
			apn.setMobileOriginateEnabled(apnBO.getApnDomainProtocolConf().getMobileOriginateEnabled());
			apn.setGeoOptimization(apnBO.getApnDomainProtocolConf().getGeoOptimization());
			apn.setSocFeatureCode(apnBO.getApnDomainProtocolConf().getSocFeatureCode());
			apn.setPcrf(apnBO.getApnDomainProtocolConf().getPcrf());
			apn.setOcs(apnBO.getApnDomainProtocolConf().getOcs());
			apn.setApnProtocol(apnBO.getApnDomainProtocolConf().getApnProtocol());
			apn.setDomainName(apnBO.getApnDomainProtocolConf().getDomainName());
			apn.setAddressType(apnBO.getApnDomainProtocolConf().getStaticAddressType());
			apn.setIpAddressSource(apnBO.getApnDomainProtocolConf().getIpAddressSource());
			apn.setTotalMobilePoolSize(apnBO.getApnDomainProtocolConf().getTotalMobilePoolSize());
			apn.setUniqueIpAddressSize(apnBO.getApnDomainProtocolConf().getUniqueIPAddressSize());
		}
		if(null != apnBO.getApnRadiusInfo()) {
			apn.setFwdRadReqAuthEnabled(apnBO.getApnRadiusInfo().getFwdRadReqAuthEnabled());
			apn.setFwdRadReqMsgEnabled(apnBO.getApnRadiusInfo().getFwdRadReqMsgEnabled());
			apn.setRadAccServEnabled(apnBO.getApnRadiusInfo().getRadAccServEnabled());
			apn.setInterimUpdate(apnBO.getApnRadiusInfo().getInterimUpdate());
			apn.setAuthenticationType(apnBO.getApnRadiusInfo().getAuthenticationType());
			apn.setHostedRadiusType(apnBO.getApnRadiusInfo().getHostedRadiusType());
			apn.setInterimUpdateValue(apnBO.getApnRadiusInfo().getInterimUpdateValue());
		}
		
		apn.setCcsVRFName(apnBO.getCcsVRFName());
		

		return apn;
	}

	public MobilePoolAddress populateMobilePoolAddress(MobilePoolAddressBO poolAddressBO) {
		logger.info("[OrderID : " + (poolAddressBO.getOrderId() == null ? "" : poolAddressBO.getOrderId()) + "] "
				+ "Starting method populateMobilePoolAddress ::", this);
		MobilePoolAddress mobilePoolAddress = new MobilePoolAddress();

		if (poolAddressBO.getOrderId() != null) {
			Apn apn = new Apn();
			apn.setOrderId(poolAddressBO.getOrderId());
			mobilePoolAddress.setApn(apn);
		}

		if (poolAddressBO.getDataCenterId() != null) {
			DataCenter dataCenter = new DataCenter();
			dataCenter.setDataCenterId(poolAddressBO.getDataCenterId());
			mobilePoolAddress.setDataCenter(dataCenter);
		}

		if (poolAddressBO.getMobilePoolAddressId() != null) {
			mobilePoolAddress.setMobilePoolAddressId(poolAddressBO.getMobilePoolAddressId());
		}

		if (poolAddressBO.getIpAddress() != null) {
			mobilePoolAddress.setIpAddress(poolAddressBO.getIpAddress());
		}

		if (poolAddressBO.getIpAddressType() != null) {
			mobilePoolAddress.setIpAddressType(poolAddressBO.getIpAddressType());
		}
		logger.info("[OrderID : " + (poolAddressBO.getOrderId() == null ? "" : poolAddressBO.getOrderId()) + "] "
				+ "Exiting method populateMobilePoolAddress ::", this);
		return mobilePoolAddress;
	}

	public PatPoolAddress populatePatPoolAddress(PatPoolAddressBO poolAddressBO) {
		logger.info("[OrderID : " + (poolAddressBO.getOrderId() == null ? "" : poolAddressBO.getOrderId()) + "] "
				+ "Starting method populatePatPoolAddress ::", this);
		PatPoolAddress patPoolAddress = new PatPoolAddress();

		if (poolAddressBO.getOrderId() != null) {
			Apn apn = new Apn();
			apn.setOrderId(poolAddressBO.getOrderId());
			patPoolAddress.setApn(apn);
		}

		if (poolAddressBO.getDataCenterId() != null) {
			DataCenter dataCenter = new DataCenter();
			dataCenter.setDataCenterId(poolAddressBO.getDataCenterId());
			patPoolAddress.setDataCenter(dataCenter);
		}

		if (poolAddressBO.getPatPoolAddressId() != null) {
			patPoolAddress.setPatPoolAddressId(poolAddressBO.getPatPoolAddressId());
		}

		if (poolAddressBO.getIpAddress() != null) {
			patPoolAddress.setIpAddress(poolAddressBO.getIpAddress());
		}
		logger.info("[OrderID : " + (poolAddressBO.getOrderId() == null ? "" : poolAddressBO.getOrderId()) + "] "
				+ "Exiting method populatePatPoolAddress ::", this);
		return patPoolAddress;
	}

	public ApnRadius populateApnRadius(ApnRadiusBO radiusBO) {
		logger.info("[OrderID : " + (radiusBO.getOrderId() == null ? "" : radiusBO.getOrderId()) + "] "
				+ "Starting method populateApnRadius ::", this);
		ApnRadius apnRadius = new ApnRadius();
		ApnRadiusId apnRadiusId = new ApnRadiusId();
		apnRadius.setId(apnRadiusId);

		Apn apn = new Apn();
		apn.setOrderId(radiusBO.getOrderId());
		apnRadius.setApn(apn);
		apnRadiusId.setOrderId(radiusBO.getOrderId());
		if (radiusBO.getDataCenterId() != null) {
			DataCenter dataCenter = new DataCenter();
			dataCenter.setDataCenterId(radiusBO.getDataCenterId());
			apnRadius.setDataCenter(dataCenter);
			apnRadiusId.setDataCenterId(radiusBO.getDataCenterId());
		}
		apnRadius.setCustRadServer(radiusBO.getCustRadServer());
		apnRadius.setRasClientIp(radiusBO.getRasClientIp());
		logger.info("[OrderID : " + (radiusBO.getOrderId() == null ? "" : radiusBO.getOrderId()) + "] "
				+ "Exiting method populateApnRadius ::", this);
		return apnRadius;
	}

	public EntTargetIpRange populateEntTargetIpRange(EnterpriseTargetIpRangeBO range) {
		logger.info("[OrderID : " + (range.getOrderId() == null ? "" : range.getOrderId()) + "] "
				+ "Starting method populateEntTargetIpRange ::", this);
		EntTargetIpRange entTargetIpRange = new EntTargetIpRange();

		Apn apn = new Apn();
		apn.setOrderId(range.getOrderId());
		entTargetIpRange.setApn(apn);

		entTargetIpRange.setEntTargetIpRange(range.getEntTargetIpRange());
		entTargetIpRange.setEntTargetIpRangeType(range.getEntTargetIpRangeType());
		entTargetIpRange.setApnProtocol(range.getApnProtocol());
		logger.info("[OrderID : " + (range.getOrderId() == null ? "" : range.getOrderId()) + "] "
				+ "Exiting method populateEntTargetIpRange ::", this);
		return entTargetIpRange;
	}

	public IntTargetIpRange populateInternetIpRange(InternetTargetIpRangeBO range) {
		logger.info("[OrderID : " + (range.getOrderId() == null ? "" : range.getOrderId()) + "] "
				+ "Starting method populateInternetIpRange ::", this);
		IntTargetIpRange intTargetIpRange = new IntTargetIpRange();
		Apn apn = new Apn();
		apn.setOrderId(range.getOrderId());
		intTargetIpRange.setApn(apn);
		intTargetIpRange.setIntTargetIpRange(range.getIntTargetIpRange());
		logger.info("[OrderID : " + (range.getOrderId() == null ? "" : range.getOrderId()) + "] "
				+ "Exiting method populateInternetIpRange ::", this);
		return intTargetIpRange;
	}

	public SplitTunnelIpRange populateSplitTunnelIpRange(SplitTunnelIpRangeBO range, Long orderId) {
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Starting method populateSplitTunnelIpRange ::", this);
		SplitTunnelIpRange splitTunnelIpRange = new SplitTunnelIpRange();
		Apn apn = new Apn();
		apn.setOrderId(range.getOrderId());
		splitTunnelIpRange.setApn(apn);
		splitTunnelIpRange.setSplitTunnelIpRange(
				StringUtils.isNotBlank(range.getSplitTunnelIpRange()) ? range.getSplitTunnelIpRange() : "/");
		
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Exiting method populateSplitTunnelIpRange ::", this);
		return splitTunnelIpRange;
	}

	public EnterpriseDnsServer populateEnterpriseDnsServers(EnterpriseDnsServerBO enterpriseDnsServerBO) {
		logger.info(
				"[OrderID : " + (enterpriseDnsServerBO.getOrderId() == null ? "" : enterpriseDnsServerBO.getOrderId())
						+ "] " + "Starting method populateEnterpriseDnsServers ::",
				this);
		EnterpriseDnsServer enterpriseDnsServer = new EnterpriseDnsServer();
		if (enterpriseDnsServerBO.getOrderId() != null) {
			Apn apn = new Apn();
			apn.setOrderId(Long.parseLong(enterpriseDnsServerBO.getOrderId()));
			enterpriseDnsServer.setApn(apn);
		}
		if (enterpriseDnsServerBO.getDataCenterId() != null) {
			DataCenter dataCenter = new DataCenter();
			dataCenter.setDataCenterId(enterpriseDnsServerBO.getDataCenterId());
			enterpriseDnsServer.setDataCenter(dataCenter);
		}
		if (enterpriseDnsServerBO.getPrimaryEntServerIp() != null) {
			enterpriseDnsServer.setPrimaryEntServerIp(enterpriseDnsServerBO.getPrimaryEntServerIp());
		}
		if (enterpriseDnsServerBO.getSecondaryEntServerIp() != null) {
			enterpriseDnsServer.setSecondaryEntServerIp(enterpriseDnsServerBO.getSecondaryEntServerIp());
		}
		if (enterpriseDnsServerBO.getDnsServerNotes() != null) {
			enterpriseDnsServer.setDnsServerNotes(enterpriseDnsServerBO.getDnsServerNotes());
		}
		if (enterpriseDnsServerBO.getApnProtocol() != null) {
			enterpriseDnsServer.setApnProtocol(enterpriseDnsServerBO.getApnProtocol());
		} 
		logger.info(
				"[OrderID : " + (enterpriseDnsServerBO.getOrderId() == null ? "" : enterpriseDnsServerBO.getOrderId())
						+ "] " + "Exiting method populateEnterpriseDnsServers ::",
				this);
		return enterpriseDnsServer;
	}

	public PdpIdInfo populatePdpIdInfo(PdpIdInfoBO pdpIdInfoBO) {
		PdpIdInfo pdpIdInfo = new PdpIdInfo();
		Apn apn = new Apn();
		apn.setOrderId(pdpIdInfoBO.getOrderId());
		pdpIdInfo.setApn(apn);
		pdpIdInfo.setAutoPdpId(pdpIdInfoBO.getAutoPdpId());
		pdpIdInfo.setAutoPdpName(pdpIdInfoBO.getAutoPdpName().toUpperCase());
		pdpIdInfo.setUserPdpId(pdpIdInfoBO.getUserPdpId());
		pdpIdInfo.setBasicPdpId(pdpIdInfoBO.getBasicPdpId());
		return pdpIdInfo;
	}
	
	public ImsiDataCenterDetails populateImsiDataCenter(ImsiMsisdnBO ImsiDataBO) {
		ImsiDataCenterDetails imsiDataCenterDetails = new ImsiDataCenterDetails();
		ImsiDataCenterDetailsId imsiDataCenterDetailsId = new ImsiDataCenterDetailsId();
		
		imsiDataCenterDetailsId.setDataCenterId(Long.parseLong(ImsiDataBO.getDataCenterId()));
		imsiDataCenterDetailsId.setOrderId(Long.parseLong(ImsiDataBO.getOrderId()));
		imsiDataCenterDetails.setImsiDataCenterDetailsId(imsiDataCenterDetailsId);
		
		if(ImsiDataBO.getOrderId() != null) {
			Apn apn = new Apn();
			apn.setOrderId(Long.parseLong(ImsiDataBO.getOrderId()));
			imsiDataCenterDetails.setApn(apn);
		}
				
		if(ImsiDataBO.getDataCenterId()!=null){
			imsiDataCenterDetails.setDataCenterId(Long.parseLong(ImsiDataBO.getDataCenterId()));
		}
		
		if(ImsiDataBO.getImsiMsisdn() != null) {
			imsiDataCenterDetails.setImsiMsisdn(ImsiDataBO.getImsiMsisdn());
		}
		
		if(ImsiDataBO.getImsiMsisdn2() != null) {
			imsiDataCenterDetails.setImsiMsisdn2(ImsiDataBO.getImsiMsisdn2());
		}
		return imsiDataCenterDetails;
	}
	public ImsiMsisdnInventory populateImsiMsisdnInventory(ImsiMsisdnBO imsiDataBO,String dataCenterName,Character dummy) {
		ImsiMsisdnInventory imsiMsisdnInventory = new ImsiMsisdnInventory();
		ImsiMsisdnDataCenterId imsiMsisdnDataCenterId = new ImsiMsisdnDataCenterId(Long.valueOf(imsiDataBO.getDataCenterId()),imsiDataBO.getImsiMsisdn());
		
		DataCenter dataCenter = new DataCenter();
		dataCenter.setDataCenterId(Long.valueOf(imsiDataBO.getDataCenterId()));
		dataCenter.setDataCenterName(dataCenterName);
		dataCenter.setDummy(dummy);
		
		imsiMsisdnInventory.setImsiMsisdnDataCenterId(imsiMsisdnDataCenterId);
		imsiMsisdnInventory.setDataCenter(dataCenter);
		imsiMsisdnInventory.setOrderId(Long.valueOf(imsiDataBO.getOrderId()));
		
		return imsiMsisdnInventory;
	}
	
	public ApnCustomerRadius populateApnCustomerRadius(ApnCustomerRadiusBO customerRadiusBO) {
		ApnCustomerRadius apnCustomerRadius = new ApnCustomerRadius();
		
		if(customerRadiusBO.getOrderId() != null) {
			ApnRadius apnRadius = new ApnRadius();
			
			ApnRadiusId apnRadiusId = new ApnRadiusId();
			apnRadiusId.setOrderId(customerRadiusBO.getOrderId());
			apnRadiusId.setDataCenterId(customerRadiusBO.getDataCenterId());
			apnRadius.setId(apnRadiusId);
			
			Apn apn = new Apn();
			apn.setOrderId(customerRadiusBO.getOrderId());
			apnRadius.setApn(apn);
			
			DataCenter dataCenter = new DataCenter();
			dataCenter.setDataCenterId(customerRadiusBO.getDataCenterId());
			
			apnRadius.setDataCenter(dataCenter);
			apnCustomerRadius.setApnRadius(apnRadius);
		}
		apnCustomerRadius.setApnCustomerRadiusId(0L);
		apnCustomerRadius.setCustomerRadIpAddress(customerRadiusBO.getCustomerRadIpAddress());
		apnCustomerRadius.setCustomerRadName(customerRadiusBO.getCustomerRadName());
		apnCustomerRadius.setCustomerRadSharedSecret(customerRadiusBO.getCustomerRadSharedSecret());
		return apnCustomerRadius;
	}

	public PersistentIp populatePersistentIp(PersistentIpBO persistentIpBO) {
		logger.info("[OrderID : " + (persistentIpBO.getOrderId() == null ? "" : persistentIpBO.getOrderId()) + "] "
				+ "Starting method populatePersistentIp ::", this);
		PersistentIp persistentIp = new PersistentIp();
		Apn apn = new Apn();
		apn.setOrderId(persistentIpBO.getOrderId());
		persistentIp.setApn(apn);
		persistentIp.setIpAddress(persistentIpBO.getIpAddress());
		persistentIp.setPassword(persistentIpBO.getPassword());
		persistentIp.setUsername(persistentIpBO.getUsername());
		logger.info("[OrderID : " + (persistentIpBO.getOrderId() == null ? "" : persistentIpBO.getOrderId()) + "] "
				+ "Exiting method populatePersistentIp ::", this);
		return persistentIp;
	}

	public void updateInsideOutsideSTGPAT(String scenario, Long orderId) throws CometDataException {
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Starting method updateInsideOutsideSTGPAT ::", this);
		String errorCode = null;
		String errorMsg = null;
		try {
			if (CommonUtils.isNotNullEmpty(orderId)) {
				StoredProcedureQuery sProcQury = em
						.createStoredProcedureQuery(CometCommonConstant.UPDATE_IN_OUT_STG_PAT_MAPPING);
				sProcQury.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
				sProcQury.registerStoredProcedureParameter(2, Long.class, ParameterMode.IN);
				sProcQury.registerStoredProcedureParameter(3, String.class, ParameterMode.OUT);
				sProcQury.registerStoredProcedureParameter(4, String.class, ParameterMode.OUT);
				sProcQury.setParameter(1, scenario);
				sProcQury.setParameter(2, orderId);

				sProcQury.execute();

				errorCode = (String) sProcQury.getOutputParameterValue(3);
				errorMsg = (String) sProcQury.getOutputParameterValue(4);

				if (CommonUtils.isValidString(errorMsg)) {
					throw new CometDataException(errorCode, errorMsg);
				}
			}
		} catch (Exception e) {
			logger.error("[OrderID : " + (orderId == null ? "" : orderId) + "] " + e.getStackTrace());
			throw new CometDataException("Error", "updateInside  Outside STG PAT failed", e);
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Starting method updateInsideOutsideSTGPAT ::", this);
	}
	
public ApnBO populateApnBO(Apn pApn) { 
		
		logger.info("Starting method populateApnBO ::", this);
		ApnBO apnBO = new ApnBO(); 
		apnBO.setOrderId(pApn.getOrderId()); 
		apnBO.setApnName(pApn.getApnName()); 
		apnBO.setProvisioningMethod(pApn.getProvisioningMethod()); 
		apnBO.setIpAddressSource(pApn.getIpAddressSource()); 
		apnBO.setAddressType(pApn.getAddressType()); 
		apnBO.setAmplifyingInformation(pApn.getAmplifyingInformation()); 
		apnBO.setFwdRadReqAuthEnabled(pApn.getFwdRadReqAuthEnabled()); 
		apnBO.setFwdRadReqMsgEnabled(pApn.getFwdRadReqMsgEnabled()); 
		apnBO.setMobileTerminationEnabled(pApn.getMobileTerminationEnabled()); 
		apnBO.setMobileToMobileEnabled(pApn.getMobileToMobileEnabled()); 
		apnBO.setMobileOriginateEnabled(pApn.getMobileOriginateEnabled()); 
		apnBO.setRadAccServEnabled(pApn.getRadAccServEnabled()); 
		apnBO.setSocFeatureCode(pApn.getSocFeatureCode()); 
		apnBO.setSplitTunnelIntEnabled(pApn.getSplitTunnelIntEnabled()); 
		apnBO.setSplitTunnelMTEnabled(pApn.getSplitTunnelMtEnabled()); 
		apnBO.setTotalMobilePoolSize(pApn.getTotalMobilePoolSize()); 
		apnBO.setUniqueIPAddressSize(pApn.getUniqueIpAddressSize()); 
		apnBO.setDnsServerIp(pApn.getDnsServerIp()); 
		apnBO.setDomainName(pApn.getDomainName()); 
		apnBO.setMigratedOrder(pApn.getMigratedOrder()); 
		apnBO.setOverRide(pApn.getOverRide()); 
		apnBO.setMobilePoolType(pApn.getMobilePoolType()); 
		apnBO.setOverRidePdp(pApn.getOverRidePdp()); 
		apnBO.setCcsVRFName(pApn.getCcsVRFName()); 
		apnBO.setManagedAvpn(pApn.getManagedAvpn()); 
		apnBO.setNoFirewall(pApn.getNoFirewall()); 
		apnBO.setIpbr(pApn.getIpbrFlag()); 
		apnBO.setMsp(pApn.getMsp()); 
		apnBO.setWhitelistBlacklist(pApn.getWhitelistBlacklist()); 
		apnBO.setPcrf(pApn.getPcrf()); 
		apnBO.setSplitAccessPAT(pApn.getSplitAccessPAT()); 
		apnBO.setGeoOptimization(pApn.getGeoOptimization()); 
		apnBO.setInsideOusideStgPat(pApn.getInsideOusideStgPat()); 
		apnBO.setCcipRadius(pApn.getCcipRadius()); 
		apnBO.setMspEntAndMms(pApn.getMspEntAndMms()); 
		apnBO.setOcs((pApn.getOcs())); 
		apnBO.setApnProtocol(pApn.getApnProtocol()); 
		apnBO.setFirstNet((pApn.getFirstNet())); 
		apnBO.setCcsmx((pApn.getCcsmx())); 
		apnBO.setTurboAppSupport((pApn.getTurboAppSupport())); 
		apnBO.setDscpPreservation((pApn.getDscpPreservation())); 
		apnBO.setInterimUpdate(pApn.getInterimUpdate()); 
		apnBO.setAuthenticationType(pApn.getAuthenticationType()); 
		apnBO.setHostedRadiusType(pApn.getHostedRadiusType()); 
		apnBO.setInterimUpdateValue(pApn.getInterimUpdateValue()); 
		apnBO.setOverRideCcsMx(pApn.getOverRideCcsMx()); 
		logger.info("Exiting method populateApnBO ::", this);
		return apnBO; 
	}
	
	public PdpIdInfoBO populatePdpIdInfoBO(PdpIdInfo pdpIdInfo){ 
		logger.info("Starting method populatePdpIdInfoBO ::", this);
		PdpIdInfoBO pdpIdInfoBO = new PdpIdInfoBO(); 
		pdpIdInfoBO.setPdpId(pdpIdInfo.getPdpId()); 
		pdpIdInfoBO.setAutoPdpId(pdpIdInfo.getAutoPdpId()); 
		pdpIdInfoBO.setAutoPdpName(pdpIdInfo.getAutoPdpName()); 
		pdpIdInfoBO.setUserPdpId(pdpIdInfo.getUserPdpId()); 
		pdpIdInfoBO.setBasicPdpId(pdpIdInfo.getBasicPdpId()); 
		logger.info("Exiting method populatePdpIdInfoBO ::", this);
		return pdpIdInfoBO; 
	}
	
	public EnterpriseTargetIpRangeBO populateEntTargetIpRangeBO(EntTargetIpRange pRange) {
		logger.info("Starting method populateEntTargetIpRangeBO ::", this);
 		EnterpriseTargetIpRangeBO ipRangeBO = new EnterpriseTargetIpRangeBO();
 		if(pRange.getApn() != null) {
 			ipRangeBO.setOrderId(pRange.getApn().getOrderId());
 		}		
 		ipRangeBO.setEntTargetIpRange(pRange.getEntTargetIpRange());	
 		ipRangeBO.setEntTargetIpRangeId(pRange.getEntTargetIpRangeId());
 		ipRangeBO.setEntTargetIpRangeType(pRange.getEntTargetIpRangeType());
 		ipRangeBO.setApnProtocol(pRange.getApnProtocol() == null ? "IPv4" : pRange.getApnProtocol());
 		logger.info("Exiting method populateEntTargetIpRangeBO ::", this);
 		return ipRangeBO;
 	}
	
	public DedicatedApnBO getDedicatedApnByOrder(Long orderId) throws CometDataException { 
		logger.info("Starting method getDedicatedApnByOrder ::", this);
		List<DapnInventory> apnList = dapnInventoryRepository.findByOrders_OrderId(orderId);
		DedicatedApnBO apnBO = null; 
		try { 
		if (apnList != null && apnList.size() > 0) { 
			DapnInventory pApn = apnList.get(0); 
			apnBO = populateDedicatedApnBO(pApn); 
		} 
		}catch(Exception e) { 
			logger.error("[OrderID : " + (orderId == null ? "" : orderId) + "] " + e.getStackTrace());
			throw new CometDataException("Error", "Not able to fetch dapn inventory", e);
		} 
		logger.info("Exiting method getDedicatedApnByOrder ::", this);
		return apnBO; 
	} 
 
	private DedicatedApnBO populateDedicatedApnBO(DapnInventory pApn) {
		logger.info("Starting method populateDedicatedApnBO ::", this);
		DedicatedApnBO apnBO = new DedicatedApnBO(); 
		apnBO.setApnId(pApn.getId().toString()); 
		apnBO.setDapnId(pApn.getDapnId()); 
		apnBO.setApnName(pApn.getApnName()); 
 
		if(pApn.getApnSize() != null){ 
			apnBO.setApnSize(pApn.getApnSize().toString()); 
		} 
 
		if(pApn.getOrders() != null){ 
			apnBO.setOrderId(pApn.getOrders().getOrderId()); 
		} 
 
		if(pApn.getDapnStatus() != null) { 
			apnBO.setInventoryStatus(pApn.getDapnStatus().getDapnStatusId()); 
		} 
 
		if(pApn.getDataCenter()!=null) { 
			apnBO.setDataCenterId(pApn.getDataCenter().getDataCenterId()); 
		} 
 
		apnBO.setPdpName(pApn.getPdpName()); 
		apnBO.setIpAddressSource(pApn.getSourceOfIpAddress()); 
		apnBO.setAddressType(pApn.getApnType()); 
		apnBO.setMobileTerminationEnabled(pApn.getmT()); 
		apnBO.setMobileToMobileEnabled(pApn.getmToM()); 
		apnBO.setPriEntDnsServAdd(pApn.getpDNSAddress()); 
		apnBO.setSecEntDnsServAdd(pApn.getsDNSAddress()); 
		apnBO.setAmplifyingInformation(pApn.getAmpInfo()); 
		apnBO.setBackhaulType(pApn.getBhiInstanceType()); 
		apnBO.setDnsNotes(pApn.getDnsNotes()); 
		apnBO.setDnsServerIp(pApn.getDnsServerIp()); 
		apnBO.setPdpId(pApn.getPdpId()); 
		apnBO.setCreatedBy(pApn.getCreatedBy()); 
		apnBO.setCreatedOn(pApn.getCreatedOn()); 
		apnBO.setUpdatedBy(pApn.getUpdatedBy()); 
		apnBO.setUpdatedOn(pApn.getUpdatedOn()); 
		apnBO.setImportedInBatch(pApn.getBatchId()); 
 
		if(pApn.getUdPDPId()!=null){ 
			apnBO.setUserDefinedPdpId(pApn.getUdPDPId().toString()); 
		} 
		apnBO.setPcrf(pApn.getPcrf()); 
 
		double total = 0.0; 
		List<DedicatedMobilePoolAddressBO> mobilePoolAddresses = new ArrayList<DedicatedMobilePoolAddressBO>(); 
		if(pApn.getMobileIP()!=null &&  CommonUtils.isValidString(pApn.getMobileIP().substring(pApn.getMobileIP().indexOf("/")))) 
		{ 
			double cal = 32 - Double.parseDouble(pApn.getMobileIP().substring(pApn.getMobileIP().indexOf("/")+1)); 
			double powVal = Math.pow(2,cal); 
			total = total+powVal; 
			DedicatedMobilePoolAddressBO mobilePooladdress = new DedicatedMobilePoolAddressBO(); 
			mobilePooladdress.setIpAddress(pApn.getMobileIP()); 
			mobilePoolAddresses.add(mobilePooladdress); 
		} 
		apnBO.setMobilePoolAddresses(mobilePoolAddresses); 
		apnBO.setTotalMobilePoolSize(new Double(total).longValue()); 
		logger.info("Exiting method populateDedicatedApnBO ::", this);
		return apnBO; 
	}

	public MobilePoolAddressBO populateMobilePoolAddress(MobilePoolAddress mobilePoolAddressInfo) {
		logger.info("Starting method populateMobilePoolAddress ::", this);
		MobilePoolAddressBO mobilePoolAddressBO = new MobilePoolAddressBO(); 
		mobilePoolAddressBO.setIpAddress(mobilePoolAddressInfo.getIpAddress()); 
		logger.info("Exiting method populateMobilePoolAddress ::", this);
		return mobilePoolAddressBO; 
	}
	private Long calculateMobilePoolSize(List<String> totalSizeOfMobilePool, String apnProtocol) {
		logger.info("Starting method calculateMobilePoolSize :", this);

		double total = 0.0;
		Long totalMobilePoolSize = 0L;
		if(apnProtocol.equalsIgnoreCase("IPv6")){
			for (String strIp : totalSizeOfMobilePool) {
				double sub = Double.parseDouble(strIp);
				if(sub >= 1.0 && sub<=64.0) {
					double cal = 64 - sub;
					double powVal = Math.pow(2, cal);
					total = total + powVal;
				}else 
					if(sub>64.0 && sub<=128.0){
						double cal = 128 - sub;
						double powVal = Math.pow(2, cal);
						total = total + powVal;
					}
			}
		}else if(apnProtocol.equalsIgnoreCase("IPv4")){
			for (String strIp : totalSizeOfMobilePool) {
				double cal = 32 - Double.parseDouble(strIp);
				double powVal = Math.pow(2, cal);
				total = total + powVal;
			}
		}else{
			for (String strIp : totalSizeOfMobilePool) {
				double sub = Double.parseDouble(strIp);
				if(sub >= 1.0 && sub<=32.0) {
					double cal = 32 - sub;
					double powVal = Math.pow(2, cal);
					total = total + powVal;
				}else 
					if(sub>64.0 && sub<=128.0){
						double cal = 128 - sub;
						double powVal = Math.pow(2, cal);
						total = total + powVal;
					}else{
						if(sub>32.0 && sub<=64.0){
							double cal = 64 - sub;
							double powVal = Math.pow(2, cal);
							total = total + powVal;
						}
					}
			}
		}
		totalMobilePoolSize = new Double(total).longValue();

		logger.info("Exiting method calculateMobilePoolSize :", this);
		return totalMobilePoolSize;
	}
	private double calculateUniqueIPAddressSize(List<String> totalSizeOfMobilePool, Set<String> sizeOfUniqueIPAddresses, String apnProtocol) {
		double unq = 0.0;
		if (apnProtocol.equalsIgnoreCase("IPv6")) {
			for (String strUnq : totalSizeOfMobilePool) {
				if (strUnq != null && !strUnq.equalsIgnoreCase("")) {
					strUnq = strUnq.substring(strUnq.indexOf("/") + 1);
					double sub = Double.parseDouble(strUnq);
					if (sub >= 0 && sub <= 64.0) {
						double cal = 64 - sub;
						double powVal = Math.pow(2, cal);
						unq = unq + powVal;
					} else if (sub > 64.0 && sub <= 128.0) {
						double cal = 128 - sub;
						double powVal = Math.pow(2, cal);
						unq = unq + powVal;
					}
				}
			}
		}else if(apnProtocol.equalsIgnoreCase("IPv4")){
			if(sizeOfUniqueIPAddresses!=null && sizeOfUniqueIPAddresses.size()>0)
			{
				for (String strUnq : sizeOfUniqueIPAddresses) {
					if (strUnq != null && !strUnq.equalsIgnoreCase("")) {
						strUnq = strUnq.substring(strUnq.indexOf("/") + 1);
						double cal = 32 - Double.parseDouble(strUnq);
						double powVal = Math.pow(2, cal);
						unq = unq + powVal;
					}
				}
			}
		} else {
			for (String strIp : totalSizeOfMobilePool) {
				if (strIp != null && !strIp.equalsIgnoreCase("")) {
					double sub = Double.parseDouble(strIp);
					if (sub >= 1.0 && sub <= 32.0) {
						double cal = 32 - sub;
						double powVal = Math.pow(2, cal);
						unq = unq + powVal;
					} else if (sub > 64.0 && sub <= 128.0) {
						double cal = 128 - sub;
						double powVal = Math.pow(2, cal);
						unq = unq + powVal;
					} else {
						if (sub > 32.0 && sub <= 64.0) {
							double cal = 64 - sub;
							double powVal = Math.pow(2, cal);
							unq = unq + powVal;
						}
					}
				}
			}
		}
		return unq;
	}
	public ApnBO getTotalMobilePoolAndUnqIpSize(ApnBO apnBO, boolean activeDataCenterMoreThanOne, boolean dataCenterHasPassive){
		logger.info("Starting method getTotalMobilePoolAndUnqIpSize ::", this);

		Long totalMobPoolSize = 0L;
		double totalUniqueIPAddressSize = 0.0;
		List<String> totalSizeOfMobilePool = new ArrayList<String>();
		Set<String> sizeOfUniqueIPAddresses = new HashSet<String>();
		String subnet=null;
		if (!CollectionUtils.isEmpty(apnBO.getApnDomainProtocolConf().getMobilePoolAddresses())) {
			Set<MobilePoolAddressBO> mobilePoolAddressList = apnBO.getApnDomainProtocolConf().getMobilePoolAddresses().stream().collect(Collectors.toSet());
			if(!CollectionUtils.isEmpty(mobilePoolAddressList) && StringUtils.isNotBlank(apnBO.getApnDomainProtocolConf().getApnProtocol())) {
				for (MobilePoolAddressBO mobilePoolAddressBO : mobilePoolAddressList) {
					if (CommonUtils.isNotNullEmpty(mobilePoolAddressBO.getDataCenterId()) && mobilePoolAddressBO != null) {
						if(StringUtils.isNotBlank(mobilePoolAddressBO.getIpAddress()) && mobilePoolAddressBO.getIpAddress().contains("/")){
							subnet = mobilePoolAddressBO.getIpAddress().substring(mobilePoolAddressBO.getIpAddress().indexOf("/")+1,mobilePoolAddressBO.getIpAddress().length());
						}
						long seq = 1;
						if (subnet != null && !subnet.trim().equals("")) {
							totalSizeOfMobilePool.add(subnet);
							sizeOfUniqueIPAddresses.add(mobilePoolAddressBO.getIpAddress());
						}
						seq = seq + 1;
					}
				}
			}
		}
		if(!CollectionUtils.isEmpty(totalSizeOfMobilePool)) {
			totalMobPoolSize = calculateMobilePoolSize(totalSizeOfMobilePool, apnBO.getApnDomainProtocolConf().getApnProtocol());
		}
		if(!CollectionUtils.isEmpty(totalSizeOfMobilePool) && !CollectionUtils.isEmpty(sizeOfUniqueIPAddresses)) {
			totalUniqueIPAddressSize = calculateUniqueIPAddressSize(totalSizeOfMobilePool, sizeOfUniqueIPAddresses, apnBO.getApnDomainProtocolConf().getApnProtocol());
		}
		apnBO.getApnDomainProtocolConf().setTotalMobilePoolSize(totalMobPoolSize);
		if(activeDataCenterMoreThanOne && apnBO.getApnDomainProtocolConf().getApnProtocol().equalsIgnoreCase("IPv6") 
				&& !dataCenterHasPassive){
			apnBO.getApnDomainProtocolConf().setUniqueIPAddressSize(new Double(totalUniqueIPAddressSize+2).longValue());
		}else{
			apnBO.getApnDomainProtocolConf().setUniqueIPAddressSize(new Double(totalUniqueIPAddressSize).longValue());
		}
		
		logger.info("Exiting method getTotalMobilePoolAndUnqIpSize ::", this);
		return apnBO;
	}

	public Long countDuplicateApnName(String apnName, Long orderId) {
		logger.error("[OrderID : " + (orderId == null ? "" : orderId) + " countDuplicateApnName started ");
		logger.error("[APN Name : " + (apnName == null ? "" : apnName) + " countDuplicateApnName started ");

		Integer count = apnRepository.countDuplicateApnNameNative(apnName, orderId);
		if(count == null) {
			count = 0;
		}
		logger.info("Exiting Methode getBlankRequestIdListCount :" + count);
		return Long.valueOf(count.longValue());
	}
}
