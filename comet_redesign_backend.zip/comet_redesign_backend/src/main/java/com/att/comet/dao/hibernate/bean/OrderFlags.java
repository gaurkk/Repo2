package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * APN persistent class. Mapped to APN table in the database.
 */
@Entity
@Table(name = "ORDER_FLAGS")
public class OrderFlags implements Serializable{
	
	private static final long serialVersionUID = 2753590243394641676L;
	private Long flagId;
	private String flagName;
	private String flagDesc;
	
	
	@Id
	@Column(name = "FLAG_ID", unique = true, nullable = false)
	public Long getFlagId() {
		return flagId;
	}
	public void setFlagId(Long flagId) {
		this.flagId = flagId;
	}
	
	@Column(name = "FLAG_NAME", unique = true, nullable = false)
	public String getFlagName() {
		return flagName;
	}
	public void setFlagName(String flagName) {
		this.flagName = flagName;
	}
	@Column(name = "flag_desc")
	public String getFlagDesc() {
		return flagDesc;
	}
	public void setFlagDesc(String flagDesc) {
		this.flagDesc = flagDesc;
	}
	
}
