/**
 * 
 */
package com.att.comet.charts.result;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author gb270s
 *
 */
@Getter
@Setter
@ToString
public class ChartInfoBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7483380013461026308L;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String title;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int totalRecord;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int totalPages;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int currentPage;

}
