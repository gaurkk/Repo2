package com.att.comet.bpm.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.att.comet.bpm.modal.BpmUserBO;
import com.att.comet.bpm.modal.BpmUserResponseBO;
import com.att.comet.bpm.modal.GroupBO;
import com.att.comet.bpm.modal.TaskInfoBO;
import com.att.comet.bpm.modal.TaskListRequestBO;
import com.att.comet.bpm.modal.TaskListResponseBO;
import com.att.comet.bpm.modal.TaskLocalVariablesBO;
import com.att.comet.common.exception.BPMException;
import com.att.comet.common.exception.CometException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.configuration.ApplicationConfig;
import com.att.comet.order.dao.OrderConstants;
import com.att.comet.order.task.modal.BpmTaskFieldDataBO;

@Service
public class BPMServiceImpl implements BPMService {
	private static final Logger logger = LoggerFactory.getLogger(BPMServiceImpl.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	ApplicationConfig applicationConfig;

	private final String GROUP_NAME = "commet_group";
	private final String GROUP_TYPE = "common";
	
	private final String HISTORY_TASK = "/history/task";
	private final String TASK = "/task";
	private final String ADD_USER_PATH = "/user/create";
	private final String CREATE_GROUP = "/group/create";
	private final String ORDER_TASK_QUERY_PARAM = "processVariables=orderId_eq_";
	private final String LOCAL_VARIABLES = "/history/variable-instance";

	private String BPM_BASE_URL;
	private String GROUP_ID;

	@PostConstruct
	public void init() {
		BPM_BASE_URL = applicationConfig.getCamundaBaseUrl();
		GROUP_ID = applicationConfig.getCamundaGroupId();
	}
	
	@Override
	public TaskListResponseBO getOrderTaskList(TaskListRequestBO requestBO) {
		logger.debug("BPMServiceImpl::getOrderTaskList Getting order tasks");
		String requestUri = BPM_BASE_URL + HISTORY_TASK;
		TaskListResponseBO taskListResponseBO = restTemplate.postForObject(requestUri, requestBO, TaskListResponseBO.class);
		return taskListResponseBO;
	}
	
	@Override
	public List<TaskInfoBO> getOrderTaskList(Long orderId) throws RestClientException, 
																	URISyntaxException, 
																	BPMException {
		logger.debug("BPMServiceImpl::getOrderTaskList Getting tasks for order ID:" + orderId);
		
		String requestPath = BPM_BASE_URL + HISTORY_TASK;
		String queryPath = ORDER_TASK_QUERY_PARAM + orderId;
		String requestUri = requestPath + "?" + queryPath;
		List<TaskInfoBO> taskInfoBOList = null;
		
		try{ 
			URI uri = new URI(requestUri);
			ResponseEntity<TaskInfoBO[]> response = restTemplate.getForEntity(uri, TaskInfoBO[].class);
	
			if (200 == response.getStatusCodeValue()) {
				logger.info("Successfully retrived tasks for Order ID: " + orderId);
				taskInfoBOList = Arrays.asList(response.getBody());
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while getting order tasks for order id: " + orderId);
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
		
		return taskInfoBOList;
	
	}
	
	@Override
	public TaskListResponseBO getUserAssignedTasks(String attuid) throws RestClientException, URISyntaxException {
		if (null == attuid) {
			logger.info("Invalid attuid for user tasks");
			return null;
		}
		
		logger.debug("BPMServiceImpl::getUserAssignedTasks Getting assigned tasks for user : " + attuid);
		
		TaskListResponseBO taskListResponseBO = null;
		String requestPath = BPM_BASE_URL + TASK;
		String queryParam = "?assignee=" + attuid; 
		String requestUri = requestPath + queryParam;
		
		try {
			URI uri = new URI(requestUri);
			ResponseEntity<TaskListResponseBO> response = restTemplate.getForEntity(uri, TaskListResponseBO.class);
			
			if (200 == response.getStatusCodeValue()) {
				logger.debug("User assigned tasks successfully retrived for userid : " + attuid);
			}
			taskListResponseBO = response.getBody();
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during getting user assigned tasks for userid : " + attuid);
			throw e;
		}
		
		return taskListResponseBO;
	}

	@Override
	public Map<String, Set<String>> assignTasksToUser(String assignUserAttuid, Set<String> taskIds) throws RestClientException, URISyntaxException {
		if (CommonUtils.isNullEmpty(assignUserAttuid) || null == taskIds) {
			logger.info("Invalid user tasks assignment request");
			return null;
		} else if (taskIds.isEmpty()) {
			logger.info("Task id list should not be empty");
			return null;
		}
		
		Map<String, Set<String>> taskMap = new HashMap<String, Set<String>>();
		Set<String> successTaskIds = new HashSet<String>();
		Set<String> failedTaskIds = new HashSet<String>();
		logger.debug("BPMServiceImpl::assignUserTasks Assigning tasks to user : " + assignUserAttuid);
		
		for (String taskId : taskIds)  {
			Boolean isAssigned = false;
			try {
				isAssigned = this.assignTask(taskId, assignUserAttuid);
				
				if (isAssigned) {
					successTaskIds.add(taskId);
				} else {
					failedTaskIds.add(taskId);
				}
				
			} catch (Exception e) {
				failedTaskIds.add(taskId);
				logger.error("Exception found during task assignment for taskId : " + taskId);
			}
		}
				
		taskMap.put("success", successTaskIds);
		taskMap.put("failed", failedTaskIds);
		
		return taskMap;
	}

	@Override
	public BpmUserBO addUser(BpmUserBO bpmUserBO) throws RestClientException, URISyntaxException, CometException {
		if (null == bpmUserBO) {
			logger.info("Invalid details for user add");
			return null;
		}
		
		logger.debug("BPMServiceImpl::addUser Adding user for attuid: " + bpmUserBO.getProfile().getId());
		String userId = bpmUserBO.getProfile().getId();
		
		// Verify the user group; create it if not exists 
		GroupBO groupBO = new GroupBO();
		groupBO.setId(GROUP_ID);
		groupBO.setName(GROUP_NAME);
		groupBO.setType(GROUP_TYPE);
		
		GroupBO group = this.getOrCreateUserGroup(groupBO);
		
		if (null == group) {
			throw new CometException("Unable to get or create the user group");
		}
		
		// Get the user if exists
		BpmUserResponseBO bpmUserResponseBO = this.getUser(userId);
		
		if (null != bpmUserResponseBO) {
			logger.debug("User already exists for attuid: " + userId);
			return bpmUserBO;
		}

		// Add the user	
		String requestUri = BPM_BASE_URL + ADD_USER_PATH;
		
		try {
			URI uri = new URI(requestUri);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, bpmUserBO, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.debug("User added successfully for id : " + userId);
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during adding user for id: " + userId);
			throw e;
		}

		// Add user to the group
		addUserToGroup(group, bpmUserBO);
		
		return bpmUserBO;
	}
	
	@Override
	public void addUserToGroup(GroupBO groupBO, BpmUserBO bpmUserBO) throws RestClientException, URISyntaxException, CometException {
		if (null == groupBO || null == bpmUserBO) {
			throw new CometException("Invalid data to add/update user in usergroup");
		}
		
		String userId = bpmUserBO.getProfile().getId();
		String groupId = groupBO.getId();
		String requestUri = BPM_BASE_URL + "/group/" + groupId + "/members/" + userId;
		
		try {
			URI uri = new URI(requestUri);
			restTemplate.put(uri, null);
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during adding user to group for user id: " + userId);
			throw e;
		}
	}
	
	@Override
	public BpmUserResponseBO getUser(String attuid) throws RestClientException, URISyntaxException {
		if (CommonUtils.isNullEmpty(attuid)) {
			logger.info("Invalid user id");
			return null;
		}
		
		logger.debug("BPMServiceImpl::getUserProfile Getting user for id: " + attuid);
		BpmUserResponseBO bpmUserResponseBO = null;
		String requestUri = BPM_BASE_URL + "/user/" + attuid + "/profile";
		
		try {
			URI uri = new URI(requestUri);
			ResponseEntity<BpmUserResponseBO> response = restTemplate.getForEntity(uri, BpmUserResponseBO.class);
			if (200 == response.getStatusCodeValue()) {
				bpmUserResponseBO = response.getBody();
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during fetching user for id: " + attuid);
			throw e;
		}
		
		return bpmUserResponseBO;
	}
	
	@Override
	public GroupBO getOrCreateUserGroup(GroupBO groupBO) throws RestClientException, URISyntaxException {
		// Check the default user group; if does not exist, then create
		logger.debug("BPMServiceImpl::getCreateUserGroup Getting or Creating Camunda User Group");
		
		String groupId = groupBO.getId();
		String requestUri = null;
		
		// Get the group
		requestUri = BPM_BASE_URL + "/group/" + groupId;
		
		try {
			URI uri = new URI(requestUri);
			ResponseEntity<String> response = restTemplate.getForEntity(uri, String.class);
		
			if (200 == response.getStatusCodeValue()) {
				logger.info("Group already exists with ID : " + groupId);
				return groupBO;
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during getting group for id: " + groupId);
			throw e;
		}
		
		// Create group
		requestUri = BPM_BASE_URL + CREATE_GROUP;
		
		try {
			URI uri = new URI(requestUri);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, groupBO, String.class);
	
			if (204 == response.getStatusCodeValue()) {
				logger.info("Group created successfully with ID : " + groupId);
				return groupBO;
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException during creating group for id: " + groupId);
			throw e;
		}
		
		return null;
	}
	
	@Override
	public Boolean claimTask(String taskId, String attuid) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || CommonUtils.isNullEmpty(attuid)) {
			logger.debug("Invalid info for claiming a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::claimTask User [" + attuid + "] claiming task ID [" + taskId + "]");
		
		String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/claim";
		Boolean isClaimSuccess = false;
		logger.debug("BPMServiceImpl::requestUri = [" +requestUri+"]");
		try{ 
			URI uri = new URI(requestUri);
			Map<String, String> user = new HashMap<String, String>();
			user.put("userId", attuid);
			
			ResponseEntity<String> response = restTemplate.postForEntity(uri, user, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.info("Successfully claimed the task ID: " + taskId);
				isClaimSuccess = true;
			} else if (500 == response.getStatusCodeValue()) {
				logger.info("Claiming the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while user [" + attuid + "] claiming task ID [" + taskId + "]"+e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			logger.debug("Exception while user [" + attuid + "] claiming task ID [" + taskId + "]"+e.getMessage());
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return isClaimSuccess;
	}
	
	@Override
	public Boolean unclaimTask(String taskId) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId)) {
			logger.debug("Invalid info for unclaiming a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::unclaimTask Unclaiming task ID [" + taskId + "]");
		
		String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/unclaim";
		Boolean isUnclaimSuccess = false;
		logger.debug("BPMServiceImpl::requestUri ::[" + requestUri + "]");
		try{ 
			URI uri = new URI(requestUri);
			
			ResponseEntity<String> response = restTemplate.postForEntity(uri, null, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.info("Successfully unclaimed the task ID: " + taskId);
				isUnclaimSuccess = true;
			} else if (400 == response.getStatusCodeValue()) {
				logger.info("Unclaiming the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while unclaiming task ID [" + taskId + "]"+e.getStackTrace());
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("RestClientException while unclaiming task ID [" + taskId + "]"+e.getStackTrace());
			throw new BPMException(e.getMessage());
		}
	
		return isUnclaimSuccess;
	}

	@Override
	public Boolean assignTask(String taskId, String attuid) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || CommonUtils.isNullEmpty(attuid)) {
			logger.debug("Invalid info for assigning a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::assignTask Task ID [" + taskId + "] is assigning to user [" + attuid + "]");
		
		String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/assignee";
		Boolean isAssignSuccess = false;
		
		try{ 
			URI uri = new URI(requestUri);
			Map<String, String> user = new HashMap<String, String>();
			user.put("userId", attuid);
			
			ResponseEntity<String> response = restTemplate.postForEntity(uri, user, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.info("Successfully assigned the task ID: " + taskId + " to user: " + attuid);
				isAssignSuccess = true;
			} else if (500 == response.getStatusCodeValue()) {
				logger.info("Assigning the task ID: " + taskId + " to user: " + attuid + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while assigning the task ID [" + taskId + "] to user [" + attuid + "]"+e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return isAssignSuccess;
	}
	
	@Override
	public Boolean completeTask(String taskId, BpmTaskFieldDataBO bpmTaskFieldDataBO) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || null == bpmTaskFieldDataBO) {
			logger.debug("Invalid info for completing a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::completeTask Task ID: " + taskId);
		
		String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/complete";
		Boolean isCompleteSuccess = false;
		
		try{ 
			URI uri = new URI(requestUri);

			if(saveTask(taskId, bpmTaskFieldDataBO)) {
				Map<String, Object> taskVariablesMap = this.prepareProcessVariablesForTaskCompletion(bpmTaskFieldDataBO);
				ResponseEntity<String> response = restTemplate.postForEntity(uri, taskVariablesMap, String.class);
				
				if (204 == response.getStatusCodeValue() ||
						200 == response.getStatusCodeValue()) {
					logger.info("Successfully completed the task ID: " + taskId);
					isCompleteSuccess = true;
				} else if (500 == response.getStatusCodeValue() ||
						400 == response.getStatusCodeValue()) {
					logger.info("Completing the task ID: " + taskId + " was not successful");
				}
			} else {
				logger.info("Task save failed. Completing the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while completing the task ID [" + taskId + "]");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return isCompleteSuccess;
	}

	@Override
	public Boolean saveTask(String taskId, BpmTaskFieldDataBO bpmTaskFieldDataBO) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || null == bpmTaskFieldDataBO) {
			logger.debug("Invalid info for saving a task");
			return false;
		}
		
		logger.debug("BPMServiceImpl::saveTask Task ID: " + taskId);
		
		String requestUri = BPM_BASE_URL + TASK + "/" + taskId + "/localVariables";
		Boolean isSaveSuccess = false;
		
		try{ 
			URI uri = new URI(requestUri);
			Map<String, Object> taskVariablesMap = this.prepareLocalVariablesForTask(bpmTaskFieldDataBO);
			
			ResponseEntity<String> response = restTemplate.postForEntity(uri, taskVariablesMap, String.class);
			
			if (204 == response.getStatusCodeValue()) {
				logger.info("Successfully saved the task ID: " + taskId);
				isSaveSuccess = true;
			} else if (500 == response.getStatusCodeValue()
						|| 400 == response.getStatusCodeValue()) {
				logger.info("Saving the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while saving the task ID [" + taskId + "]");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return isSaveSuccess;				
	}

	@Override
	public List<TaskLocalVariablesBO> getTaskLocalVariables(String taskId, String name) throws RestClientException, URISyntaxException, BPMException {
		if (CommonUtils.isNullEmpty(taskId) || CommonUtils.isNullEmpty(name)) {
			logger.debug("Invalid info for getting task local variables");
		}
		
		logger.debug("BPMServiceImpl::getTaskLocalVariables Getting local variables for task ID [" + taskId + "]");
		
		String requestPath = BPM_BASE_URL + LOCAL_VARIABLES;
		String queryPath = "taskIdIn=" + taskId + "&variableName=" + name;  
		String requestUri = requestPath + "?" + queryPath;
		List<TaskLocalVariablesBO> taskLocalVariablesList = null;
		
		try{ 
			URI uri = new URI(requestUri);
			ResponseEntity<TaskLocalVariablesBO[]> response = restTemplate.getForEntity(uri, TaskLocalVariablesBO[].class);
			
			if (200 == response.getStatusCodeValue()) {
				logger.info("Successfully retrived the local varivbles for the task ID: " + taskId);
				taskLocalVariablesList = Arrays.asList(response.getBody());
			} else if (400 == response.getStatusCodeValue()) {
				logger.info("Retriving the local variables for the task ID: " + taskId + " was not successful");
			}
		} catch (URISyntaxException e) { 
			logger.debug("URISyntaxException during URI generate for URL : " + requestUri);
			e.printStackTrace();
			throw e;
		} catch (RestClientException e) {
			logger.debug("RestClientException while retriving local variables for task ID [" + taskId + "]");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw new BPMException(e.getMessage());
		}
	
		return taskLocalVariablesList;
	}
	
	private Map<String, Object> prepareLocalVariablesForTask(BpmTaskFieldDataBO bpmTaskFieldDataBO) throws CometException {
		if (null == bpmTaskFieldDataBO) {
			throw new CometException("TaskServiceImpl::prepareLocalVariablesForTask -- Invalid task field data");
		}
		
		logger.info("TaskServiceImpl::prepareLocalVariablesForTask -- Start");
		
		Map<String, Object> dataMap = new HashMap<String, Object>();
		Map<String, Object> valueMap = new HashMap<String, Object>();
		Map<String, Object> inputMap = new HashMap<String, Object>();
		Map<String, Object> variablesMap = new HashMap<String, Object>();
		
		if (null != bpmTaskFieldDataBO.getComments()) {
			String comments = "'" + bpmTaskFieldDataBO.getComments().replaceAll("\n"," ").trim() + "'";
			dataMap.put("comments", comments);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketNum()) {
			String ticketNum = "'" + bpmTaskFieldDataBO.getTicketNum() + "'";
			dataMap.put("ticketNum", ticketNum);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketCreateDate()) {
			String ticketCreateDate = "'" + bpmTaskFieldDataBO.getTicketCreateDate() + "'";
			dataMap.put("ticketCreateDate", ticketCreateDate);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuRescheduleDateTime()) {
			String ttuRescheduleDateTime = "'" + bpmTaskFieldDataBO.getTtuRescheduleDateTime() + "'";
			dataMap.put("ttuRescheduleDateTime", ttuRescheduleDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getReasonForReschedule()) {
			String reasonForReschedule = "'" + bpmTaskFieldDataBO.getReasonForReschedule() + "'";
			dataMap.put("reasonForReschedule", reasonForReschedule);
		}
		
		if (null != bpmTaskFieldDataBO.getResponse()) {
			String response = "'" + bpmTaskFieldDataBO.getResponse() + "'";
			dataMap.put("response", response);
		}
		
		if (null != bpmTaskFieldDataBO.getCompletedDate()) {
			String completedDate = "'" + bpmTaskFieldDataBO.getCompletedDate() + "'";
			dataMap.put("completedDate", completedDate);
		}
		
		if (null != bpmTaskFieldDataBO.getApnIWOSbuildConfirmation()) {
			String apnIWOSbuildConfirmation = "'" + bpmTaskFieldDataBO.getApnIWOSbuildConfirmation() + "'";
			dataMap.put("apnIWOSbuildConfirmation", apnIWOSbuildConfirmation);
		}
		
		if (null != bpmTaskFieldDataBO.getIsPreFlightTestOccurred()) {
			String isPreFlightTestOccurred = "'" + bpmTaskFieldDataBO.getIsPreFlightTestOccurred() + "'";
			dataMap.put("isPreFlightTestOccurred", isPreFlightTestOccurred);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingResult()) {
			String preFlightTestingResult = "'" + bpmTaskFieldDataBO.getPreFlightTestingResult() + "'";
			dataMap.put("preFlightTestingResult", preFlightTestingResult);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingDateTime()) {
			String preFlightTestingDateTime = "'" + bpmTaskFieldDataBO.getPreFlightTestingDateTime() + "'";
			dataMap.put("preFlightTestingDateTime", preFlightTestingDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getIsTTURequired()) {
			String isTTURequired = "'" + bpmTaskFieldDataBO.getIsTTURequired() + "'";
			dataMap.put("isTTURequired", isTTURequired);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuScheduleDateTime()) {
			String ttuScheduleDateTime = "'" + bpmTaskFieldDataBO.getTtuScheduleDateTime() + "'";
			dataMap.put("ttuScheduleDateTime", ttuScheduleDateTime);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder()) {
			String ttuIsPerformedForTheOrder = "'" + bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder() + "'";
			dataMap.put("ttuIsPerformedForTheOrder", ttuIsPerformedForTheOrder);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuResult()) {
			String ttuResult = "'" + bpmTaskFieldDataBO.getTtuResult() + "'";
			dataMap.put("ttuResult", ttuResult);
		}
		
		if (null != bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber()) {
			String securityEngrIwosTicketNumber = "'" + bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber() + "'";
			dataMap.put("securityEngrIwosTicketNumber", securityEngrIwosTicketNumber);
		}
		
		if (null != bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate()) {
			String proposedExpediteBuildCompletionDate = "'" + bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate() + "'";
			dataMap.put("proposedExpediteBuildCompletionDate", proposedExpediteBuildCompletionDate);
		}
		
		if (null != bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate()) {
			String finalExpediteBuildCompletionDate = "'" + bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate() + "'";
			dataMap.put("finalExpediteBuildCompletionDate", finalExpediteBuildCompletionDate);
		}
		
		valueMap.put("value", dataMap);
		valueMap.put("type", "String");
		inputMap.put(OrderConstants.BPM_TASK_LOCAL_VARIABLES_NAME, valueMap);
		variablesMap.put("modifications", inputMap);
		
		logger.info("TaskServiceImpl::prepareLocalVariablesForTask -- End");
		return variablesMap;
	}
	
	private Map<String, Object> prepareProcessVariablesForTaskCompletion(BpmTaskFieldDataBO bpmTaskFieldDataBO) throws CometException {
		if (null == bpmTaskFieldDataBO) {
			throw new CometException("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- Invalid task field data");
		}
		
		logger.info("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- Start");
		
		Map<String, Object> dataMap = null;
		Map<String, Object> inputMap = new HashMap<String, Object>();
		Map<String, Object> variablesMap = new HashMap<String, Object>();
		
		if (null != bpmTaskFieldDataBO.getComments()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getComments().replaceAll("\n"," ").trim());
			dataMap.put("type", "String");
			inputMap.put("comments", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketNum()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTicketNum());
			dataMap.put("type", "String");
			inputMap.put("ticketNum", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTicketCreateDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTicketCreateDate());
			dataMap.put("type", "String");
			inputMap.put("ticketCreateDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuRescheduleDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuRescheduleDateTime());
			dataMap.put("type", "String");
			inputMap.put("ttuRescheduleDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getReasonForReschedule()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getReasonForReschedule());
			dataMap.put("type", "String");
			inputMap.put("reasonForReschedule", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getResponse()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getResponse());
			dataMap.put("type", "String");
			inputMap.put("response", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getCompletedDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getCompletedDate());
			dataMap.put("type", "String");
			inputMap.put("completedDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getApnIWOSbuildConfirmation()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getApnIWOSbuildConfirmation());
			dataMap.put("type", "String");
			inputMap.put("apnIWOSbuildConfirmation", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getIsPreFlightTestOccurred()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getIsPreFlightTestOccurred());
			dataMap.put("type", "String");
			inputMap.put("isPreFlightTestOccurred", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingResult()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getPreFlightTestingResult());
			dataMap.put("type", "String");
			inputMap.put("preFlightTestingResult", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getPreFlightTestingDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getPreFlightTestingDateTime());
			dataMap.put("type", "String");
			inputMap.put("preFlightTestingDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getIsTTURequired()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getIsTTURequired());
			dataMap.put("type", "String");
			inputMap.put("isTTURequired", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuScheduleDateTime()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuScheduleDateTime());
			dataMap.put("type", "String");
			inputMap.put("ttuScheduleDateTime", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuIsPerformedForTheOrder());
			dataMap.put("type", "String");
			inputMap.put("ttuIsPerformedForTheOrder", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getTtuResult()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getTtuResult());
			dataMap.put("type", "String");
			inputMap.put("ttuResult", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getSecurityEngrIwosTicketNumber());
			dataMap.put("type", "String");
			inputMap.put("securityEngrIwosTicketNumber", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getProposedExpediteBuildCompletionDate());
			dataMap.put("type", "String");
			inputMap.put("proposedExpediteBuildCompletionDate", dataMap);
		}
		
		if (null != bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate()) {
			dataMap = new HashMap<String, Object>();
			dataMap.put("value", bpmTaskFieldDataBO.getFinalExpediteBuildCompletionDate());
			dataMap.put("type", "String");
			inputMap.put("finalExpediteBuildCompletionDate", dataMap);
		}
		
		variablesMap.put("variables", inputMap);
		
		logger.info("TaskServiceImpl::prepareProcessVariablesForTaskCompletion -- End");
		return variablesMap;
	}
}
