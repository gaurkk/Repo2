package com.att.comet.common.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.BpmOrderBusinessStep;

@Repository
public interface BpmOrderBusinessStepRespository extends JpaRepository<BpmOrderBusinessStep,Long> {
	@Query("from BpmOrderBusinessStep where orders.orderId =:orderId")
	List<BpmOrderBusinessStep> findOrderBusinessByOrderId(Long orderId);
	
	@Query(value = "select count(*) from bpm_order_business_step where order_id = :orderId and business_step_id = 3179 and business_step_status = 'Rejected'",nativeQuery = true)
	Long findOrderBusinessByOrderIdAndBusinessStep(String orderId);
}
