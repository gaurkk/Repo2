package com.att.comet.common.constant;

public enum AMPStatus {
	
	CREATED  		    (1001L, "CREATED"),
	SYNC_READY 			(1002L, "SYNC_READY"),
	COMPLETED  			(1003L, "COMPLETED"),
	FAULTED				(1004L, "FAULTED"),
	CANCELLED			(1005L, "CANCELLED"),
	REJECTED			(1006L, "REJECTED");
	
	
	/**
	 * 
	 * property variable id
	 */
	private final Long id;
	
	/**
	 * property variable name
	 */
	private final String name;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	
	/**
	 * The method is used to get the name of the type of the order.
	 * @param id
	 * @return AMP Status , if the id is not null otherwise null.
	 */
	public static AMPStatus getName(Long id) {
		if(id != null) {
			for(AMPStatus ampStatus : AMPStatus.values()) {
				if (ampStatus.getId().longValue() == id.longValue()) {
					return ampStatus;
				}
			}
		}
		return null;
	}
	
	/**
	 * Argument Constructor.
	 * @param id
	 * @param name
	 */
	private AMPStatus(Long id, String name) {
		this.id = id;
		this.name = name;
	}

}
