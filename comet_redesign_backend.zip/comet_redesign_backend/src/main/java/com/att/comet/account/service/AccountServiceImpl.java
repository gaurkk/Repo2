package com.att.comet.account.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.rowset.serial.SerialException;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.account.dao.AccountDAO;
import com.att.comet.account.modal.AccountBO;
import com.att.comet.account.modal.AccountFileDetailBO;
import com.att.comet.account.modal.AccountInfoBO;
import com.att.comet.account.modal.AccountSearchCriteriaBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;

@Service
public class AccountServiceImpl implements AccountService {
	private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

	@Autowired
	AccountDAO accountDAO;

	@Override
	public List<AccountBO> getExternalAccounts(AccountSearchCriteriaBO criteria)
			throws CometServiceException, CometDataException {
		logger.info("Starting method getExternalAccounts : ", this);
		List<AccountBO> accountlist = new ArrayList<AccountBO>();

		try {
			logger.debug("Getting external accounts started.");
			logger.debug("Criteria Object received " + criteria);
			accountlist = accountDAO.getExternalAccounts(criteria);
			logger.debug("Getting external accounts finshed.");
		} catch (CometDataException exception) {
			/// logger.error(exception.getStackTrace());
			exception.printStackTrace();
			logger.error("Exception in getting external accounts", exception);
			throw exception;
		} catch (Exception exception) {
			/// logger.error(exception.getStackTrace());
			exception.printStackTrace();
			logger.error("Exception in getting external accounts");
			throw new CometServiceException("Error", exception);
		}
		logger.info("Exiting method getExternalAccounts : ", this);
		return accountlist;
	}

	@Override
	public List<AccountBO> getInternalAccounts(AccountSearchCriteriaBO criteria)
			throws CometServiceException, CometDataException {
		logger.info("Starting method getInternalAccounts : ", this);
		List<AccountBO> accountList = new ArrayList<AccountBO>();
		try {
			logger.debug("Getting internal accounts started.");
			accountList = accountDAO.getInternalAccounts(criteria);
			logger.debug("Getting internal accounts finished.");
		} catch (CometDataException exception) {
			/// logger.error(exception.getStackTrace());
			exception.printStackTrace();
			logger.error("Exception in getting internal accounts", exception);
			throw exception;
		} catch (Exception exception) {
			/// logger.error(exception.getStackTrace());
			exception.printStackTrace();
			logger.error("Exception in getting internal accounts");
			throw new CometServiceException("Error", exception);
		}
		logger.info("Exiting method getInternalAccounts : ", this);
		return accountList;
	}

	public List<String> getMasterAccountNameList(String criteria) throws CometDataException {
		logger.info("Starting method getMasterAccountNameList : ", this);
		List<String> masterAccountNameList = accountDAO.findMasterAccountNameList(criteria);
		if (null == masterAccountNameList) {
			masterAccountNameList = new ArrayList<String>();
		}
		logger.info("Exiting method getMasterAccountNameList : ", this);
		return masterAccountNameList;
	}

	public List<String> getSubAccountNameList(String criteria) throws CometDataException {
		logger.info("Starting method getSubAccountNameList : ", this);
		List<String> subAccountNameList = accountDAO.findSubAccountNameList(criteria);
		if (null == subAccountNameList) {
			subAccountNameList = new ArrayList<String>();
		}
		logger.info("Exiting method getSubAccountNameList : ", this);
		return subAccountNameList;
	}

	public List<String> getInternalInitiativeAccountNameList(String criteria) throws CometDataException {
		logger.info("Starting method getInternalInitiativeAccountNameList : ", this);
		List<String> internalInitiativeAccountNameList = accountDAO.findInternalInitiativeAccountNameList(criteria);
		if (null == internalInitiativeAccountNameList) {
			internalInitiativeAccountNameList = new ArrayList<String>();
		}
		logger.info("Exiting method getInternalInitiativeAccountNameList : ", this);
		return internalInitiativeAccountNameList;
	}

	public List<String> getProductInitiativeAccountNameList(String criteria) throws CometDataException {
		logger.info("Starting method getProductInitiativeAccountNameList : ", this);
		List<String> productInitiativeAccountNameList = accountDAO.findProductInitiativeAccountNameList(criteria);
		if (null == productInitiativeAccountNameList) {
			productInitiativeAccountNameList = new ArrayList<String>();
		}
		logger.info("Exiting method getProductInitiativeAccountNameList : ", this);
		return productInitiativeAccountNameList;
	}

	public List<String> getApnNameList(String criteria) throws CometDataException {
		logger.info("Starting method getApnNameList : ", this);
		List<String> apnNameList = accountDAO.findApnNameList(criteria);
		if (null == apnNameList) {
			apnNameList = new ArrayList<String>();
		}
		logger.info("Exiting method getApnNameList : ", this);
		return apnNameList;
	}

	@Override
	@Transactional
	public AccountInfoBO getAccountInfo(String accountClassId, String accountId)
			throws CometServiceException, CometDataException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method getAccountInfo : ",
				this);
		if (StringUtils.isEmpty(accountClassId) || StringUtils.isEmpty(accountId)) {
			logger.debug("Account Class or AccountId is null", this);
			return null;
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method getAccountInfo : ",
				this);
		return accountDAO.getAccountInfo(accountClassId, accountId);
	}

	@Override
	@Transactional
	public AccountInfoBO updateAccountInfo(AccountInfoBO accountInfoBO) throws CometDataException, IOException {
		return accountDAO.updateAccountInfo(accountInfoBO);
	}

	@Override
	@Transactional
	public boolean deleteAccount(String accountClassId, String accountId)
			throws CometServiceException, CometDataException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method deleteAccount : ",
				this);
		boolean isAccountDeleted = false;
		if (StringUtils.isEmpty(accountClassId) || StringUtils.isEmpty(accountId)) {
			logger.error("AccountClass Id or Account Id is null", this);
			throw new CometDataException("Error : " + "[AccountClass Id  : " + accountClassId + " ]" + "or"
					+ "[Account Id  : " + accountId + "]" + "is null");
		}
		if ("1001".equals(accountClassId.trim())) {
			isAccountDeleted = accountDAO.deleteSubAccount(accountId);
		} else if ("1002".equals(accountClassId.trim()) || "1003".equals(accountClassId.trim())) {
			isAccountDeleted = accountDAO.deleteInternalProductAccount(accountId);
		}
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method deleteAccount : ",
				this);
		return isAccountDeleted;
	}

	@Override
	@Transactional
	public AccountInfoBO createAccount(AccountInfoBO accountInfoBO)
			throws CometDataException, IOException, CometServiceException {
		return accountDAO.createAccount(accountInfoBO);
	}

	@Override
	public AccountFileDetailBO getFileDetails(String accountClassId, String accountId)
			throws CometDataException, SQLException {
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Starting method getFileDetails : ",
				this);
		if (StringUtils.isEmpty(accountClassId) || StringUtils.isEmpty(accountId)) {
			logger.error("Account Class or AccountId is null", this);
			throw new CometDataException("Account Class or AccountId is null");
		}
		AccountFileDetailBO accountFileDetailBO = accountDAO.getFileDetails(accountClassId, accountId);
		logger.info("[AccountID : " + (accountId == null ? "" : accountId) + "] " + "Exiting method getFileDetails : ",
				this);
		return accountFileDetailBO;
	}
	
	@Override
	@Transactional
	public String storeFile(MultipartFile file, String accountId, Long accClassId)
			throws CometDataException, IOException, CometServiceException, SerialException, SQLException {
		return accountDAO.storeFile(file, accountId, accClassId);
	}
	
	@Override
	@Transactional
	public List<MasterAccountBO> getExistingAccList() throws CometDataException, CometServiceException {
		return accountDAO.getExistingAccList();
	}
	
	@Override
	@Transactional
	public boolean delAccountAttachment(String accountClassId, String accountId)
			throws CometServiceException, CometDataException {
		return accountDAO.delAccountAttachment(accountClassId, accountId);
	}
}
