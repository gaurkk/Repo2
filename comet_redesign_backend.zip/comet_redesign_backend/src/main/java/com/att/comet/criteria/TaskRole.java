package com.att.comet.criteria;

public enum TaskRole {
	ORDER_SUBMITTER("OS", 1001L), 
	OSD("OS", 1001L), 
	ORDER_APPROVER("OA", 1002L), 
	ORDER_MANAGER("OM", 1003L),
	NETWORK_IMPLEMENTATION("NI", 1004L), 
	CCS_PM("CCS PM", 1005L), 
	ADMIN("", 1006L), 
	GUEST("GUEST", 1007L),
	IT_OPS("IT OPS", 1008L);

	private String value;
	private Long roleId;

	private TaskRole(String value, Long roleId) {
		this.setValue(value);
		this.setRoleId(roleId);
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public static TaskRole getTaskRole(Long roleId) {
		for (TaskRole e : TaskRole.values()) {
			if (e.getRoleId().equals(roleId))
				return e;
		}
		return null;
	}

	public static TaskRole getTaskRoleId(String value) {
		for (TaskRole e : TaskRole.values()) {
			if (e.getValue().equals(value))
				return e;
		}
		return null;
	}
}
