package com.att.comet.manage.modal;

import lombok.Data;

@Data
public class InventoryTemplateBO {
	
	private Long colNumber;
	private String fieldName;
	private String templateName;
}