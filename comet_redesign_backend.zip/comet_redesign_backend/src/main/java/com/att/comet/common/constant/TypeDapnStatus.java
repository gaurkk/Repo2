package com.att.comet.common.constant;

/**
 * Contains all possible Dapn Status types available in Comet.
 */
public enum TypeDapnStatus {

	NEW(1000L, "New"), IN_PROGRESS(1001L, "In Progress"), SUBMITTED(1002L,
			"Submitted"), CANCELLED(1003L, "Cancelled"), CCS_PM_UPDATE(1004L,
			"CCSPM Update"), CCS_PM_UPDATE_COMPLETED(1005L,
			"CCSPM Update Completed"), NI_UPDATE(1006L, "NI Update"), NI_UPDATE_COMPLETED(
			1007L, "NI Update Completed"), AVAILABLE(1008L, "Available"), ASSIGNED(
			1009L, "Assigned"), HISTORY(1010L, "History");

	/**
	 * property variable id
	 */
	private final Long id;

	/**
	 * property variable name
	 */
	private final String name;

	/**
	 * Getter method for id.
	 * 
	 * @return Long
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Getter method for name
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * The method is used to get the status based upon the id of the status.
	 * 
	 * @param id
	 * @return TypeDapnStatus, if parameter id is not null otherwise null.
	 */
	public static TypeDapnStatus getStatus(Long id) {
		if (id != null) {
			for (TypeDapnStatus orderStatus : TypeDapnStatus.values()) {
				if (orderStatus.getId().longValue() == id.longValue()) {
					return orderStatus;
				}
			}
		}
		return null;
	}

	/**
	 * Argument constructor
	 * 
	 * @param id
	 * @param name
	 */
	private TypeDapnStatus(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}
