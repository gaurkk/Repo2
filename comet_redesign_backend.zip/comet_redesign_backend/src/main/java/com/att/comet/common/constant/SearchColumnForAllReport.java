package com.att.comet.common.constant;

import org.apache.commons.lang3.StringUtils;

public enum SearchColumnForAllReport {
	ACCA_HEALTH_CHECK ("ACCA_HEALTH_CHECK_ENABLE","acca_health_check_enable@@BOOLEAN"),
	ACCOUNT_CLASS     ("ACCOUNT CLASS","account_class@@STRING"),
	ACCOUNT_NAME ("ACCOUNT NAME","account_name@@STRING"),
	ACTIVE_PASSIVE ("ACTIVE PASSIVE","active_passive@@STRING"),
	ADDRESS_TYPE ("ADDRESS TYPE","address_type@@STRING"),
	AMP_ENABLE ("AMP_ENABLE","isAmp@@STRING"),
	APN_NAME ("APN NAME","apn_name@@STRING"),
	APN_STATUS ("APN STATUS","apn_status@@STRING"),	
	ATT_RADIUS ("ATT RADIUS","att_radius@@BOOLEAN"),
	ATT_VPN_ENDPOINT ("ATT_VPN_ENDPOINT","INTERNET_VPN_ENDPOINT@@STRING"),
	BACKHAUL_TYPES ("BACKHAUL TYPES","backhaul_types@@STRING"),
	BAN_ID ("BAN ID","ban_id@@STRING"),
	CCIP_RADIUS ("CCIP_RADIUS","Ccip_Radius@@BOOLEAN"),
	CCS_MX ("CCS_MX","Ccs_Mx@@BOOLEAN"),
	CCSPM ("CCSPM","ccspm@@STRING"),
	CCS_ROUTER_BASE_RD ("CCS ROUTER BASE RD","ccs_router_base_rd@@NUMBER"),
	CIR_SPEED ("CIR SPEED","cir_speed@@STRING"),
	CRYPTO_VLAN_ID ("CRYPTO VLAN ID","crypto_vlan_id@@STRING"),
	DATA_CENTERS ("DATA CENTERS","data_centers@@STRING"),
	DATE_APN_IN_PRODUCTION ("DATE APN IN PRODUCTION","date_apn_in_production@@DATE"),
	DATE_BILLING_COMPLETE ("DATE BILLING COMPLETE","date_billing_complete@@DATE"),
	DATE_BILLING_CREATION ("DATE BILLING CREATION","date_billing_creation@@DATE"),
	DATE_CCSPM_UPDATE_COMPLETE ("DATE CCSPM UPDATE COMPLETE","date_ccspm_update_complete@@DATE"),
	DATE_DASHBOARD_COMPLETE ("DATE DASHBOARD COMPLETE","date_dashboard_complete@@DATE"),
	DATE_HLR_HSS_COMPLETE ("DATE HLR HSS COMPLETE","date_hlr_hss_complete@@DATE"),
	DATE_IN_PRODUCTION ("DATE IN PRODUCTION","date_in_production@@DATE"),
	DATE_ITOPS_COMPLETE ("DATE ITOPS COMPLETE","date_itops_complete@@DATE"),
	DATE_IWOS_COMPLETE ("DATE IWOS COMPLETE","date_iwos_complete@@DATE"),
	DATE_NI_IWOS_CREATION ("DATE NI IWOS CREATION","date_ni_iwos_creation@@DATE"),
	DATE_NI_ORDER_UPDATE_COMPLETE ("DATE NI ORDER UPDATE COMPLETE","date_ni_order_update_complete@@DATE"),
	DATE_OA_APPROVED   ("DATE OA APPROVED  ","date_oa_approved@@DATE"),
	DATE_OM_APPROVED ("DATE OM APPROVED","date_om_approved@@DATE"),
	DATE_OSD_APPROVED ("DATE OSD APPROVED","date_osd_approved@@DATE"),
	DATE_SUBMITTED ("DATE SUBMITTED","date_submitted@@DATE"),
	DEDICATED_APN ("DEDICATED APN","dedicated_apn@@BOOLEAN"),
	DSCP_PRESERVATION ("DSCP PRESERVATION","dscp_preservation@@BOOLEAN"),
	ENT_TARGET_IP_RANGE ("ENT TARGET IP RANGE","ent_target_ip_range@@IPRANGE"),
	ENT_TARGET_IP_RANGE_ROUTE ("ENT TARGET IP RANGE ROUTE","ent_target_ip_range_route@@IPRANGE"),
	EOD ("EOD","eod@@BOOLEAN"),
	EOD_BLU ("EOD BLU","eod_blu@@STRING"),
	EXPEDITE ("EXPEDITE","expedite@@BOOLEAN"),
	EXPRESS ("EXPRESS","express@@BOOLEAN"),
	FAN_ID ("FAN ID","fan_id@@STRING"),
	FEE_WAIVER_ACCOUNT ("FEE WAIVER ACCOUNT","fee_waiver_account@@BOOLEAN"),
	FEE_WAIVER_APPROVED_MRC ("FEE WAIVER APPROVED $3 MRC","fee_waiver_approved_mrc@@BOOLEAN"),
	FEE_WAIVER_ORDER ("FEE WAIVER ORDER","fee_waiver_order@@BOOLEAN"),
	FIRST_NET ("FIRST NET","first_net@@BOOLEAN"),
	FIRSTNET_EPC ("FIRSTNET_EPC","firstnet_epc@@BOOLEAN"),
	GEO ("GEO","geo@@BOOLEAN"),
	GEO_OPTIMIZATION ("GEO OPTIMIZATION","geo_optimization@@BOOLEAN"),
	INT_TARGET_IP_RANGE ("INTERNET TARGET IP RANGE","int_target_ip_range@@IPRANGE"),
	INTERFACE_TUNNEL_NUM ("INTERFACE TUNNEL NUM","interface_tunnel_num@@NUMBER"),
	IP_ADDRESS_SOURCE ("IP ADDRESS SOURCE","ip_address_source@@STRING"),
	IPPT_CUST_RADIUS ("IPPT CUST RADIUS","ippt_cust_radius@@STRING"),
	ITOPS ("ITOPS","itops@@STRING"),
	LTE_SWEEP ("LTE SWEEP","lte_sweep@@STRING"),
	MANAGED_AVPN ("MANAGED AVPN","managed_avpn@@BOOLEAN"),
	MARKET_SEGMENT ("MARKET SEGMENT","market_segment@@STRING"),
	MASTER_ACCOUNT_NAME ("MASTER ACCOUNT NAME","master_account_name@@STRING"),
	MIGRATED_ORDER ("MIGRATED ORDER","migrated_order@@BOOLEAN"),
	MOBILE_POOL_ADDRESS ("MOBILE POOL ADDRESS","mobile_pool_address@@IPRANGE"),
	MOBILE_POOL_TYPE ("MOBILE POOL TYPE","mobile_pool_type@@STRING"),
	MOBILE_TERMINATED ("MOBILE TERMINATED","mobile_terminated@@BOOLEAN"),
	MOBILE_TO_MOBILE ("MOBILE TO MOBILE","mobile_to_mobile@@BOOLEAN"),
	MSP("MSP HTTP Optimization","msp@@BOOLEAN"),
	MSP_ENTITLEMENT_AND_MMS("MSP ENTITLEMENT AND MMS","msp_entitlment_and_mms@@BOOLEAN"),
	NI ("NI","ni@@STRING"),
	NUMBER_OF_CHANGE_REQUESTS("NUMBER OF CHANGE REQUESTS","number_of_change_requests@@NUMBER"),
	OA ("OA","oa@@STRING"),
	OCS ("OCS","ocs@@BOOLEAN"),
	OM ("OM","om@@STRING"),
	ON_HOLD ("ON HOLD","on_hold@@BOOLEAN"),
	ORDER_ID ("ORDER ID","order_id@@NUMBER"),
	ORDER_STATUS ("ORDER STATUS","order_status@@STRING"),
	ORDER_TYPE ("ORDER TYPE","order_type@@STRING"),
	OS ("OS","os@@STRING"),
	OSD ("OSD","osd@@STRING"),
	PAT_POOL_RANGE ("PAT POOL RANGE","pat_pool_range@@IPRANGE"),
	PCRF("PCRF","pcrf@@STRING"),
	PDP_ID ("PDP ID","pdp_id@@NUMBER"),
	PDP_NAME ("PDP NAME","pdp_name@@STRING"),
	PMIP ("PMIP","ipbr@@BOOLEAN"),
	REF_ORDER_ID ("REF ORDER ID","ref_order_id@@NUMBER"),
	RESTRICTIVE_ROUTING ("RESTRICTIVE ROUTING","restrictive_routing@@STRING"),
	ROUTING_PROTOCOL ("ROUTING PROTOCOL","routing_protocol@@STRING"),
	SPLIT_ACCESS_PAT("SPLIT ACCESS PAT","split_access_pat@@BOOLEAN"),
	SPLIT_TUNNEL_INTERNET_ACCESS ("SPLIT TUNNEL INTERNET ACCESS","split_tunnel_internet_access@@BOOLEAN"),
	SPLIT_TUNNEL_MT_ACCESS ("SPLIT TUNNEL MT ACCESS","split_tunnel_mt_access@@BOOLEAN"),
	STRICT_TCP ("STRICT TCP","strict_tcp@@STRING"),
	TOTAL_DAYS_ON_HOLD ("TOTAL DAYS ON HOLD","total_days_on_hold@@NUMBER"),
	TSP ("TSP","tsp@@BOOLEAN"),
	TTU_REQUIRED ("TTU REQUIRED","ttu_required@@BOOLEAN"),
	TTU_SCHEDULE_DATE ("TTU SCHEDULE DATE","ttu_schedule_date@@DATE"),
	TUNNEL_TYPE ("TUNNEL TYPE","tunnel_type@@STRING"),
	TURBO_APPLICATION_SUPPORT ("TURBO APPLICATION SUPPORT","turbo_app_support@@BOOLEAN"),
	VRF_NAME ("VRF NAME","vrf_name@@STRING"),
	VLAN_GI ("VLAN GI","vlan_gi@@STRING"),
	ORDER_CREATED_ON ("ORDER CREATED_ON","ORDER_CREATED_ON@@DATE");
	
	
	private final String displayName;
	private final String nameWithdataTypes;
	
	private SearchColumnForAllReport(String displayName, String nameWithdataTypes){
		this.displayName = displayName;
		this.nameWithdataTypes = nameWithdataTypes;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getNameWithdataTypes() {
		return nameWithdataTypes;
	}
	
	public static SearchColumnForAllReport getEnum(String value) {
		SearchColumnForAllReport getColumn = null;
		if (StringUtils.isNotBlank(value)) {
			for (SearchColumnForAllReport column : SearchColumnForAllReport.values()) {
				if (column.name().equalsIgnoreCase(value)) {
					getColumn = column;
					break;
				}
			}
		}
		return getColumn;
	}
	
	public static SearchColumnForAllReport getEnumWithdataType(String nameWithdataTypes) {
		SearchColumnForAllReport getColumn = null;
		if (StringUtils.isNotBlank(nameWithdataTypes)) {
			for (SearchColumnForAllReport column : SearchColumnForAllReport.values()) {
				if (column.getNameWithdataTypes().equalsIgnoreCase(nameWithdataTypes)) {
					getColumn = column;
					break;
				}
			}
		}
		return getColumn;
	}
	
	public static SearchColumnForAllReport getEnumWithDataTypeName(String value) {
		SearchColumnForAllReport getColumn = null;
		if (StringUtils.isNotBlank(value)) {
			for (SearchColumnForAllReport column : SearchColumnForAllReport.values()) {
				if (column.getNameWithdataTypes().equalsIgnoreCase(value)) {
					getColumn = column;
					break;
				}
			}
		}
		return getColumn;
	}
}
