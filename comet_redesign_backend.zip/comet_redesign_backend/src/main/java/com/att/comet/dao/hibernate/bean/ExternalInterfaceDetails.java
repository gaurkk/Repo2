package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_INTERFACE_DETAILS")
public class ExternalInterfaceDetails implements Serializable {

	private static final long serialVersionUID = 6153397157044835809L;

	private String extInterfaceId;
	private String requestType;
	private Orders orders;
	private Date createdAt;
	private Date updatedOn;
	private EventStatus eventStatus;
	private List<ExternalInterfaceEventStatuses> lstExtIntEventStatuses = new ArrayList<ExternalInterfaceEventStatuses>();
	private List<ExternalInterfaceEventLogs> lstExtIntEventLogs = new ArrayList<ExternalInterfaceEventLogs>();

	/**
	 * @return the extInterfaceId
	 */
	@Id
	@Column(name = "EXT_INTERFACE_ID", unique = true, nullable = false, length = 100)
	public String getExtInterfaceId() {
		return extInterfaceId;
	}

	/**
	 * @param extInterfaceId the extInterfaceId to set
	 */
	public void setExtInterfaceId(String extInterfaceId) {
		this.extInterfaceId = extInterfaceId;
	}

	/**
	 * @return the orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false)
	public Orders getOrders() {
		return orders;
	}

	/**
	 * @param orders the orders to set
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * @return the createdAt
	 */
	@Column(name = "CREATED_AT", nullable = false, length = 100)
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedOn
	 */
	@Column(name = "UPDATED_ON", nullable = false, length = 100)
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the eventStatus
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EVENT_STATUS_ID", nullable = false)
	public EventStatus getEventStatus() {
		return eventStatus;
	}

	/**
	 * @param eventStatus the eventStatus to set
	 */
	public void setEventStatus(EventStatus eventStatus) {
		this.eventStatus = eventStatus;
	}

	/**
	 * @return the lstExtIntEventStatuses
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "extInterfaceDetails")
	public List<ExternalInterfaceEventStatuses> getLstExtIntEventStatuses() {
		return lstExtIntEventStatuses;
	}

	/**
	 * @param lstExtIntEventStatuses the lstExtIntEventStatuses to set
	 */
	public void setLstExtIntEventStatuses(List<ExternalInterfaceEventStatuses> lstExtIntEventStatuses) {
		this.lstExtIntEventStatuses = lstExtIntEventStatuses;
	}

	/**
	 * @return the lstExtIntEventLogs
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "extInterfaceDetails")
	public List<ExternalInterfaceEventLogs> getLstExtIntEventLogs() {
		return lstExtIntEventLogs;
	}

	/**
	 * @param lstExtIntEventLogs the lstExtIntEventLogs to set
	 */
	public void setLstExtIntEventLogs(List<ExternalInterfaceEventLogs> lstExtIntEventLogs) {
		this.lstExtIntEventLogs = lstExtIntEventLogs;
	}
	@Column(name = "REQUEST_TYPE", length = 20)
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

}
