package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for PdpPackage. Mapped to PDP_PACKAGE table in the database.
 */
@Entity
@Table(name = "PDP_PACKAGE")
public class PdpPackage implements Serializable {

	private static final long serialVersionUID = 1032868673402299683L;

	private Long pdpPackageId;
	///private InternalProductAccount internalProductAccount;
	private SubAccount subAccount;
	private String pdpPackageName;
	private Long usageCount;
	private Long maxUsageCount;
	private String pdpPackageDescription;
	private Set<OrderAccount> orderAccounts = new HashSet<OrderAccount>(0);

	/**
	 * Getter method for pdpPackageId. PDP_PACKAGE_ID mapped to PDP_PACKAGE_ID
	 * in the database table. The sequence used to generate the pdpPackageId is
	 * SEQ_PDP_PACKAGE_ID.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "PDP_PACKAGE_ID", unique = true, nullable = false, precision = 12, scale = 0)
	@GenericGenerator(name = "SEQ_PDP_PACKAGE_ID", strategy = "sequence", parameters = { @Parameter(name = "sequence", value = "SEQ_PDP_PACKAGE_ID") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_PDP_PACKAGE_ID")
	public Long getPdpPackageId() {
		return this.pdpPackageId;
	}

	/**
	 * @param pdpPackageId
	 *            to pdpPackageId set.
	 */
	public void setPdpPackageId(Long pdpPackageId) {
		this.pdpPackageId = pdpPackageId;
	}

	/**
	 * Getter method for internalProductAccount.
	 * 
	 * @return InternalProductAccount
	 */
	/**@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CIPN")
	public InternalProductAccount getInternalProductAccount() {
		return this.internalProductAccount;
	}*/

	/**
	 * @param internalProductAccount
	 *            to internalProductAccount set.
	 */
	/**public void setInternalProductAccount(
			InternalProductAccount internalProductAccount) {
		this.internalProductAccount = internalProductAccount;
	}*/

	/**
	 * Getter method for subAccount.
	 * 
	 * @return SubAccount
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BCID")
	public SubAccount getSubAccount() {
		return this.subAccount;
	}

	/**
	 * @param subAccount
	 *            to subAccount set.
	 */
	public void setSubAccount(SubAccount subAccount) {
		this.subAccount = subAccount;
	}

	/**
	 * Getter method for pdpPackageName. PDP_PACKAGE_NAME mapped to
	 * PDP_PACKAGE_NAME in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PDP_PACKAGE_NAME", nullable = false, length = 100)
	public String getPdpPackageName() {
		return this.pdpPackageName;
	}

	/**
	 * @param pdpPackageName
	 *            to pdpPackageName set.
	 */
	public void setPdpPackageName(String pdpPackageName) {
		this.pdpPackageName = pdpPackageName;
	}

	/**
	 * Getter method for usageCount. USAGE_COUNT mapped to USAGE_COUNT in the
	 * database table.
	 * 
	 * @return Long
	 */
	@Column(name = "USAGE_COUNT", nullable = false, precision = 12, scale = 0)
	public Long getUsageCount() {
		return this.usageCount;
	}

	/**
	 * @param usageCount
	 *            to usageCount set.
	 */
	public void setUsageCount(Long usageCount) {
		this.usageCount = usageCount;
	}

	/**
	 * Getter method for maxUsageCount. MAX_USAGE_COUNT mapped to
	 * MAX_USAGE_COUNT in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "MAX_USAGE_COUNT", nullable = false, precision = 12, scale = 0)
	public Long getMaxUsageCount() {
		return this.maxUsageCount;
	}

	/**
	 * @param maxUsageCount
	 *            to maxUsageCount set.
	 */
	public void setMaxUsageCount(Long maxUsageCount) {
		this.maxUsageCount = maxUsageCount;
	}

	/**
	 * Getter method for orderAccounts.
	 * 
	 * @return Set<OrderAccount>
	 */
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "pdpPackage")
	public Set<OrderAccount> getOrderAccounts() {
		return this.orderAccounts;
	}

	/**
	 * @param orderAccounts
	 *            to orderAccounts set.
	 */
	public void setOrderAccounts(Set<OrderAccount> orderAccounts) {
		this.orderAccounts = orderAccounts;
	}

	/**
	 * Getter method for pdpPackageDescription. PDP_PACKAGE_DESCRIPTION mapped
	 * to PDP_PACKAGE_DESCRIPTION in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "PDP_PACKAGE_DESCRIPTION", length = 3500)
	public String getPdpPackageDescription() {
		return this.pdpPackageDescription;
	}

	/**
	 * @param pdpPackageDescription
	 *            to pdpPackageDescription set.
	 */
	public void setPdpPackageDescription(String pdpPackageDescription) {
		this.pdpPackageDescription = pdpPackageDescription;
	}
}