package com.att.comet.apn;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApnDomainProtocolConf {

	private String sectionName;
	private String socFeatureCode;
	private String domainName;
	private String staticAddressType;	
	private Character ccipRadius='N';
	private Character isExpress='N';	
	private Character ocs = 'Y';// OCS:	
	private Character mobileToMobileEnabled='N';
	private Character mobileTerminationEnabled='N';	
	private Character mobileOriginateEnabled='N';
	private Character splitAccessPAT='N';	
	private Character dscpPreservation = 'N';
	private Character splitTunnelIntEnabled='N';	
	private Character splitTunnelMTEnabled='N';
	private Character geoOptimization='N';

	private String pcrf;
	private String apnProtocol;

	private String ipAddressSource;
	private Long uniqueIPAddressSize;
	private Long totalMobilePoolSize;
	private String mobilePoolType;
	private String insideOusideStgPat;

	private List<EnterpriseTargetIpRangeBO> entTargetIpRanges;
	private List<MobilePoolAddressBO> mobilePoolAddresses;
	private List<InternetTargetIpRangeBO> intTargetIpRanges;
	private List<SplitTunnelIpRangeBO> splitTunnelIpRanges;
	private List<PatPoolAddressBO> patPoolAddresses;	
}
