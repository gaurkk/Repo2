package com.att.comet.criteria.util;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.comet.common.modal.BackhaulStatus;
import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.SearchCriteriaImpl;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.backhaul.BackhaulAccountClassRestriction;
import com.att.comet.restriction.backhaul.BackhaulApnNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulCIPNIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulCreatedByRestriction;
import com.att.comet.restriction.backhaul.BackhaulCreationDateRestriction;
import com.att.comet.restriction.backhaul.BackhaulCustOwnDomainNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulDataCenterIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulDisplayIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulFirstNetDataCenterRestriction;
import com.att.comet.restriction.backhaul.BackhaulIntProdInitAccNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulIsDummyDCRestriction;
import com.att.comet.restriction.backhaul.BackhaulMasterAccIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulMasterAccNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulMigrationOrderRestriction;
import com.att.comet.restriction.backhaul.BackhaulNoRestriction;
import com.att.comet.restriction.backhaul.BackhaulNotInOrderIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulOrderIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulOrderStatusRestriction;
import com.att.comet.restriction.backhaul.BackhaulOrderTypeRestriction;
import com.att.comet.restriction.backhaul.BackhaulPDPIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulPDPNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulStatusRestriction;
import com.att.comet.restriction.backhaul.BackhaulSubAccIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulSubAccNameRestriction;
import com.att.comet.restriction.backhaul.BackhaulSubAccTypeRestriction;
import com.att.comet.restriction.backhaul.BackhaulTunnelTypeRestriction;
import com.att.comet.restriction.backhaul.BackhaulTypeIdRestriction;
import com.att.comet.restriction.backhaul.BackhaulVPNNameRestriction;
import com.att.comet.charts.dao.ChartsDAOImpl;
import com.att.comet.charts.result.ResultBO;

public class BackhaulCriteriaHelper {
	@Autowired
	private static SearchCriteria criteria;

	@Autowired
	private List<CriteriaRenderer> listRenderers;

	private static final Logger logger = LoggerFactory.getLogger(ChartsDAOImpl.class);

	/**
	 * Get the object of Search Criteria
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria() throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl() : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria(OutputFormat format) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format) : criteria.clone());
	}

	/**
	 * Get the object of Search Criteria with specified output format and other
	 * details
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria(OutputFormat format, OtherDetails other) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format, other) : criteria.clone());
	}

	/**
	 * Get Initial data to result
	 * 
	 * @return Restriction
	 */
	public static Restriction initalData() {
		return new BackhaulNoRestriction();
	}

	/**
	 * Add Order Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction orderId(Long propertyValue) {
		return new BackhaulOrderIdRestriction(propertyValue);
	}

	/**
	 * Add Order Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction orderType(Long propertyValue) {
		return new BackhaulOrderTypeRestriction(propertyValue);
	}

	/**
	 * Add Order Status as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction orderStatus(Long propertyValue) {
		return new BackhaulOrderStatusRestriction(propertyValue);
	}

	/**
	 * Add Migration Order as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction migrationOrder(Character propertyValue) {
		return new BackhaulMigrationOrderRestriction(propertyValue);
	}

	/**
	 * Add Apn Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction apnName(String propertyValue) {
		return new BackhaulApnNameRestriction(propertyValue);
	}

	/**
	 * Add PDP Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction pdpId(Long propertyValue) {
		return new BackhaulPDPIdRestriction(propertyValue);
	}

	/**
	 * Add PDP Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction pdpName(String propertyValue) {
		return new BackhaulPDPNameRestriction(propertyValue);
	}

	/**
	 * Add Customer owned domain name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction custmerOwnDomainName(String propertyValue) {
		return new BackhaulCustOwnDomainNameRestriction(propertyValue);
	}

	/**
	 * Add Class of Account as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction classOfAccount(Long propertyValue) {
		return new BackhaulAccountClassRestriction(propertyValue);
	}

	/**
	 * Add Account Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction accountName(String propertyValue) {
		return new BackhaulSubAccNameRestriction(propertyValue);
	}

	/**
	 * Add Account Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction accountId(String propertyValue) {
		return new BackhaulSubAccIdRestriction(propertyValue);
	}

	/**
	 * Add Account Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction accountType(String propertyValue) {
		return new BackhaulSubAccTypeRestriction(propertyValue);
	}

	/**
	 * Add Master Account Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction masterAccountName(String propertyValue) {
		return new BackhaulMasterAccNameRestriction(propertyValue);
	}

	/**
	 * Add Master Account Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction masterAccountId(String propertyValue) {
		return new BackhaulMasterAccIdRestriction(propertyValue);
	}

	/**
	 * Add Internal initiation Account Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction internalInitAccountName(String propertyValue) {
		return new BackhaulIntProdInitAccNameRestriction(propertyValue);
	}

	/**
	 * Add CIPN id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction cipnId(String propertyValue) {
		return new BackhaulCIPNIdRestriction(propertyValue);
	}
	
	/**
	 * Add BCID as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction bcid(String propertyValue) {
		return new BackhaulSubAccIdRestriction(propertyValue);
	}

	/**
	 * Add product initiation Account Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction productInitAccountName(String propertyValue) {
		return new BackhaulIntProdInitAccNameRestriction(propertyValue);
	}

	/**
	 * Add Data Center Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction dataCenterName(Long propertyValue) {
		return new BackhaulDataCenterIdRestriction(propertyValue);
	}

	/**
	 * Add Non dummy Data Center Name as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction nonDummyDataCenterName(boolean propertyValue) {
		return new BackhaulIsDummyDCRestriction(propertyValue);
	}

	/**
	 * Add backhaul instance status as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction backhaulInstanceStatus(Set<BackhaulStatus> propertyValue) {
		return new BackhaulStatusRestriction(propertyValue);
	}

	/**
	 * Add Backhaul Instance Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction backhaulInstanceId(String propertyValue) {
		return new BackhaulDisplayIdRestriction(propertyValue);
	}

	/**
	 * Add Backhaul Instance Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction backhaulInstanceType(Set<Long> propertyValue) {
		return new BackhaulTypeIdRestriction(propertyValue);
	}

	/**
	 * Add Tunnel Type as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction tunnelType(String propertyValue) {
		return new BackhaulTunnelTypeRestriction(propertyValue);
	}

	/**
	 * Add VPN Name Id as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction vpnName(String propertyValue) {
		return new BackhaulVPNNameRestriction(propertyValue);
	}

	/**
	 * Add Backhaul Created by as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction backhaulCreatedBy(String propertyValue) {
		return new BackhaulCreatedByRestriction(propertyValue);
	}

	/**
	 * Add Backhaul creation date as a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction backhaulCreationDate(String fromDate, String toDate) {
		return new BackhaulCreationDateRestriction(fromDate, toDate);
	}

	/**
	 * Add Not in Order Idas a restriction to result
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction notInOrderId(Long propertyValue) {
		return new BackhaulNotInOrderIdRestriction(propertyValue);
	}

	/**
	 * Add is FirstNet Data Center or not
	 * 
	 * @param propertyValue
	 * @return Restriction
	 */
	public static Restriction getFirstNetDataCenterOrNot(boolean propertyValue) {
		return new BackhaulFirstNetDataCenterRestriction(propertyValue);
	}

	/**
	 * Fetch Result with given Criteria
	 * 
	 * @param criteria
	 * @return ResultBO
	 * @throws Exception
	 */
	public ResultBO getOutput(SearchCriteria criteria) throws Exception {
		logger.info("Starting method getOutput : ", this);

		if (criteria.getRestrictions().size() == 0) {
			throw new Exception("No Criteria Found");
		}
		CriteriaRenderer renderer = null;
		switch (criteria.getFormat()) {
		case GRID:
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		case PIE_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof PieChartCriteriaRenderer).findFirst().get();
			break;
		case BAR_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof BarChartCriteriaRenderer).findFirst().get();
			break;
		case STACKED_COLUMN_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof StackedColumnChartCriteriaRenderer)
					.findFirst().get();
			break;
		case COLUMN_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof ColumnChartCriteriaRenderer).findFirst()
					.get();
			break;
		case LINE_CHART:
			renderer = listRenderers.stream().filter(obj -> obj instanceof LineChartCriteriaRenderer).findFirst().get();
			break;
		default:
			renderer = listRenderers.stream().filter(obj -> obj instanceof GridCriteriaRenderer).findFirst().get();
			break;
		}
		ResultBO result = renderer.getOutput(criteria);
		logger.info("Exiting method getOutput : ", this);
		return result;
	}
}
