package com.att.comet.account.modal;

import java.io.Serializable;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = true)
public class MasterAccountBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = -7572317051698120813L;
	private Long accountClass;
	private String masterAccountName;
	private String ubcid;
	private SubAccountBO subAccount;
	private String errorMessage;
}