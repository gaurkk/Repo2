package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderStatusBO extends CometGenericBO{
	private static final long serialVersionUID = -1042799976117220267L;
	private Long orderstatusId;
	private String orderStatusName;
	private String orderStatusDescription;

}
