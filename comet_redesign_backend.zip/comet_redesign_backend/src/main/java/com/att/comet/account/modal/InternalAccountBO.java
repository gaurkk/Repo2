package com.att.comet.account.modal;

import java.io.Serializable;
import java.util.Date;

import com.att.comet.common.modal.CometGenericBO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = true)
public class InternalAccountBO extends CometGenericBO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3844956328660588095L;
	private String cipnName;
	private Long accountClass;
	private String internalInitiativeName;
	private String federalTaxId;
	private Character tsp;
	private Character feeWaiverApproved;
	private String waiverNotes;
	private byte[] waiverAttachment;
	private String waiverAttachmentFilename;
	private String createdBy;
	private Date createdOn;
	private String updatedBy;
	private Date updatedOn;
}
