package com.att.comet.common.modal;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class CometUserDetails implements UserDetails  {

	private static final long serialVersionUID = -8753160697949986201L;
	
	private String attUid;
	private String name;
    private Collection<? extends GrantedAuthority> authorities;
    
	public String getAttUid() {
		return attUid;
	}

	public void setAttUid(String attUid) {
		this.attUid = attUid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.authorities;
	}

	@Override
	public String getPassword() {
		return null;
	}

	@Override
	public String getUsername() {
		return this.attUid;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}
