package com.att.comet.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.MasterAccount;

@Repository
public interface MasterAccountRepository extends JpaRepository<MasterAccount,String> {
	@Query("select distinct masterAccountName from MasterAccount where masterAccountName LIKE %:criteria%")
	List<String> getMasterAccountList(String criteria);
}
