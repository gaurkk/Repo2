package com.att.comet.manage.modal;

public class DapnCSVLineBO extends LineBO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 77414273377740403L;
	private String actionField;
	private String dapnId;
	private String apnType;
	private String apnSize;
	private String apnName;
	private String pdpName;
	private String udPDPId;
	private String mobileIP;
	private String dataCenter;
	private String pDNSAddress;
	private String sDNSAddress;
	private String dnsNotes;
	private String ampInfo;
	private String createdOn;
	private String createdBy;
	private String batchId;
	private String pcrf;
	private int recordNumber;
	
	public String getActionField() {
		return actionField;
	}
	public void setActionField(String actionField) {
		this.actionField = actionField;
	}
	public String getDapnId() {
		return dapnId;
	}
	public void setDapnId(String dapnId) {
		this.dapnId = dapnId;
	}
	public String getApnType() {
		return apnType;
	}
	public void setApnType(String apnType) {
		this.apnType = apnType;
	}
	public String getApnSize() {
		return apnSize;
	}
	public void setApnSize(String apnSize) {
		this.apnSize = apnSize;
	}
	public String getApnName() {
		return apnName;
	}
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}
	public String getPdpName() {
		return pdpName;
	}
	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}
	public String getUdPDPId() {
		return udPDPId;
	}
	public void setUdPDPId(String udPDPId) {
		this.udPDPId = udPDPId;
	}
	public String getMobileIP() {
		return mobileIP;
	}
	public void setMobileIP(String mobileIP) {
		this.mobileIP = mobileIP;
	}
	public String getDataCenter() {
		return dataCenter;
	}
	public void setDataCenter(String dataCenter) {
		this.dataCenter = dataCenter;
	}
	public String getpDNSAddress() {
		return pDNSAddress;
	}
	public void setpDNSAddress(String pDNSAddress) {
		this.pDNSAddress = pDNSAddress;
	}
	public String getsDNSAddress() {
		return sDNSAddress;
	}
	public void setsDNSAddress(String sDNSAddress) {
		this.sDNSAddress = sDNSAddress;
	}
	public String getDnsNotes() {
		return dnsNotes;
	}
	public void setDnsNotes(String dnsNotes) {
		this.dnsNotes = dnsNotes;
	}
	public String getAmpInfo() {
		return ampInfo;
	}
	public void setAmpInfo(String ampInfo) {
		this.ampInfo = ampInfo;
	}
	
	
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getPcrf() {
		return pcrf;
	}
	public void setPcrf(String pcrf) {
		this.pcrf = pcrf;
	}

	public int getRecordNumber() {
		return recordNumber;
	}
	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}
	@Override
	public String toString() {
		return "DapnUploadBO [actionField=" + actionField + ", ampInfo=" + ampInfo + ", apnName=" + apnName + ", apnSize=" + apnSize + ", apnType="
				+ apnType + ", batchId=" + batchId + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", dapnId=" + dapnId + ", dataCenter="
				+ dataCenter + ", dnsNotes=" + dnsNotes + ", mobileIP=" + mobileIP + ", pDNSAddress=" + pDNSAddress + ", pcrf=" + pcrf + ", pdpName="
				+ pdpName + ", sDNSAddress=" + sDNSAddress + ", udPDPId=" + udPDPId + "]";
	}
}
