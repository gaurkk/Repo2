package com.att.comet.apn.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.apn.ApnBO;
import com.att.comet.apn.PdpIdInfoBO;
import com.att.comet.charts.modal.UserInfoBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.order.modal.ImsiMsisdnBO;
import com.att.comet.order.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderApnController {
	private static final Logger logger = LoggerFactory.getLogger(OrderApnController.class);
	@Autowired
	OrderService orderService;
	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;
	
	@Autowired
	UserHelper userHelper;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getApnInfo/{orderId}/{validationRequired}/{showAllTabValidation}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find APN Details for unique Order Id   ", notes = "Return APN details for specific order id")
	public CometResponse<ApnBO> getApnDetail(@PathVariable Long orderId, @PathVariable boolean validationRequired, @PathVariable boolean showAllTabValidation, Authentication authentication) {
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Starting method getApnDetail : ", this);
		CometResponse<ApnBO> cometResponse = new CometResponse<ApnBO>();
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		ApnBO apnBo = null;
		try {
			apnBo = orderService.getApnDetails(orderId, validationRequired, showAllTabValidation, userInfoBO);
			if (null != apnBo) {
				cometResponse.setMethodReturnValue(apnBo);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException | CometServiceException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Exiting method getApnDetail : ", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/order/getInsideOutsideStgPatInterface/{orderId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get inside outside stg pat interface values", notes = "Get Data Center inside outside stg pat interface values")
	public CometResponse<List<StaticDataBO>> getInOutPatSTGInterface(@PathVariable Long orderId) throws CometDataException { 
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Starting method getInOutPatSTGInterface : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> listData = new ArrayList<StaticDataBO>();
		try {
			List<String> populateInOutPatSTGList = orderService.getInOutPatSTGInterface(orderId);

			if(null != populateInOutPatSTGList  && populateInOutPatSTGList.size() > 0) {
				List<KeyValueBO> keyValueList = populateInOutPatSTGList.stream().map(bo -> new KeyValueBO(bo, bo)).collect(Collectors.toList());
				listData.add(new StaticDataBO("INSIDE_OUTSIDE_STG_PAT_INTERFACE_LIST", keyValueList)); 
			}
			cometResponse.setMethodReturnValue(listData);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Exiting method getInOutPatSTGInterface : ", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/order/getImsiMsisdnList/{orderId}/{dataCenterId}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get IMSI MSISDN values", notes = "Get Imsi Msisdn values")
	public CometResponse<List<StaticDataBO>> getImsiMsisdnList(@PathVariable Long orderId ,@PathVariable Long dataCenterId) throws CometDataException { 
		logger.info("[DataCenterId : "+(dataCenterId == null ? "": dataCenterId)+"] Starting method getImsiMsisdnList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> listData = new ArrayList<StaticDataBO>();
		try {
			List<ImsiMsisdnBO> populateIMSIMSISDNList = orderService.getImsiMsisdnList(orderId, dataCenterId);
			logger.info("size of IMSIMSISDN List >>>>>>>>>>>>>>>>>>>"+populateIMSIMSISDNList.size());
			if(null != populateIMSIMSISDNList  && populateIMSIMSISDNList.size() > 0) {
				List<KeyValueBO> keyValueList = populateIMSIMSISDNList.stream().map(bo -> new KeyValueBO(bo.getImsiMsisdn(), bo.getImsiMsisdn())).collect(Collectors.toList());
				listData.add(new StaticDataBO("Get IMSIMSISDN List", keyValueList)); 
			}
			cometResponse.setMethodReturnValue(listData);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[DataCenterId : "+(dataCenterId == null ? "": dataCenterId)+"] Exiting method getImsiMsisdnList : ", this);
		return cometResponse;
	}
	
	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_NETWORK_IMPLEMENTATION", "ROLE_CCS_PM", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/apn", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Save APN Details for unique Order Id   ", notes = "Save complete APN details for specific order id")
	public CometResponse<ApnBO> saveApn(@RequestBody ApnBO apnBO ,Authentication authentication) throws CometServiceException{
		logger.info("Starting method saveApn : ", this);
		CometResponse<ApnBO> cometResponse = new CometResponse<ApnBO>();
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		apnBO.setUpdatedBy(userInfoBO.getAttuid());
		apnBO.setRoleId(userInfoBO.getRoleId());
		try {
			ApnBO apn = orderService.saveApn(apnBO);
			if(null!=apn && null==apn.getErrorCode()) {
				cometResponse.setMethodReturnValue(apn);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}if(null!=apn && null!=apn.getErrorCode()) { 
				cometResponse.setMethodReturnValue(apn);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}else if(apn==null) {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		} 
		logger.info("Exiting method saveApn : ", this);
		return cometResponse;	
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@PutMapping(value = "/order/pdpIdInfo", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Populates the pdpId info", notes = "Populates the pdpId info details")
	public CometResponse<PdpIdInfoBO> actionPdpIdInfo(
											@RequestParam(value = "orderId", required = true) Long orderId,
											@RequestParam(value = "pdpId", required = false) Long pdpId,
											@RequestParam(value = "mode", required = true) String mode,
											@RequestParam(value = "isMigratedOrder", required = false) String isMigratedOrder,
											@RequestParam(value = "isOverridePdpName", required = false) String isOverridePdpName,
											Authentication authentication) throws CometDataException { 
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Starting method actionPdpIdInfo : ", this);
		CometResponse<PdpIdInfoBO> cometResponse = new CometResponse<PdpIdInfoBO>();
		PdpIdInfoBO pdpIdInfoBO = null;
		try {
			pdpIdInfoBO = orderService.doActionPdpIdInfo(orderId, pdpId, mode, isMigratedOrder, isOverridePdpName);
			
			cometResponse.setMethodReturnValue(pdpIdInfoBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (CometDataException e) {
			cometResponse.setMethodReturnValue(pdpIdInfoBO);
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[OrderId : "+(orderId == null ? "": orderId)+"] Exiting method actionPdpIdInfo : ", this);
		return cometResponse;
	}
	
}
