package com.att.comet.dao.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderWorkStepHistory. Mapped to
 * BPM_ORDER_WORK_STEP_HISTORY table in the database.
 */
@Entity
@Table(name = "BPM_ORDER_WORK_STEP_HISTORY")
public class BpmOrderWorkStepHistory implements java.io.Serializable {

	private static final long serialVersionUID = 4015009756287335882L;

	private BpmOrderWorkStepHistoryId id;

	/**
	 * No-argument constructor of the class.
	 */
	public BpmOrderWorkStepHistory() {
	}

	/**
	 * Single argument constructor of the class.
	 * 
	 * @param id
	 */
	public BpmOrderWorkStepHistory(BpmOrderWorkStepHistoryId id) {
		this.id = id;
	}

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderWorkStepHistoryId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "workStepId", column = @Column(name = "WORK_STEP_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "bpmStatusId", column = @Column(name = "BPM_STATUS_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "workStepExecutedOn", column = @Column(name = "WORK_STEP_EXECUTED_ON", nullable = false)),
			@AttributeOverride(name = "userDecision", column = @Column(name = "USER_DECISION", length = 100)),
			@AttributeOverride(name = "userDecisionOn", column = @Column(name = "USER_DECISION_ON")),
			@AttributeOverride(name = "comments", column = @Column(name = "COMMENTS", length = 3500)),
			@AttributeOverride(name = "createdOn", column = @Column(name = "CREATED_ON", nullable = false)),
			@AttributeOverride(name = "updatedOn", column = @Column(name = "UPDATED_ON", nullable = false)) })
	public BpmOrderWorkStepHistoryId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderWorkStepHistoryId id) {
		this.id = id;
	}

}
