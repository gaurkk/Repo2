package com.att.comet.manage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CityBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.CountryBO;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StateBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.manage.service.ManageService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class ManageLocationController {

	Logger logger = LoggerFactory.getLogger(ManageLocationController.class);

	@Autowired
	ManageService manageService;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/location/getCountry", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Country Name", notes = "Return all the Country Name")
	public CometResponse<List<StaticDataBO>> getCountryList() throws CometDataException, CometServiceException {
		logger.info("Starting method getCountryList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> countryClass = new ArrayList<StaticDataBO>();
		List<CountryBO> countryNameList = manageService.getCountryList();
		if (!CollectionUtils.isEmpty(countryNameList)) {
			List<KeyValueBO> keyValueList = countryNameList.stream()
					.map(bo -> new KeyValueBO(bo.getCountryId().toString(),bo.getCountryName()))
					.collect(Collectors.toList());
			countryClass.add(new StaticDataBO(CometCommonConstant.COUNTRY, keyValueList));
		}
		cometResponse.setMethodReturnValue(countryClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getCountryList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/location/{countryId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find State Name", notes = "Return all the State Name")
	public CometResponse<List<StaticDataBO>> getStateList(@PathVariable Long countryId) throws CometDataException, CometServiceException {
		logger.info("Starting method getStateList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> stateClass = new ArrayList<StaticDataBO>();
		List<StateBO> stateNameList = manageService.getStateList(countryId);
		if (!CollectionUtils.isEmpty(stateNameList)) {
			List<KeyValueBO> keyValueList = stateNameList.stream()
					.map(bo -> new KeyValueBO(bo.getStateId().toString(), bo.getStateName()))
					.collect(Collectors.toList());
			stateClass.add(new StaticDataBO(CometCommonConstant.STATE, keyValueList));
		}
		cometResponse.setMethodReturnValue(stateClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getStateList : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/location/{stateId}/{criteria}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find City Name", notes = "Return all the City Name")
	public CometResponse<List<StaticDataBO>> getCityList(@PathVariable Long stateId, @PathVariable String criteria) throws CometDataException, CometServiceException {
		logger.info("Starting method getCityList : ", this);
		CometResponse<List<StaticDataBO>> cometResponse = new CometResponse<List<StaticDataBO>>();
		List<StaticDataBO> cityClass = new ArrayList<StaticDataBO>();
		List<CityBO> cityNameList = manageService.getCityList(stateId, criteria);
		if (!CollectionUtils.isEmpty(cityNameList)) {
			List<KeyValueBO> keyValueList = cityNameList.stream()
					.map(bo -> new KeyValueBO(bo.getCityId().toString(), bo.getCityName()))
					.collect(Collectors.toList());
			cityClass.add(new StaticDataBO(CometCommonConstant.CITY, keyValueList));
		}
		cometResponse.setMethodReturnValue(cityClass);
		cometResponse.setStatusCode(Status.SUCCESS.getCode());
		cometResponse.setStatus(Status.SUCCESS);
		logger.info("Exiting method getCityList : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PostMapping(value = "manage/location/addCountry", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add Country Name ", notes = "Return Country Name")
	public CometResponse<String> saveCountryName(@RequestBody CountryBO countryBO)
			throws CometDataException, CometServiceException {
		logger.info("[PdpPackageId : " + (countryBO == null ? "" : countryBO.getCountryName()) + "] "
				+ " Starting method saveCountryName", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String countryBO1 = null;
		try {
			countryBO1 = manageService.saveCountryName(countryBO);
			if (null != countryBO1) {
				cometResponse.setMethodReturnValue(countryBO1);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[PdpPackageId : " + (countryBO == null ? "" : countryBO.getCountryName()) + "] "
				+ " Exiting method saveCountryName", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "manage/location/updateCountry", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update Country Name", notes = "Return Country Name")
	public CometResponse<String> updateCountryName(@RequestBody CountryBO countryBO)
			throws CometDataException, IOException {
		logger.info("Starting method updateCountryName : ", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String countryBO1 = null;
		try {
			if (countryBO != null) {
				countryBO1 = manageService.updateCountry(countryBO);
				if (null != countryBO1) {
					cometResponse.setMethodReturnValue(countryBO1);
					cometResponse.setStatusCode(Status.SUCCESS.getCode());
					cometResponse.setStatus(Status.SUCCESS);
				} else {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to country name");
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method updateCountryName : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "/manage/location/deleteCountry/{countryId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Country Name", notes = "Delete Country Name")
	public CometResponse<String> deleteCountryName(@PathVariable Long countryId)
			throws CometDataException,CometServiceException {
		logger.info("[CountryId : " + (countryId == null ? "" : countryId) + "] " + "Starting method deleteCountryName : ",
				this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String isCountryNameDeleted =null;
		try {
			isCountryNameDeleted = manageService.deleteCountryName(countryId);
			if (null!=isCountryNameDeleted) {
				cometResponse.setMethodReturnValue(isCountryNameDeleted);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setMethodReturnValue(Status.ACCOUNT_DELETION_ERROR.getName());
				cometResponse.setStatusCode(Status.ACCOUNT_DELETION_ERROR.getCode());
				cometResponse.setStatus(Status.ACCOUNT_DELETION_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AccountID : " + (countryId == null ? "" : countryId) + "] " + "Exiting method deleteCountryName : ",
				this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "managelocation/getCountry", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Country Name", notes = "Return all the Country Name")
	public CometResponse<List<CountryBO>> getCountry() throws CometDataException, CometServiceException {
		logger.info("Starting method getCountry : ", this);
		CometResponse<List<CountryBO>> cometResponse = new CometResponse<List<CountryBO>>();
		try {
			List<CountryBO> countryNameList = manageService.getCountryList();
			if (!CollectionUtils.isEmpty(countryNameList)) {
				cometResponse.setMethodReturnValue(countryNameList);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}
		}catch(Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method getCountry : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "managelocation/getState", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find State Name", notes = "Return all the State Name")
	public CometResponse<List<StateBO>> getState() throws CometDataException, CometServiceException {
		logger.info("Starting method getState : ", this);
		CometResponse<List<StateBO>> cometResponseState = new CometResponse<List<StateBO>>();
		try {
			List<StateBO> countryNameList = manageService.getState();
			if (!CollectionUtils.isEmpty(countryNameList)) {
				cometResponseState.setMethodReturnValue(countryNameList);
				cometResponseState.setStatusCode(Status.SUCCESS.getCode());
				cometResponseState.setStatus(Status.SUCCESS);
			}
		}catch(Exception e) {
			cometResponseState.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponseState.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method getState : ", this);
		return cometResponseState;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "/manage/location/deleteState/{stateId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete State Name", notes = "Delete State Name")
	public CometResponse<String> deleteStateName(@PathVariable Long stateId)
			throws CometDataException,CometServiceException {
		logger.info("[StateId : " + (stateId == null ? "" : stateId) + "] " + "Starting method deleteStateName : ",
				this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String isStateNameDeleted = null;
		try {
			isStateNameDeleted = manageService.deleteStateName(stateId);
			if (null!=isStateNameDeleted) {
				cometResponse.setMethodReturnValue(isStateNameDeleted);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setMethodReturnValue(Status.ACCOUNT_DELETION_ERROR.getName());
				cometResponse.setStatusCode(Status.ACCOUNT_DELETION_ERROR.getCode());
				cometResponse.setStatus(Status.ACCOUNT_DELETION_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AccountID : " + (stateId == null ? "" : stateId) + "] " + "Exiting method deleteStateName : ",
				this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "/manage/location/deleteCity/{cityId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete City Name", notes = "Delete City Name")
	public CometResponse<String> deleteCityName(@PathVariable Long cityId)
			throws CometDataException,CometServiceException {
		logger.info("[CityId : " + (cityId == null ? "" : cityId) + "] " + "Starting method deleteCityName : ",
				this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String isCityNameDeleted = null;
		try {
			isCityNameDeleted = manageService.deleteCityName(cityId);
			if (null!=isCityNameDeleted) {
				cometResponse.setMethodReturnValue(isCityNameDeleted);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setMethodReturnValue(Status.ACCOUNT_DELETION_ERROR.getName());
				cometResponse.setStatusCode(Status.ACCOUNT_DELETION_ERROR.getCode());
				cometResponse.setStatus(Status.ACCOUNT_DELETION_ERROR);
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[AccountID : " + (cityId == null ? "" : cityId) + "] " + "Exiting method deleteCityName : ",
				this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/manage/location/getCity/{countryId}/{stateId}", produces = { 
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1") 
	@ApiOperation(value = "Find State Name", notes = "Return all the State Name") 
	public CometResponse<List<CityBO>> getCity(@PathVariable Long countryId, @PathVariable Long stateId) throws CometDataException, CometServiceException { 
		logger.info("Starting method getCity : ", this); 
		CometResponse<List<CityBO>> cometResponseCity = new CometResponse<List<CityBO>>();
		try { 
			List<CityBO> cityNameList = null; 
			cityNameList = manageService.getCity(countryId,stateId); 

			if (!CollectionUtils.isEmpty(cityNameList)) { 
				cometResponseCity.setMethodReturnValue(cityNameList); 
				cometResponseCity.setStatusCode(Status.SUCCESS.getCode()); 
				cometResponseCity.setStatus(Status.SUCCESS); 
			} 
		}catch(Exception e) { 
			cometResponseCity.setStatusCode(Status.BUSINESS_ERROR.getCode()); 
			cometResponseCity.setStatus(Status.BUSINESS_ERROR); 
			e.printStackTrace(); 
		} 
		logger.info("Exiting method getCity : ", this); 
		return cometResponseCity; 
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PostMapping(value = "managelocation/addState", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add State Name ", notes = "Return State Name")
	public CometResponse<String> saveStateName(@RequestBody StateBO stateBO)
			throws CometDataException, CometServiceException {
		logger.info("[StateBO : " + (stateBO == null ? "" : stateBO.getCountryName()) + "] "
				+ " Starting method saveStateName", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String stateNameBO = null;
		try {
			stateNameBO = manageService.saveStateName(stateBO);
			if (null != stateNameBO) {
				cometResponse.setMethodReturnValue(stateNameBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[StateBO : " + (stateBO == null ? "" : stateBO.getCountryName()) + "] "
				+ " Exiting method saveStateName", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "managelocation/updateState", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update State Name", notes = "Return State Name")
	public CometResponse<String> updateStateName(@RequestBody StateBO stateBO)
			throws CometDataException, IOException {
		logger.info("Starting method updateStateName : ", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String stateNameBO = null;
		try {
			if (stateBO != null) {
				stateNameBO = manageService.updateState(stateBO);
				if (null != stateNameBO) {
					cometResponse.setMethodReturnValue(stateNameBO);
					cometResponse.setStatusCode(Status.SUCCESS.getCode());
					cometResponse.setStatus(Status.SUCCESS);
				} else {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to State name");
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method updateStateName : ", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PostMapping(value = "manage/location/addCity", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add City Name ", notes = "Return City Name")
	public CometResponse<String> saveCityName(@RequestBody CityBO cityBO)
			throws CometDataException, CometServiceException {
		logger.info("[CityBO : " + (cityBO == null ? "" : cityBO.getCityName()) + "] "
				+ " Starting method saveCityName", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String cityNameBO = null;
		try {
			cityNameBO = manageService.saveCityName(cityBO);
			if (null != cityNameBO) {
				cometResponse.setMethodReturnValue(cityNameBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("[CityBO : " + (cityBO == null ? "" : cityBO.getCountryName()) + "] "
				+ " Exiting method saveCityName", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "manage/location/updateCity", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update City Name", notes = "Return City Name")
	public CometResponse<String> updateCityName(@RequestBody CityBO cityBO)
			throws CometDataException, IOException {
		logger.info("Starting method updateCityName : ", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String cityNameBO = null;
		try {
			if (cityBO != null) {
				cityNameBO = manageService.updateCity(cityBO);
				if (null != cityNameBO) {
					cometResponse.setMethodReturnValue(cityNameBO);
					cometResponse.setStatusCode(Status.SUCCESS.getCode());
					cometResponse.setStatus(Status.SUCCESS);
				} else {
					cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
					cometResponse.setStatus(Status.BUSINESS_ERROR);
				}
			} else {
				logger.error("No Data Found", this);
				throw new CometDataException("No Data Found to City name");
			}
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		logger.info("Exiting method updateCityName : ", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/state/{stateId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get State Data", notes = "Get State Info Details")
	public CometResponse<StateBO> getStateInfoById(@PathVariable String stateId) throws CometDataException, CometServiceException {
		logger.info("[StateID : " + (stateId == null ? "" : stateId) + "] " + "Starting method getStateInfoById : ",
				this);
		CometResponse<StateBO> cometResponse = new CometResponse<StateBO>();
		
		try {
			long state  = Long.parseLong(stateId);
			StateBO stateBO = manageService.getStateInfoById(state);
			if(stateBO!=null) {
				cometResponse.setMethodReturnValue(stateBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		}catch(Exception e ){
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("[StateID : " + (stateId == null ? "" : stateId) + "] " + "Exiting method getStateInfoById : ",
				this);
		return cometResponse;
	}
	
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/city/{cityId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get City Data", notes = "Get City Info Details")
	public CometResponse<CityBO> getCityInfoById(@PathVariable String cityId) throws CometDataException, CometServiceException {
		logger.info("[CityID : " + (cityId == null ? "" : cityId) + "] " + "Starting method getCityInfoById : ",
				this);
		CometResponse<CityBO> cometResponse = new CometResponse<CityBO>();
		
		try {
			long city  = Long.parseLong(cityId);
			CityBO cityBO = manageService.getCityInfoById(city);
			if(cityBO!=null) {
				cometResponse.setMethodReturnValue(cityBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			}else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		}catch(Exception e ){
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("[CityID : " + (cityId == null ? "" : cityId) + "] " + "Exiting method getCityInfoById : ",
				this);
		return cometResponse;
	}
}
