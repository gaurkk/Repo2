package com.att.comet.misc;

import java.io.Serializable;
import java.util.Date;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class AmpRequestBO extends CometGenericBO implements Serializable {
	private static final long serialVersionUID = -8266145998840305666L;
	private String requestId;
	private String activityDetails;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date activitySubDateTime;
	private String comments;
}