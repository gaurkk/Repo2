package com.att.comet.eiis.service;


import java.util.List;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.eiis.modal.AmpResponseBO;

public interface EiisComService extends GenericCometService{
	
	public AmpResponseBO create(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	 
	public AmpResponseBO cancel(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO status(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO skip(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO login(String userName, String password, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO details(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public List<AmpResponseBO> createAccaRequest(Long orderId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO accaStatus(Long orderId, String reqId, String attuid, String token) throws CometDataException,CometServiceException;
	
	public AmpResponseBO accaDetails(Long orderId, String reqId, String attuid, String token) throws CometDataException,CometServiceException;

}
