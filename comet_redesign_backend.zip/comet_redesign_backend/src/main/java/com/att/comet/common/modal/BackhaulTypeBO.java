package com.att.comet.common.modal;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Business object for Back-haul Types.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class BackhaulTypeBO implements Serializable {

	private static final long serialVersionUID = 8902800475516549903L;

	private Long backhaulTypeId;
	private String backhaulTypeName;
	private String isActive;

}
