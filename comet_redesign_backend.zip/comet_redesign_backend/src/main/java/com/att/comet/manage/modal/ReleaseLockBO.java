package com.att.comet.manage.modal;

import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.common.modal.OrderUserTrackerBO;
import com.att.comet.order.modal.OrderUserQueueBO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class ReleaseLockBO extends CometGenericBO {
	private static final long serialVersionUID = 4580654474510739162L;

	private OrderUserQueueBO orderUserQueue;
	private OrderUserTrackerBO orderUserTracker;	
}
