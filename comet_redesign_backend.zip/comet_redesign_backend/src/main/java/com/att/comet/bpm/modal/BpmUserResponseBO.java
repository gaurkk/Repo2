package com.att.comet.bpm.modal;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class BpmUserResponseBO {
	private UserProfileBO userProfile;
	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}
