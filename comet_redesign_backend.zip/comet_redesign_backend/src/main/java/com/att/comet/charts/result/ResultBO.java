/**
 * 
 */
package com.att.comet.charts.result;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
public class ResultBO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private DisplayResultBO lstResult;
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private ChartInfoBO otherBO = new ChartInfoBO();
}
