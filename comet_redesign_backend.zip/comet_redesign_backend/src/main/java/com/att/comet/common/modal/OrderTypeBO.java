package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderTypeBO extends CometGenericBO {

	private static final long serialVersionUID = 1L;
	private int orderTypeId;
	private String orderTypeName;
}
