package com.att.comet.criteria.util;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.comet.criteria.OtherDetails;
import com.att.comet.criteria.OutputFormat;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.criteria.SearchCriteriaImpl;
import com.att.comet.criteria.TaskRole;
import com.att.comet.order.task.constant.TaskStatus;
import com.att.comet.restriction.Restriction;
import com.att.comet.restriction.task.TaskRoleRestriction;
import com.att.comet.restriction.task.TaskStatusRestriction;

public class OrderTaskInboxCriteriaHelper {
	private static final Logger logger = LoggerFactory.getLogger(OrderTaskInboxCriteriaHelper.class);
	@Autowired
	private static SearchCriteria criteria;

	@Autowired
	private List<CriteriaRenderer> listRenderers;

	/**
	 * Get the object of Search Criteria
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria() throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl() : criteria.clone());
	}
	
	/**
	 * Get the object of Search Criteria with specified output format
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria(OutputFormat format) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format) : criteria.clone());
	}
	
	/**
	 * Get the object of Search Criteria with specified output format and other
	 * details
	 * 
	 * @return SearchCriteria
	 */
	public static SearchCriteria getCriteria(OutputFormat format, OtherDetails other) throws Exception {
		return (SearchCriteria) (criteria == null ? new SearchCriteriaImpl(format, other) : criteria.clone());
	}

	
	/**
	 * Add Task status restriction to result 
	 * @param statuses
	 * @return Restriction
	 */
	public static Restriction getTaskStatus(List<com.att.comet.criteria.TaskStatus> statuses)
	{
		return new TaskStatusRestriction(statuses);
	}
	
	/**
	 * Add User role restriction to result 
	 * @param role
	 * @return Restriction
	 */
	public static Restriction getTaskRole(TaskRole role)
	{
		return new TaskRoleRestriction(role);
	}
	
	
}
