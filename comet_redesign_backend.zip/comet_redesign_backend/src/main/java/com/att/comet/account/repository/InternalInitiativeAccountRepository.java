package com.att.comet.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.InternalProductAccount;
@Repository
public interface InternalInitiativeAccountRepository extends JpaRepository<InternalProductAccount,Long> {
	@Query("select distinct internalProductAccountName from InternalProductAccount where accountClass = '1002' AND internalProductAccountName LIKE %:criteria%")
	List<String> getInternalInitiativeAccountList(String criteria);
}
