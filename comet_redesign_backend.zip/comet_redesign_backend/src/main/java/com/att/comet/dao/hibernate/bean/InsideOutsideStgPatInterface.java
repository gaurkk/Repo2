package com.att.comet.dao.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "IN_OUT_STG_PAT_INTERFACE")
public class InsideOutsideStgPatInterface implements java.io.Serializable {

	private static final long serialVersionUID = 3538013363480413683L;
	private InsideOutsideDataCenterId insideOutsideDataCenterId;
	private DataCenter dataCenter;
	private Long orderId;

	/**
	 * @return the insideOutsideDataCenterId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "dataCenterId", column = @Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "insideOutside", column = @Column(name = "INSIDE_OUTSIDE", nullable = false, length = 100)) })
	public InsideOutsideDataCenterId getInsideOutsideDataCenterId() {
		return insideOutsideDataCenterId;
	}

	/**
	 * @param insideOutsideDataCenterId the insideOutsideDataCenterId to set
	 */
	public void setInsideOutsideDataCenterId(InsideOutsideDataCenterId insideOutsideDataCenterId) {
		this.insideOutsideDataCenterId = insideOutsideDataCenterId;
	}

	/**
	 * @return the dataCenter
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_CENTER_ID", nullable = false, insertable = false, updatable = false)
	public DataCenter getDataCenter() {
		return dataCenter;
	}

	/**
	 * @param dataCenter the dataCenter to set
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}

	/**
	 * @return the orderId
	 */
	@Column(name = "ORDER_ID", nullable = true, precision = 12, scale = 0)
	public Long getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

}
