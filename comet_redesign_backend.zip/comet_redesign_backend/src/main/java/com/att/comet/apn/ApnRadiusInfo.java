package com.att.comet.apn;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ApnRadiusInfo {
	private Character radAccServEnabled;
	private List<ApnRadiusBO> apnRadiuses;
	private List<UeIpDataCenterBo> ueIpDcList;
	private String hostedRadiusType;
	private String authenticationType;
	private Character fwdRadReqAuthEnabled;
	private Character fwdRadReqMsgEnabled;
	private Character interimUpdate = 'N';
	private String interimUpdateValue;
}
