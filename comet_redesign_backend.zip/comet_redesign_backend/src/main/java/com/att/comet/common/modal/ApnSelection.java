package com.att.comet.common.modal;

import org.apache.commons.lang3.StringUtils;

public enum ApnSelection {
	DEDICATED(3, "Dedicated"),
	NONE(2, "None"),
	NEW(1, "New"); 

	public int getApnSelectionId() {
		return apnSelectionId;
	}

	public String getApnSelectionName() {
		return apnSelectionName;
	}

	private final int apnSelectionId;
	private final String apnSelectionName;

	public static ApnSelection getEnum(String value) {
		ApnSelection getStat = null;
		if (StringUtils.isNotBlank(value)) {
			for (ApnSelection stat : ApnSelection.values()) {
				if (stat.name().equalsIgnoreCase(value)) {
					getStat = stat;
					break;
				}
			}
		}
		return getStat;
	}

	private ApnSelection(int apnSelectionId, String apnSelectionName) {
		this.apnSelectionId = apnSelectionId;
		this.apnSelectionName = apnSelectionName;
	}
}
