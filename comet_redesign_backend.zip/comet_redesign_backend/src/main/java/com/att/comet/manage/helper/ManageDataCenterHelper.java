package com.att.comet.manage.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.order.helper.OrderHelper;

@Component
public class ManageDataCenterHelper {

	private static final Logger logger = LoggerFactory.getLogger(OrderHelper.class);

	public DataCenter populateDataCenter(DataCenterBO dataCenterBO,DataCenter dataCenter){
		logger.info("Starting method populateDataCenter : ", dataCenterBO);
		dataCenter.setDataCenterName(dataCenterBO.getDataCenterName());

		if(dataCenterBO.getDummy().equalsIgnoreCase("Yes")){
			dataCenter.setDummy('Y');			
		}else{
			dataCenter.setDummy('N');
		}
		dataCenter.setFirstNet(dataCenterBO.getFirstNet()== null ? "N" : dataCenterBO.getFirstNet());
		dataCenter.setZoneName(dataCenterBO.getZoneName());
		logger.info("End method populateDataCenter : ", dataCenterBO);
		return dataCenter;
	}	

}
