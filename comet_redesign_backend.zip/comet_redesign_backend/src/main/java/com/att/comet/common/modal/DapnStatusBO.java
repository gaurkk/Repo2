package com.att.comet.common.modal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper=true)
public class DapnStatusBO extends CometGenericBO{

	private static final long serialVersionUID = 5499980404979201973L;
	private Long dapnStatusId;
	private String dapnStatus;
}
