package com.att.comet.help.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.service.GenericCometService;
import com.att.comet.help.modal.HelpContentBO;

public interface HelpService extends GenericCometService {

	Map<Long, String> prepareHelpContents() throws CometDataException;
	
	HelpContentBO getHelpForId(Long contentId) throws CometDataException;
	
	Boolean updateHelp(HelpContentBO helpContentBO, MultipartFile file, boolean isAttachFileUpdated) throws CometDataException;
}
