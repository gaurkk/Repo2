package com.att.comet.common.constant;

/**
 * Holds the contact type id present in the comet application.
 */
public class TypeOrderContact {

	/**
	 * Sales Contact
	 */
	public static final Long ORDER_CONTACT_SALES = 1001L;

	/**
	 * Provisioning Project Manager
	 */
	public static final Long ORDER_CONTACT_PPM = 1002L;

	/**
	 * Order Submitter
	 */
	public static final Long ORDER_CONTACT_OS = 1003L;

	/**
	 * Order Approver
	 */
	public static final Long ORDER_CONTACT_OA = 1004L;

	/**
	 * Order Manager
	 */
	public static final Long ORDER_CONTACT_OM = 1005L;

	/**
	 * CCS PM
	 */
	public static final Long ORDER_CONTACT_CCSPM = 1006L;

	/**
	 * Network Implementation
	 */
	public static final Long ORDER_CONTACT_NI = 1007L;

	/**
	 * Project Manager
	 */
	public static final Long ORDER_CONTACT_PM = 1008L;

	/**
	 * Application Server Admin
	 */
	public static final Long ORDER_CONTACT_APP_SERV_ADMIN = 1009L;

	/**
	 * Firewall Administrator
	 */
	public static final Long ORDER_CONTACT_FIREWALL_ADMIN = 1010L;

	/**
	 * VPN Administrator
	 */
	public static final Long ORDER_CONTACT_VPN_ADMIN = 1011L;

	/**
	 * Frame Administrator
	 */
	public static final Long ORDER_CONTACT_FRAME_ADMIN = 1012L;

	/**
	 * Billing Administrator
	 */
	public static final Long ORDER_CONTACT_BILLING_ADMIN = 1013L;

	/**
	 * Help Desk
	 */
	public static final Long ORDER_CONTACT_HELPDESK = 1014L;

	/**
	 * Customer Technical Contact
	 */
	public static final Long ORDER_CONTACT_CUST_TECH_CONTACT = 1015L;

	/**
	 * Customer Business Contact
	 */
	public static final Long ORDER_CONTACT_CUST_BUSS_CONTACT = 1016L;

	/**
	 * Initiative Originator
	 */
	public static final Long ORDER_CONTACT_INTIATIVE_ORG = 1017L;

	/**
	 * Initiative Originator
	 */
	public static final Long ORDER_CONTACT_CUSTOMER = 1018L;

	/**
	 * Technical contact
	 */
	public static final Long ORDER_CONTACT_TECHNICAL = 1019L;

	/**
	 * Billing contact
	 */
	public static final Long ORDER_CONTACT_BILLING = 1020L;

	/**
	 * Onsite contact
	 */
	public static final Long ORDER_CONTACT_ONSITE = 1021L;

	/**
	 * Alternate contact
	 */
	public static final Long ORDER_CONTACT_ALTERNATE = 1022L;

	/**
	 * System Engineer
	 */
	public static final Long ORDER_CONTACT_OSD = 1023L;

	/**
	 * IT OPS
	 */
	public static final Long ORDER_CONTACT_IT_OPS = 1024L;

	/**
	 * POST SALES SE
	 */
	public static final Long ORDER_CONTACT_POST_SALES_SE = 1025L;
}
