package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALL_FIELD_REPORT_VIEW")
public class AllFieldReportView implements Serializable {
	private static final long serialVersionUID = -2039608369505978224L;
	
	private Long orderId;
	private String orderType;
	private String orderStatus;
	private String referenceOrderId;
	private String expedite;
	private String express;
	private String accountClass;
	private String masterAccountName;
	private String subAccountName;
	private String feeWaiverAccount;
	private String feeWaiverOrder;
	private String feeWaiverApprovedMRC;
	private String tsp;
	private String apnName;
	private String apnStatus;
	private String pdpId;
	private String pdpName;
	private String managedAvpn;
	private String attRadius;
	private String mobileToMobile;
	private String mobileTerminated;
	private String mobileOriginate;
	private String eod;
	private String splitTunnelInternetAccess;
	private String mobileTerminatedSplitTunnel;
	private String sourceOfIpAddressing;
	private String mobilePoolType;
	private String addressingType;
	private String ipptCustommerHostedRadius;
	private String enterpriseTargetIpRange;
	private String mobilePoolAddress;
	private String fanId;
	private String banId;
	private String eodBlu;
	private String marketSegment;
	private String orderSubmitter;
	private String osd;
	private String orderApprover;
	private String orderManager;
	private String ccspm;
	private String networkImplementor;
	private String itOps;
	private String geoRedundant;
	private String activePassive;
	private String dataCenters;
	private String backhaulType;
	private String tunnelType;
	private String vti;
	private String routingProtocol;
	private String restrictiveRouting;
	private String cirSpeed;
	private String strictTcp;
	private String dateSubmitted;
	private String approvedByOrderApprover;
	private String approvedByOrderManager;
	private String approvedByOsd;
	private String hlrHssCompleteionDate;
	private String niIWOSCreationDate;
	private String apnBuildIwosCompeteDate;
	private Long billingTaskId;
	private String billingCreationDate;
	private String billingCompleteDate;
	private String itOpsCompleteDate;
	private String dashBoardCompleteDate;
	private String ccspmOrderUpdateCompleteDate;
	private String niOrderUpdateComplete;
	private String ttuRequired;
	private String onHoldStatus;
	private Long daysOnHold;
	private String ttuScheduleDate;
	private String inProductionDate;
	private String lteSweep;
	private String apnInProductionDate;
	private String ipbrFlag;
	private String msp;
	private String pcrf;
	private String splitAccessPAT;
	private String enterpriseTargetIpRangeRoute;
	private String intTargetIpRanges;
	private String geoOptimization;
	private String patPoolRange;
	private String ccipRadius;
	private String internetVpnEndpoint;
	private String migratedOrder;
	private String dedicatedAPN;
	private String mspEntAndMms;
	private Long vlanId;
	private String vlanGi;
	private Long ccsRouterBaseRd;
	private String vrfName;
	private String ocs;
	private String interfaceTunnelNum;
	private String cryptoVlanId;
	private String firstNet = "N";
	private String turboAppSupport = "N";
	private String dscpPreservation = "N";
	// 5.1 merging
	private String apnType;
	private String isAmp;
	private String ccsMx;
	private String firstNetEpc;// Added For Req#6.2.01 sp3599
	private String crdRow4;
	private String accaHealthCheckEnable;
	private Long numberOfChangeRequests;
	private String orderCreatedOn;
	
	@Column(name = "ORDER_CREATED_ON")
	public String getOrderCreatedOn() {
		return orderCreatedOn;
	}
	public void setOrderCreatedOn(String orderCreatedOn) {
		this.orderCreatedOn = orderCreatedOn;
	}
	
	@Id
	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	
	@Column(name = "ORDER_TYPE")
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	@Column(name = "ORDER_STATUS")
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	@Column(name = "REF_ORDER_ID")
	public String getReferenceOrderId() {
		return referenceOrderId;
	}
	public void setReferenceOrderId(String referenceOrderId) {
		this.referenceOrderId = referenceOrderId;
	}
	@Column(name = "EXPEDITE")
	public String getExpedite() {
		return expedite;
	}
	public void setExpedite(String expedite) {
		this.expedite = expedite;
	}
	@Column(name = "EXPRESS")
	public String getExpress() {
		return express;
	}
	public void setExpress(String express) {
		this.express = express;
	}
	@Column(name = "ACCOUNT_CLASS")
	public String getAccountClass() {
		return accountClass;
	}
	public void setAccountClass(String accountClass) {
		this.accountClass = accountClass;
	}
	@Column(name = "MASTER_ACCOUNT_NAME")
	public String getMasterAccountName() {
		return masterAccountName;
	}
	public void setMasterAccountName(String masterAccountName) {
		this.masterAccountName = masterAccountName;
	}
	@Column(name = "ACCOUNT_NAME")
	public String getSubAccountName() {
		return subAccountName;
	}
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}
	@Column(name = "FEE_WAIVER_ACCOUNT")
	public String getFeeWaiverAccount() {
		return feeWaiverAccount;
	}
	public void setFeeWaiverAccount(String feeWaiverAccount) {
		this.feeWaiverAccount = feeWaiverAccount;
	}
	@Column(name = "FEE_WAIVER_ORDER")
	public String getFeeWaiverOrder() {
		return feeWaiverOrder;
	}
	public void setFeeWaiverOrder(String feeWaiverOrder) {
		this.feeWaiverOrder = feeWaiverOrder;
	}
	@Column(name = "FEE_WAIVER_APPROVED_MRC")
	public String getFeeWaiverApprovedMRC() {
		return feeWaiverApprovedMRC;
	}
	public void setFeeWaiverApprovedMRC(String feeWaiverApprovedMRC) {
		this.feeWaiverApprovedMRC = feeWaiverApprovedMRC;
	}
	@Column(name = "TSP")
	public String getTsp() {
		return tsp;
	}
	public void setTsp(String tsp) {
		this.tsp = tsp;
	}
	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}
	@Column(name = "APN_STATUS")
	public String getApnStatus() {
		return apnStatus;
	}
	public void setApnStatus(String apnStatus) {
		this.apnStatus = apnStatus;
	}
	@Column(name = "PDP_ID")
	public String getPdpId() {
		return pdpId;
	}
	public void setPdpId(String pdpId) {
		this.pdpId = pdpId;
	}
	@Column(name = "PDP_NAME")
	public String getPdpName() {
		return pdpName;
	}
	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}
	@Column(name = "MANAGED_AVPN")
	public String getManagedAvpn() {
		return managedAvpn;
	}
	public void setManagedAvpn(String managedAvpn) {
		this.managedAvpn = managedAvpn;
	}
	@Column(name = "ATT_RADIUS")
	public String getAttRadius() {
		return attRadius;
	}
	public void setAttRadius(String attRadius) {
		this.attRadius = attRadius;
	}
	@Column(name = "MOBILE_TO_MOBILE")
	public String getMobileToMobile() {
		return mobileToMobile;
	}
	public void setMobileToMobile(String mobileToMobile) {
		this.mobileToMobile = mobileToMobile;
	}
	@Column(name = "MOBILE_TERMINATED")
	public String getMobileTerminated() {
		return mobileTerminated;
	}
	public void setMobileTerminated(String mobileTerminated) {
		this.mobileTerminated = mobileTerminated;
	}
	@Column(name = "MOBILE_ORIGINATE")
	public String getMobileOriginate() {
		return mobileOriginate;
	}
	public void setMobileOriginate(String mobileOriginate) {
		this.mobileOriginate = mobileOriginate;
	}
	@Column(name = "EOD")
	public String getEod() {
		return eod;
	}
	public void setEod(String eod) {
		this.eod = eod;
	}
	@Column(name = "SPLIT_TUNNEL_INTERNET_ACCESS")
	public String getSplitTunnelInternetAccess() {
		return splitTunnelInternetAccess;
	}
	public void setSplitTunnelInternetAccess(String splitTunnelInternetAccess) {
		this.splitTunnelInternetAccess = splitTunnelInternetAccess;
	}
//	@Column(name = "MOBILE_TERMINATED_SPLIT_TUNNEL")
//	public String getMobileTerminatedSplitTunnel() {
//		return mobileTerminatedSplitTunnel;
//	}
//	public void setMobileTerminatedSplitTunnel(String mobileTerminatedSplitTunnel) {
//		this.mobileTerminatedSplitTunnel = mobileTerminatedSplitTunnel;
//	}
	@Column(name = "IP_ADDRESS_SOURCE")
	public String getSourceOfIpAddressing() {
		return sourceOfIpAddressing;
	}
	public void setSourceOfIpAddressing(String sourceOfIpAddressing) {
		this.sourceOfIpAddressing = sourceOfIpAddressing;
	}
	@Column(name = "MOBILE_POOL_TYPE")
	public String getMobilePoolType() {
		return mobilePoolType;
	}
	public void setMobilePoolType(String mobilePoolType) {
		this.mobilePoolType = mobilePoolType;
	}
	@Column(name = "ADDRESS_TYPE")
	public String getAddressingType() {
		return addressingType;
	}
	public void setAddressingType(String addressingType) {
		this.addressingType = addressingType;
	}
	@Column(name = "IPPT_CUST_RADIUS")
	public String getIpptCustommerHostedRadius() {
		return ipptCustommerHostedRadius;
	}
	public void setIpptCustommerHostedRadius(String ipptCustommerHostedRadius) {
		this.ipptCustommerHostedRadius = ipptCustommerHostedRadius;
	}
	@Column(name = "ENT_TARGET_IP_RANGE")
	public String getEnterpriseTargetIpRange() {
		return enterpriseTargetIpRange;
	}
	public void setEnterpriseTargetIpRange(String enterpriseTargetIpRange) {
		this.enterpriseTargetIpRange = enterpriseTargetIpRange;
	}
	@Column(name = "MOBILE_POOL_ADDRESS")
	public String getMobilePoolAddress() {
		return mobilePoolAddress;
	}
	public void setMobilePoolAddress(String mobilePoolAddress) {
		this.mobilePoolAddress = mobilePoolAddress;
	}
	@Column(name = "FAN_ID")
	public String getFanId() {
		return fanId;
	}
	public void setFanId(String fanId) {
		this.fanId = fanId;
	}
	@Column(name = "BAN_ID")
	public String getBanId() {
		return banId;
	}
	public void setBanId(String banId) {
		this.banId = banId;
	}
	@Column(name = "EOD_BLU")
	public String getEodBlu() {
		return eodBlu;
	}
	public void setEodBlu(String eodBlu) {
		this.eodBlu = eodBlu;
	}
	@Column(name = "MARKET_SEGMENT")
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	@Column(name = "OS")
	public String getOrderSubmitter() {
		return orderSubmitter;
	}
	public void setOrderSubmitter(String orderSubmitter) {
		this.orderSubmitter = orderSubmitter;
	}
	@Column(name = "OSD")
	public String getOsd() {
		return osd;
	}
	public void setOsd(String osd) {
		this.osd = osd;
	}
	@Column(name = "OA")
	public String getOrderApprover() {
		return orderApprover;
	}
	public void setOrderApprover(String orderApprover) {
		this.orderApprover = orderApprover;
	}
	@Column(name = "OM")
	public String getOrderManager() {
		return orderManager;
	}
	public void setOrderManager(String orderManager) {
		this.orderManager = orderManager;
	}
	@Column(name = "CCSPM")
	public String getCcspm() {
		return ccspm;
	}
	public void setCcspm(String ccspm) {
		this.ccspm = ccspm;
	}
	@Column(name = "NI")
	public String getNetworkImplementor() {
		return networkImplementor;
	}
	public void setNetworkImplementor(String networkImplementor) {
		this.networkImplementor = networkImplementor;
	}
	@Column(name = "ITOPS")
	public String getItOps() {
		return itOps;
	}
	public void setItOps(String itOps) {
		this.itOps = itOps;
	}
	@Column(name = "GEO")
	public String getGeoRedundant() {
		return geoRedundant;
	}
	public void setGeoRedundant(String geoRedundant) {
		this.geoRedundant = geoRedundant;
	}
	@Column(name = "ACTIVE_PASSIVE")
	public String getActivePassive() {
		return activePassive;
	}
	public void setActivePassive(String activePassive) {
		this.activePassive = activePassive;
	}
	@Column(name = "DATA_CENTERS")
	public String getDataCenters() {
		return dataCenters;
	}
	public void setDataCenters(String dataCenters) {
		this.dataCenters = dataCenters;
	}
	@Column(name = "BACKHAUL_TYPES")
	public String getBackhaulType() {
		return backhaulType;
	}
	public void setBackhaulType(String backhaulType) {
		this.backhaulType = backhaulType;
	}
	@Column(name = "TUNNEL_TYPE")
	public String getTunnelType() {
		return tunnelType;
	}
	public void setTunnelType(String tunnelType) {
		this.tunnelType = tunnelType;
	}
	@Column(name = "VTI")
	public String getVti() {
		return vti;
	}
	public void setVti(String vti) {
		this.vti = vti;
	}
	@Column(name = "ROUTING_PROTOCOL")
	public String getRoutingProtocol() {
		return routingProtocol;
	}
	public void setRoutingProtocol(String routingProtocol) {
		this.routingProtocol = routingProtocol;
	}
	@Column(name = "RESTRICTIVE_ROUTING")
	public String getRestrictiveRouting() {
		return restrictiveRouting;
	}
	public void setRestrictiveRouting(String restrictiveRouting) {
		this.restrictiveRouting = restrictiveRouting;
	}
	@Column(name = "CIR_SPEED")
	public String getCirSpeed() {
		return cirSpeed;
	}
	public void setCirSpeed(String cirSpeed) {
		this.cirSpeed = cirSpeed;
	}
	@Column(name = "STRICT_TCP")
	public String getStrictTcp() {
		return strictTcp;
	}
	public void setStrictTcp(String strictTcp) {
		this.strictTcp = strictTcp;
	}
	@Column(name = "DATE_SUBMITTED")
	public String getDateSubmitted() {
		return dateSubmitted;
	}
	public void setDateSubmitted(String dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}
	@Column(name = "DATE_OA_APPROVED")
	public String getApprovedByOrderApprover() {
		return approvedByOrderApprover;
	}
	public void setApprovedByOrderApprover(String approvedByOrderApprover) {
		this.approvedByOrderApprover = approvedByOrderApprover;
	}
	@Column(name = "DATE_OM_APPROVED")
	public String getApprovedByOrderManager() {
		return approvedByOrderManager;
	}
	public void setApprovedByOrderManager(String approvedByOrderManager) {
		this.approvedByOrderManager = approvedByOrderManager;
	}
	@Column(name = "DATE_OSD_APPROVED")
	public String getApprovedByOsd() {
		return approvedByOsd;
	}
	public void setApprovedByOsd(String approvedByOsd) {
		this.approvedByOsd = approvedByOsd;
	}
	@Column(name = "DATE_HLR_HSS_COMPLETE")
	public String getHlrHssCompleteionDate() {
		return hlrHssCompleteionDate;
	}
	public void setHlrHssCompleteionDate(String hlrHssCompleteionDate) {
		this.hlrHssCompleteionDate = hlrHssCompleteionDate;
	}
	@Column(name = "DATE_NI_IWOS_CREATION")
	public String getNiIWOSCreationDate() {
		return niIWOSCreationDate;
	}
	public void setNiIWOSCreationDate(String niIWOSCreationDate) {
		this.niIWOSCreationDate = niIWOSCreationDate;
	}
	@Column(name = "DATE_IWOS_COMPLETE")
	public String getApnBuildIwosCompeteDate() {
		return apnBuildIwosCompeteDate;
	}
	public void setApnBuildIwosCompeteDate(String apnBuildIwosCompeteDate) {
		this.apnBuildIwosCompeteDate = apnBuildIwosCompeteDate;
	}
//	@Column(name = "APN_NAME")
//	public Long getBillingTaskId() {
//		return billingTaskId;
//	}
//	public void setBillingTaskId(Long billingTaskId) {
//		this.billingTaskId = billingTaskId;
//	}
	@Column(name = "DATE_BILLING_CREATION")
	public String getBillingCreationDate() {
		return billingCreationDate;
	}
	public void setBillingCreationDate(String billingCreationDate) {
		this.billingCreationDate = billingCreationDate;
	}
	@Column(name = "DATE_BILLING_COMPLETE")
	public String getBillingCompleteDate() {
		return billingCompleteDate;
	}
	public void setBillingCompleteDate(String billingCompleteDate) {
		this.billingCompleteDate = billingCompleteDate;
	}
	@Column(name = "DATE_ITOPS_COMPLETE")
	public String getItOpsCompleteDate() {
		return itOpsCompleteDate;
	}
	public void setItOpsCompleteDate(String itOpsCompleteDate) {
		this.itOpsCompleteDate = itOpsCompleteDate;
	}
	@Column(name = "DATE_DASHBOARd_COMPLETE")
	public String getDashBoardCompleteDate() {
		return dashBoardCompleteDate;
	}
	public void setDashBoardCompleteDate(String dashBoardCompleteDate) {
		this.dashBoardCompleteDate = dashBoardCompleteDate;
	}
	@Column(name = "DATE_CCSPM_UPDATE_COMPLETE")
	public String getCcspmOrderUpdateCompleteDate() {
		return ccspmOrderUpdateCompleteDate;
	}
	public void setCcspmOrderUpdateCompleteDate(String ccspmOrderUpdateCompleteDate) {
		this.ccspmOrderUpdateCompleteDate = ccspmOrderUpdateCompleteDate;
	}
	@Column(name = "DATE_NI_ORDER_UPDATE_COMPLETE")
	public String getNiOrderUpdateComplete() {
		return niOrderUpdateComplete;
	}
	public void setNiOrderUpdateComplete(String niOrderUpdateComplete) {
		this.niOrderUpdateComplete = niOrderUpdateComplete;
	}
	@Column(name = "TTU_REQUIRED")
	public String getTtuRequired() {
		return ttuRequired;
	}
	public void setTtuRequired(String ttuRequired) {
		this.ttuRequired = ttuRequired;
	}
	@Column(name = "ON_HOLD")
	public String getOnHoldStatus() {
		return onHoldStatus;
	}
	public void setOnHoldStatus(String onHoldStatus) {
		this.onHoldStatus = onHoldStatus;
	}
	@Column(name = "DAYS_ON_HOLD")
	public Long getDaysOnHold() {
		return daysOnHold;
	}
	public void setDaysOnHold(Long daysOnHold) {
		this.daysOnHold = daysOnHold;
	}
	@Column(name = "TTU_SCHEDULE_DATE")
	public String getTtuScheduleDate() {
		return ttuScheduleDate;
	}
	public void setTtuScheduleDate(String ttuScheduleDate) {
		this.ttuScheduleDate = ttuScheduleDate;
	}
	@Column(name = "DATE_IN_PRODUCTIOn")
	public String getInProductionDate() {
		return inProductionDate;
	}
	public void setInProductionDate(String inProductionDate) {
		this.inProductionDate = inProductionDate;
	}
	@Column(name = "LTE_SWEEP")
	public String getLteSweep() {
		return lteSweep;
	}
	public void setLteSweep(String lteSweep) {
		this.lteSweep = lteSweep;
	}
	@Column(name = "DATE_APN_IN_PRODUCTION")
	public String getApnInProductionDate() {
		return apnInProductionDate;
	}
	public void setApnInProductionDate(String apnInProductionDate) {
		this.apnInProductionDate = apnInProductionDate;
	}
	@Column(name = "IPBR")
	public String getIpbrFlag() {
		return ipbrFlag;
	}
	public void setIpbrFlag(String ipbrFlag) {
		this.ipbrFlag = ipbrFlag;
	}
	@Column(name = "MSP")
	public String getMsp() {
		return msp;
	}
	public void setMsp(String msp) {
		this.msp = msp;
	}
	@Column(name = "PCRF")
	public String getPcrf() {
		return pcrf;
	}
	public void setPcrf(String pcrf) {
		this.pcrf = pcrf;
	}
	@Column(name = "SPLIT_ACCESS_PAT")
	public String getSplitAccessPAT() {
		return splitAccessPAT;
	}
	public void setSplitAccessPAT(String splitAccessPAT) {
		this.splitAccessPAT = splitAccessPAT;
	}
	@Column(name = "ENT_TARGET_IP_RANGE_ROUTE")
	public String getEnterpriseTargetIpRangeRoute() {
		return enterpriseTargetIpRangeRoute;
	}
	public void setEnterpriseTargetIpRangeRoute(String enterpriseTargetIpRangeRoute) {
		this.enterpriseTargetIpRangeRoute = enterpriseTargetIpRangeRoute;
	}
	@Column(name = "INT_TARGET_IP_RANGE")
	public String getIntTargetIpRanges() {
		return intTargetIpRanges;
	}
	public void setIntTargetIpRanges(String intTargetIpRanges) {
		this.intTargetIpRanges = intTargetIpRanges;
	}
	@Column(name = "GEO_OPTIMIZATION")
	public String getGeoOptimization() {
		return geoOptimization;
	}
	public void setGeoOptimization(String geoOptimization) {
		this.geoOptimization = geoOptimization;
	}
	@Column(name = "PAT_POOL_RANGE")
	public String getPatPoolRange() {
		return patPoolRange;
	}
	public void setPatPoolRange(String patPoolRange) {
		this.patPoolRange = patPoolRange;
	}
	@Column(name = "CCIP_RADIUS")
	public String getCcipRadius() {
		return ccipRadius;
	}
	public void setCcipRadius(String ccipRadius) {
		this.ccipRadius = ccipRadius;
	}
	@Column(name = "INTERNET_VPN_ENDPOINT")
	public String getInternetVpnEndpoint() {
		return internetVpnEndpoint;
	}
	public void setInternetVpnEndpoint(String internetVpnEndpoint) {
		this.internetVpnEndpoint = internetVpnEndpoint;
	}
	@Column(name = "MIGRATED_ORDER")
	public String getMigratedOrder() {
		return migratedOrder;
	}
	public void setMigratedOrder(String migratedOrder) {
		this.migratedOrder = migratedOrder;
	}
	@Column(name = "DEDICATED_APN")
	public String getDedicatedAPN() {
		return dedicatedAPN;
	}
	public void setDedicatedAPN(String dedicatedAPN) {
		this.dedicatedAPN = dedicatedAPN;
	}
	@Column(name = "MSP_ENTITILEMENT_AND_MMS")
	public String getMspEntAndMms() {
		return mspEntAndMms;
	}
	public void setMspEntAndMms(String mspEntAndMms) {
		this.mspEntAndMms = mspEntAndMms;
	}
//	@Column(name = "VLAN_ID")
//	public Long getVlanId() {
//		return vlanId;
//	}
//	public void setVlanId(Long vlanId) {
//		this.vlanId = vlanId;
//	}
	@Column(name = "VLAN_GI")
	public String getVlanGi() {
		return vlanGi;
	}
	public void setVlanGi(String vlanGi) {
		this.vlanGi = vlanGi;
	}
	@Column(name = "CCS_ROUTER_BASE_RD")
	public Long getCcsRouterBaseRd() {
		return ccsRouterBaseRd;
	}
	public void setCcsRouterBaseRd(Long ccsRouterBaseRd) {
		this.ccsRouterBaseRd = ccsRouterBaseRd;
	}
	@Column(name = "VRF_NAME")
	public String getVrfName() {
		return vrfName;
	}
	public void setVrfName(String vrfName) {
		this.vrfName = vrfName;
	}
	@Column(name = "OCS")
	public String getOcs() {
		return ocs;
	}
	public void setOcs(String ocs) {
		this.ocs = ocs;
	}
	@Column(name = "INTERFACE_TUNNEL_NUM")
	public String getInterfaceTunnelNum() {
		return interfaceTunnelNum;
	}
	public void setInterfaceTunnelNum(String interfaceTunnelNum) {
		this.interfaceTunnelNum = interfaceTunnelNum;
	}
	@Column(name = "CRYPTO_VLAN_ID")
	public String getCryptoVlanId() {
		return cryptoVlanId;
	}
	public void setCryptoVlanId(String cryptoVlanId) {
		this.cryptoVlanId = cryptoVlanId;
	}
	@Column(name = "FIRST_NET")
	public String getFirstNet() {
		return firstNet;
	}
	public void setFirstNet(String firstNet) {
		this.firstNet = firstNet;
	}
	@Column(name = "TURBO_APP_SUPPORT")
	public String getTurboAppSupport() {
		return turboAppSupport;
	}
	public void setTurboAppSupport(String turboAppSupport) {
		this.turboAppSupport = turboAppSupport;
	}
	@Column(name = "DSCP_PRESERVATION")
	public String getDscpPreservation() {
		return dscpPreservation;
	}
	public void setDscpPreservation(String dscpPreservation) {
		this.dscpPreservation = dscpPreservation;
	}
	@Column(name = "APN_TYPE")
	public String getApnType() {
		return apnType;
	}
	public void setApnType(String apnType) {
		this.apnType = apnType;
	}
	@Column(name = "ISAMP")
	public String getIsAmp() {
		return isAmp;
	}
	public void setIsAmp(String isAmp) {
		this.isAmp = isAmp;
	}
	@Column(name = "CCS_MX")
	public String getCcsMx() {
		return ccsMx;
	}
	public void setCcsMx(String ccsMx) {
		this.ccsMx = ccsMx;
	}
	@Column(name = "FIRSTNET_EPC")
	public String getFirstNetEpc() {
		return firstNetEpc;
	}
	public void setFirstNetEpc(String firstNetEpc) {
		this.firstNetEpc = firstNetEpc;
	}
	@Column(name = "CRD_ROW_ENABLE")
	public String getCrdRow4() {
		return crdRow4;
	}
	public void setCrdRow4(String crdRow4) {
		this.crdRow4 = crdRow4;
	}
	@Column(name = "ACCA_HEALTH_CHECK_ENABLE")
	public String getAccaHealthCheckEnable() {
		return accaHealthCheckEnable;
	}
	public void setAccaHealthCheckEnable(String accaHealthCheckEnable) {
		this.accaHealthCheckEnable = accaHealthCheckEnable;
	}
	@Column(name = "NUMBER_OF_CHANGE_REQUESTS")
	public Long getNumberOfChangeRequests() {
		return numberOfChangeRequests;
	}
	public void setNumberOfChangeRequests(Long numberOfChangeRequests) {
		this.numberOfChangeRequests = numberOfChangeRequests;
	}

}
