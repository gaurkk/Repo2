package com.att.comet.charts.result;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class TaskListGridDisplayBO implements Serializable{

	private static final long serialVersionUID = -2197960464148467783L;

	private String taskId;
	private String bpmTaskId;
	private Long orderId;
	private String owner;
	private String apnName;
	private String accountName;
	private String taskName;
	private String subject;
	private String createdDate;
	private String displayName;
	private String completionDate;
	private String expedite;
	private String openReminder;
	private String taskType;
	private Character dashFlag = 'N';
	private String taskReference;
	private boolean userOpenPermission = false; 
	private Long taskStatusId;
}
