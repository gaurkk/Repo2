package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.AdminConfig;
@Repository
public interface TunnelTypeRepository extends JpaRepository<AdminConfig,Long> {
	@Query("select categoryValue from AdminConfig where adminCategory = '1016'")
	List<String> getTunnelTypeList();
}
