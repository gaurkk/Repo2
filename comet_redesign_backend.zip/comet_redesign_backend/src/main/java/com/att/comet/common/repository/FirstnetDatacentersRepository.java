package com.att.comet.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.comet.dao.hibernate.bean.FirstnetDatacenters;

public interface FirstnetDatacentersRepository extends JpaRepository<FirstnetDatacenters,Long>{

}
