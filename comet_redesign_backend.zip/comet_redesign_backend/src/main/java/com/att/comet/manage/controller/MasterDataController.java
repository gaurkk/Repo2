package com.att.comet.manage.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.modal.AdminCategoryBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.manage.modal.AdminConfigParamBO;
import com.att.comet.manage.modal.MasterAdminCategoryBO;
import com.att.comet.manage.service.ManageService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class MasterDataController {
	private static final Logger logger = LoggerFactory.getLogger(MasterDataController.class);

	@Autowired
	ManageService manageService;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/getCategoryInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Category Details", notes = "Find Category Details")
	public CometResponse<List<MasterAdminCategoryBO>> getCategoryInfo() throws CometDataException {
		logger.info("Starting method getCategoryInfo :", this);
		CometResponse<List<MasterAdminCategoryBO>> cometResponse = new CometResponse<List<MasterAdminCategoryBO>>();
		List<MasterAdminCategoryBO> masterAdminCategoryBOList = null;
		masterAdminCategoryBOList = manageService.getCategoryInfo();
		if (null != masterAdminCategoryBOList) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(masterAdminCategoryBOList);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method getCategoryInfo :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/getConfigInfo/{categoryId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Admin Config Details", notes = "Find Admin Config Details")
	public CometResponse<AdminCategoryBO> getConfigInfo(@PathVariable Long categoryId,
			@RequestParam(required = false) Map<String, String> serachCretriaMap) throws CometDataException {
		logger.info("Starting method getConfigInfo :", this);

		AdminConfigParamBO adminConfigParamBO = new AdminConfigParamBO(categoryId,
				Boolean.parseBoolean(serachCretriaMap.get("isSpecialCategory")), serachCretriaMap.get("dataCenter"),
				serachCretriaMap.get("ccsmx"), serachCretriaMap.get("apnProtocol"),
				serachCretriaMap.get("sourceIPAddress"), serachCretriaMap.get("ccsmxRouter"),
				serachCretriaMap.get("firstNet"));
		CometResponse<AdminCategoryBO> cometResponse = new CometResponse<AdminCategoryBO>();
		AdminCategoryBO adminCategoryBO = null;
		adminCategoryBO = manageService.getConfigInfo(adminConfigParamBO);
		if (null != adminCategoryBO) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(adminCategoryBO);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method getConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PostMapping(value = "manage/addConfigInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add Admin Config Details", notes = "Add Admin Config Details")
	public CometResponse<String> addConfigInfo(@RequestBody AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method addConfigInfo :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String message = null;
		message = manageService.addConfigInfo(adminConfigBO);
		if (null != message) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(message);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method addConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "manage/updateConfigInfo", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update Admin Config Details", notes = "Update Admin Config Details")
	public CometResponse<String> updateConfigInfo(@RequestBody AdminConfigBO adminConfigBO) throws CometDataException {
		logger.info("Starting method updateConfigInfo :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String message = null;
		message = manageService.updateConfigInfo(adminConfigBO);
		if (null != message) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(message);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method updateConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@DeleteMapping(value = "manage/deleteConfigInfo/{configId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Delete Admin Config Details", notes = "Delete Admin Config Details")
	public CometResponse<String> deleteConfigInfo(@PathVariable Long configId) throws CometDataException {
		logger.info("Starting method deleteConfigInfo :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String message = null;
		message = manageService.deleteConfigInfo(configId);
		if (null != message) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(message);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method deleteConfigInfo :", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "manage/getOrderStatus", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Manage Status Details", notes = "Manage Status Details")
	public CometResponse<List<OrderStatusBO>> getOrderStatus() throws CometDataException {
		logger.info("Starting method getOrderStatus :", this);
		CometResponse<List<OrderStatusBO>> cometResponse = new CometResponse<List<OrderStatusBO>>();
		List<OrderStatusBO> orderStatusBOList = null;
		orderStatusBOList = manageService.getOrderStatusList();
		if (null != orderStatusBOList) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(orderStatusBOList);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method getOrderStatus :", this);
		return cometResponse;
	}

	@Secured({"ROLE_COMET_ADMIN"})
	@PutMapping(value = "manage/updateOrderStatus", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Update Order Status Details", notes = "Update Order Status Details")
	public CometResponse<String> updateOrderStatus(@RequestBody OrderStatusBO orderStatusBO) throws CometDataException {
		logger.info("Starting method updateOrderStatus :", this);
		CometResponse<String> cometResponse = new CometResponse<String>();
		String message = null;
		message = manageService.updateOrderStatus(orderStatusBO);
		if (null != message) {
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
			cometResponse.setMethodReturnValue(message);
		} else {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
		}
		logger.info("Existing method updateOrderStatus :", this);
		return cometResponse;
	}
}
