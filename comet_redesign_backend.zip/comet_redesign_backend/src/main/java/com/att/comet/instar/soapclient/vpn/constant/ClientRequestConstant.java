package com.att.comet.instar.soapclient.vpn.constant;

public class ClientRequestConstant {

	public final static String vpnSearchServiceEndPoint ="https://stb-lpp.oss.att.com:9097/lppbck-service/ws/vpnInfoV1";
	
	public final static String vpnSearchSoapEnvRequestHeader = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n" + 
			"	<SOAP-ENV:Header xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n" + 
			"		<oas:Security xmlns:oas=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">\r\n" + 
			"			<oas:UsernameToken xmlns:oas=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">\r\n" + 
			"				<oas:Username xmlns:oas=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">comet_ws</oas:Username>\r\n" + 
			"				<oas:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\" xmlns:oas=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">comet_ws123</oas:Password>\r\n" + 
			"			</oas:UsernameToken>\r\n" + 
			"		</oas:Security>\r\n" + 
			"	</SOAP-ENV:Header>";
	
	public final static String vpnSearchHeaderBody1 = "<SOAP-ENV:Body xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n" + 
			"		<tns:getVpnsByNameRequest xmlns:tns=\"http://lpp.att.com/service/vpn/info/schema/v1\" xmlns:ch=\"http://cio.att.com/commonheader/v3\">\r\n" + 
			"			<ch:WSHeader/>";
	
	public final static String vpnSearchHeaderBody2 = "</tns:getVpnsByNameRequest>\r\n" + 
			"	</SOAP-ENV:Body>\r\n" + 
			"</SOAP-ENV:Envelope>";
	
}
