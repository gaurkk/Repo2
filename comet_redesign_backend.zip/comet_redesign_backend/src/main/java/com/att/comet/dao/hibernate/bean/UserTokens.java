package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "USER_TOKENS")
@Data
public class UserTokens implements Serializable {

	private static final long serialVersionUID = 2722727688877206682L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "attuid", column = @Column(name = "ATTUID", nullable = false, length = 6)),
			@AttributeOverride(name = "roleId", column = @Column(name = "ROLE_ID", nullable = false, precision = 12, scale = 0)) })
	private UserTokensId userTokensId;
	
	@Column(name = "ENV", length = 10)
	private String env;

	@Column(name = "TOKEN", length = 500)
	private String token;
}
