package com.att.comet.audit.modal;

import java.util.List;

import com.att.comet.apn.ApnDNSConfiguration;
import com.att.comet.apn.ApnDomainProtocolConf;
import com.att.comet.apn.ApnHealthCheckInfo;
import com.att.comet.apn.ApnRadiusBO;
import com.att.comet.apn.ApnRadiusInfo;
import com.att.comet.apn.ApnSectionBasicInfo;
import com.att.comet.apn.EnterpriseTargetIpRangeBO;
import com.att.comet.apn.InternetTargetIpRangeBO;
import com.att.comet.apn.MobilePoolAddressBO;
import com.att.comet.apn.PatPoolAddressBO;
import com.att.comet.apn.PdpIdInfoBO;
import com.att.comet.apn.PersistentIpBO;
import com.att.comet.common.modal.CometGenericBO;
import com.att.comet.order.modal.DedicatedMobilePoolAddressBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class ApnAuditBO extends CometGenericBO {
	private static final long serialVersionUID = 745487114850697001L;

	private String addressType;
	private Character overRide;
	private Character overRidePdp;
	private String ccsVRFName;
	private String updatedBy;
	private Long roleId;
	private String insideOusideStgPat;
	private String interimUpdateValue;
	private Character ccsmx;
	private Character overRideCcsMx;
	private List<PdpIdInfoBO> pdpIdInfoBOList;
	private List<PersistentIpBO> persistentIps;
	private ApnSectionBasicInfo apnSectionBasicInfo;
	private ApnDomainProtocolConf apnDomainProtocolConf;
	private ApnHealthCheckInfo apnHealthCheckInfo;
	private ApnDNSConfiguration apnDNSConfiguration;
	private ApnRadiusInfo apnRadiusInfo;
	private Long orderId; 
	private String apnName; 
	private String provisioningMethod; 
	private String ipAddressSource; 
	private String amplifyingInformation; 
	private Character fwdRadReqAuthEnabled; 
	private Character fwdRadReqMsgEnabled; 
	private Character mobileTerminationEnabled;  
	private Character mobileToMobileEnabled; 
 	private Character mobileOriginateEnabled; 
 	private Character radAccServEnabled; 
	private String socFeatureCode; 
	private Character splitTunnelIntEnabled; 
	private Character splitTunnelMTEnabled; 
	private Long totalMobilePoolSize; 
	private Long uniqueIPAddressSize; 
	private String dnsServerIp; 
	private String domainName; 
	private Character migratedOrder = 'N'; 
	private String mobilePoolType; 
	private Character managedAvpn; 
	private Character noFirewall; 
	private Character ipbr = 'N'; 
	private Character msp ; 
	private String whitelistBlacklist; 
	private String pcrf; 
	private Character splitAccessPAT; 
	private Character geoOptimization; 
	private Character ccipRadius; 
	private Character mspEntAndMms ; 
	private Character ocs = 'Y'; 
	private String apnProtocol; 
	private Character firstNet = 'N'; 
	private Character turboAppSupport = 'N'; 
	private Character dscpPreservation = 'N'; 
	private Character interimUpdate = 'N'; 
	private String authenticationType; 
	private String hostedRadiusType; 
	private List<EnterpriseTargetIpRangeBO> entTargetIpRanges;
	private List<DedicatedMobilePoolAddressBO> dedicatedMobilePoolAddresses;
	private List<MobilePoolAddressBO> mobilePoolAddressesList;
	private String errorCode;
	private String errorMessage;
	private List<ApnRadiusBO> apnRadiuses;
	private List<PatPoolAddressBO> patPoolAddresses;
	private List<InternetTargetIpRangeBO> intTargetIpRanges;
	private Character pacl = 'N';
	private Character paclEnabled;
}
