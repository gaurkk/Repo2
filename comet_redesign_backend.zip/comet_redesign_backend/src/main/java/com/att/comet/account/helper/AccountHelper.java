package com.att.comet.account.helper;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.account.modal.InternalAccountBO;
import com.att.comet.account.modal.MasterAccountBO;
import com.att.comet.account.modal.OrderCapacityForecastBO;
import com.att.comet.account.modal.ProductAccountBO;
import com.att.comet.account.modal.SubAccountBO;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.AccountClass;
import com.att.comet.dao.hibernate.bean.City;
import com.att.comet.dao.hibernate.bean.Country;
import com.att.comet.dao.hibernate.bean.InternalProductAccount;
import com.att.comet.dao.hibernate.bean.MasterAccount;
import com.att.comet.dao.hibernate.bean.OrderCapacityForecast;
import com.att.comet.dao.hibernate.bean.OrderCapacityForecastId;
import com.att.comet.dao.hibernate.bean.State;
import com.att.comet.dao.hibernate.bean.SubAccount;

@Component
public class AccountHelper {
	private static final Logger logger = LoggerFactory.getLogger(AccountHelper.class);

	/**
	 * Convert hibernate OrderCapacityForecast to OrderCapacityForecastBO.
	 * 
	 * @param pForecast
	 * @return
	 */
	public static OrderCapacityForecastBO populateOrderCapacityForecastBO(OrderCapacityForecast pForecast) {
		OrderCapacityForecastBO forecastBO = new OrderCapacityForecastBO();
		logger.info("[OrderId : " + (pForecast == null ? "" : pForecast.getId().getOrderId())
				+ "] Starting method populateOrderCapacityForecastBO : ");
		OrderCapacityForecastId pForecastId = pForecast.getId();
		if (pForecastId != null) {
			forecastBO.setOrderId(pForecastId.getOrderId());
			forecastBO.setYear(pForecastId.getYear());
		}

		forecastBO.setPeakConcurrentActivePDPCtxPerNDC(pForecast.getPkConcurrentPdpNdc());
		forecastBO.setPeakConcurrentActivePDPCtxTotal(pForecast.getPkConcurrentTotalPdp());
		forecastBO.setPeakPDPCtxActivationsPerSecondsNDC(pForecast.getPkPdpCtxActvPerSec());
		forecastBO.setPeakPercentDevicesWithConcurrentActivePDPCtxCalculated(pForecast.getPkPercentOfDevices());
		forecastBO.setPeakPercentOfDevicesWithConcurrentActivePDPCtxForcast(pForecast.getPkPercentPerPdp());
		forecastBO.setPeakWANBandwidthTotalAllNDC(pForecast.getPkWanBwTotalNdc());
		forecastBO.setSpeedPerMonthPerSubscriber(pForecast.getSpeedPerSubscriber());
		forecastBO.setSubscribedDevicesOnATTInfrastructure(pForecast.getSubscriberDevices());
		forecastBO.setTotalSMSWakeupsPerMonth(pForecast.getTotalSmsWakeupsMonth());
		forecastBO.setTotalSMSWakeupsPerSecondPeak(pForecast.getTotalSmsWakeupsSec());

		logger.info("[OrderId : " + (pForecast == null ? "" : pForecast.getId().getOrderId())
				+ "] Exitting method populateOrderCapacityForecastBO : ");
		return forecastBO;
	}

	public static SubAccountBO populateSubAccountBO(SubAccount pSubAccount) throws SQLException {
		logger.info("[AccountID :" + pSubAccount.getBcid() + "] " + "Method populateSubAccountBO: Start");
		SubAccountBO subAccountBO = new SubAccountBO();
		subAccountBO.setBcid(pSubAccount.getBcid());
		subAccountBO.setSubAccountName(pSubAccount.getSubAccountName());
		subAccountBO.setFederalTaxId(pSubAccount.getFederalTaxId());
		subAccountBO.setTsp(pSubAccount.getTsp());
		subAccountBO.setFeeWaiverApproved(pSubAccount.getFeeWaiverApproved());
		subAccountBO.setWaiverNotes(pSubAccount.getWaiverNotes());
		subAccountBO.setCompanyName(pSubAccount.getCompanyName());
		subAccountBO.setCompanyOwner(pSubAccount.getCompanyOwner());
		subAccountBO.setBusinessDescription(pSubAccount.getBusinessDescription());

		if (pSubAccount.getClStreetAddress() != null) {
			subAccountBO.setCompanyStreetAddress(pSubAccount.getClStreetAddress());
		}
		if (pSubAccount.getCountryByClCountryId() != null) {
			subAccountBO.setCompanyCountryCode(pSubAccount.getCountryByClCountryId().getCountryId());
		}
		if (pSubAccount.getStateByClStateId() != null) {
			subAccountBO.setCompanyState(pSubAccount.getStateByClStateId().getStateId());
		}
		if (pSubAccount.getCityByClCityId() != null) {
			subAccountBO.setCompanyCity(pSubAccount.getCityByClCityId().getCityId());
		}

		if (pSubAccount.getClZipCode() != null) {
			subAccountBO.setCompanyZip(Long.parseLong(pSubAccount.getClZipCode()));
		}

		if (pSubAccount.getCountryByBlCountryId() != null) {
			subAccountBO.setBillingCountryCode(pSubAccount.getCountryByBlCountryId().getCountryId());
		}
		if (pSubAccount.getBlStreetAddress() != null) {
			subAccountBO.setBillingStreetAddress(pSubAccount.getBlStreetAddress());
		}
		if (pSubAccount.getStateByBlStateId() != null) {
			subAccountBO.setBillingState(pSubAccount.getStateByBlStateId().getStateId());
		}
		if (pSubAccount.getCityByBlCityId() != null) {
			subAccountBO.setBillingCity(pSubAccount.getCityByBlCityId().getCityId());
		}
		if (pSubAccount.getBlZipCode() != null) {
			subAccountBO.setBillingZip(Long.parseLong(pSubAccount.getBlZipCode()));
		}
		subAccountBO.setHqStreetAddress(pSubAccount.getHlStreetAddress());

		if (pSubAccount.getCountryByHlCountryId() != null) {
			subAccountBO.setHqCountryCode(pSubAccount.getCountryByHlCountryId().getCountryId());
		}

		if (pSubAccount.getStateByHlStateId() != null) {
			subAccountBO.setHqState(pSubAccount.getStateByHlStateId().getStateId());
		}

		if (pSubAccount.getCityByHlCityId() != null) {
			subAccountBO.setHqCity(pSubAccount.getCityByHlCityId().getCityId());
		}

		if (pSubAccount.getHlZipCode() != null) {
			subAccountBO.setHqZip(Long.parseLong(pSubAccount.getHlZipCode()));
		}
		subAccountBO.setCompanyMainContact(pSubAccount.getMainCustContact());
		subAccountBO.setCompanyContactState(pSubAccount.getStateByMccStateId().getStateId());
		subAccountBO.setCompanyContactCity(pSubAccount.getCityByMccCityId().getCityId());
		if (pSubAccount.getMccZipCode() != null) {
			subAccountBO.setCompanyContactZip(Long.parseLong(pSubAccount.getMccZipCode()));
		}

		if (pSubAccount.getCountryByMccCountryId() != null) {
			subAccountBO.setCompanyContactCountry(pSubAccount.getCountryByMccCountryId().getCountryId());
			subAccountBO.setCompanyContactCountryName(pSubAccount.getCountryByMccCountryId().getCountryName());
			subAccountBO.setCompanyContactStateName(pSubAccount.getStateByMccStateId().getStateName());
			subAccountBO.setCompanyContactCityName(pSubAccount.getCityByMccCityId().getCityName());
			subAccountBO.setAccountType(pSubAccount.getAccountType());
		}

		MasterAccount pMasterAccount = pSubAccount.getMasterAccount();
		if (pMasterAccount != null) {
			subAccountBO.setUbcid(pMasterAccount.getUbcid());
			subAccountBO.setMasterAccountName(pMasterAccount.getMasterAccountName());
			AccountClass pAccountClass = pMasterAccount.getAccountClass();
			if (pAccountClass != null) {
				subAccountBO.setAccountClass(pAccountClass.getAccountClassId());
			}
		}

		subAccountBO.setCompanyContactStreetAddress(pSubAccount.getMccStreetAddress());
		if (pSubAccount.getMccDeskphone() != null) {
			subAccountBO.setCompanyContactDeskPhone(pSubAccount.getMccDeskphone().toString());
		}
		if (pSubAccount.getMccDeskphoneExtension() != null) {
			subAccountBO.setCompanyContactDeskPhoneExtension(pSubAccount.getMccDeskphoneExtension());
		}

		if (pSubAccount.getMccCellphone() != null) {
			subAccountBO.setCompanyContactCellPhone(pSubAccount.getMccCellphone().toString());
		}
		subAccountBO.setCompanyContactEmail(pSubAccount.getMccEmail());
		subAccountBO.setCreatedBy(pSubAccount.getCreatedBy());
		subAccountBO.setCreatedOn(pSubAccount.getCreatedOn());
		subAccountBO.setUpdatedBy(pSubAccount.getUpdatedBy());
		subAccountBO.setUpdatedOn(pSubAccount.getUpdatedOn());
		subAccountBO.setWaiverAttachmentFilename(pSubAccount.getWaiverAttachmentFilename());
		if (pSubAccount.getWaiverAttachment() != null) {
			//Blob attachment = pSubAccount.getWaiverAttachment();
			//subAccountBO.setWaiverAttachment(attachment.getBytes(1, (int) attachment.length()));
			subAccountBO.setWaiverAttachment(pSubAccount.getWaiverAttachment());
		}

		subAccountBO.setDerivedBlFromCl(pSubAccount.getDerivedBlFromCl());
		subAccountBO.setDerivedBlFromHq(pSubAccount.getDerivedBlFromHq());
		subAccountBO.setDerivedClFromHq(pSubAccount.getDerivedClFromHq());
		subAccountBO.setDerivedCciFromHq(pSubAccount.getDerivedCciFromHq());
		logger.info("[AccountID :" + pSubAccount.getBcid() + "] " + "Method populateSubAccountBO: End");
		return subAccountBO;
	}

	/**
	 * THe method populates Sub Account Details.
	 * 
	 * @param account
	 * @return SubAccount
	 * @throws IOException
	 */
	public SubAccount populateSubAccount(SubAccountBO account, SubAccount pSubAccount) {
		logger.info("Starting method populateSubAccount : ");
		// Basic info
		if (pSubAccount == null) {
			pSubAccount = new SubAccount();
		}

		// Set AccountBO type
		pSubAccount.setAccountType(account.getAccountType());

		// Set BCID, account name
		if (account.getBcid() != null) {
			pSubAccount.setBcid(account.getBcid());
		}
		pSubAccount.setSubAccountName(account.getSubAccountName().trim());

		// Set UBCID of master account
		if (account.getUbcid() != null) {
			MasterAccount pMasterAccount = new MasterAccount();
			pMasterAccount.setUbcid(account.getUbcid());
			pSubAccount.setMasterAccount(pMasterAccount);
		}

		// Set all cities
		if (account.getCompanyCity() != null) {
			City cityByClCityId = new City();
			cityByClCityId.setCityId(account.getCompanyCity());
			pSubAccount.setCityByClCityId(cityByClCityId);
		}

		if (account.getBillingCity() != null) {
			City cityByBlCityId = new City();
			cityByBlCityId.setCityId(account.getBillingCity());
			pSubAccount.setCityByBlCityId(cityByBlCityId);
		}

		if (account.getHqCity() != null) {
			City cityByHlCityId = new City();
			cityByHlCityId.setCityId(account.getHqCity());
			pSubAccount.setCityByHlCityId(cityByHlCityId);
		}

		if (account.getCompanyContactCity() != null) {
			City cityByMccCityId = new City();
			cityByMccCityId.setCityId(account.getCompanyContactCity());
			pSubAccount.setCityByMccCityId(cityByMccCityId);
		}

		// Set all states
		if (account.getCompanyState() != null) {
			State stateByClStateId = new State();
			stateByClStateId.setStateId(account.getCompanyState());
			pSubAccount.setStateByClStateId(stateByClStateId);
		}

		if (account.getBillingState() != null) {
			State stateByBlStateId = new State();
			stateByBlStateId.setStateId(account.getBillingState());
			pSubAccount.setStateByBlStateId(stateByBlStateId);
		}

		if (account.getHqState() != null) {
			State stateByHlStateId = new State();
			stateByHlStateId.setStateId(account.getHqState());
			pSubAccount.setStateByHlStateId(stateByHlStateId);
		}

		if (account.getCompanyContactState() != null) {
			State stateByMccStateId = new State();
			stateByMccStateId.setStateId(account.getCompanyContactState());
			pSubAccount.setStateByMccStateId(stateByMccStateId);
		}

		// Set all countries
		if (account.getCompanyCountryCode() != null) {
			Country countryByClCountryId = new Country();
			countryByClCountryId.setCountryId(account.getCompanyCountryCode());
			pSubAccount.setCountryByClCountryId(countryByClCountryId);
		}

		if (account.getBillingCountryCode() != null) {
			Country countryByBlCountryId = new Country();
			countryByBlCountryId.setCountryId(account.getBillingCountryCode());
			pSubAccount.setCountryByBlCountryId(countryByBlCountryId);
		}

		if (account.getHqCountryCode() != null) {
			Country countryByHlCountryId = new Country();
			countryByHlCountryId.setCountryId(account.getHqCountryCode());
			pSubAccount.setCountryByHlCountryId(countryByHlCountryId);
		}

		if (account.getCompanyContactCountry() != null) {
			Country countryByMccCountryId = new Country();
			countryByMccCountryId.setCountryId(account.getCompanyContactCountry());
			pSubAccount.setCountryByMccCountryId(countryByMccCountryId);
		}

		// Set Active flag
		pSubAccount.setActive('Y');

		// Set Waiver Attachment and filename
		if (account.getWaiverAttachment() != null) {
			pSubAccount.setWaiverAttachmentFilename(account.getWaiverAttachmentFilename());
			//pSubAccount.setWaiverAttachment(Hibernate.getLobCreator(null).createBlob(account.getWaiverAttachment()));
			pSubAccount.setWaiverAttachment(account.getWaiverAttachment());
		}

		// Audit user and date
		pSubAccount.setCreatedBy(account.getCreatedBy());
		pSubAccount.setCreatedOn(account.getCreatedOn());
		pSubAccount.setUpdatedBy(account.getUpdatedBy());
		pSubAccount.setUpdatedOn(account.getUpdatedOn());

		if (account.getFederalTaxId() != null) {
			pSubAccount.setFederalTaxId(account.getFederalTaxId());
		}

		pSubAccount.setTsp(account.getTsp());
		pSubAccount.setFeeWaiverApproved(account.getFeeWaiverApproved());
		pSubAccount.setWaiverNotes(account.getWaiverNotes());
		pSubAccount.setCompanyName(account.getCompanyName());
		pSubAccount.setCompanyOwner(account.getCompanyOwner());
		pSubAccount.setBusinessDescription(account.getBusinessDescription());
		pSubAccount.setClStreetAddress(account.getCompanyStreetAddress());

		if (account.getCompanyZip() != null) {
			pSubAccount.setClZipCode(account.getCompanyZip() + "");
		}

		pSubAccount.setBlStreetAddress(account.getBillingStreetAddress());

		if (account.getBillingZip() != null) {
			pSubAccount.setBlZipCode(account.getBillingZip() + "");
		}

		pSubAccount.setHlStreetAddress(account.getHqStreetAddress());

		if (account.getHqZip() != null) {
			pSubAccount.setHlZipCode(account.getHqZip() + "");
		}

		pSubAccount.setMainCustContact(account.getCompanyMainContact());
		pSubAccount.setMccStreetAddress(account.getCompanyContactStreetAddress());

		if (account.getCompanyContactZip() != null) {
			pSubAccount.setMccZipCode(account.getCompanyContactZip() + "");
		}

		if (account.getCompanyContactDeskPhone() != null) {
			pSubAccount.setMccDeskphone(Long.valueOf(account.getCompanyContactDeskPhone()));
		}

		if (account.getCompanyContactDeskPhoneExtension() != null) {
			pSubAccount.setMccDeskphoneExtension(account.getCompanyContactDeskPhoneExtension());
		}

		if (CommonUtils.isValidString(account.getCompanyContactCellPhone())) {
			pSubAccount.setMccCellphone(Long.valueOf(account.getCompanyContactCellPhone()));
		}
		pSubAccount.setMccEmail(account.getCompanyContactEmail());

		pSubAccount.setDerivedBlFromCl(account.getDerivedBlFromCl());
		pSubAccount.setDerivedBlFromHq(account.getDerivedBlFromHq());
		pSubAccount.setDerivedClFromHq(account.getDerivedClFromHq());
		pSubAccount.setDerivedCciFromHq(account.getDerivedCciFromHq());
		logger.info("End method populateSubAccount : ");
		return pSubAccount;
	}

	/**
	 * The method for populating the Internal Product Account details.
	 * 
	 * @param account
	 * @return InternalProductAccount
	 * @throws IOException
	 */
	public InternalProductAccount populateInternalAccount(InternalAccountBO account) throws IOException {
		logger.info("Starting method populateInternalAccount : ");
		InternalProductAccount pAccount = new InternalProductAccount();
		if (account.getAccountClass() != null) {
			AccountClass accountClass = new AccountClass();
			accountClass.setAccountClassId(account.getAccountClass());
			pAccount.setAccountClass(accountClass);
		}

		pAccount.setInternalProductAccountName(account.getInternalInitiativeName().trim());

		if (account.getFederalTaxId() != null) {
			pAccount.setFederalTaxId(account.getFederalTaxId());
		}

		pAccount.setTsp(account.getTsp());
		pAccount.setFeeWaiverApproved(account.getFeeWaiverApproved());
		pAccount.setWaiverNotes(account.getWaiverNotes());
		if (account.getWaiverAttachment() != null) {
			//pAccount.setWaiverAttachment(Hibernate.getLobCreator(null).createBlob(account.getWaiverAttachment()));
			pAccount.setWaiverAttachment(account.getWaiverAttachment());
		}
		pAccount.setWaiverAttachmentFilename(account.getWaiverAttachmentFilename());
		pAccount.setCreatedBy(account.getCreatedBy());
		pAccount.setCreatedOn(account.getCreatedOn());
		pAccount.setUpdatedBy(account.getUpdatedBy());
		pAccount.setUpdatedOn(account.getUpdatedOn());
		pAccount.setActive('Y');
		logger.info("End method populateInternalAccount : ");
		return pAccount;
	}

	/**
	 * Convert Internal Product Account BO to ProductAccountBO
	 * 
	 * @param account
	 * @return InternalProductAccount
	 * @throws IOException
	 */
	public InternalProductAccount populateProductAccount(ProductAccountBO account) throws IOException {
		logger.info("Start method populateProductAccount : ");
		InternalProductAccount pAccount = new InternalProductAccount();
		if (account.getAccountClass() != null) {
			AccountClass accountClass = new AccountClass();
			accountClass.setAccountClassId(account.getAccountClass());
			pAccount.setAccountClass(accountClass);
		}

		pAccount.setInternalProductAccountName(account.getProductInitiativeName().trim());

		if (account.getFederalTaxId() != null) {
			pAccount.setFederalTaxId(account.getFederalTaxId());
		}

		pAccount.setTsp(account.getTsp());
		pAccount.setFeeWaiverApproved(account.getFeeWaiverApproved());
		pAccount.setWaiverNotes(account.getWaiverNotes());
		if (account.getWaiverAttachment() != null) {
			//pAccount.setWaiverAttachment(Hibernate.getLobCreator(null).createBlob(account.getWaiverAttachment()));
			pAccount.setWaiverAttachment(account.getWaiverAttachment());

		}
		pAccount.setWaiverAttachmentFilename(account.getWaiverAttachmentFilename());
		pAccount.setCreatedBy(account.getCreatedBy());
		pAccount.setCreatedOn(account.getCreatedOn());
		pAccount.setUpdatedBy(account.getUpdatedBy());
		pAccount.setUpdatedOn(account.getUpdatedOn());
		pAccount.setActive('Y');
		logger.info("End method populateProductAccount : ");
		return pAccount;
	}

	public MasterAccount populateMasterAccount(MasterAccountBO account) {
		logger.info("Start method populateMasterAccount : ");
		MasterAccount pMasterAccount = new MasterAccount();
		pMasterAccount.setMasterAccountName(account.getMasterAccountName().trim());

		if (account.getUbcid() != null) {
			pMasterAccount.setUbcid(account.getUbcid());
		}

		if (account.getAccountClass() != null) {
			AccountClass pAccountClass = new AccountClass();
			pAccountClass.setAccountClassId(account.getAccountClass());
			pMasterAccount.setAccountClass(pAccountClass);
		}
		logger.info("End method populateMasterAccount : ");
		return pMasterAccount;
	}
}
