package com.att.comet.manage.modal;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class LineBO implements Serializable{

	private static final long serialVersionUID = -4058637991735111114L;
	
}
