package com.att.comet.dao.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Persistent class for OrderDataCenterId.
 */
@Embeddable
public class ImsiDataCenterDetailsId implements java.io.Serializable {

	private static final long serialVersionUID = 2516339686603305563L;

	private Long orderId;
	private Long dataCenterId;

	/**
	 * Getter method for orderId. ORDER_ID mapped to ORDER_ID in the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)
	public Long getOrderId() {
		return this.orderId;
	}

	/**
	 * @param orderId to orderId set.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Getter method for dataCenterId. DATA_CENTER_ID mapped to DATA_CENTER_ID in
	 * the database table.
	 * 
	 * @return Long
	 */
	@Column(name = "DATA_CENTER_ID", nullable = false, precision = 12, scale = 0)
	public Long getDataCenterId() {
		return this.dataCenterId;
	}

	/**
	 * @param dataCenterId to dataCenterId set.
	 */
	public void setDataCenterId(Long dataCenterId) {
		this.dataCenterId = dataCenterId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataCenterId == null) ? 0 : dataCenterId.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ImsiDataCenterDetailsId other = (ImsiDataCenterDetailsId) obj;
		if (dataCenterId == null) {
			if (other.dataCenterId != null)
				return false;
		} else if (!dataCenterId.equals(other.dataCenterId))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}
}