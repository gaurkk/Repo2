package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IP_REPORT_VIEW")
public class IpReportView implements Serializable {
	private static final long serialVersionUID = -2039608369505978224L;
	private Long orderId;
	private String apnName;
	private String apnStatus;
	private Long apnPriority;
	private String pdpId;
	private String pdpName;
	private String datacenters;
	private String EntTargetIpRange;
	private String mobilePoolIp;

	@Id
	@Column(name = "ORDER_ID")
	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	@Column(name = "APN_NAME")
	public String getApnName() {
		return apnName;
	}

	public void setApnName(String apnName) {
		this.apnName = apnName;
	}

	@Column(name = "APN_STATUS")
	public String getApnStatus() {
		return apnStatus;
	}

	public void setApnStatus(String apnStatus) {
		this.apnStatus = apnStatus;
	}

	@Column(name = "APN_PRIORITY")
	public Long getApnPriority() {
		return apnPriority;
	}

	public void setApnPriority(Long apnPriority) {
		this.apnPriority = apnPriority;
	}

	@Column(name = "PDP_ID")
	public String getPdpId() {
		return pdpId;
	}

	public void setPdpId(String pdpId) {
		this.pdpId = pdpId;
	}

	@Column(name = "PDP_NAME")
	public String getPdpName() {
		return pdpName;
	}

	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}

	@Column(name = "DATA_CENTERS")
	public String getDatacenters() {
		return datacenters;
	}

	public void setDatacenters(String datacenters) {
		this.datacenters = datacenters;
	}

	@Column(name = "ENT_TARGET_IP_RANGE")
	public String getEntTargetIpRange() {
		return EntTargetIpRange;
	}

	public void setEntTargetIpRange(String entTargetIpRange) {
		EntTargetIpRange = entTargetIpRange;
	}

	@Column(name = "MOBILE_POOL_IP")
	public String getMobilePoolIp() {
		return mobilePoolIp;
	}

	public void setMobilePoolIp(String mobilePoolIp) {
		this.mobilePoolIp = mobilePoolIp;
	}

}
