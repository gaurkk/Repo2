package com.att.comet.common.exception;

public class DapnValidationException extends RuntimeException{

	private static final long serialVersionUID = 640223474206214340L;
	private String errorCode;
	private Object[] params;
	/**
	 * @param errorCode
	 * @param params
	 */
	public DapnValidationException(String errorCode, Object[] params) {
		super();
		this.errorCode = errorCode;
		this.params = params;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public Object[] getParams() {
		return params;
	}
}
