package com.att.comet.manage.helper;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.exception.DapnValidationException;
import com.att.comet.common.repository.DataCenterNameRepository;
import com.att.comet.common.service.MessageConfigService;
import com.att.comet.common.util.CometValidationRegExp;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.DapnInventory;
import com.att.comet.dao.hibernate.bean.DapnStatus;
import com.att.comet.dao.hibernate.bean.DataCenter;
import com.att.comet.dao.hibernate.bean.InventoryTemplate;
import com.att.comet.manage.constant.ConstantActionMessage;
import com.att.comet.manage.modal.ColumnInfoBO;
import com.att.comet.manage.modal.DapnCSVLineBO;
import com.att.comet.manage.modal.DapnUploadStatusBO;
import com.att.comet.manage.modal.ImsiMsisdnCSVLineBO;
import com.att.comet.manage.modal.InOutCSVLineBO;
import com.att.comet.manage.modal.InOutInterfaceCSVLineBO;
import com.att.comet.manage.modal.LineBO;
import com.att.comet.manage.modal.ManageInventoryTemplateBO;
import com.att.comet.manage.modal.MessageBO;
import com.att.comet.manage.modal.ParseResultBO;
import com.att.comet.manage.repository.DapnUploadStatusRepository;
import com.att.comet.manage.service.ManageService;

import static com.att.comet.order.dao.OrderSqlConstant.CHECK_USE_OF_THE_STATE_IN_COMET;
import static com.att.comet.order.dao.OrderSqlConstant.CHECK_USE_OF_THE_CITY_IN_COMET;

@Component
public class ManageInventoryHelper {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	ManageService manageService;
	
	@Autowired
	DataCenterNameRepository dataCenterNameRepository;
	
	@Autowired
	DapnUploadStatusRepository dapnUploadStatusRepository;
	
	@Autowired
	MessageConfigService  messageConfig;

	private static final Logger logger = LoggerFactory.getLogger(ManageInventoryHelper.class);

	private static final String DAPN_FILE_HEADER = "COMET-DAPN-INV-IMP-TEMP-VER1.0";
	private static final String PAT_FILE_HEADER = "COMET-PAT-CHNL-IMP-TEMP-VER1.0";
	private static final String INOUT_INTERFACE_FILE_HEADER = "COMET-INSIDE-OUTSIDE-INV-VER1.0";
	private static final String IMSI_MSISDN_FILE_HEADER = "COMET-IMSI-MSISDN-INV-VER1.0";

	/**
	 * This method is validate the file format, size and header line
	 * @param formFile
	 * @return boolean
	 */
	public ParseResultBO validateFileUpload(MultipartFile file,ParseResultBO resultBO) {
		logger.info("Starting method uploadManageInventory.",this);
		boolean isValidFile =false;
		resultBO = new ParseResultBO();
		if(null!=file) {
			if (!file.getResource().getFilename().endsWith(".csv")) {
				resultBO.setInvalidFileMesage(messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.version"));
				return resultBO;
			} else if (file.getSize() > 2097152) {
				resultBO.setInvalidFileMesage(messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.size"));
				return resultBO;
			}
			else {
				try {
					InputStream inputStream =file.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
					String header = reader.readLine();
					reader.close();
					inputStream.close();
					if ((!header.replaceAll(",", "").trim()
							.equals(DAPN_FILE_HEADER)) && (!header.replaceAll(",", "").trim()
									.equals(PAT_FILE_HEADER))&& (!header.replaceAll(",", "").trim()
											.equals(INOUT_INTERFACE_FILE_HEADER)) && (!header.replaceAll(",", "").trim()
													.equals(IMSI_MSISDN_FILE_HEADER))) {
						resultBO.setInvalidFileMesage(messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.version"));
						return resultBO;
						//throw new DapnValidationException("errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
					}else {
						isValidFile =true;
						logger.info("Valid uploadManageInventory file.",this);
					}
				} catch (IOException e) {
					isValidFile =false;
					resultBO.setInvalidFileMesage(messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.version"));
					//throw new DapnValidationException("errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
					return resultBO;
				}
			}
		}
		logger.info("Existing method uploadManageInventory.",this);
		return resultBO;

	}

	public boolean isDapnFile(MultipartFile file) {
		logger.info("Starting method isDapnFile.",this);
		boolean isDapnFile = false;
		try {
			InputStream inputStream =file.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String header = reader.readLine();
			reader.close();
			inputStream.close();
			if ((!header.replaceAll(",", "").trim()
					.equals(DAPN_FILE_HEADER))){
				isDapnFile = false;		
			}else {
				isDapnFile = true;
			}
		}
		catch(IOException e) {
			throw new DapnValidationException(
					"errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
		}
		logger.info("Exsiting method isDapnFile.",this);
		return isDapnFile;
	}

	public boolean isPatFile(MultipartFile file) {
		logger.info("Starting method isPatFile.",this);
		boolean isPatFile = false;
		try {
			InputStream inputStream =file.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String header = reader.readLine();
			reader.close();
			inputStream.close();
			if ((!header.replaceAll(",", "").trim()
					.equals(PAT_FILE_HEADER))){
				isPatFile=false;				
			}else {
				isPatFile = true;
			}
		}
		catch(IOException e) {
			throw new DapnValidationException(
					"errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
		}
		logger.info("Exsiting method isPatFile.",this);
		return isPatFile;
	}

	public boolean isInOutInterfaceFile(MultipartFile file) {
		logger.info("Starting method isInOutInterfaceFile.",this);
		boolean isInOutInterfaceFile = false;
		try {
			InputStream inputStream =file.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String header = reader.readLine();
			reader.close();
			inputStream.close();
			if ((!header.replaceAll(",", "").trim()
					.equals(INOUT_INTERFACE_FILE_HEADER))){
				isInOutInterfaceFile = false;
			}else {
				isInOutInterfaceFile = true;
			}
		}
		catch(IOException e) {
			throw new DapnValidationException(
					"errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
		}
		logger.info("Exsiting method isInOutInterfaceFile.",this);
		return isInOutInterfaceFile;
	}


	public boolean isMisiMsisdnFile(MultipartFile file) {
		logger.info("Starting method isMisiMsisdnFile.",this);
		boolean isMisiMsisdnFile = false;
		try {
			InputStream inputStream =file.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String header = reader.readLine();
			reader.close();
			inputStream.close();
			if ((!header.replaceAll(",", "").trim()
					.equals(IMSI_MSISDN_FILE_HEADER))){
				isMisiMsisdnFile =false;
			}else {
				isMisiMsisdnFile = true;
			}
		}
		catch(IOException e) {
			throw new DapnValidationException(
					"errors.inventory.upload.invalid.file.format",new Object[] { "- Invalid file version" });
		}
		logger.info("Exsiting method isMisiMsisdnFile.",this);
		return isMisiMsisdnFile;
	}

	public ParseResultBO parseUploadInOutStgPat(MultipartFile file) {
		logger.info("Start ManageInventoryUploadAction.parseUploadInOutStgPat()",this);
		ParseResultBO resultBO = null;
		if (file.getSize() > 2097152) {
			resultBO = new ParseResultBO();
			resultBO.getMessages()
			.add(getErrorBO(
					"Issues with PAT Channel import file – Invalid file size",
					"ERROR", null));
		}
		try {
			resultBO = parseCsvFile(file);
			resultBO =manageService.saveInOutPatFile(resultBO);

			if (resultBO != null && resultBO.getMessages() != null
					&& resultBO.getMessages().size() > 0) {
				Collections.sort(resultBO.getMessages(),
						new Comparator<MessageBO>() {
					@Override
					public int compare(MessageBO o1, MessageBO o2) {
						int val1 = o1.getRecordNumber();
						int val2 = o2.getRecordNumber();
						return (val1 < val2 ? -1 : (val1 == val2 ? 0 : 1));
					}
				});
			}
		} catch (CometDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CometServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("Existing ManageInventoryUploadAction.parseUploadInOutStgPat()",this);
		return resultBO;
	}

	public ParseResultBO parseUploadImsiMsisdn(MultipartFile file) {
		logger.info("Start ManageInventoryUploadAction.parseUploadImsiMsisdn()",this);
		ParseResultBO resultBO=null;

		try {
			resultBO= parseCsvFile(file);
			resultBO= manageService.saveImsiMsisdnFile(resultBO);
			if (resultBO != null && resultBO.getMessages() != null
					&& !resultBO.getMessages().isEmpty()) {
				Collections.sort(resultBO.getMessages(),
						new Comparator<MessageBO>() {
					@Override
					public int compare(MessageBO o1, MessageBO o2) {
						int val1 = o1.getRecordNumber();
						int val2 = o2.getRecordNumber();
						return (val1 < val2 ? -1 : (val1 == val2 ? 0 : 1));
					}
				});
			}
		} catch (CometDataException | CometServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("Existing ManageInventoryUploadAction.parseUploadImsiMsisdn()",this); 
		return resultBO;
	}

	public ParseResultBO parseUploadDAPN(MultipartFile file,String isActivated,String userId) {
		logger.info("Start ManageInventoryUploadAction.parseUploadDAPN()",this);
		ParseResultBO resultBO = null;
		List<DapnUploadStatusBO> lstDapnUploadStatusBO = null;
		long dapnStatusId = 1002;
		String batchId =null;
		if (isActivated != null && isActivated.equals("Y")) {
			dapnStatusId = 1001;
		}
		try {
			resultBO = parseCsvFile(file);
			if (resultBO != null && resultBO.getMessages() != null && resultBO.getMessages().size() == 0) {
				batchId = manageService.insertDapnRecords(resultBO.getLines(), userId, dapnStatusId ,resultBO);
				if(null!=batchId || batchId != "" && batchId != "No Record Found" && !StringUtils.isEmpty(batchId)) {
					lstDapnUploadStatusBO = manageService.getDapnUploadResultMessage(batchId);
					resultBO.setDapnploadStatus(lstDapnUploadStatusBO);
				}
			}else {
				if (resultBO != null && resultBO.getMessages() != null && !resultBO.getMessages().isEmpty()) {
					Collections.sort(resultBO.getMessages(),new Comparator<MessageBO>() {
								@Override
								public int compare(MessageBO o1, MessageBO o2) {
									int val1 = o1.getRecordNumber();
									int val2 = o2.getRecordNumber();
									return (val1 < val2 ? -1
											: (val1 == val2 ? 0 : 1));
								}
							});
				}
			}
		} catch (CometDataException e) {
			logger.error("RESULTBO for DAPN IS NULL , SO NOT ABLE TO UPLOAD ", this);
			logger.error(e.getMessage());
		} catch (CometServiceException e) {
			logger.error("RESULTBO for DAPN IS NULL , SO NOT ABLE TO UPLOAD ", this);
			logger.error(e.getMessage());
		}
		logger.info("Existing ManageInventoryUploadAction.parseUploadDAPN()",this);
		return resultBO;

	}

	public ParseResultBO parseUploadInOutInterface(MultipartFile file) {
		logger.info("Starting ManageInventoryUploadAction.parseUploadInOutInterface()",this);
		ParseResultBO resultBO =null;
		try {
			resultBO = parseCsvFile(file);
			resultBO=manageService.saveINOUTInterfaceFile(resultBO);
			if (resultBO.getLines().size() > 500) {
				resultBO.getMessages().add(
						getErrorBO("Only First 500 records processed", "ERROR",
								null));
			}
			if (resultBO != null && resultBO.getMessages() != null
					&& !resultBO.getMessages().isEmpty()) {
				Collections.sort(resultBO.getMessages(),
						new Comparator<MessageBO>() {
					@Override
					public int compare(MessageBO o1, MessageBO o2) {
						int val1 = o1.getRecordNumber();
						int val2 = o2.getRecordNumber();
						return (val1 < val2 ? -1 : (val1 == val2 ? 0 : 1));
					}
				});
			}

		} catch (CometDataException e) {
			logger.error("RESULTBO for IN OU INTERFACE IS NULL , SO NOT ABLE TO UPLOAD ", this);
			logger.error(e.getMessage());
		} catch (CometServiceException e) {
			logger.error("RESULTBO for IN OU INTERFACE IS NULL , SO NOT ABLE TO UPLOAD ", this);
			logger.error(e.getMessage());
		}
		logger.info("Exsiting ManageInventoryUploadAction.parseUploadInOutInterface()",this);
		return resultBO;
	}

	public ParseResultBO parseCsvFile(MultipartFile file) throws CometDataException, CometServiceException {
		logger.info("Starting parseCsvFile",this);
		ParseResultBO parseResultBO = new ParseResultBO();
		InputStream preProccessInputSteam = null;
		InputStream processingInputSteam = null;

		ManageInventoryTemplateBO manageInventoryTemplateBO = getUploadInventoryFileBO(file.getResource().getFilename());

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len;
			InputStream inputStream =file.getInputStream();
			while ((len = inputStream.read(buffer)) > -1 ) {
				baos.write(buffer, 0, len);
			}
			baos.flush();

			preProccessInputSteam = new ByteArrayInputStream(baos.toByteArray()); 
			processingInputSteam = new ByteArrayInputStream(baos.toByteArray()); 
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		preProcessingValidations(preProccessInputSteam, manageInventoryTemplateBO, parseResultBO);
		if (parseResultBO.getMessages() != null && parseResultBO.getMessages().size() == 0) {
			processFile(processingInputSteam, manageInventoryTemplateBO, parseResultBO);
		}
		logger.info("Existing parseCsvFile",this);
		return parseResultBO;
	}

	private void preProcessingValidations(InputStream is, ManageInventoryTemplateBO uploadFileBO, ParseResultBO resultBO) {
		logger.info("Starting preProcessingValidations",this);
		if (CommonUtils.isNotNullEmpty(uploadFileBO.getFileExt())) {
			if (!uploadFileBO.getFileExt().equalsIgnoreCase("csv")) {
				resultBO.getMessages().add(getErrorBO(0, "Issues with import file – Invalid file format", "ERROR", null));
			}
		} else {
			resultBO.getMessages().add(getErrorBO(0, "Issues with import file – Invalid file format", "ERROR", null));
		}
		if (is != null) {
			if (CommonUtils.isNotNullEmpty((String) uploadFileBO.getMasterConfigMap().get("FILE_HEADER"))) {
				try {
					String seperator = ",";
					if (CommonUtils.isNotNullEmpty((String) uploadFileBO.getMasterConfigMap().get("RECORD_SEPERATOR"))) {
						seperator = (String) uploadFileBO.getMasterConfigMap().get("RECORD_SEPERATOR");
					}
					BufferedReader reader = new BufferedReader(new InputStreamReader(is));
					String header = reader.readLine();
					reader.close();
					is.close();
					if (!header.replaceAll(seperator, "").trim().equals(uploadFileBO.getMasterConfigMap().get("FILE_HEADER"))) {

						resultBO.getMessages().add(getErrorBO(0, messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.version"), "ERROR", null));
					}
				} catch (IOException ioe) {

					resultBO.getMessages().add(getErrorBO(0, messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.problem.reading.file"), "ERROR", null));
				}
			}
		} else {

			resultBO.getMessages().add(getErrorBO(0,messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.empty.file"), "ERROR", null));
		}
		logger.info("Existing preProcessingValidations",this);
	}

	private void processFile(InputStream is, ManageInventoryTemplateBO manageInventoryTemplateBO, ParseResultBO resultBO) {
		logger.info("Start processFile");
		String templateName = "";
		if (CommonUtils.isNotNullEmpty((String) manageInventoryTemplateBO.getMasterConfigMap().get("TEMPLATE_NAME"))) {
			templateName = (String) manageInventoryTemplateBO.getMasterConfigMap().get("TEMPLATE_NAME");
		}
		// Reading CSV file logic
		if (CommonUtils.isNullEmpty(templateName)) {
			//resultBO.getMessages().add(getErrorBO(0, "Issues with PAT Channel import file – Processing Logic not defined for file", "ERROR", null));
			resultBO.getMessages().add(getErrorBO(0, messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.empty.file.processing"), "ERROR", null));
		} else {
			if (templateName.equals("INSIDE_OUTSIDE_PAT")) {
				processInOutPatFile(is, manageInventoryTemplateBO, resultBO);
			}else if (templateName.equals("DAPN")) {
				processDapnFile(is, manageInventoryTemplateBO, resultBO);
			}else if(templateName.equals("INSIDE_OUTSIDE_INTERFACE")){
				processInoutInterfaceFile(is, manageInventoryTemplateBO, resultBO);
			}else if(templateName.equals("IMSI_MSISDN")){
				processImsiMsisdnFile(is, manageInventoryTemplateBO, resultBO);
			}else{
				resultBO.getMessages().add(getErrorBO(0, "Issues with import file – template not support for file", "ERROR", null));
			}
		}
	}

	private void processInoutInterfaceFile(InputStream is, ManageInventoryTemplateBO inventoryTemplateBo, ParseResultBO resultBO) {
		logger.info("Start processInOutInterfaceFile");
		int skipHeader = 1;
		String line = "";
		String seperator = ",";
		Map<Integer, ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();
		BufferedReader reader = null;

		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"))) {
			try {
				skipHeader = Integer.parseInt((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR"))) {
			seperator = (String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR");
		}
		if (inventoryTemplateBo.getColumnInfo() != null) {
			columnInfo = inventoryTemplateBo.getColumnInfo();
		} else {
			resultBO.getMessages().add(getErrorBO(0, messageConfig.properties().getProperty("errors.inventory.upload.invalid.file.format.empty.file.inout.interface.column.notsupported"), "ERROR", null));
			return;
		}
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			int rowCount = 1;
			while ((line = reader.readLine()) != null) {
				if((rowCount > 500 + skipHeader) || line.substring(0, line.indexOf(seperator)).equals("EOR")){
					break;
				}
				boolean hasError = false;
				InOutInterfaceCSVLineBO lineBO = new InOutInterfaceCSVLineBO();
				if (rowCount > skipHeader) {
					String[] records = line.split(seperator, -1);
					for (int i = 0; i < records.length; i++) {
						if (columnInfo.get(i + 1) != null) {
							// Check if field is mandatory
							if (columnInfo.get(i + 1).isMandatory() && CommonUtils.isNullEmpty(records[i])) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " is required.",
												"ERROR", null));
								hasError = true;
							}

							// Check if record has valid input
							if (CommonUtils.isNotNullEmpty(records[i]) && !CommonUtils.checkValidInput(records[i], columnInfo.get(i + 1).getColumnType())) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " has invalid input.",
												"ERROR", null));
								hasError = true;
							}
							if (!hasError) {
								if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("ACTION")) {
									lineBO.setActionField(records[i]);
								}else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("DATA_CENTER")) {
									lineBO.setDataCenter(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("INSIDE_BASE")) {
									lineBO.setInsideBase(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("OUTSIDE_BASE")) {
									lineBO.setOutsideBase(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("GW_SGI_CONTEXT")) {
									lineBO.setGwSgiContext(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("RDRT")) {
									lineBO.setRdRt(records[i]);
								}
							}
						} else {
							resultBO.getMessages().add(getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + "has invalid input.", "ERROR", null));
						}
					}
					if (!hasError) {
						lineBO.setRecordNumber(rowCount - skipHeader);
						resultBO.getLines().add(lineBO);
					}
				}
				rowCount++;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
	}

	public void validateDapnFieldValues(List<LineBO> dapnBOList) throws DapnValidationException, CometDataException {
		for(int i = 0; i <dapnBOList.size();i++){
			DapnCSVLineBO dapnBO = (DapnCSVLineBO) dapnBOList.get(i); 
			String actionField = dapnBO.getActionField();
			validateActionField(actionField);
	
			if (actionField.equalsIgnoreCase("update")) {
				validateDapnId(dapnBO.getDapnId());
			}
			validateApnType(dapnBO.getApnType());
			validateApnSize(dapnBO.getApnSize());
			validateApnName(dapnBO.getApnName());
			validatePdpName(dapnBO.getPdpName());
			validateUdPDPId(dapnBO.getUdPDPId());
			validateMobileIP(dapnBO.getMobileIP());
			validateDataCenter(dapnBO.getDataCenter());
			validatePDNSAddress(dapnBO.getpDNSAddress());
			validateSDNSAddress(dapnBO.getsDNSAddress());
			validateDnsNotes(dapnBO.getDnsNotes());
			validateAmpInfo(dapnBO.getAmpInfo());
			if (actionField.equalsIgnoreCase("add")) {
				validateCreatedOn(dapnBO.getCreatedOn());
				validateCreatedBy(dapnBO.getCreatedBy());
			}
			validatePcrfInfo(dapnBO.getPcrf());
		}
	}

	
	private void validateActionField(String actionName) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(actionName)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "ACTION" });
		} else if (!(actionName.equalsIgnoreCase("add") || actionName.equalsIgnoreCase("update"))) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "ACTION" });
		}
	}
	
	private void validateDapnId(String dapnId) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(dapnId)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "DAPN_ID" });
		}
	}
	private void validateApnType(String apnType) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(apnType)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "APN_TYPE" });
		} else if (!(apnType.trim().equalsIgnoreCase("static") || apnType.trim().equalsIgnoreCase("dynamic"))) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "APN_TYPE" });
		}
	}
	
	private void validateApnSize(String apnSize) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(apnSize)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "APN_SIZE" });
		} else if (!(apnSize.equals("32") || apnSize.equals("64") || apnSize.equals("128") || apnSize.equals("256") || apnSize.equals("512"))) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "APN_SIZE" });
		}
	}
	
	private void validateApnName(String apnName) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(apnName)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "APN_NAME" });
		}
		if (CometValidationRegExp.checkMaxLength(apnName, "[a-zA-Z0-9\\.]", 30)) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "APN_NAME" });
		}
	}
	
	private void validatePdpName(String pdpName) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(pdpName)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "PDP_NAME" });
		}
		if (CometValidationRegExp.checkMaxLength(pdpName, "[a-zA-Z0-9]", 20)) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "PDP_NAME" });
		}
	}
	private void validateUdPDPId(String udpdpId) throws DapnValidationException {
		if (!CommonUtils.isNullEmpty(udpdpId)) {
			if (CometValidationRegExp.checkMaxLength(udpdpId, "[0-9]", 4)) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "UD_PDPID" });
			}
		}
	}

	private void validateMobileIP(String mobileIp) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(mobileIp)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "MOBILE_IP" });
		}

		if (CometValidationRegExp.checkMaxLength(mobileIp.substring(0, mobileIp.indexOf("/")), "[0-9\\.]", 15)) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "MOBILE_IP" });
		}
		if (CometValidationRegExp.checkMaxLength(mobileIp.substring(mobileIp.indexOf("/")+1), "[0-9]", 2)) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "MOBILE_IP" });
		}

		if (!CometValidationRegExp.validateDestinationIpAddress(mobileIp)) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "MOBILE_IP" });
		}
	}

	private void validateDataCenter(String dataCenter) throws DapnValidationException, CometDataException {
		if (CommonUtils.isNullEmpty(dataCenter)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "DATA_CENTER" });
		}
		DataCenter dc = dataCenterNameRepository.getDateCenterDetails(dataCenter);
		if(null==dc || (null== dc.getDataCenterId() || dc.getDataCenterId()==0.0)){
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "DATA_CENTER" });
		}
	}

	private void validatePDNSAddress(String pDnsAddress) throws DapnValidationException {
		if (!StringUtils.isNotEmpty(pDnsAddress)) {
			if (CometValidationRegExp.checkMaxLength(pDnsAddress, "[0-9\\.]", 15)) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "P_DNS_ADD" });
			}
			if (!CometValidationRegExp.validateIpAddressForEnterpriseIP(pDnsAddress)) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "P_DNS_ADD" });
			}
		}
	}

	private void validateSDNSAddress(String sDnsAddress) throws DapnValidationException {
		if (!CommonUtils.isNullEmpty(sDnsAddress)) {
			if (CometValidationRegExp.checkMaxLength(sDnsAddress, "[0-9\\.]", 15)) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "S_DNS_ADD" });
			}
			if (!CometValidationRegExp.validateIpAddressForEnterpriseIP(sDnsAddress)) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "S_DNS_ADD" });
			}
		}
	}

	private void validateDnsNotes(String dnsNotes) throws DapnValidationException {
		if (!CommonUtils.isNullEmpty(dnsNotes)) {
			if (dnsNotes.length() > 2500) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "DNS_NOTES" });
			}
		}
	}

	private void validateAmpInfo(String ampInfo) throws DapnValidationException {
		if (!CommonUtils.isNullEmpty(ampInfo)) {
			if (ampInfo.length() > 2500) {
				throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "AMP_INFO" });
			}
		}
	}

	private void validateCreatedOn(String createdOn) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(createdOn)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "CREATED_ON" });
		}
		//validation check for date
		try {
			CommonUtils.isValidDateString(createdOn,"MM/dd/yyyy");
		} catch (ParseException e) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "CREATED_ON" });
		}
	}

	private void validateCreatedBy(String createdBy) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(createdBy)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "CREATED_BY" });
		}
		if (createdBy.length() > 8) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "CREATED_BY" });
		}
	}

	private void validatePcrfInfo(String pcrf) throws DapnValidationException {
		if (CommonUtils.isNullEmpty(pcrf)) {
			throw new DapnValidationException(ConstantActionMessage.FIELD_REQUIRED, new Object[] { "PCRF" });
		}
		if (!(pcrf.equalsIgnoreCase("None") || pcrf.equalsIgnoreCase("Intranet") || pcrf.equalsIgnoreCase("Internet") || pcrf.equalsIgnoreCase("Not yet Provisioned"))) {
			throw new DapnValidationException(ConstantActionMessage.INVALID_INPUT_VALUE, new Object[] { "PCRF" });
		}
	}
	
	
	private void processInOutPatFile(InputStream is, ManageInventoryTemplateBO inventoryTemplateBo, ParseResultBO resultBO) {
		logger.info("Start processInOutPatFile");
		int skipHeader = 1;
		String line = "";
		String seperator = ",";
		Map<Integer, ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();
		BufferedReader reader = null;

		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"))) {
			try {
				skipHeader = Integer.parseInt((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR"))) {
			seperator = (String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR");
		}
		if (inventoryTemplateBo.getColumnInfo() != null) {
			columnInfo = inventoryTemplateBo.getColumnInfo();
		} else {
			//resultBO.getMessages().add(getErrorBO(0, "Issues with PAT Channel import file – Column information is not provided", "ERROR", null));
			resultBO.getMessages().add(getErrorBO(0, "Issues with PAT Channel import file – Column information is not provided", "ERROR", null));
			return;
		}
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			int rowCount = 1;
			while ((line = reader.readLine()) != null) {
				if((rowCount > 500 + skipHeader) || line.substring(0, line.indexOf(seperator)).equals("EOR")){
					break;
				}
				boolean hasError = false;
				InOutCSVLineBO lineBO = new InOutCSVLineBO();
				if (rowCount > skipHeader) {
					String[] records = line.split(seperator, -1);
					for (int i = 0; i < records.length; i++) {
						if (columnInfo.get(i + 1) != null) {
							// Check if field is mandatory
							if (columnInfo.get(i + 1).isMandatory() && CommonUtils.isNullEmpty(records[i])) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " is required.",
												"ERROR", null));
								hasError = true;
							}

							// Check if record has valid input
							if (CommonUtils.isNotNullEmpty(records[i]) && !CommonUtils.checkValidInput(records[i], columnInfo.get(i + 1).getColumnType())) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " has invalid input.",
												"ERROR", null));
								hasError = true;
							}
							if (!hasError) {
								if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("Data Center")) {
									lineBO.setDataCenterName(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("Inside PAT")) {
									lineBO.setInsidePat(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("Outside PAT")) {
									lineBO.setOutsidePat(records[i]);
								}
							}
						} else {
							resultBO.getMessages().add(getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + "has invalid input.", "ERROR", null));
						}
					}
					if (!hasError) {
						lineBO.setRecordNumber(rowCount - skipHeader);
						resultBO.getLines().add(lineBO);
					}
				}
				rowCount++;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
	}

	private void processDapnFile(InputStream is, ManageInventoryTemplateBO inventoryTemplateBo, ParseResultBO resultBO) {
		logger.info("Start processDapnFile");
		int skipHeader = 1;
		String line = "";
		String seperator = ",";
		Map<Integer, ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();
		BufferedReader reader = null;

		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"))) {
			try {
				skipHeader = Integer.parseInt((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR"))) {
			seperator = (String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR");
		}
		if (inventoryTemplateBo.getColumnInfo() != null) {
			columnInfo = inventoryTemplateBo.getColumnInfo();
		} else {
			resultBO.getMessages().add(getErrorBO(0, "Only First 500 records processed", "ERROR", null));
			return;
		}
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			int rowCount = 1;
			while ((line = reader.readLine()) != null) {
				if((rowCount > 500 + skipHeader)){
					resultBO.getMessages().add(getErrorBO(0, "Issues with dapn import file – Column information is not provided", "ERROR", null));
					break;
				}
				if(line.substring(0, line.indexOf(seperator)).equals("EOR")){
					break;
				}
				boolean hasError = false;
				DapnCSVLineBO lineBO = new DapnCSVLineBO();
				if (rowCount > skipHeader) {
					String[] records = line.split(seperator, -1);
					for (int i = 0; i < records.length; i++) {
						if (columnInfo.get(i + 1) != null) {
							// Check if field is mandatory
							if (columnInfo.get(i + 1).isMandatory() && CommonUtils.isNullEmpty(records[i])) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " is required.",
												"ERROR", null));
								hasError = true;
							}

							// Check if record has valid input
							if (CommonUtils.isNotNullEmpty(records[i]) && !CommonUtils.checkValidInput(records[i], columnInfo.get(i + 1).getColumnType())) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " has invalid input.",
												"ERROR", null));
								hasError = true;
							}
							if (!hasError) {
								if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("action")) {
									lineBO.setActionField(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("DAPN_ID")) {
									lineBO.setDapnId(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("APN_TYPE")) {
									lineBO.setApnType(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("APN_SIZE")) {
									lineBO.setApnSize(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("APN_NAME")) {
									lineBO.setApnName(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("PDP_NAME")) {
									lineBO.setPdpName(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("UD_PDPID")) {
									lineBO.setUdPDPId(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("MOBILE_IP")) {
									lineBO.setMobileIP(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("DATA_CENTER")) {
									lineBO.setDataCenter(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("P_DNS_ADD")) {
									lineBO.setpDNSAddress(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("S_DNS_ADD")) {
									lineBO.setsDNSAddress(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("DNS_NOTES")) {
									lineBO.setDnsNotes(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("AMP_INFO")) {
									lineBO.setAmpInfo(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("CREATED_ON")) {
									lineBO.setCreatedOn(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("CREATED_BY")) {
									lineBO.setCreatedBy(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("PCRF")) {
									lineBO.setPcrf(records[i]);
								}
							}
						} else {
							resultBO.getMessages().add(getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + "has invalid input.", "ERROR", null));
						}
					}
					if (!hasError) {
						lineBO.setRecordNumber(rowCount - skipHeader);
						resultBO.getLines().add(lineBO);
					}
				}
				rowCount++;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
	}

	private void processImsiMsisdnFile(InputStream is, ManageInventoryTemplateBO inventoryTemplateBo, ParseResultBO resultBO) {
		logger.info("Start processImsiMsisdnFile");
		int skipHeader = 1;
		String line = "";
		String seperator = ",";
		Map<Integer, ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();
		BufferedReader reader = null;

		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"))) {
			try {
				skipHeader = Integer.parseInt((String) inventoryTemplateBo.getMasterConfigMap().get("SKIP_HEADER"));
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		if (CommonUtils.isNotNullEmpty((String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR"))) {
			seperator = (String) inventoryTemplateBo.getMasterConfigMap().get("RECORD_SEPERATOR");
		}
		if (inventoryTemplateBo.getColumnInfo() != null) {
			columnInfo = inventoryTemplateBo.getColumnInfo();
		} else {
			resultBO.getMessages().add(getErrorBO(0, "Issues with IMSI/MSISDN import file – Column information is not provided", "ERROR", null));
			return;
		}
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			int rowCount = 1;
			while ((line = reader.readLine()) != null) {
				if((rowCount > 500 + skipHeader) || line.substring(0, line.indexOf(seperator)).equals("EOR")){
					break;
				}
				boolean hasError = false;
				ImsiMsisdnCSVLineBO lineBO = new ImsiMsisdnCSVLineBO();
				if (rowCount > skipHeader) {
					String[] records = line.split(seperator, -1);
					for (int i = 0; i < records.length; i++) {
						if (columnInfo.get(i + 1) != null) {
							// Check if field is mandatory
							if (columnInfo.get(i + 1).isMandatory() && CommonUtils.isNullEmpty(records[i])) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " is required.",
												"ERROR", null));
								hasError = true;
							}

							// Check if record has valid input
							if (CommonUtils.isNotNullEmpty(records[i]) && !CommonUtils.checkValidInput(records[i], columnInfo.get(i + 1).getColumnType())) {
								resultBO.getMessages().add(
										getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + columnInfo.get(i + 1).getColumnName() + " has invalid input.",
												"ERROR", null));
								hasError = true;
							}
							if (!hasError) {

								if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("ACTION")) {
									lineBO.setActionField(records[i]);
								}else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("DATA_CENTER")) {
									lineBO.setDataCenterName(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("IMSI")) {
									lineBO.setImsi(records[i]);
								} else if (columnInfo.get(i + 1).getColumnName().equalsIgnoreCase("MSISDN")) {
									lineBO.setMsisdn(records[i]);
								}

							}
						} else {
							resultBO.getMessages().add(getErrorBO((rowCount - skipHeader), "Record# " + (rowCount - skipHeader) + ": " + "has invalid input.", "ERROR", null));
						}
					}
					if (!hasError) {
						lineBO.setRecordNumber(rowCount - skipHeader);
						resultBO.getLines().add(lineBO);
					}
				}
				rowCount++;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
	}

	public MessageBO getErrorBO(int recordNumber, String errorMessage, String errorType, String errorCode) {
		MessageBO errorBO = new MessageBO();
		errorBO.setRecordNumber(recordNumber);
		errorBO.setMessage(errorMessage);
		errorBO.setMessageType(errorType);
		errorBO.setMessageCode(errorCode);
		return errorBO;
	}

	/**
	 * 
	 * @param errorMessage
	 * @param errorType
	 * @param errorCode
	 * @return
	 */
	public MessageBO getErrorBO(String errorMessage, String errorType,	String errorCode) {
		MessageBO errorBO = new MessageBO();
		errorBO.setMessage(errorMessage);
		errorBO.setMessageType(errorType);
		errorBO.setMessageCode(errorCode);
		return errorBO;
	}


	/**
	 * 
	 * @param fileName
	 * @return
	 */
	private ManageInventoryTemplateBO getUploadInventoryFileBO(String fileName) {
		logger.info("[FileName : "+(fileName == null ? "": fileName)+"]Start getUploadInventoryFileBO()");
		ManageInventoryTemplateBO manageInventoryTemplateBO = new ManageInventoryTemplateBO();
		if (fileName.contains("")) {
			manageInventoryTemplateBO.setFileName(fileName.substring(0,
					fileName.lastIndexOf(".") + 1));
			manageInventoryTemplateBO.setFileType("CSV");
			manageInventoryTemplateBO.setFileExt("csv");
			fileName=fileName.toUpperCase();
			if(fileName.contains("PAT") || fileName.contains("DAPN") || fileName.contains("INSIDE") ||fileName.contains("INOUT")|| fileName.contains("IMSI")){
				String fname = "";
				if(fileName.contains("PAT")){
					fname ="INSIDE_OUTSIDE_PAT"; 
				}
				if(fileName.contains("DAPN")){
					fname = "DAPN"; 
				}
				if(fileName.contains("INSIDE_OUTSIDE_INVENTORY")){
					fname = "OUTSIDE_INTERFACE";
				}
				if(fileName.contains("INOUT_INTERFACE_INVENTORY")) {
					fname = "INOUT_INTERFACE";
				}
				if(fileName.contains("IMSI")){
					fname = "IMSI_MSISDN"; 
				}
				manageInventoryTemplateBO = getInventoryTemplate(manageInventoryTemplateBO,fname);
			}
		}
		logger.info("[FileName : "+(fileName == null ? "": fileName)+"]Existing getUploadInventoryFileBO()");
		return manageInventoryTemplateBO;
	}


	/**
	 * This method fetches the column names for dapn template for inventory
	 */
	public ManageInventoryTemplateBO getInventoryTemplate(
			ManageInventoryTemplateBO uploadFileBO, String fileName) {

		logger.info("[FileName : "
				+ (uploadFileBO == null ? ""
						: uploadFileBO.getFileName() == null ? ""
								: uploadFileBO.getFileName()) + "] "
								+ "Updating order started.");
		Map<Integer, ColumnInfoBO> columnInfo = new HashMap<Integer, ColumnInfoBO>();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<InventoryTemplate> query = builder.createQuery(InventoryTemplate.class);
		Root root = query.from(InventoryTemplate.class);
		Predicate templateDetails = builder.equal(root.get("templateName"), fileName);
		query.where(builder.and(templateDetails));
		@SuppressWarnings("unchecked")
		List<InventoryTemplate> lstDapnTemplate = entityManager.createQuery(query.select(root)).getResultList();

		logger.info("lstDapnTemplate list details::"+lstDapnTemplate.size(),this);

		ColumnInfoBO columnBO = null;
		if (lstDapnTemplate != null && !lstDapnTemplate.isEmpty()) {
			for (InventoryTemplate rowWise : lstDapnTemplate) {
				columnBO = new ColumnInfoBO();
				columnBO.setColumnName(rowWise.getFieldName());
				columnBO.setColumnType(rowWise.getFieldDatatype());
				columnBO.setMandatory(Boolean.parseBoolean(rowWise
						.getMandatory()));
				String dapnRowNumber = (rowWise.getColumnNumber().toString());
				columnInfo.put(Integer.parseInt(dapnRowNumber), columnBO);

			}
		}
		uploadFileBO.setColumnInfo(columnInfo);

		Map<String, Object> masterConfigMap = new HashMap<String, Object>();
		if (fileName.equalsIgnoreCase("INSIDE_OUTSIDE_PAT")) {
			masterConfigMap.put("TEMPLATE_NAME", "INSIDE_OUTSIDE_PAT");
			masterConfigMap.put("SKIP_HEADER", "2");
			masterConfigMap.put("RECORD_SEPERATOR", ",");
			masterConfigMap
			.put("FILE_HEADER", "COMET-PAT-CHNL-IMP-TEMP-VER1.0");
		}
		if (fileName.equalsIgnoreCase("DAPN")) {
			masterConfigMap.put("TEMPLATE_NAME", "DAPN");
			masterConfigMap.put("SKIP_HEADER", "2");
			masterConfigMap.put("RECORD_SEPERATOR", ",");
			masterConfigMap
			.put("FILE_HEADER", "COMET-DAPN-INV-IMP-TEMP-VER1.0");
		}
		if (fileName.equalsIgnoreCase("INOUT_INTERFACE")) {
			masterConfigMap.put("TEMPLATE_NAME", "INSIDE_OUTSIDE_INTERFACE");
			masterConfigMap.put("SKIP_HEADER", "2");
			masterConfigMap.put("RECORD_SEPERATOR", ",");
			masterConfigMap.put("FILE_HEADER",
					"COMET-INSIDE-OUTSIDE-INV-VER1.0");
		}
		if (fileName.equalsIgnoreCase("IMSI_MSISDN")) {
			masterConfigMap.put("TEMPLATE_NAME", "IMSI_MSISDN");
			masterConfigMap.put("SKIP_HEADER", "2");
			masterConfigMap.put("RECORD_SEPERATOR", ",");
			masterConfigMap.put("FILE_HEADER", "COMET-IMSI-MSISDN-INV-VER1.0");
		}
		uploadFileBO.setMasterConfigMap(masterConfigMap);
		return uploadFileBO;
	}

	public StringBuilder checkUseOfTheCountryInComet(long countryId) {

		String sqlQuery1 = "select sum(usedcount) as count from (\r\n" + 
				"				select count(attuid) as usedcount\r\n" + 
				"				from  users u, country c\r\n" + 
				"				where u.country_id = c.country_id\r\n" + 
				"				and   c.country_id =" + countryId;
		String sqlQuery2 = " union all\r\n" + 
				"				select count(DISTINCT sa.bcid) as usedcount\r\n" + 
				"				from   sub_account sa, country c\r\n" + 
				"				where  c.country_id ="+countryId;
		String sqlQuery3 = " and (\r\n" + 
				"					sa.bl_country_id = c.country_id\r\n" + 
				"					or sa.hl_country_id = c.country_id\r\n" + 
				"					or sa.cl_country_id = c.country_id\r\n" + 
				"					or sa.mcc_country_id = c.country_id\r\n" + 
				"				)\r\n" + 
				"			)";

		StringBuilder query = new StringBuilder();
		query.append(sqlQuery1).append(sqlQuery2).append(sqlQuery3);
		return query;
	}

	public StringBuilder checkUseOfTheStateInComet(Long stateId) {
		logger.info("Starting method checkUseOfTheStateInComet");
		String sql_Query_One = CHECK_USE_OF_THE_STATE_IN_COMET + stateId;
		String sql_Query_Two = " union all\r\n" + 
				"				select count(DISTINCT sa.bcid) as usedcount\r\n" + 
				"				from sub_account sa, state s\r\n" + 
				"				where s.state_id ="+stateId;
		String sql_Query_Three = " and (\r\n" + 
				"					sa.bl_state_id = s.state_id\r\n" + 
				"					or sa.hl_state_id  = s.state_id\r\n" + 
				"					or sa.cl_state_id  = s.state_id\r\n" + 
				"					or sa.mcc_state_id = s.state_id\r\n" + 
				"				)\r\n" + 
				"			)";
		StringBuilder query = new StringBuilder();
		query.append(sql_Query_One).append(sql_Query_Two).append(sql_Query_Three);
		logger.info("Exiting method checkUseOfTheStateInComet");
		return query;
	}

	public StringBuilder checkUseOfTheCityInComet(Long cityId) {
		logger.info("Starting method checkUseOfTheCityInComet");
		String sql_Query_One = CHECK_USE_OF_THE_CITY_IN_COMET + cityId;
		String sql_Query_Two = " union all \r\n" + 
				"			select count(DISTINCT sa.bcid) as usedcount \r\n" + 
				"			from sub_account sa, city c\r\n" + 
				"			where c.city_id ="+cityId;
		String sql_Query_Three = " and (\r\n" + 
				"				sa.bl_city_id = c.city_id\r\n" + 
				"				or sa.hl_city_id  = c.city_id\r\n" + 
				"				or sa.cl_city_id  = c.city_id\r\n" + 
				"				or sa.mcc_city_id = c.city_id\r\n" + 
				"			)\r\n" + 
				"		)";
		StringBuilder query = new StringBuilder();
		query.append(sql_Query_One).append(sql_Query_Two).append(sql_Query_Three);
		logger.info("Exiting method checkUseOfTheCityInComet");
		return query;
	}
	
	/*
	 * This method create and return uploaded batch id
	 */
	public String createBatchId(String attuId) {
		StringBuilder batchId = new StringBuilder(attuId);
		DateFormat sdff = new SimpleDateFormat("MMddyyyy_hhmmss");
		String frmDateStr = sdff.format(new Date());
		batchId.append("_");
		batchId.append(frmDateStr);
		return batchId.toString();
	}
	
	/*
	 * This method convert DAPNUploadBO to DAPNInventory Entity
	 */
	public DapnInventory convertBOToEntityforInsert(DapnCSVLineBO dapnBO, String attuId, long status,String batchId) throws ParseException {
		DapnInventory dapnInventory = new DapnInventory();
		dapnInventory.setDapnId(dapnBO.getDapnId());
		dapnInventory.setAmpInfo(dapnBO.getAmpInfo());
		dapnInventory.setApnName(dapnBO.getApnName());
		dapnInventory.setApnSize(Long.parseLong(dapnBO.getApnSize()));
		dapnInventory.setApnType(dapnBO.getApnType());
		dapnInventory.setBatchId(batchId);
		dapnInventory.setpDNSAddress(dapnBO.getpDNSAddress());
		dapnInventory.setCreatedBy(dapnBO.getCreatedBy());
		dapnInventory.setCreatedOn(CommonUtils.stringToDate(dapnBO.getCreatedOn(), "MM/dd/yyyy"));
		dapnInventory.setPcrf(dapnBO.getPcrf());
		//getting data center id
		DataCenter dataCenter = dataCenterNameRepository.getDateCenterDetail(dapnBO.getDataCenter());
		dapnInventory.setDataCenter(dataCenter);
		dapnInventory.setDnsNotes(dapnBO.getDnsNotes());
		dapnInventory.setsDNSAddress(dapnBO.getsDNSAddress());
		dapnInventory.setPdpName(dapnBO.getPdpName());
		dapnInventory.setMobileIP(dapnBO.getMobileIP());
		dapnInventory.setsDNSAddress(dapnBO.getpDNSAddress());
		dapnInventory.setUdPDPId(Long.parseLong(dapnBO.getUdPDPId()));
		DapnStatus dapnStatus = new DapnStatus();
		dapnStatus.setDapnStatusId(status);
		dapnInventory.setDapnStatus(dapnStatus);
		dapnInventory.setNewDapn("Y");
		return dapnInventory;
	}
}
