package com.att.comet.common.exception;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Handler class to handle COMET application exception
 * 
 * @author pd6080
 *
 */

@ControllerAdvice
public class CometExceptionHandler extends ResponseEntityExceptionHandler {
	private String INCORRECT_REQUEST = "INCORRECT_REQUEST";
	// private String BAD_REQUEST = "BAD_REQUEST";
	
	@ExceptionHandler(UserRecordNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleUserNotFoundException(UserRecordNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.COMET_USER_NTF, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleNotFoundException(RecordNotFoundException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.COMET_ANNOUNCEMENT_NTF, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MissingHeaderInfoException.class)
	public final ResponseEntity<ErrorResponse> handleInvalidTraceIdException(MissingHeaderInfoException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.COMET_USER_NTF, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public final ResponseEntity<ErrorResponse> handleConstraintViolation(ConstraintViolationException ex,
			WebRequest request) {
		List<String> details = ex.getConstraintViolations().parallelStream().map(e -> e.getMessage())
				.collect(Collectors.toList());

		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.COMET_USER_NTF, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CometDataException.class)
	public final ResponseEntity<ErrorResponse> handleCometData(CometDataException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.COMET_INVALID_REQUEST, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(OrderBhDeletionException.class)
	public final ResponseEntity<ErrorResponse> handleOrderBhDeletion(OrderBhDeletionException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.BH_DELETE_STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant.BACKHAUL_EXCEPTION, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler(FileStorageException.class)
	public final ResponseEntity<ErrorResponse> handleFileStorageException(FileStorageException ex,WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant. FILE_NOT_UPLOAD, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DapnValidationException.class)
	public final ResponseEntity<ErrorResponse> handleDapnValidationException(DapnValidationException ex ,WebRequest request){
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(ErrorCodeConstant.STATUS_CODE, ErrorCodeConstant.FAILURE,
				ErrorCodeConstant. FILE_NOT_UPLOAD, new Date(), INCORRECT_REQUEST, details);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

}
