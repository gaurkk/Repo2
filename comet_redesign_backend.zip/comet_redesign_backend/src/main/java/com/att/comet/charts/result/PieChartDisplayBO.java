package com.att.comet.charts.result;

public class PieChartDisplayBO implements DisplayResultBO {

	private static final long serialVersionUID = -903851439994755000L;

}
