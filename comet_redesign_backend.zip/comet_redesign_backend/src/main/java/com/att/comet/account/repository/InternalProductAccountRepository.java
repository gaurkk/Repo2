package com.att.comet.account.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.InternalProductAccount;

@Repository
public interface InternalProductAccountRepository extends JpaRepository<InternalProductAccount, String> {
	
	List<InternalProductAccount> findByInternalProductAccountName(String internalProductAccountName);

}
