package com.att.comet.charts.modal;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.att.comet.common.modal.CometGenericBO;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class RestrictionBO extends CometGenericBO implements Serializable {

	private static final long serialVersionUID = -4439386295919109476L;

	private String key;
	private String value;
}
