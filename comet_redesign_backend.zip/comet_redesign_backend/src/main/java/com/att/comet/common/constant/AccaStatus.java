package com.att.comet.common.constant;

public enum AccaStatus {

	ACCA_ENABLE_INPROGRESS  	    (2001L, "ENABLE_INPROGRESS"),
	ACCA_ENABLE_COMPLETED 			(2002L, "ENABLE_COMPLETED"),
	ACCA_DISABLE_INPROGRESS  		(2003L, "DISABLE_INPROGRESS"),
	ACCA_DISABLE_COMPLETED 		    (2004L, "DISABLE_COMPLETED");
	
	/**
	 * 
	 * property variable id
	 */
	private final Long id;
	
	/**
	 * property variable name
	 */
	private final String name;

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	/**
	 * The method is used to get the name of the type of the order.
	 * @param id
	 * @return ACCA Status , if the id is not null otherwise null.
	 */
	public static AccaStatus getName(Long id) {
		if(id != null) {
			for(AccaStatus accaStatus : AccaStatus.values()) {
				if (accaStatus.getId().longValue() == id.longValue()) {
					return accaStatus;
				}
			}
		}
		return null;
	}
	
	/**
	 * Argument Constructor.
	 * @param id
	 * @param name
	 */
	private AccaStatus(Long id, String name) {
		this.id = id;
		this.name = name;
	}
}
