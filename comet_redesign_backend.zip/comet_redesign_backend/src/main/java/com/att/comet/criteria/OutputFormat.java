package com.att.comet.criteria;

//Enum for output format
public enum OutputFormat {
	GRID, PIE_CHART, BAR_CHART, STACKED_COLUMN_CHART, COLUMN_CHART, LINE_CHART;
}
