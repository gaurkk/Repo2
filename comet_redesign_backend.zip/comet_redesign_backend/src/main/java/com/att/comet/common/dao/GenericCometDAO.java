package com.att.comet.common.dao;

/**
 * Marker interface for comet DAO classes.
 */
public interface GenericCometDAO {

}
