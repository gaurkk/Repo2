package com.att.comet.dao.hibernate.bean;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderProcessHistory. Mapped to
 * BPM_ORDER_PROCESS_HISTORY in the database.
 */
@Entity
@Table(name = "BPM_ORDER_PROCESS_HISTORY")
public class BpmOrderProcessHistory implements java.io.Serializable {

	private static final long serialVersionUID = 5293134739994124933L;

	private BpmOrderProcessHistoryId id;

	/**
	 * No-argument constructor of the class
	 */
	public BpmOrderProcessHistory() {
	}

	/**
	 * Single argument constructor of the class.
	 * 
	 * @param id
	 */
	public BpmOrderProcessHistory(BpmOrderProcessHistoryId id) {
		this.id = id;
	}

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderProcessHistoryId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "processId", column = @Column(name = "PROCESS_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "bpmStatusId", column = @Column(name = "BPM_STATUS_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "processExecutedOn", column = @Column(name = "PROCESS_EXECUTED_ON", nullable = false)),
			@AttributeOverride(name = "userDecision", column = @Column(name = "USER_DECISION", length = 100)),
			@AttributeOverride(name = "userDecisionOn", column = @Column(name = "USER_DECISION_ON")),
			@AttributeOverride(name = "comments", column = @Column(name = "COMMENTS", length = 3500)),
			@AttributeOverride(name = "createdOn", column = @Column(name = "CREATED_ON", nullable = false)),
			@AttributeOverride(name = "updatedOn", column = @Column(name = "UPDATED_ON", nullable = false)) })
	public BpmOrderProcessHistoryId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderProcessHistoryId id) {
		this.id = id;
	}

}
