package com.att.comet.common.service;

import java.util.List;

import com.att.comet.common.modal.AccountClassBO;
import com.att.comet.common.modal.AdminConfigBO;
import com.att.comet.common.modal.ApnSelectionBO;
import com.att.comet.common.modal.BackhaulStatusBO;
import com.att.comet.common.modal.BackhaulTypeBO;
import com.att.comet.common.modal.DapnStatusBO;
import com.att.comet.common.modal.DataCenterBO;
import com.att.comet.common.modal.OrderStatusBO;
import com.att.comet.common.modal.OrderTypeBO;
import com.att.comet.common.modal.StaticYesOrNoBO;

public interface SearchStaticDataService extends GenericCometService{

	public List<AccountClassBO> getSearchAccountStaticDataList();

	public List<AdminConfigBO> getAccountTypeList();

	public List<BackhaulTypeBO> getBackhaulTypeList();

	public List<OrderStatusBO> getOrderStatusList();

	public List<DapnStatusBO> getDapnStatusList();

	public List<AdminConfigBO> getApnSizeTypeList();

	public List<String> getCompanyNameList();

	public List<String> getBatchIdList();

	public List<BackhaulStatusBO> getBackhaulInstanceStatus();

	public List<ApnSelectionBO> getApnSelection();

	public List<OrderTypeBO> getOrderType();

	public List<StaticYesOrNoBO> getStaticYesOrNo();

	public List<DataCenterBO> getDataCenterNameList();
	
	public List<String> getTunnelTypeList();

}
