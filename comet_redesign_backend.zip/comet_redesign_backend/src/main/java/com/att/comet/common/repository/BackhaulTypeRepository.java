package com.att.comet.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.att.comet.dao.hibernate.bean.BackhaulType;

@Repository
public interface BackhaulTypeRepository extends JpaRepository<BackhaulType,Long> {
	@Query("from BackhaulType ")
	List<BackhaulType> getBackhaulTypeList();
	
	List<BackhaulType> findByIsActive(String isActive);
}
