package com.att.comet.order.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.account.modal.OrderAccountBO;
import com.att.comet.charts.modal.UserInfoBO;
import com.att.comet.common.constant.CometCommonConstant;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.common.modal.KeyValueBO;
import com.att.comet.common.modal.StaticDataBO;
import com.att.comet.order.helper.UserHelper;
import com.att.comet.order.modal.EodTypeBO;
import com.att.comet.order.modal.PdpPackageBO;
import com.att.comet.order.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class OrderAccountController {
	Logger logger = LoggerFactory.getLogger(OrderAccountController.class);

	@Autowired
	OrderService orderService;

	@Autowired
	CometResponse<List<StaticDataBO>> cometResponse;
	
	@Autowired
	UserHelper userHelper;

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getEODType", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find EOD TYPE Static Data", notes = "Return all EOD Type")
	public CometResponse<List<StaticDataBO>> getEodTypeData() throws CometDataException {
		logger.info("Starting method getEodTypeData : ", this);
		List<StaticDataBO> accClass = new ArrayList<StaticDataBO>();

		List<EodTypeBO> eodType = orderService.getEodType();
		if (!CollectionUtils.isEmpty(eodType)) {
			List<KeyValueBO> keyValueList = eodType.stream()
					.map(bo -> new KeyValueBO(bo.getEodType(), bo.getEodTypeYesorNo())).collect(Collectors.toList());
			accClass.add(new StaticDataBO(CometCommonConstant.EOD_TYPE_YES_NO, keyValueList));
		} else {
			logger.error("EODTypeYesorNoOrder is not set ", this);
		}
		if (!CollectionUtils.isEmpty(accClass)) {
			cometResponse.setMethodReturnValue(accClass);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} else {
			logger.error("accClass is not set ", this);
			cometResponse.setMethodReturnValue(accClass);
			cometResponse.setStatusCode(Status.SYSTEM_ERROR.getCode());
			cometResponse.setStatus(Status.SYSTEM_ERROR);
		}
		logger.info("Exiting method getEodTypeData : ", this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getPdpPackageInfo/{bcid}/{cipn}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get BackHaul tab information", notes = "Get BackHaul tab information")
	public CometResponse<List<PdpPackageBO>> getPdpPackageInfo(@PathVariable String cipn, @PathVariable String bcid)
			throws CometDataException, CometServiceException {
		logger.info("[PdpPackageId : " + (cipn == null ? "" : cipn + "" + bcid == null ? "" : bcid) + "] "
				+ " Starting method getPdpPackageInfo", this);

		CometResponse<List<PdpPackageBO>> cometResponse = new CometResponse<List<PdpPackageBO>>();
		List<PdpPackageBO> orderBackhaulBO = null;
		try {
			orderBackhaulBO = orderService.getPdpPackageInfo(bcid, cipn);
			if (null != orderBackhaulBO) {
				cometResponse.setMethodReturnValue(orderBackhaulBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				logger.error("PdpPackageBO is having null value for bcid and cipn:: [" + bcid + " " + cipn + "]", this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While getting PDP PAckage Info :"+e.getMessage(), e);
		}
		logger.info("[PdpPackageId : " + (cipn == null ? "" : cipn + "" + bcid == null ? "" : bcid) + "] "
				+ " Exiting method getPdpPackageInfo", this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getPdpPackageInfo/{packageID}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Get BackHaul tab information", notes = "Get BackHaul tab information")
	public CometResponse<PdpPackageBO> getPdpPackageInfoByPackageId(@PathVariable Long packageID)
			throws CometDataException, CometServiceException {
		logger.info("[PdpPackageId : " + (packageID == null ? "" : packageID) + "] Starting method getPdpPackageInfoByPackageId", this);

		CometResponse<PdpPackageBO> cometResponse = new CometResponse<PdpPackageBO>();
		PdpPackageBO pdpPackageBO = null;
		try {
			pdpPackageBO = orderService.getPdpPackageInfoByPackageID(packageID);
			if (null != pdpPackageBO) {
				cometResponse.setMethodReturnValue(pdpPackageBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				logger.error("PdpPackageBO is having null value for packageID: [" + packageID + "]", this);
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While getting PDP PAckage Info by Pckg Id :"+e.getMessage(), e);
		}
		logger.info("[PdpPackageId : " + (packageID == null ? "" : packageID ) + "] "
				+ " Exiting method getPdpPackageInfoByPackageId", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/createPdpInformation", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add BH Instance", notes = "Return BH Instance")
	public CometResponse<PdpPackageBO> createPdpInformation(@RequestBody PdpPackageBO pdpPackageBO)
			throws CometDataException, CometServiceException {
		logger.info("[PdpPackageId : " + (pdpPackageBO == null ? "" : pdpPackageBO.getPdpPackageId()) + "] "
				+ " Starting method createPdpInformation", this);
		CometResponse<PdpPackageBO> cometResponse = new CometResponse<PdpPackageBO>();
		PdpPackageBO pdBO = null;
		try {
			pdBO = orderService.createPdpInformation(pdpPackageBO);
			if (null != pdBO) {
				cometResponse.setMethodReturnValue(pdBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While Creating PDP Information :"+e.getMessage(), e);
		}
		logger.info("[PdpPackageId : " + (pdpPackageBO == null ? "" : pdpPackageBO.getPdpPackageId()) + "] "
				+ " Exiting method createPdpInformation", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@PutMapping(value = "order/updatePdpInformation", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Add BH Instance", notes = "Return BH Instance")
	public CometResponse<PdpPackageBO> updatePdpInformation(@RequestBody PdpPackageBO pdpPackageBO)
			throws CometDataException, CometServiceException {
		logger.info("[PdpPackageId : " + (pdpPackageBO == null ? "" : pdpPackageBO.getPdpPackageId()) + "] "
				+ " Starting method updatePdpInformation", this);
		CometResponse<PdpPackageBO> cometResponse = new CometResponse<PdpPackageBO>();
		PdpPackageBO pdBO = null;
		try {
			pdBO = orderService.updatePdpInformation(pdpPackageBO);
			if (null != pdBO) {
				cometResponse.setMethodReturnValue(pdBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While Updating PDP Information :"+e.getMessage(), e);
		}
		logger.info("[PdpPackageId : " + (pdpPackageBO == null ? "" : pdpPackageBO.getPdpPackageId()) + "] "
				+ " Exiting method updatePdpInformation", this);
		return cometResponse;
	}

	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_ORDER_MANAGER", "ROLE_CCS_PM", "ROLE_COMET_ADMIN"})
	@PostMapping(value = "order/orderAccount", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Save order account details by order id   ", notes = "Return order account details by order id")
	public CometResponse<OrderAccountBO> saveOrderAccount(@RequestBody OrderAccountBO orderAccountBO, Authentication authentication) {
		logger.info("[OrderID : "
				+ (orderAccountBO == null ? "" : orderAccountBO.getOrderId() == null ? "" : orderAccountBO.getOrderId())
				+ "] " + "Starting method saveOrderAccount", this);

		OrderAccountBO orderAccount = null;
		CometResponse<OrderAccountBO> cometResponse = new CometResponse<OrderAccountBO>();
		UserInfoBO userInfoBO = userHelper.getUserInfo(authentication);
		orderAccountBO.setUpdatedBy(userInfoBO.getAttuid());
		orderAccountBO.setRoleId(userInfoBO.getRoleId());
		try {
			orderAccount = orderService.saveOrderAccount(orderAccountBO);
			if (null != orderAccount) {
				cometResponse.setMethodReturnValue(orderAccount);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			} else {
				cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
				cometResponse.setStatus(Status.BUSINESS_ERROR);
			}
		} catch (CometDataException | CometServiceException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While Saving Order Account :"+e.getMessage(), e);
		}
		logger.info("[OrderID : "
				+ (orderAccountBO == null ? "" : orderAccountBO.getOrderId() == null ? "" : orderAccountBO.getOrderId())
				+ "] " + "Exiting method saveOrderAccount", this);

		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "order/getAccountDetails/{orderId}", produces = {
			MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Find Account Details for unique Order Id   ", notes = "Return Account details for specific order id")
	public CometResponse<OrderAccountBO> getAccountDetailsByOrderId(@PathVariable Long orderId) {
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Starting method getAccountDetailsByOrderId ::", this);
		OrderAccountBO orderAccountBO = null;
		CometResponse<OrderAccountBO> cometResponse = new CometResponse<OrderAccountBO>();
		try {
			orderAccountBO = orderService.getAccountInfoDetails(orderId);
				cometResponse.setMethodReturnValue(orderAccountBO);
				cometResponse.setStatusCode(Status.SUCCESS.getCode());
				cometResponse.setStatus(Status.SUCCESS);
			
		} catch (CometDataException | CometServiceException e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			logger.debug(" Error While Getting Account Details by Order Id :"+e.getMessage(), e);
		}
		logger.info("[OrderID : " + (orderId == null ? "" : orderId) + "] "
				+ "Exiting method getAccountDetailsByOrderId ::", this);

		return cometResponse;
	}

}
