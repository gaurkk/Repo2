package com.att.comet.audit.helper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;

import com.att.comet.apn.ApnCustomerRadiusBO;
import com.att.comet.apn.ApnRadiusBO;
import com.att.comet.apn.EnterpriseTargetIpRangeBO;
import com.att.comet.apn.InternetTargetIpRangeBO;
import com.att.comet.apn.MobilePoolAddressBO;
import com.att.comet.apn.PatPoolAddressBO;
import com.att.comet.apn.PdpIdInfoBO;
import com.att.comet.apn.PersistentIpBO;
import com.att.comet.audit.modal.ApnAuditBO;
import com.att.comet.audit.modal.RowData;
import com.att.comet.dao.ServiceUtils;
import com.att.comet.order.modal.DedicatedApnBO;
import com.att.comet.order.modal.DedicatedMobilePoolAddressBO;

import oracle.sql.TIMESTAMP;

@Component
public class ApnAuditHelper {
	/**
	 * Returns the details of the APN Auidt.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return ApnAuditBO
	 * @throws SQLException
	 */
	public ApnAuditBO getApnAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		ApnAuditBO apnBO = null;
		List<MobilePoolAddressBO> addressBOs = null;
		List<PatPoolAddressBO> patPooladdressBOs = null;
		List<ApnRadiusBO> apnRadiusBOs = null;
		List<EnterpriseTargetIpRangeBO> rangeBOs = null;
		List<PersistentIpBO> persistentIpBOs = null;
		List<PdpIdInfoBO> pdpIdInfoBOs = null;
		List<InternetTargetIpRangeBO> intTargetIpRangeBOs = null;
		
		List<RowData> apnResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(3));
		List<RowData> mobileRangeResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(4));
		List<RowData> patPoolAddressResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(5));
		List<RowData> persistentIpResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(6));
		List<RowData> pdpIdInfoResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(7));
		List<RowData> targetIpRangeResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(8));
		List<RowData> apnRadiusResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(9));
		List<RowData> apnCustRadiusResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(10));
		List<RowData> intTargetIpRangeResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(13));

		Object columnValue = null;
		if (apnResults != null && apnResults.size() > 0) {
			apnBO = new ApnAuditBO();
			for (RowData apnRow : apnResults) {
				Long apnOrderId = ((BigDecimal) apnRow.getColumnValue("ORDER_ID")).longValue();
				
				if (orderId.equals(apnOrderId)) {
					apnBO.setOrderId(apnOrderId);
					
					columnValue = apnRow.getColumnValue("apn_name");
					if (columnValue != null) {
						apnBO.setApnName((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("soc_feature_code");
					if (columnValue != null) {
						apnBO.setSocFeatureCode((String) columnValue);
					}

					columnValue = apnRow.getColumnValue("ip_address_source");
					if (columnValue != null) {
						apnBO.setIpAddressSource((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("address_type");
					if (columnValue != null) {
						apnBO.setAddressType((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("rad_acc_serv_enabled");
					if (columnValue != null) {
						apnBO.setRadAccServEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("unique_ip_address_size");
					if (columnValue != null) {
						apnBO.setUniqueIPAddressSize(((BigDecimal) columnValue).longValue());
					}
					
					columnValue = apnRow.getColumnValue("total_mobile_pool_size");
					if (columnValue != null) {
						apnBO.setTotalMobilePoolSize(((BigDecimal) columnValue).longValue());
					}
					
					columnValue = apnRow.getColumnValue("mobile_to_mobile_enabled");
					if (columnValue != null) {
						apnBO.setMobileToMobileEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("mobile_termination_enabled");
					if (columnValue != null) {
						apnBO.setMobileTerminationEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("split_tunnel_int_enabled");
					if (columnValue != null) {
						apnBO.setSplitTunnelIntEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("split_tunnel_mt_enabled");
					if (columnValue != null) {
						apnBO.setSplitTunnelMTEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("amplifying_information");
					if (columnValue != null) {
						apnBO.setAmplifyingInformation((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("prov_method");
					if (columnValue != null) {
						apnBO.setProvisioningMethod((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("fwd_rad_req_auth_enabled");
					if (columnValue != null) {
						apnBO.setFwdRadReqAuthEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("fwd_rad_req_msg_enabled");
					if (columnValue != null) {
						apnBO.setFwdRadReqMsgEnabled(((String) columnValue).toCharArray()[0]);
					}

					// added new field in APN
					columnValue = apnRow.getColumnValue("DNS_SERVER_IP");
					if (columnValue != null) {
						apnBO.setDnsServerIp((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("DOMAIN_NAME");
					if (columnValue != null) {
						apnBO.setDomainName((String) columnValue);
					}
					columnValue = apnRow.getColumnValue("MIGRATED_ORDER");
					if (columnValue != null) {
						apnBO.setMigratedOrder(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("OVERRIDE");
					if (columnValue != null) {
						apnBO.setOverRide(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("MOBILE_POOL_TYPE");
					if (columnValue != null) {
						apnBO.setMobilePoolType((String) columnValue);
					}

					columnValue = apnRow.getColumnValue("OVERRIDE_PDP");
					if (columnValue != null) {
						apnBO.setOverRidePdp(((String) columnValue).charAt(0));
					}

					columnValue = apnRow.getColumnValue("CCS_VRF_NAME");
					if (columnValue != null) {
						apnBO.setCcsVRFName((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("MANAGED_AVPN");
					if (columnValue != null) {
						apnBO.setManagedAvpn(((String) columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("IPBR");
					if (columnValue != null) {
						apnBO.setIpbr(((String) columnValue).charAt(0));
					}
				
					columnValue = apnRow.getColumnValue("PACL");
					if (columnValue != null) {
						apnBO.setPacl(((String) columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("OPTOUT_PACL");
					if (columnValue != null) {
						apnBO.setPaclEnabled(((String) columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("WHITELIST_BLACKLIST");
					if (columnValue != null) {
						apnBO.setWhitelistBlacklist((String) columnValue);
					}

					columnValue = apnRow.getColumnValue("MSP");
					if (columnValue != null) {
						apnBO.setMsp(((String) columnValue).charAt(0));
					}
	
					columnValue = apnRow.getColumnValue("MSP_ENTITLEMENT_AND_MMS");
					if (columnValue != null) {
						apnBO.setMspEntAndMms(((String) columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("PCRF");
					if (columnValue != null) {
						apnBO.setPcrf(columnValue.toString());
					}
					
					columnValue = apnRow.getColumnValue("SPLIT_ACC_PAT");
					if (columnValue != null) {
						apnBO.setSplitAccessPAT(((String)columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("GEO_OPTIMIZATION");
					if (columnValue != null) {
						apnBO.setGeoOptimization(((String)columnValue).charAt(0));
					}
					
					columnValue = apnRow.getColumnValue("INSIDE_OUTSIDE");
					if (columnValue != null) {
						apnBO.setInsideOusideStgPat((String)columnValue);
					}
					
					columnValue = apnRow.getColumnValue("CCIP_RADIUS");
					if (columnValue != null) {
						apnBO.setCcipRadius(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("FIRST_NET");
					if (columnValue != null) {
						apnBO.setFirstNet(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("TURBO_APP_SUPPORT");
					if (columnValue != null) {
						apnBO.setTurboAppSupport(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("DSCP_PRESERVATION");
					if (columnValue != null) {
						apnBO.setDscpPreservation(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("HOSTED_RADIUS_TYPE");
					if (columnValue != null) {
						apnBO.setHostedRadiusType(((String) columnValue));
					}
					
					columnValue = apnRow.getColumnValue("INTERIM_UPDATE_VALUE");
					if (columnValue != null) {
						apnBO.setInterimUpdateValue(((String)columnValue));
					}
					
					if (pdpIdInfoResults != null && pdpIdInfoResults.size() > 0) {
						pdpIdInfoBOs = new ArrayList<PdpIdInfoBO>();
						for (RowData pdpIdInfoRow : pdpIdInfoResults) {
							PdpIdInfoBO pdpIdInfoBO = new PdpIdInfoBO();
							Long ipOrderId = ((BigDecimal) pdpIdInfoRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(ipOrderId)) {
								pdpIdInfoBO.setOrderId(ipOrderId);
								
								columnValue = pdpIdInfoRow.getColumnValue("auto_pdp_id");
								if (columnValue != null) {
									pdpIdInfoBO.setAutoPdpId(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = pdpIdInfoRow.getColumnValue("user_pdp_id");
								if (columnValue != null) {
									pdpIdInfoBO.setUserPdpId(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = pdpIdInfoRow.getColumnValue("basic_pdp_id");
								if (columnValue != null) {
									pdpIdInfoBO.setBasicPdpId(((String) columnValue).charAt(0));
								}
								
								columnValue = pdpIdInfoRow.getColumnValue("auto_pdp_name");
								if (columnValue != null) {
									pdpIdInfoBO.setAutoPdpName(((String) columnValue));
								}

								pdpIdInfoBOs.add(pdpIdInfoBO);
							}
						}
						apnBO.setPdpIdInfoBOList(pdpIdInfoBOs);
					}

					if (persistentIpResults != null && persistentIpResults.size() > 0) {
						persistentIpBOs = new ArrayList<PersistentIpBO>();
						for (RowData persistentIpRow : persistentIpResults) {
							PersistentIpBO ipBO = new PersistentIpBO();
							Long ipOrderId = ((BigDecimal) persistentIpRow.getColumnValue("ORDER_ID")).longValue();
							
							if (orderId.equals(ipOrderId)) {
								ipBO.setOrderId(ipOrderId);
								columnValue = persistentIpRow.getColumnValue("ip_address");
								if (columnValue != null) {
									ipBO.setIpAddress((String) columnValue);
								}

								columnValue = persistentIpRow.getColumnValue("username");
								if (columnValue != null) {
									ipBO.setUsername((String) columnValue);
								}
								
								columnValue = persistentIpRow.getColumnValue("password");
								if (columnValue != null) {
									ipBO.setPassword((String) columnValue);
								}

								persistentIpBOs.add(ipBO);
							}
						}
						apnBO.setPersistentIps(persistentIpBOs);
					}

					if (apnRadiusResults != null && apnRadiusResults.size() > 0) {
						apnRadiusBOs = new ArrayList<ApnRadiusBO>();
						for (RowData apnRadiusRow : apnRadiusResults) {
							Long dcId = null;
							ApnRadiusBO radiusBO = new ApnRadiusBO();
							Long ipOrderId = ((BigDecimal) apnRadiusRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(ipOrderId)) {
								radiusBO.setOrderId(ipOrderId);
								
								columnValue = apnRadiusRow.getColumnValue("data_center_id");
								if (columnValue != null) {
									dcId = ((BigDecimal) columnValue).longValue();
									radiusBO.setDataCenterId(dcId);
								}
								
								columnValue = apnRadiusRow.getColumnValue("cust_rad_server");
								if (columnValue != null) {
									radiusBO.setCustRadServer(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = apnRadiusRow.getColumnValue("ras_client_ip");
								if (columnValue != null) {
									radiusBO.setRasClientIp((String) columnValue);
								}
								
								apnRadiusBOs.add(radiusBO);

								if (apnCustRadiusResults != null && apnCustRadiusResults.size() > 0) {
									Set<ApnCustomerRadiusBO> apnCustomerRadiusBOs = new HashSet<ApnCustomerRadiusBO>();
									radiusBO.setApnCustomerRadiuses(apnCustomerRadiusBOs);
									for (RowData apnCustRadiusRow : apnCustRadiusResults) {
										columnValue = apnCustRadiusRow.getColumnValue("data_center_id");
										Long custDcId = ((BigDecimal) columnValue).longValue();
										if (custDcId != null && dcId != null && custDcId.equals(dcId)) {
											ApnCustomerRadiusBO apnCustomerRadiusBO = new ApnCustomerRadiusBO();
											apnCustomerRadiusBO.setDataCenterId(custDcId);
											apnCustomerRadiusBO.setOrderId(ipOrderId);

											columnValue = apnCustRadiusRow.getColumnValue("customer_rad_ip_address");
											if (columnValue != null) {
												apnCustomerRadiusBO.setCustomerRadIpAddress((String) columnValue);
											}

											columnValue = apnCustRadiusRow.getColumnValue("customer_rad_name");
											if (columnValue != null) {
												apnCustomerRadiusBO.setCustomerRadName((String) columnValue);
											}
														
											columnValue = apnCustRadiusRow.getColumnValue("customer_rad_shared_secret");
											if (columnValue != null) {
												apnCustomerRadiusBO.setCustomerRadSharedSecret((String) columnValue);
											}
											
											apnCustomerRadiusBOs.add(apnCustomerRadiusBO);
										}
									}
								}
							}
						}
						apnBO.setApnRadiuses(apnRadiusBOs);
					}

					if (mobileRangeResults != null && mobileRangeResults.size() > 0) {
						addressBOs = new ArrayList<MobilePoolAddressBO>();
						for (RowData addressRow : mobileRangeResults) {
							MobilePoolAddressBO addressBO = new MobilePoolAddressBO();
							Long ipOrderId = ((BigDecimal) addressRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(ipOrderId)) {
								addressBO.setOrderId(ipOrderId);
								columnValue = addressRow.getColumnValue("data_center_id");
								if (columnValue != null) {
									addressBO.setDataCenterId(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = addressRow.getColumnValue("ip_address");
								if (columnValue != null) {
									addressBO.setIpAddress((String) columnValue);
								}
								
								columnValue = addressRow.getColumnValue("seq");
								if (columnValue != null) {
									addressBO.setSeq(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = addressRow.getColumnValue("ip_address_type");
								if (columnValue != null) {
									addressBO.setIpAddressType(((String) columnValue));
								}

								addressBOs.add(addressBO);
							}
						}
						apnBO.setMobilePoolAddressesList(addressBOs);
					}
					// fetching Pat pool address
					if (patPoolAddressResults != null && patPoolAddressResults.size() > 0) {
						patPooladdressBOs = new ArrayList<PatPoolAddressBO>();
						for (RowData addressRow : patPoolAddressResults) {
							PatPoolAddressBO patPooladdressBO = new PatPoolAddressBO();
							Long ipOrderId = ((BigDecimal) addressRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(ipOrderId)) {
								patPooladdressBO.setOrderId(ipOrderId);
								columnValue = addressRow.getColumnValue("data_center_id");
								if (columnValue != null) {
									patPooladdressBO.setDataCenterId(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = addressRow.getColumnValue("ip_address");
								if (columnValue != null) {
									patPooladdressBO.setIpAddress((String) columnValue);
								}
								
								columnValue = addressRow.getColumnValue("seq");
								if (columnValue != null) {
									patPooladdressBO.setSeq(((BigDecimal) columnValue).longValue());
								}

								patPooladdressBOs.add(patPooladdressBO);
							}
						}
						apnBO.setPatPoolAddresses((patPooladdressBOs));
					}

					if (targetIpRangeResults != null && targetIpRangeResults.size() > 0) {
						rangeBOs = new ArrayList<EnterpriseTargetIpRangeBO>();
						for (RowData rangeRow : targetIpRangeResults) {
							EnterpriseTargetIpRangeBO rangeBO = new EnterpriseTargetIpRangeBO();
							Long ipOrderId = ((BigDecimal) rangeRow.getColumnValue("ORDER_ID")).longValue();
							if (orderId.equals(ipOrderId)) {
								rangeBO.setOrderId(ipOrderId);
								columnValue = rangeRow.getColumnValue("ent_target_ip_range");
								if (columnValue != null) {
									rangeBO.setEntTargetIpRange((String) columnValue);
								}
							
								columnValue = rangeRow.getColumnValue("ENT_TARGET_IP_RANGE_TYPE");
								if (columnValue != null) {
									rangeBO.setEntTargetIpRangeType((String) columnValue);
								}
								
								columnValue = rangeRow.getColumnValue("APN_PROTOCOL");
								if (columnValue != null) {
									rangeBO.setApnProtocol((String) columnValue);
								}
								rangeBOs.add(rangeBO);
							}
						}
						apnBO.setEntTargetIpRanges(rangeBOs);
					}
				}
				
				if (intTargetIpRangeResults != null && intTargetIpRangeResults.size() > 0) {
					intTargetIpRangeBOs = new ArrayList<InternetTargetIpRangeBO>();
					for (RowData rangeRow : intTargetIpRangeResults) {
						InternetTargetIpRangeBO rangeBO = new InternetTargetIpRangeBO();
						Long ipOrderId = ((BigDecimal) rangeRow.getColumnValue("ORDER_ID")).longValue();
						if (orderId.equals(ipOrderId)) {
							rangeBO.setOrderId(ipOrderId);
							columnValue = rangeRow.getColumnValue("INT_TARGET_IP_RANGE");
							if (columnValue != null) {
								rangeBO.setIntTargetIpRange((String) columnValue);
							}
							
							columnValue = rangeRow.getColumnValue("ENT_TARGET_IP_RANGE_TYPE");
							intTargetIpRangeBOs.add(rangeBO);
						}
					}
					apnBO.setIntTargetIpRanges(intTargetIpRangeBOs);
				}
			}
		}
		return apnBO;
	}
	
	/**
	 * Returns the Dedicated APN details.
	 * 
	 * @param orderId
	 * @param spQuery
	 * @return DedicatedApnBO
	 * @throws SQLException
	 */
	public DedicatedApnBO getDedicatedApnAuditInfo(Long orderId, StoredProcedureQuery spQuery) throws SQLException {
		DedicatedApnBO dedicatedApnBO = null;
		List<DedicatedMobilePoolAddressBO> addressBOs = null;

		List<RowData> apnResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(9));
		List<RowData> mobileRangeResults = ServiceUtils.getResultSetAsList((ResultSet) spQuery.getOutputParameterValue(10));

		Object columnValue = null;
		if (apnResults != null && apnResults.size() > 0) {
			dedicatedApnBO = new DedicatedApnBO();
			for (RowData apnRow : apnResults) {
				Long apnOrderId = ((BigDecimal) apnRow.getColumnValue("ORDER_ID")).longValue();
				String dedicatedApnId = ((String) apnRow.getColumnValue("apn_id"));
				if (orderId.equals(apnOrderId)) {
					dedicatedApnBO.setOrderId(apnOrderId);

					columnValue = apnRow.getColumnValue("apn_name");
					if (columnValue != null) {
						dedicatedApnBO.setApnName((String) columnValue);
					}
					
					// added new field
					columnValue = apnRow.getColumnValue("pdp_id");
					if (columnValue != null) {
						dedicatedApnBO.setPdpId((Long) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("inventory_status");
					if (columnValue != null) {
						dedicatedApnBO.setInventoryStatus((Long) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("created_by");
					if (columnValue != null) {
						dedicatedApnBO.setCreatedBy((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("created_on");
					if (columnValue != null) {
						TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
						dedicatedApnBO.setCreatedOn(oraTimestamp.timestampValue());
					}
					
					columnValue = apnRow.getColumnValue("updated_by");
					if (columnValue != null) {
						dedicatedApnBO.setUpdatedBy((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("updated_on");
					if (columnValue != null) {
						TIMESTAMP oraTimestamp = (TIMESTAMP) columnValue;
						dedicatedApnBO.setUpdatedOn(oraTimestamp.timestampValue());
					}
					
					columnValue = apnRow.getColumnValue("soc_feature_code");
					if (columnValue != null) {
						dedicatedApnBO.setSocFeatureCode((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("pdp_name");
					if (columnValue != null) {
						dedicatedApnBO.setPdpName((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("ip_address_source");
					if (columnValue != null) {
						dedicatedApnBO.setIpAddressSource((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("address_type");
					if (columnValue != null) {
						dedicatedApnBO.setAddressType((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("static_address_type");
					if (columnValue != null) {
						dedicatedApnBO.setStaticAddressType((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("unique_ip_address_size");
					if (columnValue != null) {
						dedicatedApnBO.setUniqueIpAddressSize(((BigDecimal) columnValue).longValue());
					}
					
					columnValue = apnRow.getColumnValue("total_mobile_pool_size");
					if (columnValue != null) {
						dedicatedApnBO.setTotalMobilePoolSize(((BigDecimal) columnValue).longValue());
					}
					
					columnValue = apnRow.getColumnValue("mobile_to_mobile_enabled");
					if (columnValue != null) {
						dedicatedApnBO.setMobileToMobileEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("mobile_termination_enabled");
					if (columnValue != null) {
						dedicatedApnBO.setMobileTerminationEnabled(((String) columnValue).toCharArray()[0]);
					}
					
					columnValue = apnRow.getColumnValue("pri_ent_dns_serv_add");
					if (columnValue != null) {
						dedicatedApnBO.setPriEntDnsServAdd((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("sec_ent_dns_serv_add");
					if (columnValue != null) {
						dedicatedApnBO.setSecEntDnsServAdd((String) columnValue);
					}
					
					columnValue = apnRow.getColumnValue("amplifying_information");
					if (columnValue != null) {
						dedicatedApnBO.setAmplifyingInformation((String) columnValue);
					}

					if (mobileRangeResults != null && mobileRangeResults.size() > 0) {
						addressBOs = new ArrayList<DedicatedMobilePoolAddressBO>();
						for (RowData addressRow : mobileRangeResults) {
							DedicatedMobilePoolAddressBO addressBO = new DedicatedMobilePoolAddressBO();
							String apnId = ((String) addressRow.getColumnValue("apn_id"));
							if (apnId.equals(dedicatedApnId)) {
								addressBO.setApnId(apnId);
								columnValue = addressRow.getColumnValue("data_center_id");
								if (columnValue != null) {
									addressBO.setDataCenter(((BigDecimal) columnValue).longValue());
								}
								
								columnValue = addressRow.getColumnValue("ip_address");
								if (columnValue != null) {
									addressBO.setIpAddress((String) columnValue);
								}
								
								columnValue = addressRow.getColumnValue("seq");
								if (columnValue != null) {
									addressBO.setSeq(((BigDecimal) columnValue).byteValue());
								}

								addressBOs.add(addressBO);
							}
						}
						dedicatedApnBO.setMobilePoolAddresses(addressBOs);
					}
				}
			}
		}
		return dedicatedApnBO;
	}	
}
