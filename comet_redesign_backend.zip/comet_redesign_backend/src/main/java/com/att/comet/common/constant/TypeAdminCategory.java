package com.att.comet.common.constant;

public class TypeAdminCategory {
	/**
	 * Admin category id for ACCESS_SERVICE_PROVIDER
	 */
	public static final Long ACCESS_SERVICE_PROVIDER = 1001L;

	/**
	 * Admin category id for ACCOUNT_TYPE
	 */
	public static final Long ACCOUNT_TYPE = 1002L;

	/**
	 * Admin category id for ATT_ASN
	 */
	public static final Long ATT_ASN = 1003L;

	/**
	 * Admin category id for IKE_CIPHER
	 */
	public static final Long IKE_CIPHER = 1004L;

	/**
	 * Admin category id for IKE_GROUP
	 */
	public static final Long IKE_GROUP = 1005L;

	/**
	 * Admin category id for IKE_HASH
	 */
	public static final Long IKE_HASH = 1006L;

	/**
	 * Admin category id for INTERNAL_SUPPORT_METHOD
	 */
	public static final Long INTERNAL_SUPPORT_METHOD = 1007L;

	/**
	 * Admin category id for IP_ADDRESS_SOURCE
	 */
	public static final Long IP_ADDRESS_SOURCE = 1008L;

	/**
	 * Admin category id for IPSEC_ESP_AUTH
	 */
	public static final Long IPSEC_ESP_AUTH = 1009L;

	/**
	 * Admin category id for IPSEC_ESP_TRANSFORM
	 */
	public static final Long IPSEC_ESP_TRANSFORM = 1010L;

	/**
	 * Admin category id for MARKET_SEGMENT
	 */
	public static final Long MARKET_SEGMENT = 1011L;

	/**
	 * Admin category id for PFS
	 */
	public static final Long PFS = 1012L;

	/**
	 * Admin category id for PROVISIONING_METHOD
	 */
	public static final Long PROVISIONING_METHOD = 1014L;

	/**
	 * Admin category id for TUNNEL_TYPE
	 */
	public static final Long TUNNEL_TYPE = 1016L;
    
	/**
	 * Admin category id for NPU_INTERFACE
	 */
	public static final Long NPU_INTERFACE = 1079L;
	
	/**
	 * Admin category id for CRD_DNS
	 */
	public static final Long CRD_DNS = 1017L;

	/**
	 * Admin category id for CRD_MOBILITY_VPN_ROUTERS
	 */
	public static final Long CRD_MOBILITY_VPN_ROUTERS = 1018L;

	/**
	 * Admin category id for CRD_DATA_CENTER
	 */
	public static final Long CRD_DATA_CENTER = 1019L;

	/**
	 * Admin category id for TEAM_MANAGER_PHONE
	 */
	public static final Long TEAM_MANAGER_PHONE = 1020L;

	/**
	 * Admin category id for TEAM_MANAGER_EMAIL
	 */
	public static final Long TEAM_MANAGER_EMAIL = 1021L;

	/**
	 * Admin category id for TEAM_MANAGER_NAME
	 */
	public static final Long TEAM_MANAGER_NAME = 1022L;

	/**
	 * Admin category id for AREA_MANAGER_NAME
	 */
	public static final Long AREA_MANAGER_NAME = 1023L;

	/**
	 * Admin category id for AREA_MANAGER_PHONE
	 */
	public static final Long AREA_MANAGER_PHONE = 1024L;

	/**
	 * Admin category id for AREA_MANAGER_EMAIL
	 */
	public static final Long AREA_MANAGER_EMAIL = 1025L;

	/**
	 * Admin category id for CRITICAL_ISSUE_MANAGER_NAME
	 */
	public static final Long CRITICAL_ISSUE_MANAGER_NAME = 1026L;

	/**
	 * Admin category id for CRITICAL_ISSUE_MANAGER_PHONE
	 */
	public static final Long CRITICAL_ISSUE_MANAGER_PHONE = 1027L;

	/**
	 * Admin category id for CRITICAL_ISSUE_MANAGER_EMAIL
	 */
	public static final Long CRITICAL_ISSUE_MANAGER_EMAIL = 1028L;

	/**
	 * Admin category id for DIRECTOR_NAME
	 */
	public static final Long DIRECTOR_NAME = 1029L;

	/**
	 * Admin category id for DIRECTOR_PHONE
	 */
	public static final Long DIRECTOR_PHONE = 1030L;

	/**
	 * Admin category id for DIRECTOR_EMAIL
	 */
	public static final Long DIRECTOR_EMAIL = 1031L;

	/**
	 * Admin category id for ISSUE_RESOLUTION_INTERNATIONAL
	 */
	public static final Long ISSUE_RESOLUTION_INTERNATIONAL = 1032L;

	/**
	 * Admin category id for ISSUE_RESOLUTION_WEB
	 */
	public static final Long ISSUE_RESOLUTION_WEB = 1033L;

	/**
	 * Admin category id for ISSUE_RESOLUTION_CHAT1
	 */
	public static final Long ISSUE_RESOLUTION_CHAT1 = 1034L;

	/**
	 * Admin category id for ISSUE_RESOLUTION_CHAT2
	 */
	public static final Long ISSUE_RESOLUTION_CHAT2 = 1035L;

	/**
	 * Admin category id for HOLIDAY
	 */
	public static final Long HOLIDAY = 1036L;

	/**
	 * Admin category id for CRD_DIRECTION_INDICATOR
	 */
	public static final Long CRD_DIRECTION_INDICATOR = 1037L;

	/**
	 * Admin category id for VPN_CONNECTIVITY_URL
	 */
	public static final Long VPN_CONNECTIVITY_URL = 1038L;

	/**
	 * Admin category id for DEDICATED_APN_SIZE
	 */
	public static final Long DEDICATED_APN_SIZE = 1039L;

	/**
	 * Admin category id for DEDICATED_APN_PREFERRED_STATIC_INVENTORY
	 */
	public static final Long DEDICATED_APN_PREFERRED_STATIC_INVENTORY = 1040L;

	/**
	 * Admin category id for DEDICATED_APN_PREFERRED_DYNAMIC_INVENTORY
	 */
	public static final Long DEDICATED_APN_PREFERRED_DYNAMIC_INVENTORY = 1041L;

	/* BUC ID : 1.1.017 */
	/**
	 * Admin category id for ROUTING_PROTOCOL
	 */
	public static final Long ROUTING_PROTOCOL = 1046L;
	
	/**
	 * Admin category id for ATT_VPN_END_POINTS
	 */
	public static final Long ATT_VPN_END_POINTS = 1049L;
	
	/**
	 * Admin category id for SLA_FOR_EMAIL_NOTIFICATIONS
	 */
	public static final Long SLA_FOR_EMAIL_NOTIFICATIONS = 1051L;
	
	/**
	 * Admin category id for MPLS_CIR
	 */
	public static final Long MPLS_CIR = 1052L;	
	
	/**
	 * WELCOME_ANNOUNCEMENTS
	 */
	public static final Long WELCOME_ANNOUNCEMENTS = 1053L;

	/**
	 * Admin Category id for REASON_TO_EXPEDITE
	 */
	public static final Long REASON_TO_EXPEDITE = 1056L;
	/**
	 * Admin Category id for MIN_EXPEDITE_PERIOD
	 */
	public static final Long MIN_EXPEDITE_PERIOD = 1057L;
	/**
	 * Admin Category id for NORMAL_EXPEDITE_PERIOD
	 */
	public static final Long NORMAL_EXPEDITE_PERIOD = 1058L;
	/**
	 * Admin Category id for REASONS_FOR_ON_HOLD
	 */
	public static final Long REASONS_FOR_ON_HOLD = 1059L;
	/**
	 * Admin Category id for USE_CATEGORY
	 */
	public static final Long USE_CATEGORY = 1060L;
	/**
	 * Admin Category id for PRIMARY_BACKUP_REMOTE
	 */
	public static final Long PRIMARY_BACKUP_REMOTE = 1061L;
	/**
	 * Admin Category id for USER_TYPE
	 */
	public static final Long USER_TYPE = 1062L;
	/**
	 * Admin Category id for DROPDOWN4
	 */
	public static final Long STATIONARY_MOBILE = 1063L;
	
	/**
	 * Admin Category id for PCRF
	 */
	public static final Long PCRF = 1064L;
	
	/**
	 * Admin Category id for LTE_SWEEP
	 */
	public static final Long LTE_SWEEP = 1065L;
	
	/**
	 * Admin Category id for eiis create
	 */
	public static final Long EIIS_CREATE = 1066L;
	
	public static final Long EIIS_GETSTATUS = 1067L;
	
	public static final Long EIIS_ACCA_GETSTATUS = 1098L;
	
	public static final Long EIIS_CANCEL = 1068L;
	
	public static final Long EIIS_GETDETAILS = 1069L;
	
	public static final Long EIIS_ACCA_GETDETAILS = 1097L;
	
	public static final Long AMP_MAINTENANCE_WINDOW = 1072L;
	/**
	 * 
	 */
	public static final Long PRIMARY_DNS_SERVER_ADDRESS = 1070L;
	/**
	 * Admin category id for SECONDARY_DNS_SERVER_ADDRESS
	 */
	public static final Long SECONDARY_DNS_SERVER_ADDRESS = 1071L;
	
	//Added For Req#5.2.07 by sp3599
	public static final Long USER_ORDER_WORKING_TIME=1074L;
	
	/**
	 * Admin Category id for INTERIM_UPDATE_VALUE
	 */
	public static final Long INTERIM_UPDATE_VALUE = 1075L;
	
	/**
	 * Admin category id for INSIDE_OUTSIDE_INTERFACE
	 */
	public static final Long INSIDE_OUTSIDE_INTERFACE = 1078L;
	
	/**
	 * Admin category id for IKE_GROUP
	 */
	public static final Long IKE_LIST = 1080L;
	
	/**
	 * Admin category id for DATA_CENTER_COUNT
	 */
	public static final Long DC_COUNT_LIST = 1095L;
	
	/**
	 * Admin category id for IPSECESP
	 */
	public static final Long IPSECESP_LIST = 1081L;
	
	/**
	 * Admin Category id for ENTERPRISE_TARGET_IP_RANGES_FIREWALL
	 */
	public static final Long ENTERPRISE_TARGET_IP_RANGES_FIREWALL = 1076L;
	
	/**
	 * Admin Category id for ENTERPRISE_TARGET_IP_RANGES_ROUTE
	 */
	public static final Long ENTERPRISE_TARGET_IP_RANGES_ROUTE = 1082L;
	
	public static final Long FIRST_NET = 1083L;
	/**
	 * Admin category id for INTERNET_PAT_SGI_CONTEXT_RDRT_FOR_DC
	 */
	public static final Long INTERNET_PAT_SGI_CONTEXT_RDRT_FOR_DC = 1085L;
	
	public static final Long EIIS_ACCA_CREATE = 1093L;
		
	public static final Long EIIS_ACCA_CANCEL = 1094L;
	
	public static final Long FIRSTNET_DATACENTERS_LINKING = 1100L;
	
	public static final Long PACL_PROTOCOL = 1102L;
	
	public static final Long PACL_TIME_TO_LIVE = 1103L;
	
	public static final Long PACL_PRE_BUILD_APPLICATION = 1104L;
}
