package com.att.comet.help.modal;

import java.util.Date;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class HelpContentBO extends CometGenericBO {
	private static final long serialVersionUID = 6824341067095820926L;

	private Long contentId;
	private String contentValue;
	private String content;
	private String attachmentName;
	private byte[] attachment;
	private Date updatedOn;
	private String updatedBy;
}
