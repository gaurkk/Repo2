package com.att.comet.help.service;

import java.io.BufferedReader;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialClob;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.dao.hibernate.bean.HelpContent;
import com.att.comet.help.modal.HelpContentBO;
import com.att.comet.help.repository.HelpContentRepository;

@Service
public class HelpServiceImpl implements HelpService {
	
	private static final Logger logger = LoggerFactory.getLogger(HelpServiceImpl.class);
	
	@Autowired
	HelpContentRepository helpContentRepository;
	
	@Transactional
	public Map<Long, String> prepareHelpContents() throws CometDataException {
		logger.debug("HelpServiceImpl::prepareHelpContents -- Start");
		Map<Long, String> helpContentsMap = new HashMap<Long, String>();
		
		try {
			List<String> helpContents = helpContentRepository.getContentIdsAndValues();
			if (null == helpContents || helpContents.isEmpty()) {
				logger.info("No help conents are defined in COMET database");
				return null;
			}
			
			for (String helpContent : helpContents) {
				String [] contents = helpContent.split(","); 
				helpContentsMap.put(Long.parseLong(contents[0]), contents[1]);
			}
		} catch (Exception e) {
			throw new CometDataException("No help contents found in COMET database");
		}
		
		logger.debug("HelpServiceImpl::prepareHelpContents -- End");
		return helpContentsMap;
	}

	@Transactional
	public HelpContentBO getHelpForId(Long contentId) throws CometDataException {
		if (CommonUtils.isNullEmpty(contentId)) {
			logger.debug("Invalid Help Content Id");
			return null;
		}
		
		logger.debug("HelpServiceImpl::getHelpForId -- Start");
		
		HelpContentBO helpContentBO = null;
		
		Optional<HelpContent> helpContent = helpContentRepository.findById(contentId);
		
		if(helpContent.isPresent()) {
			HelpContent content = helpContent.get();
			helpContentBO = this.populateHelpContentBO(content);
		} else {
			throw new CometDataException("Help content does not found in COMET database");
		}
		
		logger.debug("HelpServiceImpl::getHelpForId -- End");
		return helpContentBO;
	}
	
	@Transactional
	public Boolean updateHelp(HelpContentBO helpContentBO, MultipartFile file, boolean isAttachFileUpdated) 
							throws CometDataException {
		if (null == helpContentBO) {
			logger.debug("Invalid Help Content info");
			return null;
		}
		
		logger.debug("HelpServiceImpl::updateHelp -- Start");
		Boolean isUpdateSUccess = false;
		try{
			HelpContent helpContent = this.populateHelpContent(helpContentBO, file, isAttachFileUpdated);
		
			if (null != helpContent) {
				helpContentRepository.saveAndFlush(helpContent);
				isUpdateSUccess = true;
			}
		} catch (Exception e) {
				throw new CometDataException("Unable to store help information in COMET database");
		}
		
		logger.debug("HelpServiceImpl::updateHelp -- End");
		return isUpdateSUccess;
	}
	
	private HelpContentBO populateHelpContentBO(HelpContent helpContent) throws CometDataException {
		if (null == helpContent) {
			logger.info("Invalid help content");
			return null;
		}
		
		logger.info("HelpServiceImpl::populateHelpContentBO -- Start");
		HelpContentBO helpContentBO = new HelpContentBO(); 
		
		helpContentBO.setContentId(helpContent.getContentId());
		helpContentBO.setContentValue(helpContent.getContentValue());
		
		try {
			if (null != helpContent.getContent()) {
				BufferedReader br = new BufferedReader(helpContent.getContent().getCharacterStream()); 
				String content;
				String con = "";
				
				while((content = br.readLine()) != null) {
					con = con + " "+ content;
				} 
				
				helpContentBO.setContent(con);
			}
			
			if (null != helpContent.getAttachmentName()
					&& null != helpContent.getAttachment()) {
				helpContentBO.setAttachmentName(helpContent.getAttachmentName());
				int length = (int) helpContent.getAttachment().length();
				helpContentBO.setAttachment(helpContent.getAttachment().getBytes(1L, length));
				helpContent.getAttachment().free();
			}
		} catch (Exception e) {
			throw new CometDataException("Unable to convert DB data onto HelpContentBO");
		}
		
		helpContentBO.setUpdatedOn(helpContent.getUpdatedOn());
		helpContentBO.setUpdatedBy(helpContent.getUpdatedBy());
		
		logger.info("HelpServiceImpl::populateHelpContentBO -- End");
		return helpContentBO;
	}
	
	private HelpContent populateHelpContent(HelpContentBO helpContentBO, MultipartFile file, boolean isAttachFileUpdated) 
													throws CometDataException {
		if (null == helpContentBO) {
			logger.info("Invalid help content to save");
			return null;
		}
		
		logger.info("HelpServiceImpl::populateHelpContent -- Start");
		HelpContent helpContent = null;
		
		try {
			if (null == helpContentBO.getContentId()) {
				throw new CometDataException("No contentId found");
			}
			
			Optional<HelpContent> optHelpContent = helpContentRepository.findById(helpContentBO.getContentId());
			
			if(optHelpContent.isPresent()) {
				helpContent = optHelpContent.get();
				
				if (null != helpContentBO.getContent()) {
					helpContent.setContent(new SerialClob(helpContentBO.getContent().toCharArray()));
				} else {
					helpContent.setContent(null);
				}
				
				if (null != helpContentBO.getAttachmentName() 
						&& null != file) {
					helpContent.setAttachmentName(helpContentBO.getAttachmentName());
					helpContent.setAttachment(new SerialBlob(file.getBytes()));
				} else if (null == file && isAttachFileUpdated){
					helpContent.setAttachmentName(null);
					helpContent.setAttachment(null);
				}
				
				if (null != helpContentBO.getUpdatedBy()) {
					helpContent.setUpdatedOn(new Date());
					helpContent.setUpdatedBy(helpContentBO.getUpdatedBy());
				}
			} else {
				throw new CometDataException("No such record found in database for contentId = " + helpContentBO.getContentId());
			}
		} catch (Exception e) {
			throw new CometDataException("Invalid data to store in COMET database");
		}
		
		logger.info("HelpServiceImpl::populateHelpContent -- End");
		return helpContent;
	}
}
