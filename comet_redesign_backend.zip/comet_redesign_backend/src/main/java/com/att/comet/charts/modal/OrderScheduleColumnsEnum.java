package com.att.comet.charts.modal;

public enum OrderScheduleColumnsEnum {

	THE_DATE("THE_DATE", "string"), 
	ALL_COUNT("ALL_COUNT", "number"), 
	USER_COUNT("USER_COUNT", "number"),
	STYLE("STYLE", "string");

	private OrderScheduleColumnsEnum(String orderScheduleColumnName, String orderScheduleColumnType) {
		this.columnName = orderScheduleColumnName;
		this.columnType = orderScheduleColumnType;
	}

	private String columnName;
	private String columnType;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

}
