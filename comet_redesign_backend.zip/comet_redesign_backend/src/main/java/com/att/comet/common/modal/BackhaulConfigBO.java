package com.att.comet.common.modal;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;


/**
 * Business Object for back-haul configuration.
 * 
 */
@Getter
@Setter
public class BackhaulConfigBO extends CometGenericBO{

	private static final long serialVersionUID = -8248970105533242310L;
	private Long orderId;
	private String excpRequestApprover;
	private Date excpApproverDate;
	private String excpApprovalNumber;
	private String notes;
	private String iwosNotes;
	private String updatedBy;
	private Long roleId;
	//for APN in production date
	private Date apnInProductionDate;
	public String whiteListOfBlackList;
	public String iWOS;
}
