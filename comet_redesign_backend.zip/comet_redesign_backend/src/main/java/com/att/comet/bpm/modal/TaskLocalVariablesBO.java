package com.att.comet.bpm.modal;

import com.att.comet.common.modal.CometGenericBO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.google.gson.JsonObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonInclude(Include.NON_NULL)
public class TaskLocalVariablesBO extends CometGenericBO {
	private static final long serialVersionUID = 2712130974116443103L;

	String type;
	String value;
	JsonObject valueInfo;
	String id;
	String name;
	String processDefinitionKey;
	String processDefinitionId;
	String processInstanceId;
	String executionId;
	String activityInstanceId;
	String caseDefinitionKey;
	String caseDefinitionId;
	String caseInstanceId;
	String caseExecutionId;
	String taskId;
	String errorMessage;
	String tenantId;
	String state;
	String createTime;
	String removalTime;
	String rootProcessInstanceId;
}
