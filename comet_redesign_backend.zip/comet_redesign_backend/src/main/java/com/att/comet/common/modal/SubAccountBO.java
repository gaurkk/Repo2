package com.att.comet.common.modal;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SubAccountBO extends CometGenericBO{

	private static final long serialVersionUID = 6151068075829321513L;

	private String bcid;
	private String subAccountName;
	private String masterAccountName;
	private Long accountClass;
	private String federalTaxId;
	private Character tsp;
	private Character feeWaiverApproved;
	private String waiverNotes;
	private InputStream waiverAttachment;
	private String companyName;
	private String companyOwner;
	private String businessDescription;
	private String companyStreetAddress;
	private Long companyCountryCode;
	private Long companyState;
	private Long companyCity;
	private Long companyZip;
	private Long billingCountryCode;
	private String billingStreetAddress;
	private Long billingState;
	private Long billingCity;
	private Long billingZip;
	private String hqStreetAddress;
	private Long hqCountryCode;
	private Long hqState;
	private Long hqCity;
	private Long hqZip;
	private String companyMainContact;
	private Long companyContactState;
	private Long companyContactCity;
	private Long companyContactZip;
	private Long companyContactCountry;
	private String companyContactStateName;
	private String companyContactCityName;
	private String companyContactCountryName;
	private String accountType;
	private String ubcid;
	private String companyContactStreetAddress;
	private String companyContactDeskPhone;
	private String companyContactCellPhone;
	private String companyContactEmail;
	private String createdBy;
	private Date createdOn;
	private String updatedBy;
	private Date updatedOn;
	private String waiverAttachmentFilename;
	private Character derivedClFromHq;
	private Character derivedBlFromHq;
	private Character derivedBlFromCl;
	private Character derivedCciFromHq;

	private String companyContactDeskPhoneExtension;

	private List<String> companyNameList;
}
