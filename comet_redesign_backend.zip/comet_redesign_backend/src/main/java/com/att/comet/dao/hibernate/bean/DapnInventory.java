package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * Persistent class for D-APN Inventory. Mapped to DAPN_INVENTORY table in the database.
 */
@Entity
@Table(name = "DAPN_INVENTORY")
public class DapnInventory implements Serializable{

	private static final long serialVersionUID = -1079165097624148290L;
	
	
	private String dapnId;
	private String apnType;
	private Long apnSize;
	private String apnName;
	private String pdpName;
	private Long udPDPId;
	private String mobileIP;
	private DataCenter dataCenter;
	private String pDNSAddress;
	private String sDNSAddress;
	private String dnsNotes;
	private String ampInfo;
	private Date createdOn;
	private String createdBy;
	private Date updatedOn;
	private String updatedBy;
	private DapnStatus dapnStatus;
	private String batchId;
	private Long pdpId;
	private Orders orders;
	private String sourceOfIpAddress;
	private String dnsServerIp;
	private String bhiInstanceType;
	private Character mToM;
	private Character mT;
	//private String mT;
	private String id;
	private String pcrf;
	private String newDapn;
	
	@GenericGenerator(name = "generator", strategy = "sequence-identity", parameters = @Parameter(name = "sequence", value = "SEQ_DAPN_UPLOAD_ID"))
	@Id
	@Column(name = "ID", unique = true, nullable = false, scale = 0)
    @GeneratedValue(generator = "generator")
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@Column(name = "DAPN_ID" , length = 10)
	public String getDapnId() {
		return dapnId;
	}
	public void setDapnId(String dapnId) {
		this.dapnId = dapnId;
	}
	@Column(name = "APN_TYPE", nullable = false, length = 10)
	public String getApnType() {
		return apnType;
	}
	public void setApnType(String apnType) {
		this.apnType = apnType;
	}
	@Column(name = "APN_SIZE", nullable = false, length = 4)
	public Long getApnSize() {
		return apnSize;
	}
	public void setApnSize(Long apnSize) {
		this.apnSize = apnSize;
	}
	@Column(name = "APN_NAME", unique = true, nullable = false, length = 30)
	public String getApnName() {
		return apnName;
	}
	public void setApnName(String apnName) {
		this.apnName = apnName;
	}
	@Column(name = "PDP_NAME", unique = true, nullable = false, length = 20)
	public String getPdpName() {
		return pdpName;
	}
	public void setPdpName(String pdpName) {
		this.pdpName = pdpName;
	}
	@Column(name = "UD_PDPID", unique = true, nullable = true, length = 4)
	public Long getUdPDPId() {
		return udPDPId;
	}
	public void setUdPDPId(Long udPDPId) {
		this.udPDPId = udPDPId;
	}
	@Column(name = "MOBILE_IP", unique = true, nullable = false, length = 20)
	public String getMobileIP() {
		return mobileIP;
	}
	public void setMobileIP(String mobileIP) {
		this.mobileIP = mobileIP;
	}
	
	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DATA_CENTER_ID",nullable = true)
	public DataCenter getDataCenter() {
		return this.dataCenter;
	}

	/**
	 * @param dataCenter
	 * to dataCenter set.
	 */
	public void setDataCenter(DataCenter dataCenter) {
		this.dataCenter = dataCenter;
	}
	
	
	@Column(name = "P_DNS_ADD", nullable = true, length = 15)
	public String getpDNSAddress() {
		return pDNSAddress;
	}
	public void setpDNSAddress(String pDNSAddress) {
		this.pDNSAddress = pDNSAddress;
	}
	@Column(name = "S_DNS_ADD", nullable = true, length = 15)
	public String getsDNSAddress() {
		return sDNSAddress;
	}
	public void setsDNSAddress(String sDNSAddress) {
		this.sDNSAddress = sDNSAddress;
	}
	@Column(name = "DNS_NOTES", nullable = true, length = 2500)
	public String getDnsNotes() {
		return dnsNotes;
	}
	public void setDnsNotes(String dnsNotes) {
		this.dnsNotes = dnsNotes;
	}
	@Column(name = "AMP_INFO", nullable = true, length = 2500)
	public String getAmpInfo() {
		return ampInfo;
	}
	public void setAmpInfo(String ampInfo) {
		this.ampInfo = ampInfo;
	}
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	@Column(name = "CREATED_BY", nullable = false)
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Column(name = "UPDATED_ON")
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Column(name = "BATCH_ID", nullable = false, length = 30)
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	@Column(name = "PDP_ID", nullable = true, length = 12)
	public Long getPdpId() {
		return pdpId;
	}
	public void setPdpId(Long pdpId) {
		this.pdpId = pdpId;
	}
	@Column(name = "SOURCE_OF_IP_ADDR", nullable = true, length = 50)
	public String getSourceOfIpAddress() {
		return sourceOfIpAddress;
	}
	public void setSourceOfIpAddress(String sourceOfIpAddress) {
		this.sourceOfIpAddress = sourceOfIpAddress;
	}
	@Column(name = "DNS_SERVER_IP", nullable = true, length = 30)
	public String getDnsServerIp() {
		return dnsServerIp;
	}
	public void setDnsServerIp(String dnsServerIp) {
		this.dnsServerIp = dnsServerIp;
	}
	@Column(name = "BHI_INSTANCE_TYPE", nullable = true, length = 30)
	public String getBhiInstanceType() {
		return bhiInstanceType;
	}
	public void setBhiInstanceType(String bhiInstanceType) {
		this.bhiInstanceType = bhiInstanceType;
	}
	@Column(name = "M2M", length = 1)
	public Character getmToM() {
		return mToM;
	}
	public void setmToM(Character mToM) {
		this.mToM = mToM;
	}
	@Column(name = "MT", length = 1)
	public Character getmT() {
		return mT;
	}
	public void setmT(Character mT) {
		this.mT = mT;
	}

	
	
	
	/**
	 * Getter method for orders. ORDER_ID mapped to ORDER_ID in the database
	 * table.
	 * 
	 * @return Orders
	 */
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ORDER_ID",nullable = true)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders
	 *            to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}
	
	/**
	 * Getter method for dataCenter.
	 * 
	 * @return DataCenter
	 */
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DAPN_STATUS_ID")
	public DapnStatus getDapnStatus() {
		return dapnStatus;
	}
	public void setDapnStatus(DapnStatus dapnStatus) {
		this.dapnStatus = dapnStatus;
	}
	
	@Column(name = "PCRF", nullable = true, length = 50)
	public String getPcrf() {
		return pcrf;
	}
	public void setPcrf(String pcrf) {
		this.pcrf = pcrf;
	}
	
	@Column(name = "NEW_DAPN", nullable = true, length = 50)
	public String getNewDapn() {
		return newDapn;
	}
	public void setNewDapn(String newDapn) {
		this.newDapn = newDapn;
	}
}
