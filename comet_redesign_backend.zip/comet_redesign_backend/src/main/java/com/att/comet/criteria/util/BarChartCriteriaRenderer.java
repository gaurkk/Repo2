package com.att.comet.criteria.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.exception.SQLGrammarException;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.comet.charts.modal.ChartNameEnum;
import com.att.comet.charts.modal.OrderAssignmentColumnsEnum;
import com.att.comet.charts.result.OrderAssignmentBarChartBO;
import com.att.comet.charts.result.ResultBO;
import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.util.CommonUtils;
import com.att.comet.criteria.SearchCriteria;
import com.att.comet.dao.ChartsSqlConstants;
import com.att.comet.dao.ScalarConstants;
import com.att.comet.restriction.Restriction;

@Component
public class BarChartCriteriaRenderer extends CriteriaRenderer {
	private static final Logger logger = LoggerFactory.getLogger(BarChartCriteriaRenderer.class);
	private static final String ORDER_ASSIGNMENT_COLUMN_NAME_KEY = "name";
	private static final String ORDER_ASSIGNMENT_COLUMN_TYPE_KEY = "type";

	@PersistenceContext
	EntityManager em;

	@Override
	public ResultBO createExecuteQuery(SearchCriteria criteria) {
		logger.info("Starting method createExecuteQuery : ", this);
		ResultBO result = null;
		StringBuilder sql = new StringBuilder();
		if (criteria.getRestrictions().size() > 0) {
			// Get Base query
			sql.append(ChartsSqlConstants.BASE_QUERY_FOR_BARCHART);
			if (CommonUtils.isNullEmpty(sql.toString()))
				return null;
			for (Restriction res : criteria.getRestrictions()) {
				if (CommonUtils.isNotNullEmpty(res.toSqlString())) {
					sql.append(res.toSqlString());
				}
			}
			if (criteria.getRestrictions().size() > 0) {
				sql.append(criteria.getRestrictions().get(0).getSortingGroupingQuery(criteria.getFormat()));
			}
			result = executeQuery(sql.toString(), criteria);
		}
		logger.info("Exiting method createExecuteQuery : ", this);
		return result;
	}

	/**
	 * Execute query for Bar Chart
	 * 
	 * @param sql
	 * @param criteria
	 * @return ResultBO
	 */
	@SuppressWarnings("deprecation")
	private ResultBO executeQuery(String sql, SearchCriteria criteria) {
		logger.info("Starting method executeQuery : ", this);
		ResultBO objBO = null;
		try {
			Query sqlQuery = em.createNativeQuery(sql.toString());
			sqlQuery.unwrap(NativeQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.USERID, StringType.INSTANCE);
			sqlQuery.unwrap(NativeQuery.class).addScalar(ScalarConstants.COUNT, IntegerType.INSTANCE);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = sqlQuery.getResultList();
			
			objBO = new ResultBO();

			if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString())) {
				objBO.getOtherBO().setTitle("OSD Orders Assignment");
			} else if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString())) {
				objBO.getOtherBO().setTitle("NI Orders Assignment");
			}

			OrderAssignmentBarChartBO barChartBO = new OrderAssignmentBarChartBO();

			List<Map<String, String>> colMapList = new ArrayList<Map<String, String>>();
			for (OrderAssignmentColumnsEnum columnEnum : OrderAssignmentColumnsEnum.values()) {
				HashMap<String, String> colMap = new HashMap<String, String>();
				colMap.put(ORDER_ASSIGNMENT_COLUMN_NAME_KEY, columnEnum.getColumnName());
				colMap.put(ORDER_ASSIGNMENT_COLUMN_TYPE_KEY, columnEnum.getColumnType());
				colMapList.add(colMap);
			}
			barChartBO.setLstColumns(colMapList);

			List<List<String>> rowList = new ArrayList<List<String>>();
			list.stream().forEach(mapsData -> {
				List<String> row = new ArrayList<>();
				mapsData.entrySet().forEach(mapData -> {
					row.add(mapData.getValue().toString());
				});
				if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.OSD_ORDERS_ASSIGNMENT.toString())) {
					row.add("color:#8064a2");
				} else if (criteria.getChartName().equalsIgnoreCase(ChartNameEnum.NI_ORDERS_ASSIGNMENT.toString())) {
					row.add("color:#4f81bd");
				}
				rowList.add(row);
			});

			barChartBO.setLstRows(rowList);

			objBO.setLstResult(barChartBO);
		} catch (SQLGrammarException e) {
			new CometServiceException("Invalid Criteria provided");
		} catch (Exception e) {
			new CometDataException("Error Fetching data");
		}
		logger.info("Exiting method executeQuery : ", this);
		return objBO;
	}

}
