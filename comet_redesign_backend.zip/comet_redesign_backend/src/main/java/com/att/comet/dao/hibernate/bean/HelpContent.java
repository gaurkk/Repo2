package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * Persistent class for HelpContent. Mapped to HELP_CONTENT table in the
 * database.
 */
@Entity
@Table(name = "HELP_CONTENT")
public class HelpContent implements Serializable {
	private static final long serialVersionUID = -4155350882021462368L;

	private Long contentId;
	private String contentValue;
	private Clob content;
	private String attachmentName;
	private Blob attachment;
	private Date updatedOn;
	private String updatedBy;

	/**
	 * Getter method for orderId. CONTENT_ID mapped to CONTENT_ID in the database
	 * table.
	 * 
	 * @return Long
	 */
	@Id
	@Column(name = "CONTENT_ID", unique = true, nullable = false, precision = 12, scale = 0)
	public Long getContentId() {
		return this.contentId;
	}

	/**
	 * @param contentId to contentId set.
	 */
	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}

	/**
	 * Getter method for contentValue. CONTENT_VALUE mapped to CONTENT_VALUE in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "CONTENT_VALUE", nullable = false, length = 64)
	public String getContentValue() {
		return this.contentValue;
	}

	/**
	 * @param contentValue to contentValue set.
	 */
	public void setContentValue(String contentValue) {
		this.contentValue = contentValue;
	}

	/**
	 * Getter method for content. HELP_CONTENT mapped to HELP_CONTENT in the
	 * database table.
	 * 
	 * @return Clob
	 */
	@Lob
	@Column(name = "HELP_CONTENT")
	public Clob getContent() {
		return this.content;
	}

	/**
	 * @param content to content set.
	 */
	public void setContent(Clob content) {
		this.content = content;
	}

	/**
	 * Getter method for attachmentName. ATTACHMENT_NAME mapped to ATTACHMENT_NAME
	 * in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ATTACHMENT_NAME", length = 200)
	public String getAttachmentName() {
		return this.attachmentName;
	}

	/**
	 * @param attachmentName to attachmentName set.
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	/**
	 * Getter method for attachment. ATTACHMENT mapped to ATTACHMENT in the database
	 * table.
	 * 
	 * @return Blob
	 */
	@Column(name = "ATTACHMENT")
	@Lob
	public Blob getAttachment() {
		return this.attachment;
	}

	/**
	 * @param attachment to attachment set.
	 */
	public void setAttachment(Blob attachment) {
		this.attachment = attachment;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for updatedBy. UPDATED_BY mapped to UPDATED_BY in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "UPDATED_BY", nullable = false, length = 6)
	public String getUpdatedBy() {
		return this.updatedBy;
	}

	/**
	 * @param updatedBy to updatedBy set.
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
}