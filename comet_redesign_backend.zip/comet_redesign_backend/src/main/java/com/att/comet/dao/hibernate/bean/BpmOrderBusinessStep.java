package com.att.comet.dao.hibernate.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Persistent class for BpmOrderBusinessStep. Mapped to BPM_ORDER_BUSINESS_STEP
 * in the database.
 */
@Entity
@Table(name = "BPM_ORDER_BUSINESS_STEP")
public class BpmOrderBusinessStep implements Serializable {

	private static final long serialVersionUID = 8385251642992022273L;

	private BpmOrderBusinessStepId id;
	private BpmBusinessStep bpmBusinessStep;
	private OrderType orderType;
	private Orders orders;
	private String businessStepStatus;
	private String businessStepValue;
	private Date businessStepExecutedOn;
	private String comments;
	private Date createdOn;
	private Date updatedOn;
	private String attuid;

	/**
	 * Getter method for id.
	 * 
	 * @return BpmOrderBusinessStepId
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "orderId", column = @Column(name = "ORDER_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "businessStepId", column = @Column(name = "BUSINESS_STEP_ID", nullable = false, precision = 12, scale = 0)),
			@AttributeOverride(name = "orderTypeId", column = @Column(name = "ORDER_TYPE_ID", nullable = false, precision = 12, scale = 0)) })
	public BpmOrderBusinessStepId getId() {
		return this.id;
	}

	/**
	 * @param id to id set.
	 */
	public void setId(BpmOrderBusinessStepId id) {
		this.id = id;
	}

	/**
	 * Getter method for bpmBusinessStep.
	 * 
	 * @return BpmBusinessStep
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BUSINESS_STEP_ID", nullable = false, insertable = false, updatable = false)
	public BpmBusinessStep getBpmBusinessStep() {
		return this.bpmBusinessStep;
	}

	/**
	 * @param bpmBusinessStep to bpmBusinessStep set.
	 */
	public void setBpmBusinessStep(BpmBusinessStep bpmBusinessStep) {
		this.bpmBusinessStep = bpmBusinessStep;
	}

	/**
	 * Getter method for orderType
	 * 
	 * @return OrderType
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_TYPE_ID", nullable = false, insertable = false, updatable = false)
	public OrderType getOrderType() {
		return this.orderType;
	}

	/**
	 * @param orderType to orderType set.
	 */
	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}

	/**
	 * Getter method for orders.
	 * 
	 * @return Orders
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", nullable = false, insertable = false, updatable = false)
	public Orders getOrders() {
		return this.orders;
	}

	/**
	 * @param orders to orders set.
	 */
	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	/**
	 * Getter method for businessStepStatus. BUSINESS_STEP_STATUS mapped to
	 * BUSINESS_STEP_STATUS in the database table.
	 * 
	 * @return String.
	 */
	@Column(name = "BUSINESS_STEP_STATUS", length = 100)
	public String getBusinessStepStatus() {
		return this.businessStepStatus;
	}

	/**
	 * @param businessStepStatus to businessStepStatus set.
	 */
	public void setBusinessStepStatus(String businessStepStatus) {
		this.businessStepStatus = businessStepStatus;
	}

	/**
	 * Getter method for businessStepValue. BUSINESS_STEP_VALUE mapped to
	 * BUSINESS_STEP_VALUE in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "BUSINESS_STEP_VALUE", length = 500)
	public String getBusinessStepValue() {
		return this.businessStepValue;
	}

	/**
	 * @param businessStepValue to businessStepValue set.
	 */
	public void setBusinessStepValue(String businessStepValue) {
		this.businessStepValue = businessStepValue;
	}

	/**
	 * Getter method for businessStepExecutedOn. BUSINESS_STEP_EXECUTED_ON mapped to
	 * BUSINESS_STEP_EXECUTED_ON in the database table.
	 * 
	 * @return Date
	 */
	@Column(name = "BUSINESS_STEP_EXECUTED_ON")
	public Date getBusinessStepExecutedOn() {
		return this.businessStepExecutedOn;
	}

	/**
	 * @param businessStepExecutedOn to businessStepExecutedOn set.
	 */
	public void setBusinessStepExecutedOn(Date businessStepExecutedOn) {
		this.businessStepExecutedOn = businessStepExecutedOn;
	}

	/**
	 * Getter method for comments. COMMENTS mapped to COMMENTS in the database
	 * table.
	 * 
	 * @return String
	 */
	@Column(name = "COMMENTS", length = 3500)
	public String getComments() {
		return this.comments;
	}

	/**
	 * @param comments to comments set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * Getter method for createdOn. CREATED_ON mapped to CREATED_ON in the database
	 * table.
	 * 
	 * @return Date.
	 */
	@Column(name = "CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	/**
	 * @param createdOn to createdOn set.
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * Getter method for updatedOn. UPDATED_ON mapped to UPDATED_ON in the database
	 * table.
	 * 
	 * @return Date.
	 */
	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	/**
	 * @param updatedOn to updatedOn set.
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * Getter method for attuid. ATTUID mapped to ATTUID in the database table.
	 * 
	 * @return String
	 */
	@Column(name = "ATTUID")
	public String getAttuid() {
		return attuid;
	}

	/**
	 * @param attuid to attuid set.
	 */
	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}
}