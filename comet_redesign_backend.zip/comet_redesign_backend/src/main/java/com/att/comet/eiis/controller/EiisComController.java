package com.att.comet.eiis.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.att.comet.common.exception.CometDataException;
import com.att.comet.common.exception.CometServiceException;
import com.att.comet.common.modal.CometResponse;
import com.att.comet.common.modal.CometResponse.Status;
import com.att.comet.eiis.modal.AmpResponseBO;
import com.att.comet.eiis.service.EiisComService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
public class EiisComController {

	Logger logger = LoggerFactory.getLogger(EiisComController.class);

	@Autowired
	EiisComService eiisComService;

	@Secured({"ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@GetMapping(value = "/createrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Create AMP Request", notes = "Create AMP Request")
	public CometResponse<AmpResponseBO> create(@PathVariable Long orderId, @PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method create : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.create(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode create.",this);
		return cometResponse;	
	}

	@Secured({"ROLE_NETWORK_IMPLEMENTATION", "ROLE_COMET_ADMIN"})
	@GetMapping(value = "/cancelrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Cancel AMP Request", notes = "Cancel AMP Request")
	public CometResponse<AmpResponseBO> cancel(@PathVariable Long orderId,@PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method cancel : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.cancel(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode cancel.",this);
		return cometResponse;	
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/statusrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Status AMP Request", notes = "Status AMP Request")
	public CometResponse<AmpResponseBO> getStatusById(@PathVariable Long orderId,@PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getStatusById : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.status(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode getStatusById.",this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/detailrequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Login AMP Request", notes = "Login AMP Request")
	public CometResponse<AmpResponseBO> getDetailsById(@PathVariable Long orderId,@PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getDetailsById : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.details(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode getDetailsById.",this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/skiprequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "skip AMP Request", notes = "skip AMP Request")
	public CometResponse<AmpResponseBO> skip(@PathVariable Long orderId,@PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method skip : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.skip(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode skip.",this);
		return cometResponse;
	}
	
	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/login/{userName}/{password}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Login AMP Request", notes = "Login AMP Request")
	public CometResponse<AmpResponseBO> login(@PathVariable String userName,@PathVariable String password, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[UserName : " + (userName == null ? "" : userName) + "] "+ "Starting method login : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.login(userName, password, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode login.",this);
		return cometResponse;
	}
	
	@Secured({"ROLE_ORDER_SUBMITTERS", "ROLE_COMET_ADMIN"})
	@GetMapping(value = "/accacreaterequest/{orderId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Create Account AMP Request", notes = "Create Account AMP Request")
	public CometResponse<List<AmpResponseBO>> createAcca(@PathVariable Long orderId, @PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method createAcca : ", this);
		
		List<AmpResponseBO> responseBO = new ArrayList<AmpResponseBO>();
		CometResponse<List<AmpResponseBO>> cometResponse = new CometResponse<List<AmpResponseBO>>();
		
		try {
			responseBO = eiisComService.createAccaRequest(orderId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode createAcca.",this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/accastatusrequest/{orderId}/{requestId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Account Status AMP Request", notes = "Account Status AMP Request")
	public CometResponse<AmpResponseBO> getAccaStatusById(@PathVariable Long orderId, @PathVariable String requestId, @PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getAccaStatusById : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.accaStatus(orderId, requestId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode getAccaStatusById.",this);
		return cometResponse;
	}

	@Secured({"IS_AUTHENTICATED_FULLY"})
	@GetMapping(value = "/accadetailrequest/{orderId}/{requestId}/{attuid}", produces = {MediaType.APPLICATION_JSON_VALUE }, headers = "X-API-VERSION=1")
	@ApiOperation(value = "Account Details AMP Request", notes = "Account Details AMP Request")
	public CometResponse<AmpResponseBO> getAccaDetailsById(@PathVariable Long orderId, @PathVariable String requestId, @PathVariable String attuid, @RequestHeader("Authorization") String token, Authentication authentication) throws CometDataException,CometServiceException{
		logger.info("[OrderId : " + (orderId == null ? "" : orderId) + "] "+ "Starting method getAccaDetailsById : ", this);
		
		AmpResponseBO responseBO;
		CometResponse<AmpResponseBO> cometResponse = new CometResponse<AmpResponseBO>();
		
		try {
			responseBO = eiisComService.accaDetails(orderId, requestId, attuid, token);
			cometResponse.setMethodReturnValue(responseBO);
			cometResponse.setStatusCode(Status.SUCCESS.getCode());
			cometResponse.setStatus(Status.SUCCESS);
		} catch (Exception e) {
			cometResponse.setStatusCode(Status.BUSINESS_ERROR.getCode());
			cometResponse.setStatus(Status.BUSINESS_ERROR);
			e.printStackTrace();
		}
		
		logger.info("Exiting methode getAccaDetailsById.",this);
		return cometResponse;
	}
}